# CANLI SİSTEM HARİTASI — Uygulama Raporu

> Oluşturulma: 2026-05-22  
> Dosya: `frontend/src/LiveTopology.tsx`  
> Backend: `backend/app/api/topology.py`

---

## 1. Genel Bakış

**CANLI SİSTEM HARİTASI**, StokFinans altyapısının gerçek zamanlı SVG tabanlı görselleştirmesidir. Dark-mode, Datadog/Grafana tarzı, glassmorphism paneller ve neon glow animasyonlarıyla tasarlanmıştır. Süper admin rolüne özel olup 2 saniyelik polling döngüsüyle API'den canlı veri çeker.

---

## 2. Katmanlı Sol→Sağ Yerleşim (SVG 1100×650)

```
L1 (x≈90)   L2 (x≈270)   L3 (x≈470)   L4 (x≈670)   L5 (x≈880)
──────────   ──────────   ──────────   ──────────   ──────────
Kullanıcılar  Bayiler     İnternet     FastAPI S1   PostgreSQL
IoT Cihazlar              Nginx        FastAPI S2   MinIO S1
                                                    MinIO S2
                                                    SFTP/FTP
                                                    Harici S3
```

### Katman Açıklamaları

| Katman | x pozisyonu | İçerik | Renk |
|--------|------------|--------|------|
| **L1 — Uç Noktalar** | ~90 | Aktif kullanıcılar (rol rozetleriyle) + IoT cihazlar | Method rengiyle |
| **L2 — Bayiler** | ~270 | Bayi/dükkan düğümleri, cihaz/kullanıcı sayacı, paket rozeti | Paket rengiyle |
| **L3 — Ağ Geçidi** | ~470 | İnternet (y=195) + Nginx LB (y=395) | Gri + Cyan |
| **L4 — Uygulama** | ~670 | FastAPI S1 Ana (y=275) + S2 Yedek (y=465) | Violet |
| **L5 — Veri & Depolama** | ~880 | PostgreSQL, MinIO ×2, SFTP, Harici S3 | Mavi/Yeşil/Amber |

Katmanlar arası dikey ayraç çizgileri ve yarı-saydam renkli şeritlerle görsel olarak ayrılmıştır.

---

## 3. Bağlantı (Edge) Sistemi

### S-eğrisi (Cubic Bezier)
Yatay baskın bağlantılar (ör. Nginx→FastAPI):
```
M x1 y1 C mx y1, mx y2, x2 y2
```
Dikey baskın bağlantılar (ör. MinIO S1→S2):
```
M x1 y1 Q cx cy x2 y2
```

### Standart Trafik (bekleme hali)
- Silik, yavaş akan kesikli çizgiler (`stroke-dasharray: 3 13`)
- CSS `@keyframes dash` animasyonu ile sürekli akış hissi
- Her kenarın rengi kaynak node'un sağlık durumundan gelir (yeşil=ok, sarı=warn, kırmızı=error)

### Neon Glow (olay tetiklenince)
Bir topoloji olayı geldiğinde ilgili yol **3.5 saniye** boyunca parlak neon çizgiyle aydınlanır:

```
Glow Katmanı 1: stroke-width=6, opacity=0.25, filter=glow-strong
Glow Katmanı 2: stroke-width=2.5, dash-animated, filter=glow, neon-pulse animasyonu
```

**SVG Filter tanımları:**
- `#glow` → stdDeviation=4 (orta parlaklık)
- `#glow-strong` → stdDeviation=8, çift blur katmanı (güçlü hale efekti)

---

## 4. Veri Akışı Renk Kodlaması

| Renk | Olay Türü | Görsel |
|------|-----------|--------|
| 🟢 Yeşil `#22c55e` | upload — Yükleme/Ekleme | Node halkası + edge glow |
| 🔵 Mavi `#3b82f6` | download — İndirme/Okuma | Node halkası + edge glow |
| 🟠 Turuncu `#f97316` | replicate — Çoğaltma | S1↔S2 bağlantısı |
| 🟡 Sarı `#eab308` | backup — Yedekleme | MinIO→SFTP/S3 |
| 🔴 Kırmızı `#ef4444` | delete/error — Silme/Hata | Tüm etkilenen yol |
| 🟣 Mor `#a855f7` | health — Sağlık kontrolü | Nginx→Backend |

### Olay → Yol Eşlemesi
```typescript
upload    → [nginx, backend-s1, postgres, minio-s1]
download  → [nginx, backend-s1, postgres]
replicate → [backend-s1, backend-s2, minio-s1, minio-s2]
backup    → [backend-s1, minio-s1, sftp, s3-ext]
delete    → [nginx, backend-s1, postgres]
health    → [nginx, backend-s1]
error     → [from_node]
```

---

## 5. Etkileşim Sistemi

### Hover (fare üzerine gelme)
Bir node'a gelindiğinde o node'un tooltip'i açılır (SVG içi `<g>` grubu).  
`highlightPath` yoksa `hovered` state üzerinden `nodeVisible()` ve `edgeVisible()` fonksiyonları çalışır — ilgisiz node'lar `opacity: 0.15`'e düşer.

### Highlight (neon aydınlatma) — 2 tetikleyici
1. **Otomatik:** `fetchEvents` her 2sn'de çalışır, gelen yeni olay varsa ilgili path `Set<string>` olarak `highlightPath` state'e yazılır. 3.5sn sonra `setTimeout` ile temizlenir.
2. **Manuel (Ticker):** Sağ alt köşedeki Olay Akışı tickerından bir satıra tıklanınca aynı highlight tetiklenir.

### Sağ Tık Menüsü (Context Menu)
Belirli node'lara sağ tıklanınca ilgili uygulama sekmesine yönlendirme menüsü açılır:
- `devices` → Cihaz Yönetimi
- `minio-s1/s2` → Depolama Havuzu
- `backend-s1` → Eşleşme / Sistem Yedeği
- `nginx` → Güvenlik

### Filtreler (üst toolbar)
`Tümü | Sunucular | Veritabanı | Depolama | Dış` — seçilen filtre dışındaki node ve edge'ler `opacity: 0.06–0.15`'e düşer.

---

## 6. Canlı Olay Akışı Ticker (Sağ Alt Köşe)

Haritanın sağ alt köşesinde yarı saydam glassmorphism panel içinde son 12 olay listelenir:

```
🟢 14:32:05  Yükleme   Kullanıcı A → ürün eklendi
🔵 14:31:58  İndirme   products listesi
🟣 14:31:47  Sağlık    backend-s1 → nginx
```

**Tıklanabilir:** Her satıra tıklanınca o olayın geçtiği altyapı yolu (örn. Nginx→S1→PostgreSQL) **3.5 saniye neon glow** ile haritada vurgulanır.

---

## 7. Katman 2 — Bayiler (L2, x=270)

`/api/v1/topology/cluster` endpoint'inden her 20sn'de çekilen verilerle oluşturulur.  
İlk 10 bayi gösterilir (dikey yayılım: y=70→580).

Her bayi düğümü şunları gösterir:
- 🏪 ikon + şirket adı (sağda)
- `{cihaz_online}/{cihaz_toplam} cihaz · {aktif_kullanıcı} kullanıcı`
- Aktif kullanıcı varsa mavi rozet (sol üst köşe)
- Paket rengiyle çerçeve (starter/basic/pro/enterprise)
- Bayi → İnternet S-eğrisi bağlantısı (aktifse animasyonlu paket)

---

## 8. Katman 1 — Kullanıcılar (L1, x=90)

`/api/v1/topology/users` endpoint'inden her 4sn'de çekilen aktif kullanıcılar.  
Her bayi için en fazla 4 kullanıcı, bayinin y pozisyonu etrafında 40px aralıklı dizilir.

Her kullanıcı düğümü şunları gösterir:
- Baş harfleri (2 harf) + HTTP method rengiyle çerçeve
- Son 30sn içinde aktifse `animateMotion` ile akan paket + titreşen halka
- Rol rozeti (Patron/Personel/SüperAdmin)
- Endpoint adı (kısaltılmış)
- Kullanıcı → Bayi S-eğrisi bağlantısı

Bayisiz kullanıcılar (süper admin vb.) doğrudan İnternet node'una bağlanır.

---

## 9. Canvas Üst Katmanı (WebGL yok, 2D Canvas RAF)

SVG'nin üzerinde şeffaf `<canvas>` elemanı bulunur. `requestAnimationFrame` döngüsüyle:
- **Parçacıklar (Particles):** Topoloji olaylarından üretilen renkli noktalar bezier eğrisi boyunca hareket eder. Glow efekti için `shadowBlur` kullanılır.
- **Aktif Kenar Izgarası:** Parçacık geçtiği kenar 800ms boyunca canvas üzerinde parlak çizgi olarak gösterilir.

SVG ile canvas koordinat senkronizasyonu `svgRef.current.getScreenCTM()` ile sağlanır.

---

## 10. Backend API Endpoint'leri

| Endpoint | Polling | Amaç |
|----------|---------|------|
| `GET /api/v1/topology/snapshot` | 15sn | Node statüsleri (ok/warn/error), sistem metrikleri |
| `GET /api/v1/topology/events` | 2sn | Yeni olaylar (since_id ile delta), parçacık ve highlight tetikler |
| `GET /api/v1/topology/cluster` | 20sn | Bayi listesi + cihazlar + personel sayısı |
| `GET /api/v1/topology/users` | 4sn | Son 5dk aktif kullanıcılar (in-memory cache) |
| `GET /api/v1/topology/stats` | — | Olay sayımları (kullanılmıyor, hazır) |
| `GET /api/v1/topology/alert-count` | 30sn | Sidebar badge uyarı sayısı |

Tüm endpoint'ler `is_super_admin=True` gerektirir.

---

## 11. Kullanıcı Aktivitesi İzleme

`backend/app/utils/activity.py` — in-memory `dict` (uvicorn worker başına):
```python
_user_activity[user_id] = {
    "email", "name", "endpoint", "method",
    "role", "tenant_id", "ts"
}
```
`backend/app/utils/auth.py` içindeki `get_current_user` her istekte `track_user_access()` çağırır. `tenant_id` rolden hesaplanır:
- `bayi_sahibi` → kendi `id`'si
- `calisan` → `parent_user_id`

5 dakikadan eski girişler otomatik temizlenir.

---

## 12. Topoloji Olayları Veritabanı

`topology_events` tablosu PostgreSQL'de yaşar:
```sql
id          SERIAL PRIMARY KEY
event_type  TEXT  -- upload, download, replicate, backup, delete, health, error
from_node   TEXT  -- backend-s1, nginx, minio-s1 ...
to_node     TEXT  -- nullable
message     TEXT
created_at  TIMESTAMPTZ DEFAULT now()
```

Olaylar `emit_topology_event()` fonksiyonuyla yazılır (kendi session açar/kapatır, caller session'ını bozmaz). 60 dakikadan eski olaylar scheduler tarafından temizlenir.

---

## 13. Diğer Alt Bileşenler

| Bileşen | Amaç |
|---------|------|
| `ClusterOrbit` | Bayileri S1/S2 etrafında yörüngesel SVG ile gösterir (ayrı panel) |
| `TenantDetail` | Tıklanan bayinin detay paneli (cihazlar, kullanıcılar, abonelik) |
| `UserTablePanel` | Aktif kullanıcı tablosu |
| `UserNetworkMap` | S1→Bayi→Kullanıcı→Hedef ağaç haritası |
| `LiveFlowPanel` | Yatay akış animasyonu paneli |

---

## 14. Tasarım Dili

- **Arka plan:** `#020617` (near-black), radial gradient ile hafif aydınlatma
- **Panel arkaplanı:** `bg-slate-900`, `border-slate-700`
- **Glassmorphism:** `rgba(2,6,23,0.90)` + `backdropFilter: blur(8px)` (ticker overlay)
- **Nokta ızgarası:** `r=0.7, fill=#1e293b` — Grafana/Datadog tarzı arka plan dokusu
- **Yazı tipi:** Sistem sans-serif; monospace kod alanlarında
- **İkon sistemi:** Unicode emoji (🌐⚡🚀🗄️💾☁️📡)
- **Animasyonlar:** SVG `<animate>`, `<animateMotion>`, CSS `@keyframes dash` ve `pulse-glow`

---

## 15. Performans Notları

- Parçacık listesi 150 ile sınırlandırılmıştır (`slice(-150)`)
- Bayi listesi SVG'de ilk 10 gösterilir
- `useCallback` ile fetch fonksiyonları memoize edilmiştir
- Canvas RAF sadece parçacık varken yeniden render eder
- Topoloji olayları hafızada 60 kayıtla sınırlıdır (`slice(0, 60)`)
