import React, { useState, useMemo, createContext, useContext, useEffect } from 'react';
import { 
  LayoutDashboard, Package, TrendingUp, Users, Settings, 
  LogOut, CreditCard, Building2, UserCircle, Menu, X, 
  Check, ArrowRight, BarChart3, Wallet, Box, ShieldAlert,
  Wind, Shield, Footprints, Disc, Layers, Car, BookOpen, FileText, Landmark, Calculator, Award, PieChart, History, AlertTriangle, FileDown, XCircle, AlertCircle, BarChart,
  Search, Plus, Edit, Trash, Image as ImageIcon, Barcode, Hash, UploadCloud, ArrowLeft, PlusCircle, MinusCircle, Camera, SlidersHorizontal, UserPlus, ShieldCheck, Lock, ChevronRight, Activity,
  Gift, Copy, Clock, ShieldBan, Moon, Sun, Globe
} from 'lucide-react';

// --- YARDIMCI FONKSİYONLAR ---
const sortAlpha = (arr, key) => [...arr].sort((a, b) => String(a[key]).localeCompare(String(b[key]), 'tr-TR'));
const formatMoney = (amount) => new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(amount);

// --- DİL SÖZLÜĞÜ (İNGİLİZCE) ---
const EN_DICT = {
  'Giriş Yap': 'Log In',
  'Ücretsiz Başla': 'Start for Free',
  'İşletmenizin Stok ve Finansını': 'Manage Your Stock and Finances',
  'Tek Noktadan': 'In One Place',
  'Yönetin': '',
  'Karmaşık Excel tablolarına elveda deyin. Çalışan izinleri, esnek grafikler, veresiye takibi ve detaylı raporlarla tam kontrolü elinize alın.': 'Say goodbye to complex Excel sheets. Take full control with employee permissions, flexible charts, credit tracking, and detailed reports.',
  'Hemen Hesap Oluştur': 'Create Account Now',
  'Tekrar Hoş Geldiniz': 'Welcome Back',
  'Aramıza Katılın': 'Join Us',
  'Yönetim paneline erişmek için giriş yapın.': 'Log in to access the management dashboard.',
  'Ücretsiz hesabınızı saniyeler içinde oluşturun.': 'Create your free account in seconds.',
  'Bayi (Kurucu)': 'Dealer (Founder)',
  'Çalışan': 'Employee',
  'İşletme Adı': 'Company Name',
  'Ad Soyad': 'Full Name',
  'E-posta Adresi': 'Email Address',
  'Şifre': 'Password',
  'Referans Kodu (Opsiyonel)': 'Referral Code (Optional)',
  'Sisteme Giriş Yap': 'Log In to System',
  'Hesabımı Oluştur': 'Create My Account',
  'Hesabınız yok mu?': 'Don\'t have an account?',
  'Zaten hesabınız var mı?': 'Already have an account?',
  'Kayıt Ol': 'Sign Up',
  'Hızlı Test Girişleri': 'Quick Test Logins',
  'Bayi (Patron)': 'Dealer (Boss)',
  'Personel (Sınırlı)': 'Staff (Limited)',
  
  // Sidebar & Modules
  'Ana Panel': 'Dashboard',
  'STOK YÖNETİMİ (A-Z)': 'STOCK MANAGEMENT (A-Z)',
  'Genel Ürünler': 'General Products',
  'Cam Rüzgarlığı': 'Window Deflectors',
  'Jant Kapağı': 'Hubcaps',
  'Kaput Rüzgarlığı': 'Hood Deflectors',
  'Pandizot': 'Rear Decks',
  'Paspas': 'Floor Mats',
  'Spoiler': 'Spoilers',
  'FİNANS & YÖNETİM (A-Z)': 'FINANCE & MGT. (A-Z)',
  'Firma Borçları': 'Company Debts',
  'Garanti Belgeleri': 'Warranties',
  'İşlem Geçmişi': 'Transaction History',
  'Kasa Defteri': 'Cash Book',
  'Krediler': 'Loans',
  'Gelişmiş Raporlar': 'Advanced Reports',
  'Senetler': 'Promissory Notes',
  'Veresiye (Müşteri)': 'Credit (Customer)',
  'SİSTEM AYARLARI': 'SYSTEM SETTINGS',
  'Personel Yönetimi': 'Staff Management',
  'İşletme Profili': 'Company Profile',
  'Abonelik & Davet Et': 'Subscription & Invites',
  'Ayarlar (Yetki Yok)': 'Settings (No Access)',
  'Çıkış Yap': 'Log Out',
  
  // Dashboard Core
  'Aktif Modüller:': 'Active Modules:',
  'Stok Kısayolları': 'Stock Shortcuts',
  'Finans Kısayolları': 'Finance Shortcuts',
  'Kritik Stok Uyarıları': 'Critical Stock Alerts',
  'Panel Görünümü': 'Panel View',
  'STOK YÖNETİMİ & KATEGORİLER (A-Z)': 'STOCK MANAGEMENT & CATEGORIES (A-Z)',
  'FİNANS, RAPOR & YÖNETİM (A-Z)': 'FINANCE, REPORTS & MANAGEMENT (A-Z)',
  'Kritik Stok Uyarısı': 'Critical Stock Alert',
  'Aşağıdaki': 'The following',
  'ürün stok limitinin altında! (A-Z Sıralı)': 'products are below the stock limit! (A-Z Sorted)',
  'Tümünü İncele': 'View All',
  'Kategori': 'Category',
  'Ürün Modeli': 'Product Model',
  'Stok': 'Stock',
  'Durum': 'Status',
  'TÜKENDİ': 'OUT OF STOCK',
  'KRİTİK': 'CRITICAL',
  'Hoşgeldiniz': 'Welcome',
  'genel durum panelindesiniz.': 'you are in the general dashboard.',
  
  // Actions
  'Yeni Kayıt': 'New Record',
  'Ad, model veya barkod ara...': 'Search name, model, or barcode...',
  'Toplam': 'Total',
  'kayıt listeleniyor. Sıralama: A-Z.': 'records listed. Sorted: A-Z.',
  'Yönetimi': 'Management',
  'Sistem Aktif': 'System Active',
  'Değişiklikleri Kaydet': 'Save Changes',
  'Kaydı Tamamla': 'Complete Record',
  'İptal Et': 'Cancel',
  'Kaydı Düzenle': 'Edit Record',
  
  // History & Profile
  'Tüm Kategoriler': 'All Categories',
  'Stok İşlemleri': 'Stock Transactions',
  'Finans & Cari': 'Finance & Credit',
  'Sistem Ayarları': 'System Settings',
  'Görseli İncele': 'View Image',
  'Deneme Sürümü': 'Trial Version',
  'Gün': 'Days',
  'kalan ücretsiz kullanım süreniz.': 'remaining free trial duration.',
};

// --- GLOBAL CONTEXT (Dil ve Tema) ---
const AppContext = createContext();
const useAppContext = () => useContext(AppContext);

const SettingsToggle = () => {
  const { theme, toggleTheme, lang, toggleLang } = useAppContext();
  return (
    <div className="flex items-center gap-2">
      <button onClick={toggleLang} className="flex items-center justify-center w-14 h-9 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition font-black text-xs shadow-sm">
        <Globe size={14} className="mr-1 opacity-50" /> {lang === 'tr' ? 'EN' : 'TR'}
      </button>
      <button onClick={toggleTheme} className="flex items-center justify-center w-10 h-9 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition shadow-sm">
        {theme === 'dark' ? <Sun size={18} className="text-amber-400" /> : <Moon size={18} className="text-indigo-600 dark:text-indigo-400" />}
      </button>
    </div>
  );
};

// --- MOCK VERİTABANI ---
export const mockDB = {
  users: [
    { email: 'patron@etiketoto.com', refCode: 'ETIKET2026', ip: '192.168.1.5', subDays: 14 }
  ],
  currentClientIP: '192.168.1.10' 
};

// --- MOCK VERİLER ---
const etiketKritikStoklar = sortAlpha([
  { id: 1, kategori: 'CAM', model: 'Fiat Tofaş cam rüzgarlığı', stok: 0, durum: 'TÜKENDİ' },
  { id: 2, kategori: 'CAM', model: 'Fiat Fiorino ön iki cam rüzgarlığı', stok: 1, durum: 'KRİTİK' },
  { id: 3, kategori: 'CAM', model: 'Fiat Albea cam rüzgarlığı', stok: 0, durum: 'TÜKENDİ' },
  { id: 4, kategori: 'KAPUT', model: 'Ford Transit 2002-2006 kaput rüzgarlığı', stok: 1, durum: 'KRİTİK' },
  { id: 5, kategori: 'PASPAS', model: 'Volkswagen Jetta 3D Paspas', stok: 1, durum: 'KRİTİK' },
  { id: 6, kategori: 'PANDIZOT', model: '30cm Kabinli Pandizot', stok: 1, durum: 'KRİTİK' },
  { id: 7, kategori: 'SPOILER', model: 'Volkswagen T7 Spoiler', stok: 1, durum: 'KRİTİK' },
], 'model');

// --- BİLEŞENLER ---

// 1. Karşılama Sayfası (Landing Page)
const LandingPage = ({ setView }) => {
  const { t } = useAppContext();
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col font-sans transition-colors duration-300">
      <nav className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 py-4 flex justify-between items-center sticky top-0 z-50 transition-colors duration-300">
        <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
          <TrendingUp size={28} className="font-bold" />
          <span className="text-xl sm:text-2xl font-black tracking-tight">StokFinans</span>
        </div>
        <div className="flex items-center gap-2 sm:gap-4">
          <SettingsToggle />
          <button onClick={() => setView('login')} className="hidden sm:block px-5 py-2 text-slate-600 dark:text-slate-300 font-medium hover:text-indigo-600 dark:hover:text-indigo-400 transition">{t('Giriş Yap')}</button>
          <button onClick={() => setView('register')} className="px-4 sm:px-5 py-2 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 transition shadow-sm text-sm sm:text-base">{t('Ücretsiz Başla')}</button>
        </div>
      </nav>
      <main className="flex-1 flex flex-col items-center justify-center text-center px-4 py-20 bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 transition-colors duration-300">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 font-bold text-sm mb-8 animate-in slide-in-from-bottom-4 border border-indigo-200 dark:border-indigo-800/50">
          <span className="flex h-2 w-2 rounded-full bg-indigo-600 dark:bg-indigo-400"></span>
          Yeni Nesil Oto Aksesuar Yönetimi
        </div>
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-slate-900 dark:text-white mb-6 max-w-4xl leading-tight animate-in slide-in-from-bottom-5">
          {t('İşletmenizin Stok ve Finansını')} <span className="text-indigo-600 dark:text-indigo-400">{t('Tek Noktadan')}</span> {t('Yönetin')}
        </h1>
        <p className="text-lg md:text-xl text-slate-600 dark:text-slate-400 mb-10 max-w-2xl animate-in slide-in-from-bottom-6 delay-75">
          {t('Karmaşık Excel tablolarına elveda deyin. Çalışan izinleri, esnek grafikler, veresiye takibi ve detaylı raporlarla tam kontrolü elinize alın.')}
        </p>
        <div className="flex flex-col sm:flex-row gap-4 animate-in slide-in-from-bottom-8 delay-150">
          <button onClick={() => setView('register')} className="px-8 py-4 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition text-lg shadow-xl shadow-indigo-200 dark:shadow-indigo-900/20 flex items-center justify-center gap-2 hover:-translate-y-1">
            {t('Hemen Hesap Oluştur')} <ArrowRight size={20} />
          </button>
        </div>
      </main>
    </div>
  );
};

// 2. Giriş & Kayıt Sayfaları
const AuthPage = ({ setView, isLogin, setCurrentUser }) => {
  const { t } = useAppContext();
  const [role, setRole] = useState('bayi');
  const [errorMsg, setErrorMsg] = useState('');
  const [testIP, setTestIP] = useState(mockDB.currentClientIP); 

  const handleLogin = (e) => {
    e.preventDefault();
    setErrorMsg('');
    const formData = new FormData(e.target);
    const email = formData.get('email');
    const refCode = formData.get('refCode')?.trim().toUpperCase();

    if (isLogin) {
      setCurrentUser({
        role: 'bayi_sahibi', name: 'Bayi Yöneticisi', email: email || 'demo@mail.com',
        permissions: { canAdd: true, canEdit: true, canDelete: true, allowedModules: 'all' },
        myRefCode: 'ETIKET2026', subDays: 14
      });
      setView('customerDashboard');
    } else {
      let finalSubDays = 14; 
      let isRefApplied = false;

      if (role === 'bayi' && refCode) {
        const referrer = mockDB.users.find(u => u.refCode === refCode);
        if (!referrer) {
          setErrorMsg(t('Geçersiz referans kodu. Lütfen kodu kontrol edip tekrar deneyin.'));
          return; 
        }
        if (referrer.ip === testIP) {
          setErrorMsg(t('Güvenlik İhlali: Aynı IP adresi / ağ üzerinden kendi kendinize referans olamazsınız!'));
          return; 
        }
        finalSubDays = 24; 
        referrer.subDays += 10; 
        isRefApplied = true;
      }

      const myNewRefCode = role === 'bayi' ? 'BAYI' + Math.floor(10000 + Math.random() * 90000) : null;
      if (role === 'bayi') {
         mockDB.users.push({ email: email, refCode: myNewRefCode, ip: testIP, subDays: finalSubDays });
      }

      setCurrentUser({
        role: role === 'bayi' ? 'bayi_sahibi' : 'calisan',
        name: role === 'bayi' ? t('Yeni Bayi') : t('Yeni Çalışan'),
        email: email,
        permissions: role === 'bayi' 
          ? { canAdd: true, canEdit: true, canDelete: true, allowedModules: 'all' }
          : { canAdd: false, canEdit: false, canDelete: false, allowedModules: [] },
        myRefCode: myNewRefCode,
        subDays: finalSubDays,
        isRefApplied: isRefApplied
      });
      setView('customerDashboard');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4 relative transition-colors duration-300">
      <div className="absolute top-4 right-4 sm:top-8 sm:right-8 z-50">
         <SettingsToggle />
      </div>

      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 p-8 animate-in zoom-in-95 duration-300 mt-12 sm:mt-0">
        <div className="flex justify-center mb-6 text-indigo-600 dark:text-indigo-400"><TrendingUp size={48} className="font-bold drop-shadow-md" /></div>
        <h2 className="text-3xl font-black text-center text-slate-800 dark:text-white mb-2">{isLogin ? t('Tekrar Hoş Geldiniz') : t('Aramıza Katılın')}</h2>
        <p className="text-center text-slate-500 dark:text-slate-400 mb-6 text-sm">{isLogin ? t('Yönetim paneline erişmek için giriş yapın.') : t('Ücretsiz hesabınızı saniyeler içinde oluşturun.')}</p>

        {!isLogin && (
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1.5 rounded-xl mb-6">
            <button type="button" onClick={() => setRole('bayi')} className={`flex-1 py-2.5 text-sm font-bold rounded-lg transition-all ${role === 'bayi' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}>{t('Bayi (Kurucu)')}</button>
            <button type="button" onClick={() => setRole('calisan')} className={`flex-1 py-2.5 text-sm font-bold rounded-lg transition-all ${role === 'calisan' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}>{t('Çalışan')}</button>
          </div>
        )}

        {errorMsg && (
           <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800/50 text-red-600 dark:text-red-400 text-sm font-bold rounded-xl flex items-start gap-2">
             <ShieldBan size={18} className="shrink-0 mt-0.5" />
             <span>{errorMsg}</span>
           </div>
        )}

        <form className="space-y-4" onSubmit={handleLogin}>
          {!isLogin && role === 'bayi' && (
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">{t('İşletme Adı')}</label>
              <input type="text" name="company" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-indigo-600 outline-none transition" placeholder="Örn: Etiket Oto Aksesuar" required />
            </div>
          )}
          {!isLogin && role === 'calisan' && (
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">{t('Ad Soyad')}</label>
              <input type="text" name="fullname" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-indigo-600 outline-none transition" placeholder="Adınız Soyadınız" required />
            </div>
          )}
          <div>
            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">{t('E-posta Adresi')}</label>
            <input type="email" name="email" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-indigo-600 outline-none transition" placeholder="ornek@mail.com" required />
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">{t('Şifre')}</label>
            <input type="password" name="password" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-indigo-600 outline-none transition" placeholder="••••••••" required />
          </div>
          
          {!isLogin && role === 'bayi' && (
             <div className="pt-2">
               <label className="block text-sm font-bold text-indigo-700 dark:text-indigo-400 mb-1 flex items-center gap-1"><Gift size={16}/> {t('Referans Kodu (Opsiyonel)')}</label>
               <input type="text" name="refCode" className="w-full px-4 py-3 bg-indigo-50/50 dark:bg-indigo-900/20 text-slate-800 dark:text-slate-100 rounded-xl border border-indigo-100 dark:border-indigo-800 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-indigo-600 outline-none transition font-bold uppercase" placeholder="KOD GİRİN, +10 GÜN KAZANIN!" />
             </div>
          )}

          <button type="submit" className="w-full bg-indigo-600 text-white font-bold py-3.5 rounded-xl hover:bg-indigo-700 transition shadow-lg shadow-indigo-200 dark:shadow-indigo-900/20 mt-2">{isLogin ? t('Sisteme Giriş Yap') : t('Hesabımı Oluştur')}</button>
        </form>

        <div className="mt-6 text-center text-slate-500 dark:text-slate-400 text-sm font-medium">
          {isLogin ? t('Hesabınız yok mu?') : t('Zaten hesabınız var mı?')} 
          <button onClick={() => setView(isLogin ? 'register' : 'login')} className="text-indigo-600 dark:text-indigo-400 font-bold ml-1 hover:underline">{isLogin ? t('Kayıt Ol') : t('Giriş Yap')}</button>
        </div>
        
        <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 text-center flex flex-col gap-3">
           <span className="text-xs text-slate-400 dark:text-slate-500 font-black tracking-widest uppercase">{t('Hızlı Test Girişleri')}</span>
           <div className="flex gap-2 justify-center">
             <button type="button" onClick={() => { setCurrentUser({ role: 'bayi_sahibi', name: 'Patron', email: 'patron@etiketoto.com', permissions: { canAdd: true, canEdit: true, canDelete: true, allowedModules: 'all' }, myRefCode: 'ETIKET2026', subDays: 14 }); setView('customerDashboard'); }} className="px-3 py-1.5 bg-indigo-50 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-800 text-xs font-bold rounded-lg hover:bg-indigo-100 transition">{t('Bayi (Patron)')}</button>
             <button type="button" onClick={() => { setCurrentUser({ role: 'calisan', name: 'Personel Ali', email: 'ali@etiketoto.com', permissions: { canAdd: true, canEdit: false, canDelete: false, allowedModules: ['stock_general', 'stock_cam'] } }); setView('customerDashboard'); }} className="px-3 py-1.5 bg-emerald-50 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 border border-emerald-100 dark:border-emerald-800 text-xs font-bold rounded-lg hover:bg-emerald-100 transition">{t('Personel (Sınırlı)')}</button>
           </div>
        </div>
      </div>

      {!isLogin && (
        <div className="mt-8 w-full max-w-md bg-white/80 dark:bg-slate-900/80 backdrop-blur p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm text-xs text-slate-500 dark:text-slate-400 font-mono">
           <p className="font-bold text-slate-700 dark:text-slate-300 mb-2 border-b border-slate-200 dark:border-slate-700 pb-2">🛠️ Anti-Hile Test Paneli (Normalde Gizli)</p>
           <div className="flex items-center justify-between">
              <span>Mevcut IP Adresiniz:</span>
              <div className="flex items-center gap-2">
                 <input type="text" value={testIP} onChange={(e) => setTestIP(e.target.value)} className="border border-slate-300 dark:border-slate-600 rounded px-2 py-1 w-28 bg-transparent text-slate-800 dark:text-white" />
                 <button type="button" onClick={() => setTestIP('192.168.1.5')} className="px-2 py-1 bg-slate-200 dark:bg-slate-700 rounded hover:bg-slate-300 dark:hover:bg-slate-600 font-bold">Çakıştır (Hata Al)</button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

// 3. ÖZEL MODÜLLER 

// 3.1 İşletme Profili ve Ayarlar
const ProfileSettingsView = () => {
  const { t } = useAppContext();
  return (
    <div className="max-w-4xl space-y-6 animate-in slide-in-from-bottom-4 duration-300">
      <div className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center shrink-0"><Building2 size={32} /></div>
          <div>
            <h2 className="text-2xl font-black text-slate-800 dark:text-white">{t('İşletme Profili')}</h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Firma bilgilerinizi ve faturaya yansıyacak detayları güncelleyin.</p>
          </div>
        </div>

        <form className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Firma Resmi Unvanı</label>
              <input type="text" defaultValue="Etiket Oto Aksesuar San. ve Tic. Ltd. Şti." className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 outline-none transition" />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Kısa İşletme Adı</label>
              <input type="text" defaultValue="Etiket Oto Aksesuar" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 outline-none transition" />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Vergi Dairesi</label>
              <input type="text" defaultValue="Marmara Kurumlar V.D." className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 outline-none transition" />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Vergi No / TCKN</label>
              <input type="text" defaultValue="1234567890" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 outline-none transition" />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Açık Adres</label>
              <textarea rows="3" defaultValue="Sanayi Mahallesi, Oto Sanayi Sitesi, 14. Sokak No: 12, İstanbul" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 outline-none transition resize-none"></textarea>
            </div>
          </div>
          
          <div className="pt-6 border-t border-slate-100 dark:border-slate-800 flex justify-end">
            <button type="button" className="px-6 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition shadow-md flex items-center gap-2">
              <Check size={18} /> {t('Değişiklikleri Kaydet')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// 3.2 Gelişmiş Raporlar Görünümü
const ReportsDashboardView = () => {
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div>
          <h2 className="text-2xl font-black text-slate-800 dark:text-white">Gelişmiş Finans Raporları</h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">İşletmenizin genel finansal durumunu ve stok özetlerini inceleyin.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition">
          <FileDown size={18} /> PDF Çıktısı Al
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { title: 'Aylık Toplam Ciro', val: '₺145.250,00', color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-100 dark:bg-emerald-900/30', icon: TrendingUp },
          { title: 'Bekleyen Tahsilat', val: '₺32.400,00', color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-100 dark:bg-amber-900/30', icon: Wallet },
          { title: 'Firma Borçları', val: '₺45.000,00', color: 'text-red-600 dark:text-red-400', bg: 'bg-red-100 dark:bg-red-900/30', icon: Building2 },
          { title: 'Kritik Stok Uyarısı', val: '7 Ürün', color: 'text-purple-600 dark:text-purple-400', bg: 'bg-purple-100 dark:bg-purple-900/30', icon: Package },
        ].map((card, i) => (
          <div key={i} className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
            <div className={`w-14 h-14 ${card.bg} ${card.color} rounded-2xl flex items-center justify-center shrink-0`}>
              <card.icon size={28} />
            </div>
            <div>
              <p className="text-sm font-bold text-slate-500 dark:text-slate-400 mb-1">{card.title}</p>
              <h3 className="text-2xl font-black text-slate-800 dark:text-white tracking-tight">{card.val}</h3>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-6 flex items-center gap-2"><BarChart size={20} className="text-indigo-500"/> Satış Grafiği (Son 6 Ay)</h3>
          <div className="h-64 flex items-end justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2">
             {[40, 65, 45, 80, 55, 90].map((h, i) => (
               <div key={i} className="w-full flex flex-col items-center gap-2 group">
                 <div className="w-full bg-indigo-100 dark:bg-indigo-900/30 rounded-t-lg relative flex-1 flex items-end transition-colors">
                   <div className="w-full bg-indigo-500 rounded-t-lg shadow-inner transition-all duration-1000 ease-out" style={{ height: `${h}%` }}></div>
                   <span className="absolute -top-8 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-slate-800 text-white text-xs font-bold px-2 py-1 rounded transition-opacity">₺{h}k</span>
                 </div>
                 <span className="text-xs font-bold text-slate-400">{'Oca Şub Mar Nis May Haz'.split(' ')[i]}</span>
               </div>
             ))}
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-6 flex items-center gap-2"><Activity size={20} className="text-emerald-500"/> En Çok Satan Ürünler</h3>
          <div className="space-y-4">
            {[
              { name: 'Fiat Fiorino Cam Rüzgarlığı', cat: 'CAM', qty: 145 },
              { name: 'Volkswagen Jetta 3D Paspas', cat: 'PASPAS', qty: 98 },
              { name: 'Ford Transit Kaput Koruma', cat: 'KAPUT', qty: 76 },
              { name: 'Universal 16 İnç Jant Kapağı', cat: 'JANT', qty: 54 },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-700/50">
                 <div className="flex items-center gap-3">
                   <div className="w-8 h-8 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded flex items-center justify-center font-bold text-slate-400 text-xs">#{i+1}</div>
                   <div>
                     <p className="font-bold text-slate-800 dark:text-white text-sm">{item.name}</p>
                     <p className="text-xs font-medium text-slate-500 dark:text-slate-400">{item.cat}</p>
                   </div>
                 </div>
                 <span className="px-3 py-1 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 font-bold rounded-lg text-sm">{item.qty} Adet</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// 3.3 İşlem Geçmişi (Kategorili ve Fotoğraflı)
const HistoryLogView = () => {
  const { t } = useAppContext();
  const [filterCategory, setFilterCategory] = useState('Tümü');
  const [selectedImage, setSelectedImage] = useState(null);

  const logs = [
    { id: 1, user: 'Ahmet Yılmaz', action: 'Ürün Güncelledi', detail: 'Fiat Tofaş cam rüzgarlığı stok miktarı 0 olarak değiştirildi.', time: '10 Dk Önce', type: 'stok', category: 'Stok İşlemleri', icon: Edit, color: 'text-amber-500', bg: 'bg-amber-100 dark:bg-amber-900/50', image: null },
    { id: 2, user: 'Bayi Yöneticisi', action: 'Tahsilat Eklendi', detail: 'Ahmet Oto Galerisi firmasından 5.000₺ nakit tahsilat girildi.', time: '1 Saat Önce', type: 'finans', category: 'Finans & Cari', icon: PlusCircle, color: 'text-emerald-500', bg: 'bg-emerald-100 dark:bg-emerald-900/50', image: 'https://placehold.co/600x800?text=Tahsilat+Makbuzu' },
    { id: 3, user: 'Burak Demir', action: 'Yeni Ürün Eklendi', detail: 'Volkswagen T7 Spoiler sisteme tanımlandı.', time: '3 Saat Önce', type: 'stok', category: 'Stok İşlemleri', icon: Box, color: 'text-blue-500', bg: 'bg-blue-100 dark:bg-blue-900/50', image: 'https://placehold.co/600x400?text=Urun+Gorseli' },
    { id: 4, user: 'Cem Kaya', action: 'Kayıt Silindi', detail: 'Eski veresiye kaydı (Hasan Usta) silindi.', time: 'Dün', type: 'system', category: 'Sistem Ayarları', icon: Trash, color: 'text-red-500', bg: 'bg-red-100 dark:bg-red-900/50', image: null },
  ];

  const filteredLogs = filterCategory === 'Tümü' ? logs : logs.filter(log => log.category === filterCategory);

  return (
    <div className="max-w-5xl space-y-6 animate-in slide-in-from-right-4 duration-300">
      <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-xl flex items-center justify-center shrink-0"><History size={24} /></div>
          <div>
            <h2 className="text-2xl font-black text-slate-800 dark:text-white">{t('İşlem Geçmişi')}</h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Sistemdeki tüm hareketler ve değişiklik kayıtları.</p>
          </div>
        </div>
        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          <select 
            value={filterCategory} 
            onChange={(e) => setFilterCategory(e.target.value)}
            className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-bold"
          >
            <option value="Tümü">{t('Tüm Kategoriler')}</option>
            <option value="Stok İşlemleri">{t('Stok İşlemleri')}</option>
            <option value="Finans & Cari">{t('Finans & Cari')}</option>
            <option value="Sistem Ayarları">{t('Sistem Ayarları')}</option>
          </select>
          <input type="date" className="px-4 py-2 border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 outline-none focus:ring-2 focus:ring-indigo-500 w-full sm:w-auto text-sm font-medium" />
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden p-2 sm:p-6">
         <div className="relative border-l-2 border-slate-100 dark:border-slate-800 ml-4 md:ml-6 py-4 space-y-8">
            {filteredLogs.length > 0 ? filteredLogs.map((log) => (
              <div key={log.id} className="relative pl-6 md:pl-8 group">
                <div className={`absolute -left-[17px] top-1 w-8 h-8 rounded-full border-4 border-white dark:border-slate-900 ${log.bg} flex items-center justify-center`}>
                   <log.icon size={12} className={log.color} />
                </div>
                <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800 group-hover:shadow-md transition-shadow">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-2 gap-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-slate-800 dark:text-white">{log.user}</span>
                      <span className="px-2 py-0.5 rounded bg-white dark:bg-slate-700 text-slate-500 dark:text-slate-300 border border-slate-200 dark:border-slate-600 text-xs font-bold">{log.action}</span>
                      <span className={`px-2 py-0.5 rounded text-xs font-bold ${log.category === 'Finans & Cari' ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400' : log.category === 'Stok İşlemleri' ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400' : 'bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300'}`}>{t(log.category)}</span>
                    </div>
                    <span className="text-xs font-bold text-slate-400 flex items-center gap-1"><Activity size={12}/> {log.time}</span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <p className="text-sm text-slate-600 dark:text-slate-400 font-medium">{log.detail}</p>
                    {log.image && (
                      <button onClick={() => setSelectedImage(log.image)} className="flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-800 border border-indigo-100 dark:border-indigo-900/50 text-indigo-600 dark:text-indigo-400 rounded-lg text-xs font-bold hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition shrink-0">
                        <ImageIcon size={14} /> {t('Görseli İncele')}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )) : (
               <div className="text-center py-8 text-slate-500 font-medium">Bu kategoriye ait işlem bulunamadı.</div>
            )}
         </div>
      </div>

      {selectedImage && (
        <div className="fixed inset-0 bg-slate-900/80 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-[100]" onClick={() => setSelectedImage(null)}>
           <div className="relative max-w-3xl w-full flex flex-col items-center animate-in zoom-in-95" onClick={e => e.stopPropagation()}>
              <div className="w-full flex justify-end mb-4">
                 <button onClick={() => setSelectedImage(null)} className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white backdrop-blur transition"><X size={24}/></button>
              </div>
              <img src={selectedImage} alt="İşlem Görseli" className="w-full h-auto max-h-[80vh] object-contain rounded-xl shadow-2xl" />
           </div>
        </div>
      )}
    </div>
  );
};

// 3.4 Cari Detay Görünümü (Belge/Fotoğraflı)
const CariDetailView = ({ cari, onBack, moduleTitle, permissions }) => {
  const [isTxModalOpen, setTxModalOpen] = useState(false);
  const [txType, setTxType] = useState('borc'); 
  const [txImagePreview, setTxImagePreview] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);

  const transactions = sortAlpha([
    { id: 1, date: '2026-04-10', desc: 'Açılış Bakiyesi / Mal Alımı', borc: 5000, alacak: 0, bakiye: 5000, image: 'https://placehold.co/600x800?text=Acilis+Faturasi' },
    { id: 2, date: '2026-04-15', desc: 'Elden Nakit Ödeme', borc: 0, alacak: 2000, bakiye: 3000, image: null },
    { id: 3, date: '2026-04-20', desc: 'Cam Rüzgarlığı (Yeni Sipariş)', borc: 800, alacak: 0, bakiye: 3800, image: null },
  ], 'desc'); 

  const handleOpenModal = (type) => {
    setTxType(type);
    setTxImagePreview(null);
    setTxModalOpen(true);
  };

  const handleImageUpload = (e) => {
    if (e.target.files && e.target.files[0]) {
       setTxImagePreview(URL.createObjectURL(e.target.files[0]));
    }
  };

  return (
    <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 rounded-xl transition hover:bg-slate-100 dark:hover:bg-slate-700"><ArrowLeft size={20} /></button>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-800 dark:text-white">{cari.title}</h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">{moduleTitle} / GSM: <span className="text-indigo-600 dark:text-indigo-400 font-bold">{cari.phone}</span> / VKN: {cari.vkn}</p>
          </div>
        </div>
        {permissions?.canAdd && (
          <div className="flex gap-2 w-full sm:w-auto">
            <button onClick={() => handleOpenModal('tahsilat')} className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 font-bold rounded-xl hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition border border-emerald-100 dark:border-emerald-800/50"><MinusCircle size={18} /> Tahsilat Gir</button>
            <button onClick={() => handleOpenModal('borc')} className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-400 font-bold rounded-xl hover:bg-red-100 dark:hover:bg-red-900/50 transition border border-red-100 dark:border-red-800/50"><PlusCircle size={18} /> Borçlandır</button>
          </div>
        )}
      </div>
      
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[700px]">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 text-xs uppercase border-b border-slate-200 dark:border-slate-700 tracking-wider">
                <th className="p-4 pl-6 font-bold">İşlem Tarihi</th>
                <th className="p-4 font-bold">Açıklama / İşlem Özeti</th>
                <th className="p-4 font-bold text-center">Belge</th>
                <th className="p-4 font-bold text-red-500">Borç (₺)</th>
                <th className="p-4 font-bold text-emerald-500">Alacak (₺)</th>
                <th className="p-4 pr-6 font-bold text-right text-indigo-600 dark:text-indigo-400">Güncel Bakiye</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((tx, idx) => (
                <tr key={tx.id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                  <td className="p-4 pl-6 text-slate-600 dark:text-slate-400 font-medium">{tx.date}</td>
                  <td className="p-4 font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                    {tx.borc > 0 ? <PlusCircle size={14} className="text-red-400"/> : <MinusCircle size={14} className="text-emerald-400"/>}
                    {tx.desc}
                  </td>
                  <td className="p-4 text-center">
                    {tx.image ? (
                       <button onClick={() => setSelectedImage(tx.image)} className="p-1.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 rounded-lg transition" title="Görseli İncele">
                          <ImageIcon size={18} />
                       </button>
                    ) : (
                       <span className="text-slate-300 dark:text-slate-700">-</span>
                    )}
                  </td>
                  <td className="p-4 text-red-600 dark:text-red-400 font-bold bg-red-50/30 dark:bg-red-900/10">{tx.borc > 0 ? formatMoney(tx.borc) : '-'}</td>
                  <td className="p-4 text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-50/30 dark:bg-emerald-900/10">{tx.alacak > 0 ? formatMoney(tx.alacak) : '-'}</td>
                  <td className="p-4 pr-6 text-right font-black text-slate-800 dark:text-white">{formatMoney(tx.bakiye)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedImage && (
        <div className="fixed inset-0 bg-slate-900/80 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-[100]" onClick={() => setSelectedImage(null)}>
           <div className="relative max-w-3xl w-full flex flex-col items-center animate-in zoom-in-95" onClick={e => e.stopPropagation()}>
              <div className="w-full flex justify-end mb-4">
                 <button onClick={() => setSelectedImage(null)} className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white backdrop-blur transition"><X size={24}/></button>
              </div>
              <img src={selectedImage} alt="İşlem Görseli" className="w-full h-auto max-h-[80vh] object-contain rounded-xl shadow-2xl" />
           </div>
        </div>
      )}

      {isTxModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 dark:bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[100]">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 animate-in zoom-in-95 duration-200 shadow-2xl border border-slate-200 dark:border-slate-800 max-h-[90vh] overflow-y-auto custom-scrollbar">
            <div className="flex items-center justify-between mb-6">
              <h3 className={`text-xl font-black ${txType === 'borc' ? 'text-red-600 dark:text-red-400' : 'text-emerald-600 dark:text-emerald-400'} flex items-center gap-2`}>
                {txType === 'borc' ? <PlusCircle/> : <MinusCircle/>}
                {txType === 'borc' ? 'Yeni Borç Kaydı' : 'Tahsilat Ekle'}
              </h3>
              <button onClick={() => setTxModalOpen(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-lg"><X size={20}/></button>
            </div>
            
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase">İşlem Tutarı (₺)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-slate-400">₺</span>
                  <input type="number" className={`w-full pl-8 pr-4 py-3 bg-slate-50 dark:bg-slate-800/50 border rounded-xl outline-none transition font-bold text-lg dark:text-white ${txType === 'borc' ? 'focus:border-red-500 focus:ring-2 focus:ring-red-200 dark:focus:ring-red-900 border-red-100 dark:border-red-900/30' : 'focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 dark:focus:ring-emerald-900 border-emerald-100 dark:border-emerald-900/30'}`} placeholder="0.00" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase">Açıklama</label>
                <input type="text" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium" placeholder="İşlem detayı yazın..." />
              </div>
              <div>
                 <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase">İşlem Tarihi</label>
                 <input type="date" defaultValue={new Date().toISOString().split('T')[0]} className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium" />
              </div>

              <div className="pt-2">
                 <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2 uppercase">Belge / Fatura (Opsiyonel)</label>
                 {!txImagePreview ? (
                    <div className="border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl p-6 flex flex-col items-center justify-center text-center bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer relative">
                       <UploadCloud size={32} className="text-indigo-400 dark:text-indigo-500 mb-2"/>
                       <p className="text-sm font-bold text-slate-700 dark:text-slate-300">Fotoğraf Çek veya Yükle</p>
                       <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Sadece görsel formatları</p>
                       <input type="file" accept="image/*" onChange={handleImageUpload} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                    </div>
                 ) : (
                    <div className="relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 group">
                       <img src={txImagePreview} alt="Önizleme" className="w-full h-40 object-cover opacity-90" />
                       <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                          <button onClick={() => setTxImagePreview(null)} className="px-4 py-2 bg-red-600 text-white font-bold rounded-lg text-sm flex items-center gap-2"><Trash size={16}/> Kaldır</button>
                       </div>
                    </div>
                 )}
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-8 pt-6 border-t border-slate-100 dark:border-slate-800">
              <button onClick={() => setTxModalOpen(false)} className="px-5 py-2.5 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition font-bold">İptal</button>
              <button onClick={() => setTxModalOpen(false)} className={`px-6 py-2.5 text-white rounded-xl font-bold transition shadow-lg ${txType === 'borc' ? 'bg-red-600 hover:bg-red-700 shadow-red-200 dark:shadow-red-900/20' : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200 dark:shadow-emerald-900/20'}`}>Kaydet ve İşle</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// 3.5 Çalışan Yönetimi
const EmployeeManagementView = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const employees = sortAlpha([
    { id: 1, name: 'Ahmet Yılmaz', email: 'ahmet@etiketoto.com', role: 'Satış Sorumlusu', status: 'Aktif' },
    { id: 2, name: 'Burak Demir', email: 'burak@etiketoto.com', role: 'Stok Sorumlusu', status: 'Aktif' },
    { id: 3, name: 'Cem Kaya', email: 'cem@etiketoto.com', role: 'Finans Sorumlusu', status: 'Pasif' },
  ], 'name');

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-4">
           <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-xl flex items-center justify-center shrink-0"><Users size={24} /></div>
           <div>
             <h2 className="text-2xl font-black text-slate-800 dark:text-white">Personel Yönetimi</h2>
             <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Sisteme personel ekleyin, yetkilerini sınırlandırın.</p>
           </div>
        </div>
        <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 transition text-white font-bold rounded-xl w-full sm:w-auto justify-center shadow-md shadow-indigo-200 dark:shadow-indigo-900/20">
          <UserPlus size={18} /> Yeni Personel Ekle
        </button>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[700px]">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 text-xs uppercase border-b border-slate-200 dark:border-slate-700 tracking-wider">
                <th className="p-4 pl-6 font-bold">Personel Adı</th>
                <th className="p-4 font-bold">E-Posta Adresi</th>
                <th className="p-4 font-bold">Sistem Rolü</th>
                <th className="p-4 font-bold">Hesap Durumu</th>
                <th className="p-4 pr-6 font-bold text-right">İşlemler</th>
              </tr>
            </thead>
            <tbody>
              {employees.map(emp => (
                <tr key={emp.id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                  <td className="p-4 pl-6 font-black text-slate-800 dark:text-white flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 flex items-center justify-center text-xs font-bold">{emp.name.charAt(0)}</div>
                    {emp.name}
                  </td>
                  <td className="p-4 text-slate-600 dark:text-slate-400 font-medium">{emp.email}</td>
                  <td className="p-4 text-slate-600 dark:text-slate-400 font-medium">{emp.role}</td>
                  <td className="p-4">
                    <span className={`px-3 py-1 rounded-lg text-xs font-bold border ${emp.status === 'Aktif' ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800' : 'bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700'}`}>
                      {emp.status}
                    </span>
                  </td>
                  <td className="p-4 pr-6 text-right">
                     <button className="text-indigo-600 dark:text-indigo-400 font-bold text-sm flex items-center justify-end gap-1 ml-auto hover:text-indigo-800 dark:hover:text-indigo-300 transition"><Settings size={16}/> Yetkileri Düzenle</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 dark:bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[100]">
           <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 sm:p-8 animate-in zoom-in-95 shadow-2xl border border-slate-200 dark:border-slate-800">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-black text-slate-800 dark:text-white flex items-center gap-2"><UserPlus className="text-indigo-600 dark:text-indigo-400"/> Sisteme Personel Davet Et</h3>
                <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 p-2 rounded-xl"><X size={20}/></button>
              </div>
              
              <div className="space-y-5">
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2 uppercase">Personelin E-Posta Adresi</label>
                  <input type="email" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium" placeholder="personel@sirketiniz.com" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2 uppercase">Geçici Şifre Belirle</label>
                  <input type="text" defaultValue="123456" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium" />
                </div>
                <div className="border border-slate-200 dark:border-slate-700 rounded-2xl p-5 bg-slate-50/50 dark:bg-slate-800/30 space-y-4">
                   <p className="text-sm font-black text-slate-800 dark:text-white flex items-center gap-2"><ShieldCheck size={18} className="text-emerald-600 dark:text-emerald-400"/> Varsayılan Yetkiler</p>
                   <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                     <label className="flex items-center gap-3 text-sm font-medium text-slate-700 dark:text-slate-300 cursor-pointer p-2 hover:bg-white dark:hover:bg-slate-800 rounded-lg transition"><input type="checkbox" defaultChecked className="w-4 h-4 rounded text-indigo-600"/> Stokları Görebilir</label>
                     <label className="flex items-center gap-3 text-sm font-medium text-slate-700 dark:text-slate-300 cursor-pointer p-2 hover:bg-white dark:hover:bg-slate-800 rounded-lg transition"><input type="checkbox" defaultChecked className="w-4 h-4 rounded text-indigo-600"/> Ürün/Stok Ekleyebilir</label>
                     <label className="flex items-center gap-3 text-sm font-medium text-slate-700 dark:text-slate-300 cursor-pointer p-2 hover:bg-white dark:hover:bg-slate-800 rounded-lg transition"><input type="checkbox" className="w-4 h-4 rounded text-indigo-600"/> Finans/Kasa Görebilir</label>
                     <label className="flex items-center gap-3 text-sm font-medium text-slate-700 dark:text-slate-300 cursor-pointer p-2 hover:bg-white dark:hover:bg-slate-800 rounded-lg transition"><input type="checkbox" className="w-4 h-4 rounded text-indigo-600"/> Veri Silebilir (Kritik)</label>
                   </div>
                </div>
              </div>
              <div className="flex justify-end gap-3 mt-8 pt-6 border-t border-slate-100 dark:border-slate-800">
                <button onClick={() => setIsModalOpen(false)} className="px-5 py-2.5 text-slate-600 dark:text-slate-400 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition">Vazgeç</button>
                <button onClick={() => setIsModalOpen(false)} className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold flex items-center gap-2">Davetiye Gönder <ArrowRight size={16}/></button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
}

// 3.6 Abonelik ve Referans Yönetimi (IP Korumalı)
const SubscriptionView = ({ currentUser }) => {
  const { t } = useAppContext();
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(currentUser?.myRefCode || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-5xl space-y-6 animate-in slide-in-from-bottom-4 duration-300">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm mb-6">
        <div className="flex items-center gap-4">
           <div className="w-14 h-14 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center shrink-0"><CreditCard size={28} /></div>
           <div>
             <h2 className="text-2xl font-black text-slate-800 dark:text-white">{t('Abonelik & Davet Et')}</h2>
             <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Paket durumunuzu görüntüleyin ve arkadaşlarınızı davet ederek sürenizi uzatın.</p>
           </div>
        </div>
      </div>

      {currentUser?.isRefApplied && (
        <div className="bg-gradient-to-r from-emerald-500 to-teal-500 p-4 rounded-2xl text-white font-bold flex items-center gap-3 shadow-lg shadow-emerald-200 dark:shadow-none">
           <div className="bg-white/20 p-2 rounded-xl"><Gift size={24}/></div>
           <div>
             <p className="text-lg">Tebrikler! Kayıt olurken referans kodu kullandınız.</p>
             <p className="text-emerald-100 text-sm font-medium">Standart 14 gün yerine tam 24 gün ücretsiz kullanım hakkı kazandınız.</p>
           </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Sol Panel: Mevcut Durum */}
        <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
           <div>
             <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-900/30 border border-indigo-100 dark:border-indigo-800/50 text-indigo-700 dark:text-indigo-400 font-bold text-xs uppercase tracking-wider mb-6">
               <Clock size={14}/> {t('Deneme Sürümü')}
             </div>
             <h3 className="text-5xl font-black text-slate-800 dark:text-white tracking-tight mb-2">{currentUser?.subDays || 14} <span className="text-xl text-slate-400 font-bold">{t('Gün')}</span></h3>
             <p className="text-slate-500 dark:text-slate-400 font-medium mb-8">{t('kalan ücretsiz kullanım süreniz.')}</p>
           </div>
           
           <div className="space-y-4">
              <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-3 overflow-hidden">
                 <div className="bg-indigo-600 dark:bg-indigo-500 h-3 rounded-full" style={{ width: `${((currentUser?.subDays || 14) / 30) * 100}%` }}></div>
              </div>
              <p className="text-xs text-slate-400 dark:text-slate-500 font-bold text-center">Süreniz dolduğunda sistem otomatik olarak duraklatılır, veri kaybı yaşanmaz.</p>
              <button className="w-full py-3.5 bg-slate-900 dark:bg-indigo-600 text-white font-bold rounded-xl hover:bg-slate-800 dark:hover:bg-indigo-700 transition shadow-md mt-4">Premium Pakete Geç</button>
           </div>
        </div>

        {/* Sağ Panel: Referans Sistemi */}
        <div className="bg-gradient-to-br from-indigo-600 to-blue-700 p-8 rounded-2xl text-white shadow-xl flex flex-col justify-between relative overflow-hidden">
           <div className="absolute -right-10 -top-10 opacity-10 pointer-events-none"><Gift size={200}/></div>
           <div className="relative z-10">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-white font-bold text-xs uppercase tracking-wider mb-6 backdrop-blur-sm border border-white/10">
                 Kazan - Kazan Sistemi
              </div>
              <h3 className="text-2xl font-black mb-3 leading-tight">Arkadaşlarınızı Davet Edin,<br/>Sürenizi 10 Gün Uzatın!</h3>
              <p className="text-indigo-100 font-medium text-sm mb-6 leading-relaxed">
                Referans kodunuz ile kaydolan her yeni bayi için aboneliğinize <b>+10 gün</b> eklenir. Davet ettiğiniz arkadaşınız da 14 yerine <b>24 gün</b> deneme süresiyle başlar.
              </p>

              <div className="bg-black/20 p-4 rounded-xl border border-white/10 backdrop-blur-md mb-4">
                 <label className="block text-indigo-200 text-xs font-bold uppercase tracking-wider mb-2">Size Özel Referans Kodunuz</label>
                 <div className="flex gap-2">
                    <div className="flex-1 bg-white text-indigo-900 font-black text-xl px-4 py-3 rounded-lg text-center tracking-widest border-2 border-transparent focus-within:border-indigo-300 flex items-center justify-center">
                       {currentUser?.myRefCode || 'KOD_YOK'}
                    </div>
                    <button onClick={copyToClipboard} className={`px-4 py-3 rounded-lg font-bold flex items-center gap-2 transition ${copied ? 'bg-emerald-500 text-white' : 'bg-indigo-500 hover:bg-indigo-400 text-white'}`}>
                       {copied ? <Check size={20}/> : <Copy size={20}/>}
                    </button>
                 </div>
              </div>
              
              <div className="flex items-start gap-3 mt-6 bg-red-500/20 p-3 rounded-xl border border-red-500/30">
                 <ShieldBan size={20} className="text-red-200 shrink-0 mt-0.5"/>
                 <p className="text-xs text-red-100 font-medium"><b>Anti-Hile Koruması:</b> Aynı cihaz veya IP adresi üzerinden yapılan çoklu sahte kayıtlar sistem tarafından tespit edilir ve engellenir.</p>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

// 3.7 Dinamik Genel Liste Modülü (Stok & Finans için Arama/Ekleme ile)
const GenericModuleView = ({ title, icon: Icon, type, currentUser }) => {
  const { t } = useAppContext();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedCari, setSelectedCari] = useState(null); 
  const [searchTerm, setSearchTerm] = useState('');
  const [editingItem, setEditingItem] = useState(null); 
  const p = currentUser?.permissions || {};

  const generateData = () => {
    if (type === 'stok') {
       return Array.from({ length: 12 }).map((_, i) => ({
        id: 1000 + i, barcode: `869000000${1000 + i}`, title: `${t(title)} Model ${String.fromCharCode(65 + (i%26))}`, category: t(title), buyPrice: 150 + (i * 20), sellPrice: 250 + (i * 35), amount: Math.floor(Math.random() * 50), 
      }));
    } else {
       return Array.from({ length: 8 }).map((_, i) => ({
        id: 2000 + i, title: title.includes('Firma') ? `Tedarikçi A.Ş.` : `Müşteri ${i}`, vkn: `123456789${i}`, phone: `0555 123 45 0${i}`, balance: Math.floor(Math.random() * 10000)
      }));
    }
  };

  const rawData = useMemo(generateData, [type, title, t]);
  const filteredData = sortAlpha(rawData.filter(item => item.title.toLowerCase().includes(searchTerm.toLowerCase()) || (item.barcode && item.barcode.includes(searchTerm))), 'title');

  if (type === 'finans' && selectedCari) {
    return <CariDetailView cari={selectedCari} onBack={() => setSelectedCari(null)} moduleTitle={t(title)} permissions={p} />;
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center shrink-0"><Icon size={28} /></div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-800 dark:text-white">{t(title)} {t('Yönetimi')}</h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">{t('Toplam')} {filteredData.length} {t('kayıt listeleniyor. Sıralama: A-Z.')}</p>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
           <div className="relative w-full sm:w-64">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
             <input type="text" placeholder={t('Ad, model veya barkod ara...')} value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition text-sm font-medium" />
           </div>
          {(p.canAdd || p.allowedModules === 'all') && (
            <button onClick={() => { setEditingItem(null); setIsModalOpen(true); }} className="flex justify-center items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 transition text-white font-bold rounded-xl shadow-md shadow-indigo-200 dark:shadow-indigo-900/20 shrink-0">
              <Plus size={18} /> {t('Yeni Kayıt')}
            </button>
          )}
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 text-xs uppercase border-b border-slate-200 dark:border-slate-700 tracking-wider">
                {type === 'stok' ? (
                  <><th className="p-4 pl-6 font-bold w-1/3">{t('Ürün Modeli')}</th><th className="p-4 font-bold">Barkod</th><th className="p-4 font-bold">Alış / Satış</th><th className="p-4 font-bold text-center">{t('Stok')}</th></>
                ) : (
                  <><th className="p-4 pl-6 font-bold">Cari Adı</th><th className="p-4 font-bold">İletişim</th><th className="p-4 font-bold text-right">Bakiye</th></>
                )}
                <th className="p-4 pr-6 text-right font-bold">İşlemler</th>
              </tr>
            </thead>
            <tbody className="text-sm">
               {filteredData.length > 0 ? filteredData.map(row => (
                  <tr key={row.id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition group">
                    <td className="p-4 pl-6">
                      <div className="font-bold text-slate-800 dark:text-slate-100 mb-0.5">{row.title}</div>
                      {type === 'stok' && <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded border border-slate-200 dark:border-slate-700">{row.category}</span>}
                    </td>
                    
                    {type === 'stok' ? (
                      <>
                        <td className="p-4 text-slate-500 dark:text-slate-400 font-mono text-xs">{row.barcode}</td>
                        <td className="p-4 text-xs font-bold text-slate-600 dark:text-slate-300 flex flex-col gap-0.5 mt-1">
                          <span className="text-slate-400">Alış: {formatMoney(row.buyPrice)}</span>
                          <span className="text-emerald-600 dark:text-emerald-400">Satış: {formatMoney(row.sellPrice)}</span>
                        </td>
                        <td className="p-4 text-center">
                           <span className={`px-3 py-1 rounded-lg font-bold text-xs shadow-sm ${row.amount === 0 ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 border border-red-200 dark:border-red-800/50' : row.amount < 5 ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border border-amber-200 dark:border-amber-800/50' : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-800/50'}`}>
                             {row.amount} Adet
                           </span>
                        </td>
                      </>
                    ) : (
                      <>
                         <td className="p-4">
                           <div className="font-medium text-slate-600 dark:text-slate-300">{row.phone}</div>
                           <div className="text-xs text-slate-400">VKN: {row.vkn}</div>
                         </td>
                         <td className="p-4 font-black text-slate-800 dark:text-white text-right text-base">{formatMoney(row.balance)}</td>
                      </>
                    )}
                    
                    <td className="p-4 pr-6 text-right align-middle">
                       {type === 'finans' ? (
                         <button onClick={() => setSelectedCari(row)} className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline inline-flex items-center gap-1">Yönet <ChevronRight size={16}/></button>
                       ) : (
                         <div className="flex justify-end gap-1 opacity-50 group-hover:opacity-100 transition-opacity">
                           {p.canEdit && <button onClick={() => { setEditingItem(row); setIsModalOpen(true); }} className="p-2 text-slate-400 dark:text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg transition" title="Düzenle"><Edit size={16}/></button>}
                           {p.canDelete && <button className="p-2 text-slate-400 dark:text-slate-500 hover:bg-red-50 dark:hover:bg-red-900/30 hover:text-red-600 dark:hover:text-red-400 rounded-lg transition" title="Sil"><Trash size={16}/></button>}
                         </div>
                       )}
                    </td>
                  </tr>
               )) : (
                  <tr><td colSpan={5} className="p-12 text-center text-slate-500">Bulunamadı.</td></tr>
               )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 dark:bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[100]">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 sm:p-8 animate-in zoom-in-95 duration-200 shadow-2xl border border-slate-200 dark:border-slate-800">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-black text-slate-800 dark:text-white flex items-center gap-2">
                <div className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center">
                  {editingItem ? <Edit size={16}/> : <Plus size={16}/>}
                </div>
                {editingItem ? t('Kaydı Düzenle') : t('Yeni Kayıt')}
              </h3>
              <button onClick={() => { setIsModalOpen(false); setEditingItem(null); }} className="text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 p-2 rounded-xl transition"><X size={20}/></button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">{type === 'stok' ? t('Ürün Modeli') : 'Firma Unvanı / Kişi Adı'}</label>
                <input type="text" defaultValue={editingItem?.title || ''} className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium" />
              </div>

              {type === 'stok' && (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">Kategori</label>
                      <select defaultValue={editingItem?.category || ''} className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium">
                        <option value="">Seçiniz...</option>
                        <option value="Genel Ürünler">Genel Ürünler</option>
                        <option value="Cam Rüzgarlığı">Cam Rüzgarlığı</option>
                        <option value="Kaput Rüzgarlığı">Kaput Rüzgarlığı</option>
                        <option value="Paspas">Paspas</option>
                        <option value="Jant Kapağı">Jant Kapağı</option>
                        <option value="Pandizot">Pandizot</option>
                        <option value="Spoiler">Spoiler</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">Barkod No</label>
                      <div className="relative">
                        <Barcode size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
                        <input type="text" defaultValue={editingItem?.barcode || ''} className="w-full pl-9 pr-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium" placeholder="Okutun..." />
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-4 border-t border-slate-100 dark:border-slate-800 pt-4 mt-2">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase">Alış (₺)</label>
                      <input type="number" defaultValue={editingItem?.buyPrice || ''} className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:border-indigo-500 transition font-bold" placeholder="0.00" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase">Satış (₺)</label>
                      <input type="number" defaultValue={editingItem?.sellPrice || ''} className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-indigo-700 dark:text-indigo-400 rounded-xl outline-none focus:border-indigo-500 transition font-bold" placeholder="0.00" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase">Stok</label>
                      <input type="number" defaultValue={editingItem?.amount ?? ''} className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-emerald-700 dark:text-emerald-400 rounded-xl outline-none focus:border-indigo-500 transition font-bold" placeholder="0" />
                    </div>
                  </div>
                </>
              )}
            </div>
            
            <div className="flex justify-end gap-3 mt-8 pt-6 border-t border-slate-100 dark:border-slate-800">
              <button onClick={() => { setIsModalOpen(false); setEditingItem(null); }} className="px-5 py-3 text-slate-600 dark:text-slate-400 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition">{t('İptal Et')}</button>
              <button onClick={() => { setIsModalOpen(false); setEditingItem(null); }} className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition flex items-center gap-2">
                <Check size={18}/> {editingItem ? t('Değişiklikleri Kaydet') : t('Kaydı Tamamla')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// --- ANA YÖNETİM & NAVİGASYON (DASHBOARD LAYOUT) ---
const DashboardLayout = ({ children, activeMenu, setView, currentUser }) => {
  const { t } = useAppContext();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const isPatron = currentUser?.role === 'bayi_sahibi';

  const stockItems = sortAlpha([
    { type: 'link', id: 'stock_general', label: 'Genel Ürünler', icon: Box },
    { type: 'link', id: 'stock_cam', label: 'Cam Rüzgarlığı', icon: Wind },
    { type: 'link', id: 'stock_jant', label: 'Jant Kapağı', icon: Disc },
    { type: 'link', id: 'stock_kaput', label: 'Kaput Rüzgarlığı', icon: Shield },
    { type: 'link', id: 'stock_pandizot', label: 'Pandizot', icon: Layers },
    { type: 'link', id: 'stock_paspas', label: 'Paspas', icon: Footprints },
    { type: 'link', id: 'stock_spoiler', label: 'Spoiler', icon: Car },
  ], 'label');

  const financeItems = sortAlpha([
    { type: 'link', id: 'fin_firma', label: 'Firma Borçları', icon: Building2 },
    { type: 'link', id: 'fin_garanti', label: 'Garanti Belgeleri', icon: Award },
    { type: 'link', id: 'fin_gecmis', label: 'İşlem Geçmişi', icon: History },
    { type: 'link', id: 'fin_kasa', label: 'Kasa Defteri', icon: Calculator },
    { type: 'link', id: 'fin_kredi', label: 'Krediler', icon: Landmark },
    { type: 'link', id: 'fin_raporlar', label: 'Gelişmiş Raporlar', icon: PieChart },
    { type: 'link', id: 'fin_senet', label: 'Senetler', icon: FileText },
    { type: 'link', id: 'fin_veresiye', label: 'Veresiye (Müşteri)', icon: BookOpen },
  ], 'label');

  let menuItems = [
    { type: 'link', id: 'customerDashboard', label: 'Ana Panel', icon: LayoutDashboard },
    { type: 'header', label: 'STOK YÖNETİMİ (A-Z)' },
    ...stockItems,
    { type: 'header', label: 'FİNANS & YÖNETİM (A-Z)' },
    ...financeItems,
    { type: 'header', label: 'SİSTEM AYARLARI' }
  ];

  if (isPatron) {
    menuItems.push(
      { type: 'link', id: 'employees', label: 'Personel Yönetimi', icon: Users },
      { type: 'link', id: 'profile', label: 'İşletme Profili', icon: Settings },
      { type: 'link', id: 'subscription', label: 'Abonelik & Davet Et', icon: Gift } 
    );
  } else {
    menuItems.push({ type: 'link', id: 'profile_locked', label: 'Ayarlar (Yetki Yok)', icon: Lock });
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex transition-colors duration-300">
      {sidebarOpen && <div className="fixed inset-0 bg-slate-900/60 dark:bg-black/60 backdrop-blur-sm z-40 md:hidden" onClick={() => setSidebarOpen(false)} />}
      
      <aside className={`fixed inset-y-0 left-0 bg-slate-900 dark:bg-slate-950 text-slate-300 w-72 transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 transition-transform duration-300 ease-out z-50 flex flex-col shadow-2xl border-r border-slate-800`}>
        <div className="p-6 flex items-center gap-3 text-white border-b border-slate-800/80 shrink-0 bg-slate-900 dark:bg-slate-950 z-10 shadow-sm">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-900/50"><TrendingUp size={22} className="text-white" /></div>
          <div>
            <span className="text-xl font-black tracking-tight leading-none block">StokFinans</span>
            <span className="text-[10px] text-indigo-300 font-bold tracking-widest uppercase">{isPatron ? t('Bayi (Patron)') : t('Çalışan')}</span>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar pb-6 pt-2">
          {menuItems.map((item, index) => {
            if (item.type === 'header') return <div key={`hdr-${index}`} className="px-5 pt-6 pb-2 text-[10px] font-bold text-slate-500 tracking-wider uppercase sticky top-0 bg-slate-900/95 dark:bg-slate-950/95 backdrop-blur z-10">{t(item.label)}</div>;
            return (
              <button
                key={item.id} disabled={item.id === 'profile_locked'}
                onClick={() => { if(item.id !== 'profile_locked') { setView(item.id); setSidebarOpen(false); } }}
                className={`w-full flex items-center gap-3 px-4 py-3 mx-3 rounded-xl transition-all font-medium ${item.id === 'profile_locked' ? 'opacity-40 cursor-not-allowed' : ''} ${activeMenu === item.id ? 'bg-indigo-600 text-white shadow-md shadow-indigo-900/20' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'}`} style={{ width: 'calc(100% - 24px)' }}
              >
                <item.icon size={18} className={activeMenu === item.id ? 'text-white' : 'text-slate-500'} />
                <span className="text-sm">{t(item.label)}</span>
              </button>
            )
          })}
        </div>

        <div className="p-5 border-t border-slate-800 shrink-0 bg-slate-900 dark:bg-slate-950">
          <div className="mb-4 px-2 flex items-center gap-3">
             <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center border border-slate-700 text-slate-400"><UserCircle size={24}/></div>
             <div className="overflow-hidden">
               <p className="text-white font-bold text-sm truncate">{currentUser?.name}</p>
             </div>
          </div>
          <button onClick={() => setView('landing')} className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800/50 text-red-400 border border-slate-800 hover:bg-red-500 hover:text-white hover:border-red-500 transition-all font-bold text-sm">
            <LogOut size={16} /> {t('Çıkış Yap')}
          </button>
        </div>
      </aside>

      <div className="flex-1 md:ml-72 flex flex-col min-h-screen max-w-full w-full">
        <header className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 h-16 flex items-center justify-between px-4 sm:px-6 sticky top-0 z-30 shadow-sm transition-colors duration-300">
          <div className="flex items-center gap-4">
             <button onClick={() => setSidebarOpen(true)} className="md:hidden text-slate-600 dark:text-slate-300 p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition"><Menu size={24} /></button>
             <h2 className="text-lg sm:text-xl font-black text-slate-800 dark:text-white truncate">{t(menuItems.find(m => m.id === activeMenu)?.label || 'Ana Panel')}</h2>
          </div>
          <div className="hidden sm:flex items-center gap-3">
            <span className="px-3 py-1 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 text-xs font-bold rounded-lg border border-indigo-100 dark:border-indigo-800/50">{t('Sistem Aktif')}</span>
            <SettingsToggle />
          </div>
        </header>
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-x-hidden text-slate-800 dark:text-slate-200">
          {children}
        </main>
      </div>
    </div>
  );
};

// 4. Müşteri Ana Paneli (Dashboard)
const CustomerDashboard = ({ setView, currentUser }) => {
  const { t } = useAppContext();
  const isPatron = currentUser?.role === 'bayi_sahibi';
  const [prefs, setPrefs] = useState({ stock: true, finance: true, alert: true });
  const [showSettings, setShowSettings] = useState(false);

  const stockGrid = sortAlpha([
    { label: 'Genel Ürünler', icon: Box, color: 'text-blue-600 dark:text-blue-400', bg: 'bg-blue-100 dark:bg-blue-900/30', id: 'stock_general' }, 
    { label: 'Cam Rüzgarlığı', icon: Wind, color: 'text-sky-600 dark:text-sky-400', bg: 'bg-sky-100 dark:bg-sky-900/30', id: 'stock_cam' }, 
    { label: 'Kaput Rüzgarlığı', icon: Shield, color: 'text-slate-600 dark:text-slate-400', bg: 'bg-slate-100 dark:bg-slate-800', id: 'stock_kaput' },
    { label: 'Jant Kapağı', icon: Disc, color: 'text-slate-800 dark:text-slate-300', bg: 'bg-slate-200 dark:bg-slate-700', id: 'stock_jant' },
    { label: 'Pandizot', icon: Layers, color: 'text-purple-600 dark:text-purple-400', bg: 'bg-purple-100 dark:bg-purple-900/30', id: 'stock_pandizot' },
    { label: 'Paspas', icon: Footprints, color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-100 dark:bg-amber-900/30', id: 'stock_paspas' },
    { label: 'Spoiler', icon: Car, color: 'text-red-600 dark:text-red-400', bg: 'bg-red-100 dark:bg-red-900/30', id: 'stock_spoiler' },
  ], 'label');
  
  const financeGrid = sortAlpha([
    { label: 'Veresiye (Müşteri)', icon: BookOpen, color: 'text-indigo-600 dark:text-indigo-400', bg: 'bg-indigo-100 dark:bg-indigo-900/30', id: 'fin_veresiye' }, 
    { label: 'Firma Borçları', icon: Building2, color: 'text-orange-600 dark:text-orange-400', bg: 'bg-orange-100 dark:bg-orange-900/30', id: 'fin_firma' },
    { label: 'Garanti Belgeleri', icon: Award, color: 'text-sky-600 dark:text-sky-400', bg: 'bg-sky-100 dark:bg-sky-900/30', id: 'fin_garanti' },
    { label: 'İşlem Geçmişi', icon: History, color: 'text-slate-600 dark:text-slate-400', bg: 'bg-slate-100 dark:bg-slate-800', id: 'fin_gecmis' },
    { label: 'Kasa Defteri', icon: Calculator, color: 'text-slate-700 dark:text-slate-300', bg: 'bg-slate-200 dark:bg-slate-700', id: 'fin_kasa' },
    { label: 'Krediler', icon: Landmark, color: 'text-amber-600 dark:text-amber-400', bg: 'bg-amber-100 dark:bg-amber-900/30', id: 'fin_kredi' },
    { label: 'Gelişmiş Raporlar', icon: PieChart, color: 'text-purple-600 dark:text-purple-400', bg: 'bg-purple-100 dark:bg-purple-900/30', id: 'fin_raporlar' },
    { label: 'Senetler', icon: FileText, color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-100 dark:bg-emerald-900/30', id: 'fin_senet' },
  ], 'label');

  return (
    <div className="space-y-8 animate-in fade-in duration-300 pb-10 max-w-7xl mx-auto">
      <div className="bg-indigo-600 dark:bg-indigo-700 rounded-3xl p-6 sm:p-10 text-white shadow-xl shadow-indigo-200 dark:shadow-none relative overflow-hidden transition-colors duration-300">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none"><TrendingUp size={200}/></div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
           <div>
             <h1 className="text-3xl sm:text-4xl font-black mb-2">{t('Hoşgeldiniz')}, {currentUser?.name} 👋</h1>
             <p className="text-indigo-200 dark:text-indigo-100 font-medium text-lg">Etiket Oto Aksesuar {t('genel durum panelindesiniz.')}</p>
           </div>
           {isPatron && (
             <button onClick={() => setShowSettings(!showSettings)} className="flex items-center gap-2 px-5 py-3 bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold rounded-xl backdrop-blur transition shadow-sm whitespace-nowrap">
               <SlidersHorizontal size={18}/> {t('Panel Görünümü')}
             </button>
           )}
        </div>
      </div>

      {showSettings && isPatron && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl flex flex-wrap gap-6 items-center shadow-sm animate-in slide-in-from-top-4">
          <span className="font-black text-slate-800 dark:text-white">{t('Aktif Modüller:')}</span>
          <label className="flex items-center gap-2 text-sm font-bold text-slate-600 dark:text-slate-400 cursor-pointer hover:text-indigo-600"><input type="checkbox" checked={prefs.stock} onChange={()=>setPrefs({...prefs, stock: !prefs.stock})} className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"/> {t('Stok Kısayolları')}</label>
          <label className="flex items-center gap-2 text-sm font-bold text-slate-600 dark:text-slate-400 cursor-pointer hover:text-indigo-600"><input type="checkbox" checked={prefs.finance} onChange={()=>setPrefs({...prefs, finance: !prefs.finance})} className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"/> {t('Finans Kısayolları')}</label>
          <label className="flex items-center gap-2 text-sm font-bold text-slate-600 dark:text-slate-400 cursor-pointer hover:text-indigo-600"><input type="checkbox" checked={prefs.alert} onChange={()=>setPrefs({...prefs, alert: !prefs.alert})} className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"/> {t('Kritik Stok Uyarıları')}</label>
        </div>
      )}

      {prefs.alert && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-red-200 dark:border-red-900/50 shadow-sm overflow-hidden animate-in fade-in">
          <div className="bg-red-50 dark:bg-red-900/10 p-5 sm:px-6 flex flex-col sm:flex-row sm:items-center gap-4 border-b border-red-100 dark:border-red-900/30">
            <div className="w-12 h-12 bg-red-100 dark:bg-red-900/50 rounded-2xl flex items-center justify-center shrink-0 shadow-inner"><AlertTriangle className="text-red-600 dark:text-red-400" size={24} /></div>
            <div>
              <h5 className="text-xl font-black text-slate-800 dark:text-white">{t('Kritik Stok Uyarıları')}</h5>
              <p className="text-sm text-red-600 dark:text-red-400 font-bold">{t('Aşağıdaki')} {etiketKritikStoklar.length} {t('ürün stok limitinin altında! (A-Z Sıralı)')}</p>
            </div>
            <button className="sm:ml-auto px-4 py-2 bg-white dark:bg-slate-800 border border-red-200 dark:border-red-800/50 text-red-600 dark:text-red-400 text-sm font-bold rounded-xl hover:bg-red-50 dark:hover:bg-slate-700 transition shadow-sm">{t('Tümünü İncele')}</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[600px]">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 text-[10px] uppercase border-b border-slate-200 dark:border-slate-800 tracking-wider">
                  <th className="p-3 pl-6 font-bold w-1/4">{t('Kategori')}</th>
                  <th className="p-3 font-bold w-1/2">{t('Ürün Modeli')}</th>
                  <th className="p-3 font-bold text-center">{t('Stok')}</th>
                  <th className="p-3 font-bold text-center pr-6">{t('Durum')}</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {etiketKritikStoklar.slice(0, 3).map((item, idx) => (
                  <tr key={item.id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                    <td className="p-3 pl-6"><span className="bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-md font-bold text-[10px] text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">{item.kategori}</span></td>
                    <td className="p-3 font-bold text-slate-800 dark:text-slate-100">{item.model}</td>
                    <td className="p-3 text-center"><span className={`inline-block min-w-[2rem] px-2 py-1 rounded-md font-bold text-xs text-white shadow-sm ${item.stok===0?'bg-red-500':'bg-amber-500'}`}>{item.stok}</span></td>
                    <td className="p-3 text-center pr-6">
                      {item.stok===0 ? <span className="inline-flex items-center text-red-600 dark:text-red-400 font-black text-xs bg-red-50 dark:bg-red-900/20 px-2 py-1 rounded-md"><XCircle size={14} className="mr-1.5"/> {t('TÜKENDİ')}</span> : <span className="inline-flex items-center text-amber-600 dark:text-amber-400 font-black text-xs bg-amber-50 dark:bg-amber-900/20 px-2 py-1 rounded-md"><AlertCircle size={14} className="mr-1.5"/> {t('KRİTİK')}</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {prefs.stock && (
        <div className="animate-in fade-in">
          <h6 className="text-slate-500 dark:text-slate-400 font-black tracking-widest uppercase mb-4 text-xs flex items-center gap-2 pl-2"><Box size={16} className="text-indigo-500"/> {t('STOK YÖNETİMİ & KATEGORİLER (A-Z)')}</h6>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-3 sm:gap-4">
            {stockGrid.map((item, idx) => (
              <button key={idx} onClick={() => setView(item.id)} className="bg-white dark:bg-slate-900 p-5 h-36 flex flex-col items-center justify-center text-center rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:-translate-y-1.5 hover:shadow-md hover:border-indigo-200 dark:hover:border-indigo-800 transition-all group">
                <div className={`w-14 h-14 ${item.bg} ${item.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-inner`}><item.icon size={26} strokeWidth={2.5} /></div>
                <span className="text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-300 leading-tight group-hover:text-indigo-700 dark:group-hover:text-indigo-400">{t(item.label)}</span>
              </button>
            ))}
          </div>
        </div>
      )}
      
      {prefs.finance && (
        <div className="animate-in fade-in">
          <h6 className="text-slate-500 dark:text-slate-400 font-black tracking-widest uppercase mb-4 text-xs flex items-center gap-2 pl-2"><Wallet size={16} className="text-emerald-500"/> {t('FİNANS, RAPOR & YÖNETİM (A-Z)')}</h6>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-3 sm:gap-4">
            {financeGrid.map((item, idx) => (
              <button key={idx} onClick={() => setView(item.id)} className="bg-white dark:bg-slate-900 p-5 h-36 flex flex-col items-center justify-center text-center rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:-translate-y-1.5 hover:shadow-md hover:border-indigo-200 dark:hover:border-indigo-800 transition-all group">
                <div className={`w-14 h-14 ${item.bg} ${item.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-inner`}><item.icon size={26} strokeWidth={2.5} /></div>
                <span className="text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-300 leading-tight group-hover:text-indigo-700 dark:group-hover:text-indigo-400">{t(item.label)}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};


// --- ANA UYGULAMA YÖNLENDİRİCİSİ (APP ROUTER) ---
export default function App() {
  const [currentView, setCurrentView] = useState('landing'); 
  const [currentUser, setCurrentUser] = useState(null);

  // Dil ve Tema (Dark Mode) State Yönetimi (Sistem Hatırlatması İçin)
  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'light');
  const [lang, setLang] = useState(() => localStorage.getItem('lang') || 'tr');

  useEffect(() => {
    localStorage.setItem('theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('lang', lang);
  }, [lang]);

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');
  const toggleLang = () => setLang(prev => prev === 'tr' ? 'en' : 'tr');
  const t = (text) => lang === 'tr' ? text : (EN_DICT[text] || text);

  // Tümü eklenmiş Liste Modülleri
  const moduleMap = {
    'stock_general': { title: 'Genel Ürünler', icon: Box, type: 'stok' },
    'stock_cam': { title: 'Cam Rüzgarlığı', icon: Wind, type: 'stok' },
    'stock_kaput': { title: 'Kaput Rüzgarlığı', icon: Shield, type: 'stok' },
    'stock_jant': { title: 'Jant Kapağı', icon: Disc, type: 'stok' },
    'stock_pandizot': { title: 'Pandizot', icon: Layers, type: 'stok' },
    'stock_paspas': { title: 'Paspas', icon: Footprints, type: 'stok' },
    'stock_spoiler': { title: 'Spoiler', icon: Car, type: 'stok' },
    'fin_veresiye': { title: 'Veresiye (Müşteri)', icon: BookOpen, type: 'finans' },
    'fin_firma': { title: 'Firma Borçları', icon: Building2, type: 'finans' },
    'fin_senet': { title: 'Senetler', icon: FileText, type: 'finans' },
    'fin_kredi': { title: 'Krediler', icon: Landmark, type: 'finans' },
    'fin_kasa': { title: 'Kasa Defteri', icon: Calculator, type: 'finans' },
    'fin_garanti': { title: 'Garanti Belgeleri', icon: Award, type: 'finans' },
  };

  const renderView = () => {
    if (moduleMap[currentView]) {
      const mod = moduleMap[currentView];
      return <DashboardLayout activeMenu={currentView} setView={setCurrentView} currentUser={currentUser}><GenericModuleView title={mod.title} icon={mod.icon} type={mod.type} currentUser={currentUser} /></DashboardLayout>;
    }
    switch (currentView) {
      case 'landing': return <LandingPage setView={setCurrentView} />;
      case 'login': return <AuthPage setView={setCurrentView} isLogin={true} setCurrentUser={setCurrentUser} />;
      case 'register': return <AuthPage setView={setCurrentView} isLogin={false} setCurrentUser={setCurrentUser} />;
      case 'customerDashboard': return <DashboardLayout activeMenu="customerDashboard" setView={setCurrentView} currentUser={currentUser}><CustomerDashboard setView={setCurrentView} currentUser={currentUser} /></DashboardLayout>;
      case 'profile': return <DashboardLayout activeMenu="profile" setView={setCurrentView} currentUser={currentUser}><ProfileSettingsView /></DashboardLayout>;
      case 'employees': return <DashboardLayout activeMenu="employees" setView={setCurrentView} currentUser={currentUser}><EmployeeManagementView /></DashboardLayout>;
      case 'subscription': return <DashboardLayout activeMenu="subscription" setView={setCurrentView} currentUser={currentUser}><SubscriptionView currentUser={currentUser}/></DashboardLayout>;
      case 'fin_raporlar': return <DashboardLayout activeMenu="fin_raporlar" setView={setCurrentView} currentUser={currentUser}><ReportsDashboardView /></DashboardLayout>;
      case 'fin_gecmis': return <DashboardLayout activeMenu="fin_gecmis" setView={setCurrentView} currentUser={currentUser}><HistoryLogView /></DashboardLayout>;
      default: return <LandingPage setView={setCurrentView} />;
    }
  };

  return (
    <AppContext.Provider value={{ theme, toggleTheme, lang, toggleLang, t }}>
      <div className={`min-h-screen font-sans selection:bg-indigo-100 selection:text-indigo-900 ${theme === 'dark' ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'}`}>
        {renderView()}
      </div>
    </AppContext.Provider>
  );
}