#!/bin/bash
# ============================================================
# StokFinans — Docker Yönetim Paneli
# Kullanım: bash manage.sh
# ============================================================

set -euo pipefail

# ── Renkler ─────────────────────────────────────────────────
R='\033[0;31m'  # kırmızı
G='\033[0;32m'  # yeşil
Y='\033[1;33m'  # sarı
B='\033[0;34m'  # mavi
C='\033[0;36m'  # cyan
W='\033[1;37m'  # beyaz
D='\033[2;37m'  # gri
NC='\033[0m'    # reset
BOLD='\033[1m'

# ── Yardımcılar ─────────────────────────────────────────────
clear_screen() { clear; }

header() {
    echo -e "${B}${BOLD}"
    echo "  ╔══════════════════════════════════════════════════╗"
    echo "  ║         StokFinans — Docker Yönetim Paneli       ║"
    echo "  ╚══════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

divider() { echo -e "${D}  ────────────────────────────────────────────────────${NC}"; }

ok()   { echo -e "  ${G}✔${NC}  $*"; }
err()  { echo -e "  ${R}✘${NC}  $*"; }
info() { echo -e "  ${C}ℹ${NC}  $*"; }
warn() { echo -e "  ${Y}⚠${NC}  $*"; }

press_enter() {
    echo ""
    echo -e "  ${D}Enter'a bas...${NC}"
    read -r
}

confirm() {
    local msg="$1"
    echo -e "  ${Y}${msg} [e/H]:${NC} \c"
    read -r ans
    [[ "$ans" =~ ^[eE]$ ]]
}

# ── Container durum rengi ────────────────────────────────────
status_color() {
    local s="$1"
    if [[ "$s" == *"Up"* ]]; then
        echo -e "${G}${s}${NC}"
    elif [[ "$s" == *"Exited"* || "$s" == *"Exit"* ]]; then
        echo -e "${R}${s}${NC}"
    else
        echo -e "${Y}${s}${NC}"
    fi
}

# ── Docker Compose komutu ────────────────────────────────────
DC="docker compose"
COMPOSE_FILE="docker-compose.yml"
[ ! -f "$COMPOSE_FILE" ] && COMPOSE_FILE="docker-compose.yaml"
[ ! -f "$COMPOSE_FILE" ] && COMPOSE_FILE="docker-compose.staging.yml"
[ ! -f "$COMPOSE_FILE" ] && COMPOSE_FILE="docker-compose.prod.yml"

# ============================================================
# 1) DURUM — Çalışan container'lar
# ============================================================
show_status() {
    clear_screen
    header
    echo -e "  ${BOLD}${W}Sistem Durumu${NC}"
    divider
    echo ""

    # Container tablosu
    printf "  ${BOLD}%-28s %-12s %-22s %-15s${NC}\n" "CONTAINER" "DURUM" "PORT" "IMAGE"
    echo -e "  ${D}$(printf '─%.0s' {1..75})${NC}"

    docker ps -a --format '{{.Names}}\t{{.Status}}\t{{.Ports}}\t{{.Image}}' | while IFS=$'\t' read -r name status ports image; do
        # Durum rengi
        if [[ "$status" == *"Up"* ]]; then
            st="${G}${status:0:20}${NC}"
        else
            st="${R}${status:0:20}${NC}"
        fi
        port_short="${ports:0:22}"
        img_short="${image:0:15}"
        printf "  %-28s " "$name"
        printf "${st}"
        printf "  %-22s %-15s\n" "$port_short" "$img_short"
    done

    echo ""
    divider

    # Docker images
    echo ""
    echo -e "  ${BOLD}${W}Docker Image'lar${NC}"
    echo ""
    docker images --format "  {{.Repository}}:{{.Tag}}\t{{.Size}}\t{{.CreatedSince}}" \
        | awk -F'\t' '{printf "  \033[0;36m%-45s\033[0m  %-10s  %s\n", $1, $2, $3}'

    echo ""
    divider

    # Disk & bellek
    echo ""
    echo -e "  ${BOLD}${W}Sistem Kaynakları${NC}"
    echo ""
    DISK=$(df -h / | awk 'NR==2{print $3"/"$2" ("$5" kullanıldı)"}')
    echo -e "  ${C}Disk    :${NC} $DISK"

    if command -v free &>/dev/null; then
        MEM=$(free -h | awk '/^Mem:/{print $3"/"$2}')
        echo -e "  ${C}RAM     :${NC} $MEM"
    fi

    CPU_CORES=$(nproc 2>/dev/null || echo "?")
    echo -e "  ${C}CPU     :${NC} ${CPU_CORES} çekirdek"

    echo ""
    press_enter
}

# ============================================================
# 2) BUILD
# ============================================================
build_menu() {
    clear_screen
    header
    echo -e "  ${BOLD}${W}Build${NC}"
    divider
    echo ""
    echo -e "  ${W}1)${NC} Tüm servisleri build et (cache kullan)"
    echo -e "  ${W}2)${NC} Tüm servisleri build et (${R}cache temizle${NC})"
    echo -e "  ${W}3)${NC} Sadece backend build et"
    echo -e "  ${W}4)${NC} Sadece frontend build et"
    echo -e "  ${W}0)${NC} Geri"
    echo ""
    divider
    echo -e "  ${Y}Seçim:${NC} \c"
    read -r ch

    case "$ch" in
        1)
            info "Build başlıyor (cache ile)..."
            $DC build
            ok "Build tamamlandı."
            press_enter ;;
        2)
            warn "Cache temizlenerek build yapılacak — bu uzun sürebilir."
            confirm "Devam edilsin mi?" || return
            info "Build başlıyor (--no-cache)..."
            $DC build --no-cache
            ok "Build tamamlandı."
            press_enter ;;
        3)
            info "Backend build ediliyor..."
            $DC build backend
            ok "Backend build tamamlandı."
            press_enter ;;
        4)
            info "Frontend build ediliyor..."
            $DC build frontend
            ok "Frontend build tamamlandı."
            press_enter ;;
        0) return ;;
        *) err "Geçersiz seçim."; press_enter ;;
    esac
}

# ============================================================
# 3) BAŞLAT / DURDUR / YENİDEN BAŞLAT
# ============================================================
control_menu() {
    clear_screen
    header
    echo -e "  ${BOLD}${W}Başlat / Durdur / Yeniden Başlat${NC}"
    divider
    echo ""
    echo -e "  ${W}1)${NC}  Tüm sistemi başlat        (up -d)"
    echo -e "  ${W}2)${NC}  Tüm sistemi durdur        (down)"
    echo -e "  ${W}3)${NC}  Tüm sistemi yeniden başlat (down + up)"
    echo -e "  ${W}4)${NC}  ${G}Backend${NC} başlat"
    echo -e "  ${W}5)${NC}  ${G}Frontend${NC} başlat"
    echo -e "  ${W}6)${NC}  ${R}Backend${NC} durdur"
    echo -e "  ${W}7)${NC}  ${R}Frontend${NC} durdur"
    echo -e "  ${W}8)${NC}  Backend yeniden başlat"
    echo -e "  ${W}9)${NC}  Frontend yeniden başlat"
    echo -e "  ${W}0)${NC}  Geri"
    echo ""
    divider
    echo -e "  ${Y}Seçim:${NC} \c"
    read -r ch

    case "$ch" in
        1) info "Sistem başlatılıyor...";  $DC up -d;           ok "Sistem başlatıldı.";             press_enter ;;
        2) confirm "Sistem durdurulsun mu?" && { $DC down; ok "Sistem durduruldu."; press_enter; } ;;
        3) confirm "Sistem yeniden başlatılsın mı?" && {
               info "Durduruluyor..."; $DC down
               info "Başlatılıyor..."; $DC up -d
               ok "Sistem yeniden başlatıldı."; press_enter; } ;;
        4) info "Backend başlatılıyor..."; $DC up -d backend;   ok "Backend başlatıldı.";            press_enter ;;
        5) info "Frontend başlatılıyor..."; $DC up -d frontend; ok "Frontend başlatıldı.";           press_enter ;;
        6) info "Backend durduruluyor..."; $DC stop backend;    ok "Backend durduruldu.";            press_enter ;;
        7) info "Frontend durduruluyor..."; $DC stop frontend;  ok "Frontend durduruldu.";           press_enter ;;
        8) info "Backend yeniden başlatılıyor..."; $DC restart backend; ok "Backend yeniden başlatıldı."; press_enter ;;
        9) info "Frontend yeniden başlatılıyor..."; $DC restart frontend; ok "Frontend yeniden başlatıldı."; press_enter ;;
        0) return ;;
        *) err "Geçersiz seçim."; press_enter ;;
    esac
}

# ============================================================
# 4) LOGLAR
# ============================================================
logs_menu() {
    clear_screen
    header
    echo -e "  ${BOLD}${W}Loglar${NC}"
    divider
    echo ""
    echo -e "  ${W}1)${NC}  Tüm servisler — son 100 satır"
    echo -e "  ${W}2)${NC}  Backend — son 100 satır"
    echo -e "  ${W}3)${NC}  Frontend — son 100 satır"
    echo -e "  ${W}4)${NC}  Veritabanı — son 100 satır"
    echo -e "  ${W}5)${NC}  Backend — ${Y}canlı izle${NC} (Ctrl+C ile çık)"
    echo -e "  ${W}6)${NC}  Frontend — ${Y}canlı izle${NC} (Ctrl+C ile çık)"
    echo -e "  ${W}7)${NC}  Tüm servisler — ${Y}canlı izle${NC} (Ctrl+C ile çık)"
    echo -e "  ${W}8)${NC}  Belirli satır sayısı gir (tüm servisler)"
    echo -e "  ${W}0)${NC}  Geri"
    echo ""
    divider
    echo -e "  ${Y}Seçim:${NC} \c"
    read -r ch

    case "$ch" in
        1) $DC logs --tail=100 | less -R ;;
        2) $DC logs --tail=100 backend | less -R ;;
        3) $DC logs --tail=100 frontend | less -R ;;
        4) $DC logs --tail=100 db | less -R ;;
        5) info "Ctrl+C ile çıkın..."; $DC logs -f backend ;;
        6) info "Ctrl+C ile çıkın..."; $DC logs -f frontend ;;
        7) info "Ctrl+C ile çıkın..."; $DC logs -f ;;
        8)
            echo -e "  ${Y}Kaç satır?${NC} \c"; read -r lines
            [[ "$lines" =~ ^[0-9]+$ ]] || { err "Geçersiz sayı."; press_enter; return; }
            $DC logs --tail="$lines" | less -R ;;
        0) return ;;
        *) err "Geçersiz seçim."; press_enter ;;
    esac
}

# ============================================================
# 5) SİL / TEMİZLE
# ============================================================
remove_menu() {
    clear_screen
    header
    echo -e "  ${BOLD}${R}Sil / Temizle${NC}"
    divider
    echo ""
    echo -e "  ${W}1)${NC}  Container + volume + network sil  ${R}(down --volumes)${NC}"
    echo -e "  ${W}2)${NC}  Kullanılmayan image'ları temizle   ${Y}(docker image prune)${NC}"
    echo -e "  ${W}3)${NC}  Tüm durmuş container'ları sil      ${Y}(container prune)${NC}"
    echo -e "  ${W}4)${NC}  Kullanılmayan volume'ları sil       ${Y}(volume prune)${NC}"
    echo -e "  ${W}5)${NC}  ${R}${BOLD}TAM TEMİZLİK${NC} — image + container + volume + build cache ${R}(dikkatli!)${NC}"
    echo -e "  ${W}6)${NC}  Belirli bir container'ı sil (isimle)"
    echo -e "  ${W}0)${NC}  Geri"
    echo ""
    divider
    echo -e "  ${Y}Seçim:${NC} \c"
    read -r ch

    case "$ch" in
        1)
            warn "Container'lar, volume'lar ve network'ler silinecek — veritabanı dahil!"
            confirm "Emin misiniz?" || return
            $DC down --volumes
            ok "Temizlendi."
            press_enter ;;
        2)
            confirm "Kullanılmayan image'lar silinsin mi?" || return
            docker image prune -f
            ok "Image'lar temizlendi."
            press_enter ;;
        3)
            confirm "Durmuş container'lar silinsin mi?" || return
            docker container prune -f
            ok "Container'lar temizlendi."
            press_enter ;;
        4)
            warn "Bu işlem VERİTABANI VERİLERİNİ silebilir!"
            confirm "Volume'lar silinsin mi?" || return
            docker volume prune -f
            ok "Volume'lar temizlendi."
            press_enter ;;
        5)
            warn "TÜM Docker kaynakları silinecek! Veritabanı dahil tüm veriler gidecek."
            confirm "Gerçekten devam edilsin mi?" || return
            confirm "Son uyarı — geri alınamaz. Emin misiniz?" || return
            $DC down --volumes --remove-orphans
            docker system prune -af --volumes
            ok "Tam temizlik tamamlandı."
            press_enter ;;
        6)
            echo -e "  ${Y}Container adı:${NC} \c"; read -r cname
            [ -z "$cname" ] && return
            confirm "'$cname' silinsin mi?" || return
            docker rm -f "$cname" && ok "'$cname' silindi." || err "Silinemedi."
            press_enter ;;
        0) return ;;
        *) err "Geçersiz seçim."; press_enter ;;
    esac
}

# ============================================================
# 6) BUILD + BAŞLAT (Tek Adım Deploy)
# ============================================================
deploy_menu() {
    clear_screen
    header
    echo -e "  ${BOLD}${W}Tek Adımda Deploy${NC}"
    divider
    echo ""
    echo -e "  ${W}1)${NC}  ${G}Hızlı deploy${NC}  — build (cache) + up -d"
    echo -e "  ${W}2)${NC}  ${Y}Temiz deploy${NC}  — build (no-cache) + up -d"
    echo -e "  ${W}3)${NC}  ${C}Backend deploy${NC} — backend build + restart"
    echo -e "  ${W}4)${NC}  ${C}Frontend deploy${NC} — frontend build + restart"
    echo -e "  ${W}0)${NC}  Geri"
    echo ""
    divider
    echo -e "  ${Y}Seçim:${NC} \c"
    read -r ch

    case "$ch" in
        1)
            info "Build ediliyor..."
            $DC build
            info "Başlatılıyor..."
            $DC up -d
            echo ""
            ok "Deploy tamamlandı!"
            echo ""
            $DC ps
            press_enter ;;
        2)
            warn "Cache olmadan build uzun sürebilir."
            confirm "Devam edilsin mi?" || return
            info "Build ediliyor (--no-cache)..."
            $DC build --no-cache
            info "Başlatılıyor..."
            $DC up -d
            ok "Deploy tamamlandı (temiz)."
            $DC ps
            press_enter ;;
        3)
            info "Backend build ediliyor..."
            $DC build backend
            info "Backend yeniden başlatılıyor..."
            $DC up -d backend
            ok "Backend deploy tamamlandı."
            press_enter ;;
        4)
            info "Frontend build ediliyor..."
            $DC build frontend
            info "Frontend yeniden başlatılıyor..."
            $DC up -d frontend
            ok "Frontend deploy tamamlandı."
            press_enter ;;
        0) return ;;
        *) err "Geçersiz seçim."; press_enter ;;
    esac
}

# ============================================================
# 7) CONTAINER DETAYI
# ============================================================
inspect_menu() {
    clear_screen
    header
    echo -e "  ${BOLD}${W}Container İncele${NC}"
    divider
    echo ""

    # Mevcut container listesi
    echo -e "  ${D}Mevcut container'lar:${NC}"
    docker ps -a --format "  {{.Names}} — {{.Status}}" | while read -r line; do
        if [[ "$line" == *"Up"* ]]; then
            echo -e "${G}${line}${NC}"
        else
            echo -e "${R}${line}${NC}"
        fi
    done
    echo ""
    divider
    echo -e "  ${W}1)${NC}  Container'a bağlan (exec bash)"
    echo -e "  ${W}2)${NC}  Container istatistikleri (canlı)"
    echo -e "  ${W}3)${NC}  Container detayı (inspect)"
    echo -e "  ${W}4)${NC}  PostgreSQL'e bağlan (psql)"
    echo -e "  ${W}0)${NC}  Geri"
    echo ""
    divider
    echo -e "  ${Y}Seçim:${NC} \c"
    read -r ch

    case "$ch" in
        1)
            echo -e "  ${Y}Container adı [backend/frontend/db]:${NC} \c"; read -r cname
            [ -z "$cname" ] && return
            docker exec -it "$cname" bash 2>/dev/null \
                || docker exec -it "$cname" sh \
                || err "Bağlanılamadı."
            ;;
        2)
            info "Ctrl+C ile çıkın..."
            docker stats ;;
        3)
            echo -e "  ${Y}Container adı:${NC} \c"; read -r cname
            [ -z "$cname" ] && return
            docker inspect "$cname" | less -R ;;
        4)
            info "PostgreSQL'e bağlanılıyor..."
            DB_CONTAINER=$(docker ps --format '{{.Names}}' | grep -i "db\|postgres" | head -1)
            if [ -z "$DB_CONTAINER" ]; then
                err "Veritabanı container'ı bulunamadı."
            else
                docker exec -it "$DB_CONTAINER" psql -U stokfinans_user -d stokfinans_db \
                    2>/dev/null || err "Bağlanılamadı."
            fi ;;
        0) return ;;
        *) err "Geçersiz seçim."; press_enter ;;
    esac
}

# ============================================================
# 8) GÜNCELLEŞTİR (git pull + deploy)
# ============================================================
update_menu() {
    clear_screen
    header
    echo -e "  ${BOLD}${W}Güncelleme${NC}"
    divider
    echo ""

    if ! git -C . rev-parse --git-dir &>/dev/null; then
        warn "Bu dizin bir git deposu değil — git pull atlanıyor."
    else
        BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "?")
        info "Mevcut branch: ${Y}$BRANCH${NC}"
        echo ""
        echo -e "  ${W}1)${NC}  git pull + build + up"
        echo -e "  ${W}2)${NC}  Sadece git pull (build yapmadan)"
        echo -e "  ${W}0)${NC}  Geri"
        echo ""
        divider
        echo -e "  ${Y}Seçim:${NC} \c"
        read -r ch

        case "$ch" in
            1)
                info "git pull çekiliyor..."
                git pull
                info "Build ediliyor..."
                $DC build
                info "Başlatılıyor..."
                $DC up -d
                ok "Güncelleme tamamlandı."
                press_enter ;;
            2)
                info "git pull çekiliyor..."
                git pull
                ok "Kod güncellendi. Build için ana menüden Deploy seçin."
                press_enter ;;
            0) return ;;
            *) err "Geçersiz seçim."; press_enter ;;
        esac
        return
    fi
    press_enter
}

# ============================================================
# ANA MENÜ
# ============================================================
main_menu() {
    while true; do
        clear_screen
        header

        # Hızlı durum
        RUNNING=$(docker ps -q 2>/dev/null | wc -l | tr -d ' ')
        TOTAL=$(docker ps -aq 2>/dev/null | wc -l | tr -d ' ')
        if [ "$RUNNING" -gt 0 ]; then
            echo -e "  ${G}● Sistem Aktif${NC}  —  ${G}${RUNNING}${NC} / ${TOTAL} container çalışıyor"
        else
            echo -e "  ${R}● Sistem Durmuş${NC}  —  0 / ${TOTAL} container çalışıyor"
        fi
        echo ""
        divider
        echo ""
        echo -e "  ${W}1)${NC}  ${C}Durum${NC}            — container'lar, image'lar, kaynaklar"
        echo -e "  ${W}2)${NC}  ${G}Deploy (Build+Başlat)${NC} — tek adımda"
        echo -e "  ${W}3)${NC}  ${Y}Build${NC}             — sadece build"
        echo -e "  ${W}4)${NC}  ${G}Başlat/Durdur${NC}     — servis kontrolü"
        echo -e "  ${W}5)${NC}  ${C}Loglar${NC}            — canlı veya geçmiş"
        echo -e "  ${W}6)${NC}  ${C}Container İncele${NC}  — bağlan, istatistik, psql"
        echo -e "  ${W}7)${NC}  ${Y}Güncelle${NC}          — git pull + deploy"
        echo -e "  ${W}8)${NC}  ${R}Sil/Temizle${NC}       — container, image, volume"
        echo ""
        divider
        echo -e "  ${W}0)${NC}  Çıkış"
        echo ""
        echo -e "  ${Y}Seçim:${NC} \c"
        read -r choice

        case "$choice" in
            1) show_status ;;
            2) deploy_menu ;;
            3) build_menu ;;
            4) control_menu ;;
            5) logs_menu ;;
            6) inspect_menu ;;
            7) update_menu ;;
            8) remove_menu ;;
            0)
                echo ""
                ok "Çıkılıyor."
                echo ""
                exit 0 ;;
            *)
                err "Geçersiz seçim: '$choice'"
                sleep 1 ;;
        esac
    done
}

# ── Başlangıç kontrolleri ────────────────────────────────────
if ! command -v docker &>/dev/null; then
    echo -e "${R}HATA: Docker kurulu değil veya PATH'te yok.${NC}"
    exit 1
fi

if ! docker info &>/dev/null; then
    echo -e "${R}HATA: Docker daemon çalışmıyor veya bu kullanıcının Docker izni yok.${NC}"
    echo -e "${Y}İpucu: 'sudo usermod -aG docker \$USER && newgrp docker' komutunu deneyin.${NC}"
    exit 1
fi

# docker compose v2 mi v1 mi?
if ! docker compose version &>/dev/null 2>&1; then
    if command -v docker-compose &>/dev/null; then
        DC="docker-compose"
    else
        echo -e "${R}HATA: 'docker compose' veya 'docker-compose' bulunamadı.${NC}"
        exit 1
    fi
fi

# docker-compose.yml var mı?
if [ ! -f "$COMPOSE_FILE" ]; then
    echo -e "${Y}Uyarı: $COMPOSE_FILE bulunamadı — bazı işlevler çalışmayabilir.${NC}"
fi

main_menu
