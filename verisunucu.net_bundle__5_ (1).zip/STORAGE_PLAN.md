# Depolama & Replikasyon Altyapısı — Uygulama Planı

**Tarih:** 2026-05-18  
**Durum:** Aktif — Faz 1 devam ediyor

---

## Teknoloji Seçimleri

| Bileşen | Seçim | Gerekçe |
|---------|-------|---------|
| Dosya Depolama | **MinIO** | Docker-native, S3-uyumlu, Python boto3 ile tam destek |
| DB Replikasyon (kısa vade) | **Mevcut Python sync (iyileştirilmiş)** | Sıfır migration riski, zaten çalışıyor |
| DB Replikasyon (uzun vade) | **pgLogical** | PostgreSQL native Galera alternatifi |
| Dağıtık Dosya Sistemi | **MinIO Distributed Mode** | Birden fazla disk/sunucu tek havuz gibi |
| Harici Yedek | **S3-uyumlu** (DigitalOcean/AWS/Cloudflare R2) | Dışarıda güvence |
| FTP/SFTP | Mevcut FtpServer → havuza entegre | Zaten var, genişletilecek |

---

## Mimari Genel Görünüm

```
                    ┌──────────────────────────────────────────────────────┐
                    │              DEPOLAMA HAVUZU (Storage Pool)          │
                    │                                                      │
                    │  ┌─────────────┐   ┌─────────────┐  ┌────────────┐  │
                    │  │  MinIO  S1  │◄─►│  MinIO  S2  │  │ FTP/SFTP  │  │
                    │  │  (Primary)  │   │  (Replica)  │  │  Sunucu   │  │
                    │  │  100GB+disk │   │  100GB disk │  │  Harici   │  │
                    │  └──────┬──────┘   └──────┬──────┘  └─────┬──────┘  │
                    │         └────────┬─────────┘               │         │
                    │                  ▼                          │         │
                    │       ┌──────────────────────┐             │         │
                    │       │   ANA YEDEK DÜĞÜM    │◄────────────┘         │
                    │       │  (Master Backup Node) │                       │
                    │       │   Günlük DB + Dosya  │                       │
                    │       │   20 Gün Saklama     │                       │
                    │       └──────────┬───────────┘                       │
                    │                  │                                    │
                    └──────────────────┼────────────────────────────────────┘
                                       ▼
                           ┌──────────────────────┐
                           │   HARİCİ S3 YEDEK   │
                           │  (DigitalOcean/AWS)  │
                           │  İkinci güvenlik net │
                           └──────────────────────┘
```

---

## Disk Yönetimi Mantığı

```
Örnek: S1'de 1TB disk, S2'de 500GB disk var
┌────────────────────────────────────────────────────────────┐
│  storage_nodes tablosu:                                    │
│  ┌─────────────────────────────────────────────────────┐  │
│  │ ID │ İsim       │ Tür   │ Boyut │ Kullanılan │ Rol  │  │
│  ├────┼────────────┼───────┼───────┼────────────┼──────┤  │
│  │  1 │ S1-MinIO   │ minio │ 1 TB  │    350 GB  │ ANA  │  │
│  │  2 │ S2-MinIO   │ minio │ 500GB │    350 GB  │ REP  │  │
│  │  3 │ SFTP-Yedek │ sftp  │ 2 TB  │    700 GB  │ MYD  │  │
│  └─────────────────────────────────────────────────────┘  │
│                                                            │
│  storage_file_replicas tablosu (hangi dosya nerede):      │
│  ┌─────────────────────────────────────────────────────┐  │
│  │ dosya_id │ node_id │ path               │ birincil │  │
│  ├──────────┼─────────┼────────────────────┼──────────┤  │
│  │      101 │       1 │ uploads/abc123.jpg  │   EVET   │  │
│  │      101 │       2 │ uploads/abc123.jpg  │   HAYIR  │  │
│  │      102 │       1 │ uploads/xyz789.pdf  │   EVET   │  │
│  │      102 │       2 │ uploads/xyz789.pdf  │   HAYIR  │  │
│  └─────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────┘
```

---

## Faz Listesi

| # | Faz | İçerik | Süre | Durum |
|---|-----|--------|------|-------|
| **1** | **DB Modelleri** | StorageNode, StorageFile, StorageFileReplica, StorageDailyBackup tabloları | 2 saat | ✅ **Tamamlandı** |
| **2** | **MinIO Docker Kurulumu** | docker-compose'a MinIO ekle, S1 ve S2'de başlat, bucket ayarla | 2 saat | ✅ **Tamamlandı** |
| **3** | **MinIO ↔ Uygulama Entegrasyonu** | storage_service.py: upload/download/presigned URL, replica tracking | 3 saat | ✅ **Tamamlandı** |
| **4** | **Disk Envanteri API** | /api/v1/storage/* — nodes CRUD, file listing, backup trigger, stats | 2 saat | ✅ **Tamamlandı** |
| **5** | **Storage Dashboard UI** | SuperAdmin → "Depolama Havuzu" sekmesi: düğümler, disk çubuğu, dosya envanteri, yedekler | 3 saat | ✅ **Tamamlandı** |
| **6** | **Ana Yedek Sistemi** | Günlük DB dump + MinIO yedek → master node, 20 gün saklama, otomatik temizlik | 2 saat | ✅ **Tamamlandı (servis hazır)** |
| **7** | **FTP/SFTP → Havuz** | Mevcut FtpServer'ları storage_nodes'a entegre et, havuza dahil et | 1 saat | ⏳ Bekliyor |
| **8** | **Harici S3 Yedek** | S3-uyumlu harici depolamaya günlük yedek push | 2 saat | ✅ **Tamamlandı** |
| **9** | **pgLogical Multi-Master DB** | PostgreSQL native çift yönlü replikasyon, Galera alternatifi | 1 hafta | ⏳ Bekliyor |

---

## Faz 1 — DB Modelleri Detayı

### Yeni tablolar:

**`storage_nodes`** — Depolama düğümleri (MinIO, SFTP, FTP, S3, yerel disk)
```
id, name, type (local/minio/sftp/ftp/s3),
host, port, username, password_encrypted,
access_key, secret_key_encrypted, bucket, endpoint_url,
total_bytes, used_bytes, free_bytes,
is_master_backup, is_primary, is_active,
last_check_at, last_error, created_at, updated_at
```

**`storage_files`** — Dosya kayıtları (merkezi envanter)
```
id, filename, storage_key (object key), size_bytes,
content_type, checksum_sha256, user_id (FK→users),
uploaded_at, updated_at
```

**`storage_file_replicas`** — Hangi dosya hangi düğümde
```
id, file_id (FK→storage_files CASCADE),
node_id (FK→storage_nodes CASCADE),
path_on_node, is_primary, is_verified,
last_verified_at, created_at
```

**`storage_daily_backups`** — Günlük yedek kayıtları
```
id, node_id (FK→storage_nodes SET NULL),
backup_type (daily/manual), includes_db, includes_files,
filename, size_bytes, status (pending/running/done/failed),
error, backup_date, expires_at (backup_date + 20 gün),
completed_at, created_at
```

---

## Faz 2 — MinIO Docker Kurulumu Detayı

### docker-compose.yml'e eklenecek servis:
```yaml
minio:
  image: minio/minio:latest
  container_name: stokfinans-minio
  command: server /data --console-address ":9001"
  environment:
    MINIO_ROOT_USER: stokfinans_minio
    MINIO_ROOT_PASSWORD: <güçlü_şifre>
  volumes:
    - minio_data:/data
  ports:
    - "9000:9000"   # S3 API
    - "9001:9001"   # Web console
  networks:
    - stokfinans_network
  restart: unless-stopped
  healthcheck:
    test: ["CMD", "mc", "ready", "local"]
    interval: 30s
    timeout: 20s
    retries: 3
```

### Backend env değişkenleri:
```
MINIO_ENDPOINT=http://minio:9000
MINIO_ACCESS_KEY=stokfinans_minio
MINIO_SECRET_KEY=<güçlü_şifre>
MINIO_BUCKET=stokfinans-uploads
MINIO_SECURE=false
```

---

## Faz 3 — MinIO Entegrasyon Detayı

### Dosya yükleme akışı (mevcut vs yeni):
```
MEVCUT:
  POST /files/upload → disk'e kaydet → FileLocation DB kaydı

YENİ:
  POST /files/upload → MinIO'ya yükle (boto3/aioboto3)
                     → storage_files DB kaydı
                     → storage_file_replicas: node_id=S1-MinIO, is_primary=True
                     → MinIO replikasyon kuralı → S2'ye otomatik kopyala
                     → storage_file_replicas: node_id=S2-MinIO, is_primary=False
```

### Dosya serve akışı:
```
GET /files/{filename}
  → storage_file_replicas sorgusu (en yakın erişilebilir node)
  → MinIO presigned URL oluştur (60 dakika geçerli)
  → redirect veya proxy
```

---

## Faz 5 — Storage Dashboard UI Detayı

### SuperAdmin paneline "Depolama" sekmesi:
```
┌─────────────────────────────────────────────────────────┐
│  💾 DEPOLAMA HAVUZU                                     │
├──────────────┬──────────────┬──────────────┬────────────┤
│ Toplam Alan  │ Kullanılan   │ Boş Alan     │ Dosya Say. │
│   2.5 TB     │   1.1 TB     │   1.4 TB     │   14,382   │
├─────────────────────────────────────────────────────────┤
│  DÜĞÜMLER                              [+ Düğüm Ekle]  │
│  ┌──────────────────────────────────────────────────┐  │
│  │ 🟢 S1-MinIO | ANA  | 1TB | %35 dolu | 14,382 🗂 │  │
│  │ 🟢 S2-MinIO | REP  | 500GB| %70 dolu | 14,382 🗂 │  │
│  │ 🟢 SFTP-Ydk | MYD  | 2TB | %35 dolu | 2 yedek   │  │
│  └──────────────────────────────────────────────────┘  │
├─────────────────────────────────────────────────────────┤
│  DOSYA ENVANTERİ                    [Ara] [Filtrele]    │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Dosya adı    │ Boyut │ S1 │ S2 │ SFTP │ Kontrol │  │
│  │ abc123.jpg   │ 2.3MB │ ✅ │ ✅ │  —   │ SHA✓   │  │
│  │ invoice.pdf  │ 512KB │ ✅ │ ✅ │  —   │ SHA✓   │  │
│  └──────────────────────────────────────────────────┘  │
├─────────────────────────────────────────────────────────┤
│  GÜNLÜK YEDEKLER                                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │ 2026-05-18 | ✅ Tamamlandı | 4.2 GB | 17g kaldı │  │
│  │ 2026-05-17 | ✅ Tamamlandı | 4.1 GB | 16g kaldı │  │
│  │ 2026-04-29 | ✅ Tamamlandı | 3.9 GB |  0g → SİL │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

---

## Faz 6 — Ana Yedek Sistemi Detayı

### Yedekleme akışı (her gece 02:00):
```
1. DB dump: pg_dump → stokfinans_20260518.sql.gz
2. MinIO snapshot: minio mirror → tüm bucket'ı indir
3. ZIP: DB dump + MinIO snapshot → backup_20260518.zip
4. Master node'a yükle (SFTP/MinIO)
5. storage_daily_backups kaydı oluştur (expires_at = +20 gün)
6. 20 günden eski yedekleri sil + DB kaydını güncelle
```

---

## Faz 9 — pgLogical Multi-Master Detayı

### Neden pgLogical (Galera yerine)?
- Mevcut PostgreSQL'de çalışır, migration gerekmez
- Mantıksal replikasyon → çakışma tespiti mümkün
- Her sunucu yazma kabul eder (gerçek multi-master)
- Galera'nın IST/SST eşdeğeri: `pglogical.sync_all_tables()`

### Kurulum adımları:
```
1. Her PostgreSQL'e pglogical extension ekle
2. postgresql.conf: wal_level=logical, max_wal_senders=10
3. pg_hba.conf: replikasyon bağlantısına izin ver
4. S1'de: SELECT pglogical.create_node('s1', 'host=s1...');
5. S2'de: SELECT pglogical.create_node('s2', 'host=s2...');
6. Çift yönlü subscription kur
7. Çakışma çözme: last-update-wins (update_origin_filter)
8. Mevcut Python sync servisi kapatılır
```

---

## Notlar

- Her faz bağımsız deploy edilebilir, rollback mümkün
- MinIO kurulumu mevcut uygulamayı kesmez (paralel çalışır)
- pgLogical fazı en riskli — önce staging'de test edilmeli
- `storage_nodes` tablosu mevcut `ftp_servers` tablosunun üst kümesidir (FTP server'lar buraya taşınır)
