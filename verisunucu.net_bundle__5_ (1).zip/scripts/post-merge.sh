#!/bin/bash
set -e

echo "[post-merge] Backend bağımlılıkları kontrol ediliyor..."
cd backend
pip install -r requirements.txt --quiet
cd ..

echo "[post-merge] Frontend bağımlılıkları kontrol ediliyor..."
cd frontend
npm install --legacy-peer-deps --silent
cd ..

echo "[post-merge] Tamamlandı."
