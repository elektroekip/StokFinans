# 🚀 StokFinans - Deployment Guide

**Seviye:** SEVIYE 7 - Zirve & Deployment  
**Tarih:** 28 Nisan 2026  
**Versiyon:** 1.0.0

---

## 📋 İçindekiler

1. [Gereksinimler](#gereksinimler)
2. [Yerel Geliştirme](#yerel-geliştirme)
3. [Docker Kurulumu](#docker-kurulumu)
4. [Üretim Dağıtımı](#üretim-dağıtımı)
5. [GitHub Actions CI/CD](#github-actions-cicd)
6. [Monitoring ve Logging](#monitoring-ve-logging)
7. [SSL/TLS Yapılandırması](#ssltls-yapılandırması)
8. [Sorun Giderme](#sorun-giderme)

---

## 🔧 Gereksinimler

### Yerel Geliştirme

- **Node.js:** 20 LTS
- **Python:** 3.13+
- **npm/pip:** Paket yöneticileri
- **Git:** Versiyon kontrolü

### Docker Kurulumu

- **Docker:** 24.0+
- **Docker Compose:** 2.20+
- **Docker buildx:** İçinde bulunan

### Üretim (VPS)

- **OS:** Ubuntu 22.04 LTS veya daha yeni
- **CPU:** 2+ cores
- **RAM:** 4 GB minimum
- **Disk:** 50 GB SSD

---

## 💻 Yerel Geliştirme

### 1. Repository Klonlama

```bash
git clone https://github.com/yourusername/stokfinans.git
cd stokfinans
```

### 2. Environment Dosyası Oluşturma

```bash
cp .env.example .env
# Edit .env with local settings
```

### 3. Docker Compose (Development)

Development mod sıcak yükleme (hot reload) ile çalışır:

```bash
# Tüm servisleri başlat
docker-compose -f docker-compose.dev.yml up

# Arka planda çalıştır
docker-compose -f docker-compose.dev.yml up -d

# Logları görüntüle
docker-compose -f docker-compose.dev.yml logs -f

# Durumunu kontrol et
docker-compose -f docker-compose.dev.yml ps
```

**Erişim Noktaları:**
- Frontend: http://localhost:5173 (Vite dev server)
- Backend API: http://localhost:8000
- API Docs: http://localhost:8000/api/docs
- Database: postgres://stokfinans_user:stokfinans_secure_password@localhost:5432/stokfinans_db

### 4. Manuel Başlatma (Docker olmadan)

```bash
# Backend
cd backend
python -m venv venv
source venv/bin/activate  # Linux/macOS
# or
venv\Scripts\activate  # Windows

pip install -r requirements.txt
uvicorn main:app --reload

# Frontend (ayrı terminal)
cd frontend
npm install
npm run dev
```

---

## 🐳 Docker Kurulumu

### Production Dockerfile Özellikleri

**Backend (Python FastAPI):**
- Multi-stage build: base → dependencies → production
- Python 3.13 slim image
- 4 Uvicorn workers (production)
- Health check: /health endpoint
- Non-root user (appuser:1000) for security

**Frontend (React + Nginx):**
- Multi-stage build: build → production
- Node 20 alpine (build phase)
- Nginx alpine (serving phase)
- Gzip compression
- SPA fallback routing
- Security headers (X-Frame-Options, X-Content-Type-Options)

### Docker Compose Orchestration

```yaml
Services:
├── backend (FastAPI)
├── frontend (Nginx)
└── db (PostgreSQL 16)

Networks:
└── stokfinans_network (bridge, 172.28.0.0/16)

Volumes:
├── postgres_data (persistent)
├── backend_logs
└── frontend_logs
```

### Image Build

```bash
# Build images (cached)
docker-compose build

# Build without cache
docker-compose build --no-cache

# Build specific service
docker-compose build backend
docker-compose build frontend
```

### Health Checks

Her service'in built-in health check'i var:

```bash
# Backend health
docker-compose exec backend curl http://localhost:8000/health

# Frontend health
docker-compose exec frontend wget -O /dev/null http://localhost:80/

# Database health
docker-compose exec db pg_isready -U stokfinans_user
```

---

## 🌍 Üretim Dağıtımı

### VPS Kurulumu (Ubuntu 22.04)

#### 1. Docker Yükle

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Add user to docker group
sudo usermod -aG docker $USER
newgrp docker

# Install Docker Compose
sudo apt install docker-compose-plugin

# Verify installation
docker --version
docker compose version
```

#### 2. Repository Setup

```bash
# Create app directory
sudo mkdir -p /opt/stokfinans
cd /opt/stokfinans

# Clone repository (use SSH for secure access)
sudo git clone git@github.com:yourusername/stokfinans.git .

# Set permissions
sudo chown -R $USER:$USER /opt/stokfinans
```

#### 3. Environment Configuration

```bash
# Copy and edit production environment
cp .env.example .env.production

# Edit with your production values
nano .env.production

# Key values to set:
# - JWT_SECRET_KEY: Generate with: python3 -c "import secrets; print(secrets.token_urlsafe(32))"
# - DATABASE_URL: PostgreSQL connection string
# - ALLOWED_ORIGINS: Your production domain
# - SSL certificates paths
```

#### 4. SSL/TLS Setup (Let's Encrypt)

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Generate certificate
sudo certbot certonly --standalone -d stokfinans.com -d www.stokfinans.com

# Auto-renewal
sudo systemctl enable certbot.timer
sudo systemctl start certbot.timer

# Verify cert
sudo certbot certificates
```

#### 5. Nginx Reverse Proxy (Host Level)

Create `/etc/nginx/sites-available/stokfinans.conf`:

```nginx
# HTTP → HTTPS redirect
server {
    listen 80;
    server_name stokfinans.com www.stokfinans.com;
    return 301 https://$server_name$request_uri;
}

# HTTPS - Main server
server {
    listen 443 ssl http2;
    server_name stokfinans.com www.stokfinans.com;

    # SSL certificates
    ssl_certificate /etc/letsencrypt/live/stokfinans.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/stokfinans.com/privkey.pem;

    # SSL configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;

    # Security headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Proxy to Docker containers
    location / {
        proxy_pass http://localhost:80;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # API proxy
    location /api/ {
        proxy_pass http://localhost:8000/api/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

Enable and restart:

```bash
sudo ln -s /etc/nginx/sites-available/stokfinans.conf /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

#### 6. Start Docker Containers

```bash
cd /opt/stokfinans

# Source environment (if not in .env)
export $(cat .env.production | xargs)

# Start services
docker compose up -d

# Verify all services running
docker compose ps

# Check health
docker compose exec backend curl http://localhost:8000/health
```

#### 7. Database Initialization

```bash
# Create database and migrations (if using Alembic)
docker compose exec -T backend python -m alembic upgrade head

# Or manual initialization:
docker compose exec db psql -U stokfinans_user -d stokfinans_db -c "
CREATE TABLE IF NOT EXISTS users (...);
-- Add more schema...
"
```

#### 8. Systemd Service (Auto-start on Reboot)

Create `/etc/systemd/system/stokfinans.service`:

```ini
[Unit]
Description=StokFinans Docker Compose
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/opt/stokfinans
ExecStart=/usr/bin/docker compose up -d
ExecStop=/usr/bin/docker compose down
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Enable and start:

```bash
sudo systemctl daemon-reload
sudo systemctl enable stokfinans
sudo systemctl start stokfinans
sudo systemctl status stokfinans
```

---

## 🔄 GitHub Actions CI/CD

### Setup

1. **Secrets Configuration**

   Add to GitHub Repository Settings → Secrets:

   ```
   VPS_HOST=your-vps-ip-or-domain
   VPS_USERNAME=ubuntu (or your user)
   VPS_SSH_KEY=your-private-ssh-key
   SLACK_WEBHOOK=your-slack-webhook-url (optional)
   ```

2. **Trigger Workflow**

   ```bash
   # Push to main for production deployment
   git push origin main

   # Push to develop for testing
   git push origin develop
   ```

### Pipeline Steps

1. **Backend Tests** (Python)
   - Lint with pylint/flake8
   - Type check with mypy
   - Run pytest with coverage
   - Upload to Codecov

2. **Frontend Tests** (Node.js)
   - npm ci (install dependencies)
   - npm run lint
   - TypeScript type check
   - npm run build

3. **Docker Build & Push**
   - Build both images
   - Push to GitHub Container Registry (GHCR)
   - Layer caching enabled

4. **Security Scanning**
   - Python dependency audit
   - npm audit
   - Trivy vulnerability scan

5. **Production Deployment** (Main branch only)
   - SSH into VPS
   - git pull origin main
   - docker-compose down
   - docker-compose pull
   - docker-compose up -d
   - Run migrations

---

## 📊 Monitoring ve Logging

### Log Aggregation

```bash
# View all service logs
docker compose logs -f

# View specific service
docker compose logs -f backend
docker compose logs -f frontend

# View logs with timestamps
docker compose logs --timestamps

# Follow last 100 lines
docker compose logs -f --tail=100
```

### Database Monitoring

```bash
# Connect to PostgreSQL
docker compose exec db psql -U stokfinans_user -d stokfinans_db

# Common queries:
\dt                              # List tables
SELECT COUNT(*) FROM users;      # Row counts
\l                               # List databases
\du                              # List users
```

### Container Health

```bash
# Real-time stats
docker stats

# Detailed inspect
docker compose ps
docker compose ps -q | xargs docker inspect

# Resource usage
docker system df
```

### Application Monitoring (Production)

#### Sentry Integration (Error Tracking)

1. Create Sentry account at https://sentry.io
2. Create project for Python (backend)
3. Add DSN to `.env.production`:

```bash
SENTRY_DSN=https://your-key@sentry.io/project-id
SENTRY_ENVIRONMENT=production
```

4. In backend code:

```python
import sentry_sdk

sentry_sdk.init(
    dsn=os.getenv("SENTRY_DSN"),
    environment=os.getenv("SENTRY_ENVIRONMENT"),
    traces_sample_rate=0.1
)
```

#### PM2 Process Manager (Optional)

For bare-metal (non-Docker) deployments:

```bash
npm install -g pm2

# Backend
pm2 start "uvicorn main:app --host 0.0.0.0 --port 8000" --name backend
pm2 start "npm run dev" --name frontend --cwd ./frontend

# Save startup script
pm2 startup
pm2 save

# Monitor
pm2 status
pm2 logs
```

---

## 🔐 SSL/TLS Yapılandırması

### Let's Encrypt Setup

```bash
# Install certbot
sudo apt install certbot python3-certbot-certbot-nginx

# Generate certificate
sudo certbot certonly --standalone -d stokfinans.com

# Certificate location
# - Certificate: /etc/letsencrypt/live/stokfinans.com/fullchain.pem
# - Private key: /etc/letsencrypt/live/stokfinans.com/privkey.pem

# Auto-renewal (runs daily)
sudo certbot renew --dry-run
```

### Nginx SSL Configuration

Update `/etc/nginx/sites-available/stokfinans.conf`:

```nginx
server {
    listen 443 ssl http2;
    server_name stokfinans.com;

    ssl_certificate /etc/letsencrypt/live/stokfinans.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/stokfinans.com/privkey.pem;

    # Modern configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256;
    ssl_prefer_server_ciphers off;

    # HSTS
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # ... rest of config
}
```

---

## 🔧 Sorun Giderme

### Backend sorunları

```bash
# Backend loglarını kontrol et
docker compose logs -f backend

# Common errors:
# - "Connection refused": Database not ready
#   → Fix: Ensure db service is healthy: docker compose ps

# - "ModuleNotFoundError": Missing Python package
#   → Fix: docker compose exec backend pip install -r requirements.txt

# - "port already in use": 8000 port conflict
#   → Fix: docker compose down; docker compose up -d
```

### Frontend sorunları

```bash
# Frontend loglarını kontrol et
docker compose logs -f frontend

# Common errors:
# - "Module not found": Missing npm package
#   → Fix: docker compose exec frontend npm install

# - "404 Not Found": Routing issue
#   → Check nginx.conf try_files directive

# - "CORS error": Wrong API URL
#   → Check VITE_API_URL environment variable
```

### Database sorunları

```bash
# Database loglarını kontrol et
docker compose logs -f db

# Connect and check
docker compose exec db psql -U stokfinans_user -d stokfinans_db

# Common fixes:
# - Reset database: docker compose down -v; docker compose up -d
# - Check disk space: du -sh /var/lib/postgresql/data
```

### Network sorunları

```bash
# Inspect Docker network
docker network inspect stokfinans_network

# Test connectivity between containers
docker compose exec backend ping frontend
docker compose exec backend curl http://db:5432

# Check exposed ports
docker compose ps
```

---

## 📝 Kullanışlı Komutlar

```bash
# Development
docker-compose -f docker-compose.dev.yml up -d

# Production
docker-compose up -d

# Logs
docker-compose logs -f [service]

# Stop/Start
docker-compose stop
docker-compose start

# Restart
docker-compose restart backend

# Execute commands
docker-compose exec backend bash
docker-compose exec frontend sh

# Database access
docker-compose exec db psql -U stokfinans_user -d stokfinans_db

# View volumes
docker volume ls
docker volume inspect stokfinans_postgres_data

# Clean up (CAUTION!)
docker-compose down              # Stop and remove containers
docker-compose down -v           # Also remove volumes (data loss!)
docker system prune              # Remove unused images/networks
```

---

## 🎯 Production Checklist

- [ ] Domain configured (DNS A record pointing to VPS)
- [ ] SSL certificate installed (Let's Encrypt)
- [ ] Environment variables set (.env.production)
- [ ] Database backups configured
- [ ] GitHub Actions secrets configured
- [ ] Monitoring/Sentry configured
- [ ] Nginx reverse proxy setup
- [ ] Health checks passing
- [ ] Database migrations applied
- [ ] Logs rotating properly
- [ ] Firewall rules set (allow 80, 443, restrict 8000, 5432)

---

## 📞 Support

- **Issues:** GitHub Issues
- **Docs:** Check DEVELOPMENT.md for architecture
- **Logs:** docker-compose logs -f

---

**StokFinans Production Ready! 🚀**

