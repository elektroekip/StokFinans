# Docker Test Log - 28 Nisan 2026

## Build Start Time
2026-04-28 18:30

## Test Checklist

### Containers Status
- [ ] stokfinans-backend-dev (backend service)
- [ ] stokfinans-frontend-dev (frontend service)
- [ ] stokfinans-db-dev (PostgreSQL)

### Connectivity Tests
- [ ] Backend API responds at http://localhost:8000
- [ ] Frontend loads at http://localhost:5173
- [ ] API docs available at http://localhost:8000/api/docs
- [ ] Database port 5432 reachable
- [ ] Health checks passing

### Docker Compose Tests
- [ ] docker-compose ps shows all running
- [ ] docker-compose logs show no errors
- [ ] Volume mounts working (hot reload)
- [ ] Network stokfinans_network created

### Build Status
**Frontend:** Building (npm install)
**Backend:** Building (pip install -r requirements.txt)
**Database:** Ready

## Fixed Issues
1. ✅ python-logging-loki 0.3.2 → commented (version not found)
2. ✅ pillow 10.1.0 → 11.0.0 (Python 3.13 compatibility)
3. ✅ psycopg2-binary 2.9.9 → 2.9.10
4. ✅ Removed obsolete 'version: 3.8' from compose files
5. ✅ npm install instead of npm ci --only=production

## Notes
- Build takes 3-5 minutes on first run
- Layer caching will speed up subsequent builds
- All tests run in development mode (hot reload enabled)
