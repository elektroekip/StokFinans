# StokFinans

Türkçe stok ve finans yönetimi web uygulaması (Multi-tenant — her bayinin verileri kendine ait).

## Mimari

- **Backend:** FastAPI (Python 3.11) + SQLAlchemy + JWT auth — `backend/`
- **Frontend:** React 19 + Vite + TypeScript + Tailwind v4 + shadcn/ui — `frontend/`
- **Veritabanı:** Replit-managed PostgreSQL (DATABASE_URL otomatik enjekte edilir)

## Workflows

- `Backend`: `cd backend && python -m uvicorn main:app --host 0.0.0.0 --port 8000`
- `Frontend`: `cd frontend && npm run dev` (port 5000, `vite.config.ts` `host: 0.0.0.0`)

## Önemli dosyalar

- `frontend/src/main.tsx` → `App.tsx`'i mount eder. **`App.tsx` (~3700 satır) canlı uygulamadır.**
  `pages/Dashboard.tsx`, `context/AuthContext.tsx` v.b. kullanılmıyor (eski kod, dokunmayın).
- `frontend/src/lib/api.ts` — backend rotalarıyla eşleşmiş `/finance`, `/files`, `/reports` prefiksleri.
- `frontend/src/index.css` — Tailwind v4 + class-tabanlı dark mode için
  `@custom-variant dark (&:where(.dark, .dark *));` direktifi gereklidir.
- `backend/main.py` — uygulama başlatma + `_apply_runtime_migrations()` (barkod kısıt göçü).
- `backend/app/models/product.py` — `UniqueConstraint("user_id", "barcode")` (per-tenant).
- `backend/app/api/{products,finance,dashboard,reports,files,categories}.py` — tüm SELECT/UPDATE/DELETE
  sorguları `user_id == current_user.id` filtresi içerir.

## Fotoğraf yükleme akışı

- `Product.image_url` ve `Transaction.image_url` modeli `Column(String(1000), nullable=True)`.
  Yeni eklenirse `_apply_runtime_migrations()` veya manuel `ALTER TABLE ... ADD COLUMN IF NOT EXISTS image_url`.
- `ProductResponse` ve `TransactionResponse` Pydantic şemaları **`image_url: Optional[str]` alanını içermek zorundadır** —
  yoksa frontend'e hiç gitmez ve UI resmi göremez.
- `GET /api/v1/files/{filename}` **public** (auth yok). `<img src>` Bearer header gönderemediği için zorunlu.
  Filename'lar `{entity}_{id}_{uuid8}.ext` formatında — guess imkansız. Path-traversal koruması var.
- Frontend (`App.tsx` line ~2012): cache-bust için `imageUrl: \`\${p.image_url}?v=\${p.updated_at}\``.

## Web Görünüm — Kategori yönetimi (per-bayi)

Her bayi kendi sidebar/dashboard kategorilerini tam yönetebilir.

- **Model:** `backend/app/models/category.py` — `UniqueConstraint(user_id, kind, key)`.
  `kind` ∈ {stok, finans}. Finans kayıtlarında `transaction_type`, `customer_label`,
  `amount_label`, `amount_tone`, `allow_edit_type` ek alanları bulunur.
- **API:** `backend/app/api/categories.py` — GET (eksikse 7 stok + 6 finans default'u **otomatik
  seed eder**, idempotenttir), POST, PUT (isim değişikliğinde `Product.category` string'lerini
  de günceller), DELETE (`stok` kategorisinde ürün varsa 409 döner; `move_products_to`
  parametresiyle ürünler başka kategoriye taşınabilir), POST `/reorder` (atomik toplu
  display_order güncellemesi — tek transaction).
- **Frontend:** `AppContext.categories` kullanıcı login olunca tek kez fetch edilir.
  Sidebar (`DashboardLayout`) ve `CustomerDashboard` grid'leri bu listeden türer
  (`is_visible=true`, `display_order` ASC). `WebSettingsView` (sadece patron rolü)
  CRUD UI'sı sağlar: ikon kütüphanesi (`ICON_LIBRARY`), 10-renkli palet, yukarı/aşağı
  sıralama, görünürlük toggle, finans-tipi extra alan editörü, canlı önizleme.
- **Slug:** kategori `key`'i `_slugify_key` ile Türkçe→ASCII normalize edilir
  (ç→c, ğ→g, ı→i, ö→o, ş→s, ü→u).
- **Görünüm tarzı (`view_mode`):** kategori başına 5 mod — `list` (klasik tablo,
  varsayılan), `grid` (3-4 kolon kart), `masonry` (CSS columns, mozaik), `carousel`
  (yatay kaydırma) ve `category` (ilk harfe / aya göre alt-gruplara bölünmüş kart
  ızgaraları). Schema seviyesinde `Literal[...]` ile doğrulanır; runtime migration
  `ALTER TABLE categories ADD COLUMN IF NOT EXISTS view_mode VARCHAR(20) NOT NULL
  DEFAULT 'list'` startup'ta uygulanır. Düzenleme modalindeki "Görünüm Tarzı"
  picker'ından seçilir; `GenericModuleView` `cfg.viewMode`'a göre branch yapar.

## Alt-etiket (subcategory), para birimi ve sayfalama

- **`Product.subcategory` (VARCHAR 100, nullable, indexli):** ürünün marka/tür
  bilgisini saklar. Form üst kısmındaki "Marka / Tür" datalist alanı boş başlar,
  kullanıcı yazdıkça önceki kayıtlardan otomatik öneri gösterir. Liste başlığının
  altında chip strip (`subcategoryOptions`) ile tek tıkla filtre uygulanır
  (`subcategoryFilter` state). Form "Kategori" alanı da artık datalist; sabit
  `<select>` kaldırıldı.
- **Para birimi (`Product.cost_currency`, `Product.currency`,
  `Transaction.currency` — VARCHAR 3, default `'TRY'`, indexli, CHECK
  `IN ('TRY','USD','EUR')`):** schemas pattern `^(TRY|USD|EUR)$` ile doğrular.
  Stok formunda **iki** ayrı 3-butonlu seçici (`Alış Para Birimi` amber,
  `Satış Para Birimi` indigo) — toptancıdan EUR alıp TRY satmak gibi çapraz kur
  senaryoları desteklenir. İkisi farklıysa amber "Çapraz Kur" uyarı kutusu
  gösterilir; tablo satırında alış kendi sembolüyle render edilir
  (`formatMoney(buyPrice, costCurrency)`). Finans formunda tek seçici (TRY/USD/EUR).
  `formatMoney(amount, currency)` her satırın kendi para birimini biçimler.
  **Migration kuralı:** runtime startup hook yalnızca kolon/index/CHECK ekler;
  kayıt verisini taşıyan/güncelleyen UPDATE ifadesi yoktur (idempotent değil olduğu için
  bilinçli çapraz-kur kayıtlarını her restart'ta bozardı).
- **Sayfalama (`PAGE_SIZE = 24`):** `GenericModuleView`'da `paginatedData`
  list/grid/masonry/carousel modlarında kullanılır; ellipsis'li sayfa numarası
  (1, 2, …, N) ve Önceki/Sonraki butonları içeren footer render edilir. Footer
  `cfg.viewMode === 'category'` olduğunda gizlenir (gruplama bozulmasın).
  `searchTerm`, `subcategoryFilter`, `moduleId` değişince sayfa 1'e döner.
  Backend `/products` ve `/finance/transactions` `page_size` üst sınırı `le=1000`
  yapıldı (önceden 100 idi). Migration startup hook'unda:

```sql
ALTER TABLE products ADD COLUMN IF NOT EXISTS subcategory VARCHAR(100);
CREATE INDEX IF NOT EXISTS ix_products_subcategory ON products (subcategory);
ALTER TABLE products ADD COLUMN IF NOT EXISTS currency VARCHAR(3) NOT NULL DEFAULT 'TRY';
ALTER TABLE products ADD CONSTRAINT ck_products_currency CHECK (currency IN ('TRY','USD','EUR'));
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS currency VARCHAR(3) NOT NULL DEFAULT 'TRY';
ALTER TABLE transactions ADD CONSTRAINT ck_transactions_currency CHECK (currency IN ('TRY','USD','EUR'));
```

## Çoklu kiracılık (multi-tenant) güvenlik kuralları

**Kritik:** Her veri sorgusu (`Product`, `Transaction`, `ActivityLog`) mutlaka
`user_id == current_user.id` filtresi içermelidir. Aksi halde bayiler birbirinin
verilerini görebilir. Aşağıdaki yardımcı fonksiyonlar her zaman `user_id` parametresi alır:

- `dashboard.get_product_stats(db, user_id)`, `get_sales_metrics(db, user_id)`
- `finance.calculate_customer_balance(db, customer_name, user_id)`
- `files._user_owns_file(db, filename, user_id)` — dosya indirme/silme öncesi sahiplik kontrolü

Barkodlar artık global değil, **(user_id, barcode)** çifti üzerinde benzersizdir;
böylece iki bayi aynı barkodu kullanabilir. Migration `backend/main.py`
startup hook'unda otomatik uygulanır:

```sql
ALTER TABLE products DROP CONSTRAINT IF EXISTS products_barcode_key;
DROP INDEX IF EXISTS ix_products_barcode;
ALTER TABLE products ADD CONSTRAINT uq_products_user_barcode UNIQUE (user_id, barcode);
CREATE INDEX IF NOT EXISTS ix_products_barcode ON products (barcode);
```

## Personel (çalışan) yönetimi & sayfa izinleri

Patron (`role='bayi_sahibi'`) kendi firmasına e-posta tabanlı **davet** ile personel ekler.
Şifreyi patron belirlemez; çalışan kayıt formunda kendisi belirler.

**Modeller:**
- `users.parent_user_id` (Int, FK→users.id, nullable) — çalışanın bağlı olduğu patron.
- `users.permissions` (JSONB array<string>, default `[]`) — çalışanın erişebileceği sayfa kodları.
- `employee_invites` tablosu — patronun yarattığı davet kayıtları.
  Kolonlar: `email` (unique), `full_name`, `parent_user_id`, `permissions` (JSONB), `is_consumed`, `consumed_user_id`, `consumed_at`.

**Geçerli izin kodları (granüler model — frontend & backend ortak):**
- `dashboard`, `reports.view`, `profile.view`
- `products.view | products.add | products.edit | products.delete`
- `finance.<tip>.<aksiyon>` — tipler: `veresiye, firma, senet, kredi, kasa, garanti`;
  aksiyonlar: `view, add, edit, delete`
- Eski (legacy) `["dashboard","products","finance","reports","profile"]` izinleri
  hem backend (`expand_legacy` `auth.py:_normalize_perms`) hem frontend (`hasPerm`
  `_expandLegacyPerm` fallback) tarafından otomatik genişletilir; veritabanı için
  ayrıca startup'ta tek seferlik `_migrate_employee_permissions_to_granular()`
  geçişi yapılır (`backend/main.py`).
- `transaction_type` → permission key eşlemesi (`finance_type_key()`):
  `borç→veresiye, gider→firma, senet→senet, kredi→kredi, garanti→garanti, NULL→kasa`.
  (Web Görünüm/Kategori Yönetimi sadece patron menüsünde olduğu için ayrı bir izin yok.)

**Backend yetki katmanı (`backend/app/utils/permissions.py`):**
- `is_owner(user)` — patron / süper admin tespiti.
- `has_perm(user, "products.add")` — granüler kontrol; legacy stringler runtime'da expand edilir.
- `require_perm(user, perm)` — 403 atar.
- `require_finance_action(user, transaction_type, action)` — finans alt-tipi guard'ı.
- `require_any_finance_view(user)` — en az bir `finance.*.view` iznini gerekli kılar (geniş GET'ler için).
- `products.py` her endpoint'in başında `require_perm(current_user, "products.<action>")`.
- `finance.py`:
  - POST/PUT/DELETE → ilgili `transaction_type`'tan `finance.<key>.<action>`.
  - GET single (`get/update/delete by id`): önce `require_any_finance_view`, kayıt çekildikten
    sonra `require_finance_action(user, tx.transaction_type, action)` ile **spesifik tip kontrolü**.
  - GET list: filtre verilmişse spesifik view; yoksa any-finance-view.

**Tenant helper (`backend/app/utils/tenant.py`):**
- `data_owner_id(user)` → çalışan ise `parent_user_id`, değilse `user.id`.
- Tüm veri sorguları (products, finance, dashboard, categories, files, reports)
  artık `current_user.id` yerine `data_owner_id(current_user)` ile filtrelenir.
  Böylece çalışan, patronun verisini görür/yazar; bayi-izolasyonu korunur.

**Endpoint'ler (`/api/v1/auth/...`):**
- `POST /employees` — davet oluştur (varsa upsert)
- `GET /employees` — aktif personel + bekleyen davet listesi
- `PATCH /employees/{user_id}/permissions` — aktif personelin izinleri
- `PATCH /employees/invite/{invite_id}/permissions` — davetin izinleri
- `DELETE /employees/{user_id}` — **personeli komple kaldırır**: `parent_user_id=NULL`,
  `is_active=False`, `permissions=[]` ve `email` invalid bir adresle (`deleted+{id}+{ts}@deleted.local`)
  mask'lenir; tüketilmiş davet kayıtları da silinir. Böylece FK'ler zarar görmeden geçmiş veri korunur
  ve aynı e-posta **başka bir firma tarafından** çalışan olarak yeniden davet edilebilir.
- `DELETE /employees/invite/{invite_id}` — bekleyen daveti iptal eder

**Kayıt akışı (`/auth/register`, `role='calisan'`):**
- Davet kontrolü: `EmployeeInvite.email == reg.email AND is_consumed=false` yoksa 400 döner
  ("Bu e-posta için herhangi bir firma sizi personel olarak eklemedi").
- Davetten `parent_user_id` ve `permissions` kopyalanır, `full_name` davetteki ile değişir.
- Çalışanın `sub_expires_at = NULL` — abonelik patrondan gelir.
- `SubscriptionEvent` sadece bayilar için yazılır.

**Subscription guard middleware (`backend/main.py`):**
Token payload'ında `sub=email`, `user_id=<int>` tutulur. Middleware **önce `user_id`**, yoksa
`sub`'a düşer (legacy fallback). Çalışan ise `parent_user_id` üzerinden patronu çekip onun
`sub_expires_at`'ini kontrol eder. Patron süper admin ise herkes (çalışan dahil) açıktır.

**Çalışan abonelik gösterimi (kritik):**
- Backend `_user_resp(user, db)` helper: `auth/login`, `auth/register`, `auth/profile`,
  `auth/profile PUT` cevaplarında çalışan ise `sub_days` PATRON'un kalan gününden hesaplanır.
- `GET /subscription/me`: çalışan ise `eff_user = parent` ile `package_slug`,
  `sub_expires_at`, `days_remaining`, `quota` patron üzerinden döner.
- Frontend `App.tsx`: süresi dolmuş gate'i `role !== 'calisan'` koşuluyla atlanır;
  abonelik patrona aittir, çalışan ödeme yapamaz, paneli kullanmaya devam eder.
- `POST /auth/refresh`: çalışan ise PATRON'un `sub_expires_at`'ı değerlendirilir;
  patron süper admin ise tamamen bypass. Aksi halde çalışan token'ı her yenilemede 403 alırdı.

**Frontend yetki türetme (legacy uyum) (`GenericModuleView`):**
Eski kod tabanı `permissions.canAdd / canEdit / canDelete / allowedModules` objesini bekliyordu.
Yeni model `permissions: string[]` array. `GenericModuleView` içinde `p` her render'da bayi rolü
ve modül izninden türetilir; patron için `{canAdd:true, canEdit:true, canDelete:true,
allowedModules:'all'}`, çalışan için modül iznine göre. Böylece tüm CRUD butonları (Yeni Kayıt,
Düzenle, Sil, Tahsilat/Borçlandır) patron için kırılmadan çalışmaya devam eder.

**Frontend sidebar filtresi (`DashboardLayout`):**
- Patron: tüm menüler.
- Çalışan: `currentUser.permissions` listesindeki kodlara göre filtreleme.
  - `dashboard` → Ana Panel
  - `products` → tüm stok kategorileri
  - `finance` → finans kategorileri + İşlem Geçmişi
  - `reports` → Gelişmiş Raporlar
  - `profile` → Profilim
  - Hiç izin yoksa "Yetki Verilmedi" kilitli butonu görünür.

**Personel Yönetimi ekranı (`EmployeeManagementView`):**
- Davet modalı: ad+e-posta+izin checkboxları (şifre alanı YOK).
- Tablo: aktif/davet bekliyor/pasif rozetleri, Yetkileri Düzenle modalı, Sil/İptal butonu.

## E-posta değiştirme akışı

Kullanıcılar profil ayarlarından e-posta adreslerini değiştirebilir. Yeni adres doğrulanana kadar eski adres aktif kalır.

- **Backend:** `POST /auth/change-email` — yeni e-posta + mevcut şifre doğrulama, yeni adrese doğrulama maili gönderir. `users.pending_email (VARCHAR 255)` kolonu yeni adresi tutar.
- **Doğrulama:** Mevcut `POST /auth/verify-email` endpoint'i `pending_email` varlığına göre dal yapar:
  - `pending_email` varsa: e-posta değişikliği → `user.email = pending_email`, `pending_email = NULL`, yeni token döner.
  - Yoksa: klasik kayıt doğrulaması.
- **E-posta şablonu:** `send_email_change_verification_email()` — `?action=confirm-email-change&token=...` URL'si.
- **Frontend:** `ProfileSettingsView` `App.tsx` — "E-posta adresini değiştir" butonu ile açılan form (yeni adres + mevcut şifre). Onay bekleyen adres sarı banner ile gösterilir.
- **Migration:** `backend/main.py` `_apply_runtime_migrations()` içinde `ALTER TABLE users ADD COLUMN IF NOT EXISTS pending_email VARCHAR(255)`.

## Bilinen kısıtlar / TODO

- Repo içinde `zipFile.zip` (~91MB) ve `backend/venv/` var — temizlenmeli (büyük).
- `frontend/package.json` versiyonları gerçekçi değil (`typescript ~6.0.2`, `lucide-react ^1.11.0`,
  `eslint ^10`); `npm install` muhtemelen lockfile'a düşürmüştür ama yeniden çözümlemede sorun çıkabilir.
- Çoklu worker üretim ortamında `_apply_runtime_migrations` yarış koşulu yaratabilir —
  ileride Alembic'e taşınmalı.

## Hızlı erişim eylemleri (ürün satırı/kart)

Her stok ürününün satır/kart sonunda 5 hızlı buton bulunur:

1. **Hızlı Sat** (yeşil) — modal açar: adet seçimi (max=stok), opsiyonel müşteri adı, canlı toplam tutar.
   Onaylanınca `POST /products/{id}/quick-sell` çağrılır → stok düşer + `Transaction(transaction_type='satış')` oluşur (tutar = price×qty, currency = ürün satış para birimi). Bu sayede kasa defterinde "Satılmış" rozeti ile listelenir; gelişmiş raporda "Aylık Toplam Satış" metriğine eklenir, "Bekleyen Tahsilat" hesabını şişirmez.
2. **+1 Stok** (mavi) — `POST /products/{id}/adjust-stock` `delta=+1`.
3. **−1 Stok** (amber) — aynı endpoint `delta=-1`; sıfırın altına inemez.
4. **Düzenle** / **Sil** — mevcut akış.

**Yarış koşulu güvenliği:** Her iki endpoint **atomik UPDATE** kullanır
(`UPDATE … WHERE quantity >= :qty / WHERE quantity + :delta >= 0 RETURNING …`).
PostgreSQL satır seviyesi kilidi sayesinde aynı ürüne paralel quick-sell isteklerinde
**oversell mümkün değildir** — yetersiz stok olan istekler 400 ile reddedilir.
Stress testi (5 stok, 20 paralel istek): 5 başarılı + 15 reddedildi, final stok 0 ✅.

Buton render yetkisi: `(p.canEdit || p.allowedModules === 'all')` — readonly kullanıcılar görmez.

## Test edilmiş izolasyon senaryoları

1. Bayi A ve Bayi B kayıt → her biri kendi ürün listesini görür ✅
2. Bayi B, A'nın ürün ID'sini doğrudan ister → 404 ✅
3. Aynı barkodu A ve B aynı anda ekler → ikisi de başarılı (per-tenant) ✅
4. B, A'nın ürününe dosya yüklemeye çalışır → 404 ✅
5. Token'sız dosya indirme → 401 ✅
6. Path traversal (`../etc/passwd`) → 400 ✅

## Çoklu kategori (multi-category) ve kategori filtresi

**Backend:**
- `Product.extra_categories: JSONB NOT NULL DEFAULT '[]'` — bir ürünün ek olarak göründüğü kategoriler.
- POST/PUT `/products`: `extra_categories: List[str]` kabul eder; backend strip + dedup yapar ve **ana `category` ile çakışan değerleri eler** (aynı kategori iki kez sayılmasın).
- GET `/products?category=X` filtresi `or_(func.lower(Product.category) == X.lower(), Product.extra_categories.contains([X]))` — ana kategori case-insensitive **tam eşleşme** (substring yanılgısı yok), ek kategori için JSONB contains. Bir ürün ana kategorisi ya da ek kategorilerinden biriyle eşleşirse listelenir.
- POST/PUT'ta dedup **case-insensitive**'tir (Türkçe'de "Cam"/"cam" aynı kabul edilir). PUT'ta yalnızca `category` değişirse, mevcut `extra_categories` da yeniden temizlenir; yeni ana kategoriyle çakışan ekstralar otomatik atılır.
- Runtime migration: `main.py` içinde `ALTER TABLE products ADD COLUMN IF NOT EXISTS extra_categories JSONB NOT NULL DEFAULT '[]'::jsonb` + GIN index `ix_products_extra_categories`.

**Frontend (GenericModuleView):**
- Üst arama satırına **Kategori dropdown**'ı eklendi (`<select>` + FolderTree ikonu). Seçim, modül kategorisinin alt kümesinde gösterilen ürünleri ana+ek kategoriye göre filtreler.
- `categoryOptions` listesi `GET /products/distinct-categories` endpoint'inden alınan **tüm kullanıcı kategorilerinin** (ana + ek, tüm modüller dahil) birleşimi + mevcut modülün rawData'sından gelen kategorilerin union'ıdır. Bu sayede başka bir modüldeki ürüne ek kategori eklendiğinde bile dropdown'da hemen gözükür.
- Yeni endpoint: `GET /products/distinct-categories` → `{ items: string[] }`. Modül değişiminde ve ürün create/update sonrası refresh edilir.
- Modül değişiminde `categoryFilter` ve `subcategoryFilter` sıfırlanır.
- Ürün ekleme/düzenleme modal'ında **Ek Kategoriler** chip-input alanı (Enter/virgülle ekleme, Backspace ile silme, datalist önerileri).
- Kart ve tablo görünümünde ek kategoriler **amber chip** olarak (alt-etiket olan indigo'dan ayırt edici) gösterilir; kartta en fazla 3, fazlası `+N`.

**Kullanım senaryosu:** Bir ürünün hem "Cam Rüzgarlığı" (ana) hem "Yedek Parça" (ek) menüsünde aynı anda görünmesi için ek kategoriye "Yedek Parça" yazılır. İlgili modülün DB sorgusu (`category=Yedek Parça`) ürünü `extra_categories @> '["Yedek Parça"]'` koşuluyla yakalar.

## Sıralama modu (modül başına `sortMode`)

Her modül cfg'sinde `sortMode: 'name_asc' | 'date_desc'` alanı vardır.
- `name_asc` — `title` alanına göre Türkçe `localeCompare` (A→Z). Stok modüllerinin tümü, finans tarafında müşteri-bazlı modüller (`fin_veresiye`, `fin_garanti`).
- `date_desc` — `date` (transaction `created_at`) alanına göre yeniden eskiye, eşitlikte id desc. Kronolojik finans modülleri (`fin_kasa`, `fin_firma`, `fin_senet`, `fin_kredi`).

Dinamik kategoriler için (`buildModuleConfig`) `transaction_type ∈ {borç, garanti}` ise `name_asc`, aksi halde `date_desc` varsayılır. Stok kategorileri her zaman `name_asc`. Liste başlığında "Sıralama: A-Z" / "Sıralama: Yeniden eskiye" rozeti `sortMode`'a göre değişir.

## İşlem tipi etiketleri (`txTypeLabel` / `txTypeTone`)

`App.tsx` üst tarafında iki harita: `TX_TYPE_LABEL` (DB değerini Türkçe insancıl etikete: `satış→Satılmış`, `ödeme→Tahsilat`, `gider→Gider` …) ve `TX_TYPE_TONE` (her tipe Tailwind renk sınıfları: satış emerald, borç red, ödeme blue, gider amber, senet indigo, kredi purple, garanti teal). Liste/kart ve drill-down modal aynı haritaları kullanır — yeni tip eklerken iki yere de ekleyin.

## Detaylı finans raporu (drill-down)

- **Endpoint:** `GET /api/v1/dashboard/finance-breakdown?period=today|week|month|year|all` —
  her transaction tipi (`satış`, `borç`, `ödeme`, `gider`, `senet`, `kredi`, `garanti`)
  için `{total, count, types}` döner; `outstanding_debt = borç_total − ödeme_total`.
  `period=today` günün başlangıcından itibaren, diğerleri `now − N gün`.
- **Frontend:** `ReportsDashboardView` üst sağda dönem seçici (Bugün/Bu Hafta/Bu Ay/Bu Yıl).
  7 tıklanabilir `MetricCard` her tipi gösterir; tıklanınca `TxDetailModal` açılır.
- **Period parite:** `TxDetailModal` `breakdown.start_date` (ISO) prop'unu alır ve
  `GET /finance/transactions?transaction_type=…&start_date=…&page_size=1000` ile çağırır
  (yoksa `days` fallback). `/finance/transactions` artık opsiyonel `start_date` query parametresini
  kabul eder ve verilmişse `days`'i geçersiz kılar — böylece "Bugün" KPI'sı (start-of-day)
  ile modal listesi birebir aynı kesiti gösterir. Sıralama yeniden eskiye, toplam tutar başlıkta.
  Birden fazla tip alias'ı (örn ['satış','sale']) için `id` set'i ile dedup yapılır.
- Üst özet 4 kart (Açık Müşteri Borcu — gradient indigo, Tahmini Kar, Müşteri Sayısı, Kritik Stok) tıklanabilir değildir; sadece KPI özet.

## Cari (müşteri) özet listesi — Veresiye / Firma / Senet / Kredi

Bu 4 finans modülü `MODULE_CONFIG.grouped: true` ile **cari özet** moduna çekildi: her satır = 1 müşteri/firma (ad bazında group-by), tek tek hareket satırları gizli — detay için `Yönet` butonu mevcut `CariDetailView` modalını açar.

- **Backend (`finance.py`):**
  - `GET /finance/customers/summary?transaction_type=borç|gider|senet|kredi`
    → `{ items: [{name, currency, first_at, last_at, txn_count, total_debt, total_paid, balance}] }` (balance = debt − paid; negatif = alacak/iade fazlası). `txn_count` sadece `amount > 0` olan satırları sayar (açılış kayıtları dahil değil).
  - `POST /finance/customers` `{customer_name, transaction_type, currency, notes?}` → amount=0 "açılış" kaydı atar (cariyi listeye sokar). `TransactionCreateRequest.amount` validation `gt=0` → `ge=0`.
  - `PUT /finance/customers/rename` `{old_name, new_name, transaction_type, currency?}` → tüm satırları yeniden adlandırır + opsiyonel currency günceller.
  - `DELETE /finance/customers/{name}?transaction_type=...` → o cariye ait tüm hareketleri siler.
  - `_resolve_type_group(transaction_type)` helper: alias listesi (`borç`/`debt`, `gider`/`expense`, `senet`, `kredi`/`loan`).
  - `GET /finance/transactions` artık `ledger_type` ve `exact_customer` query parametrelerini destekler:
    `ledger_type` debt+payment_types grubunu (örn. `borç` → `[borç, debt, ödeme, payment]`) `IN` filter eder; `exact_customer=true` ise `customer_name` tam eşleşme. CariDetailView böylece doğru modülün geçmişini izole çekiyor.

- **Frontend (`App.tsx`):**
  - `ModuleConfig.grouped?: boolean` — `fin_veresiye`, `fin_firma`, `fin_senet`, `fin_kredi` true; `fin_kasa` ve `fin_garanti` aynı (per-tx satır görünümü).
  - `GenericModuleView.fetchData` grouped branch: summary endpoint'inden çekip `{id:"cari:<name>", title, balance, totalDebt, totalPaid, txnCount, firstAt, currency, ledgerType: cfg.transactionType}` map'ler.
  - `handleSave` grouped: yeni → POST customers; düzenle (sadece ad) → PUT rename. `handleDelete` grouped: DELETE customers/{name}.
  - Modal: grouped iken İşlem Türü ve Tutar alanları gizli (sadece ad + currency + not). Form başlığı "Yeni Cari / Cari Düzenle".
  - Tablo: header "İlk Kayıt" + "Toplam Borç"; rozet `<txnCount> hareket` (indigo); balance negatif ise yeşil "Alacak", 0 ise "Kapalı".
  - `CariDetailView` `cari.ledgerType` taşır:
    - `loadCariTx` → `GET /finance/transactions?ledger_type=...&exact_customer=true` (modüller arası karışmayı engeller).
    - `handleCariTxSave` → "Borçlandır" düğmesinde `transaction_type` olarak `cari.ledgerType` (gider/borç/senet/kredi) kullanır; "Tahsilat" hep `ödeme`. Para birimi `cari.currency`'den taşınır.

## Süper Yönetici Paneli (Platform Sahibi)

- **Otomatik atama:** `SUPER_ADMIN_EMAILS` env (default `beratbayramkivrak@stokfinans.com`).
  - **Kayıt sırasında anlık** atama: `app/api/auth.py` register handler'ı `main.is_email_super_admin(email)` çağırarak `User.is_super_admin=True` set eder.
  - **Startup bootstrap (geriye dönük):** `main._bootstrap_super_admins()` whitelist'teki tüm mevcut hesapları flag'ler.
- **Backend:**
  - `User.is_super_admin Column(Boolean, default=False, index=True)` + `_apply_runtime_migrations` ALTER+index.
  - `app/utils/auth.get_current_super_admin` dependency.
  - `app/api/auth.login` süper admin için `sub_days <= 0` bypass eder.
  - `app/api/superadmin.py` router (`/api/v1/superadmin/*`):
    - `GET /stats` — platform sayıları (kullanıcı/bayi/çalışan/aktif/expired/expiring/ürün/işlem/kategori/30g yeni).
    - `GET /users` — sayfalı, search/role/status filtre, sort.
    - `GET /users/{id}`, `PATCH /users/{id}` (full_name/role/is_active/sub_days/is_super_admin; self-protection), `DELETE /users/{id}` (cascade tüm verileri).
    - `POST /users/{id}/subscription/adjust` — **atomik SQL** `GREATEST(0, sub_days+:delta)` (race-safe).
    - `POST /users/{id}/reset-password` — rastgele 12 char üretir, response'ta 1 kez döner.
    - `GET /users/{id}/{products|transactions|logs}`, `GET /logs` (cross-tenant inceleme).
    - **Referans takibi:** `GET /referrals/summary` (her referrer için invited_count + last_invited_at, search), `GET /referrals/pairs` (kim → kimi davet etti çiftleri, search), `GET /users/{id}/invited` (bir kullanıcının davet ettiği tüm kişiler).
- **Referans modeli:**
  - `User.referred_by_user_id Column(Integer, nullable=True, index=True)` — `_apply_runtime_migrations` ALTER+index ile eklenir.
  - `auth.register` handler'ı geçerli `ref_code` bulduğunda `referred_by_user_id=referrer.id` set eder; geçmiş kayıtlarda NULL kalır (backfill yok).
  - `SuperUserSummary` ek alanlar: `referred_by_user_id`, `referred_by_email`, `referred_by_name`, `invited_count`.
- **Frontend (`SuperAdminPanel.tsx`):**
  - `App.tsx` → 3 setCurrentUser yerinde `isSuperAdmin: !!user.is_super_admin`; renderView başında `if (currentUser.isSuperAdmin) return <SuperAdminPanel />` ile normal dashboard'u atlar.
  - Üst sekmeler: **Kullanıcılar**, **Referans Kodu Yönetimi**, **Abonelikler** (`mainTab` state).
  - Kullanıcılar: Header gradient + 6 stats kartı + filtreli kullanıcı tablosu + drawer (overview/subevents/invited/products/transactions/logs). Drawer overview'da "Kim davet etti?" ve "Kaç kişi davet etti?" kartları + "Davet Ettikleri" sekmesinde alt liste; "Abonelik Geçmişi" sekmesinde kullanıcıya özel SubEventRow listesi.
  - Referans Kodu Yönetimi: 3 stats (toplam davetli, aktif davet eden, en çok davet eden) + 2 alt sekme (**Davet Edenler** liderboard tablosu, **Tüm Hareketler** çift tablosu). Search debounce'lu, satıra tıklayınca ilgili kullanıcının drawer'ı açılır (`openUserById` helper).
  - Abonelikler: 4 stats (eklenen gün, düşen gün, etkilenen bayi, en çok süre kazanan), tip kırılımı chip grid'i (filtre olarak da çalışır), zaman penceresi (7/30/90/365 gün), event_type select, "sadece artışlar" toggle, search debounce. Liste her satırda `SubEventRow` (event_label, ±gün, before→after, actor/related kullanıcılar, not, tarih).
  - Aksiyonlar: ±gün (1/7/30/90/365), tam değer, aktif/pasif, süper admin yetkisi, şifre sıfırla (modal'da göster + kopyala), kullanıcıyı sil (EVET prompt). Kendi hesabını silme/pasifleştirme/yetki kaldırma backend+frontend'de yasak.
  - **Yeni sekmeler (paket abonelik sistemi):**
    - **Paketler** — `GET/PATCH /superadmin/packages` ile 3 paketi (starter/pro/premium) düzenler: ad, açıklama, fiyat (₺), süre (gün), max ürün, max finans, sınırsız bayrakları, aktif. Frontend `PackagesView` sadece dirty alanları PATCH gönderir.
    - **Ödemeler** — `GET /superadmin/payments?status=&page=` (PaymentsView). 4 özet kartı (toplam, başarılı, başarısız, tahsilat ₺), durum filtresi, sayfalama, satıra tıklama drawer açar.
    - **PayTR Ayarları** — `GET/PUT /superadmin/paytr` (PaytrSettingsView). Merchant ID + key + salt + test_mode. Key/Salt response'ta sadece masked döner; PUT'ta boş bırakılırsa mevcut değer korunur.
- **Abonelik geçmişi (`SubscriptionEvent`):**
  - Model: `subscription_events` (id, user_id, event_type, days_delta, days_before, days_after, actor_user_id, related_user_id, note, created_at). `_apply_runtime_migrations` CREATE TABLE + 5 index (user/created/type/actor/related).
  - Event tipleri: `initial` (kayıtta 14g), `referral_bonus_received` (yeni davetli), `referral_bonus_given` (davet eden), `admin_set` (full_user update), `admin_adjust` (±gün adjust). Sadece yeni hareketler kaydedilir; eski kullanıcılar için backfill yok.
  - Endpoints: `GET /superadmin/subscription/stats?days=N` (toplam ekleme/düşme/distinct/top_user/by_type), `GET /superadmin/subscription/events` (search/event_type/days/only_positive/sayfalı), `GET /superadmin/users/{id}/subscription/events` (kullanıcı detayı). Yanıt schema: user/actor/related için id+full_name+email+company hidrasyonlu.

## Paket abonelik & PayTR ödeme sistemi (bayi)

**3 paket:** Başlangıç (`starter`, 500₺/30g/500ürün/1000finans), Orta (`pro`, 1000₺/30g/1000ürün/sınırsız finans), Premium (`premium`, 2000₺/30g/50000ürün/sınırsız+destek). Hepsi 30 gün, günlük gün düşüşü, paket bazlı kota enforcement, abonelik bitince UI redirect.

- **Modeller:**
  - `app/models/package.py` `Package` (slug, name, description, price_try, duration_days, max_products[+_unlimited], max_transactions[+_unlimited], features JSONB, is_active, is_featured, color_class). `main.py` startup'ta 3 paket idempotent SEED.
  - `app/models/payment.py` `Payment` (user_id, package_slug, amount_try, paytr_merchant_oid uniq, status[pending/success/failed], days_added, test_mode, error_message, raw_callback JSONB, created_at/completed_at).
  - `app/models/paytr_setting.py` `PaytrSetting` (id=1 tek satır: merchant_id, merchant_key, merchant_salt, test_mode, is_configured).
  - `User` migration: `sub_expires_at TIMESTAMPTZ`, `package_slug VARCHAR(32) DEFAULT 'starter'`. Eski `sub_days` kolonu hesaplama için artık kullanılmıyor; `compute_days_remaining(expires_at)` döner.
- **Backend services:**
  - `app/services/subscription.py`: `compute_days_remaining`, `extend_subscription(user, days)` (mevcut süreden uzatır — erken yenilemede +30 üzerine eklenir, expired ise NOW+days), `set_subscription_days`, `get_quota_usage(user)`, `check_quota(user, kind)`. Quota check `app/api/products.py` POST + `app/api/finance.py` POST'ta 402 (Payment Required) atar.
  - `app/services/paytr.py`: `init_payment(payment, user, host)` urllib.request stdlib (requests/httpx YOK) ile PayTR get-token endpoint'i çağırır, iframe URL döner. `user_basket` `json.dumps` ile serialize edilir (PayTR JSON list bekler). `verify_callback(post)` `hmac.compare_digest` ile hash doğrular.
- **GLOBAL ABONELİK GUARD MIDDLEWARE (`backend/main.py` `subscription_guard_middleware`):**
  - Süresi dolmuş bayi için backend tarafında zorunlu enforcement; UI guard tek başına yeterli değil.
  - Whitelist edilen prefix'ler (her zaman erişilebilir): `/api/v1/auth/`, `/api/v1/subscription/`, `/api/v1/superadmin/`, `/api/v1/files/`. Diğer tüm `/api/v1/*` endpoint'leri JWT decode → DB'den `User.sub_expires_at` kontrolü → expired ise **HTTP 402** + `{"detail":"...", "code":"subscription_expired"}` döner.
  - Süper admin her zaman bypass; OPTIONS (CORS preflight) bypass; token yoksa router auth dependency'sine bırakılır (401 dönecek).
- **Backend API (`app/api/subscription.py`, `/api/v1/subscription/*`):**
  - `GET /packages` — aktif paketler (auth gerek yok da değil — current_user gerekli).
  - `GET /me` — paket bilgisi + days_remaining + products_used/limit/unlimited + transactions_used/limit/unlimited.
  - `POST /checkout {package_slug}` — Payment(pending) yarat, PayTR init, `{merchant_oid, iframe_url, test_mode}` döner. `merchant_oid = SF{ts}U{uid}{SLUG}{uuid4[:8]}` — uuid suffix sayesinde aynı kullanıcı saniye içinde çoklu checkout açsa bile unique constraint çakışmaz.
  - `POST /paytr/callback` (Form, public IPN) — PayTR'dan gelen webhook. Hash verify + **tutar doğrulama** (`total_amount` (kuruş) == `payment.amount_try * 100`; uyumsuzsa "failed" işaretler) + payment.status=success → `extend_subscription`, `package_slug` set, `package_changed` SubscriptionEvent. Yanıt **`OK`** plaintext zorunlu.
  - `GET /payments/me`, `GET /payments/{merchant_oid}` — bayi geçmişi + tek ödemenin status polling'i.
- **Frontend:**
  - `App.tsx` — login/auto-login sonrası `useEffect` ile `/subscription/me` çağırır, `currentUser.subDays/packageSlug/packageName` set eder. **Süresi dolan kullanıcı (`subDays<=0`) için renderView başında zorunlu redirect** — sadece `SubscriptionView expired={true}` görünür, başka view'a gidilemez.
  - `SubscriptionView` (App.tsx ~1766): paket karşılaştırma kartları (3'lü grid), 2 quota progress bar (ürün/finans, sınırsız ise ∞), ödeme geçmişi listesi, davet bölümü. "Bu Paketi Seç" → `POST /checkout` → iframe modal (700px). Modal açıkken her **3 sn'de bir** `/payments/{oid}` polling; success → toast + `refreshSubscription()` + modal kapan; failed → error toast.
  - `SuperAdminPanel.tsx`: 3 yeni sekme — `PackagesView` (paket fiyat/kota düzenle), `PaymentsView` (4 stats + sayfalı tablo), `PaytrSettingsView` (merchant_id/key/salt/test_mode; key&salt sadece dolu girildiğinde update — masked'ler `merchant_key_masked` truthy ise "Tanımlı: ****1234" şeklinde gösterilir).

## E-posta Doğrulama & SMTP Sistemi

- **Modeller:**
  - `app/models/smtp_setting.py` `SmtpSetting` (id=1 tek satır: host/port/username/password/from_email/from_name/use_tls/use_ssl/is_configured).
  - `app/models/register_notice.py` `RegisterNotice` (id=1 tek satır: is_enabled/title/message/color/updated_at).
  - `users` tablosuna 3 yeni kolon: `is_email_verified BOOL DEFAULT TRUE`, `email_verification_token VARCHAR(128)`, `token_expires_at TIMESTAMPTZ`.
- **Email servisi (`app/services/email.py`):**
  - `get_smtp_settings(db)` — SmtpSetting id=1'i döner, is_configured=False ise None.
  - `generate_verification_token()` — 32 byte urlsafe token.
  - `get_token_expiry()` — now + 24 saat.
  - `send_verification_email(db, to, token, name, base_url)` — HTML+plain MIME, TLS/SSL destek. URL: `{base_url}/?action=verify&token={token}`.
  - `send_password_reset_email(db, to, token, name, base_url)` — Şifre sıfırlama maili. URL: `{base_url}/?action=reset-password&token={token}`. Token 1 saat geçerli.
  - `test_smtp_connection(host, port, user, pwd, use_tls, use_ssl)` — (bool, msg) döner.
- **Auth endpoint'leri (yeni):**
  - `GET /auth/register-notice` (public) — is_enabled/title/message/color döner.
  - `POST /auth/verify-email?token=` (public) — token'ı doğrular, is_email_verified=True, access/refresh token döner.
  - `POST /auth/resend-verification` (JWT, get_current_user_unverified) — yeni token üretir, mail gönderir.
  - `POST /auth/resend-verification-public` (public) — e-posta alır, yeni doğrulama maili gönderir (enumeration koruması: email bulunsun/bulunmasın aynı yanıt).
  - `POST /auth/forgot-password` (public) — e-posta alır, şifre sıfırlama token üretir, mail gönderir. SMTP yapılandırılmamışsa 503. users.password_reset_token + password_reset_expires_at.
  - `POST /auth/reset-password` (public) — { token, new_password } alır, token 1 saat geçerli, users.password_hash günceller.
  - **Login:** doğrulanmamış kullanıcı → HTTP 403 + { code: "email_not_verified", email }.
  - **Register:** SMTP aktifse is_email_verified=False, token+mail+email_verification_required döner.
  - **get_current_user:** SMTP aktif ve is_email_verified=False ise → 403. Süper adminler muaf. Hata loglanır, smtp=None olur.
  - **get_current_user_unverified:** Doğrulama kontrolü yapmaz. resend/profile/logout endpoint'lerinde kullanılır.
- **Superadmin endpoint'leri (yeni):**
  - `GET/PUT /superadmin/smtp` — SMTP yapılandırması; şifre masked döner, boş bırakılırsa korunur.
  - `POST /superadmin/smtp/test` — canlı SMTP bağlantı testi.
  - `GET/PUT /superadmin/register-notice` — kayıt sayfası duyuru kutusu.
  - `GET/PUT /superadmin/terms` — site şartları (is_enabled, content).
  - `GET /auth/terms` (public whitelist) — kayıt formunda şartları çekmek için.
- **Model:** `app/models/terms_setting.py` `TermsSetting` (id=1 tek satır: is_enabled bool, content TEXT, updated_at).
- **Frontend:**
  - `App.tsx` `AuthPage`: Giriş formunda **"Şifremi Unuttum"** linki (şifre alanı sağında). Tıklayınca `forgotStep='email-form'` ekranı açılır → POST /auth/forgot-password → 'sent' ekranı. E-postadaki link `?action=reset-password&token=...` ile gelir → 'reset-form' (yeni şifre + tekrar) → POST /auth/reset-password → 'reset-success' veya 'reset-error'. `checkAuth` üst seviyede reset-password URL aksiyonunu da algılar.
  - `App.tsx` `AuthPage`: kayıt sayfasında `/auth/register-notice` duyuru kutusu, doğrulama bekleme ekranı, URL `?action=verify&token=` ile otomatik doğrulama.
  - `App.tsx` `AuthPage` (kayıt formu): `termsBox` state'i ile `/auth/terms` çekilir; `is_enabled=true` ise "Kullanım Şartları ve Gizlilik Politikası" linkli checkbox gösterilir. Checkbox işaretlenmeden submit butonu devre dışı. Link tıklandığında tam metni gösteren modal açılır; modal içindeki "Okudum, Onaylıyorum" butonu checkbox'ı da işaretler.
  - `SuperAdminPanel.tsx`: **"E-posta Ayarları"** sekmesi (SMTP + Kayıt Bildirimi + **Site Şartları** alt sekmeleri). Site Şartları sekmesi: is_enabled toggle + content textarea + önizleme + kaydet.


## Bayi Yedekleme Sistemi (Faz 1)

- **Amaç:** Bayi (kiracı) tüm verisini şifreli tek dosya olarak indirebilir/yükleyebilir; şifreyi yalnızca süperadmin görür.
- **Model:** `app/models/bayi_backup.py` `BayiBackup` (id UUID str, user_id FK→users, filename, password_encrypted (Fernet at rest, `app/utils/crypto.py` `encrypt_secret`/`decrypt_secret`), size_bytes, created_at, restored_at nullable). `models/__init__.py`'da export. `backend/main.py`'de migration tablo oluşturur (`bayi_backups`).
- **Servis (`app/services/backup_service.py`):**
  - `create_backup(db, user)` → tenant ownership: `_tenant_owner_id(user) = parent_user_id if calisan else id`. Toplanan tablolar: products, transactions, categories, activity_logs, payments, subscription_events, employee_invites, child employees, owner. JSON serialize (datetime/UUID güvenli) + `uploads/` altındaki referanslı görseller (Product.image_url, Transaction.image_url) ZIP içine `files/` ile kopyalanır. Random `Fernet.generate_key()` ile inner ZIP şifrelenir.
  - **Dosya formatı:** `{json header: backup_id, version}\n` + Fernet token bytes. Uzantı: `.sfb`. Konum: `backend/backups/{uuid}.sfb`.
  - `restore_backup(db, user, file_bytes)` → header'dan backup_id parse, DB'den BayiBackup lookup (must belong to user), şifre decrypt, Fernet decrypt → ZIP aç → DELETE existing tenant rows → JSON'dan bulk insert (id'leri korur, foreign key sırası: categories→products, then others). Owner satırı update (id/email/password_hash/is_super_admin/created_at hariç). Children employees re-create. Files restore: `uploads/` altına yazılır. `restored_at` güncellenir.
  - `read_backup_file(backup_id)` / `delete_backup_file(backup_id)` — diskten oku/sil.
- **Backend endpoint'leri (`app/api/backup.py`, `/api/v1/backup/*`):**
  - `POST /backup/create` — yedek oluştur, metadata döner (şifre yok).
  - `GET /backup/list` — kullanıcının yedekleri.
  - `GET /backup/download/{backup_id}` — `.sfb` dosyası indir (sahibi olmalı).
  - `DELETE /backup/{backup_id}` — yedek sil (DB + dosya).
  - `POST /backup/restore` (multipart `file`) — geri yükle. Response: `{tables: {table: count}, files_restored: int}`.
- **Süperadmin endpoint'leri (`app/api/superadmin.py`):**
  - `GET /superadmin/backups` → tüm yedekler + decrypt edilmiş plaintext şifre + bayi info (`user_email`, `company_name`).
  - `GET /superadmin/backups/{backup_id}/download` — herhangi bir bayinin yedeğini indir.
  - `DELETE /superadmin/backups/{backup_id}` — yedek sil.
- **Frontend:**
  - `App.tsx` `BackupView` (~L2475): bayi panelinde "Yedekleme" navigasyon öğesi (Database icon, isPatron only). Bilgi kartı + "Yeni Yedek Oluştur ve İndir" butonu (otomatik download tetikler) + "Yedek Yükle (.sfb)" file input + yedek geçmişi listesi (indir/sil). Geri yükleme onay diyaloğu kırmızı uyarı ile (mevcut veriler silinecek). Şifre **bayi UI'ında hiçbir yerde gösterilmez**.
  - `SuperAdminPanel.tsx` `BayiBackupsView` (~L2061): yeni "Bayi Yedekleri" sekmesi (HardDrive icon). Tablo: bayi (company_name + email), dosya adı, tarih, boyut, **ŞİFRE** (göster/gizle toggle + kopyala butonu), indir/sil. Arama filtresi. Restored_at varsa yeşil etiket.
- **Faz 2 (TAMAMLANDI):** Süperadmin için (1) çoklu FTP/SFTP sunucu yönetimi + bayi yedeklerini elle uzak sunucuya yükle/listele/sil, (2) iki StokFinans kurulumu arasında ana↔ayna eşleşmesi. Detaylar aşağıda.

## Süperadmin Çoklu FTP/SFTP Yönetimi (Faz 2)

- **Bağımlılıklar:** `paramiko` (SFTP — SSH üzerinden), `apscheduler` (sync için), `httpx` (peer HTTP). `backend/requirements.txt`'ye eklendi.
- **Model:** `app/models/ftp_server.py` `FtpServer` (id, name, type 'ftp'|'sftp', host, port, username, password_encrypted Fernet, base_path, is_active, created_at, updated_at). `models/__init__.py`'da export. `backend/main.py` migration `ftp_servers` tablosunu oluşturur.
- **Servis (`app/services/ftp_service.py`):** Tek arayüz iki protokolü kapsar.
  - FTP: `ftplib.FTP` context manager, MLSD listele (yoksa NLST'e düş), STOR/RETR/DELE.
  - SFTP: `paramiko.Transport` + `paramiko.SFTPClient` context manager, listdir_attr/file/remove.
  - Yardımcılar: `_ftp_ensure_path` / `_sftp_ensure_path` (derin klasör oluştur), `safe_subdir_for_user` (bayi başına alt klasör adı = company_name veya email@öncesi → alphanumerik).
  - Genel API: `test_connection`, `upload_file(server, bytes, remote_path)`, `download_file`, `list_files(sub_path)`, `delete_file`.
- **Endpoint'ler (`app/api/superadmin.py` sonuna append, hepsi `get_current_super_admin` ile korumalı):**
  - `GET/POST/PUT/DELETE /superadmin/ftp-servers` — CRUD (şifre güncellemede boş bırakılırsa korunur).
  - `POST /superadmin/ftp-servers/{id}/test` → `{ok, message}`.
  - `GET /superadmin/ftp-servers/{id}/files?sub_path=` → `{sub_path, items: [{name, path, is_dir, size}]}`.
  - `DELETE /superadmin/ftp-servers/{id}/files?path=` — uzak dosyayı sil.
  - `POST /superadmin/backups/{backup_id}/upload-ftp/{server_id}` — yerel `.sfb` yedeğini `<base_path>/<safe_subdir>/<filename>` yoluna yükler. Bayinin alt klasörü `safe_subdir_for_user` ile.
  - `POST /superadmin/ftp-servers/{id}/import?path=...` — uzak `.sfb` indirir; aynı backup_id zaten varsa diske üzerine yazar; yoksa bilinmeyen şifre nedeniyle 409 döner ("Sync ile bütün veritabanını senkronize edin").
- **Frontend (`SuperAdminPanel.tsx`):**
  - **Yeni "FTP/SFTP Sunucuları" sekmesi** (`Server` icon): tablo (ad, tür, host:port, kullanıcı, base_path, durum) + per-row eylemler: bağlantıyı test, dosyaları görüntüle (modal browser — klasör navigasyon, üst klasör, sil), düzenle, sil. `FtpServerForm` modal: ad/tür/port/host/kullanıcı/şifre/base_path/aktif (tür değişince port default güncellenir).
  - **`BayiBackupsView` per-row "FTP'ye Yükle" butonu** (Upload icon, emerald): modal aktif sunucuları listeler, seçilince `POST upload-ftp` çağrılır. Aktif sunucu yoksa uyarı çıkar.

## Ana↔Ayna Sunucu Eşleşmesi (Faz 2)

- **Tasarım:**
  - İki StokFinans kurulumu birbirini yedekler. Tek satır SyncPeer (id=1) her node'da yerel.
  - Her node bir `our_token` (rastgele) üretir; admin out-of-band karşı tarafa iletir. Her iki taraf da peer'in token'ını `peer_token_encrypted` (Fernet at-rest) saklar.
  - Snapshot = ZIP içerir: `data.json` (tüm tablolar, super admin user'lar HARİÇ) + `uploads/*` (ürün/işlem görselleri) + `backups/*.sfb` (bayi yedek dosyaları).
  - Mirror her 5 dk'da bir primary'den otomatik pull (APScheduler). Heartbeat her 60sn.
  - Recovery: süperadmin elle "Karşıdan Çek (Pull)" / "Karşıya Gönder (Push)" butonlarıyla snapshot taşır.
- **Model:** `app/models/sync_peer.py` `SyncPeer` (id=1 tek satır, role 'primary'|'mirror', peer_url, peer_token_encrypted Fernet, our_token (plaintext lookup index), last_heartbeat_at, last_sync_at, last_error, is_active). Migration `sync_peer` tablosu + `ix_sync_peer_our_token` index `backend/main.py`'de.
- **Servis (`app/services/sync_service.py`):**
  - `SYNC_TABLES` listesi (FK-safe import sırası): packages → smtp/notice/terms/paytr/ftp_servers → users (super admin hariç) → employee_invites → categories → products → transactions → activity_logs → subscription_events → payments → bayi_backups.
  - `export_full_snapshot(db)` → ZIP bytes (data.json + uploads/* + backups/*.sfb).
  - `import_full_snapshot(db, zip_bytes)` → super admin user(s) korunur; geri kalanlar reverse order TRUNCATE + forward order INSERT (id'leri korur). PostgreSQL sequence'leri `setval(..., max(id)+1, false)` ile ayarlanır. uploads/ ve backups/ dosyaları diske yazılır.
  - HTTP: `heartbeat(peer)` → `POST /sync/ping`. `pull_from_peer(db, peer)` → `GET /sync/snapshot` indir + import. `push_to_peer(db, peer)` → kendi snapshot'ını `POST /sync/import`'a gönderir.
  - `verify_peer_token(db, auth_header)` → `Authorization: Bearer <token>` doğrular (token == sync_peer.our_token).
- **Scheduler (`app/services/sync_scheduler.py`):** APScheduler `BackgroundScheduler` (UTC, daemon). İki job: `_heartbeat_job` (60sn, peer'a ping, başarısızsa last_error günceller), `_mirror_pull_job` (5dk, sadece role='mirror' iken çalışır, peer'dan snapshot pull eder). `start_scheduler()` startup'tan, `stop_scheduler()` shutdown'tan.
- **Endpoint'ler (`app/api/sync.py`, iki router):**
  - **Public peer-auth (`/api/v1/sync/*`, Bearer our_token):**
    - `POST /sync/ping` → `{ok, role, ts}`, last_heartbeat_at güncellenir.
    - `GET /sync/snapshot` → ZIP bytes.
    - `POST /sync/import` → ZIP body, import et.
  - **Süperadmin (`/api/v1/superadmin/sync/*`, JWT super admin):**
    - `GET /superadmin/sync/status` → `{paired, role, peer_url, our_token, has_peer_token, is_active, last_heartbeat_at, last_sync_at, last_error}`.
    - `POST /superadmin/sync/pair` `{peer_url, peer_token, role}` → upsert.
    - `DELETE /superadmin/sync` → eşleşmeyi temizle (token'lar sıfırlanır).
    - `POST /superadmin/sync/test` → ping çek.
    - `POST /superadmin/sync/pull-now` → manuel pull.
    - `POST /superadmin/sync/push-now` → manuel push.
    - `POST /superadmin/sync/regenerate-token` → our_token yenile (eşleşme bozulur, karşı tarafa yeni token gerek).
- **Frontend (`SuperAdminPanel.tsx`):**
  - **Yeni "Sunucu Eşleşmesi" sekmesi** (`Network` icon): üst durum kartı + (mirror+paired iken) BÜYÜK durum şeridi: yeşil "Ana sunucu erişilebilir" / kırmızı "Ana sunucu erişilemiyor — bu sunucu aktif modda" (heartbeat<180sn ise yeşil). Detay kartı: rol (PRIMARY/MIRROR badge), eşleşme durumu, peer URL, son heartbeat, son sync, last_error. Yerel token: göster/gizle + kopyala + yenile butonu. Eylemler: Eşleştir, Bağlantıyı Test Et, Karşıdan Çek (Pull), Karşıya Gönder (Push) (onay), Eşleşmeyi Kaldır.
  - `SyncPairFormModal`: peer_url + peer_token + role select. Her iki tarafta ayrı doldurulması gerektiği bilgi kutusu.
  - 30 saniyede bir otomatik status refresh.
- **Güvenlik notları:** Super admin user'lar her node'un kendi başına yerel kalır (snapshot'a girmez, import'ta korunur). Bu sayede tek node'un super admin şifreleri diğerine sızmaz. Sync token'ları Fernet ile at-rest şifreli; our_token plaintext (peer auth lookup için index gerekir).
- **Mimari/güvenlik sertleştirmeleri (code review sonrası uygulandı):**
  - `import_full_snapshot` artık **tek transaction** içinde TRUNCATE+INSERT yapar (kısmi import yok); imported user ID local super admin ID ile çakışırsa **otomatik ID remap** + tüm FK referansları güncellenir (`USER_FK_TABLES`: products/transactions/categories/activity_logs/payments/bayi_backups → user_id; subscription_events → user_id+actor_user_id+related_user_id; employee_invites → parent_user_id+consumed_user_id; users self-FK → referred_by_user_id+parent_user_id).
  - `verify_peer_token`: `hmac.compare_digest` ile sabit-zaman karşılaştırma (timing attack koruması) + `is_active` & `peer_url` & `peer_token_encrypted` zorunlu kontrolü. `DELETE /superadmin/sync` artık **`our_token`'ı yeniler** — eski token'ı bilen taraf erişimi kaybeder.
  - `POST /sync/import` streaming + 2 GiB body cap ile DoS/OOM koruması (`SYNC_MAX_BODY_BYTES`).
  - FTP/SFTP context manager'ları connect/login hatasında socket/transport'u garantili kapatır (kaynak sızıntısı yok).
  - `POST /superadmin/sync/pair` artık `peer_token` opsiyonel: ilk eşleşmede zorunlu, sonradan URL/rol güncellemesi için boş bırakılabilir (mevcut token korunur). Frontend `SyncPairFormModal` da bu davranışı destekler.

## Süperadmin Tam Sistem Yedeği (Faz 2 — ek)

- **Amaç:** Süperadminin tek tıkla TÜM sistemin (super adminler dahil) yedeğini bilgisayarına indirmesi ve aynı yedeği başka bir StokFinans kuruluma yüklemesi.
- **Bayi yedeği (Faz 1) ile farkı:** Bayi yedeği yalnızca tek bir bayinin tenant verisini içerir, şifrelenmiş `.sfb` formatındadır. Sistem yedeği TÜM tabloların ham kopyasıdır (ZIP içinde JSON), şifrelenmez (süperadmin yetkili indirir/yükler).
- **Sync ile farkı:** Sync iki canlı kurulum arasında otomatik mirror akışı; sistem yedeği insan tarafından elle taşınan offline tek dosyadır.
- **Servis (`app/services/system_backup_service.py`):**
  - `export_system_snapshot(db)` → ZIP bytes. İçerir: `data.json` (sync_service'in `SYNC_TABLES` listesi — TÜM kullanıcılar dahil) + `uploads/*` + `backups/*.sfb`. `sync_peer` HARİÇ (peer config makineye özgü).
  - `import_system_snapshot(db, zip_bytes)` → tek transaction'da reverse-order DELETE + forward-order INSERT (id'ler korunur), sequence reset, dosyalar üzerine yazılır. Restore sonrası süperadmin sayısı 0 ise `stats.warning` döner (hata değil — admin kararı).
- **Endpoint'ler (`app/api/superadmin.py`):**
  - `POST /superadmin/system-backup/create` → ZIP indirme (`stokfinans-system-<TS>.zip`).
  - `POST /superadmin/system-backup/restore` (multipart `file`, .zip) → 2 GiB üst sınırı. `kind != "system"` ise 400.
- **Frontend (`SuperAdminPanel.tsx` `SystemBackupView`):** Yeni "Sistem Yedeği" sekmesi (`Archive` icon). İki kart: "Yedek Oluştur ve İndir" (büyük indigo buton) + "Yedek Yükle ve Geri Yükle" (rose buton, file input → onay modal'ı tüm risklerle birlikte). Restore sonrası tablo başına satır sayısı + uploads/backups dosya sayısı gösterilir.
- **Sertleştirmeler (code review sonrası):**
  - **Preflight validation:** restore başlamadan önce `data.json.kind == "system"`, `tables` dict ve TÜM beklenen tablo anahtarları (`SYNC_TABLES`) mevcut + her biri liste, **users içinde en az bir `is_super_admin=True` kayıt** olmalı (yoksa `SystemBackupValidationError` → 400). Bozuk ZIP/JSON da 400.
  - **Zip bomb / DoS koruması:** açılmış toplam boyut <= 5 GiB (`MAX_UNCOMPRESSED_SIZE`), dosya sayısı <= 200_000 (`MAX_FILE_COUNT`), her dosya için path traversal (`../`, mutlak yol) reddedilir.
  - **Atomik klasör swap:** uploads/ ve backups/ restore'da `_safe_replace_dir` kullanılır — yeni dizine yazılır, başarılıysa eski dizinle takas edilir. Yedekte olmayan eski dosyalar **silinir** ("tam restore" semantiği). Hata olursa eski dizin korunur.
  - **Süperadmin'siz kilitlenme önleme:** restore SQL transaction'ı içinde son kontrol — super admin sayısı 0 ise rollback + 400.

## Faz 3 — KDV, Garanti Belgesi, Borçlu Slip Linki

Bayi panelinde 3 yeni özellik. Tüm yeni endpoint'ler `data_owner_id(current_user)` ile multi-tenant izole; public endpoint'ler tek-yönlü token ile auth'suz erişilir.

### 1. KDV (Katma Değer Vergisi)

- **Şema:** `Transaction.kdv_rate Numeric(5,2) NOT NULL DEFAULT 0` (`backend/app/models/transaction.py`).
  Migration: `main.py` `_apply_runtime_migrations()` içinde `ALTER TABLE transactions ADD COLUMN IF NOT EXISTS kdv_rate NUMERIC(5,2) NOT NULL DEFAULT 0`.
- **Semantik:** `amount` her zaman **KDV DAHİL (gross)**. Net tutar `amount / (1 + kdv_rate/100)`, KDV `amount - net`. Frontend canlı breakdown gösterir (KDV hariç / KDV / KDV dahil) — geriye dönük uyumlu (eski kayıtlarda kdv_rate=0 → net=gross).
- **Backend:** `TransactionCreate/Update/Response` Pydantic schema'larına `kdv_rate: Decimal | None` eklendi. `finance.py` create + 4 response builder'da set edilir.
- **Frontend:** `App.tsx` `GenericModuleView` finans modal'ında preset butonları (%0/1/8/10/18/20) + Özel input + canlı 3-kutulu breakdown.

### 2. Garanti Belgesi

> **ÖNEMLİ — TEK DOĞRU YER:** Garanti yönetimi sadece bu modülde yapılır (sidebar: "Garanti Belgeleri"). Eski `fin_garanti` finans kategorisi (transaction_type='garanti', "Garanti Tutarı (₺)" alanlı) **kaldırıldı** — garantide tutar kavramı yoktur. Mevcut bayilerden boş `is_default=true` `fin_garanti` kategorileri `_apply_runtime_migrations()` içindeki cleanup ile silinir; verisi olan bayilerde dokunulmaz (UI'dan elle silinebilir). Yeni bayiler `fin_garanti` görmez.

- **Şema:** `Warranty` (`backend/app/models/warranty.py`) — `id, user_id (FK), product_name, product_image_url, customer_name, customer_phone, duration_label, duration_days, start_date, end_date, public_token (unique), notes, created_at, updated_at`. **Tutar alanı YOKTUR.**
- **Bağımlılık:** `qrcode[pil]>=7.4` (requirements.txt).
- **Endpoints (`backend/app/api/warranty.py`, prefix `/warranty`):**
  - `POST /warranty` — multipart (Form + `image` UploadFile, 10 MB cap, .jpg/.jpeg/.png/.webp whitelist).
  - `GET /warranty?status=active|expired|all&q=...` — patron veya çalışan listesi.
  - `GET /warranty/{id}` / `PUT /warranty/{id}` (multipart) / `DELETE /warranty/{id}`.
  - `GET /warranty/{id}/qr.png?base_url=...` — `qrcode.make(public_url).save(BytesIO)` → `StreamingResponse(media_type="image/png")`. base_url default = ortam ya da `https://stokfinans.app`.
  - `POST /warranty/{id}/whatsapp-link` (Form `base_url`) → `{ wa_url: "https://wa.me/<digits>?text=...", text, public_url }`. Telefon `_normalize_phone()` ile temizlenir (TR varsayılan +90, baştaki 0 atılır).
- **Public link base URL — `_safe_base_url(request, client_hint)` (warranty.py):** Öncelik (1) `PUBLIC_BASE_URL` env, (2) `X-Forwarded-Proto` + `X-Forwarded-Host`, (3) browser'ın `window.location.origin` (client_hint), (4) `request.base_url`. Loopback adresleri (127.0.0.1, localhost, 0.0.0.0) HER SEVİYEDE atlanır → public link asla backend port'unu (8000) sızdırmaz. Aday yoksa 500 (yanlış link üretmek yerine hata). Vite proxy `vite.config.ts` içinde `proxy.on('proxyReq')` ile `X-Forwarded-Host`/`X-Forwarded-Proto` ekler (changeOrigin Host'u eziyor) → backend gerçek Replit domain'ini görür. Finance debtor-link modülü de aynı `_safe_base_url`'ü import eder.
- **Görüntülenme tracking:** `Warranty.view_count INTEGER NOT NULL DEFAULT 0`, `Warranty.last_viewed_at TIMESTAMPTZ` (debtor_links pattern). `/public/warranty/{token}` her açılışta sayaç++ ve last_viewed_at = now (try/except içinde, hata olsa da müşteri sayfayı görür). Migration `_apply_runtime_migrations()` içinde `ADD COLUMN IF NOT EXISTS`.
- **Süre presetleri:** `'1 ay'/30, '3 ay'/90, '6 ay'/180, '7 ay'/210, '1 yıl'/365, '2 yıl'/730, '3 yıl'/1095, 'Özel'/<duration_days>`.
- **Frontend:** `frontend/src/PhaseThreeViews.tsx` `WarrantyManagementView` — Aktif/Süresi Biten/Tümü tabları, kart görünümü (resim, müşteri, kalan gün, tarih aralığı), QR modal (PNG endpoint blob), WhatsApp share modal. Sidebar'a "Garanti Belgeleri" (`Shield` icon, display_order 8900) eklendi; `App.tsx` `case 'warranty'` switch'te.
- **Süperadmin "Garantiler" sekmesi:** `GET /superadmin/warranties?q&user_id&status_filter&sort&page&per_page` — tüm bayilerin garantileri + her birinin görüntülenme istatistikleri (view_count, last_viewed_at) + global stats (toplam garanti / toplam görüntülenme / aktif / süresi dolmuş / hiç açılmamış / garanti veren bayi sayısı). `SuperAdminPanel.tsx` içinde `WarrantiesView` component'i, `mainTab='warranties'`. Tablo bayi (tıklanınca user drawer'ı açar) / ürün+müşteri / süre / durum / view_count / son açılma / kopyala+aç action'ları.

### 3. Borçlu Slip Linki

- **Şema:** `DebtorLink` (`backend/app/models/debtor_link.py`) — `id, user_id (FK), customer_name, public_token (unique), expires_at (nullable, NULL = süresiz), last_viewed_at, view_count, created_at`.
- **Endpoints (`finance.py` sonuna append, prefix `/finance/debtor-links`):**
  - `POST /finance/debtor-links` body `{customer_name, expires_in_days?, base_url?}` → `{id, public_token, public_url, wa_url, expires_at, ...}`. Telefon en son müşteri transaction'ından (notes/customer_phone/description) parse edilir, varsa wa_url üretilir.
  - `GET /finance/debtor-links?customer_name=...` — listesi.
  - `DELETE /finance/debtor-links/{id}`.
- **Frontend:** `PhaseThreeViews.DebtorLinkModal` — Cari (grouped finans) listesinde her satırda **"Slip"** butonu (yeşil mail icon). Modal: süre seçimi (1g/7g/30g/90g/Süresiz) + mevcut linkler listesi (kopyala / WhatsApp / sil / view_count + son görüntülenme).

### 4. Public Sayfalar (auth YOK)

- **Endpoints (`backend/app/api/public.py`, prefix `/public`):**
  - `GET /public/warranty/{token}` → ürün/müşteri/tarih/bayi bilgisi + `is_expired, days_remaining`.
  - `GET /public/debtor/{token}` → süresi geçmiş ise **410 Gone**, aksi halde `{customer_name, bayi_name, total_debt, total_paid, balance, transactions: [...], server_time, expires_at}`. `last_viewed_at`/`view_count` bumplanır.
- **Sınıflandırma:** `DEBT_TYPES = {'borç','borc','debt','veresiye','satış','sale','senet','kredi'}`, `PAYMENT_TYPES = {'ödeme','odeme','payment','tahsilat'}`. Diğer tipler ne borç ne ödeme sayılır (kasa/garanti gibi).
- **Subscription middleware:** `main.py` whitelist'e `/api/v1/public/` eklendi (Faz 3 öncesi süresi dolmuş bayinin müşterileri linki açabilsin diye).
- **Frontend public path yakalama:** `frontend/src/main.tsx` `Root` component App'ten ÖNCE çalışır. URL `/garanti/<token>` ya da `/borc/<token>` ise direkt `PublicWarrantyPage` / `PublicDebtorPage` render edilir (login akışını atlar). `PublicShell` bağımsız axios instance + theme localStorage'tan okur (App context kullanmaz).
- **Borç sayfası canlı yenileme:** 15 saniyede bir otomatik refresh (`setInterval`); 410 Gone alırsa interval temizlenir.

### Sync & Yedekleme

`backend/app/services/sync_service.SYNC_TABLES` ve `SEQUENCE_TABLES` listelerine `warranties` ve `debtor_links` eklendi → ana↔ayna sunucu eşleşmesinde ve sistem yedeğinde otomatik yer alır.

### Public URL şeması

- Garanti: `${base_url}/garanti/${public_token}` — token `secrets.token_urlsafe(24)` (~32 char URL-safe).
- Borç: `${base_url}/borc/${public_token}` — aynı format.
- WhatsApp deep link: `https://wa.me/<digits_only>?text=${encodeURIComponent(text)}`.

### Güvenlik notları (Faz 3 architect review fixleri)

- **base_url phishing koruması:** QR/WhatsApp link üretiminde base_url client'tan gelse bile **backend güvenli üretir** (`backend/app/api/warranty.py::_safe_base_url`). Öncelik: (1) `PUBLIC_BASE_URL` env değişkeni, (2) `X-Forwarded-Proto`+`X-Forwarded-Host`, (3) `request.base_url`, (4) son çare: client hint (sadece scheme+netloc, http/https whitelist). Path/query/fragment client'tan **kabul edilmez** → "javascript:" gibi enjeksiyonlar engellenir.
- **view_count race-safe artırım:** `public.py::public_debtor` artık `UPDATE … SET view_count = view_count + 1` atomik SQL kullanır; eşzamanlı sayfa açılışlarında lost update yaşanmaz.
- **Public token kapasitesi:** Tokenlar yalnızca yetenek (capability) gibi davranır — DB sorgusu sadece token üzerinden yapılır, ama tenant verisi tokena bağlı `user_id`'den çekilir; URL paylaşımı = veri paylaşımı kuralı geçerli.

## Destek & Talep Sistemi

### Özellikler
- Bayiler kategori seçip (Hata / Talep / Öneri / Diğer) destek talebi açar ve mesaj atar.
- Süper admin tüm talepleri görür, cevaplar, durumu değiştirir (Açık → İşlemde → Kapalı).
- Çift yönlü mesajlaşma: mesaj thread'inde bayi mesajları sağda, admin cevapları solda görünür.
- Bayi mesaj gönderince kapalı talep otomatik "Açık"a döner.
- Süper admin cevap verince talep "İşlemde"ye geçer.
- Süper admin panelinde açık talep sayısı "Destek" tab butonunda kırmızı badge olarak gösterilir.

### Backend
- **Modeller:** `backend/app/models/support.py` — `SupportTicket`, `SupportMessage`.
  - `SupportTicket`: id, user_id (FK→users), subject (255), category (bug/request/suggestion/other), status (open/in_progress/closed), created_at, updated_at.
  - `SupportMessage`: id, ticket_id (FK→support_tickets), sender_user_id (FK→users), is_from_admin (bool), body (Text), created_at.
- **Migration:** `main.py` — `CREATE TYPE IF NOT EXISTS ticket_category_enum|ticket_status_enum` + 2 CREATE TABLE + index'ler.
- **Bayi endpoint'leri** (`backend/app/api/support.py`, prefix `/support`):
  - `POST /support/tickets` — {subject, category, body} → ilk mesajla birlikte talep oluştur.
  - `GET /support/tickets?status=` — kendi ticket'ları.
  - `GET /support/tickets/{id}` — mesaj thread'iyle.
  - `POST /support/tickets/{id}/messages` — cevap ekle (kapalı talebe ekleme reddedilir).
- **Süper admin endpoint'leri** (superadmin.py sonuna append, prefix `/superadmin/tickets`):
  - `GET /superadmin/tickets?status=&search=&page=` — tüm talepler (bayi adı, konu, filtre).
  - `GET /superadmin/tickets/open-count` — badge sayacı için.
  - `GET /superadmin/tickets/{id}` — mesaj thread'iyle.
  - `POST /superadmin/tickets/{id}/messages` — admin cevabı, status → in_progress.
  - `PATCH /superadmin/tickets/{id}/status` — durum değiştir.
- **Sync/backup:** `SupportTicket` ve `SupportMessage` `SYNC_TABLES` + `SEQUENCE_TABLES`'a eklendi.

### Frontend
- **Bayi:** `frontend/src/SupportView.tsx` — sidebar'da "DESTEK / Destek & Talepler" (MessageCircle ikonu). Sol: ticket listesi (renk kodlu durum badge). Sağ: mesaj thread + cevap textarea (Ctrl+Enter kısayolu). "Yeni Talep" modal (konu + kategori + açıklama).
- **Süper admin:** `SuperAdminPanel.tsx` — yeni `'support'` tab (açık talep sayısı badge). Tablo: bayi, konu, kategori, durum, son güncelleme. Satıra tıkla → detay paneli açılır (mesaj thread + durum dropdown + cevap kutusu).
