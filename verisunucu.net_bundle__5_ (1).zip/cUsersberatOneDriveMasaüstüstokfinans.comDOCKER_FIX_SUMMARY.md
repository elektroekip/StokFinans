
---

## Additional Fix: Frontend API URL for Browser Access

### Problem:
Frontend browser console error:
```
Failed to load resource: net::ERR_NAME_NOT_RESOLVED
POST http://backend:8000/api/v1/auth/login net::ERR_NAME_NOT_RESOLVED
```

### Root Cause:
- Docker Compose had `VITE_API_URL: http://backend:8000/api/v1`
- The hostname `backend:8000` only resolves inside the Docker network
- Browser requests from the host can't resolve `backend` hostname
- Must use `localhost:8000` for browser-based requests

### Solution:
Updated `docker-compose.dev.yml` line 78:
```yaml
# Before:
VITE_API_URL: http://backend:8000/api/v1

# After:
VITE_API_URL: http://localhost:8000/api/v1
```

### Important Note:
For **production deployment with Nginx reverse proxy**, you would:
- Use `http://backend:8000` (container-to-container networking)
- OR use Nginx to proxy `/api/*` requests to the backend container
- This configuration is only for development mode

---

**Status:** ✅ All Systems Operational

