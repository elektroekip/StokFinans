# 🚀 StokFinans: Sıfırdan Zirveye Geliştirme Master Planı

Bu belge, StokFinans sisteminin sağlam bir mimariyle, baştan sona (Frontend + Python Backend + DevOps) geliştirilmesi için hazırlanmış nihai yol haritasıdır.

---

## 🏕️ SEVİYE 1: Temel Kamp - Hazırlık ve Altyapı (0% - 10%)
*Bu aşamada kod yazmaktan çok, binanın temelini sağlam atıyoruz.*

- [ ] **Sürüm Kontrolü (Git/GitHub)**
  - [ ] GitHub'da gizli (private) bir depo (repo) oluşturulması.
  - [ ] `main` ve `develop` dallarının (branch) ayarlanması.
  - [ ] `.gitignore` dosyasının oluşturulması (Python ve Node.js için).
- [ ] **Klasör Mimarisinin Kurulması**
  - [ ] `/frontend` (React projesi)
  - [ ] `/backend` (FastAPI projesi)
- [ ] **Backend Ortam Kurulumu**
  - [ ] Python Sanal Ortam (Virtual Environment) oluşturulması (`python -m venv venv`).
  - [ ] Gerekli temel kütüphanelerin kurulması ve `requirements.txt` dosyasına eklenmesi (`fastapi`, `uvicorn`, `sqlalchemy`, `pydantic`, `alembic`, `python-dotenv`).
- [ ] **Çevre Değişkenleri (Environment Variables)**
  - [ ] `.env` dosyasının oluşturulması (Gizli şifreler, DB bağlantı URL'si, JWT Secret Key).

---

## 🧱 SEVİYE 2: Zemin Kat - Veritabanı Tasarımı ve ORM (10% - 30%)
*Verilerin nerede ve nasıl tutulacağını tasarlıyoruz.*

- [ ] **Veritabanı Seçimi**
  - [ ] Geliştirme (Dev) ortamı için SQLite kurulumu.
  - [ ] Canlı (Prod) ortam için PostgreSQL altyapısının belirlenmesi.
- [ ] **SQLAlchemy ile Veri Modellerinin (Tabloların) Yazılması**
  - [ ] `User` Tablosu: id, email, password_hash, role, ref_code, sub_days, ip_address, created_at.
  - [ ] `Company` Tablosu: id, name, tax_no, address, phone.
  - [ ] `Product` Tablosu: id, category, name, barcode, buy_price, sell_price, stock_amount.
  - [ ] `Transaction` (Cari) Tablosu: id, type (borç/alacak), amount, desc, image_url, date.
  - [ ] `Log` Tablosu: id, user_id, action_type, detail, created_at.
- [ ] **Veritabanı Göçleri (Migrations)**
  - [ ] `Alembic` kurulumu ve konfigürasyonu (`alembic init`).
  - [ ] İlk migration dosyasının oluşturulması ve tabloların DB'ye basılması (`alembic upgrade head`).

---

## 🔐 SEVİYE 3: Güvenlik Duvarı - Kimlik Doğrulama ve Referans Sistemi (30% - 50%)
*Sistemin en hassas noktası: Giriş çıkışlar, şifreleme ve hile koruması.*

- [ ] **Şifreleme (Cryptography)**
  - [ ] `passlib` ve `bcrypt` ile kullanıcı şifrelerinin hash'lenmesi mekanizması.
- [ ] **JWT (JSON Web Token) Entegrasyonu**
  - [ ] Başarılı girişte Token (Access Token) üretilmesi.
  - [ ] Süresi dolan tokenlar için yenileme (Refresh Token) mekanizması.
- [ ] **Referans ve IP Koruma Mantığının Kodlanması**
  - [ ] Kayıt uç noktasında (Register Endpoint) `request.client.host` ile IP çekilmesi.
  - [ ] Veritabanında aynı IP'den daha önce kayıt olunmuş mu kontrolü (Anti-Hile).
  - [ ] Girilen referans kodunun sahibini bulma ve her iki hesaba `sub_days += 10` ekleme algoritması.
- [ ] **Rol Bazlı Erişim Kontrolü (RBAC)**
  - [ ] Sadece `bayi_sahibi` rolündeki kullanıcıların Ayarlar ve Personel silme endpointlerine erişebilmesi için bağımlılık (Dependency) yazılması.

---

## ⚙️ SEVİYE 4: Motor Odası - Çekirdek API Uç Noktaları (50% - 70%)
*Frontend'in (React) veri çekip veri göndereceği kapıların (Endpoinler) inşası.*

- [ ] **Stok API (`/api/stocks`)**
  - [ ] `POST /`: Yeni ürün ekleme.
  - [ ] `GET /`: Ürünleri listeleme (Arama, Sayfalama/Pagination ve Kategori filtreleme ile).
  - [ ] `PUT /{id}`: Ürün güncelleme.
  - [ ] `DELETE /{id}`: Ürün silme.
- [ ] **Finans & Cari API (`/api/finance`)**
  - [ ] `POST /transaction`: Tahsilat veya borçlandırma kaydı.
  - [ ] `GET /balance`: Toplam alacak/verecek hesaplaması (Dashboard için).
- [ ] **Log & İşlem Geçmişi API (`/api/logs`)**
  - [ ] Her stok veya finans işlemi yapıldığında arka planda `Log` tablosuna kayıt atacak yardımcı fonksiyon (Helper) yazılması.
  - [ ] `GET /`: Geçmişi tarih ve kategoriye göre filtreleyip getirme.

---

## 📸 SEVİYE 5: Gelişmiş Özellikler - Dosya Yükleme ve Raporlar (70% - 85%)
*Fatura görselleri yükleme ve gelişmiş özelliklerin sisteme dahil edilmesi.*

- [ ] **Görsel Yükleme Servisi (File Upload)**
  - [ ] FastAPI `UploadFile` modülünün entegrasyonu.
  - [ ] Yüklenen görselleri `/uploads` klasörüne benzersiz (UUID) isimlerle kaydetme.
  - [ ] Resimlere statik erişim için FastAPI `StaticFiles` ayarı.
  - [ ] İleri seviye (Opsiyonel): Resimleri sıkıştırarak (Pillow kütüphanesi) sunucu alanından tasarruf etme.
- [ ] **Dashboard İstatistikleri (`/api/dashboard`)**
  - [ ] Aylık ciro, kritik stok sayısı, toplam borç verilerini tek seferde (JSON) döndüren optimize edilmiş bir SQL sorgusu yazılması.
- [ ] **PDF Rapor Çıktısı (Opsiyonel Ekstra)**
  - [ ] `WeasyPrint` veya `ReportLab` kütüphanesi kurularak, stok listesinin PDF formatında indirilmesi için endpoint yazılması.

---

## 🔗 SEVİYE 6: Köprü - Frontend ve Backend Entegrasyonu (85% - 95%)
*Önceden hazırlanan React arayüzünün, yeni yazdığımız Python sunucusuyla konuşturulması.*

- [ ] **CORS (Cross-Origin Resource Sharing) Ayarları**
  - [ ] Python backend'de React'in çalıştığı portun (örn: `localhost:3000`) yetkilendirilmesi.
- [ ] **Axios Konfigürasyonu (React Tarafı)**
  - [ ] API çağrıları için merkezi bir `api.js` dosyası oluşturulması.
  - [ ] `Axios Interceptor` yazılarak her isteğin (Request) başına JWT Token'ının otomatik eklenmesi.
- [ ] **Gerçek Veri Bağlantısı**
  - [ ] Auth, Stok, Finans, Loglar sayfalarındaki "Mock" (Sahte) verilerin silinip `useEffect` ile Backend'den çekilmesi.

---

## 🏔️ SEVİYE 7: Zirve - Optimizasyon, Test ve Canlıya Alma (Deployment) (95% - 100%)
*Uygulamanın internete açılıp gerçek müşterilere hizmet verecek hale getirilmesi.*

- [ ] **Konteynerleştirme (Docker)**
  - [ ] Python Backend için `Dockerfile` oluşturulması.
  - [ ] React Frontend için `Dockerfile` oluşturulması.
  - [ ] Veritabanı ve sunucuları tek tuşla kaldırmak için `docker-compose.yml` yazılması.
- [ ] **Sunucu Optimizasyonu**
  - [ ] FastAPI'nin canlı ortamda çalışması için `Gunicorn` ve `Uvicorn` işçilerinin (workers) ayarlanması.
- [ ] **Canlı Sunucuya Kurulum (VPS - Ubuntu)**
  - [ ] DigitalOcean, Hetzner veya AWS üzerinden bir Linux sunucu alınması.
  - [ ] `Nginx` kurulumu ve ters vekil (Reverse Proxy) yapılandırması.
  - [ ] `Certbot` ile ücretsiz SSL (HTTPS) sertifikası alınması.
- [ ] **Planlanmış Görevler (Cron Jobs - Background Tasks)**
  - [ ] Günü dolan aboneliklerin statüsünü "Pasif"e çekecek, her gece yarısı çalışacak bir Python Background Task (veya Celery worker) ayarlanması.

---
🎯 **Tebrikler!** Bu adımları tamamladığında StokFinans artık sadece bir tasarım değil, binlerce aboneyi kaldırabilecek profesyonel bir SaaS ürünüdür.