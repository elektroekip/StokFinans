import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    host: '0.0.0.0',
    port: 5000,
    allowedHosts: true,
    watch: {
      usePolling: true,
      interval: 500,
    },
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
        secure: false,
        // ÖNEMLİ: changeOrigin Host header'ını backend hedefiyle override eder.
        // Backend'in gerçek public origin'i (Replit dev/prod domain) bilebilmesi için
        // X-Forwarded-Host ve X-Forwarded-Proto'yu manuel olarak ekliyoruz.
        // Bu sayede public garanti / debtor linkleri 127.0.0.1:8000 yerine
        // doğru replit.dev domain'i ile üretilir.
        configure: (proxy) => {
          proxy.on('proxyReq', (proxyReq, req) => {
            const host = req.headers.host;
            if (host) {
              proxyReq.setHeader('X-Forwarded-Host', host);
            }
            // Replit proxy zaten https sonlandırıyor; Vite içine http olarak geliyor
            // ama dış istek https. Backend public link üretirken https kullansın.
            const xfp = req.headers['x-forwarded-proto'];
            proxyReq.setHeader('X-Forwarded-Proto', (Array.isArray(xfp) ? xfp[0] : xfp) || 'https');
          });
        },
      },
    },
  },
})
