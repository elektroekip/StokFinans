// Bu dosya artık kullanılmıyor. Yeni BTB müşteri sistemi B2BCustomerView.tsx içindedir.
export default function B2BPortal(_props: any) { return null; }
