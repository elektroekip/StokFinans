import React, { useEffect, useMemo, useState, useCallback } from 'react';
import api from './lib/api';
import LiveTopology from './LiveTopology';
import SystemOverview from './SystemOverview';
import { withSilentRefresh } from './lib/refreshBus';
import {
  exportKullanicilar, exportGarantiler, exportAbonelikler, exportOdemeler,
} from './utils/exportExcel';
import {
  Users, Building2, Boxes, Receipt, AlertTriangle, Clock, CheckCircle2,
  Search, RefreshCw, X, KeyRound, Trash2, Plus, Minus, ShieldCheck, Activity,
  ChevronLeft, ChevronRight, LogOut, Crown, Database, FolderTree,
  Share2, ArrowRight, Gift, UserPlus, Sparkles, TrendingUp, TrendingDown, Calendar,
  CreditCard, Settings, Save, Eye, EyeOff,
  Mail, CheckCircle, Send, Bell, ToggleLeft, ToggleRight, FileText,
  Download, Copy, HardDrive, Server, Cpu, Upload, Folder, FolderOpen, Network,
  PlugZap, Wifi, WifiOff, AlertCircle, ArrowUpToLine, ArrowDownToLine, Link2, XCircle,
  Archive,
  MessageCircle, Inbox,
  ShieldAlert, ExternalLink, Briefcase, UserCheck, ShoppingCart
} from 'lucide-react';

type Stats = {
  total_users: number; total_owners: number; total_employees: number;
  active_users: number; inactive_users: number;
  expiring_soon: number; expired: number;
  total_products: number; total_transactions: number;
  total_categories: number; new_users_30d: number;
};

type SuperUser = {
  id: number; email: string; full_name: string; company_name: string | null;
  role: string; ref_code: string | null; sub_days: number;
  is_active: boolean; is_super_admin: boolean;
  created_at: string;
  product_count: number; transaction_count: number;
  last_activity_at: string | null;
  referred_by_user_id: number | null;
  referred_by_email: string | null;
  referred_by_name: string | null;
  invited_count: number;
};

type ReferrerSummary = {
  referrer_id: number; email: string; full_name: string;
  company_name: string | null; ref_code: string | null;
  is_active: boolean; invited_count: number;
  last_invited_at: string | null;
};

type ReferralPair = {
  invited_id: number; invited_email: string; invited_name: string;
  invited_company: string | null; invited_active: boolean; invited_at: string;
  inviter_id: number | null; inviter_email: string | null;
  inviter_name: string | null; inviter_code: string | null;
};

const formatDate = (s?: string | null) => {
  if (!s) return '—';
  try {
    const d = new Date(s);
    return d.toLocaleDateString('tr-TR', { day: '2-digit', month: 'short', year: 'numeric' });
  } catch { return s; }
};
const formatDateTime = (s?: string | null) => {
  if (!s) return '—';
  try {
    const d = new Date(s);
    return d.toLocaleString('tr-TR', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  } catch { return s; }
};

const StatCard: React.FC<{ icon: any; label: string; value: number | string; tone?: string; sub?: string }> = ({ icon: Icon, label, value, tone = 'indigo', sub }) => {
  const tones: Record<string, string> = {
    indigo: 'bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-300',
    emerald: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-300',
    amber: 'bg-amber-50 text-amber-600 dark:bg-amber-900/30 dark:text-amber-300',
    red: 'bg-red-50 text-red-600 dark:bg-red-900/30 dark:text-red-300',
    purple: 'bg-purple-50 text-purple-600 dark:bg-purple-900/30 dark:text-purple-300',
    slate: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300',
  };
  return (
    <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${tones[tone]}`}>
        <Icon size={22} />
      </div>
      <div className="min-w-0">
        <div className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400 tracking-wider truncate">{label}</div>
        <div className="text-2xl font-black text-slate-800 dark:text-white">{value}</div>
        {sub && <div className="text-[11px] text-slate-400 dark:text-slate-500 font-medium">{sub}</div>}
      </div>
    </div>
  );
};

const RoleBadge: React.FC<{ user: SuperUser }> = ({ user }) => {
  if (user.is_super_admin) {
    return <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300 text-[11px] font-bold"><Crown size={11} />SÜPER YÖNETİCİ</span>;
  }
  if (user.role === 'bayi_sahibi') {
    return <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300 text-[11px] font-bold">BAYI SAHİBİ</span>;
  }
  return <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300 text-[11px] font-bold">ÇALIŞAN</span>;
};

const StatusBadge: React.FC<{ user: SuperUser }> = ({ user }) => {
  if (!user.is_active) {
    return <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300 text-[11px] font-bold">PASİF</span>;
  }
  if (user.sub_days <= 0) {
    return <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300 text-[11px] font-bold">SÜRESİ DOLDU</span>;
  }
  if (user.sub_days <= 7) {
    return <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300 text-[11px] font-bold">{user.sub_days} GÜN KALDI</span>;
  }
  return <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300 text-[11px] font-bold">{user.sub_days} GÜN AKTİF</span>;
};

const BTN_BASE = 'inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition disabled:opacity-50 disabled:cursor-not-allowed';
const ACTION = {
  amber: `${BTN_BASE} bg-amber-100 text-amber-700 hover:bg-amber-200 dark:bg-amber-900/40 dark:text-amber-300 dark:hover:bg-amber-900/60`,
  emerald: `${BTN_BASE} bg-emerald-100 text-emerald-700 hover:bg-emerald-200 dark:bg-emerald-900/40 dark:text-emerald-300 dark:hover:bg-emerald-900/60`,
  indigo: `${BTN_BASE} bg-indigo-600 text-white hover:bg-indigo-700`,
  purple: `${BTN_BASE} bg-purple-100 text-purple-700 hover:bg-purple-200 dark:bg-purple-900/40 dark:text-purple-300 dark:hover:bg-purple-900/60`,
  red: `${BTN_BASE} bg-red-100 text-red-700 hover:bg-red-200 dark:bg-red-900/40 dark:text-red-300 dark:hover:bg-red-900/60`,
};

interface SuperAdminPanelProps {
  currentUser: any;
  onLogout: () => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'warning') => void;
}

// =====================================================================
// Overview Panel — feature cards navigation landing page
// =====================================================================
type MainTab = 'overview' | 'users' | 'referrals' | 'subscriptions' | 'packages' | 'payments' | 'paytr' | 'email' | 'backups' | 'ftp' | 'sync' | 'system' | 'support' | 'warranties' | 'siteinfo' | 'devices' | 'security' | 'apikeys' | 'btb_activity' | 'storage' | 'sysoverview' | 'topology' | 'bulkdeploy';

const ICON_STYLE: Record<string, string> = {
  indigo: 'bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400',
  emerald: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400',
  purple: 'bg-purple-50 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400',
  amber: 'bg-amber-50 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400',
  red: 'bg-red-50 text-red-600 dark:bg-red-900/30 dark:text-red-400',
  slate: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400',
};

const OverviewPanel: React.FC<{
  stats: Stats | null;
  openTicketCount: number;
  setMainTab: (t: MainTab) => void;
}> = ({ stats, openTicketCount, setMainTab }) => {
  const FEATURES: Array<{
    category: string; color: string; icon: any;
    items: Array<{ id: MainTab; label: string; desc: string; badge?: number }>;
  }> = [
    {
      category: 'Kullanıcı Yönetimi', color: 'indigo', icon: Users,
      items: [
        { id: 'users', label: 'Tüm Kullanıcılar', desc: 'Bayileri listele, detay gör, abonelik & şifre düzenle' },
        { id: 'referrals', label: 'Referans Sistemi', desc: 'Kim kimi davet etti, referans istatistikleri' },
        { id: 'subscriptions', label: 'Abonelikler', desc: 'Süresi dolan ve bitenler, toplu abonelik yönetimi' },
      ]
    },
    {
      category: 'Finansal', color: 'emerald', icon: CreditCard,
      items: [
        { id: 'payments', label: 'Ödeme Geçmişi', desc: 'PayTR işlemleri, başarılı / başarısız ödemeler' },
        { id: 'packages', label: 'Paketler', desc: 'Abonelik paketlerini oluştur ve yönet' },
        { id: 'paytr', label: 'PayTR Ayarları', desc: 'Ödeme entegrasyonu için API key ve konfigürasyon' },
      ]
    },
    {
      category: 'İçerik & Destek', color: 'purple', icon: MessageCircle,
      items: [
        { id: 'support', label: 'Destek Talepleri', desc: openTicketCount > 0 ? `${openTicketCount} bekleyen açık talep` : 'Müşteri destek taleplerini yönet', badge: openTicketCount },
        { id: 'warranties', label: 'Garanti Takibi', desc: 'Tüm bayilerin garanti kayıtlarını görüntüle' },
        { id: 'devices', label: 'Cihazlar', desc: 'IoT ve ESP32 cihaz yönetimi' },
      ]
    },
    {
      category: 'Sistem & Altyapı', color: 'amber', icon: HardDrive,
      items: [
        { id: 'email', label: 'E-posta Ayarları', desc: 'SMTP konfigürasyonu ve test gönderimi' },
        { id: 'backups', label: 'Bayi Yedekleri', desc: 'Bayi bazlı veritabanı yedekleme ve geri yükleme' },
        { id: 'ftp', label: 'FTP / SFTP Sunucuları', desc: 'Uzak depolama ve dosya aktarım yapılandırması' },
        { id: 'sync', label: 'Eşleşme', desc: 'Cihaz ve veri senkronizasyon ayarları' },
        { id: 'system', label: 'Sistem Yedeği', desc: 'Tüm platform yedekleme ve geri yükleme' },
      ]
    },
    {
      category: 'Güvenlik & API', color: 'red', icon: ShieldAlert,
      items: [
        { id: 'security', label: 'Güvenlik Logları', desc: 'Başarısız girişler, şüpheli aktivite izleme' },
        { id: 'apikeys', label: 'API Anahtarları', desc: 'Entegrasyon anahtarları, kapsam ve kullanım yönetimi' },
      ]
    },
    {
      category: 'Platform', color: 'slate', icon: Building2,
      items: [
        { id: 'siteinfo', label: 'Site Bilgileri', desc: 'Hakkımızda ve iletişim sayfası içeriği' },
      ]
    },
  ];

  return (
    <div className="space-y-4">
      {/* Alerts */}
      {(stats?.expiring_soon ?? 0) > 0 && (
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl px-4 py-3 flex items-center gap-3">
          <Clock size={16} className="text-amber-600 dark:text-amber-400 shrink-0" />
          <div className="flex-1 min-w-0">
            <span className="text-sm font-bold text-amber-800 dark:text-amber-300">{stats!.expiring_soon} kullanıcının aboneliği 7 gün içinde bitiyor.</span>
          </div>
          <button onClick={() => setMainTab('subscriptions')} className="shrink-0 text-xs font-bold text-amber-700 dark:text-amber-400 hover:underline flex items-center gap-1">
            Yönet <ArrowRight size={12} />
          </button>
        </div>
      )}
      {openTicketCount > 0 && (
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl px-4 py-3 flex items-center gap-3">
          <MessageCircle size={16} className="text-red-600 dark:text-red-400 shrink-0" />
          <div className="flex-1 min-w-0">
            <span className="text-sm font-bold text-red-800 dark:text-red-300">{openTicketCount} bekleyen destek talebi var.</span>
          </div>
          <button onClick={() => setMainTab('support')} className="shrink-0 text-xs font-bold text-red-700 dark:text-red-400 hover:underline flex items-center gap-1">
            Görüntüle <ArrowRight size={12} />
          </button>
        </div>
      )}

      {/* Feature cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {FEATURES.map(cat => (
          <div key={cat.category} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-100 dark:border-slate-800">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${ICON_STYLE[cat.color]}`}>
                <cat.icon size={16} />
              </div>
              <h3 className="text-sm font-black text-slate-800 dark:text-white">{cat.category}</h3>
            </div>
            <div className="divide-y divide-slate-50 dark:divide-slate-800/60">
              {cat.items.map(item => (
                <button
                  key={item.id}
                  onClick={() => setMainTab(item.id)}
                  className="w-full text-left px-4 py-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition group flex items-start justify-between gap-2"
                >
                  <div className="min-w-0">
                    <div className="text-[13px] font-bold text-slate-700 dark:text-slate-200 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 flex items-center gap-2">
                      {item.label}
                      {(item.badge ?? 0) > 0 && (
                        <span className="bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400 text-[10px] font-black px-1.5 py-0.5 rounded-full">{item.badge}</span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-400 dark:text-slate-500 font-medium leading-snug mt-0.5">{item.desc}</div>
                  </div>
                  <ArrowRight size={13} className="text-slate-300 group-hover:text-indigo-400 shrink-0 mt-1" />
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// =====================================================================
// Main SuperAdminPanel Component
// =====================================================================

const NAV_GROUPS: Array<{
  label: string | null;
  items: Array<{ id: MainTab; icon: any; label: string; badgeKey?: string }>;
}> = [
  {
    label: null,
    items: [
      { id: 'overview', icon: Activity, label: 'Genel Bakış' },
    ]
  },
  {
    label: 'KULLANICILAR',
    items: [
      { id: 'users', icon: Users, label: 'Tüm Kullanıcılar' },
      { id: 'referrals', icon: Share2, label: 'Referanslar' },
      { id: 'subscriptions', icon: Sparkles, label: 'Abonelikler' },
    ]
  },
  {
    label: 'FİNANSAL',
    items: [
      { id: 'payments', icon: CreditCard, label: 'Ödemeler' },
      { id: 'packages', icon: Boxes, label: 'Paketler' },
      { id: 'paytr', icon: Settings, label: 'PayTR Ayarları' },
    ]
  },
  {
    label: 'İÇERİK & DESTEK',
    items: [
      { id: 'support', icon: MessageCircle, label: 'Destek', badgeKey: 'tickets' },
      { id: 'warranties', icon: ShieldCheck, label: 'Garantiler' },
      { id: 'devices', icon: Wifi, label: 'Cihazlar' },
    ]
  },
  {
    label: 'SİSTEM',
    items: [
      { id: 'storage', icon: Database, label: 'Depolama Havuzu' },
      { id: 'sysoverview', icon: Activity, label: 'Genel Bakış' },
      { id: 'topology', icon: Network, label: 'Canlı Sistem Haritası', badgeKey: 'topology' },
      { id: 'email', icon: Mail, label: 'E-posta' },
      { id: 'backups', icon: HardDrive, label: 'Bayi Yedekleri' },
      { id: 'ftp', icon: Server, label: 'FTP / SFTP' },
      { id: 'sync', icon: Network, label: 'Eşleşme' },
      { id: 'bulkdeploy', icon: Upload, label: 'Dağıtım Yönetimi' },
      { id: 'system', icon: Archive, label: 'Sistem Yedeği' },
    ]
  },
  {
    label: 'GÜVENLİK & API',
    items: [
      { id: 'security', icon: ShieldAlert, label: 'Güvenlik' },
      { id: 'apikeys', icon: KeyRound, label: 'API Anahtarları' },
    ]
  },
  {
    label: 'B2B & PORTAL',
    items: [
      { id: 'btb_activity', icon: Briefcase, label: 'B2B Aktivite' },
    ]
  },
  {
    label: 'PLATFORM',
    items: [
      { id: 'siteinfo', icon: Building2, label: 'Site Bilgileri' },
    ]
  },
];

const SuperAdminPanel: React.FC<SuperAdminPanelProps> = ({ currentUser, onLogout, showToast }) => {
  const [stats, setStats] = useState<Stats | null>(null);
  const [users, setUsers] = useState<SuperUser[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [sortBy, setSortBy] = useState<string>('created_at_desc');
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 50;
  const [selectedUser, setSelectedUser] = useState<SuperUser | null>(null);
  const [searchInput, setSearchInput] = useState('');
  const [mainTab, setMainTab] = useState<MainTab>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [openTicketCount, setOpenTicketCount] = useState(0);
  const [topologyAlerts, setTopologyAlerts] = useState(0);
  const [deployingNodeNames, setDeployingNodeNames] = useState<string[]>([]);
  useEffect(() => {
    api.get('/superadmin/tickets/open-count', { _noBar: true } as any).then(r => setOpenTicketCount(r.data.count)).catch(() => {});
  }, []);
  useEffect(() => {
    const poll = () => api.get('/topology/alert-count', { _noBar: true } as any).then(r => setTopologyAlerts(r.data.alerts)).catch(() => {});
    poll();
    const t = setInterval(poll, 10000);
    return () => clearInterval(t);
  }, []);

  // Hızlı kullanıcı drawer açma (referrals/subscriptions sekmesinden satıra tıklanınca).
  // Tam veriyi drawer kendi GET ile yükler.
  const openUserById = useCallback((uid: number) => {
    setSelectedUser({
      id: uid, email: '', full_name: '...', company_name: null,
      role: 'bayi_sahibi', ref_code: null, sub_days: 0,
      is_active: true, is_super_admin: false, created_at: new Date().toISOString(),
      product_count: 0, transaction_count: 0, last_activity_at: null,
      referred_by_user_id: null, referred_by_email: null, referred_by_name: null, invited_count: 0,
    });
  }, []);

  const fetchStats = useCallback(async () => {
    try {
      const r = await api.get('/superadmin/stats');
      setStats(r.data);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'İstatistikler yüklenemedi', 'error');
    }
  }, [showToast]);

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      const params: any = { page, page_size: PAGE_SIZE, sort_by: sortBy };
      if (search) params.search = search;
      if (roleFilter) params.role = roleFilter;
      if (statusFilter) params.status = statusFilter;
      const r = await api.get('/superadmin/users', { params });
      setUsers(r.data.items || []);
      setTotal(r.data.total || 0);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Kullanıcılar yüklenemedi', 'error');
    } finally {
      setLoading(false);
    }
  }, [page, sortBy, search, roleFilter, statusFilter, showToast]);

  useEffect(() => { fetchStats(); }, [fetchStats]);
  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  // Search debounce
  useEffect(() => {
    const id = setTimeout(() => { setPage(1); setSearch(searchInput.trim()); }, 350);
    return () => clearTimeout(id);
  }, [searchInput]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const refreshAll = () => { fetchStats(); fetchUsers(); };

  const SidebarNav = ({ onNavigate }: { onNavigate?: () => void }) => (
    <div className="py-2">
      {NAV_GROUPS.map((group, gi) => (
        <div key={gi} className={gi > 0 ? 'mt-1' : ''}>
          {group.label && (
            <div className="px-3 pt-3 pb-1 text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">
              {group.label}
            </div>
          )}
          {group.items.map(item => {
            const isActive = mainTab === item.id;
            const badge = item.badgeKey === 'tickets' ? openTicketCount : item.badgeKey === 'topology' ? topologyAlerts : 0;
            return (
              <button
                key={item.id}
                onClick={() => { setMainTab(item.id); onNavigate?.(); }}
                className={`relative w-full flex items-center gap-2.5 px-3 py-2 mx-1 rounded-lg text-[13px] font-bold transition text-left ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
                style={{ width: 'calc(100% - 8px)' }}
              >
                <item.icon size={15} className={isActive ? 'text-white' : 'text-slate-400 dark:text-slate-500'} />
                <span className="truncate">{item.label}</span>
                {badge > 0 && (
                  <span className="ml-auto bg-red-500 text-white text-[9px] font-black min-w-[18px] h-[18px] px-1 flex items-center justify-center rounded-full shrink-0">
                    {badge > 9 ? '9+' : badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      ))}
    </div>
  );

  // Current tab label for mobile breadcrumb
  const currentTabLabel = NAV_GROUPS.flatMap(g => g.items).find(i => i.id === mainTab)?.label ?? 'Genel Bakış';

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col">
      {/* Header */}
      <header className="bg-gradient-to-r from-purple-600 via-indigo-600 to-indigo-700 text-white sticky top-0 z-30 shadow-lg">
        <div className="max-w-[1600px] mx-auto px-3 sm:px-6 py-3 flex items-center gap-3">
          {/* Mobile sidebar toggle */}
          <button
            onClick={() => setSidebarOpen(o => !o)}
            className="lg:hidden flex items-center justify-center w-9 h-9 bg-white/15 hover:bg-white/25 rounded-lg transition shrink-0"
            aria-label="Menüyü aç"
          >
            <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <line x1="2" y1="5" x2="16" y2="5" />
              <line x1="2" y1="9" x2="16" y2="9" />
              <line x1="2" y1="13" x2="16" y2="13" />
            </svg>
          </button>

          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <div className="w-9 h-9 bg-white/20 backdrop-blur rounded-xl flex items-center justify-center shrink-0 hidden sm:flex">
              <Crown size={16} />
            </div>
            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-black tracking-tight leading-tight">Süper Yönetici</h1>
              <p className="text-[11px] text-indigo-100 font-medium truncate hidden sm:block">{currentUser?.email || ''}</p>
              {/* Mobile: show current section */}
              <p className="text-[11px] text-indigo-200 font-bold sm:hidden">{currentTabLabel}</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button onClick={refreshAll}
              className="flex items-center gap-1.5 px-2.5 py-1.5 sm:px-3 sm:py-2 bg-white/15 hover:bg-white/25 backdrop-blur rounded-lg text-xs sm:text-sm font-bold transition">
              <RefreshCw size={14} /> <span className="hidden sm:inline">Yenile</span>
            </button>
            <button onClick={onLogout}
              className="flex items-center gap-1.5 px-2.5 py-1.5 sm:px-3 sm:py-2 bg-white/15 hover:bg-red-500/80 backdrop-blur rounded-lg text-xs sm:text-sm font-bold transition">
              <LogOut size={14} /> <span className="hidden sm:inline">Çıkış</span>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 lg:hidden flex">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <div className="relative w-64 bg-white dark:bg-slate-900 shadow-2xl overflow-y-auto flex flex-col">
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-800">
              <span className="text-sm font-black text-slate-800 dark:text-white">Navigasyon</span>
              <button onClick={() => setSidebarOpen(false)} className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500">
                <X size={16} />
              </button>
            </div>
            <SidebarNav onNavigate={() => setSidebarOpen(false)} />
          </div>
        </div>
      )}

      <div className="flex flex-1 w-full max-w-[1600px] mx-auto">
        {/* Desktop sidebar */}
        <nav className="hidden lg:flex flex-col w-56 shrink-0 py-4 pl-6 pr-2">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden sticky top-[57px]">
            <SidebarNav />
          </div>
        </nav>

        {/* Main content */}
        <main className="flex-1 min-w-0 px-3 sm:px-4 lg:pr-6 py-4 space-y-4">
          {/* Stats strip — always visible */}
          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-3">
            <StatCard icon={Users} label="Toplam Kullanıcı" value={stats?.total_users ?? '—'} tone="indigo" sub={`Son 30 gün: +${stats?.new_users_30d ?? 0}`} />
            <StatCard icon={Building2} label="Bayi Sahipleri" value={stats?.total_owners ?? '—'} tone="purple" sub={`Çalışan: ${stats?.total_employees ?? 0}`} />
            <StatCard icon={CheckCircle2} label="Aktif Aboneler" value={(stats ? stats.active_users - stats.expired : 0)} tone="emerald" sub={`Pasif: ${stats?.inactive_users ?? 0}`} />
            <StatCard icon={Clock} label="7 Gün Bitiyor" value={stats?.expiring_soon ?? '—'} tone="amber" />
            <StatCard icon={AlertTriangle} label="Süresi Dolanlar" value={stats?.expired ?? '—'} tone="red" />
            <StatCard icon={Boxes} label="Toplam Ürün" value={stats?.total_products ?? '—'} tone="slate" sub={`İşlem: ${stats?.total_transactions ?? 0}`} />
          </div>

          {/* Section content */}
          {mainTab === 'overview' && <OverviewPanel stats={stats} openTicketCount={openTicketCount} setMainTab={setMainTab} />}
          {mainTab === 'support' && <SupportAdminView showToast={showToast} />}
          {mainTab === 'warranties' && <WarrantiesView showToast={showToast} onSelectUser={(uid) => openUserById(uid)} />}
          {mainTab === 'siteinfo' && <SiteInfoView showToast={showToast} />}
          {mainTab === 'devices' && <DevicesAdminView showToast={showToast} />}
          {mainTab === 'security' && <SecurityView showToast={showToast} />}
          {mainTab === 'apikeys' && <ApiKeysView showToast={showToast} />}
          {mainTab === 'referrals' && <ReferralsView showToast={showToast} onSelectUser={(uid) => openUserById(uid)} />}
          {mainTab === 'subscriptions' && <SubscriptionsView showToast={showToast} onSelectUser={(uid) => openUserById(uid)} />}
          {mainTab === 'packages' && <PackagesView showToast={showToast} />}
          {mainTab === 'payments' && <PaymentsView showToast={showToast} onSelectUser={(uid) => openUserById(uid)} />}
          {mainTab === 'paytr' && <PaytrSettingsView showToast={showToast} />}
          {mainTab === 'email' && <EmailSettingsView showToast={showToast} />}
          {mainTab === 'backups' && <BayiBackupsView showToast={showToast} />}
          {mainTab === 'ftp' && <FtpServersView showToast={showToast} />}
          {mainTab === 'sync' && <MultiNodeSyncView showToast={showToast} />}
          {mainTab === 'system' && <SystemBackupView showToast={showToast} />}
          {mainTab === 'btb_activity' && <B2bActivityView showToast={showToast} />}
          {mainTab === 'storage' && <StoragePoolView showToast={showToast} />}
          {mainTab === 'sysoverview' && <SystemOverview showToast={showToast} onOpenTopology={() => setMainTab('topology')} />}
          {mainTab === 'topology' && <LiveTopology showToast={showToast} onNavigate={(tab) => setMainTab(tab as MainTab)} deployingNodes={deployingNodeNames} />}
          {mainTab === 'bulkdeploy' && <BulkDeployView showToast={showToast} onDeployingNodesChange={setDeployingNodeNames} />}

          {mainTab === 'users' && (
            <>
              {/* Filters */}
              <div className="bg-white dark:bg-slate-900 p-3 sm:p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <div className="flex flex-col sm:flex-row flex-wrap gap-2 sm:gap-3">
                  <div className="relative flex-1 min-w-0">
                    <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      placeholder="E-posta, ad veya işletme ara..."
                      value={searchInput}
                      onChange={(e) => setSearchInput(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-medium"
                    />
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    <select value={roleFilter} onChange={(e) => { setPage(1); setRoleFilter(e.target.value); }}
                      className="flex-1 sm:flex-none px-2.5 py-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200 cursor-pointer">
                      <option value="">Tüm Roller</option>
                      <option value="bayi_sahibi">Bayi Sahibi</option>
                      <option value="calisan">Çalışan</option>
                    </select>
                    <select value={statusFilter} onChange={(e) => { setPage(1); setStatusFilter(e.target.value); }}
                      className="flex-1 sm:flex-none px-2.5 py-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200 cursor-pointer">
                      <option value="">Tüm Durumlar</option>
                      <option value="active">Aktif</option>
                      <option value="expiring">7 Gün Bitiyor</option>
                      <option value="expired">Süresi Dolmuş</option>
                      <option value="inactive">Pasif</option>
                    </select>
                    <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}
                      className="flex-1 sm:flex-none px-2.5 py-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-200 cursor-pointer">
                      <option value="created_at_desc">Yeni → Eski</option>
                      <option value="created_at_asc">Eski → Yeni</option>
                      <option value="sub_days_asc">Az Gün → Çok</option>
                      <option value="sub_days_desc">Çok Gün → Az</option>
                      <option value="email_asc">E-posta A→Z</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Table */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800">
                      <tr className="text-left text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400 tracking-wider">
                        <th className="px-4 py-3">Kullanıcı</th>
                        <th className="px-4 py-3">Rol</th>
                        <th className="px-4 py-3">Durum</th>
                        <th className="px-4 py-3 text-right">Ürün</th>
                        <th className="px-4 py-3 text-right">İşlem</th>
                        <th className="px-4 py-3">Son Aktivite</th>
                        <th className="px-4 py-3">Kayıt</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {loading && (
                        <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-400 font-medium">Yükleniyor...</td></tr>
                      )}
                      {!loading && users.length === 0 && (
                        <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-400 font-medium">Sonuç bulunamadı</td></tr>
                      )}
                      {!loading && users.map(u => (
                        <tr key={u.id}
                          onClick={() => setSelectedUser(u)}
                          className="hover:bg-indigo-50/40 dark:hover:bg-indigo-900/10 cursor-pointer transition">
                          <td className="px-4 py-3">
                            <div className="font-bold text-slate-800 dark:text-white">{u.full_name}</div>
                            <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">{u.email}</div>
                            {u.company_name && <div className="text-[11px] text-slate-400 dark:text-slate-500">🏢 {u.company_name}</div>}
                          </td>
                          <td className="px-4 py-3"><RoleBadge user={u} /></td>
                          <td className="px-4 py-3"><StatusBadge user={u} /></td>
                          <td className="px-4 py-3 text-right font-bold text-slate-700 dark:text-slate-200">{u.product_count}</td>
                          <td className="px-4 py-3 text-right font-bold text-slate-700 dark:text-slate-200">{u.transaction_count}</td>
                          <td className="px-4 py-3 text-xs text-slate-500 dark:text-slate-400 font-medium">{formatDateTime(u.last_activity_at)}</td>
                          <td className="px-4 py-3 text-xs text-slate-500 dark:text-slate-400 font-medium">{formatDate(u.created_at)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Pagination */}
                <div className="flex items-center justify-between px-4 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20">
                  <div className="flex items-center gap-3">
                    <div className="text-xs font-bold text-slate-500 dark:text-slate-400">Toplam {total} kullanıcı</div>
                    <button
                      onClick={() => exportKullanicilar(users)}
                      disabled={users.length === 0}
                      className="flex items-center gap-1.5 px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded-lg transition text-xs"
                      title="Bu sayfayı Excel olarak indir"
                    >
                      <Download size={13} /> Excel
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page <= 1}
                      className="p-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed">
                      <ChevronLeft size={16} />
                    </button>
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300">{page} / {totalPages}</span>
                    <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page >= totalPages}
                      className="p-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed">
                      <ChevronRight size={16} />
                    </button>
                  </div>
                </div>
              </div>
            </>
          )}
        </main>
      </div>

      {selectedUser && (
        <UserDetailDrawer
          user={selectedUser}
          currentUser={currentUser}
          onClose={() => setSelectedUser(null)}
          onChanged={refreshAll}
          showToast={showToast}
        />
      )}
    </div>
  );
};

// =====================================================================
// Drawer: kullanıcı detayı + abonelik / şifre / sil + ürünleri/işlemleri
// =====================================================================

interface DrawerProps {
  user: SuperUser;
  currentUser: any;
  onClose: () => void;
  onChanged: () => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'warning') => void;
}

const UserDetailDrawer: React.FC<DrawerProps> = ({ user, currentUser, onClose, onChanged, showToast }) => {
  const [tab, setTab] = useState<'overview' | 'products' | 'transactions' | 'logs' | 'invited' | 'subevents'>('overview');
  const [busy, setBusy] = useState(false);
  const [data, setData] = useState<SuperUser>(user);
  const [products, setProducts] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [invited, setInvited] = useState<any[]>([]);
  const [subEvents, setSubEvents] = useState<any[]>([]);
  const [resetPwd, setResetPwd] = useState<string | null>(null);

  const isSelf = currentUser?.id === user.id;

  useEffect(() => {
    setData(user);
    // Kullanıcı değiştiğinde tab cache'lerini sıfırla — aksi halde önceki kullanıcının
    // ürün/işlem/log/davet/abonelik geçmişi gösterilebilir (stale data riski).
    setProducts([]);
    setTransactions([]);
    setLogs([]);
    setInvited([]);
    setSubEvents([]);
  }, [user.id]);

  const refreshUser = useCallback(async () => {
    try {
      const r = await api.get(`/superadmin/users/${user.id}`);
      setData(r.data);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Kullanıcı yüklenemedi', 'error');
    }
  }, [user.id, showToast]);

  const loadTab = useCallback(async (t: typeof tab) => {
    if (t === 'products' && products.length === 0) {
      try {
        const r = await api.get(`/superadmin/users/${user.id}/products`, { params: { page_size: 200 } });
        setProducts(r.data.items || []);
      } catch (e: any) { showToast(e?.response?.data?.detail || 'Ürünler yüklenemedi', 'error'); }
    } else if (t === 'transactions' && transactions.length === 0) {
      try {
        const r = await api.get(`/superadmin/users/${user.id}/transactions`, { params: { page_size: 200 } });
        setTransactions(r.data.items || []);
      } catch (e: any) { showToast(e?.response?.data?.detail || 'İşlemler yüklenemedi', 'error'); }
    } else if (t === 'logs' && logs.length === 0) {
      try {
        const r = await api.get(`/superadmin/users/${user.id}/logs`, { params: { page_size: 200 } });
        setLogs(r.data.items || []);
      } catch (e: any) { showToast(e?.response?.data?.detail || 'Loglar yüklenemedi', 'error'); }
    } else if (t === 'invited' && invited.length === 0) {
      try {
        const r = await api.get(`/superadmin/users/${user.id}/invited`, { params: { page_size: 200 } });
        setInvited(r.data.items || []);
      } catch (e: any) { showToast(e?.response?.data?.detail || 'Davet listesi yüklenemedi', 'error'); }
    } else if (t === 'subevents' && subEvents.length === 0) {
      try {
        const r = await api.get(`/superadmin/users/${user.id}/subscription/events`, { params: { page_size: 200 } });
        setSubEvents(r.data.items || []);
      } catch (e: any) { showToast(e?.response?.data?.detail || 'Abonelik geçmişi yüklenemedi', 'error'); }
    }
  }, [user.id, products.length, transactions.length, logs.length, invited.length, subEvents.length, showToast]);

  useEffect(() => { loadTab(tab); }, [tab, loadTab]);

  const adjustDays = async (delta: number) => {
    setBusy(true);
    try {
      const r = await api.post(`/superadmin/users/${user.id}/subscription/adjust`, { delta_days: delta });
      setData(r.data);
      onChanged();
      showToast(`Abonelik ${delta > 0 ? '+' : ''}${delta} gün güncellendi`);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Güncellenemedi', 'error');
    } finally { setBusy(false); }
  };

  const setExactDays = async (days: number) => {
    setBusy(true);
    try {
      const r = await api.patch(`/superadmin/users/${user.id}`, { sub_days: days });
      setData(r.data);
      onChanged();
      showToast('Kalan gün güncellendi');
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Güncellenemedi', 'error');
    } finally { setBusy(false); }
  };

  const toggleActive = async () => {
    if (isSelf && data.is_active) {
      showToast('Kendi hesabınızı pasifleştiremezsiniz', 'error');
      return;
    }
    setBusy(true);
    try {
      const r = await api.patch(`/superadmin/users/${user.id}`, { is_active: !data.is_active });
      setData(r.data);
      onChanged();
      showToast(`Hesap ${r.data.is_active ? 'aktifleştirildi' : 'pasifleştirildi'}`);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Güncellenemedi', 'error');
    } finally { setBusy(false); }
  };

  const toggleSuperAdmin = async () => {
    if (isSelf && data.is_super_admin) {
      showToast('Kendi süper yönetici yetkinizi kaldıramazsınız', 'error');
      return;
    }
    if (!confirm(data.is_super_admin
      ? `${data.email} kullanıcısının süper yönetici yetkisini kaldırmak istiyor musunuz?`
      : `${data.email} kullanıcısına SÜPER YÖNETİCİ yetkisi vermek istiyor musunuz? (Tüm platformu yönetebilir)`)) return;
    setBusy(true);
    try {
      const r = await api.patch(`/superadmin/users/${user.id}`, { is_super_admin: !data.is_super_admin });
      setData(r.data);
      onChanged();
      showToast('Yetki güncellendi');
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Güncellenemedi', 'error');
    } finally { setBusy(false); }
  };

  const resetPassword = async () => {
    if (!confirm(`${data.email} için yeni rastgele şifre üretilecek. Devam edilsin mi?`)) return;
    setBusy(true);
    try {
      const r = await api.post(`/superadmin/users/${user.id}/reset-password`);
      setResetPwd(r.data.new_password);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Sıfırlanamadı', 'error');
    } finally { setBusy(false); }
  };

  const deleteUser = async () => {
    if (isSelf) { showToast('Kendi hesabınızı silemezsiniz', 'error'); return; }
    if (!confirm(`UYARI: ${data.email} kullanıcısı VE TÜM VERİLERİ (ürünler, işlemler, kategoriler, loglar) kalıcı olarak silinecek.\n\nDevam etmek için "EVET" yazın.`)) return;
    const v = prompt('Onay için "EVET" yazın:');
    if (v !== 'EVET') return;
    setBusy(true);
    try {
      await api.delete(`/superadmin/users/${user.id}`);
      showToast('Kullanıcı silindi');
      onChanged();
      onClose();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Silinemedi', 'error');
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end" onClick={onClose}>
      <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" />
      <div className="relative w-full max-w-3xl bg-white dark:bg-slate-950 shadow-2xl overflow-y-auto flex flex-col" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="sticky top-0 z-10 bg-white dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 py-3 sm:py-4 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <h2 className="text-base sm:text-lg font-black text-slate-800 dark:text-white truncate">{data.full_name}</h2>
              <RoleBadge user={data} />
              <StatusBadge user={data} />
            </div>
            <div className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 font-medium truncate">{data.email}</div>
            {data.company_name && <div className="text-[11px] text-slate-400 dark:text-slate-500">🏢 {data.company_name}</div>}
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 shrink-0">
            <X size={18} />
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b border-slate-200 dark:border-slate-800 overflow-x-auto scrollbar-none">
          <div className="flex gap-0.5 px-3 sm:px-4 min-w-max">
            {([
              ['overview', 'Genel'],
              ['subevents', 'Abonelik Geçmişi'],
              ['invited', `Davet (${data.invited_count})`],
              ['products', `Ürünler (${data.product_count})`],
              ['transactions', `İşlemler (${data.transaction_count})`],
              ['logs', 'Loglar'],
            ] as const).map(([k, label]) => (
              <button key={k} onClick={() => setTab(k)}
                className={`px-3 py-2.5 text-xs sm:text-sm font-bold border-b-2 transition whitespace-nowrap ${tab === k
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                  : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'}`}>
                {label}
              </button>
            ))}
          </div>
        </div>

        <div className="p-4 sm:p-6 space-y-4 sm:space-y-6">
          {tab === 'overview' && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <InfoTile label="ID" value={`#${data.id}`} />
                <InfoTile label="Kayıt Tarihi" value={formatDate(data.created_at)} />
                <InfoTile label="Kalan Gün" value={`${data.sub_days} gün`} highlight={data.sub_days <= 7} />
                <InfoTile label="Kendi Referans Kodu" value={data.ref_code || '—'} />
                <InfoTile label="Toplam Ürün" value={String(data.product_count)} />
                <InfoTile label="Toplam İşlem" value={String(data.transaction_count)} />
              </div>

              {/* Referans bilgileri */}
              <Section title="Referans Durumu" icon={Share2}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="p-4 rounded-xl border border-indigo-200 dark:border-indigo-800 bg-indigo-50/50 dark:bg-indigo-900/20">
                    <div className="text-[11px] font-bold uppercase text-indigo-700 dark:text-indigo-300 mb-1 tracking-wider">⬆ Kim davet etti?</div>
                    {data.referred_by_user_id ? (
                      <div>
                        <div className="text-base font-black text-slate-800 dark:text-white">{data.referred_by_name || '—'}</div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">{data.referred_by_email}</div>
                        <div className="text-[11px] text-slate-400 mt-1">Kullanıcı #{data.referred_by_user_id}</div>
                      </div>
                    ) : (
                      <div className="text-sm text-slate-400 dark:text-slate-500 font-medium italic">Referans kodu olmadan kayıt oldu</div>
                    )}
                  </div>
                  <div className="p-4 rounded-xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50/50 dark:bg-emerald-900/20">
                    <div className="text-[11px] font-bold uppercase text-emerald-700 dark:text-emerald-300 mb-1 tracking-wider">⬇ Kaç kişi davet etti?</div>
                    <div className="text-3xl font-black text-emerald-700 dark:text-emerald-300">{data.invited_count}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">
                      {data.invited_count > 0
                        ? `${data.ref_code || 'koduyla'} bayı kazandırdı`
                        : 'Henüz kimseyi davet etmemiş'}
                    </div>
                  </div>
                </div>
                {data.invited_count > 0 && (
                  <button onClick={() => setTab('invited' as any)}
                    className="mt-3 inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:text-indigo-800 dark:text-indigo-400">
                    Davet ettiği kullanıcıları gör <ArrowRight size={14} />
                  </button>
                )}
              </Section>

              {/* Subscription management */}
              <Section title="Abonelik Yönetimi" icon={Clock}>
                <div className="flex flex-wrap gap-2">
                  <button disabled={busy} onClick={() => adjustDays(-7)} className={ACTION.amber}><Minus size={14} /> 7 Gün</button>
                  <button disabled={busy} onClick={() => adjustDays(-1)} className={ACTION.amber}><Minus size={14} /> 1 Gün</button>
                  <button disabled={busy} onClick={() => adjustDays(7)} className={ACTION.emerald}><Plus size={14} /> 7 Gün</button>
                  <button disabled={busy} onClick={() => adjustDays(30)} className={ACTION.emerald}><Plus size={14} /> 30 Gün</button>
                  <button disabled={busy} onClick={() => adjustDays(90)} className={ACTION.emerald}><Plus size={14} /> 90 Gün</button>
                  <button disabled={busy} onClick={() => adjustDays(365)} className={ACTION.emerald}><Plus size={14} /> 1 Yıl</button>
                </div>
                <div className="flex items-center gap-2 mt-3">
                  <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase">Tam değer:</label>
                  <input type="number" min={0} defaultValue={data.sub_days} id="exactDays"
                    className="w-28 px-3 py-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg text-sm font-bold text-slate-700 dark:text-slate-200" />
                  <button disabled={busy} onClick={() => {
                    const el = document.getElementById('exactDays') as HTMLInputElement;
                    const v = parseInt(el?.value || '0', 10);
                    if (!isNaN(v) && v >= 0) setExactDays(v);
                  }} className={ACTION.indigo}>Uygula</button>
                </div>
              </Section>

              {/* Account actions */}
              <Section title="Hesap İşlemleri" icon={ShieldCheck}>
                <div className="flex flex-wrap gap-2">
                  <button disabled={busy || (isSelf && data.is_active)} onClick={toggleActive}
                    className={data.is_active ? ACTION.amber : ACTION.emerald}>
                    {data.is_active ? 'Hesabı Pasifleştir' : 'Hesabı Aktifleştir'}
                  </button>
                  <button disabled={busy || (isSelf && data.is_super_admin)} onClick={toggleSuperAdmin}
                    className={ACTION.purple}>
                    <Crown size={14} /> {data.is_super_admin ? 'Süper Yönetici Yetkisini Kaldır' : 'Süper Yönetici Yap'}
                  </button>
                  <button disabled={busy} onClick={resetPassword} className={ACTION.indigo}>
                    <KeyRound size={14} /> Şifreyi Sıfırla
                  </button>
                  <button disabled={busy || isSelf} onClick={deleteUser} className={ACTION.red}>
                    <Trash2 size={14} /> Kullanıcıyı Sil
                  </button>
                </div>
                {resetPwd && (
                  <div className="mt-3 p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-300 dark:border-amber-700 rounded-xl">
                    <div className="text-xs font-bold text-amber-700 dark:text-amber-300 uppercase mb-2">⚠ Yeni Şifre (sadece bir kez gösteriliyor)</div>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 px-3 py-2 bg-white dark:bg-slate-900 rounded-lg font-mono text-base font-bold text-slate-800 dark:text-white border border-amber-200 dark:border-amber-800 select-all">{resetPwd}</code>
                      <button onClick={() => { navigator.clipboard.writeText(resetPwd); showToast('Panoya kopyalandı'); }}
                        className="px-3 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold">Kopyala</button>
                      <button onClick={() => setResetPwd(null)} className="px-3 py-2 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-bold">Kapat</button>
                    </div>
                    <p className="text-[11px] text-amber-700 dark:text-amber-300 mt-2 font-medium">Kullanıcıya iletin. Bu pencereyi kapatınca tekrar görüntülenemez.</p>
                  </div>
                )}
              </Section>
            </>
          )}

          {tab === 'products' && (
            <Section title={`Ürünler (${products.length})`} icon={Boxes}>
              {products.length === 0 ? (
                <p className="text-sm text-slate-400 font-medium">Bu kullanıcının ürünü yok.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-slate-50 dark:bg-slate-800/50">
                      <tr className="text-left text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400">
                        <th className="px-3 py-2">#</th>
                        <th className="px-3 py-2">Ad</th>
                        <th className="px-3 py-2">Kategori</th>
                        <th className="px-3 py-2 text-right">Stok</th>
                        <th className="px-3 py-2 text-right">Satış</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {products.map(p => (
                        <tr key={p.id}>
                          <td className="px-3 py-2 text-xs text-slate-400">#{p.id}</td>
                          <td className="px-3 py-2 font-bold text-slate-700 dark:text-slate-200">{p.name}</td>
                          <td className="px-3 py-2 text-xs text-slate-500">{p.category}{p.subcategory ? ` · ${p.subcategory}` : ''}</td>
                          <td className="px-3 py-2 text-right font-bold">{p.quantity}</td>
                          <td className="px-3 py-2 text-right font-bold">{p.sell_price?.toFixed?.(2)} {p.currency}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Section>
          )}

          {tab === 'transactions' && (
            <Section title={`İşlemler (${transactions.length})`} icon={Receipt}>
              {transactions.length === 0 ? (
                <p className="text-sm text-slate-400 font-medium">İşlem yok.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-slate-50 dark:bg-slate-800/50">
                      <tr className="text-left text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400">
                        <th className="px-3 py-2">Tarih</th>
                        <th className="px-3 py-2">Tür</th>
                        <th className="px-3 py-2">Müşteri</th>
                        <th className="px-3 py-2 text-right">Tutar</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {transactions.map(t => (
                        <tr key={t.id}>
                          <td className="px-3 py-2 text-xs text-slate-500">{formatDateTime(t.created_at)}</td>
                          <td className="px-3 py-2 text-xs font-bold text-slate-600">{t.type}</td>
                          <td className="px-3 py-2 font-bold text-slate-700 dark:text-slate-200">{t.customer_name}</td>
                          <td className="px-3 py-2 text-right font-bold">{t.amount?.toFixed?.(2)} {t.currency}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Section>
          )}

          {tab === 'invited' && (
            <Section title={`Davet Ettiği Kullanıcılar (${invited.length})`} icon={UserPlus}>
              {invited.length === 0 ? (
                <p className="text-sm text-slate-400 font-medium italic">
                  {data.ref_code
                    ? `${data.ref_code} kodu ile henüz kimse kayıt olmadı.`
                    : 'Bu kullanıcının referans kodu yok.'}
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-slate-50 dark:bg-slate-800/50">
                      <tr className="text-left text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400">
                        <th className="px-3 py-2">Kullanıcı</th>
                        <th className="px-3 py-2">Durum</th>
                        <th className="px-3 py-2 text-right">Kalan Gün</th>
                        <th className="px-3 py-2">Kayıt</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {invited.map(u => (
                        <tr key={u.id}>
                          <td className="px-3 py-2">
                            <div className="font-bold text-slate-700 dark:text-slate-200">{u.full_name}</div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">{u.email}</div>
                            {u.company_name && <div className="text-[11px] text-slate-400">🏢 {u.company_name}</div>}
                          </td>
                          <td className="px-3 py-2">
                            {u.is_active
                              ? <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300 text-[11px] font-bold">AKTİF</span>
                              : <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300 text-[11px] font-bold">PASİF</span>}
                          </td>
                          <td className="px-3 py-2 text-right font-bold">{u.sub_days}</td>
                          <td className="px-3 py-2 text-xs text-slate-500">{formatDate(u.created_at)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Section>
          )}

          {tab === 'subevents' && (
            <Section title={`Abonelik Geçmişi (${subEvents.length})`} icon={Sparkles}>
              {subEvents.length === 0 ? (
                <p className="text-sm text-slate-400 font-medium italic">
                  Henüz abonelik hareketi kaydedilmedi. (Eski hesaplarda kayıt sırasında oluşan ilk gün otomatik olarak loglanmaz; yeni kayıt ve yönetici işlemleri burada görünür.)
                </p>
              ) : (
                <div className="space-y-2">
                  {subEvents.map(ev => (
                    <SubEventRow key={ev.id} ev={ev} />
                  ))}
                </div>
              )}
            </Section>
          )}

          {tab === 'logs' && (
            <Section title="Aktivite Logları" icon={Activity}>
              {logs.length === 0 ? (
                <p className="text-sm text-slate-400 font-medium">Log kaydı yok.</p>
              ) : (
                <div className="space-y-2">
                  {logs.map(l => (
                    <div key={l.id} className="p-3 bg-slate-50 dark:bg-slate-800/30 rounded-lg border border-slate-100 dark:border-slate-800">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">{l.action_type}</span>
                        <span className="text-[11px] text-slate-400">{formatDateTime(l.created_at)}</span>
                      </div>
                      <p className="text-sm text-slate-700 dark:text-slate-200 font-medium">{l.description}</p>
                      {l.ip_address && <p className="text-[11px] text-slate-400 mt-1">IP: {l.ip_address}</p>}
                    </div>
                  ))}
                </div>
              )}
            </Section>
          )}
        </div>
      </div>
    </div>
  );
};

const InfoTile: React.FC<{ label: string; value: string; highlight?: boolean }> = ({ label, value, highlight }) => (
  <div className={`p-3 rounded-xl border ${highlight
    ? 'bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800'
    : 'bg-slate-50 dark:bg-slate-800/30 border-slate-200 dark:border-slate-800'}`}>
    <div className="text-[10px] font-bold uppercase text-slate-500 dark:text-slate-400 tracking-wider">{label}</div>
    <div className="text-base font-black text-slate-800 dark:text-white mt-0.5">{value}</div>
  </div>
);

const Section: React.FC<{ title: string; icon: any; children: React.ReactNode }> = ({ title, icon: Icon, children }) => (
  <div>
    <div className="flex items-center gap-2 mb-3">
      <Icon size={16} className="text-indigo-600 dark:text-indigo-400" />
      <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-wider">{title}</h3>
    </div>
    {children}
  </div>
);

// =====================================================================
// ReferralsView — Tüm referans hareketleri (özet + çiftler)
// =====================================================================

interface ReferralsViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'warning') => void;
  onSelectUser: (uid: number) => void;
}

type ReferralStats = {
  total_invited: number;
  active_referrers: number;
  top_referrer: null | { id: number; full_name: string; email: string; ref_code: string | null; invited_count: number };
};

const ReferralsView: React.FC<ReferralsViewProps> = ({ showToast, onSelectUser }) => {
  const [view, setView] = useState<'summary' | 'pairs'>('summary');
  const [summary, setSummary] = useState<ReferrerSummary[]>([]);
  const [pairs, setPairs] = useState<ReferralPair[]>([]);
  const [stats, setStats] = useState<ReferralStats | null>(null);
  const [loadingS, setLoadingS] = useState(false);
  const [loadingP, setLoadingP] = useState(false);
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');

  const loadStats = useCallback(async () => {
    try {
      const r = await api.get('/superadmin/referrals/stats');
      setStats(r.data);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Referans istatistikleri yüklenemedi', 'error');
    }
  }, [showToast]);

  useEffect(() => { loadStats(); }, [loadStats]);

  const loadSummary = useCallback(async () => {
    setLoadingS(true);
    try {
      const r = await api.get('/superadmin/referrals/summary', {
        params: { page_size: 200, ...(search ? { search } : {}) },
      });
      setSummary(r.data.items || []);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Referans özeti yüklenemedi', 'error');
    } finally { setLoadingS(false); }
  }, [search, showToast]);

  const loadPairs = useCallback(async () => {
    setLoadingP(true);
    try {
      const r = await api.get('/superadmin/referrals/pairs', {
        params: { page_size: 300, ...(search ? { search } : {}) },
      });
      setPairs(r.data.items || []);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Referans hareketleri yüklenemedi', 'error');
    } finally { setLoadingP(false); }
  }, [search, showToast]);

  useEffect(() => {
    if (view === 'summary') loadSummary();
    else loadPairs();
  }, [view, loadSummary, loadPairs]);

  useEffect(() => {
    const id = setTimeout(() => setSearch(searchInput.trim()), 350);
    return () => clearTimeout(id);
  }, [searchInput]);

  return (
    <div className="space-y-4">
      {/* Üst stats — global, search'ten bağımsız */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-indigo-500 to-indigo-700 text-white p-5 rounded-2xl shadow-lg">
          <div className="flex items-center gap-2 text-indigo-100 text-xs font-bold uppercase mb-1"><Share2 size={14} /> Referansla Gelen</div>
          <div className="text-3xl font-black">{stats?.total_invited ?? '—'}</div>
          <div className="text-xs text-indigo-100 mt-1 font-medium">kullanıcı bir referans kodu ile geldi</div>
        </div>
        <div className="bg-gradient-to-br from-emerald-500 to-emerald-700 text-white p-5 rounded-2xl shadow-lg">
          <div className="flex items-center gap-2 text-emerald-100 text-xs font-bold uppercase mb-1"><Users size={14} /> Aktif Davet Eden</div>
          <div className="text-3xl font-black">{stats?.active_referrers ?? '—'}</div>
          <div className="text-xs text-emerald-100 mt-1 font-medium">kullanıcı en az 1 kişi davet etti</div>
        </div>
        <div className="bg-gradient-to-br from-amber-500 to-orange-600 text-white p-5 rounded-2xl shadow-lg">
          <div className="flex items-center gap-2 text-amber-100 text-xs font-bold uppercase mb-1"><Gift size={14} /> En Çok Davet Eden</div>
          {stats?.top_referrer ? (
            <button onClick={() => onSelectUser(stats.top_referrer!.id)} className="text-left w-full">
              <div className="text-xl font-black truncate hover:underline">{stats.top_referrer.full_name}</div>
              <div className="text-xs text-amber-100 mt-0.5 font-medium">{stats.top_referrer.invited_count} davet · {stats.top_referrer.ref_code || '—'}</div>
            </button>
          ) : (
            <div className="text-base font-bold text-amber-100 italic">Henüz kayıt yok</div>
          )}
        </div>
      </div>

      {/* Alt sekmeler */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center justify-between gap-3 p-4 border-b border-slate-200 dark:border-slate-800 flex-wrap">
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
            <button onClick={() => setView('summary')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition ${view === 'summary' ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-sm' : 'text-slate-600 dark:text-slate-300'}`}>
              Davet Edenler
            </button>
            <button onClick={() => setView('pairs')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition ${view === 'pairs' ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-sm' : 'text-slate-600 dark:text-slate-300'}`}>
              Tüm Hareketler
            </button>
          </div>
          <div className="relative flex-1 min-w-[220px] max-w-md">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder={view === 'summary' ? 'Davet eden ara (isim/email/kod)...' : 'Davet eden veya edilen ara...'}
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium outline-none focus:ring-2 focus:ring-indigo-500 text-slate-700 dark:text-slate-200"
            />
          </div>
        </div>

        {view === 'summary' && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800">
                <tr className="text-left text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400 tracking-wider">
                  <th className="px-4 py-3">#</th>
                  <th className="px-4 py-3">Davet Eden</th>
                  <th className="px-4 py-3">Referans Kodu</th>
                  <th className="px-4 py-3 text-right">Davet Sayısı</th>
                  <th className="px-4 py-3">Son Davet</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {loadingS && <tr><td colSpan={5} className="px-4 py-10 text-center text-slate-400 font-medium">Yükleniyor...</td></tr>}
                {!loadingS && summary.length === 0 && (
                  <tr><td colSpan={5} className="px-4 py-10 text-center text-slate-400 font-medium italic">
                    Henüz hiç kimse referans kodu kullanarak kayıt olmadı.
                  </td></tr>
                )}
                {!loadingS && summary.map((r, i) => (
                  <tr key={r.referrer_id} onClick={() => onSelectUser(r.referrer_id)}
                    className="hover:bg-indigo-50/40 dark:hover:bg-indigo-900/10 cursor-pointer transition">
                    <td className="px-4 py-3 text-xs font-bold text-slate-400">
                      {i === 0 && '🥇'} {i === 1 && '🥈'} {i === 2 && '🥉'} {i > 2 && (i + 1)}
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-bold text-slate-800 dark:text-white">{r.full_name}</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">{r.email}</div>
                      {r.company_name && <div className="text-[11px] text-slate-400">🏢 {r.company_name}</div>}
                    </td>
                    <td className="px-4 py-3">
                      {r.ref_code
                        ? <code className="px-2 py-1 bg-indigo-100 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300 rounded font-mono text-xs font-bold">{r.ref_code}</code>
                        : <span className="text-xs text-slate-400 italic">—</span>}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span className="inline-flex items-center justify-center min-w-[2.5rem] px-3 py-1 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 rounded-lg font-black text-sm">{r.invited_count}</span>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-500 dark:text-slate-400 font-medium">{formatDateTime(r.last_invited_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {view === 'pairs' && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800">
                <tr className="text-left text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400 tracking-wider">
                  <th className="px-4 py-3">Davet Eden</th>
                  <th className="px-4 py-3 text-center">→</th>
                  <th className="px-4 py-3">Davet Edilen</th>
                  <th className="px-4 py-3">Kullanılan Kod</th>
                  <th className="px-4 py-3">Tarih</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {loadingP && <tr><td colSpan={5} className="px-4 py-10 text-center text-slate-400 font-medium">Yükleniyor...</td></tr>}
                {!loadingP && pairs.length === 0 && (
                  <tr><td colSpan={5} className="px-4 py-10 text-center text-slate-400 font-medium italic">
                    Henüz referans hareketi yok.
                  </td></tr>
                )}
                {!loadingP && pairs.map(p => (
                  <tr key={p.invited_id} className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition">
                    <td className="px-4 py-3">
                      {p.inviter_id ? (
                        <button onClick={() => onSelectUser(p.inviter_id!)}
                          className="text-left hover:underline">
                          <div className="font-bold text-slate-700 dark:text-slate-200">{p.inviter_name}</div>
                          <div className="text-xs text-slate-500 dark:text-slate-400">{p.inviter_email}</div>
                        </button>
                      ) : <span className="text-xs text-slate-400 italic">Silinmiş kullanıcı</span>}
                    </td>
                    <td className="px-4 py-3 text-center text-indigo-400"><ArrowRight size={16} className="inline" /></td>
                    <td className="px-4 py-3">
                      <button onClick={() => onSelectUser(p.invited_id)}
                        className="text-left hover:underline">
                        <div className="font-bold text-slate-700 dark:text-slate-200 flex items-center gap-2">
                          {p.invited_name}
                          {!p.invited_active && <span className="text-[10px] px-1.5 py-0.5 bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300 rounded font-bold">PASİF</span>}
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400">{p.invited_email}</div>
                        {p.invited_company && <div className="text-[11px] text-slate-400">🏢 {p.invited_company}</div>}
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      {p.inviter_code
                        ? <code className="px-2 py-1 bg-indigo-100 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300 rounded font-mono text-xs font-bold">{p.inviter_code}</code>
                        : <span className="text-xs text-slate-400 italic">—</span>}
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-500 dark:text-slate-400 font-medium whitespace-nowrap">{formatDateTime(p.invited_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

// =====================================================================
// SubEventRow + SubscriptionsView
// =====================================================================

type SubEvent = {
  id: number;
  user_id: number;
  user_email: string | null;
  user_full_name: string | null;
  user_company: string | null;
  event_type: string;
  event_label: string;
  days_delta: number;
  days_before: number;
  days_after: number;
  actor_user_id: number | null;
  actor_full_name: string | null;
  actor_email: string | null;
  related_user_id: number | null;
  related_full_name: string | null;
  related_email: string | null;
  note: string | null;
  created_at: string;
};

const EVENT_STYLE: Record<string, { bg: string; text: string; icon: React.ReactNode; label?: string }> = {
  initial:                  { bg: 'bg-slate-100 dark:bg-slate-800',          text: 'text-slate-700 dark:text-slate-200', icon: <Calendar size={12} /> },
  referral_bonus_received:  { bg: 'bg-indigo-100 dark:bg-indigo-900/40',     text: 'text-indigo-700 dark:text-indigo-300', icon: <Gift size={12} /> },
  referral_bonus_given:     { bg: 'bg-purple-100 dark:bg-purple-900/40',     text: 'text-purple-700 dark:text-purple-300', icon: <Share2 size={12} /> },
  admin_adjust:             { bg: 'bg-amber-100 dark:bg-amber-900/40',       text: 'text-amber-700 dark:text-amber-300', icon: <Sparkles size={12} /> },
  admin_set:                { bg: 'bg-emerald-100 dark:bg-emerald-900/40',   text: 'text-emerald-700 dark:text-emerald-300', icon: <Sparkles size={12} /> },
};

const SubEventRow: React.FC<{ ev: SubEvent; onSelectActor?: (uid: number) => void }> = ({ ev, onSelectActor }) => {
  const style = EVENT_STYLE[ev.event_type] || { bg: 'bg-slate-100', text: 'text-slate-700', icon: <Sparkles size={12} /> };
  const positive = ev.days_delta > 0;
  return (
    <div className="p-3 bg-slate-50 dark:bg-slate-800/30 rounded-lg border border-slate-100 dark:border-slate-800">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2 flex-wrap">
          <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-bold uppercase tracking-wider ${style.bg} ${style.text}`}>
            {style.icon} {ev.event_label}
          </span>
          <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-black ${positive ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300' : 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300'}`}>
            {positive ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
            {positive ? '+' : ''}{ev.days_delta} gün
          </span>
          <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
            {ev.days_before} → <strong className="text-slate-700 dark:text-slate-200">{ev.days_after}</strong>
          </span>
        </div>
        <span className="text-[11px] text-slate-400">{formatDateTime(ev.created_at)}</span>
      </div>
      {ev.note && <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 font-medium">{ev.note}</p>}
      {(ev.actor_user_id || ev.related_user_id) && (
        <div className="flex items-center gap-3 text-[11px] text-slate-500 dark:text-slate-400 mt-2 flex-wrap">
          {ev.actor_user_id && (
            <span>
              👤 <strong>Yapan:</strong>{' '}
              {onSelectActor
                ? <button onClick={() => onSelectActor(ev.actor_user_id!)} className="hover:underline text-indigo-600 dark:text-indigo-400 font-bold">{ev.actor_full_name || ev.actor_email}</button>
                : <span className="font-bold text-slate-700 dark:text-slate-200">{ev.actor_full_name || ev.actor_email}</span>}
            </span>
          )}
          {ev.related_user_id && (
            <span>
              🔗 <strong>İlgili:</strong>{' '}
              {onSelectActor
                ? <button onClick={() => onSelectActor(ev.related_user_id!)} className="hover:underline text-indigo-600 dark:text-indigo-400 font-bold">{ev.related_full_name || ev.related_email}</button>
                : <span className="font-bold text-slate-700 dark:text-slate-200">{ev.related_full_name || ev.related_email}</span>}
            </span>
          )}
        </div>
      )}
    </div>
  );
};

interface SubscriptionsViewProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'warning') => void;
  onSelectUser: (uid: number) => void;
}

type SubStats = {
  period_days: number;
  total_events: number;
  total_days_added: number;
  total_days_removed: number;
  net_days_change: number;
  distinct_users: number;
  by_type: Array<{ event_type: string; event_label: string; count: number; days_total: number }>;
  top_user: null | { id: number; full_name: string; email: string; ref_code: string | null; days_added_in_period: number; events_in_period: number; current_sub_days: number };
};

const PERIOD_OPTIONS = [
  { v: 7, label: '7 gün' },
  { v: 30, label: '30 gün' },
  { v: 90, label: '90 gün' },
  { v: 365, label: '1 yıl' },
];

const TYPE_FILTERS = [
  { v: '', label: 'Tüm tipler' },
  { v: 'admin_adjust', label: 'Yönetici Ekledi/Düştü' },
  { v: 'admin_set', label: 'Yönetici Set Etti' },
  { v: 'referral_bonus_received', label: 'Referans Bonusu Alındı' },
  { v: 'referral_bonus_given', label: 'Referans Bonusu Verildi' },
  { v: 'initial', label: 'İlk Kayıt' },
];

const SubscriptionsView: React.FC<SubscriptionsViewProps> = ({ showToast, onSelectUser }) => {
  const [period, setPeriod] = useState(30);
  const [typeFilter, setTypeFilter] = useState('');
  const [onlyPositive, setOnlyPositive] = useState(false);
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [stats, setStats] = useState<SubStats | null>(null);
  const [events, setEvents] = useState<SubEvent[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const id = setTimeout(() => setSearch(searchInput.trim()), 350);
    return () => clearTimeout(id);
  }, [searchInput]);

  const loadStats = useCallback(async () => {
    try {
      const r = await api.get('/superadmin/subscription/stats', { params: { days: period } });
      setStats(r.data);
    } catch (e: any) { showToast(e?.response?.data?.detail || 'İstatistik yüklenemedi', 'error'); }
  }, [period, showToast]);

  const loadEvents = useCallback(async () => {
    setLoading(true);
    try {
      const params: any = { page_size: 200, days: period };
      if (typeFilter) params.event_type = typeFilter;
      if (onlyPositive) params.only_positive = true;
      if (search) params.search = search;
      const r = await api.get('/superadmin/subscription/events', { params });
      setEvents(r.data.items || []);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Hareketler yüklenemedi', 'error');
    } finally { setLoading(false); }
  }, [period, typeFilter, onlyPositive, search, showToast]);

  useEffect(() => { loadStats(); }, [loadStats]);
  useEffect(() => { loadEvents(); }, [loadEvents]);

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-gradient-to-br from-emerald-500 to-emerald-700 text-white p-5 rounded-2xl shadow-lg">
          <div className="flex items-center gap-2 text-emerald-100 text-xs font-bold uppercase mb-1"><TrendingUp size={14} /> Eklenen Gün</div>
          <div className="text-3xl font-black">+{stats?.total_days_added ?? 0}</div>
          <div className="text-xs text-emerald-100 mt-1 font-medium">son {period} günde</div>
        </div>
        <div className="bg-gradient-to-br from-red-500 to-red-700 text-white p-5 rounded-2xl shadow-lg">
          <div className="flex items-center gap-2 text-red-100 text-xs font-bold uppercase mb-1"><TrendingDown size={14} /> Düşen Gün</div>
          <div className="text-3xl font-black">{stats?.total_days_removed ?? 0}</div>
          <div className="text-xs text-red-100 mt-1 font-medium">manuel veya otomatik düşüş</div>
        </div>
        <div className="bg-gradient-to-br from-indigo-500 to-indigo-700 text-white p-5 rounded-2xl shadow-lg">
          <div className="flex items-center gap-2 text-indigo-100 text-xs font-bold uppercase mb-1"><Users size={14} /> Etkilenen Bayı</div>
          <div className="text-3xl font-black">{stats?.distinct_users ?? 0}</div>
          <div className="text-xs text-indigo-100 mt-1 font-medium">{stats?.total_events ?? 0} hareket</div>
        </div>
        <div className="bg-gradient-to-br from-amber-500 to-orange-600 text-white p-5 rounded-2xl shadow-lg">
          <div className="flex items-center gap-2 text-amber-100 text-xs font-bold uppercase mb-1"><Sparkles size={14} /> En Çok Süre Kazanan</div>
          {stats?.top_user ? (
            <button onClick={() => onSelectUser(stats.top_user!.id)} className="text-left w-full">
              <div className="text-base font-black truncate hover:underline">{stats.top_user.full_name}</div>
              <div className="text-[11px] text-amber-100 mt-0.5 font-medium">+{stats.top_user.days_added_in_period} gün · {stats.top_user.events_in_period} hareket · şu an {stats.top_user.current_sub_days}g</div>
            </button>
          ) : (
            <div className="text-base font-bold text-amber-100 italic">Bu dönemde hareket yok</div>
          )}
        </div>
      </div>

      {/* By type breakdown */}
      {stats && stats.by_type.length > 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4">
          <h4 className="text-xs font-black uppercase text-slate-500 dark:text-slate-400 mb-3 tracking-wider">Hareket Tipine Göre</h4>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2">
            {stats.by_type.map(t => (
              <button key={t.event_type}
                onClick={() => setTypeFilter(typeFilter === t.event_type ? '' : t.event_type)}
                className={`p-3 rounded-xl border text-left transition ${typeFilter === t.event_type
                  ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/30'
                  : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/30'}`}>
                <div className="text-[10px] font-bold uppercase text-slate-500 dark:text-slate-400 tracking-wider mb-1">{t.event_label}</div>
                <div className="flex items-baseline gap-2">
                  <span className="text-xl font-black text-slate-800 dark:text-white">{t.count}</span>
                  <span className={`text-xs font-bold ${t.days_total >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
                    {t.days_total >= 0 ? '+' : ''}{t.days_total}g
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Filters + Liste */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
            {PERIOD_OPTIONS.map(p => (
              <button key={p.v} onClick={() => setPeriod(p.v)}
                className={`px-3 py-1 rounded-md text-xs font-bold transition ${period === p.v ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-sm' : 'text-slate-600 dark:text-slate-300'}`}>
                {p.label}
              </button>
            ))}
          </div>

          <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold outline-none text-slate-700 dark:text-slate-200">
            {TYPE_FILTERS.map(t => <option key={t.v} value={t.v}>{t.label}</option>)}
          </select>

          <label className="flex items-center gap-2 text-xs font-bold text-slate-600 dark:text-slate-300 cursor-pointer">
            <input type="checkbox" checked={onlyPositive} onChange={(e) => setOnlyPositive(e.target.checked)}
              className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500" />
            Sadece artışlar
          </label>

          <div className="relative flex-1 min-w-[200px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input type="text"
              placeholder="Bayı/email/açıklama ara..."
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium outline-none focus:ring-2 focus:ring-indigo-500 text-slate-700 dark:text-slate-200" />
          </div>

          <button onClick={() => { loadStats(); loadEvents(); }} className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700">
            <RefreshCw size={14} className="text-slate-600 dark:text-slate-300" />
          </button>
          <button
            onClick={() => exportAbonelikler(events.map((ev: any) => ({
              full_name: ev.user_full_name ?? ev.user_name ?? '',
              email: ev.user_email ?? '',
              company_name: ev.company_name ?? '',
              sub_days: ev.days_delta ?? ev.delta_days ?? '',
              sub_expires_at: ev.expires_at ?? '',
              is_active: ev.is_active ?? true,
              created_at: ev.created_at ?? '',
            })))}
            disabled={events.length === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded-lg transition text-xs shrink-0"
          >
            <Download size={13} /> Excel
          </button>
        </div>

        <div className="p-4">
          {loading && <div className="text-center text-slate-400 font-medium py-10">Yükleniyor...</div>}
          {!loading && events.length === 0 && (
            <div className="text-center text-slate-400 font-medium py-10 italic">
              Bu filtrelere uygun abonelik hareketi bulunamadı.
            </div>
          )}
          {!loading && events.length > 0 && (
            <div className="space-y-3">
              {events.map(ev => (
                <div key={ev.id} className="border border-slate-200 dark:border-slate-800 rounded-xl p-3 hover:bg-slate-50 dark:hover:bg-slate-800/30 transition">
                  <div className="flex items-start justify-between gap-3 mb-2 flex-wrap">
                    <button onClick={() => onSelectUser(ev.user_id)} className="text-left hover:underline">
                      <div className="font-black text-slate-800 dark:text-white">{ev.user_full_name || '—'}</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">{ev.user_email}</div>
                      {ev.user_company && <div className="text-[11px] text-slate-400">🏢 {ev.user_company}</div>}
                    </button>
                  </div>
                  <SubEventRow ev={ev} onSelectActor={onSelectUser} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// =====================================================================
// Paketler Yönetimi (3 paket: starter, pro, premium)
// =====================================================================
const PackagesView: React.FC<{ showToast: (msg: string, type?: any) => void }> = ({ showToast }) => {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Record<string, any>>({});
  const [savingSlug, setSavingSlug] = useState<string | null>(null);

  const reload = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api.get('/superadmin/packages');
      setItems(r.data || []);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Paketler yüklenemedi', 'error');
    } finally { setLoading(false); }
  }, [showToast]);

  useEffect(() => { reload(); }, [reload]);

  const setField = (slug: string, key: string, val: any) => {
    setEditing(prev => ({ ...prev, [slug]: { ...(prev[slug] || {}), [key]: val } }));
  };

  const save = async (pkg: any) => {
    const patch = editing[pkg.slug] || {};
    if (Object.keys(patch).length === 0) { showToast('Değişiklik yok', 'info'); return; }
    setSavingSlug(pkg.slug);
    try {
      await api.patch(`/superadmin/packages/${pkg.slug}`, patch);
      showToast('Paket güncellendi', 'success');
      setEditing(prev => { const c = { ...prev }; delete c[pkg.slug]; return c; });
      await reload();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Kaydedilemedi', 'error');
    } finally { setSavingSlug(null); }
  };

  if (loading) return <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl text-center text-slate-500">Yükleniyor…</div>;

  return (
    <div className="space-y-4">
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 text-sm text-slate-600 dark:text-slate-300">
        Paket fiyat ve kotalarını buradan güncelleyebilirsiniz. Kullanıcılar bu paketleri abonelik sayfasında görür.
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {items.map(pkg => {
          const ed = editing[pkg.slug] || {};
          const cur = {
            max_products_unlimited: pkg.max_products === null,
            max_transactions_unlimited: pkg.max_transactions === null,
            max_support_tickets_unlimited: pkg.max_support_tickets === null,
            ...pkg,
            ...ed,
          };
          const dirty = !!editing[pkg.slug] && Object.keys(editing[pkg.slug]).length > 0;
          return (
            <div key={pkg.slug} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col">
              <div className={`px-5 py-3 ${pkg.color_class === 'amber' ? 'bg-amber-50 dark:bg-amber-900/20' : pkg.color_class === 'indigo' ? 'bg-indigo-50 dark:bg-indigo-900/20' : 'bg-slate-50 dark:bg-slate-800/30'} border-b border-slate-200 dark:border-slate-800 flex justify-between items-center`}>
                <div>
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">{pkg.slug}</p>
                  <p className="font-black text-slate-800 dark:text-white">{pkg.name}</p>
                </div>
                {pkg.is_featured && <Sparkles size={18} className="text-amber-500"/>}
              </div>
              <div className="p-4 space-y-3 flex-1">
                <Field label="Görünen Ad" value={cur.name} onChange={(v) => setField(pkg.slug, 'name', v)} />
                <Field label="Açıklama" value={cur.description || ''} onChange={(v) => setField(pkg.slug, 'description', v)} />
                <div className="grid grid-cols-2 gap-3">
                  <Field type="number" label="Fiyat (₺)" value={cur.price_try} onChange={(v) => setField(pkg.slug, 'price_try', Number(v))} />
                  <Field type="number" label="Süre (gün)" value={cur.duration_days} onChange={(v) => setField(pkg.slug, 'duration_days', Number(v))} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Field type="number" label="Ürün Limiti" value={cur.max_products ?? 0} onChange={(v) => setField(pkg.slug, 'max_products', Number(v))} disabled={!!cur.max_products_unlimited} />
                  <label className="flex items-center gap-2 mt-6 text-xs font-bold text-slate-600 dark:text-slate-300">
                    <input type="checkbox" checked={!!cur.max_products_unlimited} onChange={(e) => setField(pkg.slug, 'max_products_unlimited', e.target.checked)} />
                    Sınırsız Ürün
                  </label>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Field type="number" label="Finans Limiti" value={cur.max_transactions ?? 0} onChange={(v) => setField(pkg.slug, 'max_transactions', Number(v))} disabled={!!cur.max_transactions_unlimited} />
                  <label className="flex items-center gap-2 mt-6 text-xs font-bold text-slate-600 dark:text-slate-300">
                    <input type="checkbox" checked={!!cur.max_transactions_unlimited} onChange={(e) => setField(pkg.slug, 'max_transactions_unlimited', e.target.checked)} />
                    Sınırsız Finans
                  </label>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Field type="number" label="Aylık Destek Limiti" value={cur.max_support_tickets ?? 0} onChange={(v) => setField(pkg.slug, 'max_support_tickets', Number(v))} disabled={!!cur.max_support_tickets_unlimited} />
                  <label className="flex items-center gap-2 mt-6 text-xs font-bold text-slate-600 dark:text-slate-300">
                    <input type="checkbox" checked={!!cur.max_support_tickets_unlimited} onChange={(e) => setField(pkg.slug, 'max_support_tickets_unlimited', e.target.checked)} />
                    Sınırsız Destek
                  </label>
                </div>
                <label className="flex items-center gap-2 text-xs font-bold text-slate-600 dark:text-slate-300">
                  <input type="checkbox" checked={!!cur.is_active} onChange={(e) => setField(pkg.slug, 'is_active', e.target.checked)} />
                  Aktif (kullanıcılar görebilir)
                </label>
              </div>
              <div className="px-4 py-3 border-t border-slate-200 dark:border-slate-800">
                <button disabled={!dirty || savingSlug === pkg.slug}
                  onClick={() => save(pkg)}
                  className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 bg-indigo-600 text-white font-bold text-sm rounded-lg hover:bg-indigo-700 transition disabled:opacity-50 disabled:cursor-not-allowed">
                  <Save size={15}/> {savingSlug === pkg.slug ? 'Kaydediliyor…' : 'Kaydet'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const Field: React.FC<{ label: string; value: any; onChange: (v: any) => void; type?: string; disabled?: boolean }> = ({ label, value, onChange, type = 'text', disabled }) => (
  <div>
    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">{label}</label>
    <input type={type} value={value ?? ''} onChange={(e) => onChange(e.target.value)} disabled={disabled}
      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"/>
  </div>
);

// =====================================================================
// Ödemeler Listesi
// =====================================================================
const PaymentsView: React.FC<{ showToast: (msg: string, type?: any) => void; onSelectUser: (uid: number) => void }> = ({ showToast, onSelectUser }) => {
  const [items, setItems] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>({});
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const PAGE_SIZE = 50;

  const reload = useCallback(async () => {
    setLoading(true);
    try {
      const params: any = { page, page_size: PAGE_SIZE };
      if (statusFilter) params.status = statusFilter;
      const r = await api.get('/superadmin/payments', { params });
      setItems(r.data?.items || []);
      setTotal(r.data?.total || 0);
      setSummary(r.data?.summary || {});
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Ödemeler yüklenemedi', 'error');
    } finally { setLoading(false); }
  }, [page, statusFilter, showToast]);

  useEffect(() => { reload(); }, [reload]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatBox label="Toplam Ödeme" value={total} tone="slate" />
        <StatBox label="Başarılı" value={summary.success_count ?? 0} tone="emerald" />
        <StatBox label="Başarısız" value={summary.failed_count ?? 0} tone="red" />
        <StatBox label="Tahsilat (₺)" value={(summary.total_revenue_try ?? 0).toLocaleString('tr-TR')} tone="indigo" />
      </div>
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3 mb-3">
          <select value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm font-bold text-slate-700 dark:text-slate-200">
            <option value="">Tüm durumlar</option>
            <option value="success">Başarılı</option>
            <option value="failed">Başarısız</option>
            <option value="pending">Beklemede</option>
          </select>
          <button onClick={() => reload()} className="px-3 py-2 bg-slate-100 dark:bg-slate-800 rounded-lg text-sm font-bold inline-flex items-center gap-2 text-slate-700 dark:text-slate-200 hover:bg-slate-200">
            <RefreshCw size={14}/> Yenile
          </button>
          <button
            onClick={() => exportOdemeler(items)}
            disabled={items.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded-lg transition text-sm"
          >
            <Download size={14}/> Excel
          </button>
        </div>
        {loading && <div className="text-center text-slate-500 py-8">Yükleniyor…</div>}
        {!loading && items.length === 0 && <div className="text-center text-slate-500 py-8">Henüz ödeme yok.</div>}
        {!loading && items.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-slate-500 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
                  <th className="py-2 pr-3">Tarih</th>
                  <th className="py-2 pr-3">Kullanıcı</th>
                  <th className="py-2 pr-3">Paket</th>
                  <th className="py-2 pr-3">Tutar</th>
                  <th className="py-2 pr-3">Durum</th>
                  <th className="py-2 pr-3">Ödeme No</th>
                </tr>
              </thead>
              <tbody>
                {items.map(p => (
                  <tr key={p.id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/30 cursor-pointer" onClick={() => onSelectUser(p.user_id)}>
                    <td className="py-2 pr-3 text-slate-600 dark:text-slate-400">{p.created_at ? new Date(p.created_at).toLocaleString('tr-TR') : '-'}</td>
                    <td className="py-2 pr-3 font-bold text-slate-800 dark:text-slate-200">{p.user_email || `#${p.user_id}`}</td>
                    <td className="py-2 pr-3 uppercase text-xs font-bold text-indigo-600 dark:text-indigo-400">{p.package_slug}</td>
                    <td className="py-2 pr-3 font-bold text-slate-800 dark:text-slate-100">{p.amount_try}₺</td>
                    <td className="py-2 pr-3">
                      <span className={`px-2 py-0.5 rounded text-xs font-bold ${p.status === 'success' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' : p.status === 'failed' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'}`}>
                        {p.status === 'success' ? 'Başarılı' : p.status === 'failed' ? 'Başarısız' : 'Beklemede'}
                      </span>
                    </td>
                    <td className="py-2 pr-3 text-xs text-slate-500 font-mono">{p.merchant_oid}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {totalPages > 1 && (
          <div className="flex items-center justify-between mt-4 text-sm">
            <span className="text-slate-500">Toplam {total}</span>
            <div className="flex items-center gap-2">
              <button disabled={page <= 1} onClick={() => setPage(p => Math.max(1, p - 1))} className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 disabled:opacity-50 inline-flex items-center gap-1"><ChevronLeft size={14}/> Önceki</button>
              <span className="text-slate-600 dark:text-slate-300 font-bold">{page} / {totalPages}</span>
              <button disabled={page >= totalPages} onClick={() => setPage(p => p + 1)} className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 disabled:opacity-50 inline-flex items-center gap-1">Sonraki <ChevronRight size={14}/></button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const StatBox: React.FC<{ label: string; value: any; tone?: string }> = ({ label, value, tone = 'slate' }) => {
  const toneMap: Record<string, string> = {
    slate: 'bg-slate-50 dark:bg-slate-800/40 text-slate-700 dark:text-slate-200',
    emerald: 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400',
    red: 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400',
    indigo: 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-400',
  };
  return (
    <div className={`p-4 rounded-2xl border border-slate-200 dark:border-slate-800 ${toneMap[tone]}`}>
      <p className="text-xs font-bold uppercase tracking-wider opacity-80">{label}</p>
      <p className="text-2xl font-black mt-1">{value}</p>
    </div>
  );
};

// =====================================================================
// PayTR Ayarları (merchant_id / key / salt + test_mode)
// =====================================================================
const PaytrSettingsView: React.FC<{ showToast: (msg: string, type?: any) => void }> = ({ showToast }) => {
  const [settings, setSettings] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [merchantId, setMerchantId] = useState('');
  const [merchantKey, setMerchantKey] = useState('');
  const [merchantSalt, setMerchantSalt] = useState('');
  const [testMode, setTestMode] = useState(true);
  const [showKey, setShowKey] = useState(false);
  const [showSalt, setShowSalt] = useState(false);

  const reload = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api.get('/superadmin/paytr');
      setSettings(r.data);
      setMerchantId(r.data?.merchant_id || '');
      setTestMode(!!r.data?.test_mode);
      setMerchantKey('');
      setMerchantSalt('');
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Ayarlar yüklenemedi', 'error');
    } finally { setLoading(false); }
  }, [showToast]);

  useEffect(() => { reload(); }, [reload]);

  const save = async () => {
    setSaving(true);
    try {
      const payload: any = { merchant_id: merchantId, test_mode: testMode };
      if (merchantKey.trim()) payload.merchant_key = merchantKey.trim();
      if (merchantSalt.trim()) payload.merchant_salt = merchantSalt.trim();
      await api.put('/superadmin/paytr', payload);
      showToast('PayTR ayarları kaydedildi', 'success');
      await reload();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Kaydedilemedi', 'error');
    } finally { setSaving(false); }
  };

  if (loading) return <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl text-center text-slate-500">Yükleniyor…</div>;

  return (
    <div className="max-w-2xl space-y-4">
      <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800/50 p-4 rounded-2xl text-sm text-amber-800 dark:text-amber-300">
        <b>Güvenlik:</b> Merchant Key ve Salt değerleri sunucuda şifresiz tutulur ancak hiçbir yerde geri görüntülenmez. Yeni değer girip Kaydet'e basmadığınız sürece mevcut değer korunur.
      </div>
      <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Merchant ID</label>
          <input value={merchantId} onChange={(e) => setMerchantId(e.target.value)} placeholder="123456"
            className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm font-mono text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"/>
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
            Merchant Key {settings?.merchant_key_masked && <span className="text-emerald-600 ml-2">(Tanımlı: {settings.merchant_key_masked})</span>}
          </label>
          <div className="relative">
            <input type={showKey ? 'text' : 'password'} value={merchantKey} onChange={(e) => setMerchantKey(e.target.value)} placeholder={settings?.merchant_key_masked ? 'Değiştirmek için yeni değer girin' : 'PayTR panelinden alın'}
              className="w-full px-3 py-2.5 pr-10 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm font-mono text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"/>
            <button type="button" onClick={() => setShowKey(s => !s)} className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700">{showKey ? <EyeOff size={16}/> : <Eye size={16}/>}</button>
          </div>
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
            Merchant Salt {settings?.merchant_salt_masked && <span className="text-emerald-600 ml-2">(Tanımlı: {settings.merchant_salt_masked})</span>}
          </label>
          <div className="relative">
            <input type={showSalt ? 'text' : 'password'} value={merchantSalt} onChange={(e) => setMerchantSalt(e.target.value)} placeholder={settings?.merchant_salt_masked ? 'Değiştirmek için yeni değer girin' : 'PayTR panelinden alın'}
              className="w-full px-3 py-2.5 pr-10 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm font-mono text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"/>
            <button type="button" onClick={() => setShowSalt(s => !s)} className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700">{showSalt ? <EyeOff size={16}/> : <Eye size={16}/>}</button>
          </div>
        </div>
        <label className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-200 dark:border-slate-700">
          <input type="checkbox" checked={testMode} onChange={(e) => setTestMode(e.target.checked)} />
          <div>
            <p className="text-sm font-bold text-slate-800 dark:text-slate-100">Test Modu</p>
            <p className="text-xs text-slate-500">Aktifken PayTR test ortamı kullanılır, gerçek kart ile çekim yapılmaz.</p>
          </div>
        </label>
        <div className="pt-2">
          <button disabled={saving} onClick={save} className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition disabled:opacity-50">
            <Save size={16}/> {saving ? 'Kaydediliyor…' : 'Ayarları Kaydet'}
          </button>
        </div>
      </div>
    </div>
  );
};

// ============================================================
// E-POSTA AYARLARI + KAYIT BİLDİRİMİ
// ============================================================

type SmtpSettings = {
  host: string; port: number; username: string; password_masked: string | null;
  from_email: string; from_name: string; use_tls: boolean; use_ssl: boolean;
  is_configured: boolean;
};
type RegisterNotice = {
  is_enabled: boolean; title: string; message: string; color: string;
};
type EmailTab = 'smtp' | 'notice' | 'terms';

const EmailSettingsView: React.FC<{ showToast: (msg: string, type?: any) => void }> = ({ showToast }) => {
  const [tab, setTab] = useState<EmailTab>('smtp');
  // SMTP state
  const [smtp, setSmtp] = useState<SmtpSettings | null>(null);
  const [smtpLoading, setSmtpLoading] = useState(true);
  const [smtpSaving, setSmtpSaving] = useState(false);
  const [smtpTesting, setSmtpTesting] = useState(false);
  const [testResult, setTestResult] = useState<{success:boolean;message:string}|null>(null);
  const [showPwd, setShowPwd] = useState(false);
  const [smtpForm, setSmtpForm] = useState({
    host:'', port:'587', username:'', password:'', from_email:'', from_name:'StokFinans',
    use_tls:true, use_ssl:false
  });
  // Notice state
  const [notice, setNotice] = useState<RegisterNotice | null>(null);
  const [noticeLoading, setNoticeLoading] = useState(true);
  const [noticeSaving, setNoticeSaving] = useState(false);
  const [noticeForm, setNoticeForm] = useState({
    is_enabled:false, title:'Duyuru', message:'', color:'indigo'
  });
  // Terms state
  const [termsLoading, setTermsLoading] = useState(true);
  const [termsSaving, setTermsSaving] = useState(false);
  const [termsForm, setTermsForm] = useState({ is_enabled: false, content: '' });

  useEffect(() => {
    api.get('/superadmin/smtp').then(r => {
      setSmtp(r.data);
      setSmtpForm({
        host: r.data.host || '',
        port: String(r.data.port || 587),
        username: r.data.username || '',
        password: '',
        from_email: r.data.from_email || '',
        from_name: r.data.from_name || 'StokFinans',
        use_tls: !!r.data.use_tls,
        use_ssl: !!r.data.use_ssl,
      });
    }).catch(() => {}).finally(() => setSmtpLoading(false));
    api.get('/superadmin/register-notice').then(r => {
      setNotice(r.data);
      setNoticeForm({
        is_enabled: !!r.data.is_enabled,
        title: r.data.title || '',
        message: r.data.message || '',
        color: r.data.color || 'indigo',
      });
    }).catch(() => {}).finally(() => setNoticeLoading(false));
    api.get('/superadmin/terms').then(r => {
      setTermsForm({ is_enabled: !!r.data.is_enabled, content: r.data.content || '' });
    }).catch(() => {}).finally(() => setTermsLoading(false));
  }, []);

  const saveSmtp = async () => {
    setSmtpSaving(true);
    try {
      const payload: any = {
        host: smtpForm.host.trim() || null,
        port: parseInt(smtpForm.port) || 587,
        username: smtpForm.username.trim() || null,
        from_email: smtpForm.from_email.trim() || null,
        from_name: smtpForm.from_name.trim() || 'StokFinans',
        use_tls: smtpForm.use_tls,
        use_ssl: smtpForm.use_ssl,
      };
      if (smtpForm.password.trim()) payload.password = smtpForm.password.trim();
      const r = await api.put('/superadmin/smtp', payload);
      setSmtp(r.data);
      showToast('SMTP ayarları kaydedildi', 'success');
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Kayıt hatası', 'error');
    } finally { setSmtpSaving(false); }
  };

  const testSmtp = async () => {
    if (!smtpForm.host || !smtpForm.username) {
      showToast('Host ve kullanıcı adı gerekli', 'error'); return;
    }
    const pwd = smtpForm.password.trim() || '(mevcut şifre)';
    if (!smtpForm.password.trim() && !smtp?.password_masked) {
      showToast('Şifre giriniz', 'error'); return;
    }
    setSmtpTesting(true); setTestResult(null);
    try {
      const r = await api.post('/superadmin/smtp/test', {
        host: smtpForm.host, port: parseInt(smtpForm.port) || 587,
        username: smtpForm.username, password: smtpForm.password.trim() || '__use_saved__',
        use_tls: smtpForm.use_tls, use_ssl: smtpForm.use_ssl,
      });
      setTestResult(r.data);
    } catch (e: any) {
      setTestResult({ success: false, message: e.response?.data?.detail || 'Bağlantı hatası' });
    } finally { setSmtpTesting(false); }
  };

  const saveNotice = async () => {
    setNoticeSaving(true);
    try {
      const r = await api.put('/superadmin/register-notice', noticeForm);
      setNotice(r.data);
      showToast('Kayıt bildirimi kaydedildi', 'success');
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Kayıt hatası', 'error');
    } finally { setNoticeSaving(false); }
  };

  const saveTerms = async () => {
    setTermsSaving(true);
    try {
      await api.put('/superadmin/terms', termsForm);
      showToast('Site şartları kaydedildi', 'success');
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Kayıt hatası', 'error');
    } finally { setTermsSaving(false); }
  };

  const inputCls = "w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500";
  const labelCls = "block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wide";

  const colorOptions = ['indigo','sky','green','amber','red'];

  return (
    <div className="space-y-4">
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="flex border-b border-slate-200 dark:border-slate-800">
          <button onClick={() => setTab('smtp')} className={`flex items-center gap-2 px-5 py-3.5 text-sm font-bold transition border-b-2 ${tab === 'smtp' ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}>
            <Mail size={15}/> SMTP Ayarları
          </button>
          <button onClick={() => setTab('notice')} className={`flex items-center gap-2 px-5 py-3.5 text-sm font-bold transition border-b-2 ${tab === 'notice' ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}>
            <Bell size={15}/> Kayıt Bildirimi
          </button>
          <button onClick={() => setTab('terms')} className={`flex items-center gap-2 px-5 py-3.5 text-sm font-bold transition border-b-2 ${tab === 'terms' ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}>
            <FileText size={15}/> Site Şartları
          </button>
        </div>

        {/* ── SMTP ────────────────────────────────── */}
        {tab === 'smtp' && (
          <div className="p-6">
            {smtpLoading ? (
              <div className="text-center py-8 text-slate-400">Yükleniyor...</div>
            ) : (
              <>
                <div className="flex items-center gap-2 mb-4">
                  <div className={`w-2.5 h-2.5 rounded-full ${smtp?.is_configured ? 'bg-green-500' : 'bg-slate-300'}`}/>
                  <span className="text-sm font-semibold text-slate-600 dark:text-slate-300">
                    {smtp?.is_configured ? 'SMTP Yapılandırılmış — E-posta doğrulama aktif' : 'SMTP Yapılandırılmamış — E-posta doğrulama devre dışı'}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                  <div className="sm:col-span-2">
                    <label className={labelCls}>SMTP Sunucusu (Host)</label>
                    <input className={inputCls} placeholder="smtp.gmail.com" value={smtpForm.host}
                      onChange={e => setSmtpForm(f=>({...f, host:e.target.value}))} />
                  </div>
                  <div>
                    <label className={labelCls}>Port</label>
                    <input className={inputCls} type="number" placeholder="587" value={smtpForm.port}
                      onChange={e => setSmtpForm(f=>({...f, port:e.target.value}))} />
                  </div>
                  <div>
                    <label className={labelCls}>Kullanıcı Adı / E-posta</label>
                    <input className={inputCls} placeholder="gonderici@domain.com" value={smtpForm.username}
                      onChange={e => setSmtpForm(f=>({...f, username:e.target.value}))} />
                  </div>
                  <div>
                    <label className={labelCls}>Şifre {smtp?.password_masked && <span className="font-normal normal-case">(Tanımlı: {smtp.password_masked})</span>}</label>
                    <div className="relative">
                      <input className={inputCls + ' pr-10'} type={showPwd ? 'text' : 'password'}
                        placeholder={smtp?.password_masked ? 'Değiştirmek için girin' : 'Şifre'}
                        value={smtpForm.password}
                        onChange={e => setSmtpForm(f=>({...f, password:e.target.value}))} />
                      <button type="button" onClick={() => setShowPwd(v=>!v)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                        {showPwd ? <EyeOff size={15}/> : <Eye size={15}/>}
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className={labelCls}>Gönderen E-posta</label>
                    <input className={inputCls} placeholder="noreply@domain.com" value={smtpForm.from_email}
                      onChange={e => setSmtpForm(f=>({...f, from_email:e.target.value}))} />
                  </div>
                  <div>
                    <label className={labelCls}>Gönderen Adı</label>
                    <input className={inputCls} placeholder="StokFinans" value={smtpForm.from_name}
                      onChange={e => setSmtpForm(f=>({...f, from_name:e.target.value}))} />
                  </div>
                  <div className="sm:col-span-2 flex gap-6">
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input type="checkbox" checked={smtpForm.use_tls} onChange={e => setSmtpForm(f=>({...f, use_tls:e.target.checked}))}
                        className="w-4 h-4 rounded accent-indigo-600" />
                      <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">STARTTLS (port 587)</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input type="checkbox" checked={smtpForm.use_ssl} onChange={e => setSmtpForm(f=>({...f, use_ssl:e.target.checked}))}
                        className="w-4 h-4 rounded accent-indigo-600" />
                      <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">SSL/TLS (port 465)</span>
                    </label>
                  </div>
                </div>

                {testResult && (
                  <div className={`mb-4 p-3 rounded-xl border text-sm font-semibold flex items-center gap-2 ${testResult.success ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-700 text-green-700 dark:text-green-300' : 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-700 text-red-700 dark:text-red-300'}`}>
                    {testResult.success ? <CheckCircle size={15}/> : <Mail size={15}/>}
                    {testResult.message}
                  </div>
                )}

                <div className="flex gap-3">
                  <button onClick={testSmtp} disabled={smtpTesting}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl border border-indigo-200 dark:border-indigo-700 text-indigo-600 dark:text-indigo-400 text-sm font-bold hover:bg-indigo-50 dark:hover:bg-indigo-900/20 disabled:opacity-50 transition">
                    <Send size={14}/> {smtpTesting ? 'Test ediliyor...' : 'Bağlantıyı Test Et'}
                  </button>
                  <button onClick={saveSmtp} disabled={smtpSaving}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-bold hover:bg-indigo-700 disabled:opacity-50 transition">
                    <Save size={14}/> {smtpSaving ? 'Kaydediliyor...' : 'Kaydet'}
                  </button>
                </div>
              </>
            )}
          </div>
        )}

        {/* ── NOTICE ──────────────────────────────── */}
        {tab === 'terms' && (
          <div className="p-6">
            {termsLoading ? (
              <div className="text-center py-8 text-slate-400">Yükleniyor...</div>
            ) : (
              <>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                  Kayıt formunda gösterilecek "Okudum, onaylıyorum" kutucuğu içeriğini düzenleyin. Aktifken kullanıcılar kutuyu işaretlemeden kayıt olamaz.
                </p>
                <div className="space-y-4">
                  <div>
                    <label className="flex items-center gap-3 cursor-pointer select-none">
                      <button type="button" onClick={() => setTermsForm(f=>({...f, is_enabled:!f.is_enabled}))}
                        className={`transition-colors ${termsForm.is_enabled ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-300 dark:text-slate-600'}`}>
                        {termsForm.is_enabled ? <ToggleRight size={28}/> : <ToggleLeft size={28}/>}
                      </button>
                      <span className="text-sm font-bold text-slate-700 dark:text-slate-200">
                        {termsForm.is_enabled ? 'Aktif — Kayıt formunda gösteriliyor' : 'Devre Dışı'}
                      </span>
                    </label>
                  </div>
                  <div>
                    <label className={labelCls}>Şartlar & Koşullar Metni</label>
                    <textarea
                      className={inputCls + ' resize-none h-48'}
                      placeholder="Kullanım şartları, gizlilik politikası ve diğer koşullar burada yer alacak..."
                      value={termsForm.content}
                      onChange={e => setTermsForm(f=>({...f, content:e.target.value}))}
                    />
                    <p className="mt-1 text-xs text-slate-400 dark:text-slate-500">
                      Kullanıcılar kayıt formunda bu metni okuyup onaylayacak.
                    </p>
                  </div>
                  {termsForm.is_enabled && termsForm.content && (
                    <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 max-h-36 overflow-y-auto whitespace-pre-wrap">
                      {termsForm.content}
                    </div>
                  )}
                </div>
                <div className="mt-5">
                  <button onClick={saveTerms} disabled={termsSaving}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-bold hover:bg-indigo-700 disabled:opacity-50 transition">
                    <Save size={14}/> {termsSaving ? 'Kaydediliyor...' : 'Kaydet'}
                  </button>
                </div>
              </>
            )}
          </div>
        )}

        {tab === 'notice' && (
          <div className="p-6">
            {noticeLoading ? (
              <div className="text-center py-8 text-slate-400">Yükleniyor...</div>
            ) : (
              <>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                  Kayıt sayfasında kullanıcılara gösterilecek bilgi/duyuru kutusunu yapılandırın.
                </p>
                <div className="space-y-4">
                  <div>
                    <label className="flex items-center gap-3 cursor-pointer select-none">
                      <button type="button" onClick={() => setNoticeForm(f=>({...f, is_enabled:!f.is_enabled}))}
                        className={`transition-colors ${noticeForm.is_enabled ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-300 dark:text-slate-600'}`}>
                        {noticeForm.is_enabled ? <ToggleRight size={28}/> : <ToggleLeft size={28}/>}
                      </button>
                      <span className="text-sm font-bold text-slate-700 dark:text-slate-200">
                        {noticeForm.is_enabled ? 'Aktif — Kayıt sayfasında gösteriliyor' : 'Devre Dışı'}
                      </span>
                    </label>
                  </div>
                  <div>
                    <label className={labelCls}>Başlık</label>
                    <input className={inputCls} placeholder="Duyuru" value={noticeForm.title}
                      onChange={e => setNoticeForm(f=>({...f, title:e.target.value}))} />
                  </div>
                  <div>
                    <label className={labelCls}>Mesaj</label>
                    <textarea className={inputCls + ' resize-none h-24'} placeholder="Kayıt sayfasında gösterilecek mesaj..."
                      value={noticeForm.message}
                      onChange={e => setNoticeForm(f=>({...f, message:e.target.value}))} />
                  </div>
                  <div>
                    <label className={labelCls}>Renk</label>
                    <div className="flex gap-2 flex-wrap">
                      {colorOptions.map(c => (
                        <button key={c} type="button" onClick={() => setNoticeForm(f=>({...f, color:c}))}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold border-2 transition capitalize ${noticeForm.color === c ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400' : 'border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-indigo-300'}`}>
                          {c}
                        </button>
                      ))}
                    </div>
                  </div>
                  {noticeForm.is_enabled && noticeForm.message && (
                    <div className={`p-3.5 rounded-xl border text-sm ${
                      noticeForm.color === 'indigo' ? 'bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200 dark:border-indigo-700 text-indigo-800 dark:text-indigo-300' :
                      noticeForm.color === 'green'  ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-700 text-green-800 dark:text-green-300' :
                      noticeForm.color === 'amber'  ? 'bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-700 text-amber-800 dark:text-amber-300' :
                      noticeForm.color === 'red'    ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-700 text-red-800 dark:text-red-300' :
                                                      'bg-sky-50 dark:bg-sky-900/20 border-sky-200 dark:border-sky-700 text-sky-800 dark:text-sky-300'
                    }`}>
                      {noticeForm.title && <p className="font-bold mb-0.5">{noticeForm.title}</p>}
                      <p style={{whiteSpace:'pre-line'}}>{noticeForm.message}</p>
                    </div>
                  )}
                </div>
                <div className="mt-5">
                  <button onClick={saveNotice} disabled={noticeSaving}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-bold hover:bg-indigo-700 disabled:opacity-50 transition">
                    <Save size={14}/> {noticeSaving ? 'Kaydediliyor...' : 'Kaydet'}
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

// ====================== Bayi Yedekleri (SuperAdmin) ======================
const BayiBackupsView: React.FC<{ showToast: (msg: string, type?: any) => void }> = ({ showToast }) => {
  const [backups, setBackups] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const [confirmDelete, setConfirmDelete] = useState<any>(null);
  const [uploadTarget, setUploadTarget] = useState<any>(null); // backup row
  const [ftpServers, setFtpServers] = useState<any[]>([]);
  const [uploading, setUploading] = useState(false);

  // Bayi seçimli yedek
  const [bayiList, setBayiList] = useState<any[]>([]);
  const [bayiLoading, setBayiLoading] = useState(false);
  const [creatingFor, setCreatingFor] = useState<number | null>(null);
  const [bayiSearch, setBayiSearch] = useState('');

  const load = async () => {
    setLoading(true);
    try {
      const r = await api.get('/superadmin/backups');
      setBackups(r.data || []);
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Yedekler yüklenemedi', 'error');
    } finally { setLoading(false); }
  };

  const loadBayiList = async () => {
    setBayiLoading(true);
    try {
      const r = await api.get('/backup/admin/list-users');
      setBayiList(r.data || []);
    } catch { /* sessizce yoksay */ } finally { setBayiLoading(false); }
  };

  const createBackupFor = async (userId: number, companyName: string) => {
    setCreatingFor(userId);
    try {
      const r = await api.post(`/backup/admin/create-for-user/${userId}`);
      const used = r.data?.backups_used ?? '?';
      const max = r.data?.backups_max ?? 3;
      showToast(`${companyName} için yedek oluşturuldu (${used}/${max} sunucu yedeği)`, 'success');
      await Promise.all([load(), loadBayiList()]);
      const backupId = r.data?.id;
      if (backupId) {
        const dl = await api.get(`/superadmin/backups/${backupId}/download`, { responseType: 'blob' });
        const blob = new Blob([dl.data], { type: 'application/octet-stream' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = r.data?.filename || `yedek-${userId}.sfb`;
        document.body.appendChild(a); a.click(); a.remove();
        window.URL.revokeObjectURL(url);
      }
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Yedek oluşturulamadı', 'error');
    } finally { setCreatingFor(null); }
  };

  const loadFtpServers = async () => {
    try {
      const r = await api.get('/superadmin/ftp-servers');
      setFtpServers((r.data || []).filter((s: any) => s.is_active));
    } catch { /* yoksa boş kalır */ }
  };

  const uploadToFtp = async (backupId: string, serverId: number) => {
    setUploading(true);
    try {
      const r = await api.post(`/superadmin/backups/${backupId}/upload-ftp/${serverId}`);
      showToast(`FTP'ye yüklendi: ${r.data?.remote_path || 'ok'}`, 'success');
      setUploadTarget(null);
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'FTP yükleme başarısız', 'error');
    } finally {
      setUploading(false);
    }
  };

  useEffect(() => { load(); loadFtpServers(); loadBayiList(); }, []);

  const fmtSize = (n: number) => {
    if (!n) return '0 B';
    const u = ['B','KB','MB','GB'];
    let i = 0; let v = n;
    while (v >= 1024 && i < u.length-1) { v /= 1024; i++; }
    return `${v.toFixed(v < 10 ? 2 : 1)} ${u[i]}`;
  };

  const fmtDate = (s: string) => {
    try { return new Date(s).toLocaleString('tr-TR'); } catch { return s; }
  };

  const download = async (b: any) => {
    try {
      const r = await api.get(`/superadmin/backups/${b.id}/download`, { responseType: 'blob' });
      const blob = new Blob([r.data], { type: 'application/octet-stream' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = b.filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'İndirme başarısız', 'error');
    }
  };

  const remove = async (b: any) => {
    try {
      await api.delete(`/superadmin/backups/${b.id}`);
      showToast('Yedek silindi', 'success');
      setConfirmDelete(null);
      await load();
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Silme başarısız', 'error');
    }
  };

  const copyPwd = async (pwd: string) => {
    try {
      await navigator.clipboard.writeText(pwd);
      showToast('Şifre kopyalandı', 'success');
    } catch {
      showToast('Kopyalama başarısız', 'error');
    }
  };

  const filtered = backups.filter(b => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (b.user_email || '').toLowerCase().includes(q)
      || (b.company_name || '').toLowerCase().includes(q)
      || (b.filename || '').toLowerCase().includes(q);
  });

  const filteredBayiList = bayiList.filter(u => {
    if (!bayiSearch.trim()) return true;
    const q = bayiSearch.toLowerCase();
    return (u.company_name || '').toLowerCase().includes(q) || (u.email || '').toLowerCase().includes(q);
  });

  return (
    <div className="space-y-4">

      {/* ── Bayi Seçimli Yedek Paneli ── */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Users size={18} className="text-indigo-500"/>
            <span className="font-bold text-slate-800 dark:text-slate-100">Bayi Seçimli Yedek Al</span>
            <span className="text-xs text-slate-400 ml-1">{bayiList.length} bayi</span>
          </div>
          <button onClick={loadBayiList} disabled={bayiLoading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm text-slate-500 hover:text-slate-700 dark:hover:text-slate-200">
            <RefreshCw size={13} className={bayiLoading ? 'animate-spin' : ''}/> Yenile
          </button>
        </div>

        {/* Arama */}
        <div className="relative mb-3">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
          <input value={bayiSearch} onChange={e => setBayiSearch(e.target.value)}
            placeholder="Bayi adı veya e-posta ara..."
            className="w-full pl-9 pr-3 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 outline-none focus:border-indigo-500"/>
        </div>

        {bayiLoading ? (
          <div className="py-6 text-center text-sm text-slate-400">Yükleniyor...</div>
        ) : filteredBayiList.length === 0 ? (
          <div className="py-6 text-center text-sm text-slate-400">Bayi bulunamadı.</div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-72 overflow-y-auto rounded-xl border border-slate-100 dark:border-slate-800">
            {filteredBayiList.map(u => (
              <div key={u.id} className="flex items-center justify-between px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-800/50">
                <div className="min-w-0">
                  <div className="font-semibold text-slate-800 dark:text-slate-100 text-sm truncate">{u.company_name}</div>
                  <div className="text-xs text-slate-400 truncate">{u.email}</div>
                  {u.last_backup_at ? (
                    <div className="text-xs text-emerald-600 dark:text-emerald-400 mt-0.5">
                      Son yedek: {new Date(u.last_backup_at).toLocaleString('tr-TR')}
                    </div>
                  ) : (
                    <div className="text-xs text-amber-500 mt-0.5">Hiç yedek alınmamış</div>
                  )}
                </div>
                <button
                  onClick={() => createBackupFor(u.id, u.company_name)}
                  disabled={creatingFor === u.id}
                  className="ml-4 flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white text-xs font-bold rounded-lg transition shrink-0">
                  <HardDrive size={13}/>
                  {creatingFor === u.id ? 'Hazırlanıyor...' : 'Yedek Al'}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Üst bilgi/araç çubuğu */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-4 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200">
          <HardDrive size={18}/> <span className="font-bold">Mevcut Yedekler</span>
          <span className="text-xs text-slate-400 ml-2">{backups.length} yedek</span>
        </div>
        <div className="flex-1 min-w-[200px]">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Bayi adı, e-posta veya dosya adı ara..."
              className="w-full pl-9 pr-3 py-2 text-sm rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 outline-none focus:border-indigo-500"/>
          </div>
        </div>
        <button onClick={load} disabled={loading}
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 text-sm font-bold">
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''}/> Yenile
        </button>
      </div>

      {/* Tablo */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-400">Yükleniyor...</div>
        ) : filtered.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <HardDrive size={32} className="mx-auto mb-3 opacity-40"/>
            <p className="text-sm">{search ? 'Eşleşen yedek bulunamadı.' : 'Henüz hiç yedek yok.'}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/50 text-xs text-slate-500 uppercase">
                <tr>
                  <th className="px-4 py-3 text-left font-semibold">Bayi</th>
                  <th className="px-4 py-3 text-left font-semibold">Dosya</th>
                  <th className="px-4 py-3 text-left font-semibold">Tarih</th>
                  <th className="px-4 py-3 text-left font-semibold">Boyut</th>
                  <th className="px-4 py-3 text-left font-semibold">Şifre</th>
                  <th className="px-4 py-3 text-right font-semibold">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filtered.map(b => {
                  const shown = !!revealed[b.id];
                  return (
                    <tr key={b.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <td className="px-4 py-3">
                        <div className="font-bold text-slate-800 dark:text-slate-100">{b.company_name || b.user_email}</div>
                        <div className="text-xs text-slate-400">{b.user_email}</div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200">
                          <FileText size={14} className="text-slate-400"/>
                          <span className="font-mono text-xs truncate max-w-[180px]" title={b.filename}>{b.filename}</span>
                        </div>
                        {b.restored_at && <div className="text-xs text-emerald-600 dark:text-emerald-400 mt-1">Geri yüklendi: {fmtDate(b.restored_at)}</div>}
                      </td>
                      <td className="px-4 py-3 text-slate-600 dark:text-slate-300 whitespace-nowrap">{fmtDate(b.created_at)}</td>
                      <td className="px-4 py-3 text-slate-600 dark:text-slate-300 whitespace-nowrap">{fmtSize(b.size_bytes)}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <code className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 text-xs text-slate-700 dark:text-slate-200 font-mono max-w-[220px] truncate">
                            {shown ? b.password : '••••••••••••••••'}
                          </code>
                          <button onClick={() => setRevealed(r => ({ ...r, [b.id]: !r[b.id] }))}
                            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800" title={shown ? 'Gizle' : 'Göster'}>
                            {shown ? <EyeOff size={14}/> : <Eye size={14}/>}
                          </button>
                          <button onClick={() => copyPwd(b.password)}
                            className="p-1.5 rounded-lg text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30" title="Kopyala">
                            <Copy size={14}/>
                          </button>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right whitespace-nowrap">
                        <button onClick={() => download(b)} title="İndir"
                          className="inline-flex items-center justify-center p-2 rounded-lg text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30">
                          <Download size={15}/>
                        </button>
                        <button onClick={() => setUploadTarget(b)} title="FTP'ye Yükle"
                          className="inline-flex items-center justify-center p-2 rounded-lg text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/30 ml-1">
                          <Upload size={15}/>
                        </button>
                        <button onClick={() => setConfirmDelete(b)} title="Sil"
                          className="inline-flex items-center justify-center p-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 ml-1">
                          <Trash2 size={15}/>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => setConfirmDelete(null)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-md w-full p-6" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-2">Yedek silinsin mi?</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-5">
              <strong>{confirmDelete.company_name || confirmDelete.user_email}</strong> bayisinin
              <strong className="font-mono"> {confirmDelete.filename}</strong> yedeği kalıcı olarak silinecek.
            </p>
            <div className="flex justify-end gap-3">
              <button onClick={() => setConfirmDelete(null)} className="px-4 py-2 text-sm text-slate-500 hover:text-slate-700">İptal</button>
              <button onClick={() => remove(confirmDelete)} className="px-5 py-2 bg-red-600 text-white text-sm font-bold rounded-xl hover:bg-red-700">Sil</button>
            </div>
          </div>
        </div>
      )}

      {uploadTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => !uploading && setUploadTarget(null)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-md w-full p-6" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-2 flex items-center gap-2">
              <Upload size={18}/> FTP/SFTP'ye Yükle
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
              <strong className="font-mono">{uploadTarget.filename}</strong> hedef sunucuya yüklenecek.
            </p>
            {ftpServers.length === 0 ? (
              <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl p-4 text-sm text-amber-800 dark:text-amber-300 mb-4">
                Henüz aktif FTP/SFTP sunucusu yok. Önce <strong>FTP/SFTP Sunucuları</strong> sekmesinden bir sunucu ekleyin.
              </div>
            ) : (
              <div className="space-y-2 mb-4 max-h-[300px] overflow-y-auto">
                {ftpServers.map((s: any) => (
                  <button key={s.id} disabled={uploading}
                    onClick={() => uploadToFtp(uploadTarget.id, s.id)}
                    className="w-full text-left p-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition disabled:opacity-50">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-2">
                          <Server size={14}/> {s.name}
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-700 uppercase">{s.type}</span>
                        </div>
                        <div className="text-xs text-slate-500 mt-0.5">{s.host}:{s.port} · {s.base_path}</div>
                      </div>
                      <ArrowRight size={16} className="text-emerald-500"/>
                    </div>
                  </button>
                ))}
              </div>
            )}
            <div className="flex justify-end gap-3">
              <button onClick={() => !uploading && setUploadTarget(null)} disabled={uploading}
                className="px-4 py-2 text-sm text-slate-500 hover:text-slate-700 disabled:opacity-50">
                {uploading ? 'Yükleniyor...' : 'Kapat'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ====================== FTP/SFTP Sunucuları (SuperAdmin) ======================
const FtpServersView: React.FC<{ showToast: (msg: string, type?: any) => void }> = ({ showToast }) => {
  const [servers, setServers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<any>(null); // null|object (object={} for new)
  const [confirmDelete, setConfirmDelete] = useState<any>(null);
  const [browserFor, setBrowserFor] = useState<any>(null);
  const [browserPath, setBrowserPath] = useState('');
  const [browserItems, setBrowserItems] = useState<any[]>([]);
  const [browserLoading, setBrowserLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const r = await api.get('/superadmin/ftp-servers');
      setServers(r.data || []);
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Sunucular yüklenemedi', 'error');
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const save = async (form: any) => {
    try {
      const payload = {
        name: form.name, type: form.type, host: form.host,
        port: Number(form.port), username: form.username,
        password: form.password || undefined,
        base_path: form.base_path || '/', is_active: !!form.is_active,
      };
      if (form.id) await api.put(`/superadmin/ftp-servers/${form.id}`, payload);
      else await api.post('/superadmin/ftp-servers', payload);
      showToast('Sunucu kaydedildi', 'success');
      setEditing(null);
      await load();
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Kayıt başarısız', 'error');
    }
  };

  const remove = async (s: any) => {
    try {
      await api.delete(`/superadmin/ftp-servers/${s.id}`);
      showToast('Sunucu silindi', 'success');
      setConfirmDelete(null);
      await load();
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Silme başarısız', 'error');
    }
  };

  const test = async (s: any) => {
    try {
      const r = await api.post(`/superadmin/ftp-servers/${s.id}/test`);
      showToast(r.data?.message || 'Test başarılı', r.data?.ok ? 'success' : 'error');
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Test başarısız', 'error');
    }
  };

  const browse = async (s: any, path = '') => {
    setBrowserFor(s); setBrowserPath(path); setBrowserLoading(true);
    try {
      const r = await api.get(`/superadmin/ftp-servers/${s.id}/files`, { params: { sub_path: path } });
      setBrowserItems(r.data?.items || []);
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Listeleme başarısız', 'error');
      setBrowserItems([]);
    } finally { setBrowserLoading(false); }
  };

  const removeRemote = async (item: any) => {
    if (!browserFor) return;
    if (!window.confirm(`"${item.name}" silinecek. Emin misiniz?`)) return;
    try {
      await api.delete(`/superadmin/ftp-servers/${browserFor.id}/files`, { params: { path: item.path } });
      showToast('Silindi', 'success');
      await browse(browserFor, browserPath);
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Silme başarısız', 'error');
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-4 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200">
          <Server size={18}/> <span className="font-bold">FTP / SFTP Sunucuları</span>
          <span className="text-xs text-slate-400 ml-2">{servers.length} sunucu</span>
        </div>
        <div className="flex-1"/>
        <button onClick={load} disabled={loading}
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 text-sm font-bold">
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''}/> Yenile
        </button>
        <button onClick={() => setEditing({ type: 'sftp', port: 22, base_path: '/', is_active: true })}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-bold hover:bg-indigo-700">
          <Plus size={14}/> Yeni Sunucu
        </button>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-400">Yükleniyor...</div>
        ) : servers.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <Server size={32} className="mx-auto mb-3 opacity-40"/>
            <p className="text-sm">Henüz hiç sunucu yok. Yeni Sunucu ile FTP/SFTP ekleyin.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 dark:bg-slate-800/50 text-xs text-slate-500 uppercase">
                <tr>
                  <th className="px-4 py-3 text-left font-semibold">İsim</th>
                  <th className="px-4 py-3 text-left font-semibold">Tür</th>
                  <th className="px-4 py-3 text-left font-semibold">Sunucu</th>
                  <th className="px-4 py-3 text-left font-semibold">Kullanıcı</th>
                  <th className="px-4 py-3 text-left font-semibold">Yol</th>
                  <th className="px-4 py-3 text-left font-semibold">Durum</th>
                  <th className="px-4 py-3 text-right font-semibold">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {servers.map(s => (
                  <tr key={s.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-4 py-3 font-bold text-slate-800 dark:text-slate-100">{s.name}</td>
                    <td className="px-4 py-3"><span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-700 uppercase font-mono">{s.type}</span></td>
                    <td className="px-4 py-3 font-mono text-xs text-slate-600 dark:text-slate-300">{s.host}:{s.port}</td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">{s.username}</td>
                    <td className="px-4 py-3 font-mono text-xs text-slate-500">{s.base_path}</td>
                    <td className="px-4 py-3">
                      {s.is_active ? <span className="text-xs font-bold text-emerald-600">Aktif</span>
                        : <span className="text-xs font-bold text-slate-400">Pasif</span>}
                    </td>
                    <td className="px-4 py-3 text-right whitespace-nowrap">
                      <button onClick={() => test(s)} title="Bağlantıyı Test Et"
                        className="inline-flex items-center justify-center p-2 rounded-lg text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/30">
                        <PlugZap size={15}/>
                      </button>
                      <button onClick={() => browse(s, '')} title="Dosyaları Görüntüle"
                        className="inline-flex items-center justify-center p-2 rounded-lg text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/30 ml-1">
                        <FolderOpen size={15}/>
                      </button>
                      <button onClick={() => setEditing(s)} title="Düzenle"
                        className="inline-flex items-center justify-center p-2 rounded-lg text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 ml-1">
                        <Settings size={15}/>
                      </button>
                      <button onClick={() => setConfirmDelete(s)} title="Sil"
                        className="inline-flex items-center justify-center p-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 ml-1">
                        <Trash2 size={15}/>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Edit/New modal */}
      {editing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => setEditing(null)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-lg w-full p-6 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-2">
              <Server size={18}/> {editing.id ? 'Sunucuyu Düzenle' : 'Yeni Sunucu'}
            </h3>
            <FtpServerForm initial={editing} onSubmit={save} onCancel={() => setEditing(null)}/>
          </div>
        </div>
      )}

      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => setConfirmDelete(null)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-md w-full p-6" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-2">Sunucu silinsin mi?</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-5">
              <strong>{confirmDelete.name}</strong> kaydı silinecek (uzaktaki dosyalara dokunulmaz).
            </p>
            <div className="flex justify-end gap-3">
              <button onClick={() => setConfirmDelete(null)} className="px-4 py-2 text-sm text-slate-500 hover:text-slate-700">İptal</button>
              <button onClick={() => remove(confirmDelete)} className="px-5 py-2 bg-red-600 text-white text-sm font-bold rounded-xl hover:bg-red-700">Sil</button>
            </div>
          </div>
        </div>
      )}

      {/* File browser modal */}
      {browserFor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => setBrowserFor(null)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-3xl w-full p-6 max-h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-2 flex items-center gap-2">
              <FolderOpen size={18}/> {browserFor.name} — Uzak Dosyalar
            </h3>
            <div className="flex items-center gap-2 mb-3 text-xs">
              <button onClick={() => browse(browserFor, '')}
                className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 font-mono">
                / (kök)
              </button>
              {browserPath && (
                <span className="font-mono text-slate-600 dark:text-slate-300">{browserPath}</span>
              )}
              {browserPath && (
                <button onClick={() => {
                  const parts = browserPath.split('/').filter(Boolean);
                  parts.pop();
                  browse(browserFor, parts.join('/'));
                }} className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700">
                  ↑ Üst
                </button>
              )}
              <div className="flex-1"/>
              <button onClick={() => browse(browserFor, browserPath)}
                className="px-2 py-1 rounded text-slate-500 hover:text-slate-700">
                <RefreshCw size={12} className={browserLoading ? 'animate-spin inline' : 'inline'}/>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto border border-slate-200 dark:border-slate-700 rounded-xl">
              {browserLoading ? (
                <div className="p-8 text-center text-slate-400 text-sm">Yükleniyor...</div>
              ) : browserItems.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-sm">Bu klasör boş.</div>
              ) : (
                <ul className="divide-y divide-slate-100 dark:divide-slate-800">
                  {browserItems.map((it: any) => (
                    <li key={it.path} className="px-3 py-2 flex items-center gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 text-sm">
                      {it.is_dir ? <Folder size={16} className="text-amber-500"/> : <FileText size={16} className="text-slate-400"/>}
                      <button
                        disabled={!it.is_dir}
                        onClick={() => it.is_dir && browse(browserFor, it.path)}
                        className={`flex-1 text-left font-mono text-xs ${it.is_dir ? 'text-indigo-600 dark:text-indigo-400 hover:underline' : 'text-slate-700 dark:text-slate-200'}`}>
                        {it.name}
                      </button>
                      {!it.is_dir && (
                        <span className="text-xs text-slate-400">
                          {it.size > 1024 * 1024 ? `${(it.size/1024/1024).toFixed(1)} MB`
                            : it.size > 1024 ? `${(it.size/1024).toFixed(1)} KB`
                            : `${it.size} B`}
                        </span>
                      )}
                      <button onClick={() => removeRemote(it)} title="Sil"
                        className="p-1.5 rounded text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30">
                        <Trash2 size={13}/>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div className="flex justify-end mt-4">
              <button onClick={() => setBrowserFor(null)} className="px-4 py-2 text-sm text-slate-500 hover:text-slate-700">Kapat</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const FtpServerForm: React.FC<{ initial: any; onSubmit: (f: any) => void; onCancel: () => void }> = ({ initial, onSubmit, onCancel }) => {
  const [form, setForm] = useState({
    id: initial.id,
    name: initial.name || '',
    type: initial.type || 'sftp',
    host: initial.host || '',
    port: initial.port || (initial.type === 'ftp' ? 21 : 22),
    username: initial.username || '',
    password: '',
    base_path: initial.base_path || '/',
    is_active: initial.is_active !== false,
  });

  const upd = (k: string, v: any) => setForm(f => {
    const next = { ...f, [k]: v };
    if (k === 'type' && (v === 'sftp' || v === 'ftp')) {
      // varsayılan port'u türe göre güncelle
      if (!initial.id) next.port = v === 'sftp' ? 22 : 21;
    }
    return next;
  });

  return (
    <div className="space-y-3">
      <div>
        <label className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block">Ad (etiket)</label>
        <input value={form.name} onChange={e => upd('name', e.target.value)}
          placeholder="Hetzner Yedek 1"
          className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm outline-none focus:border-indigo-500"/>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block">Tür</label>
          <select value={form.type} onChange={e => upd('type', e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm">
            <option value="sftp">SFTP (SSH)</option>
            <option value="ftp">FTP (klasik)</option>
          </select>
        </div>
        <div>
          <label className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block">Port</label>
          <input type="number" value={form.port} onChange={e => upd('port', Number(e.target.value) || 0)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm"/>
        </div>
      </div>
      <div>
        <label className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block">Sunucu (host)</label>
        <input value={form.host} onChange={e => upd('host', e.target.value)}
          placeholder="ftp.ornek.com"
          className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono"/>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block">Kullanıcı</label>
          <input value={form.username} onChange={e => upd('username', e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono"/>
        </div>
        <div>
          <label className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block">
            Şifre {initial.id ? <span className="text-slate-400 font-normal">(değiştirmek istemezseniz boş bırakın)</span> : ''}
          </label>
          <input type="password" value={form.password} onChange={e => upd('password', e.target.value)}
            placeholder={initial.id ? '••••••••' : ''}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono"/>
        </div>
      </div>
      <div>
        <label className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block">Temel klasör (base path)</label>
        <input value={form.base_path} onChange={e => upd('base_path', e.target.value)}
          placeholder="/backups/stokfinans"
          className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono"/>
      </div>
      <label className="flex items-center gap-2 text-sm cursor-pointer text-slate-700 dark:text-slate-200">
        <input type="checkbox" checked={form.is_active} onChange={e => upd('is_active', e.target.checked)} className="w-4 h-4"/>
        Aktif (yedek yüklemeleri için seçilebilir)
      </label>
      <div className="flex justify-end gap-3 pt-2">
        <button onClick={onCancel} className="px-4 py-2 text-sm text-slate-500 hover:text-slate-700">İptal</button>
        <button onClick={() => onSubmit(form)} className="px-5 py-2 bg-indigo-600 text-white text-sm font-bold rounded-xl hover:bg-indigo-700 flex items-center gap-2">
          <Save size={14}/> Kaydet
        </button>
      </div>
    </div>
  );
};

// ====================== Sunucu Eşleşmesi (SuperAdmin) ======================
// ============================================================
// MultiNodeSyncView — Çok-sunuculu senkronizasyon yönetimi
// ============================================================

interface SelfInfo {
  name: string;
  our_token: string;
  sys_cpu_count: number | null;
  sys_ram_gb: number | null;
  sys_disk_total_gb: number | null;
  sys_disk_free_gb: number | null;
  sys_os: string | null;
}

interface RemoteNode {
  id: number;
  name: string;
  display_order: number;
  url: string;
  is_active: boolean;
  last_heartbeat_at: string | null;
  last_sync_at: string | null;
  last_pull_at: string | null;
  last_error: string | null;
  sys_cpu_count: number | null;
  sys_ram_gb: number | null;
  sys_disk_total_gb: number | null;
  sys_disk_free_gb: number | null;
  sys_os: string | null;
}

interface SyncLogEntry {
  id: number;
  from_node_name: string;
  to_node_name: string;
  event_type: string;
  records_total: number | null;
  duration_ms: number | null;
  error: string | null;
  details: any;
  created_at: string;
}

// Active sync pair key: "FromNode->ToNode"
type ActiveArrow = { from: string; to: string };

const AddNodeModal: React.FC<{
  onClose: () => void;
  onSaved: () => void;
  showToast: (m: string, t?: any) => void;
  editNode?: RemoteNode | null;
}> = ({ onClose, onSaved, showToast, editNode }) => {
  const [name, setName] = useState(editNode?.name || '');
  const [url, setUrl] = useState(editNode?.url || '');
  const [peerToken, setPeerToken] = useState('');
  const [displayOrder, setDisplayOrder] = useState(editNode?.display_order ?? 2);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!name.trim()) { showToast('Sunucu adı gerekli', 'error'); return; }
    if (!url.trim()) { showToast('URL gerekli', 'error'); return; }
    if (!editNode && !peerToken.trim()) { showToast('Token gerekli', 'error'); return; }
    setBusy(true);
    try {
      const payload: any = { name: name.trim(), url: url.trim(), display_order: displayOrder };
      if (peerToken.trim()) payload.peer_token = peerToken.trim();
      if (editNode) {
        await api.put(`/superadmin/sync/nodes/${editNode.id}`, payload);
        showToast('Sunucu güncellendi', 'success');
      } else {
        await api.post('/superadmin/sync/nodes', payload);
        showToast('Sunucu eklendi', 'success');
      }
      onSaved();
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'İşlem başarısız', 'error');
    } finally { setBusy(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-lg w-full p-6" onClick={e => e.stopPropagation()}>
        <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-2">
          <Server size={18} /> {editNode ? 'Sunucuyu Düzenle' : 'Yeni Sunucu Ekle'}
        </h3>
        <div className="space-y-3">
          <div>
            <label className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block">Sunucu Adı</label>
            <input value={name} onChange={e => setName(e.target.value)}
              placeholder="Sunucu 2"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm" />
          </div>
          <div>
            <label className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block">Sunucu URL'si</label>
            <input value={url} onChange={e => setUrl(e.target.value)}
              placeholder="https://sunucu2.ornek.com"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono" />
            <p className="text-xs text-slate-400 mt-1">Sondaki "/" gerekmez. /api/v1/sync/* yolları otomatik eklenir.</p>
          </div>
          <div>
            <label className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block">
              {editNode ? "Peer Token (boş bırakılırsa korunur)" : "Peer Token (uzak sunucunun 'our_token'ı)"}
            </label>
            <input value={peerToken} onChange={e => setPeerToken(e.target.value)}
              placeholder={editNode ? '(değiştirmek için girin)' : 'Uzak sunucunun süperadmin panelinden kopyalayın'}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono" />
          </div>
          <div>
            <label className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block">Sıra</label>
            <input type="number" min={1} value={displayOrder} onChange={e => setDisplayOrder(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm" />
          </div>
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl p-3 text-xs text-blue-800 dark:text-blue-300">
            <strong>Not:</strong> Uzak sunucunun süperadmin panelinde "Bu Sunucunun Token'ı" bölümünden token kopyalayın,
            ve uzak sunucuya bu sunucunun token'ını aynı şekilde ekleyin.
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-5">
          <button onClick={onClose} disabled={busy} className="px-4 py-2 text-sm text-slate-500 hover:text-slate-700">İptal</button>
          <button onClick={submit} disabled={busy}
            className="px-5 py-2 bg-indigo-600 text-white text-sm font-bold rounded-xl hover:bg-indigo-700 flex items-center gap-2 disabled:opacity-50">
            <Save size={14} /> {busy ? 'Kaydediliyor...' : 'Kaydet'}
          </button>
        </div>
      </div>
    </div>
  );
};

const MAX_POLL_ATTEMPTS = 360; // 360 × 3s = 18 dk (build timeout 15 dk + 3 dk marj)

// ── DeployModal ───────────────────────────────────────────────────────────────

interface DeployStatus {
  step: string;
  message: string;
  done: boolean;
  error: string | null;
  ts: string | null;
  offline?: boolean;
}

const DEPLOY_STEPS = [
  { key: 'received',   label: 'ZIP Alındı',           desc: 'Kaynak kodu uzak sunucuya iletildi' },
  { key: 'extracting', label: 'Yedek + Çıkarma',      desc: 'Rollback yedeği alınıyor, ZIP açılıyor' },
  { key: 'copying',    label: 'Dosyalar Kopyalanıyor', desc: 'Yeni dosyalar hedef dizine taşınıyor' },
  { key: 'rebuilding', label: 'Docker Build',          desc: 'Docker imajları derleniyor (~2-5 dk)' },
  { key: 'restarting', label: 'Yeniden Başlatılıyor',  desc: 'Containerlar durduruluyor ve yeniden başlatılıyor' },
  { key: 'done',       label: 'Tamamlandı',            desc: 'Sunucu başarıyla güncellendi' },
];

function fmtElapsed(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  return `${Math.floor(seconds / 60)}dk ${seconds % 60}s`;
}

const DeployModal: React.FC<{
  node: RemoteNode;
  onClose: () => void;
  showToast: (m: string, t?: any) => void;
}> = ({ node, onClose, showToast }) => {
  const [phase, setPhase] = useState<'choose' | 'deploying'>('choose');
  const [deployMode, setDeployMode] = useState<'push' | 'upload'>('push');
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<DeployStatus | null>(null);
  const [starting, setStarting] = useState(false);
  const [stepStartTimes, setStepStartTimes] = useState<Record<string, number>>({});
  const [now, setNow] = useState(Date.now());
  const pollRef = React.useRef<number | null>(null);
  const pollCountRef = React.useRef<number>(0);
  const timerRef = React.useRef<number | null>(null);

  const stopPoll = () => {
    if (pollRef.current !== null) { window.clearTimeout(pollRef.current); pollRef.current = null; }
  };

  // Saniyeyi güncelle
  useEffect(() => {
    timerRef.current = window.setInterval(() => setNow(Date.now()), 1000);
    return () => { if (timerRef.current) window.clearInterval(timerRef.current); };
  }, []);

  // Her adım ilk görüldüğünde zamanı kaydet
  useEffect(() => {
    if (status?.step && !stepStartTimes[status.step]) {
      setStepStartTimes(prev => ({ ...prev, [status.step]: Date.now() }));
    }
  }, [status?.step]);

  const poll = React.useCallback(async () => {
    pollCountRef.current += 1;
    if (pollCountRef.current > MAX_POLL_ATTEMPTS) {
      setStatus({
        step: 'error',
        message: 'Deploy zaman aşımına uğradı — sunucu 18 dakika boyunca yanıt vermedi',
        done: false,
        error: 'Zaman aşımı: 18 dakika içinde tamamlanma sinyali alınamadı. Sunucu loglarını kontrol edin.',
        ts: new Date().toISOString(),
      });
      return;
    }
    try {
      const r = await api.get(`/superadmin/sync/nodes/${node.id}/deploy-status`);
      const s: DeployStatus = r.data;
      setStatus(s);
      if (!s.done && s.step !== 'error') {
        pollRef.current = window.setTimeout(poll, 3000);
      }
    } catch {
      pollRef.current = window.setTimeout(poll, 3000);
    }
  }, [node.id]);

  useEffect(() => () => { stopPoll(); if (timerRef.current) window.clearInterval(timerRef.current); }, []);

  // Escape tuşunu deploy sırasında engelle
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      if (phase === 'choose' || status?.done || status?.step === 'error') {
        stopPoll(); onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [phase, status, onClose]);

  const startDeploy = async () => {
    if (deployMode === 'upload' && !file) { showToast('ZIP dosyası seçin', 'error'); return; }
    setStarting(true);
    try {
      if (deployMode === 'push') {
        const r = await api.post(`/superadmin/sync/nodes/${node.id}/push-deploy`);
        const kb: number = r.data?.bundle_kb ?? 0;
        const initMsg = kb > 0
          ? `ZIP gönderildi (${kb} KB), deploy başlatıldı...`
          : 'ZIP gönderildi, deploy başlatıldı...';
        const initStep = 'received';
        setStepStartTimes({ [initStep]: Date.now() });
        setStatus({ step: initStep, message: initMsg, done: false, error: null, ts: null });
      } else {
        const arrayBuffer = await file!.arrayBuffer();
        const blob = new Blob([arrayBuffer], { type: 'application/octet-stream' });
        await api.post(`/superadmin/sync/nodes/${node.id}/upload-deploy`, blob, {
          headers: { 'Content-Type': 'application/octet-stream' },
        });
        const initStep = 'received';
        setStepStartTimes({ [initStep]: Date.now() });
        setStatus({ step: initStep, message: 'ZIP yüklendi, deploy başlatıldı...', done: false, error: null, ts: null });
      }
      setPhase('deploying');
      pollCountRef.current = 0;
      pollRef.current = window.setTimeout(poll, 2000);
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Deploy başlatılamadı', 'error');
    } finally {
      setStarting(false);
    }
  };

  const currentStepIdx = status
    ? status.step === 'error'
      ? -1
      : DEPLOY_STEPS.findIndex(s => s.key === status.step)
    : -1;

  // Mevcut adımda geçen süre (saniye)
  const currentElapsedSec = status?.step && stepStartTimes[status.step]
    ? Math.floor((now - stepStartTimes[status.step]) / 1000)
    : 0;

  const isRestartingTooLong = status?.step === 'restarting' && currentElapsedSec > 180;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => { if (status?.done || status?.step === 'error' || phase === 'choose') { stopPoll(); onClose(); } }}>
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-lg w-full p-6" onClick={e => e.stopPropagation()}>

        {/* Başlık */}
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Upload size={18} className="text-indigo-500" />
            Uzak Güncelleme — {node.name}
          </h3>
          {(phase === 'choose' || status?.done || status?.step === 'error') && (
            <button onClick={() => { stopPoll(); onClose(); }} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
              <X size={18} />
            </button>
          )}
        </div>

        {/* ── Seçim ekranı ─────────────────────────────────────── */}
        {phase === 'choose' && (
          <div className="space-y-4">
            <p className="text-sm text-slate-600 dark:text-slate-400">
              <strong>{node.name}</strong> sunucusuna nasıl güncellensin?
            </p>

            <div className="space-y-2">
              <label className={`flex items-start gap-3 p-4 rounded-xl border-2 cursor-pointer transition-colors ${
                deployMode === 'push'
                  ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-950/30'
                  : 'border-slate-200 dark:border-slate-700 hover:border-slate-300'
              }`} onClick={() => setDeployMode('push')}>
                <input type="radio" checked={deployMode === 'push'} onChange={() => setDeployMode('push')} className="mt-0.5 accent-indigo-600" />
                <div>
                  <div className="font-bold text-slate-800 dark:text-slate-100 text-sm flex items-center gap-1.5">
                    <Server size={14} className="text-indigo-500" /> Bu sunucunun dosyalarını gönder
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Mevcut sunucunun tüm kaynak kodunu paketleyip <strong>{node.name}</strong>'e gönderir ve yeniden başlatır.
                  </div>
                </div>
              </label>

              <label className={`flex items-start gap-3 p-4 rounded-xl border-2 cursor-pointer transition-colors ${
                deployMode === 'upload'
                  ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/30'
                  : 'border-slate-200 dark:border-slate-700 hover:border-slate-300'
              }`} onClick={() => setDeployMode('upload')}>
                <input type="radio" checked={deployMode === 'upload'} onChange={() => setDeployMode('upload')} className="mt-0.5 accent-emerald-600" />
                <div className="flex-1">
                  <div className="font-bold text-slate-800 dark:text-slate-100 text-sm flex items-center gap-1.5">
                    <Upload size={14} className="text-emerald-500" /> ZIP dosyası yükle
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Bilgisayarınızdan bir bundle ZIP seçin; uzak sunucuya gönderilir.
                  </div>
                  {deployMode === 'upload' && (
                    <div className="mt-2">
                      <input
                        type="file"
                        accept=".zip"
                        onChange={e => setFile(e.target.files?.[0] ?? null)}
                        className="block w-full text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-emerald-100 file:text-emerald-700 hover:file:bg-emerald-200 cursor-pointer"
                      />
                      {file && <div className="mt-1 text-xs text-emerald-600 font-medium">{file.name} ({(file.size / 1024 / 1024).toFixed(1)} MB)</div>}
                    </div>
                  )}
                </div>
              </label>
            </div>

            <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-700 rounded-xl p-3 text-xs text-amber-800 dark:text-amber-300">
              ⚠️ Uzak sunucu birkaç dakika yeniden başlatılacak. Bu sürede o sunucuya erişim kesilir.
            </div>

            <div className="flex justify-end gap-3">
              <button onClick={onClose} className="px-4 py-2 text-sm text-slate-500 hover:text-slate-700">İptal</button>
              <button
                onClick={startDeploy}
                disabled={starting || (deployMode === 'upload' && !file)}
                className="px-5 py-2 bg-indigo-600 text-white text-sm font-bold rounded-xl hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-2"
              >
                <Upload size={14} /> {starting ? 'Gönderiliyor...' : 'Dağıtımı Başlat'}
              </button>
            </div>
          </div>
        )}

        {/* ── İlerleme ekranı ──────────────────────────────────── */}
        {phase === 'deploying' && (
          <div className="space-y-4">
            {/* Adım listesi */}
            <div className="space-y-1.5">
              {DEPLOY_STEPS.map((step, idx) => {
                const isDone    = currentStepIdx > idx || (status?.done ?? false);
                const isCurrent = currentStepIdx === idx && !(status?.done ?? false);
                const isPending = !isDone && !isCurrent;
                const elapsed   = isCurrent && stepStartTimes[step.key]
                  ? Math.floor((now - stepStartTimes[step.key]) / 1000)
                  : null;
                return (
                  <div key={step.key} className={`flex items-start gap-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                    isDone    ? 'bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800'
                    : isCurrent ? 'bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-300 dark:border-indigo-700 shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 opacity-40'
                  }`}>
                    {/* İkon */}
                    <div className="shrink-0 w-6 h-6 flex items-center justify-center mt-0.5">
                      {isDone ? (
                        <span className="text-emerald-500 text-lg">✓</span>
                      ) : isCurrent ? (
                        <div className="w-4 h-4 rounded-full border-2 border-indigo-500 border-t-transparent animate-spin" />
                      ) : (
                        <div className="w-3 h-3 rounded-full border-2 border-slate-300 dark:border-slate-600" />
                      )}
                    </div>

                    {/* İçerik */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className={`text-sm font-bold ${
                          isDone    ? 'text-emerald-700 dark:text-emerald-300'
                          : isCurrent ? 'text-indigo-700 dark:text-indigo-300'
                          : 'text-slate-400'
                        }`}>{step.label}</span>
                        {elapsed !== null && !status?.done && (
                          <span className="text-xs font-mono text-indigo-500 dark:text-indigo-400 shrink-0">
                            {fmtElapsed(elapsed)}
                          </span>
                        )}
                      </div>
                      <div className={`text-xs mt-0.5 ${
                        isDone ? 'text-emerald-600 dark:text-emerald-400'
                        : isCurrent ? 'text-indigo-500 dark:text-indigo-400'
                        : 'text-slate-400'
                      }`}>
                        {isCurrent && status?.message ? status.message : step.desc}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Yeniden başlatılıyor — offline uyarısı */}
            {status?.step === 'restarting' && !status.done && (
              <div className={`flex items-start gap-3 px-4 py-3 rounded-xl border ${
                isRestartingTooLong
                  ? 'bg-amber-50 dark:bg-amber-950/20 border-amber-300 dark:border-amber-700'
                  : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700'
              }`}>
                <div className={`w-2.5 h-2.5 rounded-full shrink-0 mt-0.5 animate-pulse ${
                  isRestartingTooLong ? 'bg-amber-500' : 'bg-indigo-400'
                }`} />
                <div className="flex-1">
                  <div className={`text-xs font-semibold ${isRestartingTooLong ? 'text-amber-700 dark:text-amber-300' : 'text-slate-600 dark:text-slate-300'}`}>
                    {isRestartingTooLong
                      ? `⚠️ Yeniden başlatma ${fmtElapsed(currentElapsedSec)} sürüyor — beklenenden uzun`
                      : 'Sunucu yeniden başlatılıyor — bu ekranı kapatmayın'}
                  </div>
                  {isRestartingTooLong && (
                    <div className="text-xs text-amber-600 dark:text-amber-400 mt-1">
                      Sorun olabilir: uzak sunucuda <code className="font-mono bg-amber-100 dark:bg-amber-900/30 px-1 rounded">docker logs stokfinans-backend</code> komutunu çalıştırın.
                    </div>
                  )}
                  {!isRestartingTooLong && (
                    <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      Her 3 saniyede bir kontrol ediliyor — backend başlayınca otomatik tamamlanacak
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Hata */}
            {status?.step === 'error' && (
              <div className="px-4 py-4 bg-red-50 dark:bg-red-950/20 border border-red-300 dark:border-red-700 rounded-xl">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-red-500 text-lg">✕</span>
                  <div className="text-sm font-bold text-red-700 dark:text-red-300">Deploy Başarısız</div>
                </div>
                <div className="text-xs text-red-600 dark:text-red-400 font-mono whitespace-pre-wrap break-all max-h-40 overflow-y-auto bg-red-100 dark:bg-red-900/20 rounded-lg p-3">
                  {status.error || status.message}
                </div>
              </div>
            )}

            {/* Başarı */}
            {status?.done && (
              <div className="px-4 py-4 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-700 rounded-xl text-center">
                <div className="text-2xl mb-1">🎉</div>
                <div className="text-sm font-bold text-emerald-700 dark:text-emerald-300">{node.name} başarıyla güncellendi!</div>
                <div className="text-xs text-emerald-600 dark:text-emerald-400 mt-1">
                  Toplam süre: {stepStartTimes['received'] ? fmtElapsed(Math.floor((Date.now() - stepStartTimes['received']) / 1000)) : '—'}
                </div>
              </div>
            )}

            {(status?.done || status?.step === 'error') && (
              <div className="flex justify-end">
                <button onClick={() => { stopPoll(); onClose(); }} className="px-5 py-2 bg-slate-700 text-white text-sm font-bold rounded-xl hover:bg-slate-800">
                  Kapat
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

// ── BulkDeployView ────────────────────────────────────────────────────────────

interface BatchItem {
  id: number;
  node_name: string;
  sync_node_id: number | null;
  status: string;
  error_message: string | null;
  started_at: string | null;
  completed_at: string | null;
}
interface Batch {
  id: string;
  status: string;
  bundle_size_bytes: number | null;
  created_at: string | null;
  items: BatchItem[];
}
interface BatchSummary {
  id: string;
  status: string;
  bundle_size_bytes: number | null;
  created_at: string | null;
  node_count: number;
  done_count: number;
  error_count: number;
}

const BULK_STEP_LABELS: Record<string, string> = {
  queued: 'Sırада',
  deploying: 'Gönderiliyor',
  extracting: 'Yedek + Çıkarma',
  copying: 'Kopyalanıyor',
  rebuilding: 'Docker Build',
  restarting: 'Yeniden Başlatılıyor',
  done: 'Tamamlandı',
  error: 'Hata',
};

const BULK_STEP_ORDER = ['queued','deploying','extracting','copying','rebuilding','restarting','done'];

function stepProgress(status: string): number {
  const idx = BULK_STEP_ORDER.indexOf(status);
  if (idx < 0) return 0;
  if (status === 'done') return 100;
  return Math.round((idx / (BULK_STEP_ORDER.length - 1)) * 100);
}

function batchStatusBadge(status: string) {
  if (status === 'done') return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300';
  if (status === 'failed') return 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300';
  if (status === 'partial') return 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300';
  return 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300';
}

const BulkDeployView: React.FC<{
  showToast: (m: string, t?: any) => void;
  onDeployingNodesChange?: (names: string[]) => void;
}> = ({ showToast, onDeployingNodesChange }) => {
  const [nodes, setNodes] = useState<RemoteNode[]>([]);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [loading, setLoading] = useState(true);
  const [deploying, setDeploying] = useState(false);
  const [activeBatch, setActiveBatch] = useState<Batch | null>(null);
  const [history, setHistory] = useState<BatchSummary[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const pollRef = React.useRef<number | null>(null);

  const secondsAgo = (s: string | null): number | null => {
    if (!s) return null;
    return Math.floor((Date.now() - new Date(s).getTime()) / 1000);
  };
  const isOnline = (node: RemoteNode) => {
    const age = secondsAgo(node.last_heartbeat_at);
    return age !== null && age < 300;
  };

  const fmtDt = (s: string | null) => {
    if (!s) return '—';
    try { return new Date(s).toLocaleString('tr-TR'); } catch { return s; }
  };
  const fmtKb = (b: number | null) => b ? `${Math.round(b / 1024)} KB` : '—';

  const stopPoll = () => {
    if (pollRef.current !== null) { window.clearTimeout(pollRef.current); pollRef.current = null; }
  };

  const loadNodes = async () => {
    try {
      const r = await api.get('/superadmin/sync/nodes');
      setNodes(r.data.filter((n: RemoteNode) => n.is_active));
    } catch { /* ignore */ }
    setLoading(false);
  };

  const loadHistory = async () => {
    setHistoryLoading(true);
    try {
      const r = await api.get('/superadmin/sync/deploy-batches');
      setHistory(r.data);
    } catch { /* ignore */ }
    setHistoryLoading(false);
  };

  useEffect(() => {
    loadNodes();
    loadHistory();
    return stopPoll;
  }, []);

  // Poll active batch
  const pollBatch = React.useCallback(async (batchId: string) => {
    try {
      const r = await api.get(`/superadmin/sync/deploy-batch/${batchId}/status`);
      const b: Batch = r.data;
      setActiveBatch(b);

      // Update parent with currently deploying node names
      const activeNames = b.items
        .filter(i => !['done','error','queued'].includes(i.status))
        .map(i => i.node_name);
      onDeployingNodesChange?.(activeNames);

      if (b.status === 'in_progress') {
        pollRef.current = window.setTimeout(() => pollBatch(batchId), 2000);
      } else {
        onDeployingNodesChange?.([]);
        loadHistory();
        if (b.status === 'done') showToast('Tüm node\'lar başarıyla güncellendi', 'success');
        else if (b.status === 'partial') showToast('Bazı node\'larda hata oluştu', 'warning');
        else showToast('Deploy başarısız', 'error');
      }
    } catch {
      pollRef.current = window.setTimeout(() => pollBatch(batchId), 3000);
    }
  }, [onDeployingNodesChange, showToast]);

  const startBulkDeploy = async () => {
    if (selected.size === 0) { showToast('En az bir sunucu seçin', 'error'); return; }
    setDeploying(true);
    try {
      const r = await api.post('/superadmin/sync/nodes/bulk-deploy', { node_ids: [...selected] });
      const batchId: string = r.data.batch_id;
      const kb: number = r.data.bundle_kb ?? 0;
      showToast(`Deploy başlatıldı — ${selected.size} sunucu, ${kb} KB bundle`, 'success');
      setSelected(new Set());
      stopPoll();
      pollRef.current = window.setTimeout(() => pollBatch(batchId), 1000);
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Deploy başlatılamadı', 'error');
    } finally {
      setDeploying(false);
    }
  };

  const toggleAll = () => {
    if (selected.size === nodes.length) setSelected(new Set());
    else setSelected(new Set(nodes.map(n => n.id)));
  };

  const toggleNode = (id: number) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const isBatchActive = activeBatch?.status === 'in_progress';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Upload size={16} className="text-indigo-500" /> Toplu Dağıtım
          </h3>
          <button onClick={() => { loadNodes(); loadHistory(); }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800">
            <RefreshCw size={14} />
          </button>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
          Seçili sunuculara bu sunucunun kaynak kodu paketlenerek tek seferinde gönderilir. Bundle bir kez oluşturulur, tüm sunuculara paralel iletilir.
        </p>

        {loading ? (
          <div className="text-sm text-slate-500 py-4 text-center">Sunucular yükleniyor...</div>
        ) : nodes.length === 0 ? (
          <div className="text-sm text-slate-500 py-4 text-center">Aktif uzak sunucu yok. Önce Eşleşme bölümünden sunucu ekleyin.</div>
        ) : (
          <>
            {/* Node checkboxes */}
            <div className="space-y-2 mb-4">
              <div className="flex items-center justify-between mb-2">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-600 dark:text-slate-400 uppercase">
                  <input type="checkbox" checked={selected.size === nodes.length && nodes.length > 0}
                    onChange={toggleAll} className="rounded accent-indigo-600" />
                  Tümünü Seç ({nodes.length})
                </label>
                <span className="text-xs text-slate-400">{selected.size} seçili</span>
              </div>

              {nodes.map(node => {
                const online = isOnline(node);
                const beingDeployed = activeBatch?.items.some(
                  i => i.sync_node_id === node.id && !['done','error','queued'].includes(i.status)
                );
                return (
                  <label key={node.id} className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-colors ${
                    selected.has(node.id)
                      ? 'border-indigo-400 bg-indigo-50 dark:bg-indigo-950/20 dark:border-indigo-700'
                      : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
                  }`}>
                    <input type="checkbox" checked={selected.has(node.id)}
                      onChange={() => toggleNode(node.id)} disabled={isBatchActive}
                      className="rounded accent-indigo-600 shrink-0" />
                    <div className={`w-2 h-2 rounded-full shrink-0 ${
                      beingDeployed ? 'bg-blue-500 animate-pulse' : online ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-600'
                    }`} />
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm text-slate-800 dark:text-slate-100 truncate">{node.name}</div>
                      <div className="text-xs text-slate-400 truncate">{node.url}</div>
                    </div>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold shrink-0 ${
                      beingDeployed
                        ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300'
                        : online
                          ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300'
                          : 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400'
                    }`}>
                      {beingDeployed ? 'Deploy' : online ? 'Çevrimiçi' : 'Çevrimdışı'}
                    </span>
                  </label>
                );
              })}
            </div>

            <button
              onClick={startBulkDeploy}
              disabled={deploying || isBatchActive || selected.size === 0}
              className="w-full flex items-center justify-center gap-2 px-5 py-3 bg-indigo-600 text-white text-sm font-bold rounded-xl hover:bg-indigo-700 disabled:opacity-50 transition-colors">
              <Upload size={14} />
              {deploying ? 'Başlatılıyor...' : isBatchActive ? 'Deploy Devam Ediyor...' : `${selected.size || 'Sunucu'} Sunucuyu Güncelle`}
            </button>
          </>
        )}
      </div>

      {/* Active batch progress */}
      {activeBatch && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <Activity size={15} className={isBatchActive ? 'text-blue-500 animate-pulse' : 'text-emerald-500'} />
              {isBatchActive ? 'Deploy Devam Ediyor' : 'Deploy Tamamlandı'}
            </h4>
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${batchStatusBadge(activeBatch.status)}`}>
              {activeBatch.status === 'in_progress' ? 'Devam Ediyor' : activeBatch.status === 'done' ? 'Başarılı' : activeBatch.status === 'partial' ? 'Kısmi' : 'Başarısız'}
            </span>
          </div>
          <div className="text-xs text-slate-400 mb-4">
            Bundle: {fmtKb(activeBatch.bundle_size_bytes)} · {fmtDt(activeBatch.created_at)}
          </div>

          <div className="space-y-3">
            {activeBatch.items.map(item => {
              const pct = stepProgress(item.status);
              const isErr = item.status === 'error';
              const isDone = item.status === 'done';
              const barColor = isErr ? 'bg-red-500' : isDone ? 'bg-emerald-500' : 'bg-blue-500';
              return (
                <div key={item.id} className="border border-slate-200 dark:border-slate-700 rounded-xl p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-sm text-slate-800 dark:text-slate-100">{item.node_name}</span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      isErr ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300'
                        : isDone ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300'
                        : 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300'
                    }`}>
                      {BULK_STEP_LABELS[item.status] ?? item.status}
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-2 rounded-full transition-all duration-700 ${barColor} ${
                        !isDone && !isErr ? 'animate-pulse' : ''
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  {isErr && item.error_message && (
                    <div className="mt-1.5 text-[11px] text-red-600 dark:text-red-400 truncate" title={item.error_message}>
                      {item.error_message}
                    </div>
                  )}
                  {item.started_at && item.completed_at && (
                    <div className="mt-1 text-[10px] text-slate-400">
                      Süre: {Math.round((new Date(item.completed_at).getTime() - new Date(item.started_at).getTime()) / 1000)}s
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* History */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-bold text-slate-800 dark:text-slate-100 text-sm flex items-center gap-2">
            <Archive size={14} className="text-slate-400" /> Deploy Geçmişi
          </h4>
          <button onClick={loadHistory} className="text-xs text-indigo-500 hover:underline">Yenile</button>
        </div>

        {historyLoading ? (
          <div className="text-sm text-slate-500 py-2 text-center">Yükleniyor...</div>
        ) : history.length === 0 ? (
          <div className="text-sm text-slate-500 py-2 text-center">Henüz deploy geçmişi yok</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="text-slate-400 border-b border-slate-100 dark:border-slate-800">
                  <th className="pb-2 font-bold">Tarih</th>
                  <th className="pb-2 font-bold">Sunucu</th>
                  <th className="pb-2 font-bold">Bundle</th>
                  <th className="pb-2 font-bold">Durum</th>
                  <th className="pb-2 font-bold text-center">✓</th>
                  <th className="pb-2 font-bold text-center">✗</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {history.map(b => (
                  <tr key={b.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer"
                    onClick={() => { if (!isBatchActive) { api.get(`/superadmin/sync/deploy-batch/${b.id}/status`).then(r => setActiveBatch(r.data)).catch(() => {}); } }}>
                    <td className="py-2 text-slate-600 dark:text-slate-400 whitespace-nowrap">{fmtDt(b.created_at)}</td>
                    <td className="py-2 font-medium text-slate-800 dark:text-slate-100">{b.node_count} node</td>
                    <td className="py-2 text-slate-500">{fmtKb(b.bundle_size_bytes)}</td>
                    <td className="py-2">
                      <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${batchStatusBadge(b.status)}`}>
                        {b.status === 'done' ? 'Başarılı' : b.status === 'failed' ? 'Başarısız' : b.status === 'partial' ? 'Kısmi' : 'Devam Ediyor'}
                      </span>
                    </td>
                    <td className="py-2 text-center text-emerald-600 dark:text-emerald-400 font-bold">{b.done_count}</td>
                    <td className="py-2 text-center text-red-600 dark:text-red-400 font-bold">{b.error_count > 0 ? b.error_count : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

// ── MultiNodeSyncView ──────────────────────────────────────────────────────────

const MultiNodeSyncView: React.FC<{ showToast: (msg: string, type?: any) => void }> = ({ showToast }) => {
  const [selfInfo, setSelfInfo] = useState<SelfInfo | null>(null);
  const [nodes, setNodes] = useState<RemoteNode[]>([]);
  const [logs, setLogs] = useState<SyncLogEntry[]>([]);
  const [diskStatus, setDiskStatus] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [busyNodeId, setBusyNodeId] = useState<number | null>(null);
  const [busyAll, setBusyAll] = useState(false);
  const [showToken, setShowToken] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editNode, setEditNode] = useState<RemoteNode | null>(null);
  const [activeArrows, setActiveArrows] = useState<ActiveArrow[]>([]);
  const [deployNode, setDeployNode] = useState<RemoteNode | null>(null);
  const [downloadingNodeId, setDownloadingNodeId] = useState<number | 'self' | null>(null);
  const [renamingSelf, setRenamingSelf] = useState(false);
  const [selfNameInput, setSelfNameInput] = useState('');
  const [savingName, setSavingName] = useState(false);

  const fmtDate = (s: string | null) => {
    if (!s) return '—';
    try { return new Date(s).toLocaleString('tr-TR'); } catch { return s; }
  };

  const secondsAgo = (s: string | null): number | null => {
    if (!s) return null;
    return Math.floor((Date.now() - new Date(s).getTime()) / 1000);
  };

  const isOnline = (node: RemoteNode) => {
    const age = secondsAgo(node.last_heartbeat_at);
    return age !== null && age < 300; // 5 dk eşik
  };

  const load = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const [selfR, nodesR, logsR, diskR] = await Promise.allSettled([
        api.get('/superadmin/sync/self'),
        api.get('/superadmin/sync/nodes'),
        api.get('/superadmin/sync/logs?limit=100'),
        api.get('/superadmin/sync/disk-status'),
      ]);

      if (selfR.status === 'fulfilled') setSelfInfo(selfR.value.data);
      if (nodesR.status === 'fulfilled') setNodes(nodesR.value.data);
      if (diskR.status === 'fulfilled') setDiskStatus(diskR.value.data);
      if (logsR.status === 'fulfilled') {
        const newLogs: SyncLogEntry[] = logsR.value.data;
        setLogs(newLogs);

        // Animasyonlu oklar: son 30 saniye içindeki log kayıtları
        const now = Date.now();
        const recent = newLogs.filter(l => now - new Date(l.created_at).getTime() < 30000);
        setActiveArrows(recent.map(l => ({ from: l.from_node_name, to: l.to_node_name })));
      }
    } catch (e: any) {
      if (!silent) showToast('Veri alınamadı', 'error');
    } finally {
      if (!silent) setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const id = setInterval(() => withSilentRefresh(() => load(true)), 10000);
    return () => clearInterval(id);
  }, []);

  const copy = async (text: string) => {
    try { await navigator.clipboard.writeText(text); showToast('Kopyalandı', 'success'); }
    catch { showToast('Kopyalama başarısız', 'error'); }
  };

  const regenToken = async () => {
    if (!window.confirm("Token yenilensin mi? Mevcut tüm peer bağlantıları bozulur — uzak sunuculara yeni token'ı vermeniz gerekir.")) return;
    try {
      await api.post('/superadmin/sync/regenerate-token');
      showToast('Token yenilendi', 'success');
      load();
    } catch (e: any) { showToast(e.response?.data?.detail || 'Hata', 'error'); }
  };

  const nodeAction = async (nodeId: number, action: 'test' | 'pull' | 'push', label: string) => {
    if (action === 'push' && !window.confirm(`${label}: Bu sunucunun verisi uzak sunucuya MERGE edilecek. Devam edilsin mi?`)) return;
    setBusyNodeId(nodeId);
    try {
      const r = await api.post(`/superadmin/sync/nodes/${nodeId}/${action}`);
      showToast(r.data?.message || `${label} tamamlandı`, 'success');
      load();
    } catch (e: any) {
      showToast(e.response?.data?.detail || `${label} başarısız`, 'error');
    } finally { setBusyNodeId(null); }
  };

  const deleteNode = async (node: RemoteNode) => {
    if (!window.confirm(`"${node.name}" silinsin mi?`)) return;
    try {
      await api.delete(`/superadmin/sync/nodes/${node.id}`);
      showToast('Sunucu silindi', 'success');
      load();
    } catch (e: any) { showToast(e.response?.data?.detail || 'Hata', 'error'); }
  };

  const pushAll = async () => {
    if (!window.confirm('Tüm aktif sunuculara veri gönderilsin mi?')) return;
    setBusyAll(true);
    try {
      const r = await api.post('/superadmin/sync/nodes/push-all');
      const results: any[] = r.data?.results || [];
      const ok = results.filter(x => x.ok).length;
      const fail = results.filter(x => !x.ok).length;
      showToast(`Push tamamlandı: ${ok} başarılı, ${fail} başarısız`, fail ? 'warning' : 'success');
      load();
    } catch (e: any) { showToast(e.response?.data?.detail || 'Hata', 'error'); }
    finally { setBusyAll(false); }
  };

  const downloadBundle = async (nodeId: number | 'self', nodeName: string) => {
    setDownloadingNodeId(nodeId);
    try {
      const url = nodeId === 'self'
        ? '/superadmin/sync/bundle'
        : `/superadmin/sync/nodes/${nodeId}/bundle`;
      const r = await api.get(url, { responseType: 'blob' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(r.data);
      a.download = `${nodeName.toLowerCase().replace(/\s+/g, '_')}_bundle.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      showToast('Bundle indirildi', 'success');
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'İndirme başarısız', 'error');
    } finally {
      setDownloadingNodeId(null);
    }
  };

  const downloadAllBundles = async () => {
    setDownloadingNodeId('self');
    try {
      const r = await api.get('/superadmin/sync/bundle-all', { responseType: 'blob' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(r.data);
      a.download = 'all_servers_bundle.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      const nodeCount = 1 + nodes.filter(n => n.is_active).length;
      showToast(`Tüm sunucuların bundle'ı indirildi (${nodeCount} sunucu)`, 'success');
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'İndirme başarısız', 'error');
    } finally {
      setDownloadingNodeId(null);
    }
  };

  const saveSelfName = async () => {
    if (!selfNameInput.trim()) return;
    setSavingName(true);
    try {
      await api.put('/superadmin/sync/self', { name: selfNameInput.trim() });
      showToast('Sunucu adı güncellendi', 'success');
      setRenamingSelf(false);
      load();
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Ad güncellenemedi', 'error');
    } finally { setSavingName(false); }
  };

  const isArrowActive = (from: string, to: string) =>
    activeArrows.some(a => a.from === from && a.to === to);

  if (loading && !selfInfo) {
    return (
      <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200 dark:border-slate-800 text-center text-slate-400 text-sm">
        Yükleniyor...
      </div>
    );
  }

  const selfName = selfInfo?.name || 'Ana Sunucu';

  return (
    <div className="space-y-5">
      {/* Üst bar: Bu sunucu + token */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-5">
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <Network size={20} className="text-indigo-600" />
          <h3 className="text-lg font-black text-slate-800 dark:text-slate-100">Çok-Sunuculu Senkronizasyon</h3>
          <div className="ml-auto flex items-center gap-2 flex-wrap">
            <button
              onClick={downloadAllBundles}
              disabled={downloadingNodeId === 'self'}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold disabled:opacity-50"
              title="Tüm sunucuların kaynak dosyalarını tek ZIP olarak indir (bu sunucu + aktif uzak node'lar)"
            >
              <Download size={13} /> {downloadingNodeId === 'self' ? 'İndiriliyor...' : 'Tüm Bundle\'ları İndir'}
            </button>

            {/* Bu sunucunun adı — tıklanınca düzenlenebilir */}
            {renamingSelf ? (
              <div className="flex items-center gap-1">
                <input
                  autoFocus
                  value={selfNameInput}
                  onChange={e => setSelfNameInput(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') saveSelfName(); if (e.key === 'Escape') setRenamingSelf(false); }}
                  className="px-2 py-1 text-xs rounded-lg border border-indigo-400 dark:border-indigo-600 bg-white dark:bg-slate-800 text-slate-800 dark:text-white font-bold w-36 outline-none"
                  placeholder="Sunucu adı"
                />
                <button onClick={saveSelfName} disabled={savingName}
                  className="px-2 py-1 rounded-lg bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 disabled:opacity-50">
                  {savingName ? '...' : 'Kaydet'}
                </button>
                <button onClick={() => setRenamingSelf(false)}
                  className="px-2 py-1 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs">
                  İptal
                </button>
              </div>
            ) : (
              <button
                onClick={() => { setSelfNameInput(selfName); setRenamingSelf(true); }}
                className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 text-xs font-bold hover:bg-emerald-200 dark:hover:bg-emerald-900/50 transition-colors"
                title="Sunucu adını düzenle"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                {selfName} (Bu Sunucu)
                <Settings size={10} className="opacity-60" />
              </button>
            )}
          </div>
        </div>

        {/* Bu sunucunun sistem bilgileri */}
        {selfInfo && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
            <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-3 flex items-center gap-2">
              <Cpu size={16} className="text-indigo-500 shrink-0" />
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-bold">CPU</div>
                <div className="text-sm font-bold text-slate-700 dark:text-slate-200">
                  {selfInfo.sys_cpu_count != null ? `${selfInfo.sys_cpu_count} çekirdek` : '—'}
                </div>
              </div>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-3 flex items-center gap-2">
              <Activity size={16} className="text-purple-500 shrink-0" />
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-bold">RAM</div>
                <div className="text-sm font-bold text-slate-700 dark:text-slate-200">
                  {selfInfo.sys_ram_gb != null ? `${selfInfo.sys_ram_gb} GB` : '—'}
                </div>
              </div>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-3 flex items-center gap-2">
              <HardDrive size={16} className="text-amber-500 shrink-0" />
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-bold">Disk</div>
                <div className="text-sm font-bold text-slate-700 dark:text-slate-200">
                  {selfInfo.sys_disk_total_gb != null
                    ? `${selfInfo.sys_disk_free_gb ?? '?'} / ${selfInfo.sys_disk_total_gb} GB`
                    : '—'}
                </div>
              </div>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-3 flex items-center gap-2">
              <Server size={16} className="text-slate-500 shrink-0" />
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-bold">OS</div>
                <div className="text-sm font-bold text-slate-700 dark:text-slate-200">
                  {selfInfo.sys_os || '—'}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Token */}
        <div>
          <div className="text-xs font-bold text-slate-500 uppercase mb-2">
            Bu Sunucunun Token'ı <span className="text-slate-400 font-normal">(diğer sunucuların peer_token alanına girin)</span>
          </div>
          <div className="flex items-center gap-2">
            <code className="flex-1 px-3 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-mono text-slate-700 dark:text-slate-200 break-all select-all">
              {showToken ? (selfInfo?.our_token || '—') : '•'.repeat(32)}
            </code>
            <button onClick={() => setShowToken(s => !s)}
              className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800" title={showToken ? 'Gizle' : 'Göster'}>
              {showToken ? <EyeOff size={14} /> : <Eye size={14} />}
            </button>
            {selfInfo?.our_token && (
              <button onClick={() => copy(selfInfo.our_token)}
                className="p-2 rounded-lg text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/30" title="Kopyala">
                <Copy size={14} />
              </button>
            )}
            <button onClick={regenToken}
              className="px-3 py-2 rounded-lg text-xs text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-900/30 font-bold">
              Yenile
            </button>
          </div>
        </div>
      </div>

      {/* Disk Durumu — tek bulut mimarisi */}
      {diskStatus && diskStatus.servers && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-5">
          <div className="text-xs font-bold text-slate-500 uppercase mb-4 flex items-center gap-2">
            <HardDrive size={14} /> Disk Durumu — Tek Bulut Depolama
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {diskStatus.servers.map((srv: any) => {
              const pct = srv.used_percent ?? 0;
              const barColor = pct >= 90 ? 'bg-red-500' : pct >= 70 ? 'bg-amber-500' : 'bg-emerald-500';
              const textColor = pct >= 90 ? 'text-red-600 dark:text-red-400' : pct >= 70 ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600 dark:text-emerald-400';
              return (
                <div key={srv.node_id} className="border border-slate-200 dark:border-slate-700 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Server size={16} className={srv.is_self ? 'text-indigo-500' : 'text-slate-400'} />
                    <span className="font-bold text-sm text-slate-800 dark:text-slate-100">{srv.name}</span>
                    {srv.is_self && <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 font-bold">ANA</span>}
                    {srv.disk_low && <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 font-bold">⚠ DÜŞÜK</span>}
                  </div>
                  {/* Disk bar */}
                  <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-3 mb-2 overflow-hidden">
                    <div className={`h-3 rounded-full transition-all ${barColor}`} style={{ width: `${Math.min(pct, 100)}%` }} />
                  </div>
                  <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400 mb-3">
                    <span>{srv.used_gb} GB kullanıldı</span>
                    <span className={`font-bold ${textColor}`}>{pct}%</span>
                    <span>{srv.total_gb} GB toplam</span>
                  </div>
                  <div className="flex items-center gap-4 text-xs text-slate-500 dark:text-slate-400">
                    <span>🆓 Boş: <span className="font-semibold text-slate-700 dark:text-slate-200">{srv.free_gb} GB</span></span>
                    <span>📁 Dosya: <span className="font-semibold text-slate-700 dark:text-slate-200">{srv.file_count}</span></span>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-3 text-xs text-slate-400 dark:text-slate-500">
            Eşik: {diskStatus.threshold_gb} GB boş alan altında yeni dosyalar diğer sunucuya yönlendirilir
          </div>
        </div>
      )}

      {/* Topoloji diyagramı */}
      {nodes.length > 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-5">
          <div className="text-xs font-bold text-slate-500 uppercase mb-4 flex items-center gap-2">
            <Network size={14} /> Sunucu Topolojisi
          </div>
          <div className="overflow-x-auto">
            <div className="flex items-center gap-4 min-w-max flex-wrap">
              {/* Bu sunucu */}
              <div className="flex flex-col items-center gap-1">
                <div className="w-16 h-16 rounded-2xl bg-indigo-600 flex items-center justify-center shadow-lg">
                  <Server size={28} className="text-white" />
                </div>
                <div className="text-xs font-bold text-indigo-600 dark:text-indigo-400 text-center max-w-[80px] truncate">{selfName}</div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 font-bold">ANA</span>
              </div>

              {/* Ok + uzak sunucular */}
              {nodes.map(node => {
                const online = isOnline(node);
                const toActive = isArrowActive(selfName, node.name);
                // Show reverse arrow if peer is online (heartbeat recent), even if no log entry
                // exists for that direction (e.g. when peer can't reach us through a firewall).
                const fromActive = isArrowActive(node.name, selfName) || (toActive && online);
                return (
                  <React.Fragment key={node.id}>
                    <div className="flex flex-col items-center gap-1">
                      {/* Ok (çift yönlü) */}
                      <div className="relative flex items-center justify-center w-16 h-6">
                        <svg viewBox="-8 0 80 24" className="w-full h-full overflow-visible">
                          {/* Sol→Sağ ok (push: self→node) */}
                          <line x1="4" y1="8" x2="60" y2="8" stroke={toActive ? '#6366f1' : '#cbd5e1'} strokeWidth="2"
                            strokeDasharray={toActive ? '6 3' : '0'}
                            style={toActive ? { animation: 'dash-move 0.8s linear infinite' } : {}}>
                          </line>
                          <polygon points="60,4 60,12 68,8" fill={toActive ? '#6366f1' : '#cbd5e1'} />
                          {/* Sağ→Sol ok (pull: node→self) — line drawn R→L so dash-move (-18) moves R→L */}
                          <line x1="60" y1="16" x2="4" y2="16" stroke={fromActive ? '#10b981' : '#cbd5e1'} strokeWidth="2"
                            strokeDasharray={fromActive ? '6 3' : '0'}
                            style={fromActive ? { animation: 'dash-move 0.8s linear infinite' } : {}}>
                          </line>
                          <polygon points="4,12 4,20 -4,16" fill={fromActive ? '#10b981' : '#cbd5e1'} />
                        </svg>
                      </div>
                      <div className="text-[9px] text-slate-400 text-center">
                        {toActive && <span className="text-indigo-500 font-bold">→ Push</span>}
                        {fromActive && <span className="text-emerald-500 font-bold"> ← Pull</span>}
                        {!toActive && !fromActive && 'bekleniyor'}
                      </div>
                    </div>

                    {/* Uzak sunucu kutusu */}
                    <div className="flex flex-col items-center gap-1">
                      <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-md ${
                        online ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'
                      }`}>
                        <Server size={28} className="text-white" />
                      </div>
                      <div className="text-xs font-bold text-slate-700 dark:text-slate-300 text-center max-w-[80px] truncate">{node.name}</div>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        online
                          ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300'
                          : 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400'
                      }`}>
                        {online ? 'Çevrimiçi' : 'Çevrimdışı'}
                      </span>
                    </div>
                  </React.Fragment>
                );
              })}
            </div>
          </div>

          {/* CSS animasyonu */}
          <style>{`
            @keyframes dash-move {
              to { stroke-dashoffset: -18; }
            }
            @keyframes dash-move-rev {
              to { stroke-dashoffset: 18; }
            }
          `}</style>
        </div>
      )}

      {/* Uzak sunucu kartları */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-bold text-slate-700 dark:text-slate-200 flex items-center gap-2">
            <Server size={15} /> Uzak Sunucular ({nodes.length})
          </h4>
          <div className="flex gap-2">
            {nodes.length > 0 && (
              <button onClick={pushAll} disabled={busyAll}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-600 text-white text-xs font-bold hover:bg-purple-700 disabled:opacity-50">
                <ArrowUpToLine size={13} /> {busyAll ? 'Gönderiliyor...' : 'Tümüne Push'}
              </button>
            )}
            <button onClick={() => { setEditNode(null); setShowAddModal(true); }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700">
              <Plus size={13} /> Sunucu Ekle
            </button>
          </div>
        </div>

        {nodes.length === 0 && (
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 p-8 text-center">
            <Server size={32} className="mx-auto mb-3 text-slate-300 dark:text-slate-600" />
            <div className="text-sm text-slate-500 dark:text-slate-400">Henüz uzak sunucu eklenmemiş.</div>
            <button onClick={() => { setEditNode(null); setShowAddModal(true); }}
              className="mt-3 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700">
              İlk Sunucuyu Ekle
            </button>
          </div>
        )}

        {nodes.map(node => {
          const online = isOnline(node);
          const busy = busyNodeId === node.id;
          const hbAge = secondsAgo(node.last_heartbeat_at);
          return (
            <div key={node.id} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-5">
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${online ? 'bg-emerald-500' : 'bg-slate-200 dark:bg-slate-700'}`}>
                    {online ? <Wifi size={18} className="text-white" /> : <WifiOff size={18} className="text-slate-500" />}
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold text-slate-800 dark:text-slate-100 truncate">{node.name}</div>
                    <div className="text-xs font-mono text-slate-400 truncate">{node.url}</div>
                  </div>
                  <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                    online
                      ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300'
                      : 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400'
                  }`}>
                    {online ? 'Çevrimiçi' : 'Çevrimdışı'}
                  </span>
                </div>

                {/* Eylemler */}
                <div className="flex flex-wrap gap-2 shrink-0">
                  <button onClick={() => nodeAction(node.id, 'test', 'Test')} disabled={busy}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 disabled:opacity-50" title="Bağlantıyı test et">
                    <PlugZap size={12} /> Test
                  </button>
                  <button onClick={() => nodeAction(node.id, 'pull', 'Pull')} disabled={busy}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700 disabled:opacity-50" title="Uzak sunucudan çek">
                    <ArrowDownToLine size={12} /> Pull
                  </button>
                  <button onClick={() => nodeAction(node.id, 'push', 'Push')} disabled={busy}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 disabled:opacity-50" title="Uzak sunucuya gönder">
                    <ArrowUpToLine size={12} /> Push
                  </button>
                  <button
                    onClick={() => downloadBundle(node.id, node.name)}
                    disabled={busy || downloadingNodeId === node.id}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold disabled:opacity-50"
                    title="Bu sunucunun dosyalarını ZIP olarak indir"
                  >
                    <Download size={12} /> {downloadingNodeId === node.id ? '...' : 'İndir'}
                  </button>
                  <button
                    onClick={() => setDeployNode(node)}
                    disabled={busy}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-orange-500 text-white text-xs font-bold hover:bg-orange-600 disabled:opacity-50"
                    title="Bu sunucuya uzak güncelleme gönder"
                  >
                    <Upload size={12} /> Güncelle
                  </button>
                  <button onClick={() => { setEditNode(node); setShowAddModal(true); }} disabled={busy}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold">
                    <Settings size={12} />
                  </button>
                  <button onClick={() => deleteNode(node)} disabled={busy}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-900/30 text-xs font-bold">
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>

              {/* Sistem specs */}
              <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-2 flex items-center gap-1.5">
                  <Cpu size={13} className="text-indigo-400 shrink-0" />
                  <span className="text-xs text-slate-600 dark:text-slate-300">
                    {node.sys_cpu_count != null ? `${node.sys_cpu_count} çekirdek` : '—'}
                  </span>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-2 flex items-center gap-1.5">
                  <Activity size={13} className="text-purple-400 shrink-0" />
                  <span className="text-xs text-slate-600 dark:text-slate-300">
                    {node.sys_ram_gb != null ? `${node.sys_ram_gb} GB RAM` : '—'}
                  </span>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-2 flex items-center gap-1.5">
                  <HardDrive size={13} className="text-amber-400 shrink-0" />
                  <span className="text-xs text-slate-600 dark:text-slate-300">
                    {node.sys_disk_total_gb != null
                      ? `${node.sys_disk_free_gb ?? '?'} / ${node.sys_disk_total_gb} GB`
                      : '—'}
                  </span>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-2 flex items-center gap-1.5">
                  <Server size={13} className="text-slate-400 shrink-0" />
                  <span className="text-xs text-slate-600 dark:text-slate-300">{node.sys_os || '—'}</span>
                </div>
              </div>

              {/* Zaman bilgileri */}
              <div className="mt-3 flex flex-wrap gap-4 text-xs text-slate-500 dark:text-slate-400">
                <span>
                  <span className="font-bold text-slate-600 dark:text-slate-300">Heartbeat:</span>{' '}
                  {hbAge != null ? (hbAge < 60 ? `${hbAge}sn önce` : fmtDate(node.last_heartbeat_at)) : '—'}
                </span>
                <span>
                  <span className="font-bold text-slate-600 dark:text-slate-300">Son push:</span>{' '}
                  {node.last_sync_at ? (() => { const s = secondsAgo(node.last_sync_at); return s != null && s < 120 ? `${s}sn önce` : fmtDate(node.last_sync_at); })() : '—'}
                </span>
                <span>
                  <span className="font-bold text-slate-600 dark:text-slate-300">Son pull:</span>{' '}
                  {node.last_pull_at ? (() => { const s = secondsAgo(node.last_pull_at); return s != null && s < 120 ? `${s}sn önce` : fmtDate(node.last_pull_at); })() : '—'}
                </span>
              </div>

              {/* Hata */}
              {node.last_error && (
                <div className="mt-2 px-3 py-2 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-xs font-mono text-red-700 dark:text-red-300 break-all">
                  {node.last_error}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Sync logları */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-5">
        <h4 className="text-sm font-bold text-slate-700 dark:text-slate-200 mb-3 flex items-center gap-2">
          <Activity size={15} /> Son Senkronizasyon Kayıtları
        </h4>
        {logs.length === 0 ? (
          <div className="text-center text-sm text-slate-400 py-6">Henüz log kaydı yok.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-700">
                  <th className="text-left py-2 px-3 text-slate-500 font-bold uppercase text-[10px]">Zaman</th>
                  <th className="text-left py-2 px-3 text-slate-500 font-bold uppercase text-[10px]">Yön</th>
                  <th className="text-left py-2 px-3 text-slate-500 font-bold uppercase text-[10px]">Olay</th>
                  <th className="text-right py-2 px-3 text-slate-500 font-bold uppercase text-[10px]">Kayıt</th>
                  <th className="text-right py-2 px-3 text-slate-500 font-bold uppercase text-[10px]">Süre</th>
                  <th className="text-left py-2 px-3 text-slate-500 font-bold uppercase text-[10px]">Tablo Detayı / Durum</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {logs.map(log => {
                  const ageMs = Date.now() - new Date(log.created_at).getTime();
                  const isNew = ageMs < 30000;
                  const typeColors: Record<string, string> = {
                    push_delta: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300',
                    pull_delta: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
                    push: 'bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300',
                    pull: 'bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300',
                    heartbeat: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300',
                    HEARTBEAT: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300',
                    error: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300',
                  };
                  // Tablo özeti — details.tables nesnesinden
                  const tblSummary: string[] = [];
                  if (log.details?.tables && typeof log.details.tables === 'object') {
                    Object.entries(log.details.tables).forEach(([tbl, stat]: [string, any]) => {
                      if (tbl === '_deletions') {
                        if (stat?.deleted > 0) tblSummary.push(`🗑 ${stat.deleted} silme`);
                      } else if (stat && typeof stat === 'object') {
                        const parts: string[] = [];
                        if (stat.inserted > 0) parts.push(`+${stat.inserted}`);
                        if (stat.updated > 0) parts.push(`~${stat.updated}`);
                        if (stat.conflict_skipped > 0) parts.push(`⚡${stat.conflict_skipped}`);
                        if (parts.length) tblSummary.push(`${tbl}:${parts.join(',')}`);
                      }
                    });
                  }
                  return (
                    <tr key={log.id} className={`hover:bg-slate-50 dark:hover:bg-slate-800/50 ${isNew ? 'bg-indigo-50/40 dark:bg-indigo-900/10' : ''}`}>
                      <td className="py-2 px-3 text-slate-500 whitespace-nowrap">
                        {fmtDate(log.created_at)}
                        {isNew && <span className="ml-1 text-indigo-500 font-bold animate-pulse">●</span>}
                      </td>
                      <td className="py-2 px-3 whitespace-nowrap">
                        <span className="font-semibold text-slate-700 dark:text-slate-200">{log.from_node_name}</span>
                        <ArrowRight size={11} className="inline mx-1 text-slate-400" />
                        <span className="font-semibold text-slate-700 dark:text-slate-200">{log.to_node_name}</span>
                      </td>
                      <td className="py-2 px-3">
                        <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${typeColors[log.event_type] || 'bg-slate-100 text-slate-600'}`}>
                          {log.event_type.replace('_', ' ').toUpperCase()}
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right text-slate-600 dark:text-slate-300 font-mono">
                        {log.records_total != null ? log.records_total : '—'}
                      </td>
                      <td className="py-2 px-3 text-right text-slate-600 dark:text-slate-300 font-mono">
                        {log.duration_ms != null ? `${log.duration_ms}ms` : '—'}
                      </td>
                      <td className="py-2 px-3 max-w-xs">
                        {log.error
                          ? <span className="text-red-600 dark:text-red-400 font-mono text-[10px] truncate block" title={log.error}>{log.error}</span>
                          : tblSummary.length > 0
                            ? <span className="text-slate-500 font-mono text-[10px] truncate block" title={tblSummary.join(' | ')}>{tblSummary.slice(0,4).join(' | ')}{tblSummary.length > 4 ? ' …' : ''}</span>
                            : <span className="text-emerald-600 dark:text-emerald-400 font-bold text-[10px]">✓ Değişiklik yok</span>
                        }
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modaller */}
      {showAddModal && (
        <AddNodeModal
          editNode={editNode}
          onClose={() => { setShowAddModal(false); setEditNode(null); }}
          onSaved={() => { setShowAddModal(false); setEditNode(null); load(); }}
          showToast={showToast}
        />
      )}
      {deployNode && (
        <DeployModal
          node={deployNode}
          onClose={() => setDeployNode(null)}
          showToast={showToast}
        />
      )}
    </div>
  );
};

// ============================================================
// SystemBackupView — TAM SİSTEM YEDEĞİ (super admin'ler dahil)
// ============================================================

const SystemBackupView: React.FC<{ showToast: (msg: string, type?: any) => void }> = ({ showToast }) => {
  const [creating, setCreating] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [confirmRestore, setConfirmRestore] = useState<File | null>(null);
  const [lastStats, setLastStats] = useState<any>(null);

  const downloadBackup = async () => {
    setCreating(true);
    try {
      const resp = await api.post('/superadmin/system-backup/create', null, {
        responseType: 'blob',
      });
      const blob = new Blob([resp.data], { type: 'application/zip' });
      const ts = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `stokfinans-system-${ts}.zip`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      showToast('Sistem yedeği indirildi', 'success');
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Yedek oluşturulamadı', 'error');
    } finally {
      setCreating(false);
    }
  };

  const onFilePicked = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!f.name.toLowerCase().endsWith('.zip')) {
      showToast('Lütfen .zip uzantılı sistem yedeği seçin', 'error');
      return;
    }
    setConfirmRestore(f);
    e.target.value = '';
  };

  const doRestore = async () => {
    if (!confirmRestore) return;
    setRestoring(true);
    try {
      const fd = new FormData();
      fd.append('file', confirmRestore);
      const resp = await api.post('/superadmin/system-backup/restore', fd, {
        headers: { 'Content-Type': 'multipart/form-data' },
        timeout: 600000, // 10 dk
      });
      setLastStats(resp.data?.stats || null);
      showToast('Sistem yedeği geri yüklendi. Lütfen tekrar giriş yapın.', 'success');
      setConfirmRestore(null);
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Geri yükleme başarısız', 'error');
    } finally {
      setRestoring(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Bilgi kartı */}
      <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" size={20}/>
          <div className="text-sm text-amber-900 dark:text-amber-200">
            <p className="font-bold mb-1">Tam Sistem Yedeği</p>
            <p>Bu yedek <strong>tüm tablolar</strong> (süper adminler dahil tüm kullanıcılar, paketler, e-posta ayarları, tüm bayi verileri, FTP/SFTP sunucuları) ve <strong>tüm dosyalar</strong> (uploads/, mevcut bayi yedekleri) içerir. <strong>Sunucu Eşleşmesi (sync_peer) hariç tutulur</strong> çünkü o yapılandırma makineye özgüdür.</p>
            <p className="mt-2">Yedeği başka bir StokFinans kurulumuna yüklediğinizde, mevcut tüm veri silinir ve yedektekiyle değiştirilir.</p>
          </div>
        </div>
      </div>

      {/* Yedek oluştur */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl p-5 shadow-sm">
        <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-2 flex items-center gap-2">
          <Download size={18}/> Yedek Oluştur ve İndir
        </h3>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
          Tüm sistemin anlık durumunu .zip olarak bilgisayarınıza indirin.
        </p>
        <button onClick={downloadBackup} disabled={creating}
          className="px-5 py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 flex items-center gap-2 disabled:opacity-50">
          <Download size={16}/>
          {creating ? 'Hazırlanıyor...' : 'Tam Sistem Yedeği İndir (.zip)'}
        </button>
      </div>

      {/* Yedek yükle */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl p-5 shadow-sm">
        <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-2 flex items-center gap-2">
          <Upload size={18}/> Yedek Yükle ve Geri Yükle
        </h3>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
          .zip uzantılı bir sistem yedeği seçin. Mevcut veri silinecek, geri alınamaz.
        </p>
        <label className="inline-flex items-center gap-2 px-5 py-3 bg-rose-600 text-white font-bold rounded-xl hover:bg-rose-700 cursor-pointer">
          <Upload size={16}/>
          Yedek Dosyası Seç (.zip)
          <input type="file" accept=".zip,application/zip" onChange={onFilePicked} className="hidden" disabled={restoring}/>
        </label>
      </div>

      {/* Son işlem istatistiği */}
      {lastStats && (
        <div className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 rounded-xl p-4">
          <h4 className="font-bold text-emerald-800 dark:text-emerald-300 mb-2 flex items-center gap-2">
            <CheckCircle size={16}/> Geri Yükleme Tamamlandı
          </h4>
          <div className="text-xs text-emerald-700 dark:text-emerald-300 grid grid-cols-2 gap-1">
            {Object.entries(lastStats.tables || {}).map(([k, v]) => (
              <div key={k}><strong>{k}:</strong> {String(v)} satır</div>
            ))}
            <div><strong>uploads:</strong> {lastStats.uploads ?? 0} dosya</div>
            <div><strong>backups:</strong> {lastStats.backups ?? 0} dosya</div>
          </div>
          {lastStats.warning && (
            <p className="mt-2 text-xs text-amber-700 dark:text-amber-300 font-bold">⚠ {lastStats.warning}</p>
          )}
        </div>
      )}

      {/* Restore confirm modal */}
      {confirmRestore && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => !restoring && setConfirmRestore(null)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-lg w-full p-6" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-rose-600 dark:text-rose-400 mb-3 flex items-center gap-2">
              <AlertTriangle size={20}/> DİKKAT: Tüm Veri Silinecek
            </h3>
            <div className="space-y-3 text-sm text-slate-700 dark:text-slate-200">
              <p>Yüklenen yedek: <strong className="font-mono">{confirmRestore.name}</strong> ({(confirmRestore.size / 1024 / 1024).toFixed(2)} MB)</p>
              <div className="bg-rose-50 dark:bg-rose-900/20 border border-rose-200 dark:border-rose-800 rounded-xl p-3">
                <p className="font-bold mb-1">Bu işlem:</p>
                <ul className="list-disc list-inside space-y-1 text-xs">
                  <li>Tüm kullanıcıları, bayileri ve süper adminleri siler</li>
                  <li>Tüm ürünleri, işlemleri, kategorileri, ödemeleri siler</li>
                  <li>Tüm yüklü dosyaları ve mevcut bayi yedeklerini siler</li>
                  <li>Yedekteki tüm veriyle değiştirir</li>
                  <li><strong>GERİ ALINAMAZ</strong></li>
                </ul>
              </div>
              <p className="text-xs text-slate-500">İşlem tamamlandıktan sonra oturumunuz kapanabilir, yeniden giriş yapmanız gerekir.</p>
            </div>
            <div className="flex justify-end gap-3 mt-5">
              <button onClick={() => setConfirmRestore(null)} disabled={restoring}
                className="px-4 py-2 text-sm text-slate-500 hover:text-slate-700">İptal</button>
              <button onClick={doRestore} disabled={restoring}
                className="px-5 py-2 bg-rose-600 text-white text-sm font-bold rounded-xl hover:bg-rose-700 flex items-center gap-2 disabled:opacity-50">
                <Upload size={14}/> {restoring ? 'Geri yükleniyor...' : 'Evet, Geri Yükle'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ============================================================
// Destek & Talep Yönetimi — Süper Admin
// ============================================================

const STATUS_CFG_ADMIN: Record<string, { label: string; color: string; dot: string }> = {
  open:        { label: 'Açık',    color: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300', dot: 'bg-green-500' },
  in_progress: { label: 'İşlemde', color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300',   dot: 'bg-blue-500' },
  closed:      { label: 'Kapalı',  color: 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400',   dot: 'bg-slate-400' },
};


function fmtAdminDate(iso: string) {
  if (!iso) return '';
  return new Date(iso).toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' });
}

interface AdminTicket {
  id: number; subject: string; category: string; status: string;
  created_at: string; updated_at: string; message_count: number;
  last_message_at: string | null; bayi_name: string | null; bayi_email: string | null; bayi_id: number | null;
}
interface AdminMessage { id: number; is_from_admin: boolean; body: string; created_at: string; sender_name: string | null; }
interface AdminTicketDetail extends AdminTicket { messages: AdminMessage[]; }

const SupportAdminView: React.FC<{ showToast: (m: string, t?: string) => void }> = ({ showToast }) => {
  const [tickets, setTickets] = useState<AdminTicket[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 30;

  const [selected, setSelected] = useState<AdminTicketDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [replyBody, setReplyBody] = useState('');
  const [sending, setSending] = useState(false);
  const [changingStatus, setChangingStatus] = useState(false);
  const messagesEndRef = React.useRef<HTMLDivElement>(null);

  const fetchTickets = async () => {
    setLoading(true);
    try {
      const params: any = { page, page_size: PAGE_SIZE };
      if (statusFilter !== 'all') params.status = statusFilter;
      if (search.trim()) params.search = search.trim();
      const res = await api.get('/superadmin/tickets', { params });
      setTickets(res.data.items);
      setTotal(res.data.total);
    } catch { showToast('Talepler yüklenemedi.', 'error'); }
    finally { setLoading(false); }
  };

  const fetchDetail = async (id: number) => {
    setDetailLoading(true);
    try {
      const res = await api.get(`/superadmin/tickets/${id}`);
      setSelected(res.data);
    } catch { showToast('Detay yüklenemedi.', 'error'); }
    finally { setDetailLoading(false); }
  };

  useEffect(() => { setPage(1); }, [statusFilter, search]);
  useEffect(() => { fetchTickets(); }, [statusFilter, search, page]);

  useEffect(() => {
    if (messagesEndRef.current) messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
  }, [selected?.messages]);

  const handleReply = async () => {
    if (!selected || !replyBody.trim()) return;
    setSending(true);
    try {
      await api.post(`/superadmin/tickets/${selected.id}/messages`, { body: replyBody.trim() });
      setReplyBody('');
      await fetchDetail(selected.id);
      fetchTickets();
    } catch (e: any) { showToast(e?.response?.data?.detail || 'Mesaj gönderilemedi.', 'error'); }
    finally { setSending(false); }
  };

  const handleStatusChange = async (newStatus: string) => {
    if (!selected) return;
    setChangingStatus(true);
    try {
      await api.patch(`/superadmin/tickets/${selected.id}/status`, { status: newStatus });
      await fetchDetail(selected.id);
      fetchTickets();
      showToast('Durum güncellendi.', 'success');
    } catch { showToast('Durum değiştirilemedi.', 'error'); }
    finally { setChangingStatus(false); }
  };

  const STATUS_TABS_A = [
    { v: 'all', l: 'Tümü' }, { v: 'open', l: 'Açık' }, { v: 'in_progress', l: 'İşlemde' }, { v: 'closed', l: 'Kapalı' },
  ];

  return (
    <div className="mt-4 flex flex-col gap-4" style={{ minHeight: 600 }}>
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 rounded-lg p-1">
          {STATUS_TABS_A.map(tab => (
            <button key={tab.v} onClick={() => setStatusFilter(tab.v)}
              className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${statusFilter === tab.v ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}>
              {tab.l}
            </button>
          ))}
        </div>
        <input
          type="text" value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Bayi veya konu ara..."
          className="flex-1 min-w-[200px] rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-800 dark:text-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400"
        />
        <button onClick={fetchTickets} className="p-2 rounded-lg border border-slate-200 dark:border-slate-600 text-slate-500 hover:text-indigo-600 hover:border-indigo-400 transition-colors">
          <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
        </button>
        <span className="text-xs text-slate-400">{total} talep</span>
      </div>

      {/* Main area */}
      <div className="flex gap-4 flex-1 min-h-0 overflow-hidden" style={{ minHeight: 500 }}>

        {/* Ticket table */}
        <div className={`overflow-y-auto overflow-x-hidden flex-shrink-0 ${selected ? 'w-2/5' : 'w-full'}`}>
          {loading ? (
            <div className="text-center py-16 text-slate-400"><RefreshCw size={24} className="animate-spin mx-auto mb-2" /></div>
          ) : tickets.length === 0 ? (
            <div className="text-center py-16 text-slate-400">
              <Inbox size={40} className="mx-auto mb-3 opacity-30" />
              <p className="font-medium">Talep bulunamadı</p>
            </div>
          ) : (
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="text-xs text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                  <th className="text-left py-2 px-3 font-semibold">#</th>
                  <th className="text-left py-2 px-3 font-semibold">Bayi</th>
                  <th className="text-left py-2 px-3 font-semibold">Konu</th>
                  <th className="text-left py-2 px-3 font-semibold">Kategori</th>
                  <th className="text-left py-2 px-3 font-semibold">Durum</th>
                  <th className="text-left py-2 px-3 font-semibold">Son güncelleme</th>
                  <th className="text-right py-2 px-3 font-semibold">Mesaj</th>
                </tr>
              </thead>
              <tbody>
                {tickets.map(t => {
                  const sc = STATUS_CFG_ADMIN[t.status] || STATUS_CFG_ADMIN.open;
                  const isActive = selected?.id === t.id;
                  return (
                    <tr key={t.id} onClick={() => fetchDetail(t.id)}
                      className={`border-b border-slate-100 dark:border-slate-800 cursor-pointer transition-colors ${isActive ? 'bg-indigo-50 dark:bg-indigo-950/30' : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'}`}>
                      <td className="py-2.5 px-3 text-slate-400 dark:text-slate-500 font-mono text-xs">{t.id}</td>
                      <td className="py-2.5 px-3">
                        <p className="font-medium text-slate-800 dark:text-white text-xs">{t.bayi_name || '—'}</p>
                        <p className="text-slate-400 text-[10px]">{t.bayi_email || ''}</p>
                      </td>
                      <td className="py-2.5 px-3 text-slate-700 dark:text-slate-200 max-w-[200px] truncate">{t.subject}</td>
                      <td className="py-2.5 px-3 text-slate-400 text-xs">{t.category}</td>
                      <td className="py-2.5 px-3">
                        <span className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium w-fit ${sc.color}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                          {sc.label}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-xs text-slate-400">{fmtAdminDate(t.updated_at)}</td>
                      <td className="py-2.5 px-3 text-right text-xs text-slate-400 flex items-center justify-end gap-1">
                        <MessageCircle size={11} /> {t.message_count}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}

          {/* Pagination */}
          {total > PAGE_SIZE && (
            <div className="flex justify-center gap-2 mt-4">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                className="px-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-800">Önceki</button>
              <span className="px-3 py-1.5 text-xs text-slate-500">{page} / {Math.ceil(total / PAGE_SIZE)}</span>
              <button onClick={() => setPage(p => p + 1)} disabled={page >= Math.ceil(total / PAGE_SIZE)}
                className="px-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-800">Sonraki</button>
            </div>
          )}
        </div>

        {/* Detail panel */}
        {selected && (
          <div className="flex-1 min-w-0 flex flex-col bg-white dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 min-h-0 overflow-hidden" style={{ minHeight: 400 }}>
            {/* Header */}
            <div className="p-4 border-b border-slate-200 dark:border-slate-700 shrink-0">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-slate-800 dark:text-white text-base leading-snug">{selected.subject}</h3>
                  <div className="flex flex-wrap items-center gap-2 mt-1">
                    <span className="text-xs text-slate-400">{selected.bayi_name}</span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-slate-400">{selected.category}</span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-slate-400">#{selected.id}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {/* Status dropdown */}
                  <select
                    value={selected.status}
                    onChange={e => handleStatusChange(e.target.value)}
                    disabled={changingStatus}
                    className="text-xs rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-400"
                  >
                    <option value="open">Açık</option>
                    <option value="in_progress">İşlemde</option>
                    <option value="closed">Kapalı</option>
                  </select>
                  <button onClick={() => setSelected(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1">
                    <X size={18} />
                  </button>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
              {detailLoading ? (
                <div className="text-center py-8 text-slate-400"><RefreshCw size={20} className="animate-spin mx-auto" /></div>
              ) : selected.messages.map(msg => (
                <div key={msg.id} className={`flex min-w-0 ${msg.is_from_admin ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] min-w-0 rounded-2xl px-4 py-3 text-sm shadow-sm ${
                    msg.is_from_admin
                      ? 'bg-indigo-600 text-white rounded-tr-sm'
                      : 'bg-slate-100 dark:bg-slate-700 text-slate-800 dark:text-slate-100 rounded-tl-sm'
                  }`}>
                    {!msg.is_from_admin && (
                      <p className="text-[10px] font-bold uppercase tracking-wide mb-1 opacity-60">{msg.sender_name || 'Bayi'}</p>
                    )}
                    <p className="whitespace-pre-wrap leading-relaxed break-words overflow-wrap-anywhere">{msg.body}</p>
                    <p className="text-[10px] mt-1.5 opacity-60 text-right">{fmtAdminDate(msg.created_at)}</p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Reply */}
            {selected.status !== 'closed' ? (
              <div className="p-3 border-t border-slate-200 dark:border-slate-700 shrink-0">
                <div className="flex gap-2 items-end">
                  <textarea
                    value={replyBody}
                    onChange={e => setReplyBody(e.target.value)}
                    placeholder="Cevabınızı yazın..."
                    rows={2}
                    className="flex-1 resize-none rounded-xl border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-700 text-slate-800 dark:text-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400"
                    onKeyDown={e => { if (e.key === 'Enter' && e.ctrlKey) handleReply(); }}
                  />
                  <button onClick={handleReply} disabled={sending || !replyBody.trim()}
                    className="p-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white rounded-xl transition-colors shrink-0">
                    <Send size={16} />
                  </button>
                </div>
                <p className="text-[10px] text-slate-400 mt-1 ml-1">Ctrl+Enter ile gönder</p>
              </div>
            ) : (
              <div className="p-3 border-t border-slate-200 dark:border-slate-700 text-center text-sm text-slate-400">
                Talep kapalı — "Açık" yaparak tekrar aktif edebilirsiniz.
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

// ============================================================================
// WarrantiesView — Süperadmin için tüm bayilerin garanti belgelerini listele
// + her belgenin kim tarafından kaç kere açıldığı (view_count, last_viewed_at).
// ============================================================================

type WarrantyRow = {
  id: number;
  user_id: number;
  bayi_email: string;
  bayi_name: string;
  bayi_company: string | null;
  product_name: string;
  product_image_url: string | null;
  customer_name: string;
  customer_phone: string | null;
  duration_label: string;
  duration_days: number;
  start_date: string;
  end_date: string;
  is_expired: boolean;
  days_remaining: number;
  public_token: string;
  view_count: number;
  last_viewed_at: string | null;
  created_at: string;
};

type WarrantyStats = {
  total_warranties: number;
  total_views: number;
  expired_count: number;
  active_count: number;
  never_viewed_count: number;
  bayi_count: number;
};

const fmtDate = (s: string | null): string => {
  if (!s) return '—';
  try {
    const d = new Date(s);
    return d.toLocaleString('tr-TR', { dateStyle: 'short', timeStyle: 'short' });
  } catch { return s; }
};

const fmtDateOnly = (s: string | null): string => {
  if (!s) return '—';
  try { return new Date(s).toLocaleDateString('tr-TR'); } catch { return s; }
};

const WarrantiesView: React.FC<{
  showToast: (m: string, t?: any) => void;
  onSelectUser: (uid: number) => void;
}> = ({ showToast, onSelectUser }) => {
  const [items, setItems] = useState<WarrantyRow[]>([]);
  const [stats, setStats] = useState<WarrantyStats | null>(null);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [perPage] = useState(50);
  const [q, setQ] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [statusFilter, setStatusFilter] = useState<'' | 'active' | 'expired' | 'unviewed'>('');
  const [sort, setSort] = useState<'created_desc' | 'views_desc' | 'last_viewed_desc' | 'end_date_asc'>('created_desc');
  const [loading, setLoading] = useState(false);

  // Search debounce
  useEffect(() => {
    const t = setTimeout(() => { setPage(1); setQ(searchInput.trim()); }, 350);
    return () => clearTimeout(t);
  }, [searchInput]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params: any = { page, per_page: perPage, sort };
      if (q) params.q = q;
      if (statusFilter) params.status_filter = statusFilter;
      const r = await api.get('/superadmin/warranties', { params });
      setItems(r.data.items || []);
      setTotal(r.data.total || 0);
      setStats(r.data.stats || null);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Garantiler yüklenemedi', 'error');
    } finally { setLoading(false); }
  }, [page, perPage, sort, q, statusFilter, showToast]);

  useEffect(() => { load(); }, [load]);

  const totalPages = Math.max(1, Math.ceil(total / perPage));

  const copyPublicLink = async (token: string) => {
    const url = `${window.location.origin}/garanti/${token}`;
    try {
      await navigator.clipboard.writeText(url);
      showToast('Link kopyalandı', 'success');
    } catch {
      showToast(url, 'info');
    }
  };

  return (
    <div className="space-y-4">
      {/* Stats grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        <StatCard icon={ShieldCheck} label="Toplam Garanti" value={stats?.total_warranties ?? '—'} tone="indigo" />
        <StatCard icon={Eye} label="Toplam Görüntülenme" value={stats?.total_views ?? '—'} tone="emerald" />
        <StatCard icon={CheckCircle2} label="Aktif" value={stats?.active_count ?? '—'} tone="emerald" />
        <StatCard icon={ShieldAlert} label="Süresi Dolmuş" value={stats?.expired_count ?? '—'} tone="red" />
        <StatCard icon={EyeOff} label="Hiç Açılmamış" value={stats?.never_viewed_count ?? '—'} tone="amber" />
        <StatCard icon={Building2} label="Garanti Veren Bayi" value={stats?.bayi_count ?? '—'} tone="purple" />
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex flex-wrap gap-3 items-center">
          <div className="relative flex-1 min-w-[240px]">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Müşteri, ürün veya bayi ara..."
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="w-full pl-10 pr-3 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-medium"
            />
          </div>
          <select value={statusFilter} onChange={(e) => { setPage(1); setStatusFilter(e.target.value as any); }}
            className="px-3 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-bold text-slate-700 dark:text-slate-200 cursor-pointer">
            <option value="">Tüm Durumlar</option>
            <option value="active">Aktif (süresi dolmamış)</option>
            <option value="expired">Süresi Dolmuş</option>
            <option value="unviewed">Hiç Açılmamış</option>
          </select>
          <select value={sort} onChange={(e) => setSort(e.target.value as any)}
            className="px-3 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl text-sm font-bold text-slate-700 dark:text-slate-200 cursor-pointer">
            <option value="created_desc">En Yeni Önce</option>
            <option value="views_desc">En Çok Görüntülenen</option>
            <option value="last_viewed_desc">Son Açılan Önce</option>
            <option value="end_date_asc">Bitişi Yakın Olan</option>
          </select>
          <button onClick={load} className="flex items-center gap-2 px-3 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl text-sm font-bold text-slate-700 dark:text-slate-200 transition">
            <RefreshCw size={14} /> Yenile
          </button>
          <button
            onClick={() => exportGarantiler(items.map((w: any) => ({
              customer_name: w.customer_name, product_name: w.product_name,
              serial_number: w.serial_number, warranty_start: w.start_date,
              warranty_end: w.end_date, status: w.is_expired ? 'Süresi Dolmuş' : 'Aktif',
              notes: w.notes, created_at: w.created_at,
            })))}
            disabled={items.length === 0}
            className="flex items-center gap-1.5 px-3 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded-xl transition text-sm"
          >
            <Download size={14} /> Excel
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800">
              <tr className="text-left text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400 tracking-wider">
                <th className="px-4 py-3">Bayi</th>
                <th className="px-4 py-3">Ürün / Müşteri</th>
                <th className="px-4 py-3">Süre</th>
                <th className="px-4 py-3">Durum</th>
                <th className="px-4 py-3 text-right">Görüntülenme</th>
                <th className="px-4 py-3">Son Açılma</th>
                <th className="px-4 py-3">Oluşturma</th>
                <th className="px-4 py-3 text-right">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {loading && (
                <tr><td colSpan={8} className="px-4 py-10 text-center text-slate-400 font-medium">Yükleniyor...</td></tr>
              )}
              {!loading && items.length === 0 && (
                <tr><td colSpan={8} className="px-4 py-10 text-center text-slate-400 font-medium">Henüz garanti belgesi yok.</td></tr>
              )}
              {!loading && items.map(w => (
                <tr key={w.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                  <td className="px-4 py-3">
                    <button
                      onClick={() => onSelectUser(w.user_id)}
                      className="text-left hover:text-indigo-600 dark:hover:text-indigo-400 transition"
                      title="Bayi detayını aç"
                    >
                      <div className="font-bold text-slate-800 dark:text-slate-100">
                        {w.bayi_company || w.bayi_name}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">{w.bayi_email}</div>
                    </button>
                  </td>
                  <td className="px-4 py-3">
                    <div className="font-semibold text-slate-800 dark:text-slate-100">{w.product_name}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">{w.customer_name}</div>
                  </td>
                  <td className="px-4 py-3 text-xs">
                    <div className="font-bold text-slate-700 dark:text-slate-200">{w.duration_label}</div>
                    <div className="text-slate-500 dark:text-slate-400">Bitiş: {fmtDateOnly(w.end_date)}</div>
                  </td>
                  <td className="px-4 py-3">
                    {w.is_expired ? (
                      <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-red-100 dark:bg-red-500/20 text-red-700 dark:text-red-300 text-[11px] font-bold">
                        <ShieldAlert size={11} /> Süresi Dolmuş
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-emerald-100 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 text-[11px] font-bold">
                        <CheckCircle2 size={11} /> {w.days_remaining} gün
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold ${
                      w.view_count > 0
                        ? 'bg-indigo-100 dark:bg-indigo-500/20 text-indigo-700 dark:text-indigo-300'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                    }`}>
                      <Eye size={12} /> {w.view_count}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-600 dark:text-slate-300">
                    {w.last_viewed_at ? fmtDate(w.last_viewed_at) : <span className="text-slate-400">—</span>}
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-500 dark:text-slate-400">{fmtDateOnly(w.created_at)}</td>
                  <td className="px-4 py-3 text-right">
                    <div className="inline-flex items-center gap-1">
                      <button
                        onClick={() => copyPublicLink(w.public_token)}
                        className="inline-flex items-center gap-1 px-2 py-1.5 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-[11px] font-bold transition"
                        title="Public linki kopyala"
                      >
                        <Copy size={11} />
                      </button>
                      <a
                        href={`${window.location.origin}/garanti/${w.public_token}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 px-2 py-1.5 rounded-md bg-indigo-100 dark:bg-indigo-500/20 hover:bg-indigo-200 dark:hover:bg-indigo-500/30 text-indigo-700 dark:text-indigo-300 text-[11px] font-bold transition"
                        title="Public sayfayı aç"
                      >
                        <ExternalLink size={11} />
                      </a>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            {total > 0 ? `${(page - 1) * perPage + 1}–${Math.min(page * perPage, total)} / ${total}` : '0 sonuç'}
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page <= 1 || loading}
              className="px-2 py-1.5 rounded-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 dark:hover:bg-slate-800 transition"
            >
              <ChevronLeft size={14} />
            </button>
            <span className="px-3 py-1.5 text-xs font-bold text-slate-600 dark:text-slate-300">
              {page} / {totalPages}
            </span>
            <button
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages || loading}
              className="px-2 py-1.5 rounded-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 dark:hover:bg-slate-800 transition"
            >
              <ChevronRight size={14} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// ── Site Info (Hakkımızda) ─────────────────────────────────────────────────────
const SiteInfoView: React.FC<{ showToast: (msg: string, type?: any) => void }> = ({ showToast }) => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    company_name: '',
    contact_person: '',
    address: '',
    phone: '',
    email: '',
    working_hours: '',
    about_text: '',
    instagram_url: '',
    whatsapp_number: '',
  });

  const reload = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api.get('/superadmin/site-info');
      setForm({
        company_name: r.data.company_name || '',
        contact_person: r.data.contact_person || '',
        address: r.data.address || '',
        phone: r.data.phone || '',
        email: r.data.email || '',
        working_hours: r.data.working_hours || '',
        about_text: r.data.about_text || '',
        instagram_url: r.data.instagram_url || '',
        whatsapp_number: r.data.whatsapp_number || '',
      });
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Bilgiler yüklenemedi', 'error');
    } finally { setLoading(false); }
  }, [showToast]);

  useEffect(() => { reload(); }, [reload]);

  const setF = (key: string, val: string) => setForm(prev => ({ ...prev, [key]: val }));

  const save = async () => {
    setSaving(true);
    try {
      await api.patch('/superadmin/site-info', form);
      showToast('Site bilgileri kaydedildi', 'success');
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Kaydedilemedi', 'error');
    } finally { setSaving(false); }
  };

  if (loading) return <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl text-center text-slate-500">Yükleniyor…</div>;

  const inputCls = "w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500";
  const labelCls = "block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1";

  return (
    <div className="max-w-2xl space-y-4">
      <div className="bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800/50 p-4 rounded-2xl text-sm text-indigo-800 dark:text-indigo-300">
        Bu bilgiler ana sayfanın <b>Hakkımızda</b> bölümünde ve iletişim alanında görünür. Tüm alanlar isteğe bağlıdır.
      </div>
      <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        <h3 className="font-black text-slate-800 dark:text-white text-lg flex items-center gap-2">
          <Building2 size={20} className="text-indigo-500" /> Şirket & İletişim Bilgileri
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className={labelCls}>Şirket / Marka Adı</label>
            <input value={form.company_name} onChange={e => setF('company_name', e.target.value)} placeholder="StokFinans A.Ş." className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>İsim Soyisim (Yetkili)</label>
            <input value={form.contact_person} onChange={e => setF('contact_person', e.target.value)} placeholder="Ahmet Yılmaz" className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>Telefon</label>
            <input value={form.phone} onChange={e => setF('phone', e.target.value)} placeholder="+90 (555) 123 45 67" className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>E-posta</label>
            <input value={form.email} onChange={e => setF('email', e.target.value)} placeholder="info@stokfinans.com" className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>WhatsApp Numarası</label>
            <input value={form.whatsapp_number} onChange={e => setF('whatsapp_number', e.target.value)} placeholder="905551234567" className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>Çalışma Saatleri</label>
            <input value={form.working_hours} onChange={e => setF('working_hours', e.target.value)} placeholder="Hft içi 09:00–18:00" className={inputCls} />
          </div>
        </div>
        <div>
          <label className={labelCls}>Açık Adres</label>
          <textarea value={form.address} onChange={e => setF('address', e.target.value)} rows={2} placeholder="Örnek Mah. Örnek Sok. No:1, İstanbul" className={inputCls + ' resize-none'} />
        </div>
        <div>
          <label className={labelCls}>Instagram URL</label>
          <input value={form.instagram_url} onChange={e => setF('instagram_url', e.target.value)} placeholder="https://www.instagram.com/stokfinans" className={inputCls} />
        </div>
        <div>
          <label className={labelCls}>Hakkımızda Metni</label>
          <textarea value={form.about_text} onChange={e => setF('about_text', e.target.value)} rows={4} placeholder="Şirketiniz hakkında kısa bir tanıtım metni…" className={inputCls + ' resize-none'} />
        </div>
        <button onClick={save} disabled={saving}
          className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl transition disabled:opacity-50 disabled:cursor-not-allowed">
          <Save size={16} /> {saving ? 'Kaydediliyor…' : 'Kaydet'}
        </button>
      </div>
    </div>
  );
};

// ============================================================
// DevicesAdminView — Süper admin cihaz yönetimi
// ============================================================
type AdminDevice = {
  id: number;
  device_id: string;
  device_type: string;
  api_key?: string;
  user_id: number | null;
  user_email: string | null;
  user_name: string | null;
  is_paired: boolean;
  is_active: boolean;
  is_online: boolean;
  paired_at: string | null;
  firmware_version: string | null;
  ip_address: string | null;
  mac_address: string | null;
  wifi_ssid: string | null;
  wifi_rssi: number | null;
  free_heap: number | null;
  uptime_seconds: number | null;
  last_seen: string | null;
  pending_firmware_version: string | null;
  created_at: string;
  notes: string | null;
};

type FirmwareFile = {
  filename: string;
  device_type: string;
  variant: string;
  version: string;
  size_kb: number;
};

const VARIANT_OPTIONS = [
  { value: 'standart', label: 'Standart' },
  { value: 'ekran',    label: 'Ekranlı' },
  { value: 'barkod',   label: 'Barkod Okuyucu' },
  { value: 'ozel',     label: 'Özel' },
];

const variantLabel = (v: string) => VARIANT_OPTIONS.find(o => o.value === v)?.label ?? v;

const variantColor = (v: string) => {
  switch (v) {
    case 'ekran':  return 'bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300';
    case 'barkod': return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300';
    case 'ozel':   return 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300';
    default:       return 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300';
  }
};

const DevicesAdminView: React.FC<{ showToast: (msg: string, type?: 'success' | 'error' | 'warning') => void }> = ({ showToast }) => {
  const [devices, setDevices] = useState<AdminDevice[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [firmwareFiles, setFirmwareFiles] = useState<FirmwareFile[]>([]);
  const [pendingOta, setPendingOta] = useState<any[]>([]);
  const [loadingPending, setLoadingPending] = useState(false);
  // OTA push state
  const [otaFirmware, setOtaFirmware] = useState('');
  const [otaVersion, setOtaVersion] = useState('');
  const [otaTarget, setOtaTarget] = useState('all');
  const [pushing, setPushing] = useState(false);
  // Upload state
  const [uploadDeviceType, setUploadDeviceType] = useState('ESP8266');
  const [uploadVariant, setUploadVariant] = useState('standart');
  const [uploadVersion, setUploadVersion] = useState('');
  const [uploading, setUploading] = useState(false);
  const [showApiKey, setShowApiKey] = useState<Record<number, boolean>>({});
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const fetchDevices = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api.get('/devices/admin/all');
      setDevices(Array.isArray(r.data) ? r.data : []);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Cihazlar yüklenemedi', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  const fetchFirmware = useCallback(async () => {
    try {
      const r = await api.get('/devices/admin/firmware/list');
      setFirmwareFiles(Array.isArray(r.data) ? r.data : []);
    } catch {}
  }, []);

  const fetchPendingOta = useCallback(async () => {
    setLoadingPending(true);
    try {
      const r = await api.get('/devices/admin/ota/pending');
      setPendingOta(Array.isArray(r.data) ? r.data : []);
    } catch {} finally {
      setLoadingPending(false);
    }
  }, []);

  useEffect(() => { fetchDevices(); fetchFirmware(); fetchPendingOta(); }, [fetchDevices, fetchFirmware, fetchPendingOta]);

  const uploadFirmware = async (file: File) => {
    if (!uploadVersion.trim()) { showToast('Versiyon numarası girin (ör: 1.2.0)', 'warning'); return; }
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      await api.post(
        `/devices/admin/firmware/upload?device_type=${uploadDeviceType}&variant=${uploadVariant}&version=${encodeURIComponent(uploadVersion.trim())}`,
        fd
      );
      showToast(`${uploadDeviceType} (${variantLabel(uploadVariant)}) firmware yüklendi`, 'success');
      setUploadVersion('');
      fetchFirmware();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Yükleme başarısız', 'error');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const pushOta = async () => {
    if (!otaFirmware) { showToast('Firmware dosyası seçin', 'warning'); return; }
    if (!otaVersion.trim()) { showToast('Versiyon girin', 'warning'); return; }
    setPushing(true);
    try {
      const selectedFile = firmwareFiles.find(f => f.filename === otaFirmware);
      await api.post('/devices/admin/ota/push', {
        firmware_filename: otaFirmware,
        firmware_version: otaVersion.trim(),
        device_type: selectedFile?.device_type || undefined,
        variant: selectedFile?.variant || undefined,
        device_ids: otaTarget !== 'all' ? [otaTarget] : undefined,
      });
      showToast('OTA güncellemesi gönderildi', 'success');
      setOtaFirmware('');
      setOtaVersion('');
      fetchDevices();
      fetchPendingOta();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'OTA gönderilemedi', 'error');
    } finally {
      setPushing(false);
    }
  };

  const deleteFirmware = async (filename: string) => {
    if (!confirm(`"${filename}" dosyasını kalıcı olarak silmek istiyor musunuz?`)) return;
    try {
      await api.delete(`/devices/admin/firmware/file/${encodeURIComponent(filename)}`);
      showToast(`${filename} silindi`, 'success');
      fetchFirmware();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Silme başarısız', 'error');
    }
  };

  const cancelOta = async (deviceId: string) => {
    try {
      await api.post('/devices/admin/ota/cancel', { device_ids: [deviceId] });
      showToast('OTA güncellemesi iptal edildi', 'success');
      fetchPendingOta();
      fetchDevices();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'İptal başarısız', 'error');
    }
  };

  const deactivateDevice = async (deviceId: string) => {
    if (!confirm('Bu cihazı devre dışı bırakmak istiyor musunuz? Bayi bağlantısı da kaldırılacak.')) return;
    try {
      await api.delete(`/devices/admin/${deviceId}`);
      showToast('Cihaz devre dışı bırakıldı', 'success');
      fetchDevices();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'İşlem başarısız', 'error');
    }
  };

  const activateDevice = async (deviceId: string) => {
    try {
      await api.post(`/devices/admin/${deviceId}/activate`);
      showToast('Cihaz etkinleştirildi', 'success');
      fetchDevices();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'İşlem başarısız', 'error');
    }
  };

  const deleteDevicePermanent = async (deviceId: string) => {
    if (!confirm(`"${deviceId}" cihazını kalıcı olarak silmek istiyor musunuz? Bu işlem geri alınamaz.`)) return;
    try {
      await api.delete(`/devices/admin/${deviceId}/permanent`);
      showToast('Cihaz kalıcı olarak silindi', 'success');
      fetchDevices();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Silme başarısız', 'error');
    }
  };

  const filtered = Array.isArray(devices) ? devices.filter(d => {
    if (!search) return true;
    const s = search.toLowerCase();
    return d.device_id.toLowerCase().includes(s)
      || (d.user_email || '').toLowerCase().includes(s)
      || (d.user_name || '').toLowerCase().includes(s)
      || (d.ip_address || '').includes(s)
      || (d.mac_address || '').toLowerCase().includes(s);
  }) : [];

  const inp = 'w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500';

  const onlineCount = devices.filter(d => d.is_online).length;
  const pairedCount = devices.filter(d => d.is_paired).length;

  return (
    <div className="space-y-5">

      {/* Özet kartlar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: 'Toplam Cihaz', value: devices.length, tone: 'indigo' },
          { label: 'Çevrimiçi', value: onlineCount, tone: 'emerald' },
          { label: 'Eşleşmiş', value: pairedCount, tone: 'purple' },
          { label: 'Eşleşmemiş', value: devices.length - pairedCount, tone: 'amber' },
        ].map(c => (
          <div key={c.label} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-4 flex flex-col gap-1">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide">{c.label}</span>
            <span className="text-3xl font-black text-slate-800 dark:text-white">{c.value}</span>
          </div>
        ))}
      </div>

      {/* Firmware Yükleme */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-5">
        <h2 className="text-sm font-bold text-slate-700 dark:text-slate-200 mb-4 flex items-center gap-2">
          <Upload size={15} className="text-indigo-500" /> Firmware Yükle (.bin)
        </h2>
        <div className="flex flex-wrap gap-3 items-end">
          <div>
            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Cihaz Türü</label>
            <select value={uploadDeviceType} onChange={e => setUploadDeviceType(e.target.value)}
              className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
              <option value="ESP8266">ESP8266</option>
              <option value="ESP32">ESP32</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Varyant</label>
            <input
              list="variant-suggestions"
              value={uploadVariant}
              onChange={e => setUploadVariant(e.target.value.toLowerCase().replace(/\s+/g, '_'))}
              placeholder="ör: ekran, barkod, ozel…"
              className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 w-44"
            />
            <datalist id="variant-suggestions">
              {VARIANT_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </datalist>
          </div>
          <div className="flex-1 min-w-28">
            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Versiyon</label>
            <input value={uploadVersion} onChange={e => setUploadVersion(e.target.value)}
              placeholder="ör: 1.2.0" className={inp} />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1 opacity-0">_</label>
            <button onClick={() => fileInputRef.current?.click()} disabled={uploading}
              className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-sm transition disabled:opacity-50">
              <Upload size={14} /> {uploading ? 'Yükleniyor…' : '.bin Seç & Yükle'}
            </button>
            <input ref={fileInputRef} type="file" accept=".bin" className="hidden"
              onChange={e => { if (e.target.files?.[0]) uploadFirmware(e.target.files[0]); }} />
          </div>
        </div>
        {firmwareFiles.length > 0 && (
          <div className="mt-4">
            <div className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-2">Sunucudaki Dosyalar</div>
            <div className="flex flex-wrap gap-2">
              {firmwareFiles.map(f => {
                const installedCount = devices.filter(d =>
                  d.firmware_version === f.version &&
                  d.device_type === f.device_type &&
                  ((d as any).variant || 'standart') === f.variant
                ).length;
                return (
                  <div key={f.filename} className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold border ${f.device_type === 'ESP8266' ? 'bg-indigo-50 border-indigo-200 text-indigo-700 dark:bg-indigo-900/30 dark:border-indigo-800 dark:text-indigo-300' : 'bg-purple-50 border-purple-200 text-purple-700 dark:bg-purple-900/30 dark:border-purple-800 dark:text-purple-300'}`}>
                    <HardDrive size={11} />
                    <span>{f.device_type}</span>
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${variantColor(f.variant)}`}>{variantLabel(f.variant)}</span>
                    <span>v{f.version}</span>
                    <span className="opacity-50">{f.size_kb} KB</span>
                    {installedCount > 0 && (
                      <span className="px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300 text-[10px]">
                        {installedCount} cihaz
                      </span>
                    )}
                    <button
                      onClick={() => deleteFirmware(f.filename)}
                      title="Dosyayı sil"
                      className="ml-0.5 p-0.5 rounded hover:bg-red-100 dark:hover:bg-red-900/40 text-red-400 hover:text-red-600 transition"
                    >
                      <Trash2 size={11} />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* OTA Güncelleme Gönder */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-5">
        <h2 className="text-sm font-bold text-slate-700 dark:text-slate-200 mb-4 flex items-center gap-2">
          <ArrowUpToLine size={15} className="text-emerald-500" /> OTA Güncelleme Gönder
        </h2>
        <div className="flex flex-wrap gap-3 items-end">
          <div className="flex-1 min-w-40">
            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Firmware Dosyası</label>
            <select value={otaFirmware} onChange={e => {
              setOtaFirmware(e.target.value);
              const f = firmwareFiles.find(f => f.filename === e.target.value);
              if (f) setOtaVersion(f.version);
            }} className={inp}>
              <option value="">— seçin —</option>
              {firmwareFiles.map(f => (
                <option key={f.filename} value={f.filename}>
                  {f.device_type} · {variantLabel(f.variant)} · v{f.version} ({f.size_kb} KB)
                </option>
              ))}
            </select>
          </div>
          <div className="w-32">
            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Versiyon</label>
            <input value={otaVersion} onChange={e => setOtaVersion(e.target.value)} placeholder="1.2.0" className={inp} />
          </div>
          <div className="flex-1 min-w-40">
            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1">Hedef</label>
            <select value={otaTarget} onChange={e => setOtaTarget(e.target.value)} className={inp}>
              <option value="all">Firmware ile eşleşen tüm cihazlar</option>
              {devices.filter(d => d.is_active && d.is_paired).map(d => (
                <option key={d.device_id} value={d.device_id}>
                  {d.device_id} · {d.device_type} · {variantLabel((d as any).variant || 'standart')}
                </option>
              ))}
            </select>
          </div>
          <div>
            <button onClick={pushOta} disabled={pushing}
              className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-sm transition disabled:opacity-50">
              <ArrowUpToLine size={14} /> {pushing ? 'Gönderiliyor…' : 'Gönder'}
            </button>
          </div>
        </div>
      </div>

      {/* Aktif OTA Güncellemeleri */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ArrowUpToLine size={15} className="text-amber-500" />
            <h2 className="text-sm font-bold text-slate-700 dark:text-slate-200">Aktif OTA Güncellemeleri</h2>
            {pendingOta.length > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300 text-[11px] font-bold">{pendingOta.length} cihaz bekliyor</span>
            )}
            {pendingOta.some(p => p.is_problem) && (
              <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300 text-[11px] font-bold flex items-center gap-1">
                <AlertCircle size={10} /> {pendingOta.filter(p => p.is_problem).length} sorunlu
              </span>
            )}
          </div>
          <button onClick={fetchPendingOta} disabled={loadingPending}
            className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition">
            <RefreshCw size={13} className={loadingPending ? 'animate-spin text-indigo-500' : 'text-slate-500'} />
          </button>
        </div>

        {pendingOta.length === 0 ? (
          <div className="px-5 py-8 text-center text-slate-400 text-sm">
            {loadingPending ? 'Yükleniyor…' : 'Bekleyen OTA güncellemesi yok'}
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {pendingOta.map(p => (
              <div key={p.device_id} className={`px-5 py-3 flex items-center gap-4 ${p.is_problem ? 'bg-red-50 dark:bg-red-950/20' : ''}`}>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-xs font-bold text-slate-700 dark:text-slate-200">{p.device_id}</span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${p.device_type === 'ESP8266' ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300' : 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300'}`}>{p.device_type}</span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${variantColor(p.variant)}`}>{variantLabel(p.variant)}</span>
                    <span className={`inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full font-bold ${p.is_online ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300' : 'bg-slate-100 text-slate-500 dark:bg-slate-800'}`}>
                      {p.is_online ? <><Wifi size={8} /> Çevrimiçi</> : <><WifiOff size={8} /> Çevrimdışı</>}
                    </span>
                    {p.is_problem && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300">
                        <AlertCircle size={9} /> SORUN — {p.attempt_count}x indirildi, güncellenmedi
                      </span>
                    )}
                    {!p.is_problem && p.attempt_count > 0 && (
                      <span className="text-[10px] text-amber-600 dark:text-amber-400 font-bold">{p.attempt_count}x indirildi</span>
                    )}
                  </div>
                  <div className="mt-1 flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                    <span className="font-mono">{p.current_version}</span>
                    <span>→</span>
                    <span className="font-mono font-bold text-amber-600 dark:text-amber-400">{p.pending_version}</span>
                    {p.pending_filename && <span className="opacity-60">({p.pending_filename})</span>}
                    {p.user_name && <span>· {p.user_name}</span>}
                  </div>
                </div>
                <button
                  onClick={() => cancelOta(p.device_id)}
                  className="shrink-0 inline-flex items-center gap-1 px-3 py-1.5 bg-red-100 hover:bg-red-200 dark:bg-red-900/40 dark:hover:bg-red-900/60 text-red-700 dark:text-red-300 font-bold rounded-lg text-xs transition"
                >
                  <XCircle size={12} /> İptal
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Cihaz Listesi */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-slate-800">
          <h2 className="text-sm font-bold text-slate-700 dark:text-slate-200 flex items-center gap-2">
            <Wifi size={15} className="text-indigo-500" /> Tüm Cihazlar
          </h2>
          <div className="flex items-center gap-2">
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="ID, bayi, IP ara…"
              className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 w-48" />
            <button onClick={() => { fetchDevices(); fetchFirmware(); fetchPendingOta(); }} disabled={loading}
              className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition">
              <RefreshCw size={14} className={loading ? 'animate-spin text-indigo-500' : 'text-slate-500'} />
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-800 text-[11px] uppercase text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-900/60">
                <th className="px-4 py-2.5 text-left font-bold">Durum</th>
                <th className="px-4 py-2.5 text-left font-bold">Cihaz ID</th>
                <th className="px-4 py-2.5 text-left font-bold">Tür / Varyant</th>
                <th className="px-4 py-2.5 text-left font-bold">Bayi</th>
                <th className="px-4 py-2.5 text-left font-bold">IP / WiFi</th>
                <th className="px-4 py-2.5 text-left font-bold">Firmware</th>
                <th className="px-4 py-2.5 text-left font-bold">Son Görülme</th>
                <th className="px-4 py-2.5 text-left font-bold">API Key</th>
                <th className="px-4 py-2.5 text-right font-bold">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {loading && (
                <tr><td colSpan={9} className="text-center py-10 text-slate-400 text-sm">Yükleniyor…</td></tr>
              )}
              {!loading && filtered.length === 0 && (
                <tr><td colSpan={9} className="text-center py-10 text-slate-400 text-sm">Kayıtlı cihaz yok</td></tr>
              )}
              {filtered.map(d => (
                <tr key={d.id} className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 transition ${!d.is_active ? 'opacity-40' : ''}`}>
                  <td className="px-4 py-3">
                    <div className="flex flex-col gap-1">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${d.is_online ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300' : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'}`}>
                        {d.is_online ? <><Wifi size={9} /> Çevrimiçi</> : <><WifiOff size={9} /> Çevrimdışı</>}
                      </span>
                      {d.is_paired
                        ? <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300"><PlugZap size={9} /> Eşleşti</span>
                        : <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300"><AlertCircle size={9} /> Bekliyor</span>
                      }
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="font-mono text-xs font-bold text-slate-700 dark:text-slate-200 whitespace-nowrap">{d.device_id}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col gap-1">
                      <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md w-fit ${d.device_type === 'ESP8266' ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300' : 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300'}`}>
                        {d.device_type}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md w-fit ${variantColor((d as any).variant || 'standart')}`}>
                        {variantLabel((d as any).variant || 'standart')}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    {d.user_email ? (
                      <div>
                        <div className="text-xs font-bold text-slate-700 dark:text-slate-200 whitespace-nowrap">{d.user_name || '—'}</div>
                        <div className="text-[11px] text-slate-400 whitespace-nowrap">{d.user_email}</div>
                      </div>
                    ) : <span className="text-xs text-slate-400">Eşleşmemiş</span>}
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-xs text-slate-600 dark:text-slate-300 whitespace-nowrap">{d.ip_address || '—'}</div>
                    <div className="text-[11px] text-slate-400 whitespace-nowrap">{d.wifi_ssid ? `${d.wifi_ssid} (${d.wifi_rssi ?? '?'} dBm)` : '—'}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-xs font-mono text-slate-600 dark:text-slate-300 whitespace-nowrap">{d.firmware_version || '—'}</div>
                    {d.pending_firmware_version && (
                      <div className="text-[11px] text-amber-600 dark:text-amber-400 font-bold whitespace-nowrap">↑ {d.pending_firmware_version}</div>
                    )}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <span className="text-xs text-slate-500 dark:text-slate-400">{formatDateTime(d.last_seen)}</span>
                  </td>
                  <td className="px-4 py-3">
                    {d.api_key ? (
                      <div className="flex items-center gap-1">
                        <span className="font-mono text-[10px] text-slate-400 truncate max-w-[72px]">
                          {showApiKey[d.id] ? d.api_key.substring(0, 16) + '…' : '••••••••••••'}
                        </span>
                        <button onClick={() => setShowApiKey(prev => ({ ...prev, [d.id]: !prev[d.id] }))}
                          className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700">
                          {showApiKey[d.id] ? <EyeOff size={11} className="text-slate-400" /> : <Eye size={11} className="text-slate-400" />}
                        </button>
                        <button onClick={() => { navigator.clipboard.writeText(d.api_key!); showToast('API key kopyalandı', 'success'); }}
                          className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700">
                          <Copy size={11} className="text-slate-400" />
                        </button>
                      </div>
                    ) : <span className="text-xs text-slate-400">—</span>}
                  </td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    <div className="inline-flex items-center gap-1.5">
                      {d.is_active ? (
                        <button onClick={() => deactivateDevice(d.device_id)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 bg-red-100 text-red-700 hover:bg-red-200 dark:bg-red-900/40 dark:text-red-300 rounded-lg text-xs font-bold transition">
                          <WifiOff size={11} /> Devre Dışı
                        </button>
                      ) : (
                        <button onClick={() => activateDevice(d.device_id)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-100 text-emerald-700 hover:bg-emerald-200 dark:bg-emerald-900/40 dark:text-emerald-300 rounded-lg text-xs font-bold transition">
                          <Wifi size={11} /> Etkinleştir
                        </button>
                      )}
                      <button onClick={() => deleteDevicePermanent(d.device_id)}
                        title="Cihazı kalıcı sil"
                        className="inline-flex items-center gap-1 px-2 py-1 bg-slate-100 text-slate-500 hover:bg-red-100 hover:text-red-700 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-red-900/40 dark:hover:text-red-300 rounded-lg text-xs font-bold transition">
                        <Trash2 size={11} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// ============================================================
// GÜVENLİK RAPORU (SuperAdmin)
// ============================================================

interface SecurityLogEntry {
  id: number;
  ip_address: string;
  event_type: string;
  email_attempted?: string;
  user_id?: number;
  user_email?: string;
  user_name?: string;
  user_role?: string;
  path?: string;
  method?: string;
  user_agent?: string;
  details?: string;
  created_at: string;
}

interface IpBan {
  id: number;
  ip_address: string;
  reason?: string;
  banned_by?: string;
  created_at: string;
  expires_at?: string;
}

interface SecurityStats {
  total_failed_logins: number;
  total_rate_limited: number;
  total_banned_access: number;
  unique_attacker_ips: number;
  active_bans: number;
  top_attacker_ips: { ip: string; count: number }[];
}

const EVENT_LABELS: Record<string, { label: string; color: string }> = {
  failed_login:     { label: 'Başarısız Giriş', color: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400' },
  rate_limited:     { label: 'Hız Limiti',      color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400' },
  banned_access:    { label: 'Banlı Erişim',    color: 'bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-400' },
  suspicious_scan:  { label: 'Şüpheli Tarama',  color: 'bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-400' },
  invalid_token:    { label: 'Geçersiz Token',  color: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400' },
};

function fmtSecDate(iso: string) {
  return new Date(iso).toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

const SecurityView: React.FC<{ showToast: (msg: string, type?: any) => void }> = ({ showToast }) => {
  const [secTab, setSecTab] = useState<'logs' | 'bans'>('logs');
  const [logs, setLogs] = useState<SecurityLogEntry[]>([]);
  const [bans, setBans] = useState<IpBan[]>([]);
  const [stats, setStats] = useState<SecurityStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [filterIp, setFilterIp] = useState('');
  const [filterEmail, setFilterEmail] = useState('');
  const [filterEvent, setFilterEvent] = useState('');
  const [page, setPage] = useState(1);
  const [banIp, setBanIp] = useState('');
  const [banReason, setBanReason] = useState('');
  const [banning, setBanning] = useState(false);

  const loadStats = useCallback(async () => {
    try {
      const r = await api.get('/superadmin/security/stats');
      setStats(r.data);
    } catch {}
  }, []);

  const loadLogs = useCallback(async (p = 1) => {
    setLoading(true);
    try {
      const params: Record<string, any> = { page: p, page_size: 50 };
      if (filterIp) params.ip = filterIp;
      if (filterEmail) params.email = filterEmail;
      if (filterEvent) params.event_type = filterEvent;
      const r = await api.get('/superadmin/security/logs', { params });
      setLogs(r.data);
    } catch { showToast('Loglar yüklenemedi', 'error'); }
    finally { setLoading(false); }
  }, [filterIp, filterEmail, filterEvent, showToast]);

  const loadBans = useCallback(async () => {
    try {
      const r = await api.get('/superadmin/security/banned-ips');
      setBans(r.data);
    } catch {}
  }, []);

  useEffect(() => { loadStats(); loadLogs(1); loadBans(); }, []);

  const handleSearch = () => { setPage(1); loadLogs(1); };

  const handleBanFromLog = async (ip: string) => {
    try {
      await api.post('/superadmin/security/ban-ip', { ip_address: ip, reason: 'Süper admin tarafından logdan banlandı' });
      showToast(`${ip} banlandı`, 'success');
      loadBans(); loadStats();
    } catch (e: any) { showToast(e?.response?.data?.detail || 'Banlama başarısız', 'error'); }
  };

  const handleBanSubmit = async () => {
    if (!banIp.trim()) return;
    setBanning(true);
    try {
      await api.post('/superadmin/security/ban-ip', { ip_address: banIp.trim(), reason: banReason.trim() || undefined });
      showToast(`${banIp} banlandı`, 'success');
      setBanIp(''); setBanReason('');
      loadBans(); loadStats();
    } catch (e: any) { showToast(e?.response?.data?.detail || 'Banlama başarısız', 'error'); }
    finally { setBanning(false); }
  };

  const handleUnban = async (ban: IpBan) => {
    try {
      await api.delete(`/superadmin/security/ban-ip/${ban.id}`);
      showToast(`${ban.ip_address} banı kaldırıldı`, 'success');
      loadBans(); loadStats();
    } catch { showToast('Ban kaldırılamadı', 'error'); }
  };

  return (
    <div className="space-y-4">
      {/* İstatistik kartları */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {[
            { label: 'Başarısız Giriş', value: stats.total_failed_logins, color: 'text-red-600 dark:text-red-400' },
            { label: 'Hız Limiti',      value: stats.total_rate_limited,  color: 'text-amber-600 dark:text-amber-400' },
            { label: 'Banlı Erişim',   value: stats.total_banned_access,  color: 'text-purple-600 dark:text-purple-400' },
            { label: 'Farklı IP',      value: stats.unique_attacker_ips,  color: 'text-slate-600 dark:text-slate-400' },
            { label: 'Aktif Ban',      value: stats.active_bans,          color: 'text-indigo-600 dark:text-indigo-400' },
          ].map(s => (
            <div key={s.label} className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 text-center">
              <p className={`text-2xl font-extrabold ${s.color}`}>{s.value}</p>
              <p className="text-xs text-slate-500 mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      {/* En çok saldıran IP'ler */}
      {stats && stats.top_attacker_ips.length > 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4">
          <p className="text-sm font-bold text-slate-700 dark:text-slate-200 mb-3">En Çok Deneme Yapan IP'ler</p>
          <div className="flex flex-wrap gap-2">
            {stats.top_attacker_ips.map(t => (
              <div key={t.ip} className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 rounded-lg px-3 py-1.5 text-xs">
                <span className="font-mono text-slate-700 dark:text-slate-300">{t.ip}</span>
                <span className="text-red-600 font-bold">{t.count}</span>
                <button
                  onClick={() => handleBanFromLog(t.ip)}
                  className="text-xs px-2 py-0.5 rounded bg-red-100 hover:bg-red-200 text-red-700 dark:bg-red-900/40 dark:text-red-400 dark:hover:bg-red-900/60 font-semibold transition"
                >
                  Banla
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sekmeler */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
        <div className="flex border-b border-slate-200 dark:border-slate-800">
          {(['logs', 'bans'] as const).map(t => (
            <button key={t} onClick={() => setSecTab(t)}
              className={`px-5 py-3 text-sm font-semibold border-b-2 transition ${secTab === t ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}>
              {t === 'logs' ? 'Güvenlik Logları' : `Banlı IP'ler (${bans.length})`}
            </button>
          ))}
        </div>

        {secTab === 'logs' && (
          <div className="p-4 space-y-3">
            {/* Filtreler */}
            <div className="flex flex-wrap gap-2">
              <input value={filterIp} onChange={e => setFilterIp(e.target.value)}
                placeholder="IP filtrele..." onKeyDown={e => e.key === 'Enter' && handleSearch()}
                className="flex-1 min-w-[140px] text-sm px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100" />
              <input value={filterEmail} onChange={e => setFilterEmail(e.target.value)}
                placeholder="E-posta filtrele..." onKeyDown={e => e.key === 'Enter' && handleSearch()}
                className="flex-1 min-w-[160px] text-sm px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100" />
              <select value={filterEvent} onChange={e => setFilterEvent(e.target.value)}
                className="text-sm px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100">
                <option value="">Tüm olaylar</option>
                {Object.entries(EVENT_LABELS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
              <button onClick={handleSearch}
                className="px-4 py-2 rounded-lg bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700 transition">
                Ara
              </button>
            </div>

            {loading ? (
              <div className="py-10 text-center text-slate-400 text-sm">Yükleniyor...</div>
            ) : logs.length === 0 ? (
              <div className="py-10 text-center text-slate-400 text-sm">Kayıt bulunamadı</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-left text-slate-500 dark:text-slate-400 border-b border-slate-100 dark:border-slate-800">
                      <th className="py-2 pr-3 font-semibold">Tarih</th>
                      <th className="py-2 pr-3 font-semibold">IP</th>
                      <th className="py-2 pr-3 font-semibold">Olay</th>
                      <th className="py-2 pr-3 font-semibold">Denenen E-posta</th>
                      <th className="py-2 pr-3 font-semibold">Eşleşen Kullanıcı</th>
                      <th className="py-2 pr-3 font-semibold">Detay</th>
                      <th className="py-2 font-semibold">İşlem</th>
                    </tr>
                  </thead>
                  <tbody>
                    {logs.map(log => {
                      const ev = EVENT_LABELS[log.event_type] ?? { label: log.event_type, color: 'bg-slate-100 text-slate-600' };
                      return (
                        <tr key={log.id} className="border-b border-slate-50 dark:border-slate-800/60 hover:bg-slate-50 dark:hover:bg-slate-800/40">
                          <td className="py-2 pr-3 whitespace-nowrap text-slate-500">{fmtSecDate(log.created_at)}</td>
                          <td className="py-2 pr-3 font-mono text-slate-700 dark:text-slate-300">{log.ip_address}</td>
                          <td className="py-2 pr-3">
                            <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${ev.color}`}>{ev.label}</span>
                          </td>
                          <td className="py-2 pr-3 text-slate-600 dark:text-slate-400">{log.email_attempted || '—'}</td>
                          <td className="py-2 pr-3">
                            {log.user_email ? (
                              <div>
                                <p className="font-semibold text-slate-700 dark:text-slate-300">{log.user_name || log.user_email}</p>
                                <p className="text-slate-400">{log.user_email} · {log.user_role}</p>
                              </div>
                            ) : <span className="text-slate-400">—</span>}
                          </td>
                          <td className="py-2 pr-3 text-slate-500 max-w-[200px] truncate">{log.details || '—'}</td>
                          <td className="py-2">
                            <button onClick={() => handleBanFromLog(log.ip_address)}
                              className="px-2 py-1 rounded bg-red-100 hover:bg-red-200 text-red-700 dark:bg-red-900/40 dark:text-red-400 dark:hover:bg-red-900/60 text-xs font-semibold transition whitespace-nowrap">
                              Banla
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Sayfalama */}
            <div className="flex items-center gap-2 pt-1">
              <button disabled={page <= 1} onClick={() => { const p = page - 1; setPage(p); loadLogs(p); }}
                className="px-3 py-1.5 rounded-lg border text-xs disabled:opacity-40 hover:bg-slate-50 dark:hover:bg-slate-800 transition">
                ← Önceki
              </button>
              <span className="text-xs text-slate-500">Sayfa {page}</span>
              <button disabled={logs.length < 50} onClick={() => { const p = page + 1; setPage(p); loadLogs(p); }}
                className="px-3 py-1.5 rounded-lg border text-xs disabled:opacity-40 hover:bg-slate-50 dark:hover:bg-slate-800 transition">
                Sonraki →
              </button>
            </div>
          </div>
        )}

        {secTab === 'bans' && (
          <div className="p-4 space-y-4">
            {/* Manuel ban ekleme */}
            <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4">
              <p className="text-sm font-bold text-slate-700 dark:text-slate-200 mb-3">IP Banla</p>
              <div className="flex flex-wrap gap-2">
                <input value={banIp} onChange={e => setBanIp(e.target.value)}
                  placeholder="IP adresi (ör: 192.168.1.1)"
                  className="flex-1 min-w-[160px] text-sm px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100" />
                <input value={banReason} onChange={e => setBanReason(e.target.value)}
                  placeholder="Sebep (isteğe bağlı)"
                  className="flex-1 min-w-[200px] text-sm px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100" />
                <button onClick={handleBanSubmit} disabled={banning || !banIp.trim()}
                  className="px-4 py-2 rounded-lg bg-red-600 text-white text-sm font-semibold hover:bg-red-700 disabled:opacity-50 transition">
                  {banning ? 'Banlanıyor...' : 'Banla'}
                </button>
              </div>
            </div>

            {bans.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-sm">Banlı IP yok</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-left text-slate-500 dark:text-slate-400 border-b border-slate-100 dark:border-slate-800">
                      <th className="py-2 pr-3 font-semibold">IP Adresi</th>
                      <th className="py-2 pr-3 font-semibold">Sebep</th>
                      <th className="py-2 pr-3 font-semibold">Banlayan</th>
                      <th className="py-2 pr-3 font-semibold">Banlandı</th>
                      <th className="py-2 pr-3 font-semibold">Bitiş</th>
                      <th className="py-2 font-semibold">İşlem</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bans.map(ban => (
                      <tr key={ban.id} className="border-b border-slate-50 dark:border-slate-800/60 hover:bg-slate-50 dark:hover:bg-slate-800/40">
                        <td className="py-2 pr-3 font-mono font-semibold text-red-600 dark:text-red-400">{ban.ip_address}</td>
                        <td className="py-2 pr-3 text-slate-600 dark:text-slate-400">{ban.reason || '—'}</td>
                        <td className="py-2 pr-3 text-slate-500">{ban.banned_by || '—'}</td>
                        <td className="py-2 pr-3 text-slate-500 whitespace-nowrap">{fmtSecDate(ban.created_at)}</td>
                        <td className="py-2 pr-3 text-slate-500">
                          {ban.expires_at ? fmtSecDate(ban.expires_at) : <span className="text-red-500 font-semibold">Kalıcı</span>}
                        </td>
                        <td className="py-2">
                          <button onClick={() => handleUnban(ban)}
                            className="px-2 py-1 rounded bg-emerald-100 hover:bg-emerald-200 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400 text-xs font-semibold transition">
                            Kaldır
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default SuperAdminPanel;

// ─── B2B Activity View ───────────────────────────────────────────────────────

const B2bActivityView: React.FC<{ showToast: (msg: string, type?: any) => void }> = ({ showToast }) => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'pending' | 'registrations'>('pending');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api.get('/superadmin/btb/activity');
      setData(r.data);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'B2B verisi yüklenemedi', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => { load(); }, [load]);

  const fmt = (n: number) => new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n);

  if (loading) return <div className="py-16 text-center text-slate-400">Yükleniyor...</div>;
  if (!data) return null;

  const stats = data.stats;

  return (
    <div className="space-y-5">
      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatCard icon={ShoppingCart} label="Onay Bekleyen" value={stats.total_pending} tone={stats.total_pending > 0 ? 'amber' : 'slate'} />
        <StatCard icon={UserCheck} label="Portal Hesabı" value={stats.total_portal_accounts} tone="indigo" />
        <StatCard icon={Briefcase} label="B2B Müşteri" value={stats.total_btb_customers} tone="emerald" />
        <StatCard icon={Receipt} label="Toplam Sipariş" value={stats.total_btb_orders} tone="purple" />
      </div>

      {/* Tabs */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="flex border-b border-slate-200 dark:border-slate-800 overflow-x-auto">
          {[
            { key: 'pending', label: `Onay Bekleyenler (${data.pending_orders.length})` },
            { key: 'registrations', label: `Portal Hesapları (${data.recent_registrations.length})` },
          ].map(t => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key as any)}
              className={`px-5 py-3.5 text-sm font-bold border-b-2 transition whitespace-nowrap ${activeTab === t.key ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
            >{t.label}</button>
          ))}
          <div className="ml-auto px-4 flex items-center">
            <button onClick={load} className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"><RefreshCw size={14} /></button>
          </div>
        </div>

        {activeTab === 'pending' && (
          <>
            {data.pending_orders.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-sm">Onay bekleyen portal siparişi yok</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm min-w-[560px]">
                  <thead className="bg-slate-50 dark:bg-slate-800/60">
                    <tr className="text-xs text-slate-500 uppercase tracking-wide">
                      <th className="text-left px-5 py-3">Sipariş</th>
                      <th className="text-left px-5 py-3">Müşteri</th>
                      <th className="text-left px-5 py-3">Bayi</th>
                      <th className="text-right px-5 py-3">Tutar</th>
                      <th className="text-left px-5 py-3">Tarih</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {data.pending_orders.map((o: any) => (
                      <tr key={o.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                        <td className="px-5 py-3">
                          <span className="font-mono text-xs bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400 px-2 py-0.5 rounded">{o.order_number}</span>
                        </td>
                        <td className="px-5 py-3 font-medium text-slate-800 dark:text-slate-200">{o.customer_name}</td>
                        <td className="px-5 py-3">
                          <p className="text-slate-700 dark:text-slate-300">{o.bayi_company || o.bayi_email}</p>
                          <p className="text-xs text-slate-400">{o.bayi_email}</p>
                        </td>
                        <td className="px-5 py-3 text-right font-bold text-slate-800 dark:text-slate-200">
                          {fmt(o.total_amount)} {o.currency === 'TRY' ? '₺' : o.currency}
                        </td>
                        <td className="px-5 py-3 text-slate-500 text-xs">{formatDateTime(o.created_at)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}

        {activeTab === 'registrations' && (
          <>
            {data.recent_registrations.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-sm">Portal hesabı yok</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm min-w-[560px]">
                  <thead className="bg-slate-50 dark:bg-slate-800/60">
                    <tr className="text-xs text-slate-500 uppercase tracking-wide">
                      <th className="text-left px-5 py-3">Portal Hesabı</th>
                      <th className="text-left px-5 py-3">Müşteri Firması</th>
                      <th className="text-left px-5 py-3">Bayi</th>
                      <th className="text-left px-5 py-3">Son Giriş</th>
                      <th className="text-left px-5 py-3">Durum</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {data.recent_registrations.map((r: any) => (
                      <tr key={r.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                        <td className="px-5 py-3">
                          <p className="font-medium text-slate-800 dark:text-slate-200">{r.email}</p>
                          {r.full_name && <p className="text-xs text-slate-400">{r.full_name}</p>}
                        </td>
                        <td className="px-5 py-3 text-slate-700 dark:text-slate-300">{r.customer_name}</td>
                        <td className="px-5 py-3">
                          <p className="text-slate-700 dark:text-slate-300">{r.bayi_company || r.bayi_email}</p>
                          <p className="text-xs text-slate-400">{r.bayi_email}</p>
                        </td>
                        <td className="px-5 py-3 text-xs text-slate-500">{r.last_login ? formatDateTime(r.last_login) : '—'}</td>
                        <td className="px-5 py-3">
                          {r.is_active
                            ? <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400"><CheckCircle size={11}/>Aktif</span>
                            : <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400"><XCircle size={11}/>Askıda</span>
                          }
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

// ============================================================
// API KEYS VIEW — Harici entegrasyon anahtarları yönetimi
// ============================================================
const SCOPES_DEF = [
  { key: 'products:read',      group: 'Ürünler',     label: 'Okuma' },
  { key: 'products:write',     group: 'Ürünler',     label: 'Yazma' },
  { key: 'transactions:read',  group: 'Satışlar',    label: 'Okuma' },
  { key: 'transactions:write', group: 'Satışlar',    label: 'Yazma' },
  { key: 'finance:read',       group: 'Finans',      label: 'Okuma' },
  { key: 'customers:read',     group: 'Müşteriler',  label: 'Okuma' },
  { key: 'customers:write',    group: 'Müşteriler',  label: 'Yazma' },
  { key: 'warranty:read',      group: 'Garanti',     label: 'Okuma' },
  { key: 'warranty:write',     group: 'Garanti',     label: 'Yazma' },
  { key: 'categories:read',    group: 'Kategoriler', label: 'Okuma' },
  { key: 'categories:write',   group: 'Kategoriler', label: 'Yazma' },
  { key: 'reports:read',       group: 'Raporlar',    label: 'Okuma' },
  { key: 'profile:read',       group: 'Profil',      label: 'Okuma' },
  { key: 'devices:read',       group: 'Cihazlar',    label: 'Okuma' },
  { key: 'devices:write',      group: 'Cihazlar',    label: 'Yazma' },
  { key: 'vehicles:read',      group: 'Araçlar',     label: 'Okuma' },
  { key: 'vehicles:write',     group: 'Araçlar',     label: 'Yazma' },
];

const SCOPE_GROUPS = Array.from(new Set(SCOPES_DEF.map(s => s.group)));

type ApiKeyItem = {
  id: number;
  key_prefix: string;
  name: string;
  description?: string;
  user_id: number;
  user_email: string;
  user_full_name: string;
  scopes: string[];
  is_full_access: boolean;
  is_active: boolean;
  usage_count: number;
  last_used_at?: string;
  created_at: string;
  expires_at?: string;
};

type CodeLang = 'curl' | 'python' | 'javascript' | 'csharp' | 'arduino' | 'admin_python';

function buildExampleCode(lang: CodeLang, key: string, baseUrl: string): string {
  const url = `${baseUrl}/api/v1/products`;
  if (lang === 'curl') return `# Ürün listesini getir
curl -X GET "${url}" \\
  -H "X-API-Key: ${key}" \\
  -H "Content-Type: application/json"

# Yeni ürün ekle
curl -X POST "${url}" \\
  -H "X-API-Key: ${key}" \\
  -H "Content-Type: application/json" \\
  -d '{"name":"Yeni Ürün","barcode":"BRK001","price":150.0,"quantity":50}'`;

  if (lang === 'python') return `import requests

API_KEY = "${key}"
BASE_URL = "${baseUrl}/api/v1"
HEADERS  = {"X-API-Key": API_KEY}

# Ürün listesi
resp = requests.get(f"{BASE_URL}/products", headers=HEADERS)
products = resp.json()
print(f"Toplam ürün: {products['total']}")

# Yeni ürün oluştur
new_product = {
    "name": "Yeni Ürün",
    "barcode": "BRK001",
    "price": 150.0,
    "quantity": 50,
    "min_stock_alert": 5,
}
r = requests.post(f"{BASE_URL}/products", json=new_product, headers=HEADERS)
print(r.json())`;

  if (lang === 'javascript') return `const API_KEY = "${key}";
const BASE_URL = "${baseUrl}/api/v1";

const headers = {
  "X-API-Key": API_KEY,
  "Content-Type": "application/json",
};

// Ürün listesi
const resp = await fetch(\`\${BASE_URL}/products\`, { headers });
const products = await resp.json();
console.log("Toplam ürün:", products.total);

// Axios ile (React / Node.js)
import axios from "axios";
const client = axios.create({ baseURL: BASE_URL, headers });

const { data } = await client.get("/products");
console.log(data.items);`;

  if (lang === 'csharp') return `using System.Net.Http.Json;

var client = new HttpClient { BaseAddress = new Uri("${baseUrl}/api/v1/") };
client.DefaultRequestHeaders.Add("X-API-Key", "${key}");

// Ürün listesi
var products = await client.GetFromJsonAsync<ProductList>("products");
Console.WriteLine($"Toplam ürün: {products?.Total}");

// Yeni ürün
var newProduct = new { name = "Yeni Ürün", barcode = "BRK001", price = 150.0, quantity = 50 };
var resp = await client.PostAsJsonAsync("products", newProduct);
Console.WriteLine(await resp.Content.ReadAsStringAsync());`;

  if (lang === 'arduino') return `// Arduino / ESP32 — ArduinoJson + HTTPClient
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

const char* API_KEY  = "${key}";
const char* BASE_URL = "${baseUrl}/api/v1";

void getProducts() {
  HTTPClient http;
  String url = String(BASE_URL) + "/products";
  http.begin(url);
  http.addHeader("X-API-Key", API_KEY);
  http.addHeader("Content-Type", "application/json");

  int code = http.GET();
  if (code == 200) {
    JsonDocument doc;
    deserializeJson(doc, http.getString());
    Serial.println(doc["total"].as<int>());
  }
  http.end();
}

// Stok güncelle (PUT)
void updateStock(int productId, int newQty) {
  HTTPClient http;
  String url = String(BASE_URL) + "/products/" + productId;
  http.begin(url);
  http.addHeader("X-API-Key", API_KEY);
  http.addHeader("Content-Type", "application/json");

  String body = "{\\"quantity\\":" + String(newQty) + "}";
  int code = http.PUT(body);
  Serial.println("HTTP: " + String(code));
  http.end();
}`;

  if (lang === 'admin_python') return `import requests

# Süper Admin Yönetim API Anahtarı
ADMIN_KEY = "${key}"
BASE_URL  = "${baseUrl}/api/v1/ext/admin"
HEADERS   = {"X-API-Key": ADMIN_KEY}

# Platform genel istatistikleri
overview = requests.get(f"{BASE_URL}/overview", headers=HEADERS).json()
print(f"Toplam kullanıcı : {overview['users']['total']}")
print(f"Bu ay ciro       : {overview['revenue']['this_month']:,.2f} TL")
print(f"Kritik stok      : {overview['products']['low_stock']} ürün")

# Tüm bayi listesi (abonelik + satış istatistikleriyle)
users = requests.get(f"{BASE_URL}/users", headers=HEADERS,
    params={"page_size": 100}).json()
for u in users["items"]:
    print(f"  [{u['id']}] {u['email']:<30} | "
          f"Ürün: {u['product_count']:>4} | "
          f"30g satış: {u['transactions_30d']:>3} | "
          f"Kalan gün: {u['sub_days_left']}")

# Belirli bir bayinin ürünleri
user_id = 42
prods = requests.get(f"{BASE_URL}/users/{user_id}/products",
    headers=HEADERS, params={"low_stock_only": True}).json()
print(f"\\nDüşük stok ürünler ({prods['total']} adet):")
for p in prods["items"]:
    print(f"  {p['name']:<30} Stok: {p['quantity']}")

# Abonelik güncelle
resp = requests.patch(f"{BASE_URL}/users/{user_id}/subscription",
    json={"sub_days": 30}, headers=HEADERS)
print("Abonelik güncellendi:", resp.json()["updated"])

# Tüm sistem işlemleri (cross-tenant)
import datetime
today = datetime.date.today().isoformat()
txs = requests.get(f"{BASE_URL}/transactions", headers=HEADERS,
    params={"date_from": today, "page_size": 50}).json()
print(f"\\nBugünkü işlemler: {txs['total']} adet")`;

  return '';
}

const ApiKeysView: React.FC<{ showToast: (m: string, t?: 'success'|'error') => void }> = ({ showToast }) => {
  const [keys, setKeys] = useState<ApiKeyItem[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');

  // Create modal
  const [showCreate, setShowCreate] = useState(false);
  const [allUsers, setAllUsers] = useState<{id:number,email:string,full_name:string}[]>([]);
  const [form, setForm] = useState({ name:'', description:'', user_id:0, scopes:[] as string[], is_full_access:false, is_super_admin_key:false, expires_at:'' });
  const [creating, setCreating] = useState(false);

  // Raw key display (shown once after creation)
  const [newRawKey, setNewRawKey] = useState<string|null>(null);
  const [keyCopied, setKeyCopied] = useState(false);

  // Example code section
  const [showExamples, setShowExamples] = useState(false);
  const [codeLang, setCodeLang] = useState<CodeLang>('curl');
  const [exampleKey, setExampleKey] = useState('sf_xxxxxxxxxxxxxxxxxxxxxxxxxxxx');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await api.get('/superadmin/api-keys', { params: { search: search || undefined, page_size: 100 } });
      setKeys(r.data.items || []);
      setTotal(r.data.total || 0);
    } catch { showToast('Anahtarlar yüklenemedi', 'error'); }
    finally { setLoading(false); }
  // showToast intentionally excluded — it's an unstable reference that would cause infinite refetch loops
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  useEffect(() => { load(); }, [load]);

  const loadUsers = async () => {
    try {
      const r = await api.get('/superadmin/users', { params: { page_size: 500, role: 'bayi_sahibi' } });
      setAllUsers((r.data.users || r.data.items || []).map((u: any) => ({ id: u.id, email: u.email, full_name: u.full_name || '' })));
    } catch {}
  };

  const openCreate = () => {
    loadUsers();
    setForm({ name:'', description:'', user_id:0, scopes:[], is_full_access:false, is_super_admin_key:false, expires_at:'' });
    setShowCreate(true);
  };

  const toggleScope = (scope: string) => {
    setForm(f => ({ ...f, scopes: f.scopes.includes(scope) ? f.scopes.filter(s=>s!==scope) : [...f.scopes, scope] }));
  };

  const handleCreate = async () => {
    if (!form.name.trim()) { showToast('İsim zorunlu', 'error'); return; }
    if (!form.is_super_admin_key && !form.user_id) { showToast('Kullanıcı seçiniz', 'error'); return; }
    if (!form.is_full_access && form.scopes.length === 0) { showToast('En az bir yetki seçin veya Tam Yetki verin', 'error'); return; }
    setCreating(true);
    try {
      const r = await api.post('/superadmin/api-keys', {
        name: form.name.trim(),
        description: form.description || null,
        user_id: form.is_super_admin_key ? null : form.user_id,
        scopes: form.is_full_access ? [] : form.scopes,
        is_full_access: form.is_full_access,
        is_super_admin_key: form.is_super_admin_key,
        expires_at: form.expires_at || null,
      });
      setShowCreate(false);
      setNewRawKey(r.data.raw_key);
      setKeyCopied(false);
      showToast('API anahtarı oluşturuldu', 'success');
      load();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Oluşturma hatası', 'error');
    } finally { setCreating(false); }
  };

  const handleToggle = async (id: number) => {
    try {
      await api.patch(`/superadmin/api-keys/${id}/toggle`);
      setKeys(ks => ks.map(k => k.id === id ? { ...k, is_active: !k.is_active } : k));
    } catch { showToast('Güncelleme hatası', 'error'); }
  };

  const handleDelete = async (id: number, name: string) => {
    if (!confirm(`"${name}" anahtarını kalıcı olarak sil?`)) return;
    try {
      await api.delete(`/superadmin/api-keys/${id}`);
      setKeys(ks => ks.filter(k => k.id !== id));
      showToast('Anahtar silindi', 'success');
    } catch { showToast('Silme hatası', 'error'); }
  };

  const copyKey = (key: string) => {
    navigator.clipboard.writeText(key).then(() => { setKeyCopied(true); setTimeout(() => setKeyCopied(false), 2000); });
  };

  const baseUrl = window.location.origin.replace(':5173','').replace(':3000','') + (window.location.port === '80' || window.location.port === '443' ? '' : '');
  const apiBase = import.meta.env?.VITE_API_URL?.replace('/api/v1','') || window.location.origin;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <KeyRound size={20} className="text-indigo-500" /> API Anahtarları
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Masaüstü, mobil ve web uygulamaları için X-API-Key kimlik doğrulama anahtarları
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setShowExamples(!showExamples)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400 text-sm hover:bg-indigo-50 dark:hover:bg-indigo-950 transition">
            <ExternalLink size={14} /> Entegrasyon Rehberi
          </button>
          <button onClick={openCreate}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-indigo-600 text-white text-sm hover:bg-indigo-700 transition">
            <Plus size={14} /> Yeni Anahtar
          </button>
        </div>
      </div>

      {/* New raw key display (shown ONCE) */}
      {newRawKey && (
        <div className="bg-amber-50 dark:bg-amber-950 border border-amber-300 dark:border-amber-700 rounded-xl p-4 space-y-3">
          <div className="flex items-center gap-2 text-amber-700 dark:text-amber-300 font-bold text-sm">
            <AlertTriangle size={16} /> API anahtarı yalnızca bir kez gösterilir — şimdi kopyalayın!
          </div>
          <div className="flex items-center gap-2">
            <code className="flex-1 bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-800 rounded-lg px-3 py-2 text-sm font-mono text-slate-800 dark:text-slate-200 break-all select-all">
              {newRawKey}
            </code>
            <button onClick={() => copyKey(newRawKey)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-sm font-medium transition whitespace-nowrap">
              {keyCopied ? <CheckCircle size={14} /> : <Copy size={14} />}
              {keyCopied ? 'Kopyalandı!' : 'Kopyala'}
            </button>
          </div>
          <button onClick={() => setNewRawKey(null)} className="text-xs text-amber-600 dark:text-amber-400 hover:underline">
            Anladım, pencereyi kapat
          </button>
        </div>
      )}

      {/* Integration guide */}
      {showExamples && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-700">
            <h3 className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-2">
              <ExternalLink size={16} /> Entegrasyon Rehberi
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Tüm isteklerde <code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">X-API-Key</code> header'ı kullanın.
              JWT token gerekmez. Anahtar sahibi bayi hesabı adına çalışır.
            </p>
          </div>

          {/* Key input for examples */}
          <div className="px-5 py-3 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-700 flex items-center gap-3">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400 whitespace-nowrap">Örnek anahtar:</span>
            <input
              value={exampleKey}
              onChange={e => setExampleKey(e.target.value)}
              className="flex-1 text-xs font-mono bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded px-2 py-1 text-slate-700 dark:text-slate-200"
              placeholder="sf_..."
            />
          </div>

          {/* Language tabs */}
          <div className="flex border-b border-slate-200 dark:border-slate-700 px-4 gap-1 overflow-x-auto">
            {(['curl','python','javascript','csharp','arduino','admin_python'] as CodeLang[]).map(lang => (
              <button key={lang} onClick={() => setCodeLang(lang)}
                className={`px-3 py-2.5 text-xs font-bold whitespace-nowrap border-b-2 transition ${codeLang===lang ? (lang==='admin_python' ? 'border-red-500 text-red-600 dark:text-red-400' : 'border-indigo-600 text-indigo-600 dark:text-indigo-400') : 'border-transparent text-slate-400 hover:text-slate-600'}`}>
                {lang === 'curl' ? 'cURL' : lang === 'python' ? 'Python' : lang === 'javascript' ? 'JavaScript' : lang === 'csharp' ? 'C#' : lang === 'arduino' ? 'Arduino/ESP32' : '👑 Yönetim API (Python)'}
              </button>
            ))}
          </div>

          <div className="p-4">
            <pre className="bg-slate-900 dark:bg-slate-950 text-green-300 text-xs p-4 rounded-lg overflow-x-auto whitespace-pre leading-relaxed">
              {buildExampleCode(codeLang, exampleKey, apiBase)}
            </pre>
          </div>

          {/* API endpoints reference */}
          <div className="px-5 pb-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              { method:'GET',    path:'/api/v1/products',             scope:'products:read',     desc:'Ürün listesi' },
              { method:'POST',   path:'/api/v1/products',             scope:'products:write',    desc:'Ürün oluştur' },
              { method:'PUT',    path:'/api/v1/products/{id}',        scope:'products:write',    desc:'Ürün güncelle' },
              { method:'GET',    path:'/api/v1/finance/transactions', scope:'transactions:read', desc:'Satış listesi' },
              { method:'POST',   path:'/api/v1/finance/transactions', scope:'transactions:write',desc:'Satış oluştur' },
              { method:'GET',    path:'/api/v1/debts',                scope:'customers:read',    desc:'Borç listesi' },
              { method:'GET',    path:'/api/v1/warranty',             scope:'warranty:read',     desc:'Garanti listesi' },
              { method:'GET',    path:'/api/v1/categories',           scope:'categories:read',   desc:'Kategoriler' },
              { method:'GET',    path:'/api/v1/dashboard/stats',      scope:'reports:read',      desc:'Dashboard istatistikleri' },
              { method:'GET',    path:'/api/v1/devices',              scope:'devices:read',      desc:'Cihaz listesi' },
            ].map(ep => (
              <div key={ep.path+ep.method} className="flex items-start gap-2 bg-slate-50 dark:bg-slate-800 rounded-lg p-2.5">
                <span className={`text-xs font-bold px-1.5 py-0.5 rounded shrink-0 ${ep.method==='GET' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300' : 'bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300'}`}>
                  {ep.method}
                </span>
                <div className="min-w-0">
                  <code className="text-xs text-slate-600 dark:text-slate-300 break-all">{ep.path}</code>
                  <div className="text-xs text-slate-400 dark:text-slate-500">{ep.desc} · <span className="font-mono">{ep.scope}</span></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Search bar */}
      <div className="flex gap-2 items-center">
        <div className="relative flex-1 max-w-xs">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Anahtar adı ara..."
            className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none" />
        </div>
        <button onClick={load} className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 transition">
          <RefreshCw size={14} className="text-slate-400" />
        </button>
        <span className="text-sm text-slate-500 dark:text-slate-400">{total} anahtar</span>
      </div>

      {/* Keys table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-12 text-slate-400"><RefreshCw size={18} className="animate-spin mr-2" /> Yükleniyor…</div>
        ) : keys.length === 0 ? (
          <div className="py-12 text-center text-slate-400 text-sm">Henüz API anahtarı oluşturulmamış</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 text-left text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  <th className="px-4 py-3 font-semibold">Anahtar</th>
                  <th className="px-4 py-3 font-semibold">Kullanıcı</th>
                  <th className="px-4 py-3 font-semibold">Yetkiler</th>
                  <th className="px-4 py-3 font-semibold text-right">Kullanım</th>
                  <th className="px-4 py-3 font-semibold">Son Kullanım</th>
                  <th className="px-4 py-3 font-semibold">Durum</th>
                  <th className="px-4 py-3 font-semibold">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {keys.map(k => (
                  <tr key={k.id} className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 transition ${k.is_super_admin_key ? 'bg-red-50/30 dark:bg-red-900/10' : ''}`}>
                    <td className="px-4 py-3">
                      <div className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                        {k.name}
                        {k.is_super_admin_key && (
                          <span className="text-xs bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-300 px-1.5 py-0.5 rounded-full font-semibold flex items-center gap-0.5">
                            <Crown size={9}/> YÖNETİM
                          </span>
                        )}
                      </div>
                      <code className="text-xs text-slate-400 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">{k.key_prefix}…</code>
                      {k.description && <div className="text-xs text-slate-400 mt-0.5">{k.description}</div>}
                      {k.expires_at && <div className="text-xs text-orange-500 mt-0.5">Bitiş: {new Date(k.expires_at).toLocaleDateString('tr-TR')}</div>}
                    </td>
                    <td className="px-4 py-3">
                      {k.is_super_admin_key
                        ? <span className="text-xs text-red-500 font-semibold">Süper Admin</span>
                        : <><div className="text-slate-700 dark:text-slate-300 text-xs">{k.user_full_name || k.user_email}</div><div className="text-slate-400 text-xs">{k.user_email}</div></>
                      }
                    </td>
                    <td className="px-4 py-3 max-w-[200px]">
                      {k.is_full_access ? (
                        <span className="inline-flex items-center gap-1 text-xs bg-purple-100 dark:bg-purple-900/40 text-purple-700 dark:text-purple-300 px-2 py-0.5 rounded-full font-semibold">
                          <Crown size={10} /> Tam Yetki
                        </span>
                      ) : (
                        <div className="flex flex-wrap gap-1">
                          {k.scopes.map(s => (
                            <span key={s} className="text-xs bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 px-1.5 py-0.5 rounded font-mono">{s}</span>
                          ))}
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span className="font-semibold text-slate-700 dark:text-slate-300">{k.usage_count.toLocaleString('tr-TR')}</span>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-400">
                      {k.last_used_at ? new Date(k.last_used_at).toLocaleString('tr-TR') : '—'}
                    </td>
                    <td className="px-4 py-3">
                      <button onClick={() => handleToggle(k.id)}
                        className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full font-medium transition ${k.is_active ? 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-200' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-slate-200'}`}>
                        {k.is_active ? <><CheckCircle size={10} /> Aktif</> : <><XCircle size={10} /> Pasif</>}
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <button onClick={() => handleDelete(k.id, k.name)}
                        className="p-1.5 text-red-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition">
                        <Trash2 size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-700">
              <h3 className="font-bold text-slate-800 dark:text-slate-200 text-lg flex items-center gap-2">
                <KeyRound size={18} className="text-indigo-500" /> Yeni API Anahtarı
              </h3>
              <button onClick={() => setShowCreate(false)} className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800"><X size={18} /></button>
            </div>

            <div className="p-6 space-y-5">
              {/* Name */}
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Anahtar Adı *</label>
                <input value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))}
                  placeholder="Örn: Mobil Uygulama, Depo Sistemi, Arduino Bağlantısı"
                  className="w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Açıklama (opsiyonel)</label>
                <input value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))}
                  placeholder="Hangi uygulama için kullanılacak?"
                  className="w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
              </div>

              {/* Süper admin key toggle */}
              <div className={`flex items-center gap-3 p-3 rounded-lg border transition ${form.is_super_admin_key ? 'bg-red-50 dark:bg-red-900/20 border-red-300 dark:border-red-700' : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700'}`}>
                <button onClick={() => setForm(f=>({...f, is_super_admin_key:!f.is_super_admin_key, user_id:0, scopes:[], is_full_access:f.is_super_admin_key ? false : f.is_full_access}))}
                  className={`shrink-0 ${form.is_super_admin_key ? 'text-red-600 dark:text-red-400' : 'text-slate-400'}`}>
                  {form.is_super_admin_key ? <ToggleRight size={28} /> : <ToggleLeft size={28} />}
                </button>
                <div>
                  <div className="text-sm font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <Crown size={13} className={form.is_super_admin_key ? 'text-red-500' : 'text-slate-400'} />
                    Süper Admin Yönetim Anahtarı
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    Tüm bayilerin verilerine çapraz erişim sağlar. <span className="font-semibold text-red-500">Yalnızca kendiniz için oluşturun.</span>
                  </div>
                </div>
              </div>

              {/* User select — sadece bayi anahtarı için */}
              {!form.is_super_admin_key && (
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Hesap (Bayi) *</label>
                <select value={form.user_id} onChange={e=>setForm(f=>({...f,user_id:+e.target.value}))}
                  className="w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
                  <option value={0}>— Kullanıcı seçin —</option>
                  {allUsers.map(u => (
                    <option key={u.id} value={u.id}>{u.full_name ? `${u.full_name} (${u.email})` : u.email}</option>
                  ))}
                </select>
                <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">Anahtar bu hesabın verilerine erişir.</p>
              </div>
              )}

              {/* Full access toggle */}
              <div className="flex items-center gap-3 p-3 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg">
                <button onClick={() => setForm(f=>({...f, is_full_access:!f.is_full_access, scopes:[]}))}
                  className="shrink-0 text-purple-600 dark:text-purple-400">
                  {form.is_full_access ? <ToggleRight size={28} /> : <ToggleLeft size={28} className="text-slate-400" />}
                </button>
                <div>
                  <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">Tam Yetki</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">Tüm API endpoint'lerine tam erişim sağlar. Yetki seçimine gerek kalmaz.</div>
                </div>
              </div>

              {/* Scope selector */}
              {!form.is_full_access && (
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                    {form.is_super_admin_key ? 'Yönetim Yetkileri *' : 'Yetkiler *'}
                  </label>
                  {form.is_super_admin_key && (
                    <div className="mb-3 flex flex-wrap gap-2">
                      {[
                        { key:'admin:overview',   label:'Genel Bakış' },
                        { key:'admin:users:read', label:'Bayi Listesi' },
                        { key:'admin:users:write',label:'Bayi Yönetimi' },
                        { key:'admin:data:read',  label:'Veri Erişimi' },
                        { key:'admin:full',       label:'Tam Yönetim' },
                      ].map(s => (
                        <button key={s.key} onClick={() => toggleScope(s.key)}
                          className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border transition ${form.scopes.includes(s.key) ? 'bg-red-600 border-red-600 text-white' : 'bg-white dark:bg-slate-900 border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-400 hover:border-red-400'}`}>
                          {form.scopes.includes(s.key) && <CheckCircle size={10} />}
                          {s.label}
                        </button>
                      ))}
                    </div>
                  )}
                  {!form.is_super_admin_key && (
                  <div className="space-y-3">
                    {SCOPE_GROUPS.map(group => {
                      const groupScopes = SCOPES_DEF.filter(s => s.group === group);
                      return (
                        <div key={group} className="border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden">
                          <div className="px-3 py-2 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wide">{group}</div>
                          <div className="flex flex-wrap gap-2 p-3">
                            {groupScopes.map(s => (
                              <button key={s.key} onClick={() => toggleScope(s.key)}
                                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition ${form.scopes.includes(s.key) ? 'bg-indigo-600 border-indigo-600 text-white' : 'bg-white dark:bg-slate-900 border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-400 hover:border-indigo-400'}`}>
                                {form.scopes.includes(s.key) && <CheckCircle size={10} />}
                                {s.label}
                              </button>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  )}
                  {form.scopes.length > 0 && (
                    <p className="text-xs text-slate-400 mt-2">{form.scopes.length} yetki seçildi</p>
                  )}
                </div>
              )}

              {/* Expiry */}
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Geçerlilik Tarihi (opsiyonel)</label>
                <input type="datetime-local" value={form.expires_at} onChange={e=>setForm(f=>({...f,expires_at:e.target.value}))}
                  className="w-full px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
                <p className="text-xs text-slate-400 mt-1">Boş bırakılırsa süresiz geçerlidir.</p>
              </div>
            </div>

            <div className="flex gap-3 px-6 py-4 border-t border-slate-200 dark:border-slate-700">
              <button onClick={() => setShowCreate(false)}
                className="flex-1 py-2 rounded-lg border border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-400 text-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition">
                İptal
              </button>
              <button onClick={handleCreate} disabled={creating}
                className="flex-1 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold transition disabled:opacity-50 flex items-center justify-center gap-2">
                {creating ? <><RefreshCw size={14} className="animate-spin" /> Oluşturuluyor…</> : <><KeyRound size={14} /> Anahtar Oluştur</>}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ─── Storage Pool View ───────────────────────────────────────────────────────

const StoragePoolView: React.FC<{ showToast: (msg: string, type?: any) => void }> = ({ showToast }) => {
  const [stats, setStats] = useState<any>(null);
  const [nodes, setNodes] = useState<any[]>([]);
  const [files, setFiles] = useState<any[]>([]);
  const [backups, setBackups] = useState<any[]>([]);
  const [fileTotal, setFileTotal] = useState(0);
  const [fileQ, setFileQ] = useState('');
  const [fileOffset, setFileOffset] = useState(0);
  const [tab, setTab] = useState<'nodes' | 'files' | 'backups'>('nodes');
  const [loading, setLoading] = useState(false);
  const [backupRunning, setBackupRunning] = useState(false);
  const [showAddNode, setShowAddNode] = useState(false);
  const [newNode, setNewNode] = useState({ name: '', type: 'minio', endpoint_url: '', access_key: '', secret_key: '', bucket: '', is_primary: false, is_master_backup: false, is_external_backup: false });
  const [pushingExternal, setPushingExternal] = useState<Record<number, boolean>>({});
  const [nodeHealth, setNodeHealth] = useState<Record<number, { ok: boolean; latency_ms: number; checking: boolean }>>({});
  const [importingFtp, setImportingFtp] = useState(false);
  const FILE_PAGE = 20;

  const fmt = (bytes: number | null) => {
    if (bytes == null) return '—';
    if (bytes >= 1e12) return `${(bytes / 1e12).toFixed(1)} TB`;
    if (bytes >= 1e9) return `${(bytes / 1e9).toFixed(1)} GB`;
    if (bytes >= 1e6) return `${(bytes / 1e6).toFixed(1)} MB`;
    return `${(bytes / 1e3).toFixed(0)} KB`;
  };

  const pct = (used: number | null, total: number | null) => {
    if (!used || !total) return 0;
    return Math.round((used / total) * 100);
  };

  const load = async () => {
    setLoading(true);
    try {
      const [sR, nR, bR] = await Promise.all([
        api.get('/storage/stats'),
        api.get('/storage/nodes'),
        api.get('/storage/backups'),
      ]);
      setStats(sR.data);
      setNodes(nR.data);
      setBackups(bR.data);
    } catch { showToast('Depolama verileri yüklenemedi', 'error'); }
    finally { setLoading(false); }
  };

  const loadFiles = async () => {
    try {
      const r = await api.get('/storage/files', { params: { q: fileQ || undefined, limit: FILE_PAGE, offset: fileOffset } });
      setFiles(r.data.items || []);
      setFileTotal(r.data.total || 0);
    } catch { showToast('Dosyalar yüklenemedi', 'error'); }
  };

  useEffect(() => { load(); }, []);
  useEffect(() => { if (tab === 'files') loadFiles(); }, [tab, fileQ, fileOffset]);

  const triggerBackup = async () => {
    setBackupRunning(true);
    try {
      await api.post('/storage/backups/trigger');
      showToast('Yedek başlatıldı', 'success');
      setTimeout(load, 2000);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Yedek başlatılamadı', 'error');
    } finally { setBackupRunning(false); }
  };

  const refreshNodeStats = async (nodeId: number) => {
    try {
      await api.post(`/storage/nodes/${nodeId}/refresh-stats`);
      showToast('İstatistikler güncellendi', 'success');
      load();
    } catch { showToast('Güncelleme başarısız', 'error'); }
  };

  const healthCheckNode = async (nodeId: number) => {
    setNodeHealth(h => ({ ...h, [nodeId]: { ok: false, latency_ms: 0, checking: true } }));
    try {
      const r = await api.post(`/storage/nodes/${nodeId}/health-check`);
      setNodeHealth(h => ({ ...h, [nodeId]: { ok: r.data.ok, latency_ms: r.data.latency_ms, checking: false } }));
    } catch {
      setNodeHealth(h => ({ ...h, [nodeId]: { ok: false, latency_ms: 0, checking: false } }));
    }
  };

  const pushExternalBackup = async (backupId: number) => {
    setPushingExternal(p => ({ ...p, [backupId]: true }));
    try {
      const r = await api.post(`/storage/backups/${backupId}/push-external`);
      const results: Array<{node: string; ok: boolean; error?: string}> = r.data.results || [];
      const ok = results.filter(x => x.ok).length;
      const fail = results.filter(x => !x.ok).length;
      showToast(fail === 0 ? `${ok} düğüme başarıyla gönderildi` : `${ok} başarılı, ${fail} hatalı`, fail === 0 ? 'success' : 'error');
      load();
    } catch (e: any) { showToast(e?.response?.data?.detail || 'Harici gönderim başarısız', 'error'); }
    finally { setPushingExternal(p => ({ ...p, [backupId]: false })); }
  };

  const importFtpServers = async () => {
    setImportingFtp(true);
    try {
      const r = await api.post('/storage/nodes/import-ftp-servers');
      showToast(`${r.data.imported} FTP sunucu içe aktarıldı, ${r.data.skipped} atlandı`, 'success');
      load();
    } catch (e: any) { showToast(e?.response?.data?.detail || 'İçe aktarma başarısız', 'error'); }
    finally { setImportingFtp(false); }
  };

  const addNode = async () => {
    try {
      await api.post('/storage/nodes', newNode);
      showToast('Düğüm eklendi', 'success');
      setShowAddNode(false);
      setNewNode({ name: '', type: 'minio', endpoint_url: '', access_key: '', secret_key: '', bucket: '', is_primary: false, is_master_backup: false, is_external_backup: false });
      load();
    } catch (e: any) { showToast(e?.response?.data?.detail || 'Eklenemedi', 'error'); }
  };

  const deleteNode = async (id: number, name: string) => {
    if (!confirm(`"${name}" düğümü silinsin mi?`)) return;
    try {
      await api.delete(`/storage/nodes/${id}`);
      showToast('Düğüm silindi', 'success');
      load();
    } catch (e: any) { showToast(e?.response?.data?.detail || 'Silinemedi', 'error'); }
  };

  const nodeTypeBadge = (type: string) => {
    const map: Record<string, string> = {
      minio: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',
      sftp: 'bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300',
      ftp: 'bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300',
      s3: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
      local: 'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300',
    };
    return map[type] || map.local;
  };

  const statusDot = (status: string) => {
    if (status === 'done') return 'text-emerald-500';
    if (status === 'running') return 'text-blue-500 animate-pulse';
    if (status === 'failed') return 'text-red-500';
    return 'text-slate-400';
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-black text-slate-800 dark:text-white flex items-center gap-2">
            <Database size={20} className="text-indigo-500" /> Depolama Havuzu
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">MinIO · FTP/SFTP · S3 · Günlük Yedek (20 gün)</p>
        </div>
        <button onClick={load} disabled={loading} className="flex items-center gap-2 px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg text-sm font-semibold transition">
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} /> Yenile
        </button>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: 'Toplam Alan', value: fmt(stats.total_bytes), icon: HardDrive, color: 'indigo' },
            { label: 'Kullanılan', value: fmt(stats.used_bytes), icon: Archive, color: 'amber' },
            { label: 'Boş Alan', value: fmt(stats.free_bytes), icon: CheckCircle2, color: 'emerald' },
            { label: 'Dosya Sayısı', value: stats.file_count?.toLocaleString() ?? '0', icon: FolderTree, color: 'purple' },
          ].map(s => (
            <div key={s.label} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl bg-${s.color}-100 dark:bg-${s.color}-900/30 flex items-center justify-center`}>
                <s.icon size={18} className={`text-${s.color}-600 dark:text-${s.color}-400`} />
              </div>
              <div>
                <div className="text-xs text-slate-500">{s.label}</div>
                <div className="text-lg font-black text-slate-800 dark:text-white">{s.value}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tabs */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex border-b border-slate-200 dark:border-slate-800">
          {([['nodes', 'Düğümler'], ['files', 'Dosya Envanteri'], ['backups', 'Yedekler']] as const).map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)}
              className={`px-5 py-3.5 text-sm font-bold border-b-2 transition ${tab === k ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400' : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}>
              {l}
            </button>
          ))}
        </div>

        <div className="p-4">
          {/* NODES TAB */}
          {tab === 'nodes' && (
            <div className="space-y-3">
              <div className="flex flex-wrap gap-2 justify-end">
                <button onClick={importFtpServers} disabled={importingFtp}
                  className="flex items-center gap-2 px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg text-sm font-semibold transition disabled:opacity-50">
                  {importingFtp ? <RefreshCw size={13} className="animate-spin" /> : <Server size={13} />}
                  FTP/SFTP'yi Aktar
                </button>
                <button onClick={() => setShowAddNode(v => !v)}
                  className="flex items-center gap-2 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition">
                  <Plus size={14} /> Düğüm Ekle
                </button>
              </div>

              {showAddNode && (
                <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-4 space-y-3 border border-slate-200 dark:border-slate-700">
                  <h3 className="font-bold text-sm text-slate-700 dark:text-slate-200">Yeni Düğüm</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <input placeholder="İsim" value={newNode.name} onChange={e => setNewNode(n => ({ ...n, name: e.target.value }))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm" />
                    <select value={newNode.type} onChange={e => setNewNode(n => ({ ...n, type: e.target.value }))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm">
                      <option value="minio">MinIO</option>
                      <option value="sftp">SFTP</option>
                      <option value="ftp">FTP</option>
                      <option value="s3">S3</option>
                      <option value="local">Yerel</option>
                    </select>
                    <input placeholder="Endpoint URL (http://host:9000)" value={newNode.endpoint_url} onChange={e => setNewNode(n => ({ ...n, endpoint_url: e.target.value }))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm" />
                    <input placeholder="Bucket adı" value={newNode.bucket} onChange={e => setNewNode(n => ({ ...n, bucket: e.target.value }))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm" />
                    <input placeholder="Access Key" value={newNode.access_key} onChange={e => setNewNode(n => ({ ...n, access_key: e.target.value }))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm" />
                    <input type="password" placeholder="Secret Key" value={newNode.secret_key} onChange={e => setNewNode(n => ({ ...n, secret_key: e.target.value }))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm" />
                  </div>
                  <div className="flex gap-4 text-sm">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={newNode.is_primary} onChange={e => setNewNode(n => ({ ...n, is_primary: e.target.checked }))} /> Ana Depolama
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={newNode.is_master_backup} onChange={e => setNewNode(n => ({ ...n, is_master_backup: e.target.checked }))} /> Ana Yedek Düğümü
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" checked={newNode.is_external_backup} onChange={e => setNewNode(n => ({ ...n, is_external_backup: e.target.checked }))} /> Harici S3 Yedek
                    </label>
                  </div>
                  <div className="flex gap-2 justify-end">
                    <button onClick={() => setShowAddNode(false)} className="px-4 py-2 rounded-lg bg-slate-200 dark:bg-slate-700 text-sm font-semibold">İptal</button>
                    <button onClick={addNode} className="px-4 py-2 rounded-lg bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700">Ekle</button>
                  </div>
                </div>
              )}

              {nodes.length === 0 && !loading && (
                <div className="text-center py-10 text-slate-400">
                  <Database size={32} className="mx-auto mb-2 opacity-30" />
                  <p className="text-sm">Henüz düğüm yok. MinIO otomatik olarak kaydedilecek.</p>
                </div>
              )}

              {nodes.map(node => {
                const usedPct = pct(node.used_bytes, node.total_bytes);
                return (
                  <div key={node.id} className="bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className={`w-2.5 h-2.5 rounded-full shrink-0 ${node.is_active ? 'bg-emerald-500' : 'bg-slate-400'}`} />
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-sm text-slate-800 dark:text-white">{node.name}</span>
                            <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${nodeTypeBadge(node.type)}`}>{node.type.toUpperCase()}</span>
                            {node.is_primary && <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300">ANA</span>}
                            {node.is_master_backup && <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300">ANA YEDEK</span>}
                            {node.is_external_backup && <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-sky-100 text-sky-700 dark:bg-sky-900/40 dark:text-sky-300">HARİCİ S3</span>}
                          </div>
                          <div className="text-xs text-slate-500 truncate mt-0.5">{node.endpoint_url || node.host || 'Yerel'} {node.bucket ? `· ${node.bucket}` : ''}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        {/* Health check göstergesi */}
                        {nodeHealth[node.id] && (
                          <span className={`text-[11px] font-bold px-1.5 py-0.5 rounded ${
                            nodeHealth[node.id].checking ? 'text-slate-400' :
                            nodeHealth[node.id].ok ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'
                          }`}>
                            {nodeHealth[node.id].checking ? '…' : nodeHealth[node.id].ok ? `✓ ${nodeHealth[node.id].latency_ms}ms` : '✗ Hata'}
                          </span>
                        )}
                        <button onClick={() => healthCheckNode(node.id)} title="Ping / Bağlantı testi"
                          className="p-1.5 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/30 text-slate-400 hover:text-blue-600 transition"
                          disabled={nodeHealth[node.id]?.checking}>
                          <Activity size={13} />
                        </button>
                        <button onClick={() => refreshNodeStats(node.id)} title="İstatistikleri güncelle"
                          className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 transition">
                          <RefreshCw size={13} />
                        </button>
                        <button onClick={() => deleteNode(node.id, node.name)}
                          className="p-1.5 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30 text-slate-400 hover:text-red-500 transition">
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>

                    {/* Disk kullanım çubuğu */}
                    {node.total_bytes && (
                      <div className="mt-3">
                        <div className="flex justify-between text-xs text-slate-500 mb-1">
                          <span>{fmt(node.used_bytes)} kullanıldı</span>
                          <span>{fmt(node.total_bytes)} toplam · %{usedPct}</span>
                        </div>
                        <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                          <div className={`h-full rounded-full transition-all ${usedPct > 85 ? 'bg-red-500' : usedPct > 60 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                            style={{ width: `${Math.min(usedPct, 100)}%` }} />
                        </div>
                      </div>
                    )}
                    {!node.total_bytes && (
                      <p className="text-xs text-slate-400 mt-2 italic">Disk bilgisi için "İstatistikleri güncelle" düğmesine tıklayın</p>
                    )}
                    {node.last_error && (
                      <div className="mt-2 text-xs text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 px-2 py-1 rounded">⚠ {node.last_error}</div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* FILES TAB */}
          {tab === 'files' && (
            <div className="space-y-3">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input placeholder="Dosya ara..." value={fileQ} onChange={e => { setFileQ(e.target.value); setFileOffset(0); }}
                    className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm" />
                </div>
              </div>

              {files.length === 0 ? (
                <div className="text-center py-10 text-slate-400">
                  <FolderTree size={32} className="mx-auto mb-2 opacity-30" />
                  <p className="text-sm">Henüz dosya kaydı yok</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-xs text-slate-500 border-b border-slate-200 dark:border-slate-700">
                        <th className="text-left py-2 px-2 font-semibold">Dosya</th>
                        <th className="text-right py-2 px-2 font-semibold">Boyut</th>
                        <th className="text-center py-2 px-2 font-semibold">Replica'lar</th>
                        <th className="text-right py-2 px-2 font-semibold">Tarih</th>
                      </tr>
                    </thead>
                    <tbody>
                      {files.map(f => (
                        <tr key={f.id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50">
                          <td className="py-2 px-2">
                            <div className="font-medium text-slate-800 dark:text-white truncate max-w-[200px]">{f.filename}</div>
                            <div className="text-[11px] text-slate-400 truncate">{f.storage_key}</div>
                          </td>
                          <td className="py-2 px-2 text-right text-slate-600 dark:text-slate-300 whitespace-nowrap">{fmt(f.size_bytes)}</td>
                          <td className="py-2 px-2 text-center">
                            <div className="flex items-center justify-center gap-1">
                              {f.replicas.map((r: any) => (
                                <span key={r.id} title={`Node ${r.node_id} · ${r.is_primary ? 'Primary' : 'Replica'}`}
                                  className={`w-2 h-2 rounded-full ${r.is_verified ? 'bg-emerald-500' : 'bg-amber-400'}`} />
                              ))}
                              {f.replicas.length === 0 && <span className="text-[11px] text-slate-400">—</span>}
                            </div>
                          </td>
                          <td className="py-2 px-2 text-right text-[11px] text-slate-400 whitespace-nowrap">
                            {f.uploaded_at ? new Date(f.uploaded_at).toLocaleDateString('tr-TR') : '—'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Sayfalama */}
              {fileTotal > FILE_PAGE && (
                <div className="flex justify-between items-center pt-2">
                  <span className="text-xs text-slate-500">{fileTotal} dosya</span>
                  <div className="flex gap-2">
                    <button disabled={fileOffset === 0} onClick={() => setFileOffset(Math.max(0, fileOffset - FILE_PAGE))}
                      className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-sm font-semibold disabled:opacity-40">‹</button>
                    <span className="text-xs text-slate-500 self-center">{Math.floor(fileOffset / FILE_PAGE) + 1} / {Math.ceil(fileTotal / FILE_PAGE)}</span>
                    <button disabled={fileOffset + FILE_PAGE >= fileTotal} onClick={() => setFileOffset(fileOffset + FILE_PAGE)}
                      className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-sm font-semibold disabled:opacity-40">›</button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* BACKUPS TAB */}
          {tab === 'backups' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <p className="text-xs text-slate-500">Günlük otomatik yedekler — 20 gün saklanır, eski olanlar otomatik silinir</p>
                <button onClick={triggerBackup} disabled={backupRunning || stats?.backup_running}
                  className="flex items-center gap-2 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-semibold transition disabled:opacity-50">
                  {backupRunning || stats?.backup_running
                    ? <><RefreshCw size={13} className="animate-spin" /> Çalışıyor…</>
                    : <><Archive size={13} /> Şimdi Yedekle</>}
                </button>
              </div>

              {backups.length === 0 ? (
                <div className="text-center py-10 text-slate-400">
                  <Archive size={32} className="mx-auto mb-2 opacity-30" />
                  <p className="text-sm">Henüz yedek yok</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {backups.map(b => (
                    <div key={b.id} className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                      <div className={`w-2.5 h-2.5 rounded-full shrink-0 ${statusDot(b.status)}`} />
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm text-slate-800 dark:text-white truncate">{b.filename || '—'}</div>
                        <div className="text-xs text-slate-500">
                          {b.backup_date ? new Date(b.backup_date).toLocaleString('tr-TR') : '—'}
                          {b.size_bytes ? ` · ${fmt(b.size_bytes)}` : ''}
                          {b.days_remaining != null ? ` · ${b.days_remaining}g kaldı` : ''}
                        </div>
                        {b.error && <div className="text-xs text-red-500 mt-0.5 truncate">{b.error}</div>}
                        {b.external_backup_status && (
                          <div className={`text-[11px] mt-0.5 font-semibold ${
                            b.external_backup_status === 'done' ? 'text-sky-600 dark:text-sky-400' :
                            b.external_backup_status === 'failed' ? 'text-red-500' :
                            b.external_backup_status === 'running' ? 'text-blue-500 animate-pulse' :
                            'text-slate-400'
                          }`}>
                            ☁ Harici S3: {b.external_backup_status === 'done' ? 'Gönderildi' : b.external_backup_status === 'failed' ? 'Hata' : b.external_backup_status}
                            {b.external_backup_error && ` — ${b.external_backup_error}`}
                          </div>
                        )}
                        {b.dr_tested_at && (
                          <div className={`text-[11px] mt-0.5 font-semibold ${b.dr_test_result === 'ok' ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500'}`}>
                            🧪 DR Test: {b.dr_test_result === 'ok' ? 'Başarılı' : 'Başarısız'} — {new Date(b.dr_tested_at).toLocaleDateString('tr-TR')}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap ${
                          b.status === 'done' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300' :
                          b.status === 'running' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300' :
                          b.status === 'failed' ? 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300' :
                          'bg-slate-100 text-slate-600'
                        }`}>{b.status}</span>
                        {b.status === 'done' && (
                          <button
                            onClick={() => pushExternalBackup(b.id)}
                            disabled={pushingExternal[b.id]}
                            title="Harici S3'e gönder"
                            className="p-1.5 rounded-lg hover:bg-sky-100 dark:hover:bg-sky-900/30 text-slate-400 hover:text-sky-600 transition disabled:opacity-40"
                          >
                            {pushingExternal[b.id] ? <RefreshCw size={13} className="animate-spin" /> : <Upload size={13} />}
                          </button>
                        )}
                        {b.status === 'done' && (
                          <button
                            onClick={async () => {
                              try {
                                await api.post(`/storage/backups/${b.id}/mark-dr-tested`, null, { params: { result: 'ok' } });
                                showToast('DR test başarılı olarak işaretlendi', 'success');
                                load();
                              } catch { showToast('İşaretlenemedi', 'error'); }
                            }}
                            title="DR testi başarılı olarak işaretle"
                            className="p-1.5 rounded-lg hover:bg-emerald-100 dark:hover:bg-emerald-900/30 text-slate-400 hover:text-emerald-600 transition"
                          >
                            <CheckCircle size={13} />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
