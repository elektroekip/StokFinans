import axios from 'axios';
import { loadingStart, loadingEnd } from '../components/GlobalLoadingBar';
import { isBackgroundRefresh } from './refreshBus';

export const api = axios.create({
  baseURL: '/api/v1',
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token');
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    // FormData (multipart upload — örn. garanti belgesi görseli, ürün resmi)
    // gönderirken default 'application/json' Content-Type'ı SİLMELİYİZ ki
    // tarayıcı kendi multipart boundary'sini eklesin. Aksi halde FastAPI
    // Form()/File() alanlarını parse edemez ve "Field required" 422 döner.
    if (config.data instanceof FormData && config.headers) {
      try { (config.headers as any).delete?.('Content-Type'); } catch {}
      delete (config.headers as any)['Content-Type'];
      delete (config.headers as any)['content-type'];
    }
    // Loading bar: arka plan yenileme veya _silent işaretli isteklerde gizlenir.
    // Kullanıcının başlattığı GET (sayfa açma, filtreleme) ve tüm mutasyonlarda görünür.
    if ((config as any)._silent || isBackgroundRefresh) {
      (config as any)._noBar = true;
    }
    if (!(config as any)._noBar) loadingStart();
    return config;
  },
  (error) => { loadingEnd(); return Promise.reject(error); },
);

// Refresh token işlemi sırasında birden fazla isteğin aynı anda yenileme
// denemesi yapmasını önleyen kuyruk mekanizması.
let isRefreshing = false;
let refreshQueue: Array<{ resolve: (token: string) => void; reject: (err: any) => void }> = [];

const processQueue = (error: any, token: string | null) => {
  refreshQueue.forEach(({ resolve, reject }) => {
    if (token) resolve(token);
    else reject(error);
  });
  refreshQueue = [];
};

const forceLogout = (showExpiredMessage = true) => {
  localStorage.removeItem('access_token');
  localStorage.removeItem('refresh_token');
  if (showExpiredMessage && typeof window !== 'undefined') {
    try { sessionStorage.setItem('session_expired', '1'); } catch {}
    window.location.reload();
  }
};

api.interceptors.response.use(
  (response) => {
    if (!(response.config as any)._noBar) loadingEnd();
    return response;
  },
  async (error) => {
    if (!(error?.config as any)?._noBar) loadingEnd();
    const status = error?.response?.status;
    const url: string = error?.config?.url || '';
    const isAuthRoute =
      url.includes('/auth/login') ||
      url.includes('/auth/register') ||
      url.includes('/auth/refresh');

    // 403 + email_not_verified: e-posta doğrulama ekranına yönlendir
    if (status === 403) {
      const detail = error?.response?.data?.detail;
      const isEmailNotVerified =
        detail && typeof detail === 'object' && detail.code === 'email_not_verified';
      const isLocallyHandled =
        url.includes('/auth/login') || url.includes('/auth/register');
      if (isEmailNotVerified && !isLocallyHandled) {
        const hadToken = !!localStorage.getItem('access_token');
        const email = (detail && typeof detail === 'object' && detail.email) || '';
        try {
          localStorage.removeItem('access_token');
          localStorage.removeItem('refresh_token');
        } catch {}
        if (typeof window !== 'undefined') {
          try {
            sessionStorage.setItem('email_verification_pending', email);
            if (hadToken) sessionStorage.setItem('email_verification_session_ended', '1');
          } catch {}
          window.location.reload();
        }
        return Promise.reject(error);
      }
    }

    // 401: access token süresi dolmuş → refresh token ile yenile
    if (status === 401 && !isAuthRoute) {
      const originalRequest = error.config;

      // Sonsuz döngüyü önle: zaten yenileme denemesi yapılmış istek tekrar 401 dönerse
      if (originalRequest._retried) {
        forceLogout(true);
        return Promise.reject(error);
      }

      const refreshToken = localStorage.getItem('refresh_token');
      if (!refreshToken) {
        forceLogout(!!localStorage.getItem('access_token'));
        return Promise.reject(error);
      }

      if (isRefreshing) {
        // Başka bir yenileme zaten devam ediyor: kuyrukta bekle
        return new Promise((resolve, reject) => {
          refreshQueue.push({ resolve, reject });
        }).then((newToken) => {
          originalRequest.headers.Authorization = `Bearer ${newToken}`;
          return api(originalRequest);
        });
      }

      originalRequest._retried = true;
      isRefreshing = true;

      try {
        const res = await axios.post('/api/v1/auth/refresh', { refresh_token: refreshToken });
        const newAccessToken: string = res.data.access_token;
        localStorage.setItem('access_token', newAccessToken);
        // Backend yeni refresh token döndürüyorsa onu da sakla
        if (res.data.refresh_token) {
          localStorage.setItem('refresh_token', res.data.refresh_token);
        }
        api.defaults.headers.common.Authorization = `Bearer ${newAccessToken}`;
        processQueue(null, newAccessToken);
        originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
        return api(originalRequest);
      } catch (refreshError) {
        processQueue(refreshError, null);
        forceLogout(true);
        return Promise.reject(refreshError);
      } finally {
        isRefreshing = false;
      }
    }

    return Promise.reject(error);
  },
);

// Backend rotalarıyla eşleşen adlandırılmış istemciler.
export const authApi = {
  login: (email: string, password: string) =>
    api.post('/auth/login', { email, password }),
  register: (data: Record<string, unknown>) =>
    api.post('/auth/register', data),
  logout: () => api.post('/auth/logout'),
  getProfile: () => api.get('/auth/profile'),
  updateProfile: (data: Record<string, unknown>) =>
    api.put('/auth/profile', data),
  refresh: (refresh_token: string) =>
    api.post('/auth/refresh', { refresh_token }),
};

export const productsApi = {
  list: (params?: Record<string, unknown>) => api.get('/products', { params }),
  get: (id: number | string) => api.get(`/products/${id}`),
  create: (data: Record<string, unknown>) => api.post('/products', data),
  update: (id: number | string, data: Record<string, unknown>) =>
    api.put(`/products/${id}`, data),
  remove: (id: number | string) => api.delete(`/products/${id}`),
};

export const financeApi = {
  list: (params?: Record<string, unknown>) =>
    api.get('/finance/transactions', { params }),
  create: (data: Record<string, unknown>) =>
    api.post('/finance/transactions', data),
  get: (id: number | string) => api.get(`/finance/transactions/${id}`),
  update: (id: number | string, data: Record<string, unknown>) =>
    api.put(`/finance/transactions/${id}`, data),
  remove: (id: number | string) => api.delete(`/finance/transactions/${id}`),
  balance: (customerName: string) =>
    api.get(`/finance/balance/${encodeURIComponent(customerName)}`),
  summary: (params?: Record<string, unknown>) =>
    api.get('/finance/summary', { params }),
};

export const dashboardApi = {
  getStats: (days = 30) => api.get('/dashboard/stats', { params: { days } }),
  getCriticalStockAlerts: () => api.get('/dashboard/critical-stock'),
  getPerformance: (params?: Record<string, unknown>) =>
    api.get('/dashboard/performance', { params }),
  getChartData: (params?: Record<string, unknown>) =>
    api.get('/dashboard/chart-data', { params }),
  getActivities: (params?: Record<string, unknown>) =>
    api.get('/dashboard/activities', { params }),
};

export const reportsApi = {
  daily: (params?: Record<string, unknown>) =>
    api.get('/reports/daily', { params }),
  monthly: (params?: Record<string, unknown>) =>
    api.get('/reports/monthly', { params }),
  custom: (params?: Record<string, unknown>) =>
    api.get('/reports/custom', { params }),
};

export const filesApi = {
  uploadProductImage: (productId: number | string, file: File) => {
    const fd = new FormData();
    fd.append('file', file);
    return api.post(`/files/product/${productId}/image`, fd, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  uploadTransactionAttachment: (transactionId: number | string, file: File) => {
    const fd = new FormData();
    fd.append('file', file);
    return api.post(`/files/transaction/${transactionId}/attachment`, fd, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  get: (filename: string) => api.get(`/files/${encodeURIComponent(filename)}`),
  remove: (filename: string) =>
    api.delete(`/files/${encodeURIComponent(filename)}`),
};

/**
 * Fetch-style wrapper over axios — used by newer view components.
 * Throws Error with detail message on non-2xx responses.
 */
export async function apiRequest(path: string, options?: RequestInit): Promise<any> {
  const method = (options?.method || 'GET').toUpperCase();
  const body = options?.body as string | undefined;

  try {
    const resp = await api.request({
      url: path,
      method: method as any,
      data: body ? JSON.parse(body) : undefined,
    });
    return resp.data;
  } catch (err: any) {
    const detail = err?.response?.data?.detail || err?.message || 'İstek başarısız';
    throw new Error(typeof detail === 'string' ? detail : JSON.stringify(detail));
  }
}

export default api;
