import { useState, useEffect } from 'react';

/**
 * useLang — returns current lang ('tr' | 'en') and reacts to changes
 * dispatched by App.tsx via window.dispatchEvent(new Event('langchange'))
 */
export function useLang(): 'tr' | 'en' {
  const [lang, setLang] = useState<'tr' | 'en'>(
    () => (localStorage.getItem('lang') as 'tr' | 'en') || 'tr',
  );

  useEffect(() => {
    const handler = () =>
      setLang((localStorage.getItem('lang') as 'tr' | 'en') || 'tr');
    window.addEventListener('langchange', handler);
    return () => window.removeEventListener('langchange', handler);
  }, []);

  return lang;
}

/**
 * makeT — returns a t() function for a given lang and dict.
 * Usage: const t = makeT(lang, DICT);
 */
export function makeT(lang: string, dict: Record<string, string>) {
  return (text: string): string =>
    lang === 'en' ? (dict[text] ?? text) : text;
}
