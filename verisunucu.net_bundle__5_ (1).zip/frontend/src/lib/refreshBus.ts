type Listener = () => void;

const listeners = new Set<Listener>();

// api.ts interceptor bunu okur; true iken loadingStart() atlanır
export let isBackgroundRefresh = false;

export const refreshBus = {
  subscribe(fn: Listener): () => void {
    listeners.add(fn);
    return () => listeners.delete(fn);
  },
  emit(): void {
    isBackgroundRefresh = true;
    listeners.forEach((fn) => fn());
    Promise.resolve().then(() => { isBackgroundRefresh = false; });
  },
};

/**
 * Bileşenlerin kendi periyodik interval'larında kullanılır.
 * İçindeki fonksiyonun tetiklediği tüm API GET istekleri loading bar göstermez.
 */
export function withSilentRefresh(fn: () => void): void {
  isBackgroundRefresh = true;
  fn();
  Promise.resolve().then(() => { isBackgroundRefresh = false; });
}
