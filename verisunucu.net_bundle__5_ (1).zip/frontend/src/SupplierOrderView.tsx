import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Building2, Package, Search, ShoppingCart, Plus, Minus, X,
  ChevronRight, AlertTriangle, CheckCircle, Clock, Truck,
  XCircle, ChevronDown, ChevronUp, ArrowLeft,
  RefreshCw, ShoppingBag
} from 'lucide-react';
import { apiRequest } from './lib/api';
import { useLang, makeT } from './lib/i18n';

const DICT: Record<string, string> = {
  'Toptancı Sipariş Paneli': 'Wholesale Order Panel',
  'Sizi BTB müşterisi olarak ekleyen bayilerden sipariş verin': 'Order from dealers who added you as a B2B customer',
  'Tedarikçiler': 'Suppliers',
  'Siparişlerim': 'My Orders',
  'Henüz tedarikçi yok': 'No suppliers yet',
  'Bir bayi sizi BTB müşterisi olarak eklediğinde burada görünür.': 'Will appear here when a dealer adds you as a B2B customer.',
  'İskonto': 'Discount',
  'Limit': 'Limit',
  'Toplam Sipariş': 'Total Orders',
  'Vade': 'Payment Term',
  'gün': 'days',
  'Sepet': 'Cart',
  'Devam Et': 'Continue',
  'Sipariş Ver': 'Place Order',
  'Pasif': 'Inactive',
  'Ürün ara...': 'Search products...',
  'Tümü': 'All',
  'Stokta ürün yok': 'No products in stock',
  'Bu kategoride ürün yok': 'No products in this category',
  'KDV hariç': 'Excl. VAT',
  'KDV dahil': 'Incl. VAT',
  'Stok': 'Stock',
  'Ekle': 'Add',
  'Ara toplam': 'Subtotal',
  'KDV': 'VAT',
  'Toplam': 'Total',
  'Sepet boş': 'Cart is empty',
  'İskonto yok': 'No discount',
  'Henüz sipariş yok': 'No orders yet',
  'Onay Bekliyor': 'Pending Approval',
  'Taslak': 'Draft',
  'Onaylı': 'Confirmed',
  'Kargoda': 'Shipped',
  'Teslim': 'Delivered',
  'İptal': 'Cancelled',
  'Sipariş tedarikçi bayinin onayını bekliyor.': 'Order is awaiting supplier dealer approval.',
  'Ürün': 'Product',
  'Adet': 'Qty',
  'Birim': 'Unit',
  'Teslimat Adresi': 'Delivery Address',
  'Adres (opsiyonel)': 'Address (optional)',
  'İstenen Teslim Tarihi': 'Requested Delivery Date',
  'Not': 'Note',
  'Siparişle ilgili notlar...': 'Notes about the order...',
  'ürün': 'items',
  'Gönderiliyor...': 'Sending...',
  'Siparişi Onayla': 'Confirm Order',
  'Siparişiniz iletildi, onay bekleniyor': 'Order submitted, awaiting approval',
  'Sipariş gönderilemedi': 'Could not send order',
  'Tedarikçiler yüklenemedi': 'Could not load suppliers',
  'Ürünler yüklenemedi': 'Could not load products',
  'Siparişler yüklenemedi': 'Could not load orders',
  'Yükleniyor...': 'Loading...',
  'Büyük görsel': 'Full image',
  'bekliyor': 'pending',
  'iskonto': 'discount',
};

interface SupplySource {
  btb_customer_id: number;
  bayi_user_id: number;
  bayi_name: string;
  bayi_email: string;
  my_company_name: string;
  discount_rate: number;
  credit_limit: number;
  payment_term_days: number;
  pending_orders: number;
  total_orders: number;
  is_active: boolean;
}

interface Product {
  id: number; name: string; stock: number;
  list_price: number; customer_price: number;
  currency: string; category?: string; kdv_rate: number; barcode?: string;
  image_url?: string;
}

interface CartItem { product: Product; quantity: number; }

interface Order {
  id: number; order_number: string; status: string;
  total_amount: number; currency: string; is_paid: boolean;
  due_date?: string; created_at?: string; supplier_name: string;
  items: { product_name: string; quantity: number; unit_price: number; }[];
}

const STATUS_CFG: Record<string, { label: string; color: string; icon: any }> = {
  pending_approval: { label: 'Onay Bekliyor', color: 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300', icon: AlertTriangle },
  draft:     { label: 'Taslak',  color: 'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300', icon: Clock },
  confirmed: { label: 'Onaylı',  color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300',   icon: CheckCircle },
  shipped:   { label: 'Kargoda', color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300', icon: Truck },
  delivered: { label: 'Teslim',  color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300', icon: CheckCircle },
  cancelled: { label: 'İptal',   color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300',     icon: XCircle },
};

function StatusBadge({ status }: { status: string }) {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const cfg = STATUS_CFG[status] || { label: status, color: 'bg-gray-100 text-gray-700 dark:bg-slate-700 dark:text-slate-300', icon: Clock };
  const Icon = cfg.icon;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${cfg.color}`}>
      <Icon size={11} />{t(cfg.label)}
    </span>
  );
}

const fmt = (n: number) =>
  new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n) + ' ₺';

export default function SupplierOrderView({
  currentUser, showToast,
}: {
  currentUser: any;
  showToast: (msg: string, type?: 'success' | 'error' | 'warning') => void;
}) {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const [view, setView] = useState<'sources' | 'shop' | 'orders'>('sources');
  const [sources, setSources] = useState<SupplySource[]>([]);
  const [selectedSource, setSelectedSource] = useState<SupplySource | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [cart, setCart] = useState<CartItem[]>(() => {
    // Son aktif tedarikçi sepetini geri yükle
    try {
      const activeKey = localStorage.getItem('supply_cart_active_key');
      if (activeKey) {
        const stored = localStorage.getItem(activeKey);
        if (stored) return JSON.parse(stored);
      }
    } catch {}
    return [];
  });
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [checkoutForm, setCheckoutForm] = useState({ notes: '', due_date: '', shipping_address: '' });
  const [submitting, setSubmitting] = useState(false);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedOrder, setExpandedOrder] = useState<number | null>(null);

  // Ref to always have current selectedSource in cart mutation closures
  const sourceRef = useRef<SupplySource | null>(null);
  useEffect(() => { sourceRef.current = selectedSource; }, [selectedSource]);

  const loadSources = useCallback(async () => {
    setLoading(true);
    try {
      const data = await apiRequest('/btb/supply/sources', { method: 'GET' });
      setSources(Array.isArray(data) ? data : []);
    } catch { showToast(t('Tedarikçiler yüklenemedi'), 'error'); }
    finally { setLoading(false); }
  }, [showToast]);

  const loadProducts = useCallback(async (src: SupplySource, q?: string) => {
    try {
      const params = q ? `?q=${encodeURIComponent(q)}` : '';
      const data = await apiRequest(`/btb/supply/${src.btb_customer_id}/products${params}`, { method: 'GET' });
      setProducts(Array.isArray(data) ? data : []);
    } catch { showToast(t('Ürünler yüklenemedi'), 'error'); }
  }, [showToast]);

  const loadOrders = useCallback(async () => {
    try {
      const data = await apiRequest('/btb/supply/orders', { method: 'GET' });
      setOrders(Array.isArray(data) ? data : []);
    } catch { showToast(t('Siparişler yüklenemedi'), 'error'); }
  }, [showToast]);

  useEffect(() => { loadSources(); }, [loadSources]);

  // Synchronous localStorage write — called inside every cart mutation
  const persistCart = (items: CartItem[], src: SupplySource | null = sourceRef.current) => {
    if (!src) return;
    const key = `supply_cart_${src.btb_customer_id}`;
    try {
      if (items.length > 0) {
        localStorage.setItem(key, JSON.stringify(items));
        localStorage.setItem('supply_cart_active_key', key);
      } else {
        localStorage.removeItem(key);
        localStorage.removeItem('supply_cart_active_key');
      }
    } catch {}
  };

  const searchTimer = useRef<any>(null);
  const handleSearch = (val: string) => {
    setSearch(val);
    if (searchTimer.current) clearTimeout(searchTimer.current);
    if (selectedSource) {
      searchTimer.current = setTimeout(() => loadProducts(selectedSource, val), 350);
    }
  };

  const cartCount = cart.reduce((s, i) => s + i.quantity, 0);
  const cartSubtotal = cart.reduce((s, i) => s + i.product.customer_price * i.quantity, 0);
  const cartKdv = cart.reduce((s, i) => s + i.product.customer_price * i.quantity * (i.product.kdv_rate / 100), 0);

  const addToCart = (p: Product) => setCart(prev => {
    const ex = prev.find(i => i.product.id === p.id);
    const next = ex
      ? prev.map(i => i.product.id === p.id ? { ...i, quantity: i.quantity + 1 } : i)
      : [...prev, { product: p, quantity: 1 }];
    persistCart(next);
    return next;
  });

  const updateQty = (id: number, delta: number) => setCart(prev => {
    const next = prev.map(i => i.product.id === id ? { ...i, quantity: i.quantity + delta } : i).filter(i => i.quantity > 0);
    persistCart(next);
    return next;
  });

  const removeFromCart = (id: number) => setCart(prev => {
    const next = prev.filter(i => i.product.id !== id);
    persistCart(next);
    return next;
  });

  // Ürünlerden unique kategorileri çıkar
  const categories = Array.from(new Set(products.map(p => p.category).filter(Boolean))) as string[];

  // Kategori + arama filtresi (client-side)
  const filteredProducts = products.filter(p => {
    const matchCat = !selectedCategory || p.category === selectedCategory;
    const matchQ = !search || p.name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchQ;
  });

  const openSource = (src: SupplySource) => {
    sourceRef.current = src;
    setSelectedSource(src);
    // Bu tedarikçiye ait kayıtlı sepeti yükle
    try {
      const saved = localStorage.getItem(`supply_cart_${src.btb_customer_id}`);
      setCart(saved ? JSON.parse(saved) : []);
    } catch {
      setCart([]);
    }
    setSearch('');
    setSelectedCategory('');
    setView('shop');
    loadProducts(src);
  };

  const handleCheckout = async () => {
    if (!selectedSource || cart.length === 0) return;
    setSubmitting(true);
    try {
      await apiRequest(`/btb/supply/${selectedSource.btb_customer_id}/checkout`, {
        method: 'POST',
        body: JSON.stringify({
          items: cart.map(i => ({ product_id: i.product.id, quantity: i.quantity })),
          notes: checkoutForm.notes,
          due_date: checkoutForm.due_date || undefined,
          shipping_address: checkoutForm.shipping_address,
        }),
      });
      showToast(t('Siparişiniz iletildi, onay bekleniyor'), 'success');
      // Sepeti temizle + localStorage'dan kaldır
      persistCart([], sourceRef.current);
      setCart([]);
      setCheckoutOpen(false);
      setCartOpen(false);
      setView('orders');
      loadOrders();
    } catch (e: any) {
      showToast(e?.message || t('Sipariş gönderilemedi'), 'error');
    } finally { setSubmitting(false); }
  };

  // ─── SOURCES VIEW ────────────────────────────────────────────
  if (loading) return <div className="py-16 text-center text-gray-400 dark:text-slate-500">{t('Yükleniyor...')}</div>;

  return (
    <div className="space-y-5">
      {/* Header tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-slate-100">{t('Toptancı Sipariş Paneli')}</h2>
          <p className="text-sm text-gray-500 dark:text-slate-400 mt-0.5">{t('Sizi BTB müşterisi olarak ekleyen bayilerden sipariş verin')}</p>
        </div>
        <div className="flex gap-1 bg-gray-100 dark:bg-slate-700 rounded-xl p-1 w-fit">
          <button onClick={() => { setView('sources'); loadSources(); }}
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition ${view === 'sources' || view === 'shop' ? 'bg-white dark:bg-slate-800 text-indigo-700 shadow-sm' : 'text-gray-600 dark:text-slate-400 hover:text-gray-900 dark:hover:text-slate-100'}`}>
            {t('Tedarikçiler')} ({sources.length})
          </button>
          <button onClick={() => { setView('orders'); loadOrders(); }}
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition ${view === 'orders' ? 'bg-white dark:bg-slate-800 text-indigo-700 shadow-sm' : 'text-gray-600 dark:text-slate-400 hover:text-gray-900 dark:hover:text-slate-100'}`}>
            {t('Siparişlerim')} ({orders.length})
          </button>
        </div>
      </div>

      {/* SOURCES LIST */}
      {view === 'sources' && (
        <>
          {sources.length === 0 ? (
            <div className="bg-white dark:bg-slate-800 rounded-2xl border border-dashed border-gray-300 dark:border-slate-600 py-16 text-center">
              <Building2 size={40} className="mx-auto mb-3 text-gray-300 dark:text-slate-600" />
              <p className="font-medium text-gray-500 dark:text-slate-400">{t('Henüz tedarikçi yok')}</p>
              <p className="text-sm text-gray-400 dark:text-slate-500 mt-1">
                {t('Bir bayi sizi BTB müşterisi olarak eklediğinde burada görünür.')}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {sources.map(src => (
                <div key={src.btb_customer_id}
                  className={`bg-white dark:bg-slate-800 rounded-2xl border-2 p-5 transition hover:shadow-md cursor-pointer ${src.is_active ? 'border-gray-200 dark:border-slate-700 hover:border-indigo-300' : 'border-gray-100 dark:border-slate-700/50 opacity-60'}`}
                  onClick={() => src.is_active && openSource(src)}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-bold text-gray-900 dark:text-slate-100">{src.bayi_name}</h3>
                      <p className="text-xs text-gray-500 dark:text-slate-400">{src.bayi_email}</p>
                    </div>
                    {src.pending_orders > 0 && (
                      <span className="shrink-0 bg-orange-100 text-orange-700 text-xs font-bold px-2 py-0.5 rounded-full">
                        {src.pending_orders} {t('bekliyor')}
                      </span>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs text-gray-500 dark:text-slate-400 mb-4">
                    {src.discount_rate > 0 && (
                      <div><p className="text-[10px]">{t('İskonto')}</p><p className="font-bold text-emerald-600">%{src.discount_rate}</p></div>
                    )}
                    {src.credit_limit > 0 && (
                      <div><p className="text-[10px]">{t('Limit')}</p><p className="font-bold">{fmt(src.credit_limit)}</p></div>
                    )}
                    <div><p className="text-[10px]">{t('Toplam Sipariş')}</p><p className="font-bold">{src.total_orders}</p></div>
                    <div><p className="text-[10px]">{t('Vade')}</p><p className="font-bold">{src.payment_term_days} {t('gün')}</p></div>
                  </div>
                  {(() => {
                    let savedCount = 0;
                    try {
                      const s = localStorage.getItem(`supply_cart_${src.btb_customer_id}`);
                      if (s) savedCount = (JSON.parse(s) as CartItem[]).reduce((n, i) => n + i.quantity, 0);
                    } catch {}
                    return src.is_active ? (
                      <button className="w-full py-2 bg-indigo-600 text-white text-sm font-bold rounded-xl hover:bg-indigo-700 flex items-center justify-center gap-1">
                        {savedCount > 0
                          ? <><ShoppingCart size={14} /> {t('Sepet')} ({savedCount}) — {t('Devam Et')}</>
                          : <>{t('Sipariş Ver')} <ChevronRight size={15} /></>}
                      </button>
                    ) : (
                      <div className="w-full py-2 bg-gray-100 dark:bg-slate-700 text-gray-400 dark:text-slate-500 text-sm text-center rounded-xl">{t('Pasif')}</div>
                    );
                  })()}
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* SHOP VIEW */}
      {view === 'shop' && selectedSource && (
        <div>
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 mb-4">
            <button onClick={() => setView('sources')} className="flex items-center gap-1 text-sm text-indigo-600 hover:text-indigo-800 font-medium">
              <ArrowLeft size={15} /> {t('Tedarikçiler')}
            </button>
            <span className="text-gray-300 dark:text-slate-600">/</span>
            <span className="text-sm font-medium text-gray-700 dark:text-slate-300">{selectedSource.bayi_name}</span>
            {selectedSource.discount_rate > 0 && (
              <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-medium">%{selectedSource.discount_rate} {t('iskonto')}</span>
            )}
          </div>

          {/* Search + Cart button */}
          <div className="flex gap-3 mb-3">
            <div className="relative flex-1">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-slate-500" />
              <input
                type="text"
                placeholder={t('Ürün ara...')}
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 bg-white dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100"
              />
            </div>
            <button onClick={() => loadProducts(selectedSource)} className="p-2.5 border border-gray-200 dark:border-slate-600 rounded-xl bg-white dark:bg-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700 text-gray-500 dark:text-slate-400">
              <RefreshCw size={15} />
            </button>
            <button onClick={() => setCartOpen(true)}
              className="relative px-4 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 flex items-center gap-2 text-sm font-bold">
              <ShoppingCart size={16} /> {cartCount > 0 ? `${t('Sepet')} (${cartCount})` : t('Sepet')}
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
          </div>

          {/* Kategori pilleri */}
          {categories.length > 0 && (
            <div className="flex gap-2 flex-wrap mb-4">
              <button
                onClick={() => setSelectedCategory('')}
                className={`px-3 py-1 rounded-full text-xs font-medium transition ${!selectedCategory ? 'bg-indigo-600 text-white' : 'bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-slate-400 hover:bg-gray-200 dark:hover:bg-slate-600'}`}
              >{t('Tümü')} ({products.length})</button>
              {categories.map(cat => (
                <button key={cat}
                  onClick={() => setSelectedCategory(cat === selectedCategory ? '' : cat)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition ${selectedCategory === cat ? 'bg-indigo-600 text-white' : 'bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-slate-400 hover:bg-gray-200 dark:hover:bg-slate-600'}`}
                >
                  {cat} ({products.filter(p => p.category === cat).length})
                </button>
              ))}
            </div>
          )}

          {filteredProducts.length === 0 ? (
            <div className="py-16 text-center text-gray-400 dark:text-slate-500">
              <Package size={40} className="mx-auto mb-3 opacity-30" />
              <p className="text-sm">{products.length === 0 ? t('Stokta ürün yok') : t('Bu kategoride ürün yok')}</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {filteredProducts.map(p => {
                const cartItem = cart.find(i => i.product.id === p.id);
                const qty = cartItem?.quantity || 0;
                return (
                  <div key={p.id} className="bg-white dark:bg-slate-800 rounded-2xl border border-gray-200 dark:border-slate-700 overflow-hidden hover:shadow-md transition-shadow">
                    {/* Ürün görseli */}
                    {p.image_url ? (
                      <div className="relative cursor-zoom-in" onClick={() => setZoomedImage(p.image_url!)}>
                        <img src={p.image_url} alt={p.name}
                          className="w-full h-32 object-cover bg-gray-50 dark:bg-slate-700/50 hover:opacity-90 transition-opacity" />
                        {p.category && (
                          <span className="absolute top-2 left-2 text-[10px] bg-white/90 dark:bg-slate-800/90 text-gray-600 dark:text-slate-400 px-2 py-0.5 rounded-full shadow-sm">{p.category}</span>
                        )}
                        {p.customer_price < p.list_price && (
                          <span className="absolute top-2 right-2 text-[10px] bg-red-500 text-white px-2 py-0.5 rounded-full font-bold">
                            -%{Math.round((1 - p.customer_price / p.list_price) * 100)}
                          </span>
                        )}
                      </div>
                    ) : (
                      <div className="relative h-28 bg-gray-50 dark:bg-slate-700/50 flex items-center justify-center">
                        <Package size={32} className="text-gray-200 dark:text-slate-600" />
                        {p.category && (
                          <span className="absolute top-2 left-2 text-[10px] bg-white dark:bg-slate-800 text-gray-500 dark:text-slate-400 px-2 py-0.5 rounded-full border border-gray-100 dark:border-slate-700/50">{p.category}</span>
                        )}
                        {p.customer_price < p.list_price && (
                          <span className="absolute top-2 right-2 text-[10px] bg-red-500 text-white px-2 py-0.5 rounded-full font-bold">
                            -%{Math.round((1 - p.customer_price / p.list_price) * 100)}
                          </span>
                        )}
                      </div>
                    )}
                    <div className="p-3">
                      <h3 className="font-medium text-gray-900 dark:text-slate-100 text-sm leading-tight mb-2 line-clamp-2">{p.name}</h3>
                      {p.barcode && <p className="text-[10px] text-gray-400 dark:text-slate-500 mb-1">{p.barcode}</p>}
                      <div className="flex items-end justify-between mb-3">
                        <div>
                          <p className="text-[10px] text-gray-400 dark:text-slate-500">{t('KDV hariç')}</p>
                          <p className="text-base font-bold text-indigo-700">{fmt(p.customer_price)}</p>
                          {p.customer_price < p.list_price && (
                            <p className="text-xs text-gray-400 dark:text-slate-500 line-through">{fmt(p.list_price)}</p>
                          )}
                          <p className="text-[10px] text-gray-400 dark:text-slate-500 mt-1">{t('KDV dahil')} (%{p.kdv_rate ?? 18})</p>
                          <p className="text-sm font-semibold text-emerald-600">{fmt(p.customer_price * (1 + (p.kdv_rate ?? 18) / 100))}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-[10px] text-gray-400 dark:text-slate-500">{t('Stok')}</p>
                          <span className={`text-xs font-medium ${p.stock < 5 ? 'text-red-600' : 'text-emerald-600'}`}>{p.stock}</span>
                        </div>
                      </div>
                      {qty === 0 ? (
                        <button onClick={() => addToCart(p)}
                          className="w-full py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-700 flex items-center justify-center gap-1">
                          <Plus size={13} /> {t('Ekle')}
                        </button>
                      ) : (
                        <div className="flex items-center justify-between bg-indigo-50 dark:bg-indigo-900/30 rounded-xl px-2 py-1">
                          <button onClick={() => updateQty(p.id, -1)} className="w-7 h-7 rounded-lg bg-white dark:bg-slate-700 border border-indigo-200 dark:border-indigo-700 flex items-center justify-center hover:bg-indigo-100 dark:hover:bg-indigo-900/30">
                            <Minus size={12} />
                          </button>
                          <span className="font-bold text-indigo-700 text-sm">{qty}</span>
                          <button onClick={() => updateQty(p.id, 1)} disabled={qty >= p.stock}
                            className="w-7 h-7 rounded-lg bg-white dark:bg-slate-700 border border-indigo-200 dark:border-indigo-700 flex items-center justify-center hover:bg-indigo-100 dark:hover:bg-indigo-900/30 disabled:opacity-40">
                            <Plus size={12} />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ORDERS VIEW */}
      {view === 'orders' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-gray-800 dark:text-slate-200">{t('Siparişlerim')}</h3>
            <button onClick={loadOrders} className="p-2 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700"><RefreshCw size={15} /></button>
          </div>
          {orders.length === 0 ? (
            <div className="py-16 text-center text-gray-400 dark:text-slate-500">
              <ShoppingBag size={40} className="mx-auto mb-3 opacity-30" />
              <p className="text-sm">{t('Henüz sipariş yok')}</p>
            </div>
          ) : (
            orders.map(o => (
              <div key={o.id} className="bg-white dark:bg-slate-800 rounded-2xl border border-gray-200 dark:border-slate-700">
                <div className="p-4 flex items-center gap-3 cursor-pointer" onClick={() => setExpandedOrder(expandedOrder === o.id ? null : o.id)}>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-slate-300 px-2 py-0.5 rounded">{o.order_number}</span>
                      <StatusBadge status={o.status} />
                      <span className="text-xs text-gray-500 dark:text-slate-400">← {o.supplier_name}</span>
                    </div>
                    <p className="text-xs text-gray-400 dark:text-slate-500 mt-0.5">{o.created_at ? new Date(o.created_at).toLocaleDateString('tr-TR') : '—'}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="font-bold text-gray-900 dark:text-slate-100">{fmt(o.total_amount)}</p>
                    {expandedOrder === o.id ? <ChevronUp size={15} className="text-gray-400 dark:text-slate-500 mx-auto mt-1" /> : <ChevronDown size={15} className="text-gray-400 dark:text-slate-500 mx-auto mt-1" />}
                  </div>
                </div>
                {expandedOrder === o.id && (
                  <div className="border-t border-gray-100 dark:border-slate-700/50 px-4 pb-4 pt-3">
                    {o.status === 'pending_approval' && (
                      <div className="mb-3 bg-orange-50 dark:bg-orange-900/30 border border-orange-200 rounded-xl p-3 text-xs text-orange-800 dark:text-orange-300 flex items-center gap-2">
                        <AlertTriangle size={13} /> {t('Sipariş tedarikçi bayinin onayını bekliyor.')}
                      </div>
                    )}
                    <table className="w-full text-xs">
                      <thead><tr className="text-gray-400 dark:text-slate-500 border-b dark:border-slate-700"><th className="text-left pb-1">{t('Ürün')}</th><th className="text-right pb-1">{t('Adet')}</th><th className="text-right pb-1">{t('Birim')}</th></tr></thead>
                      <tbody>
                        {o.items.map((item, idx) => (
                          <tr key={idx} className="border-b border-gray-50 dark:border-slate-700/50">
                            <td className="py-1.5 text-gray-700 dark:text-slate-300">{item.product_name}</td>
                            <td className="py-1.5 text-right">{item.quantity}</td>
                            <td className="py-1.5 text-right">{fmt(item.unit_price)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    <div className="mt-2 text-right font-bold text-gray-900 dark:text-slate-100">{fmt(o.total_amount)}</div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {/* Cart Sidebar */}
      {cartOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div className="flex-1 bg-black/40" onClick={() => setCartOpen(false)} />
          <div className="w-full max-w-sm bg-white dark:bg-slate-800 h-full flex flex-col shadow-2xl">
            <div className="flex items-center justify-between px-5 py-4 border-b dark:border-slate-700">
              <h2 className="font-bold text-gray-900 dark:text-slate-100 flex items-center gap-2"><ShoppingCart size={18} /> {t('Sepet')} ({cartCount})</h2>
              <button onClick={() => setCartOpen(false)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700"><X size={18} /></button>
            </div>
            <div className="px-2 py-1 bg-indigo-50 dark:bg-indigo-900/30 text-xs text-indigo-700 dark:text-indigo-300 text-center font-medium">
              {selectedSource?.bayi_name} — {selectedSource?.discount_rate > 0 ? `%${selectedSource.discount_rate} ${t('iskonto')}` : t('İskonto yok')}
            </div>
            <div className="flex-1 overflow-y-auto px-5 py-3 space-y-3">
              {cart.length === 0 ? (
                <p className="text-gray-400 dark:text-slate-500 text-sm text-center py-8">{t('Sepet boş')}</p>
              ) : (
                cart.map(item => (
                  <div key={item.product.id} className="flex items-center gap-3 bg-gray-50 dark:bg-slate-700/50 rounded-xl p-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 dark:text-slate-200 leading-tight line-clamp-2">{item.product.name}</p>
                      <p className="text-xs text-indigo-600 font-bold mt-0.5">{fmt(item.product.customer_price)}</p>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button onClick={() => updateQty(item.product.id, -1)} className="w-7 h-7 rounded-lg border border-gray-200 dark:border-slate-600 bg-white dark:bg-slate-700 flex items-center justify-center"><Minus size={12} /></button>
                      <span className="w-7 text-center text-sm font-bold dark:text-slate-100">{item.quantity}</span>
                      <button onClick={() => updateQty(item.product.id, 1)} disabled={item.quantity >= item.product.stock} className="w-7 h-7 rounded-lg border border-gray-200 dark:border-slate-600 bg-white dark:bg-slate-700 flex items-center justify-center disabled:opacity-40"><Plus size={12} /></button>
                      <button onClick={() => removeFromCart(item.product.id)} className="ml-1 text-gray-300 dark:text-slate-600 hover:text-red-500"><X size={14} /></button>
                    </div>
                  </div>
                ))
              )}
            </div>
            {cart.length > 0 && (
              <div className="border-t dark:border-slate-700 px-5 py-4 space-y-3">
                <div className="flex justify-between text-sm"><span className="text-gray-600 dark:text-slate-400">{t('Ara toplam')}</span><span className="dark:text-slate-200">{fmt(cartSubtotal)}</span></div>
                <div className="flex justify-between text-sm"><span className="text-gray-600 dark:text-slate-400">{t('KDV')}</span><span className="dark:text-slate-200">{fmt(cartKdv)}</span></div>
                <div className="flex justify-between font-bold"><span className="dark:text-slate-100">{t('Toplam')}</span><span className="text-indigo-700 dark:text-indigo-400 text-lg">{fmt(cartSubtotal + cartKdv)}</span></div>
                <button onClick={() => { setCartOpen(false); setCheckoutOpen(true); }}
                  className="w-full py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 flex items-center justify-center gap-2">
                  {t('Sipariş Ver')} <ChevronRight size={16} />
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Checkout Modal */}
      {checkoutOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white dark:bg-slate-800 rounded-2xl w-full max-w-md shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b dark:border-slate-700">
              <div>
                <h2 className="font-bold text-gray-900 dark:text-slate-100">{t('Sipariş Ver')}</h2>
                <p className="text-xs text-gray-500 dark:text-slate-400">{selectedSource?.bayi_name}</p>
              </div>
              <button onClick={() => setCheckoutOpen(false)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700"><X size={18} /></button>
            </div>
            <div className="px-6 py-5 space-y-4">
              <div className="bg-orange-50 dark:bg-orange-900/30 border border-orange-200 rounded-xl p-3 text-xs text-orange-800 dark:text-orange-300 flex items-start gap-2">
                <AlertTriangle size={13} className="mt-0.5 shrink-0" />
                {lang === 'en'
                  ? `Order will be sent to ${selectedSource?.bayi_name} and prepared after confirmation.`
                  : `Sipariş ${selectedSource?.bayi_name}'e iletilecek. Onayladıktan sonra hazırlanacak.`}
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1">{t('Teslimat Adresi')}</label>
                <input type="text" placeholder={t('Adres (opsiyonel)')}
                  value={checkoutForm.shipping_address}
                  onChange={e => setCheckoutForm(f => ({ ...f, shipping_address: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1">{t('İstenen Teslim Tarihi')}</label>
                <input type="date" value={checkoutForm.due_date}
                  onChange={e => setCheckoutForm(f => ({ ...f, due_date: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1">{t('Not')}</label>
                <textarea rows={2} placeholder={t('Siparişle ilgili notlar...')}
                  value={checkoutForm.notes}
                  onChange={e => setCheckoutForm(f => ({ ...f, notes: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 resize-none dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
              </div>
              <div className="bg-gray-50 dark:bg-slate-700/50 rounded-xl p-3">
                <div className="flex justify-between text-sm mb-1"><span className="text-gray-600 dark:text-slate-400">{cartCount} {t('ürün')}</span><span className="dark:text-slate-200">{fmt(cartSubtotal)}</span></div>
                <div className="flex justify-between text-sm mb-1"><span className="text-gray-600 dark:text-slate-400">{t('KDV')}</span><span className="dark:text-slate-200">{fmt(cartKdv)}</span></div>
                <div className="flex justify-between font-bold text-base pt-1 border-t border-gray-200 dark:border-slate-600">
                  <span className="dark:text-slate-100">{t('Toplam')}</span><span className="text-indigo-700 dark:text-indigo-400">{fmt(cartSubtotal + cartKdv)}</span>
                </div>
              </div>
              <button onClick={handleCheckout} disabled={submitting}
                className="w-full py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 disabled:opacity-50">
                {submitting ? t('Gönderiliyor...') : t('Siparişi Onayla')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Görsel Zoom Overlay */}
      {zoomedImage && (
        <div
          className="fixed inset-0 z-[60] bg-black/85 flex items-center justify-center p-4 cursor-zoom-out"
          onClick={() => setZoomedImage(null)}
        >
          <img
            src={zoomedImage}
            alt={t('Büyük görsel')}
            className="max-w-full max-h-[90vh] rounded-2xl shadow-2xl object-contain"
            onClick={e => e.stopPropagation()}
          />
          <button
            onClick={() => setZoomedImage(null)}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/20 hover:bg-white/40 flex items-center justify-center text-white transition"
          >
            <X size={20} />
          </button>
        </div>
      )}
    </div>
  );
}
