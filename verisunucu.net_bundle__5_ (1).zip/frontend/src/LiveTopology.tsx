import React, { useCallback, useEffect, useRef, useState } from 'react';
import api from './lib/api';
import { Camera, RefreshCw, ChevronDown, ChevronUp, Wifi, WifiOff, Maximize2, Minimize2 } from 'lucide-react';

// ── Types ──────────────────────────────────────────────────────────────────
interface NodeDef {
  id: string; x: number; y: number; label: string; sublabel?: string;
  type: 'internet' | 'nginx' | 'backend' | 'database' | 'storage' | 'external' | 'device';
  color: string;
}
interface NodeStatus {
  status: 'ok' | 'warn' | 'error' | 'unknown';
  label?: string; latency_ms?: number; load?: number;
  ram_pct?: number; disk_pct?: number; last_error?: string;
  online?: number; total?: number;
}
interface TopoEvent {
  id: number; event_type: string; from_node: string; to_node?: string;
  message: string; created_at: string;
}
interface Particle { id: number; fromId: string; toId: string; progress: number; color: string; speed: number; size: number; }
interface ActiveEdge { key: string; color: string; until: number; }

interface DeviceDef {
  device_id: string; type: string; variant: string;
  online: boolean; last_seen: string | null; firmware: string; ip: string;
}
interface TenantDef {
  id: number; name: string; company: string; email: string; package: string;
  device_total: number; device_online: number; worker_count: number;
  sub_days: number;
  devices: DeviceDef[];
}
interface ActiveUser {
  user_id: number; email: string; name: string;
  endpoint: string; method: string; role: string;
  seconds_ago: number; tenant_id?: number;
}

// Background API call config — loading bar'ı gizler, polling isteklerinde kullanılır
const BG = { _noBar: true } as any;

// ── Static infra layout (SVG viewport 800×520) ────────────────────────────
// Katmanlı sol→sağ yerleşim (1100x650 SVG)
// L1 x=90: Kullanıcılar + IoT  |  L2 x=270: Bayiler
// L3 x=470: Gateway (İnternet+Nginx)  |  L4 x=670: Backend  |  L5 x=880: Veri&Depolama
const NODE_DEFS: NodeDef[] = [
  { id: 'internet',   x: 470, y: 195, label: 'İnternet',    type: 'internet',  color: '#94a3b8' },
  { id: 'nginx',      x: 470, y: 395, label: 'Nginx',        type: 'nginx',     color: '#06b6d4' },
  { id: 'devices',    x: 90,  y: 555, label: 'IoT Cihazlar',sublabel:'ESP32',  type: 'device',   color: '#f97316' },
  { id: 'backend-s1', x: 670, y: 275, label: 'FastAPI S1',  sublabel:'Ana',    type: 'backend',  color: '#8b5cf6' },
  { id: 'backend-s2', x: 670, y: 465, label: 'FastAPI S2',  sublabel:'Yedek',  type: 'backend',  color: '#8b5cf6' },
  { id: 'postgres',   x: 880, y: 175, label: 'PostgreSQL',  type: 'database',  color: '#3b82f6' },
  { id: 'minio-s1',   x: 880, y: 295, label: 'MinIO S1',    type: 'storage',   color: '#10b981' },
  { id: 'minio-s2',   x: 880, y: 400, label: 'MinIO S2',    type: 'storage',   color: '#10b981' },
  { id: 'sftp',       x: 880, y: 495, label: 'SFTP/FTP',    type: 'storage',   color: '#f59e0b' },
  { id: 's3-ext',     x: 880, y: 585, label: 'Harici S3',   sublabel:'S3',     type: 'external', color: '#f97316' },
];

const EDGES: Array<{ from: string; to: string; reverse?: boolean }> = [
  { from: 'internet',   to: 'nginx' },
  { from: 'devices',    to: 'nginx' },
  { from: 'nginx',      to: 'backend-s1' },
  { from: 'nginx',      to: 'backend-s2' },
  { from: 'backend-s1', to: 'backend-s2', reverse: true },
  { from: 'backend-s1', to: 'postgres' },
  { from: 'backend-s2', to: 'postgres' },
  { from: 'backend-s1', to: 'minio-s1' },
  { from: 'backend-s2', to: 'minio-s2' },
  { from: 'minio-s1',   to: 'minio-s2', reverse: true },
  { from: 'minio-s1',   to: 'sftp' },
  { from: 'minio-s1',   to: 's3-ext' },
  { from: 'minio-s2',   to: 's3-ext' },
];

const EVENT_CFG: Record<string, { color: string; emoji: string; label: string }> = {
  upload:    { color: '#22c55e', emoji: '🟢', label: 'Yükleme' },
  download:  { color: '#3b82f6', emoji: '🔵', label: 'İndirme' },
  replicate: { color: '#f97316', emoji: '🟠', label: 'Replika' },
  backup:    { color: '#eab308', emoji: '🟡', label: 'Yedek' },
  delete:    { color: '#ef4444', emoji: '🔴', label: 'Silme' },
  health:    { color: '#a855f7', emoji: '🟣', label: 'Sağlık' },
  error:     { color: '#ef4444', emoji: '💀', label: 'Hata' },
};
const TYPE_ICON: Record<string, string> = {
  internet: '🌐', nginx: '⚡', backend: '🚀', database: '🗄️', storage: '💾', external: '☁️', device: '📡',
};
const PACKAGE_COLOR: Record<string, string> = {
  starter: '#64748b', basic: '#3b82f6', pro: '#8b5cf6', enterprise: '#f97316', default: '#94a3b8',
};
const METHOD_COLOR: Record<string, string> = {
  GET: '#3b82f6', POST: '#22c55e', PUT: '#f59e0b', PATCH: '#f97316', DELETE: '#ef4444',
};
const ROLE_INFO: Record<string, { label: string; color: string }> = {
  bayi_sahibi: { label: 'Patron',     color: '#8b5cf6' },
  calisan:     { label: 'Personel',   color: '#3b82f6' },
  super_admin: { label: 'SüperAdmin', color: '#f97316' },
};

const nodeMap = Object.fromEntries(NODE_DEFS.map(n => [n.id, n]));
let _pid = 0;

// ── Bezier helpers ─────────────────────────────────────────────────────────
function ctrlPt(a: NodeDef, b: NodeDef) {
  return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 - 24 };
}
function bezierPoint(t: number, a: NodeDef, b: NodeDef) {
  const c = ctrlPt(a, b), mt = 1 - t;
  return { x: mt*mt*a.x + 2*mt*t*c.x + t*t*b.x, y: mt*mt*a.y + 2*mt*t*c.y + t*t*b.y };
}
function svgPath(a: NodeDef, b: NodeDef) {
  const dx = Math.abs(b.x - a.x), dy = Math.abs(b.y - a.y);
  if (dx > dy * 0.8) {
    // Yatay baskın: S-eğrisi (sol→sağ akış)
    const mx = (a.x + b.x) / 2;
    return `M ${a.x} ${a.y} C ${mx} ${a.y}, ${mx} ${b.y}, ${b.x} ${b.y}`;
  }
  // Dikey baskın: quadratic bezier
  const c = ctrlPt(a, b);
  return `M ${a.x} ${a.y} Q ${c.x} ${c.y} ${b.x} ${b.y}`;
}

// ── Cluster orbital math ───────────────────────────────────────────────────
function orbitalPos(idx: number, total: number, cx: number, cy: number, r: number) {
  const angle = (2 * Math.PI * idx / Math.max(total, 1)) - Math.PI / 2;
  return { x: cx + r * Math.cos(angle), y: cy + r * Math.sin(angle) };
}
function devicePos(idx: number, total: number, tx: number, ty: number) {
  const angle = 2 * Math.PI * idx / Math.max(total, 1);
  return { x: tx + 34 * Math.cos(angle), y: ty + 34 * Math.sin(angle) };
}

// ── Endpoint → infrastructure target ──────────────────────────────────────
function endpointToTarget(endpoint: string): { icon: string; label: string; color: string } {
  const e = endpoint.toLowerCase();
  if (e.includes('/file'))                            return { icon: '💾', label: 'MinIO',   color: '#10b981' };
  if (e.includes('/backup') || e.includes('/sftp'))  return { icon: '💿', label: 'SFTP',    color: '#f59e0b' };
  if (e.includes('/camera'))                          return { icon: '📡', label: 'Kamera',  color: '#f97316' };
  if (e.includes('/sync'))                            return { icon: '🔄', label: 'Sync',    color: '#f97316' };
  if (e.includes('/auth') || e.includes('/login'))   return { icon: '🔐', label: 'Auth',    color: '#a855f7' };
  if (e.includes('/warrant'))                         return { icon: '📋', label: 'Garanti', color: '#06b6d4' };
  if (e.includes('/report') || e.includes('/dashb')) return { icon: '📊', label: 'Rapor',   color: '#3b82f6' };
  if (e.includes('/product'))                         return { icon: '📦', label: 'Ürün',    color: '#f97316' };
  if (e.includes('/categor'))                         return { icon: '🗂️', label: 'Kategori',color: '#06b6d4' };
  if (e.includes('/finance') || e.includes('/transact')) return { icon: '💳', label: 'Finans', color: '#22c55e' };
  return { icon: '🗄️', label: 'DB', color: '#3b82f6' };
}

// ── Filter + context menu ──────────────────────────────────────────────────
type FilterType = 'all' | 'backend' | 'database' | 'storage' | 'external';
const FILTERS: Array<{ id: FilterType; label: string; types: NodeDef['type'][] }> = [
  { id: 'all',      label: 'Tümü',       types: [] },
  { id: 'backend',  label: 'Sunucular',  types: ['backend', 'nginx', 'internet', 'device'] },
  { id: 'database', label: 'Veritabanı', types: ['database'] },
  { id: 'storage',  label: 'Depolama',   types: ['storage'] },
  { id: 'external', label: 'Dış',        types: ['external'] },
];
const CONTEXT_ITEMS: Record<string, Array<{ label: string; tab: string }>> = {
  devices:     [{ label: 'Cihaz Yönetimi ▸', tab: 'devices' }],
  'minio-s1':  [{ label: 'Depolama Havuzu ▸', tab: 'storage' }],
  'minio-s2':  [{ label: 'Depolama Havuzu ▸', tab: 'storage' }],
  sftp:        [{ label: 'Depolama Havuzu ▸', tab: 'storage' }, { label: 'FTP/SFTP ▸', tab: 'ftp' }],
  's3-ext':    [{ label: 'Depolama Havuzu ▸', tab: 'storage' }],
  'backend-s1':[{ label: 'Eşleşme ▸', tab: 'sync' }, { label: 'Sistem Yedeği ▸', tab: 'system' }],
  'backend-s2':[{ label: 'Eşleşme ▸', tab: 'sync' }],
  postgres:    [{ label: 'Sistem Yedeği ▸', tab: 'system' }],
  nginx:       [{ label: 'Güvenlik ▸', tab: 'security' }],
};

// ═════════════════════════════════════════════════════════════════════════════
// ClusterOrbit
// ═════════════════════════════════════════════════════════════════════════════
const S1 = { x: 250, y: 205 };
const S2 = { x: 750, y: 205 };
const CR1 = 150;
const CR2 = 110;
const MAX_VIS = 8;
const USER_ANGLES = [-Math.PI / 2, Math.PI * 7 / 6, -Math.PI / 6];
const USER_R = 55;

function ClusterOrbit({
  tenants, statuses, activeUsers, selectedTenant, onSelectTenant,
}: {
  tenants: TenantDef[];
  statuses: Record<string, NodeStatus>;
  activeUsers: ActiveUser[];
  selectedTenant: number | null;
  onSelectTenant: (id: number | null) => void;
}) {
  const [hoveredTenant, setHoveredTenant] = useState<number | null>(null);
  const visible = tenants.slice(0, MAX_VIS);
  const extra   = tenants.length - MAX_VIS;
  const s1st    = statuses['backend-s1'];
  const s2st    = statuses['backend-s2'];

  return (
    <svg viewBox="0 0 1000 415" preserveAspectRatio="xMidYMid meet" className="w-full" style={{ height: 370 }}>
      <defs>
        <style>{`
          @keyframes orb { 0%,100%{opacity:.12} 50%{opacity:.3} }
          @keyframes cdash { to { stroke-dashoffset: -20; } }
          .orb-ring { animation: orb 3s ease-in-out infinite; }
          .c-flow { animation: cdash 1.2s linear infinite; }
          .c-rev  { animation: cdash 1.2s linear infinite reverse; }
        `}</style>
        <radialGradient id="g1" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#8b5cf6" stopOpacity=".35"/>
          <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0"/>
        </radialGradient>
        <radialGradient id="g2" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#8b5cf6" stopOpacity=".2"/>
          <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0"/>
        </radialGradient>
      </defs>

      <rect width="1000" height="415" fill="#020617" rx="16"/>
      {Array.from({length:10},(_,i)=>Array.from({length:4},(_,j)=>(
        <circle key={`${i}-${j}`} cx={i*110+10} cy={j*105+15} r={1} fill="#1e293b"/>
      )))}

      <circle cx={S1.x} cy={S1.y} r={CR1+42} fill="url(#g1)"/>
      <circle cx={S2.x} cy={S2.y} r={CR2+30} fill="url(#g2)"/>

      <circle cx={S1.x} cy={S1.y} r={CR1} fill="none" stroke="#8b5cf6" strokeWidth={.8} strokeDasharray="4 10" className="orb-ring"/>
      <circle cx={S2.x} cy={S2.y} r={CR2} fill="none" stroke="#8b5cf6" strokeWidth={.6} strokeDasharray="3 8" className="orb-ring" style={{opacity:.6}}/>

      {/* User orbit rings (only for tenants that have active users) */}
      {visible.map((t, i) => {
        const p  = orbitalPos(i, visible.length, S1.x, S1.y, CR1);
        const tu = activeUsers.filter(u => u.tenant_id === t.id);
        if (tu.length === 0) return null;
        return <circle key={`ur-${t.id}`} cx={p.x} cy={p.y} r={USER_R} fill="none"
          stroke="#1d4ed8" strokeWidth={.5} strokeDasharray="3 7" opacity={.5}/>;
      })}

      {/* S1 ↔ S2 sync link */}
      <path d={`M ${S1.x} ${S1.y} Q 500 115 ${S2.x} ${S2.y}`}
        fill="none" stroke="#f97316" strokeWidth={1.5} strokeDasharray="4 8" opacity={.45} className="c-flow"/>
      <path d={`M ${S2.x} ${S2.y} Q 500 295 ${S1.x} ${S1.y}`}
        fill="none" stroke="#f97316" strokeWidth={.8} strokeDasharray="3 10" opacity={.25} className="c-rev"/>
      {[0,.35,.7].map((off,oi)=>(
        <circle key={`sp-${oi}`} cx={0} cy={0} r={3.5} fill="#f97316" opacity={.8}>
          <animateMotion dur="2.8s" begin={`${off*2.8}s`} repeatCount="indefinite"
            path={`M ${S1.x} ${S1.y} Q 500 115 ${S2.x} ${S2.y}`}/>
        </circle>
      ))}

      {/* ── S1 Tenant orbit ── */}
      {visible.map((t, i) => {
        const pos    = orbitalPos(i, visible.length, S1.x, S1.y, CR1);
        const pkgCol = PACKAGE_COLOR[t.package] || PACKAGE_COLOR.default;
        const isSel  = selectedTenant === t.id;
        const isHov  = hoveredTenant === t.id;
        const hasOnl = t.device_online > 0;
        const label  = (t.company || t.name).slice(0, 10);
        const lblY   = pos.y < S1.y - 55 ? pos.y - 32 : pos.y + 30;
        const tu     = activeUsers.filter(u => u.tenant_id === t.id);
        const subCol = t.sub_days > 30 ? '#22c55e' : t.sub_days > 7 ? '#f59e0b' : '#ef4444';

        // Tooltip positioning — stay inside viewBox
        const ttW = 138, ttH = 98;
        let ttX = pos.x + 22;
        let ttY = pos.y - 55;
        if (ttX + ttW > 980) ttX = pos.x - ttW - 10;
        if (ttY < 4) ttY = pos.y + 22;

        return (
          <g key={`s1-${t.id}`} style={{ cursor: 'pointer' }}
            onClick={() => onSelectTenant(isSel ? null : t.id)}
            onMouseEnter={() => setHoveredTenant(t.id)}
            onMouseLeave={() => setHoveredTenant(null)}>

            {/* Spoke */}
            <line x1={S1.x} y1={S1.y} x2={pos.x} y2={pos.y}
              stroke={isSel ? pkgCol : '#1e293b'} strokeWidth={isSel ? 1.5 : .8} opacity={.7}/>

            {/* Data flow particle tenant → S1 */}
            {hasOnl && (
              <circle cx={0} cy={0} r={3} fill="#22c55e" opacity={.85}>
                <animateMotion dur={`${2+i*.25}s`} repeatCount="indefinite"
                  path={`M ${pos.x} ${pos.y} L ${S1.x} ${S1.y}`}/>
              </circle>
            )}

            {/* Device satellite dots */}
            {t.devices.slice(0, 3).map((d, di) => {
              const dp = devicePos(di, Math.min(t.devices.length, 3), pos.x, pos.y);
              return (
                <g key={d.device_id}>
                  <line x1={pos.x} y1={pos.y} x2={dp.x} y2={dp.y} stroke="#1e293b" strokeWidth={.7}/>
                  <circle cx={dp.x} cy={dp.y} r={4.5}
                    fill={d.online ? '#22c55e' : '#1e293b'}
                    stroke={d.online ? '#22c55e' : '#475569'}
                    strokeWidth={d.online ? 0 : .8} opacity={d.online ? .9 : .5}/>
                  {d.online && (
                    <circle cx={dp.x} cy={dp.y} r={4.5} fill="none" stroke="#22c55e" strokeWidth={1}>
                      <animate attributeName="r" values="4.5;9;4.5" dur="2.2s" repeatCount="indefinite"/>
                      <animate attributeName="opacity" values=".5;0;.5" dur="2.2s" repeatCount="indefinite"/>
                    </circle>
                  )}
                  {d.online && (
                    <circle cx={0} cy={0} r={2} fill="#22c55e" opacity={.7}>
                      <animateMotion dur={`${1.4+di*.3}s`} repeatCount="indefinite"
                        path={`M ${dp.x} ${dp.y} L ${pos.x} ${pos.y}`}/>
                    </circle>
                  )}
                </g>
              );
            })}

            {/* Active user sub-nodes */}
            {tu.slice(0, 3).map((u, ui) => {
              const angle = USER_ANGLES[ui] ?? (ui * Math.PI * 2 / 3 - Math.PI / 2);
              const ux = pos.x + USER_R * Math.cos(angle);
              const uy = pos.y + USER_R * Math.sin(angle);
              const inits = (u.name || u.email.split('@')[0]).slice(0, 2).toUpperCase();
              const mc    = METHOD_COLOR[u.method] || '#94a3b8';
              const fresh = u.seconds_ago < 30;
              return (
                <g key={`u-${u.user_id}`}>
                  <line x1={ux} y1={uy} x2={pos.x} y2={pos.y}
                    stroke={mc} strokeWidth={.8} opacity={fresh ? .5 : .2}/>
                  {fresh && (
                    <circle cx={0} cy={0} r={2.5} fill={mc} opacity={.9}>
                      <animateMotion dur={`${.85 + ui*.15}s`} repeatCount="indefinite"
                        path={`M ${ux} ${uy} L ${pos.x} ${pos.y}`}/>
                    </circle>
                  )}
                  {fresh && (
                    <circle cx={ux} cy={uy} r={10} fill="none" stroke={mc} strokeWidth={1}>
                      <animate attributeName="r" values="10;16;10" dur="1.6s" repeatCount="indefinite"/>
                      <animate attributeName="opacity" values=".5;0;.5" dur="1.6s" repeatCount="indefinite"/>
                    </circle>
                  )}
                  <circle cx={ux} cy={uy} r={9} fill="#0f172a"
                    stroke={fresh ? mc : '#1e293b'} strokeWidth={fresh ? 1.5 : .7}/>
                  <text x={ux} y={uy} textAnchor="middle" dominantBaseline="central"
                    fill={fresh ? '#f1f5f9' : '#475569'} fontSize={6} fontWeight="700"
                    style={{userSelect:'none'}}>{inits}</text>
                  {fresh && (
                    <text x={ux} y={uy - 14} textAnchor="middle"
                      fill={mc} fontSize={5.5} fontWeight="800" style={{userSelect:'none'}}>
                      {u.method}
                    </text>
                  )}
                </g>
              );
            })}

            {/* Selected pulse */}
            {isSel && (
              <circle cx={pos.x} cy={pos.y} r={22} fill="none" stroke={pkgCol} strokeWidth={2} opacity={.6}>
                <animate attributeName="r" values="22;30;22" dur="1.4s" repeatCount="indefinite"/>
                <animate attributeName="opacity" values=".6;0;.6" dur="1.4s" repeatCount="indefinite"/>
              </circle>
            )}

            {/* Tenant node */}
            <circle cx={pos.x} cy={pos.y} r={18} fill="#0f172a"
              stroke={isSel ? pkgCol : isHov ? '#64748b' : hasOnl ? '#334155' : '#1e293b'}
              strokeWidth={isSel ? 2 : isHov ? 1.5 : 1}/>
            <text x={pos.x} y={pos.y} textAnchor="middle" dominantBaseline="central"
              fill={hasOnl ? '#f1f5f9' : '#64748b'} fontSize={8.5} fontWeight="700"
              style={{userSelect:'none'}}>
              {t.device_online}/{t.device_total}
            </text>

            {/* Active user count badge */}
            {tu.length > 0 && (
              <g transform={`translate(${pos.x + 14},${pos.y - 14})`}>
                <circle r={7} fill="#1d4ed8" stroke="#020617" strokeWidth={1}/>
                <text textAnchor="middle" dominantBaseline="central"
                  fill="white" fontSize={6.5} fontWeight="800" style={{userSelect:'none'}}>
                  {tu.length > 9 ? '9+' : tu.length}
                </text>
              </g>
            )}

            {/* Worker count badge */}
            {t.worker_count > 0 && (
              <g transform={`translate(${pos.x - 14},${pos.y - 14})`}>
                <circle r={6} fill="#475569"/>
                <text textAnchor="middle" dominantBaseline="central"
                  fill="#e2e8f0" fontSize={6} fontWeight="700" style={{userSelect:'none'}}>
                  {t.worker_count > 9 ? '9+' : t.worker_count}
                </text>
              </g>
            )}

            {/* Tenant label */}
            <text x={pos.x} y={lblY} textAnchor="middle"
              fill={isSel ? '#f1f5f9' : '#94a3b8'} fontSize={8} fontWeight={isSel ? '700' : '500'}
              style={{userSelect:'none'}}>{label}</text>
            <text x={pos.x} y={lblY + 11} textAnchor="middle"
              fill={pkgCol} fontSize={6.5} style={{userSelect:'none'}}>{t.package}</text>

            {/* SVG hover tooltip */}
            {isHov && !isSel && (
              <g>
                <rect x={ttX} y={ttY} width={ttW} height={ttH} rx={6}
                  fill="#0f172a" stroke={pkgCol} strokeWidth={1} opacity={.97}/>
                <text x={ttX+8} y={ttY+15} fill="white" fontSize={9.5} fontWeight="700"
                  style={{userSelect:'none'}}>{(t.company||t.name).slice(0,16)}</text>
                <text x={ttX+8} y={ttY+25} fill="#64748b" fontSize={7}
                  style={{userSelect:'none'}}>{t.email.slice(0,22)}</text>
                {/* Package pill */}
                <rect x={ttX+8} y={ttY+30} width={44} height={11} rx={4} fill={pkgCol+'33'}/>
                <text x={ttX+30} y={ttY+37.5} textAnchor="middle" fill={pkgCol} fontSize={7} fontWeight="700"
                  style={{userSelect:'none'}}>{t.package}</text>
                {/* Divider */}
                <line x1={ttX+4} y1={ttY+46} x2={ttX+ttW-4} y2={ttY+46} stroke="#1e293b" strokeWidth={.7}/>
                <text x={ttX+8} y={ttY+57} fill="#94a3b8" fontSize={7.5} style={{userSelect:'none'}}>
                  📡 {t.device_online}/{t.device_total} cihaz
                </text>
                <text x={ttX+8} y={ttY+68} fill="#94a3b8" fontSize={7.5} style={{userSelect:'none'}}>
                  👤 {t.worker_count} personel
                </text>
                <text x={ttX+8} y={ttY+79} fill={tu.length>0?'#60a5fa':'#475569'} fontSize={7.5}
                  style={{userSelect:'none'}}>
                  ● {tu.length} aktif kullanıcı
                </text>
                <text x={ttX+8} y={ttY+90} fill={subCol} fontSize={7} style={{userSelect:'none'}}>
                  Abonelik: {t.sub_days}g kaldı
                </text>
              </g>
            )}
          </g>
        );
      })}

      {/* ── S2 Replica tenants (smaller, dimmed) ── */}
      {visible.map((t, i) => {
        const pos    = orbitalPos(i, visible.length, S2.x, S2.y, CR2);
        const pkgCol = PACKAGE_COLOR[t.package] || PACKAGE_COLOR.default;
        const tu     = activeUsers.filter(u => u.tenant_id === t.id);
        return (
          <g key={`s2-${t.id}`} opacity={.55}>
            <line x1={S2.x} y1={S2.y} x2={pos.x} y2={pos.y} stroke="#1e293b" strokeWidth={.7}/>
            {tu.length > 0 && (
              <circle cx={0} cy={0} r={2.5} fill="#1d4ed8" opacity={.7}>
                <animateMotion dur={`${1.8+i*.2}s`} repeatCount="indefinite"
                  path={`M ${pos.x} ${pos.y} L ${S2.x} ${S2.y}`}/>
              </circle>
            )}
            <circle cx={pos.x} cy={pos.y} r={13} fill="#0f172a" stroke={pkgCol} strokeWidth={.7}/>
            <text x={pos.x} y={pos.y} textAnchor="middle" dominantBaseline="central"
              fill="#64748b" fontSize={7} fontWeight="600" style={{userSelect:'none'}}>
              {t.device_online}/{t.device_total}
            </text>
            {t.devices.slice(0,2).map((d,di)=>{
              const dp = devicePos(di, 2, pos.x, pos.y);
              return <circle key={d.device_id} cx={dp.x} cy={dp.y} r={3}
                fill={d.online?'#22c55e':'#334155'} opacity={.55}/>;
            })}
            {tu.slice(0,2).map((u,ui)=>{
              const angle = USER_ANGLES[ui] ?? 0;
              const ux = pos.x + 38 * Math.cos(angle);
              const uy = pos.y + 38 * Math.sin(angle);
              const mc = METHOD_COLOR[u.method]||'#94a3b8';
              return <circle key={`s2u-${u.user_id}`} cx={ux} cy={uy} r={5}
                fill="#0f172a" stroke={mc} strokeWidth={.8} opacity={.7}/>;
            })}
          </g>
        );
      })}

      {extra > 0 && (
        <g transform={`translate(${S1.x},${S1.y + CR1 + 22})`}>
          <rect x={-28} y={-10} width={56} height={20} rx={10} fill="#1e293b"/>
          <text textAnchor="middle" y={4} fill="#94a3b8" fontSize={8} fontWeight="700">+{extra} daha</text>
        </g>
      )}

      {/* ── S1 Hub ── */}
      <g>
        <circle cx={S1.x} cy={S1.y} r={30} fill="#0f172a"
          stroke={s1st?.status==='ok'?'#22c55e':'#8b5cf6'} strokeWidth={2}/>
        {s1st?.status === 'ok' && (
          <circle cx={S1.x} cy={S1.y} r={30} fill="none" stroke="#22c55e" strokeWidth={1}>
            <animate attributeName="r" values="30;44;30" dur="2.5s" repeatCount="indefinite"/>
            <animate attributeName="opacity" values=".3;0;.3" dur="2.5s" repeatCount="indefinite"/>
          </circle>
        )}
        <text x={S1.x} y={S1.y-5} textAnchor="middle" dominantBaseline="central"
          fill="white" fontSize={12} style={{userSelect:'none'}}>🚀</text>
        <text x={S1.x} y={S1.y+13} textAnchor="middle" fill="#e2e8f0" fontSize={9} fontWeight="700"
          style={{userSelect:'none'}}>S1</text>
        <text x={S1.x} y={S1.y-42} textAnchor="middle" fill="#8b5cf6" fontSize={9.5} fontWeight="800"
          style={{userSelect:'none'}}>{tenants.length} dükkan</text>
        {activeUsers.length > 0 && (
          <text x={S1.x} y={S1.y-54} textAnchor="middle" fill="#1d4ed8" fontSize={8} fontWeight="700"
            style={{userSelect:'none'}}>{activeUsers.length} aktif kullanıcı</text>
        )}
        {s1st?.ram_pct !== undefined && (
          <text x={S1.x} y={S1.y+50} textAnchor="middle" fill="#475569" fontSize={7.5}
            style={{userSelect:'none'}}>CPU {s1st.load} · RAM %{s1st.ram_pct}</text>
        )}
      </g>

      {/* ── S2 Hub ── */}
      <g>
        <circle cx={S2.x} cy={S2.y} r={23} fill="#0f172a"
          stroke={s2st?.status==='ok'?'#22c55e':s2st?.status==='error'?'#ef4444':'#334155'}
          strokeWidth={1.5}/>
        <text x={S2.x} y={S2.y-4} textAnchor="middle" dominantBaseline="central"
          fill="white" fontSize={11} style={{userSelect:'none'}}>🚀</text>
        <text x={S2.x} y={S2.y+12} textAnchor="middle" fill="#94a3b8" fontSize={8} fontWeight="600"
          style={{userSelect:'none'}}>S2</text>
        <text x={S2.x} y={S2.y-36} textAnchor="middle"
          fill={s2st?.status==='ok'?'#22c55e':'#ef4444'} fontSize={8.5} fontWeight="700"
          style={{userSelect:'none'}}>Replika</text>
      </g>

      <text x={S1.x} y={400} textAnchor="middle" fill="#334155" fontSize={7.5} style={{userSelect:'none'}}>
        S1 — Ana Küme · daire=dükkan · yeşil dot=cihaz · mavi dot=kullanıcı
      </text>
      <text x={S2.x} y={400} textAnchor="middle" fill="#334155" fontSize={7.5} style={{userSelect:'none'}}>
        S2 — Replika (aynı veri tabanı) · üzerine gel → detay
      </text>
    </svg>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// TenantGridPanel — rich dealer cards with device bars + sub_days
// ═════════════════════════════════════════════════════════════════════════════
function TenantGridPanel({ tenants, activeUsers, selectedTenant, onSelectTenant }: {
  tenants: TenantDef[];
  activeUsers: ActiveUser[];
  selectedTenant: number | null;
  onSelectTenant: (id: number | null) => void;
}) {
  return (
    <div>
      <div className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-2 px-1">
        Dükkan Listesi — tıkla detay gör
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
        {tenants.map(t => {
          const pkgColor = PACKAGE_COLOR[t.package] || PACKAGE_COLOR.default;
          const tu       = activeUsers.filter(u => u.tenant_id === t.id);
          const isSel    = selectedTenant === t.id;
          const devPct   = t.device_total > 0 ? Math.round(t.device_online / t.device_total * 100) : 0;
          const subColor = t.sub_days > 30 ? '#22c55e' : t.sub_days > 7 ? '#f59e0b' : '#ef4444';
          const subPct   = Math.min(Math.round(t.sub_days / 90 * 100), 100);
          return (
            <button key={t.id} onClick={() => onSelectTenant(isSel ? null : t.id)}
              className={`text-left w-full rounded-xl p-3 border transition ${
                isSel
                  ? 'bg-violet-950/30 border-violet-500'
                  : 'bg-slate-800/60 hover:bg-slate-700/60 border-slate-700/60 hover:border-slate-500'
              }`}>

              {/* Header */}
              <div className="flex items-start justify-between gap-2 mb-1.5">
                <div className="flex items-center gap-2 min-w-0">
                  <span className={`w-2 h-2 rounded-full flex-shrink-0 mt-0.5 ${
                    t.device_online > 0 ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'}`}/>
                  <div className="min-w-0">
                    <div className="font-bold text-sm text-slate-100 truncate">{t.company || t.name}</div>
                    <div className="text-[10px] text-slate-500 truncate">{t.name !== t.company ? t.name : ''}</div>
                  </div>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full flex-shrink-0"
                  style={{ background: pkgColor+'22', color: pkgColor }}>{t.package}</span>
              </div>

              {/* Email */}
              <div className="text-[10px] text-slate-600 truncate mb-2.5 ml-4">{t.email}</div>

              {/* Device progress */}
              <div className="mb-2">
                <div className="flex justify-between text-[10px] mb-1">
                  <span className="text-slate-500">📡 Cihazlar</span>
                  <span className={`font-bold ${t.device_online > 0 ? 'text-emerald-400' : 'text-slate-600'}`}>
                    {t.device_online}/{t.device_total} online
                  </span>
                </div>
                <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-700"
                    style={{ width: `${devPct}%`, background: t.device_online > 0 ? '#22c55e' : '#475569' }}/>
                </div>
              </div>

              {/* Subscription bar */}
              <div className="mb-2.5">
                <div className="flex justify-between text-[10px] mb-1">
                  <span className="text-slate-500">Abonelik</span>
                  <span className="font-bold" style={{ color: subColor }}>{t.sub_days} gün kaldı</span>
                </div>
                <div className="h-1 bg-slate-700 rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-700"
                    style={{ width: `${subPct}%`, background: subColor }}/>
                </div>
              </div>

              {/* Badges */}
              <div className="flex items-center gap-1.5 flex-wrap mb-2">
                {t.worker_count > 0 && (
                  <span className="text-[10px] text-slate-400 bg-slate-700/60 px-1.5 py-0.5 rounded">
                    👤 {t.worker_count} personel
                  </span>
                )}
                {tu.length > 0 ? (
                  <span className="text-[10px] text-blue-400 bg-blue-400/10 px-1.5 py-0.5 rounded font-bold">
                    ● {tu.length} aktif
                  </span>
                ) : (
                  <span className="text-[10px] text-slate-700">pasif</span>
                )}
                {t.device_online === 0 && t.device_total > 0 && (
                  <span className="text-[10px] text-slate-600 bg-slate-700/40 px-1.5 py-0.5 rounded">
                    tüm cihazlar offline
                  </span>
                )}
              </div>

              {/* Device ID chips */}
              {t.devices.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {t.devices.slice(0, 4).map(d => (
                    <span key={d.device_id}
                      className={`text-[9px] font-mono px-1.5 py-0.5 rounded border ${
                        d.online
                          ? 'bg-emerald-400/10 border-emerald-400/30 text-emerald-400'
                          : 'bg-slate-700/30 border-slate-700/50 text-slate-600'
                      }`}>
                      {d.device_id.slice(-8)}
                    </span>
                  ))}
                  {t.devices.length > 4 && (
                    <span className="text-[9px] text-slate-600 py-0.5">+{t.devices.length-4}</span>
                  )}
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// UserTablePanel — detailed active user table
// ═════════════════════════════════════════════════════════════════════════════
function UserTablePanel({ users, tenants }: { users: ActiveUser[]; tenants: TenantDef[] }) {
  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-700 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-700/60">
        <div className="flex items-center gap-2.5">
          <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse"/>
          <span className="text-sm font-black text-white tracking-tight">AKTİF KULLANICILAR</span>
          <span className="text-xs text-slate-500">{users.length} bağlantı / son 5dk</span>
        </div>
        <div className="text-[10px] text-slate-600 font-mono">4s güncelleme</div>
      </div>

      {users.length === 0 ? (
        <div className="flex items-center justify-center py-10 text-slate-600 text-sm font-mono">
          Aktif kullanıcı yok
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-800">
                <th className="text-left px-4 py-2 text-[10px] font-black text-slate-500 uppercase tracking-wider">Kullanıcı</th>
                <th className="text-left px-3 py-2 text-[10px] font-black text-slate-500 uppercase tracking-wider">Rol</th>
                <th className="text-left px-3 py-2 text-[10px] font-black text-slate-500 uppercase tracking-wider hidden md:table-cell">Dükkan</th>
                <th className="text-left px-3 py-2 text-[10px] font-black text-slate-500 uppercase tracking-wider">İstek</th>
                <th className="text-left px-3 py-2 text-[10px] font-black text-slate-500 uppercase tracking-wider hidden sm:table-cell">Hedef</th>
                <th className="text-right px-4 py-2 text-[10px] font-black text-slate-500 uppercase tracking-wider">Süre</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40">
              {users.slice(0, 20).map(u => {
                const mc      = METHOD_COLOR[u.method] || '#94a3b8';
                const fresh   = u.seconds_ago < 30;
                const tenant  = tenants.find(t => t.id === u.tenant_id);
                const target  = endpointToTarget(u.endpoint);
                const inits   = (u.name || u.email.split('@')[0]).slice(0, 2).toUpperCase();
                const ri      = ROLE_INFO[u.role] || { label: u.role || '—', color: '#94a3b8' };
                const epClean = u.endpoint.replace('/api/v1/', '').replace(/\/\d+/g, '/…').slice(0, 30);
                return (
                  <tr key={u.user_id}
                    className={`transition-colors hover:bg-slate-800/30 ${fresh ? 'bg-emerald-950/10' : ''}`}>

                    {/* Kullanıcı */}
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-black"
                          style={{ background: mc + '1a', border: `1.5px solid ${mc}`, color: mc }}>
                          {inits}
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs font-semibold text-slate-200 truncate max-w-[130px]">
                            {u.name || u.email.split('@')[0]}
                          </div>
                          <div className="text-[9px] text-slate-600 truncate max-w-[130px]">{u.email}</div>
                        </div>
                        {fresh && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse flex-shrink-0"/>}
                      </div>
                    </td>

                    {/* Rol */}
                    <td className="px-3 py-2.5">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap"
                        style={{ background: ri.color + '22', color: ri.color }}>{ri.label}</span>
                    </td>

                    {/* Dükkan */}
                    <td className="px-3 py-2.5 hidden md:table-cell">
                      <div className="min-w-0">
                        <div className="text-[11px] text-slate-300 truncate max-w-[120px]">
                          {tenant?.company || tenant?.name || '—'}
                        </div>
                        {tenant && (
                          <div className="text-[9px] truncate max-w-[120px]"
                            style={{ color: PACKAGE_COLOR[tenant.package] || '#94a3b8' }}>
                            {tenant.package}
                          </div>
                        )}
                      </div>
                    </td>

                    {/* İstek */}
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className="text-[10px] font-black px-1.5 py-0.5 rounded flex-shrink-0"
                          style={{ background: mc + '22', color: mc }}>{u.method}</span>
                        <span className="text-[10px] text-slate-500 font-mono truncate max-w-[160px]">{epClean}</span>
                      </div>
                    </td>

                    {/* Hedef */}
                    <td className="px-3 py-2.5 hidden sm:table-cell">
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm">{target.icon}</span>
                        <span className="text-[10px] font-medium" style={{ color: target.color }}>{target.label}</span>
                      </div>
                    </td>

                    {/* Süre */}
                    <td className="px-4 py-2.5 text-right">
                      <span className={`text-[10px] font-mono font-bold ${fresh ? 'text-emerald-400' : 'text-slate-600'}`}>
                        {u.seconds_ago < 60 ? `${u.seconds_ago}s` : `${Math.floor(u.seconds_ago/60)}dk`}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// UserNetworkMap — ağaç yapısı: S1 → Bayi → Kullanıcı → Hedef, canlı parçacık akışı
// ═════════════════════════════════════════════════════════════════════════════
const UNM = {
  SVG_W: 980,
  S1X: 68,  S1R: 24,
  TNX: 230, TNR: 18,
  BUS_X: 348,
  USX: 415, USR: 17,
  TGX: 810, TGR: 15,
  ROW_H: 66,
  GROUP_PAD: 20,
};

function UserNetworkMap({ activeUsers, tenants }: { activeUsers: ActiveUser[]; tenants: TenantDef[] }) {
  type RowLayout  = { user: ActiveUser; y: number };
  type GroupLayout = { tenant: TenantDef; tenantY: number; rows: RowLayout[] };

  const groups: GroupLayout[] = [];
  let curY = 38;

  for (const tenant of tenants) {
    const users = activeUsers.filter(u => u.tenant_id === tenant.id);
    if (users.length === 0) continue;
    const rows: RowLayout[] = users.map((u, i) => ({
      user: u,
      y: curY + i * UNM.ROW_H + UNM.ROW_H / 2,
    }));
    const tenantY = (rows[0].y + rows[rows.length - 1].y) / 2;
    groups.push({ tenant, tenantY, rows });
    curY += users.length * UNM.ROW_H + UNM.GROUP_PAD;
  }

  // Unmatched users (no tenant found — e.g. super_admin)
  const unmatchedUsers = activeUsers.filter(u => !tenants.some(t => t.id === u.tenant_id));
  const unmatchedStart = curY;
  if (unmatchedUsers.length > 0) curY += unmatchedUsers.length * UNM.ROW_H + UNM.GROUP_PAD;

  const totalH = Math.max(130, curY + 20);
  const S1Y    = totalH / 2;
  const { SVG_W, S1X, S1R, TNX, TNR, BUS_X, USX, USR, TGX, TGR, ROW_H } = UNM;

  if (groups.length === 0 && unmatchedUsers.length === 0) {
    return (
      <div className="flex items-center justify-center py-10 text-slate-600 text-sm font-mono">
        Aktif kullanıcı yok — bağlantı haritası boş
      </div>
    );
  }

  const renderUserRow = (user: ActiveUser, y: number, animIdx: number) => {
    const mc      = METHOD_COLOR[user.method] || '#94a3b8';
    const ri      = ROLE_INFO[user.role] || { label: user.role || '—', color: '#94a3b8' };
    const target  = endpointToTarget(user.endpoint);
    const fresh   = user.seconds_ago < 30;
    const inits   = (user.name || user.email.split('@')[0]).slice(0, 2).toUpperCase();
    const name    = (user.name || user.email.split('@')[0]).slice(0, 19);
    const ep      = user.endpoint.replace('/api/v1/', '').replace(/\/\d+/g, '/…').slice(0, 26);
    const dur1    = (0.70 + animIdx * 0.11).toFixed(2);
    const dur2    = (1.05 + animIdx * 0.09).toFixed(2);
    const delay   = (animIdx * 0.20).toFixed(2);
    const busPath = `M ${BUS_X} ${y} L ${USX - USR} ${y}`;
    const flowPath= `M ${USX + USR} ${y} L ${TGX - TGR - 6} ${y}`;

    return (
      <g key={user.user_id}>
        {/* Bus → User branch */}
        <path d={busPath} fill="none" stroke="#1e293b" strokeWidth={.9}/>
        <path d={busPath} fill="none" stroke={mc} strokeWidth={.9}
          opacity={fresh ? .5 : .15} strokeDasharray="4 7">
          <animate attributeName="stroke-dashoffset" from="0" to="-22"
            dur={`${dur1}s`} repeatCount="indefinite"/>
        </path>
        {fresh && (
          <circle r={3} fill={mc} opacity={.9}>
            <animateMotion dur={`${dur1}s`} begin={`${delay}s`} repeatCount="indefinite" path={busPath}/>
          </circle>
        )}

        {/* User node pulse */}
        {fresh && (
          <circle cx={USX} cy={y} r={USR} fill="none" stroke={mc} strokeWidth={1}>
            <animate attributeName="r" values={`${USR};${USR+11};${USR}`} dur="1.9s" repeatCount="indefinite"/>
            <animate attributeName="opacity" values=".4;0;.4" dur="1.9s" repeatCount="indefinite"/>
          </circle>
        )}

        {/* User node */}
        <circle cx={USX} cy={y} r={USR} fill="#0f172a"
          stroke={fresh ? mc : '#1e293b'} strokeWidth={fresh ? 1.8 : 0.7}/>
        <text x={USX} y={y} textAnchor="middle" dominantBaseline="central"
          fill={fresh ? '#f1f5f9' : '#475569'} fontSize={8.5} fontWeight="700"
          style={{userSelect:'none'}}>{inits}</text>

        {/* Method badge above node */}
        <rect x={USX - 15} y={y - USR - 15} width={30} height={12} rx={5}
          fill={mc + '2a'} stroke={mc} strokeWidth={.5}/>
        <text x={USX} y={y - USR - 7} textAnchor="middle" fill={mc} fontSize={7} fontWeight="800"
          style={{userSelect:'none'}}>{user.method}</text>

        {/* User name (right of node, above flow line) */}
        <text x={USX + USR + 8} y={y - 6} fill={fresh ? '#cbd5e1' : '#475569'} fontSize={8.5} fontWeight="600"
          style={{userSelect:'none'}}>{name}</text>
        {/* Role (right of node, below flow line) */}
        <text x={USX + USR + 8} y={y + 6} fill={ri.color} fontSize={7} fontWeight="600"
          style={{userSelect:'none'}}>{ri.label}</text>
        {/* Endpoint below */}
        <text x={USX + USR + 8} y={y + 17} fill="#334155" fontSize={6.5} fontFamily="monospace"
          style={{userSelect:'none'}}>{ep}</text>

        {/* User → Target flow */}
        <path d={flowPath} fill="none" stroke="#1e293b" strokeWidth={.9}/>
        <path d={flowPath} fill="none" stroke={target.color} strokeWidth={.9}
          opacity={fresh ? .5 : .1} strokeDasharray="5 8">
          <animate attributeName="stroke-dashoffset" from="0" to="-26"
            dur={`${dur2}s`} repeatCount="indefinite"/>
        </path>
        {fresh && (
          <circle r={3} fill={target.color} opacity={.9}>
            <animateMotion dur={`${dur2}s`} begin={`${delay}s`} repeatCount="indefinite" path={flowPath}/>
          </circle>
        )}

        {/* Target node */}
        <circle cx={TGX} cy={y} r={TGR} fill="#0f172a"
          stroke={target.color} strokeWidth={.9} opacity={fresh ? .95 : .45}/>
        <text x={TGX} y={y} textAnchor="middle" dominantBaseline="central" fontSize={10}
          style={{userSelect:'none'}}>{target.icon}</text>
        <text x={TGX} y={y + TGR + 9} textAnchor="middle" fill={target.color} fontSize={6.5}
          style={{userSelect:'none'}}>{target.label}</text>

        {/* Freshness badge */}
        <text x={TGX + TGR + 5} y={y + 3} fontSize={7} fontWeight={fresh ? '800' : '400'}
          fill={fresh ? '#22c55e' : '#334155'} style={{userSelect:'none'}}>
          {fresh ? '● canlı' : `${user.seconds_ago < 60 ? user.seconds_ago + 's' : Math.floor(user.seconds_ago / 60) + 'dk'}`}
        </text>
      </g>
    );
  };

  return (
    <div className="overflow-auto" style={{ maxHeight: 560 }}>
      <svg viewBox={`0 0 ${SVG_W} ${totalH}`} preserveAspectRatio="xMinYMid meet"
        style={{ width: '100%', minWidth: 720, height: Math.min(totalH, 560) }}>

        {/* Background */}
        <rect width={SVG_W} height={totalH} fill="#020617"/>
        {Array.from({length:18},(_,i)=>Array.from({length:Math.ceil(totalH/55)+1},(_,j)=>(
          <circle key={`${i}-${j}`} cx={i*56+14} cy={j*55+14} r={.8} fill="#1e293b"/>
        )))}

        {/* Column labels */}
        {[
          { x: TNX,     label: 'BAYİ' },
          { x: USX + 50, label: 'KULLANICI' },
          { x: TGX,     label: 'HEDEF' },
        ].map(({ x, label }) => (
          <text key={label} x={x} y={17} textAnchor="middle" fill="#1e293b" fontSize={7.5} fontWeight="800"
            style={{userSelect:'none'}}>{label}</text>
        ))}

        {/* S1 Hub */}
        <circle cx={S1X} cy={S1Y} r={S1R} fill="#0f172a" stroke="#8b5cf6" strokeWidth={2}/>
        <circle cx={S1X} cy={S1Y} r={S1R} fill="none" stroke="#22c55e" strokeWidth={1}>
          <animate attributeName="r" values={`${S1R};${S1R+14};${S1R}`} dur="2.5s" repeatCount="indefinite"/>
          <animate attributeName="opacity" values=".25;0;.25" dur="2.5s" repeatCount="indefinite"/>
        </circle>
        <text x={S1X} y={S1Y - 3} textAnchor="middle" fill="white" fontSize={13} style={{userSelect:'none'}}>🚀</text>
        <text x={S1X} y={S1Y + 12} textAnchor="middle" fill="#e2e8f0" fontSize={8} fontWeight="700"
          style={{userSelect:'none'}}>S1</text>
        <text x={S1X} y={S1Y - 34} textAnchor="middle" fill="#475569" fontSize={7}
          style={{userSelect:'none'}}>{groups.length} bayi</text>
        <text x={S1X} y={S1Y - 24} textAnchor="middle" fill="#334155" fontSize={7}
          style={{userSelect:'none'}}>{activeUsers.length} kullanıcı</text>

        {/* Tenant groups */}
        {groups.map(({ tenant, tenantY, rows }, gi) => {
          const pkgCol    = PACKAGE_COLOR[tenant.package] || PACKAGE_COLOR.default;
          const hasActive = rows.some(r => r.user.seconds_ago < 30);
          const midX      = (S1X + S1R + TNX - TNR) / 2;
          const s1Path    = `M ${S1X + S1R} ${S1Y} Q ${midX} ${tenantY} ${TNX - TNR} ${tenantY}`;
          const topY      = rows[0].y;
          const botY      = rows[rows.length - 1].y;

          return (
            <g key={tenant.id}>
              {/* S1 → Tenant curved path */}
              <path d={s1Path} fill="none" stroke="#1e293b" strokeWidth={1.2}/>
              <path d={s1Path} fill="none" stroke={pkgCol} strokeWidth={1}
                opacity={hasActive ? .5 : .2} strokeDasharray="5 10">
                <animate attributeName="stroke-dashoffset" from="0" to="-30"
                  dur={`${1.6 + gi * 0.18}s`} repeatCount="indefinite"/>
              </path>
              {hasActive && (
                <circle r={3.5} fill={pkgCol} opacity={.85}>
                  <animateMotion dur={`${1.8 + gi * 0.18}s`} begin={`${gi * 0.28}s`}
                    repeatCount="indefinite" path={s1Path}/>
                </circle>
              )}

              {/* Tenant node */}
              <circle cx={TNX} cy={tenantY} r={TNR} fill="#0f172a" stroke={pkgCol} strokeWidth={1.5}/>
              <text x={TNX} y={tenantY - 3} textAnchor="middle" fill="white" fontSize={10}
                style={{userSelect:'none'}}>🏪</text>
              <text x={TNX} y={tenantY + 10} textAnchor="middle" fill={pkgCol} fontSize={6} fontWeight="700"
                style={{userSelect:'none'}}>{(tenant.company || tenant.name).slice(0, 10)}</text>

              {/* Tenant → Bus horizontal */}
              <line x1={TNX + TNR} y1={tenantY} x2={BUS_X} y2={tenantY}
                stroke="#1e293b" strokeWidth={.8}/>

              {/* Vertical bus */}
              {rows.length > 1 && (
                <line x1={BUS_X} y1={topY} x2={BUS_X} y2={botY}
                  stroke="#1e293b" strokeWidth={.8}/>
              )}

              {/* Each user row */}
              {rows.map(({ user, y }, ui) =>
                renderUserRow(user, y, gi * 6 + ui)
              )}
            </g>
          );
        })}

        {/* Unmatched users (super_admin etc) — appear directly linked to S1 */}
        {unmatchedUsers.map((user, ui) => {
          const y       = unmatchedStart + ui * ROW_H + ROW_H / 2;
          const mc      = METHOD_COLOR[user.method] || '#94a3b8';
          const midX    = (S1X + S1R + USX - USR) / 2;
          const s1Path  = `M ${S1X + S1R} ${S1Y} Q ${midX} ${y} ${USX - USR} ${y}`;
          const fresh   = user.seconds_ago < 30;
          return (
            <g key={`unmatched-${user.user_id}`}>
              <path d={s1Path} fill="none" stroke="#1e293b" strokeWidth={.8}/>
              <path d={s1Path} fill="none" stroke={mc} strokeWidth={.8}
                opacity={fresh ? .4 : .1} strokeDasharray="3 8">
                <animate attributeName="stroke-dashoffset" from="0" to="-22"
                  dur={`${1.2 + ui * 0.1}s`} repeatCount="indefinite"/>
              </path>
              {renderUserRow(user, y, groups.length * 6 + ui)}
            </g>
          );
        })}
      </svg>
    </div>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// LiveFlowPanel — animated data flow: user → S1 → target
// ═════════════════════════════════════════════════════════════════════════════
function LiveFlowPanel({ users, tenants }: { users: ActiveUser[]; tenants: TenantDef[] }) {
  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-700 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-700/60">
        <div className="flex items-center gap-2.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"/>
          <span className="text-sm font-black text-white tracking-tight">CANLI VERİ AKIŞI</span>
          <span className="text-xs text-slate-500">{users.length} aktif bağlantı</span>
        </div>
        <div className="flex items-center gap-2 text-[10px] text-slate-600 font-mono">
          <span>👤</span><span>──►</span><span>🚀 S1</span><span>──►</span><span>🗄️ hedef</span>
        </div>
      </div>

      {users.length === 0 ? (
        <div className="flex items-center justify-center py-10 text-slate-600 text-sm font-mono">
          Aktif veri akışı bekleniyor…
        </div>
      ) : (
        <div className="divide-y divide-slate-800/60">
          {users.slice(0, 12).map((u, i) => {
            const tenant  = tenants.find(t => t.id === u.tenant_id);
            const target  = endpointToTarget(u.endpoint);
            const mc      = METHOD_COLOR[u.method] || '#94a3b8';
            const fresh   = u.seconds_ago < 8;
            const inits   = (u.name || u.email.split('@')[0]).slice(0, 2).toUpperCase();
            const epClean = u.endpoint.replace('/api/v1/', '').replace(/\/\d+/g, '/…').slice(0, 28);
            const ri      = ROLE_INFO[u.role] || { label: u.role || '—', color: '#94a3b8' };
            const dur1    = (1.2 + i * 0.08).toFixed(2);
            const dur2    = (1.8 + i * 0.08).toFixed(2);
            const delay   = (i * 0.18).toFixed(2);

            return (
              <div key={u.user_id} className={`px-4 py-2 transition-colors ${fresh ? 'bg-emerald-950/20' : ''}`}>
                <div className="flex items-center gap-2">

                  {/* Kullanıcı */}
                  <div className="flex items-center gap-2 flex-shrink-0 w-[150px]">
                    <div className="w-9 h-9 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-black"
                      style={{ background: mc + '1a', border: `1.5px solid ${mc}`, color: mc }}>
                      {inits}
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-slate-200 truncate">
                        {(u.name || 'Kullanıcı').slice(0, 14)}
                      </div>
                      <div className="flex items-center gap-1 min-w-0">
                        <span className="text-[9px] font-bold flex-shrink-0" style={{ color: ri.color }}>{ri.label}</span>
                        {tenant && (
                          <span className="text-[9px] text-slate-600 truncate">· {(tenant.company || tenant.name).slice(0, 10)}</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Flow 1: Kullanıcı → S1 */}
                  <div className="flex-1 flex flex-col gap-1.5 min-w-0">
                    <svg viewBox="0 0 200 10" preserveAspectRatio="none" className="w-full" height="10">
                      <line x1="0" y1="5" x2="200" y2="5" stroke="#1e293b" strokeWidth="2"/>
                      <line x1="0" y1="5" x2="200" y2="5" stroke={mc} strokeWidth="1.2"
                        opacity=".4" strokeDasharray="6 10">
                        <animate attributeName="stroke-dashoffset" from="0" to="-32"
                          dur={`${dur1}s`} repeatCount="indefinite"/>
                      </line>
                      <circle cx="0" cy="5" r="4.5" fill={mc}
                        style={{ filter: `drop-shadow(0 0 4px ${mc})` }}>
                        <animateMotion dur={`${dur1}s`} begin={`${delay}s`} repeatCount="indefinite"
                          path="M 0 5 L 200 5"/>
                      </circle>
                    </svg>
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span className="text-[9px] font-black px-1 rounded flex-shrink-0"
                        style={{ background: mc + '22', color: mc }}>{u.method}</span>
                      <span className="text-[9px] text-slate-600 truncate">{epClean}</span>
                    </div>
                  </div>

                  {/* S1 */}
                  <div className="flex flex-col items-center gap-0.5 flex-shrink-0">
                    <div className="w-9 h-9 rounded-full bg-violet-950 border border-violet-700 flex items-center justify-center">
                      <span className="text-sm">🚀</span>
                    </div>
                    <span className="text-[9px] text-slate-500">S1</span>
                  </div>

                  {/* Flow 2: S1 → Target */}
                  <div className="flex-1 flex flex-col gap-1.5 min-w-0">
                    <svg viewBox="0 0 200 10" preserveAspectRatio="none" className="w-full" height="10">
                      <line x1="0" y1="5" x2="200" y2="5" stroke="#1e293b" strokeWidth="2"/>
                      <line x1="0" y1="5" x2="200" y2="5" stroke={target.color} strokeWidth="1"
                        opacity=".35" strokeDasharray="5 12">
                        <animate attributeName="stroke-dashoffset" from="0" to="-34"
                          dur={`${dur2}s`} repeatCount="indefinite"/>
                      </line>
                      <circle cx="0" cy="5" r="3.5" fill={target.color} opacity=".85">
                        <animateMotion dur={`${dur2}s`} begin={`${delay}s`} repeatCount="indefinite"
                          path="M 0 5 L 200 5"/>
                      </circle>
                    </svg>
                    <div className="text-[9px] text-slate-600 text-center">
                      {fresh
                        ? <span className="text-emerald-500 font-bold">● canlı</span>
                        : `${u.seconds_ago < 60 ? u.seconds_ago + 's' : Math.floor(u.seconds_ago/60) + 'dk'} önce`}
                    </div>
                  </div>

                  {/* Hedef */}
                  <div className="flex flex-col items-center gap-0.5 flex-shrink-0">
                    <div className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center">
                      <span className="text-sm">{target.icon}</span>
                    </div>
                    <span className="text-[9px] text-slate-500">{target.label}</span>
                  </div>

                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// TenantDetail — clicked tenant full detail panel
// ═════════════════════════════════════════════════════════════════════════════
function TenantDetail({ tenant, activeUsers, onClose }: {
  tenant: TenantDef;
  activeUsers: ActiveUser[];
  onClose: () => void;
}) {
  const pkgColor    = PACKAGE_COLOR[tenant.package] || PACKAGE_COLOR.default;
  const tenantUsers = activeUsers.filter(u => u.tenant_id === tenant.id);
  const subColor    = tenant.sub_days > 30 ? '#22c55e' : tenant.sub_days > 7 ? '#f59e0b' : '#ef4444';
  const devPct      = tenant.device_total > 0 ? Math.round(tenant.device_online / tenant.device_total * 100) : 0;

  return (
    <div className="bg-slate-900 border border-slate-700 rounded-2xl p-4">
      <div className="flex items-start justify-between mb-3">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-lg">🏪</span>
            <span className="font-black text-white text-base">{tenant.company || tenant.name}</span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
              style={{ background: pkgColor+'22', color: pkgColor }}>{tenant.package}</span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
              style={{ background: subColor+'22', color: subColor }}>
              {tenant.sub_days}g abonelik
            </span>
          </div>
          <div className="text-xs text-slate-500 mt-0.5">{tenant.email}</div>
        </div>
        <button onClick={onClose} className="text-slate-500 hover:text-white transition text-lg ml-4">✕</button>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-4 gap-2 mb-4">
        {[
          { label: 'Çevrimiçi Cihaz', val: tenant.device_online, col: tenant.device_online > 0 ? '#22c55e' : '#64748b' },
          { label: 'Toplam Cihaz',    val: tenant.device_total,  col: '#8b5cf6' },
          { label: 'Personel',        val: tenant.worker_count,  col: '#3b82f6' },
          { label: 'Aktif Kullanıcı', val: tenantUsers.length,   col: '#1d4ed8' },
        ].map(item => (
          <div key={item.label} className="bg-slate-800 rounded-xl p-2.5 text-center">
            <div className="text-xl font-black" style={{ color: item.col }}>{item.val}</div>
            <div className="text-[9px] text-slate-500 mt-0.5">{item.label}</div>
          </div>
        ))}
      </div>

      {/* Device health bar */}
      <div className="mb-4">
        <div className="flex justify-between text-[10px] text-slate-500 mb-1">
          <span>Cihaz sağlığı</span>
          <span className={tenant.device_online > 0 ? 'text-emerald-400 font-bold' : 'text-slate-600'}>
            %{devPct} online
          </span>
        </div>
        <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
          <div className="h-full rounded-full transition-all"
            style={{ width: `${devPct}%`, background: devPct > 50 ? '#22c55e' : devPct > 0 ? '#f59e0b' : '#ef4444' }}/>
        </div>
      </div>

      {/* Active users */}
      {tenantUsers.length > 0 && (
        <div className="mb-3">
          <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">
            Şu An Aktif Kullanıcılar
          </div>
          <div className="space-y-1">
            {tenantUsers.map(u => {
              const mc     = METHOD_COLOR[u.method] || '#94a3b8';
              const target = endpointToTarget(u.endpoint);
              const ri     = ROLE_INFO[u.role] || { label: u.role || '—', color: '#94a3b8' };
              return (
                <div key={u.user_id} className="flex items-center gap-2 bg-slate-800/50 rounded-lg px-3 py-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse flex-shrink-0"/>
                  <span className="text-xs font-semibold text-slate-300 w-[100px] truncate">{u.name || u.email.split('@')[0]}</span>
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full"
                    style={{background:ri.color+'22',color:ri.color}}>{ri.label}</span>
                  <span className="text-[9px] font-black px-1 rounded"
                    style={{background:mc+'22',color:mc}}>{u.method}</span>
                  <span className="text-[9px] text-slate-600 flex-1 truncate">
                    {u.endpoint.replace('/api/v1/','').slice(0,28)}
                  </span>
                  <span className="text-[10px]">{target.icon}</span>
                  <span className="text-[9px] text-slate-600 flex-shrink-0">{u.seconds_ago}s</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Devices */}
      {tenant.devices.length > 0 && (
        <div>
          <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Cihazlar</div>
          <div className="space-y-1.5">
            {tenant.devices.map(d => (
              <div key={d.device_id} className="flex items-center gap-2.5 bg-slate-800/50 rounded-lg px-3 py-2">
                <span className={`w-2 h-2 rounded-full flex-shrink-0 ${d.online ? 'bg-emerald-400' : 'bg-slate-600'}`}/>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-xs text-slate-300">{d.device_id}</span>
                    <span className="text-[10px] text-slate-600 bg-slate-700 px-1.5 rounded">{d.type}</span>
                    {d.variant !== 'standart' && (
                      <span className="text-[10px] text-orange-400 bg-orange-400/10 px-1.5 rounded">{d.variant}</span>
                    )}
                    {d.firmware && <span className="text-[10px] text-slate-600">fw {d.firmware}</span>}
                    {d.ip && <span className="text-[10px] text-slate-600 font-mono">{d.ip}</span>}
                  </div>
                  <div className="text-[10px] text-slate-600 mt-0.5">
                    {d.online ? '🟢 Çevrimiçi' : d.last_seen
                      ? `🔴 ${new Date(d.last_seen).toLocaleString('tr-TR',{dateStyle:'short',timeStyle:'short'})}`
                      : '⚫ Hiç bağlanmadı'}
                  </div>
                </div>
                {d.online
                  ? <Wifi size={12} className="text-emerald-400 flex-shrink-0"/>
                  : <WifiOff size={12} className="text-slate-600 flex-shrink-0"/>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ═════════════════════════════════════════════════════════════════════════════
// Main component
// ═════════════════════════════════════════════════════════════════════════════
interface Props {
  showToast: (m: string, t?: string) => void;
  onNavigate?: (tab: string) => void;
  deployingNodes?: string[];
}

export default function LiveTopology({ showToast, onNavigate, deployingNodes = [] }: Props) {
  const [statuses, setStatuses]             = useState<Record<string, NodeStatus>>({});
  const [events, setEvents]                 = useState<TopoEvent[]>([]);
  const [particles, setParticles]           = useState<Particle[]>([]);
  const [hovered, setHovered]               = useState<string | null>(null);
  const [elapsed, setElapsed]               = useState(0);
  const [loading, setLoading]               = useState(false);
  const [activeFilter, setActiveFilter]     = useState<FilterType>('all');
  const [contextMenu, setContextMenu]       = useState<{ nodeId: string; x: number; y: number } | null>(null);
  const [tenants, setTenants]               = useState<TenantDef[]>([]);
  const [activeUsers, setActiveUsers]       = useState<ActiveUser[]>([]);
  const [selectedTenant, setSelectedTenant] = useState<number | null>(null);
  const [clusterOpen, setClusterOpen]       = useState(true);
  const [highlightPath, setHighlightPath]   = useState<{ nodes: Set<string>; color: string; label: string } | null>(null);
  const [errorNodes, setErrorNodes]         = useState<Set<string>>(new Set());
  const [isFullscreen, setIsFullscreen]     = useState(false);

  const canvasRef          = useRef<HTMLCanvasElement>(null);
  const svgRef             = useRef<SVGSVGElement>(null);
  const containerRef       = useRef<HTMLDivElement>(null);
  const particlesRef       = useRef<Particle[]>([]);
  const activeEdgesRef     = useRef<ActiveEdge[]>([]);
  const rafRef             = useRef<number>();
  const lastIdRef          = useRef(0);
  const failCountRef       = useRef(0);
  const disconnectShownRef = useRef(false);

  particlesRef.current = particles;

  // ── Data fetching ──────────────────────────────────────────────────────
  const fetchSnapshot = useCallback(async () => {
    try { const r = await api.get('/topology/snapshot', BG); setStatuses(r.data.nodes || {}); } catch {}
  }, []);
  const fetchCluster = useCallback(async () => {
    try { const r = await api.get('/topology/cluster', BG); setTenants(r.data.tenants || []); } catch {}
  }, []);
  const fetchUsers = useCallback(async () => {
    try { const r = await api.get('/topology/users', BG); setActiveUsers(r.data.users || []); } catch {}
  }, []);
  const fetchEvents = useCallback(async () => {
    try {
      const r = await api.get('/topology/events', { params: { since_id: lastIdRef.current, limit: 20 }, ...BG });

      // Bağlantı yeniden kuruldu
      if (failCountRef.current > 0) {
        failCountRef.current = 0;
        if (disconnectShownRef.current) {
          disconnectShownRef.current = false;
          showToast('Bağlantı yeniden kuruldu', 'success');
        }
      }

      const incoming: TopoEvent[] = r.data || [];
      if (!incoming.length) return;
      lastIdRef.current = Math.max(...incoming.map(e => e.id));
      setEvents(prev => [...incoming, ...prev].slice(0, 60));

      const newP: Particle[] = [];
      for (const ev of incoming) {
        const from = nodeMap[ev.from_node]; const to = ev.to_node ? nodeMap[ev.to_node] : null;
        if (!from || !to) continue;
        const cfg = EVENT_CFG[ev.event_type] || EVENT_CFG.health;
        newP.push({ id: ++_pid, fromId: ev.from_node, toId: ev.to_node!, progress: 0, color: cfg.color, speed: .35 + Math.random() * .25, size: 5 });

        // Hata olayı: node'u 30s kırmızı yanıp söndür
        if (ev.event_type === 'error') {
          const errId = ev.from_node || 'backend-s1';
          setErrorNodes(prev => new Set([...prev, errId]));
          setTimeout(() => setErrorNodes(prev => { const n = new Set(prev); n.delete(errId); return n; }), 30000);
        }
      }
      if (newP.length) setParticles(prev => { const c=[...prev,...newP]; return c.length>150?c.slice(-150):c; });

      // Neon path highlight: son olaydan path hesapla
      if (incoming.length > 0) {
        const ev = incoming[incoming.length - 1];
        const pathMap: Record<string, string[]> = {
          upload:    ['nginx','backend-s1','postgres','minio-s1'],
          download:  ['nginx','backend-s1','postgres'],
          replicate: ['backend-s1','backend-s2','minio-s1','minio-s2'],
          backup:    ['backend-s1','minio-s1','sftp','s3-ext'],
          delete:    ['nginx','backend-s1','postgres'],
          health:    ['nginx','backend-s1'],
          error:     [ev.from_node||'backend-s1'],
        };
        const colMap: Record<string,string> = {
          upload:'#22c55e', download:'#3b82f6', replicate:'#f97316',
          backup:'#eab308', delete:'#ef4444', error:'#ef4444', health:'#a855f7',
        };
        const nodes = pathMap[ev.event_type];
        if (nodes) {
          const label = ev.message || ev.event_type;
          setHighlightPath({ nodes: new Set(nodes), color: colMap[ev.event_type]||'#94a3b8', label });
          showToast(`Yol: ${label}`, ev.event_type === 'error' ? 'error' : 'success');
          setTimeout(() => setHighlightPath(null), 3500);
        }
      }
    } catch {
      failCountRef.current++;
      if (failCountRef.current >= 3 && !disconnectShownRef.current) {
        disconnectShownRef.current = true;
        showToast('Bağlantı sorunu, yeniden deneniyor…', 'error');
      }
    }
  }, [showToast]);

  useEffect(() => { fetchSnapshot(); const t = setInterval(fetchSnapshot, 15000); return () => clearInterval(t); }, [fetchSnapshot]);
  useEffect(() => { fetchCluster();  const t = setInterval(fetchCluster,  20000); return () => clearInterval(t); }, [fetchCluster]);
  useEffect(() => { fetchUsers();    const t = setInterval(fetchUsers,    4000);  return () => clearInterval(t); }, [fetchUsers]);
  useEffect(() => { const t = setInterval(fetchEvents, 2000); return () => clearInterval(t); }, [fetchEvents]);
  useEffect(() => { const t = setInterval(() => setElapsed(s => s + 1), 1000); return () => clearInterval(t); }, []);

  // ── Fullscreen ─────────────────────────────────────────────────────────
  useEffect(() => {
    const handler = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', handler);
    return () => document.removeEventListener('fullscreenchange', handler);
  }, []);

  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
  }, []);

  // ── Canvas RAF ─────────────────────────────────────────────────────────
  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d')!; let last = performance.now();
    const frame = (now: number) => {
      const dt = Math.min((now - last) / 1000, 0.08); last = now;
      const cr = canvas.getBoundingClientRect();
      const cw = Math.round(cr.width) || 800, ch = Math.round(cr.height) || 520;
      if (canvas.width !== cw || canvas.height !== ch) { canvas.width = cw; canvas.height = ch; }
      ctx.clearRect(0, 0, cw, ch);
      const ctm = svgRef.current?.getScreenCTM();
      if (!ctm) { rafRef.current = requestAnimationFrame(frame); return; }
      ctx.save();
      ctx.setTransform(ctm.a, ctm.b, ctm.c, ctm.d, ctm.e - cr.left, ctm.f - cr.top);
      activeEdgesRef.current = activeEdgesRef.current.filter(e => e.until > now);
      for (const ae of activeEdgesRef.current) {
        const [fId, tId] = ae.key.split('→');
        const fn = nodeMap[fId], tn = nodeMap[tId]; if (!fn || !tn) continue;
        const cp = ctrlPt(fn, tn); const age = 1 - Math.max(0, (ae.until - now) / 800);
        ctx.save(); ctx.shadowColor = ae.color; ctx.shadowBlur = 12;
        ctx.strokeStyle = ae.color; ctx.lineWidth = 3; ctx.globalAlpha = .5 * (1 - age * age);
        ctx.beginPath(); ctx.moveTo(fn.x, fn.y); ctx.quadraticCurveTo(cp.x, cp.y, tn.x, tn.y); ctx.stroke();
        ctx.restore();
      }
      const next: Particle[] = [];
      for (const p of particlesRef.current) {
        p.progress = Math.min(1, p.progress + p.speed * dt);
        const from = nodeMap[p.fromId], to = nodeMap[p.toId]; if (!from || !to) continue;
        const pos = bezierPoint(p.progress, from, to);
        const alpha = p.progress > .85 ? (1 - p.progress) / .15 : 1;
        const eKey = `${p.fromId}→${p.toId}`;
        const ex = activeEdgesRef.current.find(e => e.key === eKey);
        if (ex) ex.until = now + 800; else activeEdgesRef.current.push({ key: eKey, color: p.color, until: now + 800 });
        ctx.save(); ctx.shadowColor = p.color; ctx.shadowBlur = 20; ctx.globalAlpha = alpha;
        ctx.beginPath(); ctx.arc(pos.x, pos.y, p.size, 0, Math.PI * 2); ctx.fillStyle = p.color; ctx.fill();
        const pp = bezierPoint(Math.max(0, p.progress - .08), from, to);
        ctx.globalAlpha = alpha * .4;
        ctx.beginPath(); ctx.arc(pp.x, pp.y, p.size * .6, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
        if (p.progress < 1) next.push(p);
      }
      ctx.restore();
      const pl = particlesRef.current.length; particlesRef.current = next;
      if (next.length !== pl) setParticles([...next]);
      rafRef.current = requestAnimationFrame(frame);
    };
    rafRef.current = requestAnimationFrame(frame);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, []);

  // ── Helpers ────────────────────────────────────────────────────────────
  const statusColor = (id: string) => {
    const s = statuses[id]; if (!s) return '#334155';
    return s.status==='ok'?'#22c55e':s.status==='warn'?'#eab308':s.status==='error'?'#ef4444':'#64748b';
  };
  const fmtTime = (s: number) =>
    `${Math.floor(s/60).toString().padStart(2,'0')}:${(s%60).toString().padStart(2,'0')}`;

  const handleManualRefresh = async () => {
    setLoading(true);
    await Promise.all([fetchSnapshot(), fetchCluster(), fetchUsers()]);
    setLoading(false); showToast('Durum güncellendi', 'success');
  };

  const handleScreenshot = useCallback(() => {
    const svgEl = svgRef.current, canvas = canvasRef.current;
    if (!svgEl || !canvas) return;
    setHovered('__ss__');
    requestAnimationFrame(() => {
      const d = new XMLSerializer().serializeToString(svgEl); setHovered(null);
      const blob = new Blob([d], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const img = new Image();
      img.onload = () => {
        const out = document.createElement('canvas'); out.width = 800; out.height = 800;
        const ctx = out.getContext('2d')!; ctx.fillStyle = '#020617'; ctx.fillRect(0,0,800,520);
        ctx.drawImage(img, 0, 0); ctx.drawImage(canvas, 0, 0); URL.revokeObjectURL(url);
        const a = document.createElement('a');
        a.download = `topoloji-${new Date().toISOString().slice(0,19).replace(/:/g,'-')}.png`;
        a.href = out.toDataURL('image/png'); a.click();
      };
      img.src = url;
    });
  }, []);

  const nodeVisible = useCallback((t: NodeDef['type']) => {
    const f = FILTERS.find(f => f.id === activeFilter);
    if (!f || f.types.length === 0) return 1;
    return f.types.includes(t) ? 1 : 0.15;
  }, [activeFilter]);

  const edgeVisible = useCallback((from: string, to: string) => {
    const f = FILTERS.find(f => f.id === activeFilter);
    if (!f || f.types.length === 0) return true;
    return f.types.includes(nodeMap[from]?.type) || f.types.includes(nodeMap[to]?.type);
  }, [activeFilter]);

  const selectedTenantData = tenants.find(t => t.id === selectedTenant) || null;

  // Radyal SVG — sabit 800×800, merkez (400,400)
  // Katmanlı layout sabitleri (SVG 1100x650)
  const DEALER_X = 270, USER_X = 90;
  const VIS_T = tenants.slice(0, 10);
  const NT    = VIS_T.length;
  const DEALER_Y_MIN = 70, DEALER_Y_MAX = 580;
  const dealerY   = (i: number) => NT <= 1 ? 325 : Math.round(DEALER_Y_MIN + i * (DEALER_Y_MAX - DEALER_Y_MIN) / (NT - 1));
  const dealerPos = (i: number) => ({ x: DEALER_X, y: dealerY(i) });

  // Aktif kullanıcının hedef node'u endpoint'ten tespit et
  const userTargetNodes = (endpoint: string, method: string): string[] => {
    const ep = endpoint.replace('/api/v1/', '');
    const isWrite = ['POST','PUT','PATCH','DELETE'].includes(method);
    if (ep.startsWith('products') || ep.startsWith('finance') || ep.startsWith('categories'))
      return isWrite ? ['backend-s1','postgres','minio-s1'] : ['backend-s1','postgres'];
    if (ep.startsWith('files') || ep.startsWith('backup'))
      return ['backend-s1','minio-s1','s3-ext'];
    return ['nginx','backend-s1'];
  };

  // ── Render ─────────────────────────────────────────────────────────────
  return (
    <div ref={containerRef}
      className={`space-y-3${isFullscreen ? ' bg-slate-950 p-4 overflow-y-auto' : ''}`}
      style={isFullscreen ? { background: '#020617', minHeight: '100vh' } : undefined}>

      {/* ── Header ── */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"/>
            <h2 className={`text-lg font-black tracking-tight ${isFullscreen ? 'text-white' : 'text-slate-800 dark:text-white'}`}>
              CANLI SİSTEM HARİTASI
            </h2>
          </div>
          <span className="text-xs text-slate-500 font-mono bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
            ⏱ {fmtTime(elapsed)}
          </span>
          <span className="text-xs text-slate-500 hidden sm:inline">
            {tenants.length} dükkan · {tenants.reduce((a,t)=>a+t.device_total,0)} cihaz · {activeUsers.length} aktif kullanıcı
          </span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 rounded-lg p-0.5">
            {FILTERS.map(f => (
              <button key={f.id} onClick={() => setActiveFilter(f.id)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition ${
                  activeFilter===f.id?'bg-indigo-600 text-white shadow-sm':'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}>
                {f.label}
              </button>
            ))}
          </div>
          <button onClick={handleScreenshot} title="PNG olarak indir"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-sm font-semibold transition">
            <Camera size={13}/>
          </button>
          <button onClick={handleManualRefresh} disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-sm font-semibold transition">
            <RefreshCw size={13} className={loading?'animate-spin':''}/> Yenile
          </button>
          <button onClick={toggleFullscreen}
            title={isFullscreen ? 'Tam ekrandan çık (Esc)' : 'Tam ekran'}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-semibold transition ${
              isFullscreen
                ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}>
            {isFullscreen ? <Minimize2 size={13}/> : <Maximize2 size={13}/>}
          </button>
        </div>
      </div>

      {/* ── Main Infra SVG ── */}
      <div className="relative rounded-2xl overflow-hidden border border-slate-700/60"
        style={{ background: '#020617', height: isFullscreen ? 'calc(100vh - 120px)' : 650 }}
        onClick={() => setContextMenu(null)}>

        <svg ref={svgRef} viewBox="0 0 1100 650" preserveAspectRatio="xMidYMid meet"
          className="absolute inset-0 w-full h-full">
          <defs>
            <style>{`
              @keyframes dash{to{stroke-dashoffset:-16}}
              .flow{animation:dash 1.2s linear infinite}
              .flow-rev{animation:dash 1.2s linear infinite reverse}
              @keyframes pulse-glow{0%,100%{opacity:.7}50%{opacity:1}}
              .neon-pulse{animation:pulse-glow 1s ease-in-out infinite}
              @keyframes err-blink{0%,100%{opacity:.85;stroke-width:2.5}50%{opacity:.1;stroke-width:1}}
              .err-blink{animation:err-blink 0.65s ease-in-out infinite}
            `}</style>
            <radialGradient id="bg-grad" cx="50%" cy="35%" r="65%">
              <stop offset="0%" stopColor="#0f172a"/><stop offset="100%" stopColor="#020617"/>
            </radialGradient>
            {/* Neon glow filtresi */}
            <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="4" result="blur"/>
              <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
            </filter>
            <filter id="glow-strong" x="-80%" y="-80%" width="260%" height="260%">
              <feGaussianBlur stdDeviation="8" result="blur"/>
              <feMerge><feMergeNode in="blur"/><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
            </filter>
          </defs>

          <rect width="1100" height="650" fill="url(#bg-grad)"/>

          {/* Katman arka plan şeritleri */}
          <rect x={0}   y={0} width={183} height={650} fill="#8b5cf6" fillOpacity={0.018}/>
          <rect x={183} y={0} width={185} height={650} fill="#06b6d4" fillOpacity={0.018}/>
          <rect x={368} y={0} width={200} height={650} fill="#94a3b8" fillOpacity={0.012}/>
          <rect x={568} y={0} width={200} height={650} fill="#8b5cf6" fillOpacity={0.018}/>
          <rect x={768} y={0} width={332} height={650} fill="#10b981" fillOpacity={0.015}/>

          {/* Katman ayraçları */}
          {[183, 368, 568, 768].map(x => (
            <line key={x} x1={x} y1={0} x2={x} y2={650}
              stroke="#1e293b" strokeWidth={0.8} strokeDasharray="4 10"/>
          ))}

          {/* Katman başlıkları */}
          {[
            { x: 91,  label: 'UÇ NOKTALAR' },
            { x: 275, label: 'BAYİLER' },
            { x: 468, label: 'AĞ GEÇİDİ' },
            { x: 668, label: 'UYGULAMA' },
            { x: 934, label: 'VERİ & DEPOLAMA' },
          ].map(l => (
            <text key={l.x} x={l.x} y={18} textAnchor="middle"
              fill="#1e3a5f" fontSize={8} fontWeight="900" letterSpacing="1.5"
              style={{userSelect:'none'}}>{l.label}</text>
          ))}

          {/* Nokta ızgarası */}
          {Array.from({length:12},(_,i)=>Array.from({length:8},(_,j)=>(
            <circle key={`${i}-${j}`} cx={i*100+50} cy={j*90+40} r={0.7} fill="#1e293b"/>
          )))}

          {/* Edges */}
          {EDGES.map(edge => {
            const a = nodeMap[edge.from], b = nodeMap[edge.to]; if (!a || !b) return null;
            const col = statusColor(edge.from);
            const isHL = highlightPath
              ? (highlightPath.nodes.has(edge.from) && highlightPath.nodes.has(edge.to))
              : false;
            const dimmed = highlightPath && !isHL;
            const baseOp = edgeVisible(edge.from, edge.to) ? 1 : 0.06;
            return (
              <g key={`${edge.from}-${edge.to}`} opacity={dimmed ? 0.04 : baseOp}>
                <path d={svgPath(a,b)} stroke="#1e293b" strokeWidth={2} fill="none"/>
                {isHL ? (
                  <>
                    {/* Neon glow katmanı */}
                    <path d={svgPath(a,b)} stroke={highlightPath!.color} strokeWidth={6} fill="none"
                      opacity={0.25} filter="url(#glow-strong)"/>
                    <path d={svgPath(a,b)} stroke={highlightPath!.color} strokeWidth={2.5} fill="none"
                      strokeDasharray="5 8" className="flow neon-pulse" filter="url(#glow)"/>
                  </>
                ) : (
                  <path d={svgPath(a,b)} stroke={col} strokeWidth={1.5} fill="none"
                    strokeDasharray="3 13" opacity={.5} className="flow"/>
                )}
                {edge.reverse && !isHL && (
                  <path d={svgPath(b,a)} stroke={statusColor(edge.to)} strokeWidth={1.5} fill="none"
                    strokeDasharray="3 13" opacity={.3} className="flow-rev"/>
                )}
              </g>
            );
          })}

          {/* Nodes */}
          {NODE_DEFS.map(node => {
            const st  = statuses[node.id];
            const col = statusColor(node.id);
            const isH = hovered === node.id;
            const R   = node.id === 'internet' ? 26 : 20;
            const op  = nodeVisible(node.type);
            const isNodeHL = highlightPath?.nodes.has(node.id) ?? false;
            const nodeDim  = highlightPath && !isNodeHL ? 0.12 : 1;
            return (
              <g key={node.id} transform={`translate(${node.x},${node.y})`}
                opacity={Math.min(op, nodeDim)}
                onMouseEnter={() => setHovered(node.id)}
                onMouseLeave={() => setHovered(null)}
                onContextMenu={e => {
                  e.preventDefault();
                  if (CONTEXT_ITEMS[node.id]) setContextMenu({ nodeId: node.id, x: e.clientX, y: e.clientY });
                }}
                style={{ cursor: CONTEXT_ITEMS[node.id] ? 'context-menu' : 'pointer' }}>

                {errorNodes.has(node.id) && !isNodeHL && (
                  <circle r={R+16} fill="none" stroke="#ef4444" strokeWidth={2.5}
                    filter="url(#glow)" className="err-blink"/>
                )}
                {isNodeHL && highlightPath && (
                  <circle r={R+14} fill="none" stroke={highlightPath.color} strokeWidth={2.5}
                    opacity={0.6} filter="url(#glow-strong)" className="neon-pulse"/>
                )}

                <circle r={R} fill="#0f172a" stroke={col} strokeWidth={isH?2.5:1.5}/>
                <text textAnchor="middle" dominantBaseline="central" fontSize={15} style={{userSelect:'none'}}>
                  {TYPE_ICON[node.type]}
                </text>
                <text y={R+11} textAnchor="middle" fill="#e2e8f0" fontSize={9.5} fontWeight="600" style={{userSelect:'none'}}>
                  {node.label}
                </text>
                {node.sublabel && (
                  <text y={R+21} textAnchor="middle" fill="#64748b" fontSize={7.5} style={{userSelect:'none'}}>
                    {node.sublabel}
                  </text>
                )}
                <circle cx={R-4} cy={-(R-4)} r={4.5} fill={col}/>
                {st?.status==='ok' && <circle cx={R-4} cy={-(R-4)} r={3} fill="#020617"/>}

                {node.id==='devices' && st?.online !== undefined && (
                  <text x={0} y={-(R+5)} textAnchor="middle"
                    fill={st.online>0?'#22c55e':'#64748b'} fontSize={7} fontWeight="700">
                    {st.online}/{st.total} cihaz
                  </text>
                )}
                {(node.id==='backend-s1'||node.id==='backend-s2') && tenants.length>0 && (
                  <text x={0} y={-(R+5)} textAnchor="middle" fill="#8b5cf6" fontSize={7} fontWeight="700">
                    {tenants.length} dükkan
                  </text>
                )}
                {(node.id==='backend-s1'||node.id==='backend-s2') && activeUsers.length>0 && (
                  <text x={0} y={-(R+15)} textAnchor="middle" fill="#1d4ed8" fontSize={6.5} fontWeight="700">
                    {activeUsers.length} aktif kullanıcı
                  </text>
                )}
                {st?.load !== undefined && (
                  <text x={0} y={R+33} textAnchor="middle" fill="#475569" fontSize={7}>
                    CPU {st.load} · RAM %{st.ram_pct}
                  </text>
                )}
                {st?.latency_ms !== undefined && st.latency_ms>0 && (
                  <text x={R-4} y={-(R+5)} textAnchor="middle" fill={col} fontSize={7} fontWeight="700">
                    {st.latency_ms}ms
                  </text>
                )}

                {isH && (
                  <g transform={`translate(${node.x<=400?30:-182},-80)`}>
                    <rect x={0} y={0} width={152}
                      height={st?(st.disk_pct!==undefined?108:st.ram_pct!==undefined?96:st.online!==undefined?84:52):44}
                      rx={8} fill="#0f172a" stroke={col} strokeWidth={1}/>
                    <text x={10} y={16} fill="white" fontSize={10} fontWeight="700">{st?.label||node.label}</text>
                    <text x={10} y={29} fill={col} fontSize={9} fontWeight="600">
                      {st?.status==='ok'?'✓ Sağlıklı':st?.status==='warn'?'⚠ Uyarı':st?.status==='error'?'✗ Hata':'? Bilinmiyor'}
                    </text>
                    {st?.online!==undefined && (
                      <text x={10} y={42} fill="#94a3b8" fontSize={8}>
                        Çevrimiçi: <tspan fill={st.online>0?'#22c55e':'#ef4444'}>{st.online}</tspan>/{st.total}
                      </text>
                    )}
                    {st?.latency_ms!==undefined && <text x={10} y={42} fill="#94a3b8" fontSize={8}>Gecikme: {st.latency_ms}ms</text>}
                    {st?.load!==undefined && <text x={10} y={st.latency_ms!==undefined?54:42} fill="#94a3b8" fontSize={8}>CPU: {st.load}</text>}
                    {st?.ram_pct!==undefined && <text x={10} y={st.load!==undefined?66:42} fill="#94a3b8" fontSize={8}>RAM: %{st.ram_pct}</text>}
                    {st?.disk_pct!==undefined && (
                      <text x={10} y={st.ram_pct!==undefined?80:66}
                        fill={st.disk_pct>80?'#ef4444':'#94a3b8'} fontSize={8}>Disk: %{st.disk_pct}</text>
                    )}
                  </g>
                )}
              </g>
            );
          })}

          {/* ── Katman 2: Bayiler (x=270) ── */}
          {VIS_T.length === 0 && (
            <text x={270} y={325} textAnchor="middle" fill="#1e3a5f" fontSize={9}
              style={{userSelect:'none'}}>Kayıtlı bayi yok</text>
          )}
          {VIS_T.map((t, i) => {
            const dp      = dealerPos(i);
            const pkgCol  = PACKAGE_COLOR[t.package as keyof typeof PACKAGE_COLOR] || PACKAGE_COLOR.default;
            const tu      = activeUsers.filter(u => u.tenant_id === t.id);
            const hasOnl  = t.device_online > 0 || tu.length > 0;
            // Bayi → İnternet bağlantısı
            const ix = 470, iy = 195;
            const bPath = `M ${dp.x} ${dp.y} C ${(dp.x+ix)/2} ${dp.y}, ${(dp.x+ix)/2} ${iy}, ${ix} ${iy}`;
            return (
              <g key={`dt-${t.id}`}>
                {/* Bayi → İnternet kenar */}
                <path d={bPath} fill="none" stroke="#1e293b" strokeWidth={1}/>
                <path d={bPath} fill="none" stroke={pkgCol} strokeWidth={0.8}
                  opacity={hasOnl ? .35 : .08} strokeDasharray="3 8" className="flow"/>
                {hasOnl && (
                  <circle r={2} fill={pkgCol} opacity={.8}>
                    <animateMotion dur={`${2 + i * 0.15}s`} begin={`${i * 0.2}s`}
                      repeatCount="indefinite" path={bPath}/>
                  </circle>
                )}
                {/* Bayi düğümü */}
                {hasOnl && (
                  <circle cx={dp.x} cy={dp.y} r={22} fill="none" stroke={pkgCol} strokeWidth={0.5} opacity={0.2}>
                    <animate attributeName="r" values="19;27;19" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values=".2;0;.2" dur="3s" repeatCount="indefinite"/>
                  </circle>
                )}
                <circle cx={dp.x} cy={dp.y} r={17}
                  fill={hasOnl ? '#0f1d35' : '#0a0f1a'}
                  stroke={hasOnl ? pkgCol : '#1e293b'} strokeWidth={1.5}/>
                <text x={dp.x} y={dp.y} textAnchor="middle" dominantBaseline="central"
                  fontSize={10} style={{userSelect:'none'}}>🏪</text>
                {/* İsim — sağ tarafa */}
                <text x={dp.x + 22} y={dp.y - 3} textAnchor="start" fill="#94a3b8"
                  fontSize={7.5} fontWeight="700" style={{userSelect:'none'}}>
                  {(t.company || t.name).slice(0, 12)}
                </text>
                <text x={dp.x + 22} y={dp.y + 7} textAnchor="start"
                  fill={hasOnl ? '#22c55e' : '#334155'} fontSize={6} style={{userSelect:'none'}}>
                  {t.device_online}/{t.device_total} cihaz · {tu.length} kullanıcı
                </text>
                {/* Aktif kullanıcı badge */}
                {tu.length > 0 && (
                  <g transform={`translate(${dp.x + 13}, ${dp.y - 13})`}>
                    <circle r={6} fill="#1d4ed8" stroke="#020617" strokeWidth={0.8}/>
                    <text textAnchor="middle" dominantBaseline="central" fill="white"
                      fontSize={5.5} fontWeight="900" style={{userSelect:'none'}}>
                      {tu.length > 9 ? '9+' : tu.length}
                    </text>
                  </g>
                )}
              </g>
            );
          })}

          {/* ── Katman 1: Kullanıcılar (x=90) ── */}
          {VIS_T.flatMap((t, i) => {
            const dp = dealerPos(i);
            const tu = activeUsers.filter(u => u.tenant_id === t.id).slice(0, 4);
            return tu.map((u, ui) => {
              const uy    = dp.y + (ui - (tu.length - 1) / 2) * 40;
              const ux    = USER_X;
              const mc    = METHOD_COLOR[u.method as keyof typeof METHOD_COLOR] || '#94a3b8';
              const fresh = u.seconds_ago < 30;
              const inits = (u.name || u.email.split('@')[0]).slice(0, 2).toUpperCase();
              const ri    = ROLE_INFO[u.role] || { label: '?', color: '#94a3b8' };
              const uPath = `M ${ux} ${uy} C ${(ux+dp.x)/2} ${uy}, ${(ux+dp.x)/2} ${dp.y}, ${dp.x-17} ${dp.y}`;
              return (
                <g key={`du-${u.user_id}-${ui}`}>
                  {/* Kullanıcı → Bayi */}
                  <path d={uPath} fill="none" stroke="#1e293b" strokeWidth={0.7}/>
                  <path d={uPath} fill="none" stroke={mc} strokeWidth={0.8}
                    opacity={fresh ? .5 : .15} strokeDasharray="2 6" className={fresh ? 'flow' : ''}/>
                  {fresh && (
                    <circle r={2} fill={mc} opacity={.9}>
                      <animateMotion dur={`.65s`} begin={`${ui * 0.12}s`}
                        repeatCount="indefinite" path={uPath}/>
                    </circle>
                  )}
                  {/* Kullanıcı düğümü */}
                  {fresh && (
                    <circle cx={ux} cy={uy} r={14} fill="none" stroke={mc} strokeWidth={0.7}>
                      <animate attributeName="r" values="12;18;12" dur="1.5s" repeatCount="indefinite"/>
                      <animate attributeName="opacity" values=".3;0;.3" dur="1.5s" repeatCount="indefinite"/>
                    </circle>
                  )}
                  <circle cx={ux} cy={uy} r={11} fill="#0a0f1a"
                    stroke={fresh ? mc : '#1e293b'} strokeWidth={fresh ? 1.4 : 0.6}/>
                  <text x={ux} y={uy} textAnchor="middle" dominantBaseline="central"
                    fill={fresh ? '#f1f5f9' : '#475569'} fontSize={6} fontWeight="800"
                    style={{userSelect:'none'}}>{inits}</text>
                  {/* İsim + metod — sağ tarafa */}
                  <text x={ux + 15} y={uy - 3} textAnchor="start"
                    fill={fresh ? '#cbd5e1' : '#475569'} fontSize={7} fontWeight="700"
                    style={{userSelect:'none'}}>{(u.name||u.email.split('@')[0]).slice(0,10)}</text>
                  <text x={ux + 15} y={uy + 6} textAnchor="start" fill={mc} fontSize={5.5} fontWeight="800"
                    style={{userSelect:'none'}}>{u.method}</text>
                  <text x={ux + 15} y={uy + 14} textAnchor="start" fill="#334155" fontSize={5}
                    style={{userSelect:'none'}}>
                    {u.endpoint.replace('/api/v1/','').replace(/\/\d+/g,'/…').slice(0,13)}
                  </text>
                  {/* Rol rozeti */}
                  <rect x={ux - 11} y={uy - 20} width={22} height={8} rx={2}
                    fill={ri.color+'22'} stroke={ri.color+'44'} strokeWidth={0.5}/>
                  <text x={ux} y={uy - 14} textAnchor="middle" fill={ri.color} fontSize={4.5} fontWeight="800"
                    style={{userSelect:'none'}}>{ri.label.slice(0,7)}</text>
                </g>
              );
            });
          })}

          {/* Eşleşmeyen kullanıcılar (süper admin vs) → Direkt İnternet'e */}
          {activeUsers.filter(u => !VIS_T.some(t => t.id === u.tenant_id)).slice(0, 3).map((u, ui) => {
            const ux = USER_X, uy = 55 + ui * 55;
            const mc = METHOD_COLOR[u.method as keyof typeof METHOD_COLOR] || '#94a3b8';
            const fresh = u.seconds_ago < 30;
            const inits = (u.name || u.email.split('@')[0]).slice(0, 2).toUpperCase();
            const sPath = `M ${ux} ${uy} C ${(ux+470)/2} ${uy}, ${(ux+470)/2} 195, 470 195`;
            return (
              <g key={`sa-${u.user_id}`}>
                <path d={sPath} fill="none" stroke="#1e293b" strokeWidth={0.6}/>
                <path d={sPath} fill="none" stroke={mc} strokeWidth={0.7}
                  opacity={fresh ? .4 : .1} strokeDasharray="2 6" className={fresh ? 'flow' : ''}/>
                <circle cx={ux} cy={uy} r={10} fill="#0a0f1a"
                  stroke={fresh ? mc : '#1e293b'} strokeWidth={fresh ? 1.2 : 0.5}/>
                <text x={ux} y={uy} textAnchor="middle" dominantBaseline="central"
                  fill={fresh ? '#f1f5f9' : '#475569'} fontSize={5.5} fontWeight="800"
                  style={{userSelect:'none'}}>{inits}</text>
                <text x={ux + 14} y={uy} textAnchor="start" fill="#475569" fontSize={6}
                  style={{userSelect:'none'}}>{u.role==='super_admin'?'SA':'USR'}</text>
              </g>
            );
          })}

        </svg>

        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none"/>

        {/* Renk lejantı — sol alt */}
        <div className="absolute bottom-3 left-3 flex flex-col gap-0.5">
          {Object.entries(EVENT_CFG).slice(0,5).map(([k,v])=>(
            <div key={k} className="flex items-center gap-1.5 text-[9px] text-slate-600">
              <span>{v.emoji}</span><span>{v.label}</span>
            </div>
          ))}
        </div>

        {/* ── Olay Akışı Ticker (sağ alt köşe overlay) ── */}
        <div className="absolute bottom-3 right-3 w-64 flex flex-col rounded-xl overflow-hidden border border-slate-700/70"
          style={{ background: 'rgba(2,6,23,0.90)', backdropFilter: 'blur(8px)', maxHeight: 220 }}>
          <div className="flex items-center gap-1.5 px-3 py-1.5 border-b border-slate-700/60 flex-shrink-0">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"/>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Olay Akışı</span>
            <span className="text-[9px] text-slate-600 ml-auto font-mono">{events.length} kayıt</span>
          </div>
          {events.length === 0 ? (
            <div className="flex items-center justify-center py-5 text-slate-600 text-[10px] font-mono">
              Olay bekleniyor…
            </div>
          ) : (
            <div className="overflow-y-auto flex-1 divide-y divide-slate-800/40">
              {events.slice(0, 12).map(ev => {
                const cfg = EVENT_CFG[ev.event_type] || { emoji: '⚪', color: '#94a3b8', label: ev.event_type };
                const ts  = new Date(ev.created_at).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                const tickerPathMap: Record<string, string[]> = {
                  upload:    ['nginx','backend-s1','postgres','minio-s1'],
                  download:  ['nginx','backend-s1','postgres'],
                  replicate: ['backend-s1','backend-s2','minio-s1','minio-s2'],
                  backup:    ['backend-s1','minio-s1','sftp','s3-ext'],
                  delete:    ['nginx','backend-s1','postgres'],
                  health:    ['nginx','backend-s1'],
                  error:     [ev.from_node || 'backend-s1'],
                };
                const hlNodes = tickerPathMap[ev.event_type] || ['backend-s1'];
                return (
                  <button key={ev.id}
                    onClick={() => {
                      const lbl = ev.message || ev.event_type;
                      setHighlightPath({ nodes: new Set(hlNodes), color: cfg.color, label: lbl });
                      showToast(`Yol: ${lbl}`, ev.event_type === 'error' ? 'error' : 'info');
                      setTimeout(() => setHighlightPath(null), 3500);
                    }}
                    className="w-full text-left px-2.5 py-1.5 hover:bg-slate-800/60 transition group">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span className="text-[11px] flex-shrink-0">{cfg.emoji}</span>
                      <span className="text-[9px] text-slate-600 font-mono flex-shrink-0 tabular-nums">{ts}</span>
                      <span className="text-[9px] font-bold flex-shrink-0 truncate" style={{ color: cfg.color }}>
                        {(cfg as typeof EVENT_CFG[string] & {label:string}).label || ev.event_type}
                      </span>
                    </div>
                    <div className="text-[9px] text-slate-500 truncate pl-5 group-hover:text-slate-300 transition-colors">
                      {ev.message || [ev.from_node, ev.to_node].filter(Boolean).join(' → ')}
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Active user badge */}
        {activeUsers.length > 0 && (
          <div className="absolute top-3 right-3 flex items-center gap-1.5 bg-violet-900/60 border border-violet-700/40 rounded-lg px-2.5 py-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-violet-400 animate-pulse"/>
            <span className="text-[11px] font-bold text-violet-300">{activeUsers.length} kullanıcı aktif</span>
          </div>
        )}

        {/* Context menu */}
        {contextMenu && CONTEXT_ITEMS[contextMenu.nodeId] && (
          <div className="fixed z-50 bg-slate-900 border border-slate-600 rounded-xl shadow-2xl overflow-hidden py-1 min-w-[160px]"
            style={{ top: contextMenu.y, left: contextMenu.x }}
            onClick={e => e.stopPropagation()}>
            <div className="px-3 py-1.5 border-b border-slate-700/60 mb-0.5">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                {nodeMap[contextMenu.nodeId]?.label}
              </span>
            </div>
            {CONTEXT_ITEMS[contextMenu.nodeId].map(item => (
              <button key={item.tab}
                onClick={() => { setContextMenu(null); onNavigate?.(item.tab); }}
                className="w-full text-left px-3 py-2 text-[12px] font-bold text-slate-200 hover:bg-indigo-600 hover:text-white transition">
                {item.label}
              </button>
            ))}
            <div className="border-t border-slate-700/60 mt-0.5">
              <button onClick={() => setContextMenu(null)}
                className="w-full text-left px-3 py-1.5 text-[11px] text-slate-500 hover:text-slate-300 transition">
                Kapat
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ══════════════════════════════════════════════════════════════
           BAYİLER + KULLANICILAR — yan yana, temiz
      ══════════════════════════════════════════════════════════════ */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-3">

        {/* ── BAYİLER (3/5) ── */}
        <div className="lg:col-span-3 bg-slate-900 rounded-2xl border border-slate-700 overflow-hidden flex flex-col">
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-700/60 flex-shrink-0">
            <div className="flex items-center gap-2.5">
              <span className="w-2 h-2 rounded-full bg-violet-500 animate-pulse"/>
              <span className="text-sm font-black text-white">BAYİLER</span>
              <span className="text-[11px] text-slate-500">{tenants.length} kayıtlı · {tenants.filter(t=>t.device_online>0).length} online</span>
            </div>
            <span className="text-[10px] text-slate-600 font-mono">4s</span>
          </div>

          {tenants.length === 0 ? (
            <div className="flex items-center justify-center py-12 text-slate-600 text-sm font-mono flex-1">
              Kayıtlı bayi yok
            </div>
          ) : (
            <div className="overflow-y-auto max-h-[520px]">
              {tenants.map(t => {
                const pkgColor = PACKAGE_COLOR[t.package] || PACKAGE_COLOR.default;
                const tu       = activeUsers.filter(u => u.tenant_id === t.id);
                const devPct   = t.device_total > 0 ? Math.round(t.device_online / t.device_total * 100) : 0;
                const subColor = t.sub_days > 30 ? '#22c55e' : t.sub_days > 7 ? '#f59e0b' : '#ef4444';
                const subPct   = Math.min(Math.round(t.sub_days / 90 * 100), 100);
                const isOnline = t.device_online > 0 || tu.length > 0;
                return (
                  <div key={t.id} className={`px-4 py-3 border-b border-slate-800/50 ${isOnline ? 'bg-violet-950/10' : ''}`}>
                    {/* Başlık satırı */}
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`w-2 h-2 rounded-full flex-shrink-0 ${isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'}`}/>
                      <span className="font-bold text-sm text-white truncate flex-1">{t.company || t.name}</span>
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded flex-shrink-0"
                        style={{ background: pkgColor+'22', color: pkgColor }}>{t.package}</span>
                      {tu.length > 0 && (
                        <span className="text-[10px] font-bold text-blue-300 bg-blue-500/10 px-1.5 py-0.5 rounded flex-shrink-0">
                          {tu.length} aktif
                        </span>
                      )}
                    </div>

                    {/* İki mini bar */}
                    <div className="grid grid-cols-2 gap-3 mb-2">
                      <div>
                        <div className="flex justify-between text-[9px] mb-1">
                          <span className="text-slate-500">Cihaz</span>
                          <span className={t.device_online > 0 ? 'text-emerald-400' : 'text-slate-600'}>
                            {t.device_online}/{t.device_total}
                          </span>
                        </div>
                        <div className="h-1 bg-slate-700 rounded-full overflow-hidden">
                          <div className="h-full rounded-full" style={{ width:`${devPct}%`, background: t.device_online > 0 ? '#22c55e' : '#475569' }}/>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-[9px] mb-1">
                          <span className="text-slate-500">Abonelik</span>
                          <span style={{ color: subColor }}>{t.sub_days}g</span>
                        </div>
                        <div className="h-1 bg-slate-700 rounded-full overflow-hidden">
                          <div className="h-full rounded-full" style={{ width:`${subPct}%`, background: subColor }}/>
                        </div>
                      </div>
                    </div>

                    {/* Aktif kullanıcılar (inline, tek satır) */}
                    {tu.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {tu.slice(0, 4).map(u => {
                          const mc = METHOD_COLOR[u.method] || '#94a3b8';
                          const fresh = u.seconds_ago < 30;
                          return (
                            <span key={u.user_id}
                              className={`flex items-center gap-1 text-[9px] px-1.5 py-0.5 rounded ${
                                fresh ? 'bg-emerald-950/40 border border-emerald-800/40' : 'bg-slate-800'
                              }`}>
                              <span className="font-bold" style={{ color: mc }}>{u.method.slice(0,3)}</span>
                              <span className="text-slate-400">{(u.name || u.email.split('@')[0]).slice(0,10)}</span>
                              {fresh && <span className="w-1 h-1 rounded-full bg-emerald-400"/>}
                            </span>
                          );
                        })}
                        {tu.length > 4 && <span className="text-[9px] text-slate-600">+{tu.length-4}</span>}
                      </div>
                    )}

                    {/* Cihaz ID'leri — sadece varsa */}
                    {t.devices.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {t.devices.slice(0, 4).map(d => (
                          <span key={d.device_id} className={`text-[8px] font-mono px-1 py-0.5 rounded ${
                            d.online ? 'text-emerald-500 bg-emerald-500/10' : 'text-slate-700 bg-slate-800'
                          }`}>{d.device_id.slice(-6)}</span>
                        ))}
                        {t.devices.length > 4 && <span className="text-[8px] text-slate-700">+{t.devices.length-4}</span>}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* ── AKTİF KULLANICILAR (2/5) ── */}
        <div className="lg:col-span-2 bg-slate-900 rounded-2xl border border-slate-700 overflow-hidden flex flex-col">
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-700/60 flex-shrink-0">
            <div className="flex items-center gap-2.5">
              <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"/>
              <span className="text-sm font-black text-white">KULLANICILAR</span>
              <span className="text-[11px] text-slate-500">{activeUsers.length} aktif</span>
            </div>
            <span className="text-[10px] text-slate-600 font-mono">4s</span>
          </div>

          {activeUsers.length === 0 ? (
            <div className="flex items-center justify-center py-12 text-slate-600 text-sm font-mono flex-1">
              Aktif kullanıcı yok
            </div>
          ) : (
            <div className="overflow-y-auto max-h-[520px] divide-y divide-slate-800/50">
              {activeUsers.map(u => {
                const mc      = METHOD_COLOR[u.method] || '#94a3b8';
                const fresh   = u.seconds_ago < 30;
                const tenant  = tenants.find(t => t.id === u.tenant_id);
                const inits   = (u.name || u.email.split('@')[0]).slice(0, 2).toUpperCase();
                const ri      = ROLE_INFO[u.role] || { label: u.role || '—', color: '#94a3b8' };
                const epClean = u.endpoint.replace('/api/v1/', '').replace(/\/\d+/g, '/…').slice(0, 28);
                return (
                  <div key={u.user_id}
                    className={`flex items-start gap-2.5 px-3 py-2.5 transition ${fresh ? 'bg-emerald-950/15' : 'hover:bg-slate-800/30'}`}>
                    {/* Avatar */}
                    <div className="relative flex-shrink-0 mt-0.5">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-[11px] font-black"
                        style={{ background: mc+'1a', border:`1.5px solid ${mc}`, color: mc }}>
                        {inits}
                      </div>
                      {fresh && <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 border border-slate-900 animate-pulse"/>}
                    </div>

                    {/* Bilgiler */}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <span className="text-[11px] font-bold text-slate-200 truncate">
                          {u.name || u.email.split('@')[0]}
                        </span>
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded flex-shrink-0"
                          style={{ background: ri.color+'22', color: ri.color }}>{ri.label}</span>
                      </div>
                      {tenant && (
                        <div className="text-[9px] text-slate-500 truncate mb-0.5">
                          {tenant.company || tenant.name}
                        </div>
                      )}
                      <div className="flex items-center gap-1">
                        <span className="text-[9px] font-black flex-shrink-0" style={{ color: mc }}>{u.method}</span>
                        <span className="text-[9px] text-slate-600 font-mono truncate">{epClean}</span>
                      </div>
                    </div>

                    {/* Süre */}
                    <span className={`text-[10px] font-mono font-bold flex-shrink-0 mt-1 ${fresh ? 'text-emerald-400' : 'text-slate-600'}`}>
                      {u.seconds_ago < 60 ? `${u.seconds_ago}s` : `${Math.floor(u.seconds_ago/60)}dk`}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* ── Event log ── */}
      <div className="bg-slate-900 rounded-xl border border-slate-700 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-700/60">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"/>
            Altyapı Olay Akışı
          </h3>
          <span className="text-xs text-slate-500 font-mono">{events.length} olay</span>
        </div>
        <div className="h-44 overflow-y-auto">
          {events.length === 0 ? (
            <div className="flex items-center justify-center h-full text-slate-600 text-xs font-mono">
              Altyapı olayı bekleniyor…
            </div>
          ) : (
            <div className="p-2 space-y-0.5 font-mono text-xs">
              {events.map(ev => {
                const cfg = EVENT_CFG[ev.event_type] || { emoji: '⚪', color: '#94a3b8' };
                const ts  = new Date(ev.created_at).toLocaleTimeString('tr-TR');
                const rt  = [ev.from_node, ev.to_node].filter(Boolean).join(' → ');
                return (
                  <div key={ev.id} className="flex items-start gap-2 py-0.5 hover:bg-slate-800/50 px-2 rounded">
                    <span className="shrink-0 mt-0.5">{cfg.emoji}</span>
                    <span className="text-slate-500 shrink-0 w-20">{ts}</span>
                    {rt && <span className="text-slate-600 shrink-0">{rt}</span>}
                    <span style={{ color: cfg.color }} className="truncate">{ev.message}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* ── Stats bar ── */}
      <div className="grid grid-cols-3 gap-3">
        {(['backend-s1','postgres','minio-s1'] as const).map(id => {
          const st = statuses[id], node = nodeMap[id];
          if (!node) return null; const col = statusColor(id);
          return (
            <div key={id} className="bg-slate-900 rounded-xl border border-slate-700 p-3">
              <div className="flex items-center gap-2 mb-1.5">
                <span className="w-2 h-2 rounded-full" style={{background:col}}/>
                <span className="text-xs font-bold text-slate-300">{node.label}</span>
              </div>
              {st ? (
                <div className="space-y-1">
                  {st.load!==undefined && (
                    <div>
                      <div className="flex justify-between text-[10px] text-slate-500 mb-0.5"><span>CPU Yük</span><span>{st.load}</span></div>
                      <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                        <div className="h-full rounded-full bg-violet-500" style={{width:`${Math.min((st.load||0)*25,100)}%`}}/>
                      </div>
                    </div>
                  )}
                  {st.ram_pct!==undefined && (
                    <div>
                      <div className="flex justify-between text-[10px] text-slate-500 mb-0.5"><span>RAM</span><span>%{st.ram_pct}</span></div>
                      <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{width:`${st.ram_pct}%`,background:st.ram_pct>85?'#ef4444':col}}/>
                      </div>
                    </div>
                  )}
                  {st.disk_pct!==undefined && (
                    <div>
                      <div className="flex justify-between text-[10px] text-slate-500 mb-0.5"><span>Disk</span><span>%{st.disk_pct}</span></div>
                      <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{width:`${st.disk_pct}%`,background:st.disk_pct>80?'#ef4444':col}}/>
                      </div>
                    </div>
                  )}
                  {st.latency_ms!==undefined && (
                    <div className="text-[10px] text-slate-500">
                      Gecikme: <span style={{color:col}}>{st.latency_ms}ms</span>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-[10px] text-slate-600">Veri bekleniyor…</div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
