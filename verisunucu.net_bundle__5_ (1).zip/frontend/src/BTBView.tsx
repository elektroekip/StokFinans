import { useState, useEffect, useCallback, useRef } from 'react';
import { useRefreshOnChange } from './hooks/useRefreshOnChange';
import {
  Building2, Package, Plus, Search,
  Truck, CheckCircle, XCircle, Clock, AlertTriangle, Banknote,
  FileCheck, Edit3, Trash2, ReceiptText, Tag, MapPin, Phone,
  Mail, TrendingUp, Upload, Download, RefreshCw, ChevronDown, ChevronUp,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { apiRequest } from './lib/api';
import { useLang, makeT } from './lib/i18n';

// ─── Types ────────────────────────────────────────────────────

interface BtbCustomer {
  id: number; company_name: string; contact_person?: string;
  phone?: string; email?: string; vkn?: string; tax_office?: string;
  address?: string; notes?: string;
  category: string; discount_rate: number;
  credit_limit: number; payment_term_days: number; is_active: boolean;
  order_count: number; total_debt: number; overdue_count: number;
  created_at?: string;
}

interface BtbOrderItem {
  id: number; product_id?: number; product_name: string;
  unit_price: number; currency: string; quantity: number;
  discount_rate: number; kdv_rate: number; line_total: number;
}

interface BtbPayment {
  id: number; order_id: number; amount: number;
  payment_method: string; notes?: string; paid_at?: string;
}

interface BtbOrder {
  id: number; customer_id: number; customer_name: string;
  order_number: string; status: string;
  notes?: string; due_date?: string;
  shipping_address?: string; shipping_carrier?: string; tracking_number?: string;
  subtotal: number; kdv_amount: number;
  discount_rate: number; discount_amount: number;
  total_amount: number; currency: string;
  transaction_id?: number;
  is_paid: boolean; paid_at?: string; paid_total: number; remaining: number;
  created_at?: string;
  items: BtbOrderItem[]; payments: BtbPayment[];
}

interface Product { id: number; name: string; quantity: number; price: number; }

// ─── Translation Dictionary ───────────────────────────────────

const DICT: Record<string, string> = {
  // Page header
  'B2B Sipariş': 'B2B Orders',
  'Kurumsal müşteri siparişleri, iskonto ve alacak takibi': 'Corporate customer orders, discount & receivables management',
  // Stats bar
  'Aktif Siparişler': 'Active Orders',
  'Açık Alacak': 'Open Receivable',
  'Bu Ay Tahsilat': 'This Month Collection',
  'Vadesi Geçmiş': 'Overdue',
  'Müşteriler': 'Customers',
  'Bu Ay Teslim': 'Delivered This Month',
  // Pending banner
  'portal siparişi onay bekliyor': 'portal orders awaiting approval',
  'Bekleyenleri Göster →': 'Show Pending →',
  // Tab labels
  'Siparişler': 'Orders',
  'Aktivite': 'Activity',
  // Status filter buttons
  'Tümü': 'All',
  // Status badge labels
  'Onay Bekliyor': 'Pending Approval',
  'Taslak': 'Draft',
  'Onaylı': 'Confirmed',
  'Kargoda': 'Shipped',
  'Teslim': 'Delivered',
  'İptal': 'Cancel',
  // Orders table
  'Sipariş no veya müşteri ara…': 'Search order no or customer…',
  'Yeni Sipariş': 'New Order',
  'Sipariş No': 'Order No',
  'Müşteri': 'Customer',
  'Tarih / Vade': 'Date / Due',
  'Tutar': 'Amount',
  'Durum': 'Status',
  'Ödeme': 'Payment',
  'Sipariş bulunamadı': 'No orders found',
  'Vade:': 'Due:',
  'Kalan:': 'Remaining:',
  '✓ Ödendi': '✓ Paid',
  'Kısmi': 'Partial',
  'Bekliyor': 'Pending',
  // Customers tab
  'Firma ara…': 'Search company…',
  'Yeni Müşteri': 'New Customer',
  'Müşteri bulunamadı': 'No customers found',
  'A Sınıfı': 'Class A',
  'B Sınıfı': 'Class B',
  'C Sınıfı': 'Class C',
  'Açık Borç': 'Outstanding Debt',
  'Sipariş': 'Orders',
  'Vade': 'Due Days',
  'İskonto': 'Discount',
  'Kredi Kullanımı': 'Credit Usage',
  // Portal tab
  'Müşteri Portal Erişimi': 'Customer Portal Access',
  'Müşteri Aktiviteleri': 'Customer Activities',
  'Henüz aktivite yok.': 'No activity yet.',
  'Müşterileriniz sisteme giriş yaptığında burada görünür.': 'Will appear here when your customers log in.',
  'Hesap aktif': 'Account active',
  'Kayıt bekleniyor': 'Awaiting registration',
  // Activity log action labels
  'Giriş yaptı': 'Logged in',
  'Ürünleri inceledi': 'Browsed products',
  'Sipariş verdi': 'Placed order',
  'Siparişlerine baktı': 'Viewed orders',
  'Sipariş detayını gördü': 'Viewed order detail',
  // Order Detail Modal
  'Vadesi Geçti': 'Overdue',
  'Kargo Bilgisi': 'Shipping Info',
  'Firma:': 'Carrier:',
  'Takip:': 'Tracking:',
  'Kalemler': 'Line Items',
  'Ürün': 'Product',
  'Adet': 'Qty',
  'Fiyat': 'Price',
  'İsk%': 'Disc%',
  'KDV%': 'VAT%',
  'Ara Toplam (KDV Hariç)': 'Subtotal (Excl. VAT)',
  'Sipariş İndirimi': 'Order Discount',
  'Toplam KDV': 'Total VAT',
  'Genel Toplam': 'Grand Total',
  'Toplam Ödenen': 'Total Paid',
  'Kalan Borç': 'Remaining Debt',
  'Not:': 'Note:',
  'Ödeme Geçmişi': 'Payment History',
  'Ödeme Ekle': 'Add Payment',
  'Not (opsiyonel)': 'Note (optional)',
  'Kaydet': 'Save',
  'Kaydediliyor…': 'Saving…',
  'İptal Et': 'Cancel',
  'Bu siparişi silmek istiyor musunuz?': 'Do you want to delete this order?',
  'Bu ödeme kaydı silinsin mi?': 'Delete this payment record?',
  'Sipariş silindi': 'Order deleted',
  'Sipariş onaylandı': 'Order confirmed',
  'Kargoya verildi': 'Shipped',
  'Teslim edildi': 'Delivered',
  'İptal edildi': 'Cancelled',
  'Ödendi işaretlendi': 'Marked as paid',
  'Portal siparişi onaylandı': 'Portal order confirmed',
  'Portal siparişi reddedildi': 'Portal order rejected',
  'Bu sipariş müşteri tarafından verildi, onayınızı bekliyor.': 'This order was placed by the customer and awaits your approval.',
  'Onayla': 'Confirm',
  'Reddet': 'Reject',
  'Kargoya Ver': 'Ship',
  'Teslim Edildi': 'Mark Delivered',
  'Ödendi': 'Paid',
  'Ödendi İşaretle': 'Mark as Paid',
  'Sil': 'Delete',
  // Order Create/Edit Modal
  'Siparişi Düzenle': 'Edit Order',
  '— Müşteri Seçin —': '— Select Customer —',
  'Müşteri *': 'Customer *',
  'Vade Tarihi': 'Due Date',
  'Para Birimi': 'Currency',
  'Şablon İndir': 'Download Template',
  "Excel'den Yükle": 'Import from Excel',
  'Yükleniyor…': 'Loading…',
  'Ürün Seç': 'Select Product',
  'Manuel giriş': 'Manual entry',
  'Ürün Adı *': 'Product Name *',
  'Ürün adı': 'Product name',
  'Birim Fiyat': 'Unit Price',
  'İskonto %': 'Discount %',
  'KDV %': 'VAT %',
  'Kalem Ekle': 'Add Item',
  'Sipariş İndirimi %': 'Order Discount %',
  'Ara Toplam': 'Subtotal',
  'İndirim': 'Discount',
  'KDV': 'VAT',
  'Toplam': 'Total',
  'Kargo & Notlar': 'Shipping & Notes',
  'Kargo firması': 'Carrier',
  'Kargo takip no': 'Tracking no',
  'Farklı teslimat adresi': 'Different delivery address',
  'Sipariş notu': 'Order note',
  'Güncelle': 'Update',
  'Sipariş Oluştur': 'Create Order',
  'Sipariş güncellendi': 'Order updated',
  'Sipariş oluşturuldu': 'Order created',
  'Müşteri seçin': 'Select a customer',
  'Tüm kalemleri doldurun': 'Fill in all line items',
  'Dosyada veri satırı bulunamadı': 'No data rows found in file',
  'Geçerli ürün satırı bulunamadı': 'No valid product rows found',
  'kalem içe aktarıldı': 'items imported',
  'Dosya okunamadı. Geçerli bir Excel/CSV yükleyin.': 'Could not read file. Upload a valid Excel/CSV.',
  // Customer Modal
  'Müşteriyi Düzenle': 'Edit Customer',
  'Firma Adı *': 'Company Name *',
  'Yetkili Kişi': 'Contact Person',
  'Telefon': 'Phone',
  'E-posta': 'Email',
  'VKN / TCKN': 'Tax No / ID No',
  'Vergi Dairesi': 'Tax Office',
  'Adres': 'Address',
  'Kategori': 'Category',
  'A — Öncelikli': 'A — Priority',
  'B — Standart': 'B — Standard',
  'C — Dikkatli': 'C — Caution',
  'Vade (Gün)': 'Payment Term (Days)',
  'Kredi Limiti ₺ (0 = limitsiz)': 'Credit Limit ₺ (0 = unlimited)',
  'Not': 'Note',
  'Aktif Müşteri': 'Active Customer',
  'Müşteri güncellendi': 'Customer updated',
  'Müşteri eklendi': 'Customer added',
  'Firma adı zorunlu': 'Company name is required',
  'Müşteri silindi': 'Customer deleted',
  'Müşteri Ekle': 'Add Customer',
  'silinsin mi?': 'deleted?',
  // Customer Detail Modal
  'Toplam Sipariş': 'Total Orders',
  'Sipariş Sayısı': 'Order Count',
  'Kredi Limiti': 'Credit Limit',
  'Sipariş Geçmişi': 'Order History',
  'Henüz sipariş yok': 'No orders yet',
  'Ödemeler': 'Payments',
  'Kalan Alacak': 'Remaining Receivable',
  'Yükleme hatası': 'Load error',
  'Yüklenemedi': 'Failed to load',
  // Misc badges / labels
  'Pasif': 'Inactive',
  'Aktif': 'Active',
  'Güncellendi': 'Updated',
  'Hata': 'Error',
  // Payment methods
  'Nakit': 'Cash',
  'Havale/EFT': 'Bank Transfer',
  'Çek': 'Cheque',
  'Kart': 'Card',
  'Diğer': 'Other',
};

// ─── Constants ────────────────────────────────────────────────

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: any }> = {
  pending_approval: { label: 'Onay Bekliyor', color: 'bg-orange-100 text-orange-700', icon: AlertTriangle },
  draft:     { label: 'Taslak',  color: 'bg-slate-100 text-slate-700',    icon: Clock },
  confirmed: { label: 'Onaylı',  color: 'bg-blue-100 text-blue-700',      icon: FileCheck },
  shipped:   { label: 'Kargoda', color: 'bg-amber-100 text-amber-700',    icon: Truck },
  delivered: { label: 'Teslim',  color: 'bg-emerald-100 text-emerald-700',icon: CheckCircle },
  cancelled: { label: 'İptal',   color: 'bg-red-100 text-red-700',        icon: XCircle },
};

const PAYMENT_METHOD_LABELS: Record<string, string> = {
  cash: 'Nakit', bank: 'Havale/EFT', check: 'Çek', card: 'Kart', other: 'Diğer',
};

const CATEGORY_CONFIG: Record<string, { color: string }> = {
  A: { color: 'bg-emerald-100 text-emerald-700' },
  B: { color: 'bg-blue-100 text-blue-700' },
  C: { color: 'bg-amber-100 text-amber-700' },
};

const fmt = (n: number, cur = 'TRY') =>
  new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n) +
  (cur === 'USD' ? ' $' : cur === 'EUR' ? ' €' : ' ₺');

function isOverdue(o: BtbOrder) {
  if (!o.due_date || o.is_paid) return false;
  if (!['confirmed', 'shipped'].includes(o.status)) return false;
  return new Date(o.due_date) < new Date();
}

function StatusBadge({ status }: { status: string }) {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const cfg = STATUS_CONFIG[status] || { label: status, color: 'bg-gray-100 text-gray-700', icon: Clock };
  const Icon = cfg.icon;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${cfg.color}`}>
      <Icon size={11} />{t(cfg.label)}
    </span>
  );
}

// ─── Stats Bar ────────────────────────────────────────────────

function StatsBar({ stats }: { stats: any }) {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const cards = [
    { label: t('Aktif Siparişler'), value: stats.active_orders, icon: Package, color: 'text-blue-600' },
    { label: t('Açık Alacak'), value: fmt(stats.total_receivable), icon: Banknote, color: 'text-amber-600' },
    { label: t('Bu Ay Tahsilat'), value: fmt(stats.total_collected_this_month ?? 0), icon: TrendingUp, color: 'text-emerald-600' },
    { label: t('Vadesi Geçmiş'), value: stats.overdue_count, icon: AlertTriangle, color: stats.overdue_count > 0 ? 'text-red-600' : 'text-gray-400' },
    { label: t('Müşteriler'), value: stats.customer_count, icon: Building2, color: 'text-indigo-600' },
    { label: t('Bu Ay Teslim'), value: stats.delivered_this_month, icon: CheckCircle, color: 'text-teal-600' },
  ];
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
      {cards.map(c => {
        const Icon = c.icon;
        return (
          <div key={c.label} className="bg-white dark:bg-slate-800 rounded-xl border border-gray-200 dark:border-slate-700 p-3">
            <div className="flex items-center gap-2 mb-1">
              <Icon size={15} className={c.color} />
              <span className="text-xs text-gray-500 dark:text-slate-400 truncate">{c.label}</span>
            </div>
            <p className={`text-lg font-bold ${c.color}`}>{c.value}</p>
          </div>
        );
      })}
    </div>
  );
}

// ─── Order Detail Modal ───────────────────────────────────────

function OrderDetailModal({ order, onClose, onAction, currentUser }: {
  order: BtbOrder; onClose: () => void;
  onAction: (id: number, action: string) => void; currentUser: any;
}) {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const [showAddPayment, setShowAddPayment] = useState(false);
  const [payForm, setPayForm] = useState({ amount: '', payment_method: 'cash', notes: '' });
  const [saving, setSaving] = useState(false);
  const overdue = isOverdue(order);
  const canEdit = order?.status !== undefined;

  async function handleAddPayment() {
    if (!payForm.amount) return;
    setSaving(true);
    try {
      await apiRequest(`/btb/orders/${order.id}/payments`, {
        method: 'POST',
        body: JSON.stringify({ ...payForm, amount: parseFloat(payForm.amount) }),
      });
      onAction(order.id, 'payment_added');
      setShowAddPayment(false);
      setPayForm({ amount: '', payment_method: 'cash', notes: '' });
    } finally { setSaving(false); }
  }

  async function handleDeletePayment(pid: number) {
    if (!confirm(t('Bu ödeme kaydı silinsin mi?'))) return;
    await apiRequest(`/btb/orders/${order.id}/payments/${pid}`, { method: 'DELETE' });
    onAction(order.id, 'payment_deleted');
  }

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className={`p-4 border-b flex items-start justify-between ${overdue ? 'bg-red-50 dark:bg-red-900/30' : 'bg-gray-50 dark:bg-slate-700/50'} rounded-t-2xl`}>
          <div>
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <h2 className="font-bold text-lg">#{order.order_number}</h2>
              <StatusBadge status={order.status} />
              {overdue && <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-medium flex items-center gap-1"><AlertTriangle size={11}/>{t('Vadesi Geçti')}</span>}
              {order.is_paid && <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-medium">{t('✓ Ödendi')}</span>}
            </div>
            <p className="text-sm text-gray-600 dark:text-slate-400">{order.customer_name}</p>
            {order.due_date && <p className="text-xs text-gray-500 dark:text-slate-400 mt-0.5">{t('Vade:')} {order.due_date}</p>}
          </div>
          <button onClick={onClose} className="text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 text-xl font-light ml-4">✕</button>
        </div>

        <div className="p-4 space-y-4">
          {/* Kargo */}
          {(order.shipping_carrier || order.tracking_number || order.shipping_address) && (
            <div className="bg-blue-50 dark:bg-blue-900/30 rounded-xl p-3 text-sm space-y-1">
              <p className="font-medium text-blue-800 flex items-center gap-1"><Truck size={14}/>{t('Kargo Bilgisi')}</p>
              {order.shipping_carrier && <p className="text-blue-700">{t('Firma:')} {order.shipping_carrier}</p>}
              {order.tracking_number && <p className="text-blue-700">{t('Takip:')} <span className="font-mono font-medium">{order.tracking_number}</span></p>}
              {order.shipping_address && <p className="text-blue-700 flex items-center gap-1"><MapPin size={12}/>{order.shipping_address}</p>}
            </div>
          )}

          {/* Kalemler */}
          <div>
            <p className="text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wide mb-2">{t('Kalemler')}</p>
            <div className="border border-gray-200 dark:border-slate-700 rounded-xl overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 dark:bg-slate-700/50">
                  <tr>
                    <th className="text-left p-2 text-xs text-gray-500 dark:text-slate-400">{t('Ürün')}</th>
                    <th className="text-right p-2 text-xs text-gray-500 dark:text-slate-400">{t('Adet')}</th>
                    <th className="text-right p-2 text-xs text-gray-500 dark:text-slate-400">{t('Fiyat')}</th>
                    <th className="text-right p-2 text-xs text-gray-500 dark:text-slate-400">{t('İsk%')}</th>
                    <th className="text-right p-2 text-xs text-gray-500 dark:text-slate-400">{t('KDV%')}</th>
                    <th className="text-right p-2 text-xs text-gray-500 dark:text-slate-400">{t('Tutar')}</th>
                  </tr>
                </thead>
                <tbody>
                  {order.items.map(it => (
                    <tr key={it.id} className="border-t border-gray-200 dark:border-slate-700">
                      <td className="p-2 font-medium">{it.product_name}</td>
                      <td className="p-2 text-right">{it.quantity}</td>
                      <td className="p-2 text-right">{fmt(it.unit_price, it.currency)}</td>
                      <td className="p-2 text-right text-orange-600">{it.discount_rate > 0 ? `%${it.discount_rate}` : '—'}</td>
                      <td className="p-2 text-right text-gray-400 dark:text-slate-500">%{it.kdv_rate}</td>
                      <td className="p-2 text-right font-medium">{fmt(it.line_total, it.currency)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Finansal özet */}
          <div className="bg-gray-50 dark:bg-slate-700/50 rounded-xl p-3 space-y-1 text-sm">
            <div className="flex justify-between text-gray-600 dark:text-slate-400"><span>{t('Ara Toplam (KDV Hariç)')}</span><span>{fmt(order.subtotal, order.currency)}</span></div>
            {order.discount_amount > 0 && <div className="flex justify-between text-orange-600"><span>{t('Sipariş İndirimi')} (%{order.discount_rate})</span><span>−{fmt(order.discount_amount, order.currency)}</span></div>}
            <div className="flex justify-between text-gray-500 dark:text-slate-400"><span>{t('Toplam KDV')}</span><span>{fmt(order.kdv_amount, order.currency)}</span></div>
            <div className="flex justify-between font-bold text-base border-t dark:border-slate-600 pt-1"><span>{t('Genel Toplam')}</span><span>{fmt(order.total_amount, order.currency)}</span></div>
            {order.paid_total > 0 && <div className="flex justify-between text-emerald-600"><span>{t('Toplam Ödenen')}</span><span>{fmt(order.paid_total, order.currency)}</span></div>}
            {order.remaining > 0 && <div className="flex justify-between text-red-600 font-semibold"><span>{t('Kalan Borç')}</span><span>{fmt(order.remaining, order.currency)}</span></div>}
          </div>

          {/* Not */}
          {order.notes && (
            <div className="text-sm text-gray-600 dark:text-slate-400 bg-yellow-50 dark:bg-yellow-900/30 rounded-xl p-3">
              <span className="font-medium text-yellow-800">{t('Not:')} </span>{order.notes}
            </div>
          )}

          {/* Ödeme geçmişi */}
          {order.payments.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wide mb-2">{t('Ödeme Geçmişi')}</p>
              <div className="space-y-1.5">
                {order.payments.map(p => (
                  <div key={p.id} className="flex items-center justify-between bg-emerald-50 dark:bg-emerald-900/30 rounded-lg px-3 py-2 text-sm">
                    <div>
                      <span className="font-semibold">{fmt(p.amount, order.currency)}</span>
                      <span className="text-gray-500 dark:text-slate-400 ml-2">{t(PAYMENT_METHOD_LABELS[p.payment_method] || p.payment_method)}</span>
                      {p.notes && <span className="text-gray-400 dark:text-slate-500 ml-2">· {p.notes}</span>}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-400 dark:text-slate-500">{p.paid_at ? new Date(p.paid_at).toLocaleDateString('tr-TR') : ''}</span>
                      <button onClick={() => handleDeletePayment(p.id)} className="text-red-400 hover:text-red-600"><Trash2 size={13}/></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Ödeme ekle */}
          {canEdit && ['confirmed', 'shipped', 'delivered'].includes(order.status) && !order.is_paid && (
            showAddPayment ? (
              <div className="border border-gray-200 dark:border-slate-700 rounded-xl p-3 space-y-3">
                <p className="text-sm font-medium">{t('Ödeme Ekle')}</p>
                <div className="grid grid-cols-2 gap-2">
                  <input type="number" step="0.01" placeholder={t('Tutar')} value={payForm.amount}
                    onChange={e => setPayForm(f => ({ ...f, amount: e.target.value }))}
                    className="border rounded-lg px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
                  <select value={payForm.payment_method}
                    onChange={e => setPayForm(f => ({ ...f, payment_method: e.target.value }))}
                    className="border rounded-lg px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100">
                    {Object.entries(PAYMENT_METHOD_LABELS).map(([k, v]) => <option key={k} value={k}>{t(v)}</option>)}
                  </select>
                </div>
                <input type="text" placeholder={t('Not (opsiyonel)')} value={payForm.notes}
                  onChange={e => setPayForm(f => ({ ...f, notes: e.target.value }))}
                  className="w-full border rounded-lg px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
                <div className="flex gap-2">
                  <button onClick={handleAddPayment} disabled={saving}
                    className="flex-1 bg-emerald-600 text-white rounded-lg py-2 text-sm font-medium hover:bg-emerald-700">
                    {saving ? t('Kaydediliyor…') : t('Kaydet')}
                  </button>
                  <button onClick={() => setShowAddPayment(false)} className="px-4 border border-gray-200 dark:border-slate-600 rounded-lg text-sm dark:text-slate-300">{t('İptal')}</button>
                </div>
              </div>
            ) : (
              <button onClick={() => setShowAddPayment(true)}
                className="w-full border-2 border-dashed border-emerald-300 text-emerald-700 rounded-xl py-2 text-sm hover:bg-emerald-50 dark:hover:bg-emerald-900/30 flex items-center justify-center gap-2">
                <Banknote size={15}/>{t('Ödeme Ekle')}
              </button>
            )
          )}

          {/* Aksiyon butonları */}
          <div className="flex flex-wrap gap-2 pt-2 border-t dark:border-slate-700">
            {order.status === 'pending_approval' && (
              <>
                <div className="w-full bg-orange-50 dark:bg-orange-900/30 border border-orange-200 rounded-xl px-3 py-2 text-xs text-orange-800 flex items-center gap-2 mb-1">
                  <AlertTriangle size={13} className="shrink-0" /> {t('Bu sipariş müşteri tarafından verildi, onayınızı bekliyor.')}
                </div>
                <button onClick={() => onAction(order.id, 'portal-approve')} className="flex-1 bg-blue-600 text-white rounded-xl py-2 text-sm font-medium hover:bg-blue-700 flex items-center justify-center gap-1"><FileCheck size={14}/>{t('Onayla')}</button>
                <button onClick={() => onAction(order.id, 'portal-reject')} className="px-4 border border-red-200 text-red-600 rounded-xl py-2 text-sm hover:bg-red-50 dark:hover:bg-red-900/30">{t('Reddet')}</button>
              </>
            )}
            {order.status === 'draft' && (
              <>
                <button onClick={() => onAction(order.id, 'confirm')} className="flex-1 bg-blue-600 text-white rounded-xl py-2 text-sm font-medium hover:bg-blue-700">{t('Onayla')}</button>
                <button onClick={() => onAction(order.id, 'delete')} className="px-4 border border-red-200 text-red-600 rounded-xl py-2 text-sm hover:bg-red-50 dark:hover:bg-red-900/30">{t('Sil')}</button>
              </>
            )}
            {order.status === 'confirmed' && (
              <>
                <button onClick={() => onAction(order.id, 'ship')} className="flex-1 bg-amber-500 text-white rounded-xl py-2 text-sm font-medium hover:bg-amber-600"><Truck size={14} className="inline mr-1"/>{t('Kargoya Ver')}</button>
                {!order.is_paid && <button onClick={() => onAction(order.id, 'mark-paid')} className="flex-1 bg-emerald-600 text-white rounded-xl py-2 text-sm font-medium hover:bg-emerald-700">{t('Ödendi')}</button>}
                <button onClick={() => onAction(order.id, 'cancel')} className="px-4 border border-red-200 text-red-600 rounded-xl py-2 text-sm hover:bg-red-50 dark:hover:bg-red-900/30">{t('İptal')}</button>
              </>
            )}
            {order.status === 'shipped' && (
              <>
                <button onClick={() => onAction(order.id, 'deliver')} className="flex-1 bg-emerald-600 text-white rounded-xl py-2 text-sm font-medium hover:bg-emerald-700"><CheckCircle size={14} className="inline mr-1"/>{t('Teslim Edildi')}</button>
                {!order.is_paid && <button onClick={() => onAction(order.id, 'mark-paid')} className="flex-1 bg-teal-600 text-white rounded-xl py-2 text-sm font-medium hover:bg-teal-700">{t('Ödendi')}</button>}
                <button onClick={() => onAction(order.id, 'cancel')} className="px-4 border border-red-200 text-red-600 rounded-xl py-2 text-sm hover:bg-red-50 dark:hover:bg-red-900/30">{t('İptal')}</button>
              </>
            )}
            {order.status === 'delivered' && !order.is_paid && (
              <button onClick={() => onAction(order.id, 'mark-paid')} className="flex-1 bg-emerald-600 text-white rounded-xl py-2 text-sm font-medium hover:bg-emerald-700">{t('Ödendi İşaretle')}</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Order Create/Edit Modal ──────────────────────────────────

const EMPTY_ITEM = { product_id: null as number | null, product_name: '', unit_price: '', quantity: '1', discount_rate: '0', kdv_rate: '18' };

function OrderModal({ order, customers, products, onClose, onSaved, showToast }: {
  order?: BtbOrder | null; customers: BtbCustomer[]; products: Product[];
  onClose: () => void; onSaved: () => void; showToast: (m: string, t: string) => void;
}) {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const [form, setForm] = useState({
    customer_id: order?.customer_id?.toString() || '',
    notes: order?.notes || '',
    due_date: order?.due_date || '',
    shipping_address: order?.shipping_address || '',
    shipping_carrier: order?.shipping_carrier || '',
    tracking_number: order?.tracking_number || '',
    currency: order?.currency || 'TRY',
    discount_rate: order?.discount_rate?.toString() || '0',
  });
  const [items, setItems] = useState<typeof EMPTY_ITEM[]>(
    order?.items.map(i => ({
      product_id: i.product_id ?? null,
      product_name: i.product_name,
      unit_price: i.unit_price.toString(),
      quantity: i.quantity.toString(),
      discount_rate: i.discount_rate.toString(),
      kdv_rate: i.kdv_rate.toString(),
    })) || [{ ...EMPTY_ITEM }]
  );
  const [saving, setSaving] = useState(false);
  const [importing, setImporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  function downloadTemplate() {
    const ws = XLSX.utils.aoa_to_sheet([
      ['urun_adi', 'adet', 'birim_fiyat', 'iskonto_yuzde', 'kdv_yuzde'],
      ['Örnek Ürün A', 5, 100.00, 0, 20],
      ['Örnek Ürün B', 2, 250.50, 10, 10],
    ]);
    ws['!cols'] = [{ wch: 30 }, { wch: 8 }, { wch: 14 }, { wch: 14 }, { wch: 10 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Siparis');
    XLSX.writeFile(wb, 'btb_siparis_sablonu.xlsx');
  }

  function handleExcelImport(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setImporting(true);
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = new Uint8Array(ev.target!.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: 'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
        if (rows.length < 2) { showToast(t('Dosyada veri satırı bulunamadı'), 'error'); return; }

        // Detect header row (first row): find column positions by name
        const header = (rows[0] as string[]).map(h => String(h).toLowerCase().trim());
        const col = (names: string[]) => names.reduce((best, n) => {
          const idx = header.findIndex(h => h.includes(n));
          return idx >= 0 ? idx : best;
        }, -1);

        const nameCol   = col(['urun_adi', 'ürün_adı', 'urun', 'isim', 'name', 'product', 'ürün']);
        const qtyCol    = col(['adet', 'miktar', 'qty', 'quantity']);
        const priceCol  = col(['birim_fiyat', 'fiyat', 'price', 'unit_price']);
        const discCol   = col(['iskonto', 'indirim', 'discount']);
        const kdvCol    = col(['kdv', 'vat', 'tax']);

        const parsed = rows.slice(1).map(row => ({
          product_id: null,
          product_name: nameCol >= 0 ? String(row[nameCol] || '').trim() : '',
          unit_price:   priceCol >= 0 ? String(parseFloat(String(row[priceCol])) || 0) : '0',
          quantity:     qtyCol >= 0   ? String(parseInt(String(row[qtyCol])) || 1) : '1',
          discount_rate: discCol >= 0 ? String(parseFloat(String(row[discCol])) || 0) : '0',
          kdv_rate:     kdvCol >= 0   ? String(parseFloat(String(row[kdvCol])) || 0) : '0',
        })).filter(r => r.product_name);

        if (parsed.length === 0) { showToast(t('Geçerli ürün satırı bulunamadı'), 'error'); return; }
        setItems(parsed);
        showToast(`${parsed.length} ${t('kalem içe aktarıldı')}`, 'success');
      } catch {
        showToast(t('Dosya okunamadı. Geçerli bir Excel/CSV yükleyin.'), 'error');
      } finally {
        setImporting(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsArrayBuffer(file);
  }

  const subtotal = items.reduce((acc, it) => {
    const qty = parseFloat(it.quantity) || 0;
    const price = parseFloat(it.unit_price) || 0;
    const disc = parseFloat(it.discount_rate) || 0;
    return acc + price * qty * (1 - disc / 100);
  }, 0);
  const kdv = items.reduce((acc, it) => {
    const qty = parseFloat(it.quantity) || 0;
    const price = parseFloat(it.unit_price) || 0;
    const disc = parseFloat(it.discount_rate) || 0;
    const kdvRate = parseFloat(it.kdv_rate) || 0;
    return acc + price * qty * (1 - disc / 100) * kdvRate / 100;
  }, 0);
  const orderDisc = subtotal * (parseFloat(form.discount_rate) || 0) / 100;
  const total = subtotal - orderDisc + kdv;

  function setItem(idx: number, key: string, val: string) {
    setItems(prev => prev.map((it, i) => i === idx ? { ...it, [key]: val } : it));
  }

  function selectProduct(idx: number, pid: string) {
    const prod = products.find(p => p.id === parseInt(pid));
    if (prod) {
      setItems(prev => prev.map((it, i) => i === idx
        ? { ...it, product_id: prod.id, product_name: prod.name, unit_price: prod.price.toString() } : it));
    } else {
      setItems(prev => prev.map((it, i) => i === idx ? { ...it, product_id: null } : it));
    }
  }

  async function handleSubmit() {
    if (!form.customer_id) { showToast(t('Müşteri seçin'), 'error'); return; }
    if (items.some(it => !it.product_name)) { showToast(t('Tüm kalemleri doldurun'), 'error'); return; }
    setSaving(true);
    try {
      const payload = {
        ...form,
        customer_id: parseInt(form.customer_id),
        discount_rate: parseFloat(form.discount_rate) || 0,
        items: items.map(it => ({
          product_id: it.product_id || null,
          product_name: it.product_name,
          unit_price: parseFloat(it.unit_price) || 0,
          quantity: parseInt(it.quantity) || 1,
          discount_rate: parseFloat(it.discount_rate) || 0,
          kdv_rate: parseFloat(it.kdv_rate) || 0,
          currency: form.currency,
        })),
      };
      if (order) {
        await apiRequest(`/btb/orders/${order.id}`, { method: 'PUT', body: JSON.stringify(payload) });
        showToast(t('Sipariş güncellendi'), 'success');
      } else {
        await apiRequest('/btb/orders', { method: 'POST', body: JSON.stringify(payload) });
        showToast(t('Sipariş oluşturuldu'), 'success');
      }
      onSaved();
    } catch (e: any) { showToast(e.message || t('Hata'), 'error'); }
    finally { setSaving(false); }
  }

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <div className="p-4 border-b dark:border-slate-700 flex items-center justify-between bg-gray-50 dark:bg-slate-700/50 rounded-t-2xl">
          <h2 className="font-bold text-lg">{order ? t('Siparişi Düzenle') : t('Yeni Sipariş')}</h2>
          <button onClick={onClose} className="text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 text-xl">✕</button>
        </div>
        <div className="p-4 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <label className="text-xs font-medium text-gray-600 dark:text-slate-300 mb-1 block">{t('Müşteri *')}</label>
              <select value={form.customer_id} onChange={e => setForm(f => ({ ...f, customer_id: e.target.value }))}
                className="w-full border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100">
                <option value="">{t('— Müşteri Seçin —')}</option>
                {customers.filter(c => c.is_active).map(c => (
                  <option key={c.id} value={c.id}>{c.company_name}{c.discount_rate > 0 ? ` (İsk %${c.discount_rate})` : ''}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-gray-600 dark:text-slate-300 mb-1 block">{t('Vade Tarihi')}</label>
              <input type="date" value={form.due_date} onChange={e => setForm(f => ({ ...f, due_date: e.target.value }))}
                className="w-full border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            </div>
            <div>
              <label className="text-xs font-medium text-gray-600 dark:text-slate-300 mb-1 block">{t('Para Birimi')}</label>
              <select value={form.currency} onChange={e => setForm(f => ({ ...f, currency: e.target.value }))}
                className="w-full border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100">
                <option value="TRY">TRY ₺</option>
                <option value="USD">USD $</option>
                <option value="EUR">EUR €</option>
              </select>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wide">{t('Kalemler')}</p>
              <div className="flex gap-2">
                <button type="button" onClick={downloadTemplate}
                  className="text-xs flex items-center gap-1 text-gray-500 dark:text-slate-400 hover:text-indigo-600 border border-gray-200 dark:border-slate-600 rounded-lg px-2 py-1">
                  <Download size={12}/> {t('Şablon İndir')}
                </button>
                <label className={`text-xs flex items-center gap-1 cursor-pointer border rounded-lg px-2 py-1 ${importing ? 'opacity-50' : 'text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 border-indigo-300'}`}>
                  <Upload size={12}/> {importing ? t('Yükleniyor…') : t("Excel'den Yükle")}
                  <input ref={fileInputRef} type="file" accept=".xlsx,.xls,.csv" className="hidden"
                    onChange={handleExcelImport} disabled={importing} />
                </label>
              </div>
            </div>
            <div className="space-y-2">
              {items.map((item, idx) => (
                <div key={idx} className="border border-gray-200 dark:border-slate-700 rounded-xl p-3 bg-gray-50 dark:bg-slate-700/50">
                  <div className="flex gap-2 mb-2">
                    <div className="flex-1 min-w-0">
                      <label className="text-xs text-gray-500 dark:text-slate-400 mb-0.5 block">{t('Ürün Seç')}</label>
                      <select value={item.product_id?.toString() || ''} onChange={e => selectProduct(idx, e.target.value)}
                        className="w-full border rounded-lg px-2 py-1.5 text-sm bg-white dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100">
                        <option value="">{t('Manuel giriş')}</option>
                        {products.map(p => <option key={p.id} value={p.id}>{p.name} (Stok: {p.quantity})</option>)}
                      </select>
                    </div>
                    <div className="flex-1 min-w-0">
                      <label className="text-xs text-gray-500 dark:text-slate-400 mb-0.5 block">{t('Ürün Adı *')}</label>
                      <input value={item.product_name} onChange={e => setItem(idx, 'product_name', e.target.value)}
                        placeholder={t('Ürün adı')} className="w-full border rounded-lg px-2 py-1.5 text-sm bg-white dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
                    </div>
                    <div className="flex items-end">
                      {items.length > 1 && (
                        <button onClick={() => setItems(p => p.filter((_, i) => i !== idx))}
                          className="text-red-400 hover:text-red-600 p-1.5 border border-red-200 rounded-lg"><Trash2 size={14}/></button>
                      )}
                    </div>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {[
                      { key: 'unit_price', label: t('Birim Fiyat'), type: 'number', step: '0.01', placeholder: '0.00' },
                      { key: 'quantity', label: t('Adet'), type: 'number', min: '1' },
                      { key: 'discount_rate', label: t('İskonto %'), type: 'number', min: '0', max: '100', step: '0.5' },
                    ].map(f => (
                      <div key={f.key}>
                        <label className="text-xs text-gray-500 dark:text-slate-400 mb-0.5 block">{f.label}</label>
                        <input type={f.type} {...f} value={(item as any)[f.key]}
                          onChange={e => setItem(idx, f.key, e.target.value)}
                          className="w-full border rounded-lg px-2 py-1.5 text-sm bg-white dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
                      </div>
                    ))}
                    <div>
                      <label className="text-xs text-gray-500 dark:text-slate-400 mb-0.5 block">{t('KDV %')}</label>
                      <select value={item.kdv_rate} onChange={e => setItem(idx, 'kdv_rate', e.target.value)}
                        className="w-full border rounded-lg px-2 py-1.5 text-sm bg-white dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100">
                        {['0','1','10','18','20'].map(v => <option key={v} value={v}>%{v}</option>)}
                      </select>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <button onClick={() => setItems(p => [...p, { ...EMPTY_ITEM }])}
              className="mt-2 w-full border-2 border-dashed border-gray-300 dark:border-slate-600 text-gray-500 dark:text-slate-400 rounded-xl py-2 text-sm hover:bg-gray-50 dark:hover:bg-slate-700 flex items-center justify-center gap-2">
              <Plus size={14}/>{t('Kalem Ekle')}
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-gray-600 dark:text-slate-300 mb-1 block">{t('Sipariş İndirimi %')}</label>
              <input type="number" min="0" max="100" step="0.5" value={form.discount_rate}
                onChange={e => setForm(f => ({ ...f, discount_rate: e.target.value }))}
                className="w-full border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            </div>
            <div className="bg-indigo-50 dark:bg-indigo-900/30 rounded-xl p-3 text-sm space-y-1">
              <div className="flex justify-between text-gray-600 dark:text-slate-400"><span>{t('Ara Toplam')}</span><span>{fmt(subtotal, form.currency)}</span></div>
              {orderDisc > 0 && <div className="flex justify-between text-orange-600"><span>{t('İndirim')}</span><span>−{fmt(orderDisc, form.currency)}</span></div>}
              <div className="flex justify-between text-gray-600 dark:text-slate-400"><span>{t('KDV')}</span><span>{fmt(kdv, form.currency)}</span></div>
              <div className="flex justify-between font-bold border-t dark:border-slate-600 pt-1"><span>{t('Toplam')}</span><span>{fmt(total, form.currency)}</span></div>
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wide">{t('Kargo & Notlar')}</p>
            <div className="grid grid-cols-2 gap-2">
              <input value={form.shipping_carrier} onChange={e => setForm(f => ({ ...f, shipping_carrier: e.target.value }))}
                placeholder={t('Kargo firması')} className="border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
              <input value={form.tracking_number} onChange={e => setForm(f => ({ ...f, tracking_number: e.target.value }))}
                placeholder={t('Kargo takip no')} className="border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            </div>
            <input value={form.shipping_address} onChange={e => setForm(f => ({ ...f, shipping_address: e.target.value }))}
              placeholder={t('Farklı teslimat adresi')} className="w-full border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
              placeholder={t('Sipariş notu')} rows={2} className="w-full border rounded-xl px-3 py-2 text-sm resize-none dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
          </div>

          <div className="flex gap-3">
            <button onClick={handleSubmit} disabled={saving}
              className="flex-1 bg-indigo-600 text-white rounded-xl py-2.5 font-medium hover:bg-indigo-700 disabled:opacity-50">
              {saving ? t('Kaydediliyor…') : order ? t('Güncelle') : t('Sipariş Oluştur')}
            </button>
            <button onClick={onClose} className="px-6 border border-gray-200 dark:border-slate-600 rounded-xl text-gray-600 dark:text-slate-300 hover:bg-gray-50 dark:hover:bg-slate-700">{t('İptal')}</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Customer Detail Modal ────────────────────────────────────

const PM_LABELS: Record<string, string> = {
  cash: 'Nakit', bank: 'Havale/EFT', check: 'Çek', card: 'Kart', other: 'Diğer',
};

function CustomerDetailModal({ customerId, onClose, showToast }: {
  customerId: number; onClose: () => void;
  showToast: (m: string, t: string) => void;
}) {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [expandedOrder, setExpandedOrder] = useState<number | null>(null);

  useEffect(() => {
    apiRequest(`/btb/customers/${customerId}/summary`)
      .then(d => setData(d))
      .catch(() => showToast(t('Yüklenemedi'), 'error'))
      .finally(() => setLoading(false));
  }, [customerId]);

  if (loading || !data) return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center">
      <div className="bg-white dark:bg-slate-800 rounded-2xl p-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto" /></div>
    </div>
  );

  const { customer: c, summary: s, orders } = data;
  const catColor = CATEGORY_CONFIG[c.category]?.color || 'bg-gray-100 text-gray-600';

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-5 border-b dark:border-slate-700 bg-gray-50 dark:bg-slate-700/50 rounded-t-2xl flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <h2 className="font-bold text-xl text-gray-900 dark:text-slate-100">{c.company_name}</h2>
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${catColor}`}>{c.category}</span>
              {!c.is_active && <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full">{t('Pasif')}</span>}
            </div>
            <div className="flex flex-wrap gap-x-4 gap-y-0.5 text-xs text-gray-500 dark:text-slate-400">
              {c.contact_person && <span>{c.contact_person}</span>}
              {c.phone && <span>{c.phone}</span>}
              {c.email && <span>{c.email}</span>}
              {c.vkn && <span>VKN: {c.vkn}{c.tax_office ? ` / ${c.tax_office}` : ''}</span>}
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 text-xl font-light ml-4">✕</button>
        </div>

        <div className="p-5 space-y-5">
          {/* Finansal özet */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: t('Toplam Sipariş'), value: fmt(s.total_ordered), color: 'text-gray-900 dark:text-slate-100' },
              { label: t('Toplam Ödenen'), value: fmt(s.total_paid), color: 'text-emerald-600' },
              { label: t('Kalan Alacak'), value: fmt(s.total_remaining), color: s.total_remaining > 0 ? 'text-red-600' : 'text-gray-400 dark:text-slate-500' },
              { label: t('Sipariş Sayısı'), value: String(s.order_count), color: 'text-indigo-600' },
            ].map(item => (
              <div key={item.label} className="bg-gray-50 dark:bg-slate-700/50 rounded-xl p-3 text-center">
                <p className="text-xs text-gray-500 dark:text-slate-400 mb-1">{item.label}</p>
                <p className={`font-bold text-base ${item.color}`}>{item.value}</p>
              </div>
            ))}
          </div>

          {/* Koşullar */}
          <div className="flex flex-wrap gap-4 text-sm border border-gray-200 dark:border-slate-700 rounded-xl p-3">
            <div><span className="text-gray-400 dark:text-slate-500 text-xs">{t('Vade')}</span><p className="font-medium">{c.payment_term_days} gün</p></div>
            <div><span className="text-gray-400 dark:text-slate-500 text-xs">{t('İskonto')}</span><p className="font-medium text-orange-600">{c.discount_rate > 0 ? `%${c.discount_rate}` : '—'}</p></div>
            {c.credit_limit > 0 && <div><span className="text-gray-400 dark:text-slate-500 text-xs">{t('Kredi Limiti')}</span><p className="font-medium">{fmt(c.credit_limit)}</p></div>}
            {c.address && <div className="flex-1"><span className="text-gray-400 dark:text-slate-500 text-xs">{t('Adres')}</span><p className="font-medium text-sm">{c.address}</p></div>}
          </div>

          {/* Sipariş geçmişi */}
          <div>
            <p className="text-xs font-semibold text-gray-500 dark:text-slate-400 uppercase tracking-wide mb-2">{t('Sipariş Geçmişi')}</p>
            {orders.length === 0 ? (
              <p className="text-sm text-gray-400 dark:text-slate-500 py-4 text-center">{t('Henüz sipariş yok')}</p>
            ) : (
              <div className="space-y-2">
                {orders.map((o: any) => {
                  const isExpanded = expandedOrder === o.id;
                  const cfg = STATUS_CONFIG[o.status] || { label: o.status, color: 'bg-gray-100 text-gray-700', icon: Clock };
                  const Icon = cfg.icon;
                  const overdue = o.due_date && !o.is_paid && ['confirmed','shipped','delivered'].includes(o.status) && new Date(o.due_date) < new Date();
                  return (
                    <div key={o.id} className={`border rounded-xl overflow-hidden ${overdue ? 'border-red-200' : 'border-gray-200 dark:border-slate-700'}`}>
                      <div
                        className={`flex items-center gap-3 px-4 py-3 cursor-pointer hover:bg-gray-50 dark:hover:bg-slate-700 ${overdue ? 'bg-red-50 dark:bg-red-900/30' : ''}`}
                        onClick={() => setExpandedOrder(isExpanded ? null : o.id)}
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-mono text-xs text-indigo-700 font-medium">{o.order_number}</span>
                            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${cfg.color}`}>
                              <Icon size={10}/>{cfg.label}
                            </span>
                            {o.is_paid && <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-medium">{t('✓ Ödendi')}</span>}
                            {overdue && <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-medium flex items-center gap-1"><AlertTriangle size={9}/>{t('Vadesi Geçti')}</span>}
                          </div>
                          <p className="text-xs text-gray-400 dark:text-slate-500 mt-0.5">
                            {o.created_at ? new Date(o.created_at).toLocaleDateString('tr-TR') : '—'}
                            {o.due_date ? ` · ${t('Vade:')} ${o.due_date}` : ''}
                          </p>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="font-bold text-gray-900 dark:text-slate-100">{fmt(o.total_amount)}</p>
                          {o.remaining > 0 && <p className="text-xs text-red-600">{t('Kalan:')} {fmt(o.remaining)}</p>}
                          {isExpanded ? <ChevronUp size={14} className="text-gray-400 dark:text-slate-500 mx-auto mt-1"/> : <ChevronDown size={14} className="text-gray-400 dark:text-slate-500 mx-auto mt-1"/>}
                        </div>
                      </div>
                      {isExpanded && (
                        <div className="border-t dark:border-slate-700 px-4 pb-4 pt-3 bg-gray-50 dark:bg-slate-700/50 space-y-3">
                          {/* Kalemler */}
                          <table className="w-full text-xs">
                            <thead><tr className="text-gray-400 dark:text-slate-500 border-b dark:border-slate-600"><th className="text-left pb-1">{t('Ürün')}</th><th className="text-right pb-1">{t('Adet')}</th><th className="text-right pb-1">{t('Birim Fiyat')}</th><th className="text-right pb-1">{t('KDV%')}</th><th className="text-right pb-1">{t('Tutar')}</th></tr></thead>
                            <tbody>
                              {o.items.map((it: any, idx: number) => (
                                <tr key={idx} className="border-b border-gray-100 dark:border-slate-700/50">
                                  <td className="py-1.5 text-gray-700 dark:text-slate-300">{it.product_name}</td>
                                  <td className="py-1.5 text-right">{it.quantity}</td>
                                  <td className="py-1.5 text-right">{fmt(it.unit_price)}</td>
                                  <td className="py-1.5 text-right text-gray-400 dark:text-slate-500">%{it.kdv_rate}</td>
                                  <td className="py-1.5 text-right font-medium">{fmt(it.line_total)}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                          {/* Ödemeler */}
                          {o.payments.length > 0 && (
                            <div className="space-y-1">
                              <p className="text-[11px] font-semibold text-gray-400 dark:text-slate-500 uppercase">{t('Ödemeler')}</p>
                              {o.payments.map((p: any) => (
                                <div key={p.id} className="flex justify-between text-xs bg-emerald-50 dark:bg-emerald-900/30 rounded-lg px-3 py-1.5">
                                  <span className="font-semibold text-emerald-700">{fmt(p.amount)}</span>
                                  <span className="text-gray-500 dark:text-slate-400">{t(PM_LABELS[p.payment_method] || p.payment_method)}{p.notes ? ` · ${p.notes}` : ''}</span>
                                  <span className="text-gray-400 dark:text-slate-500">{p.paid_at ? new Date(p.paid_at).toLocaleDateString('tr-TR') : ''}</span>
                                </div>
                              ))}
                            </div>
                          )}
                          <div className="flex justify-between text-xs font-bold pt-1 border-t border-gray-200 dark:border-slate-600">
                            <span>{t('Toplam')}</span><span>{fmt(o.total_amount)}</span>
                          </div>
                          {o.remaining > 0 && (
                            <div className="flex justify-between text-xs text-red-600 font-semibold">
                              <span>{t('Kalan Alacak')}</span><span>{fmt(o.remaining)}</span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {c.notes && (
            <div className="text-sm text-gray-600 dark:text-slate-400 bg-yellow-50 dark:bg-yellow-900/30 rounded-xl p-3">
              <span className="font-medium text-yellow-800">{t('Not:')} </span>{c.notes}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Customer Modal ───────────────────────────────────────────

function CustomerModal({ customer, onClose, onSaved, showToast }: {
  customer?: BtbCustomer | null; onClose: () => void;
  onSaved: () => void; showToast: (m: string, t: string) => void;
}) {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const [form, setForm] = useState({
    company_name: customer?.company_name || '',
    contact_person: customer?.contact_person || '',
    phone: customer?.phone || '',
    email: customer?.email || '',
    vkn: customer?.vkn || '',
    tax_office: customer?.tax_office || '',
    address: customer?.address || '',
    notes: customer?.notes || '',
    category: customer?.category || 'B',
    discount_rate: customer?.discount_rate?.toString() || '0',
    credit_limit: customer?.credit_limit?.toString() || '0',
    payment_term_days: customer?.payment_term_days?.toString() || '30',
    is_active: customer?.is_active ?? true,
  });
  const [saving, setSaving] = useState(false);

  async function handleSubmit() {
    if (!form.company_name) { showToast(t('Firma adı zorunlu'), 'error'); return; }
    setSaving(true);
    try {
      const payload = {
        ...form,
        discount_rate: parseFloat(form.discount_rate) || 0,
        credit_limit: parseFloat(form.credit_limit) || 0,
        payment_term_days: parseInt(form.payment_term_days) || 30,
      };
      if (customer) {
        await apiRequest(`/btb/customers/${customer.id}`, { method: 'PUT', body: JSON.stringify(payload) });
        showToast(t('Müşteri güncellendi'), 'success');
      } else {
        await apiRequest('/btb/customers', { method: 'POST', body: JSON.stringify(payload) });
        showToast(t('Müşteri eklendi'), 'success');
      }
      onSaved();
    } catch (e: any) { showToast(e.message || t('Hata'), 'error'); }
    finally { setSaving(false); }
  }

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="p-4 border-b dark:border-slate-700 flex items-center justify-between bg-gray-50 dark:bg-slate-700/50 rounded-t-2xl">
          <h2 className="font-bold text-lg">{customer ? t('Müşteriyi Düzenle') : t('Yeni Müşteri')}</h2>
          <button onClick={onClose} className="text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 text-xl">✕</button>
        </div>
        <div className="p-4 space-y-3">
          <input value={form.company_name} onChange={e => setForm(f => ({ ...f, company_name: e.target.value }))}
            placeholder={t('Firma Adı *')} className="w-full border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
          <div className="grid grid-cols-2 gap-2">
            <input value={form.contact_person} onChange={e => setForm(f => ({ ...f, contact_person: e.target.value }))}
              placeholder={t('Yetkili Kişi')} className="border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            <input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
              placeholder={t('Telefon')} className="border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <input value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
              placeholder={t('E-posta')} className="border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            <input value={form.vkn} onChange={e => setForm(f => ({ ...f, vkn: e.target.value }))}
              placeholder={t('VKN / TCKN')} className="border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
          </div>
          <input value={form.tax_office} onChange={e => setForm(f => ({ ...f, tax_office: e.target.value }))}
            placeholder={t('Vergi Dairesi')} className="w-full border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
          <textarea value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))}
            placeholder={t('Adres')} rows={2} className="w-full border rounded-xl px-3 py-2 text-sm resize-none dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="text-xs text-gray-500 dark:text-slate-400 mb-1 block">{t('Kategori')}</label>
              <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
                className="w-full border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100">
                <option value="A">{t('A — Öncelikli')}</option>
                <option value="B">{t('B — Standart')}</option>
                <option value="C">{t('C — Dikkatli')}</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-gray-500 dark:text-slate-400 mb-1 block">{t('İskonto %')}</label>
              <input type="number" min="0" max="100" step="0.5" value={form.discount_rate}
                onChange={e => setForm(f => ({ ...f, discount_rate: e.target.value }))}
                className="w-full border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            </div>
            <div>
              <label className="text-xs text-gray-500 dark:text-slate-400 mb-1 block">{t('Vade (Gün)')}</label>
              <input type="number" min="0" value={form.payment_term_days}
                onChange={e => setForm(f => ({ ...f, payment_term_days: e.target.value }))}
                className="w-full border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
            </div>
          </div>
          <div>
            <label className="text-xs text-gray-500 dark:text-slate-400 mb-1 block">{t('Kredi Limiti ₺ (0 = limitsiz)')}</label>
            <input type="number" min="0" step="100" value={form.credit_limit}
              onChange={e => setForm(f => ({ ...f, credit_limit: e.target.value }))}
              className="w-full border rounded-xl px-3 py-2 text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
          </div>
          <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
            placeholder={t('Not')} rows={2} className="w-full border rounded-xl px-3 py-2 text-sm resize-none dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.is_active} onChange={e => setForm(f => ({ ...f, is_active: e.target.checked }))} className="rounded" />
            {t('Aktif Müşteri')}
          </label>
          <div className="flex gap-3 pt-2">
            <button onClick={handleSubmit} disabled={saving}
              className="flex-1 bg-indigo-600 text-white rounded-xl py-2.5 font-medium hover:bg-indigo-700 disabled:opacity-50">
              {saving ? t('Kaydediliyor…') : customer ? t('Güncelle') : t('Müşteri Ekle')}
            </button>
            <button onClick={onClose} className="px-6 border border-gray-200 dark:border-slate-600 rounded-xl text-gray-600 dark:text-slate-300 hover:bg-gray-50 dark:hover:bg-slate-700">{t('İptal')}</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────

interface Props {
  currentUser: any;
  showToast: (msg: string, type: string) => void;
  navigateTo?: (view: string) => void;
}

interface ActivityLog {
  id: number; btb_customer_id: number; company_name: string;
  action: string; details?: any; created_at?: string;
}

export default function BTBView({ currentUser, showToast }: Props) {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const [tab, setTab] = useState<'orders' | 'customers' | 'portal'>('orders');
  const [stats, setStats] = useState<any>(null);
  const [orders, setOrders] = useState<BtbOrder[]>([]);
  const [customers, setCustomers] = useState<BtbCustomer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [pendingCount, setPendingCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<BtbOrder | null>(null);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [showCustomerModal, setShowCustomerModal] = useState(false);
  const [editCustomer, setEditCustomer] = useState<BtbCustomer | null>(null);
  const [detailCustomerId, setDetailCustomerId] = useState<number | null>(null);

  const canAdd = currentUser?.role === 'bayi_sahibi' || currentUser?.permissions?.includes('btb.add');
  const canEdit = currentUser?.role === 'bayi_sahibi' || currentUser?.permissions?.includes('btb.edit');
  const canDelete = currentUser?.role === 'bayi_sahibi' || currentUser?.permissions?.includes('btb.delete');

  const loadAll = useCallback(async () => {
    try {
      const [s, o, c, p] = await Promise.all([
        apiRequest('/btb/stats'),
        apiRequest('/btb/orders'),
        apiRequest('/btb/customers'),
        apiRequest('/products'),
      ]);
      setStats(s);
      setOrders(Array.isArray(o) ? o : []);
      setCustomers(Array.isArray(c) ? c : []);
      const rawP = p?.items || p;
      setProducts(Array.isArray(rawP) ? rawP : []);
      const [activity] = await Promise.allSettled([
        apiRequest('/btb/portal/activity-summary', { method: 'GET' }),
      ]);
      if (activity.status === 'fulfilled' && activity.value) {
        setActivityLogs(activity.value.logs || []);
        setPendingCount(activity.value.pending_count || 0);
      }
    } catch (e: any) { showToast(e.message || t('Yükleme hatası'), 'error'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);
  useRefreshOnChange(loadAll);

  async function handleOrderAction(orderId: number, action: string) {
    try {
      if (action === 'delete') {
        if (!confirm(t('Bu siparişi silmek istiyor musunuz?'))) return;
        await apiRequest(`/btb/orders/${orderId}`, { method: 'DELETE' });
        setSelectedOrder(null);
        showToast(t('Sipariş silindi'), 'success');
      } else if (action === 'payment_added' || action === 'payment_deleted') {
        // falls through to refresh
      } else {
        await apiRequest(`/btb/orders/${orderId}/${action}`, { method: 'POST' });
        const labels: Record<string, string> = {
          confirm: t('Sipariş onaylandı'), ship: t('Kargoya verildi'),
          deliver: t('Teslim edildi'), cancel: t('İptal edildi'), 'mark-paid': t('Ödendi işaretlendi'),
          'portal-approve': t('Portal siparişi onaylandı'), 'portal-reject': t('Portal siparişi reddedildi'),
        };
        showToast(labels[action] || t('Güncellendi'), 'success');
      }
      if (selectedOrder && action !== 'delete') {
        const updated = await apiRequest(`/btb/orders/${orderId}`);
        setSelectedOrder(updated);
      }
      await loadAll();
    } catch (e: any) { showToast(e.message || t('Hata'), 'error'); }
  }

  async function handleDeleteCustomer(c: BtbCustomer) {
    const msg = lang === 'en' ? `Delete "${c.company_name}"?` : `"${c.company_name}" silinsin mi?`;
    if (!confirm(msg)) return;
    try {
      await apiRequest(`/btb/customers/${c.id}`, { method: 'DELETE' });
      showToast(t('Müşteri silindi'), 'success');
      loadAll();
    } catch (e: any) { showToast(e.message || t('Hata'), 'error'); }
  }

  const filteredOrders = orders.filter(o => {
    if (statusFilter && o.status !== statusFilter) return false;
    if (search && !o.order_number.toLowerCase().includes(search.toLowerCase()) &&
        !o.customer_name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const filteredCustomers = customers.filter(c => {
    if (categoryFilter && c.category !== categoryFilter) return false;
    if (search && !c.company_name.toLowerCase().includes(search.toLowerCase()) &&
        !(c.contact_person || '').toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600" />
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-4 py-4 sm:py-6">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-slate-100">B2B Sipariş</h1>
          <p className="text-xs sm:text-sm text-gray-500 dark:text-slate-400 mt-0.5">Kurumsal müşteri siparişleri, iskonto ve alacak takibi</p>
        </div>
      </div>

      {stats && <StatsBar stats={stats} />}

      {/* Bekleyen portal sipariş banner */}
      {pendingCount > 0 && (
        <div className="mb-4 bg-orange-50 dark:bg-orange-900/30 border border-orange-200 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div className="flex items-center gap-2">
            <AlertTriangle size={16} className="text-orange-500 flex-shrink-0" />
            <span className="text-orange-800 font-medium text-sm">
              <span className="font-bold">{pendingCount}</span> portal siparişi onay bekliyor
            </span>
          </div>
          <button onClick={() => setStatusFilter('pending_approval')}
            className="text-sm text-orange-600 font-medium hover:text-orange-800 underline underline-offset-2 self-start sm:self-auto">
            Bekleyenleri Göster →
          </button>
        </div>
      )}

      <div className="flex flex-wrap gap-1 bg-gray-100 dark:bg-slate-700 rounded-xl p-1 mb-5 w-fit">
        {[
          { key: 'orders', label: `Siparişler (${orders.length})` },
          { key: 'customers', label: `Müşteriler (${customers.length})` },
          { key: 'portal', label: `Aktivite (${activityLogs.length})` },
        ].map(t => (
          <button key={t.key} onClick={() => setTab(t.key as any)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${tab === t.key ? 'bg-white dark:bg-slate-800 text-indigo-700 shadow-sm' : 'text-gray-600 dark:text-slate-300 hover:text-gray-900 dark:hover:text-slate-100'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'orders' && (
        <div>
          <div className="space-y-3 mb-4">
            <div className="flex flex-wrap gap-1">
              {[['', 'Tümü'], ...Object.entries(STATUS_CONFIG).map(([k, v]) => [k, v.label])].map(([k, l]) => (
                <button key={k} onClick={() => setStatusFilter(k)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${statusFilter === k ? 'bg-indigo-600 text-white' : 'bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-slate-300 hover:bg-gray-200 dark:hover:bg-slate-600'}`}>
                  {l}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-slate-500" />
                <input value={search} onChange={e => setSearch(e.target.value)}
                  placeholder="Sipariş no veya müşteri ara…" className="w-full pl-8 pr-3 py-2 border rounded-xl text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
              </div>
              {canAdd && (
                <button onClick={() => setShowOrderModal(true)}
                  className="flex items-center gap-2 bg-indigo-600 text-white px-3 sm:px-4 py-2 rounded-xl text-sm font-medium hover:bg-indigo-700 whitespace-nowrap">
                  <Plus size={15}/><span className="hidden sm:inline">Yeni Sipariş</span><span className="sm:hidden">Yeni</span>
                </button>
              )}
            </div>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-gray-200 dark:border-slate-700 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[560px]">
                <thead className="bg-gray-50 dark:bg-slate-700/50 border-b dark:border-slate-700">
                  <tr>
                    <th className="text-left p-3 text-xs font-semibold text-gray-500 dark:text-slate-400">Sipariş No</th>
                    <th className="text-left p-3 text-xs font-semibold text-gray-500 dark:text-slate-400">Müşteri</th>
                    <th className="hidden sm:table-cell text-left p-3 text-xs font-semibold text-gray-500 dark:text-slate-400">Tarih / Vade</th>
                    <th className="text-right p-3 text-xs font-semibold text-gray-500 dark:text-slate-400">Tutar</th>
                    <th className="text-left p-3 text-xs font-semibold text-gray-500 dark:text-slate-400">Durum</th>
                    <th className="hidden sm:table-cell text-left p-3 text-xs font-semibold text-gray-500 dark:text-slate-400">Ödeme</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredOrders.length === 0 ? (
                    <tr><td colSpan={6} className="text-center py-12 text-gray-400 dark:text-slate-500 text-sm">Sipariş bulunamadı</td></tr>
                  ) : filteredOrders.map(o => {
                    const overdue = isOverdue(o);
                    return (
                      <tr key={o.id} onClick={() => setSelectedOrder(o)}
                        className={`border-t dark:border-slate-700 cursor-pointer hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition-colors ${overdue ? 'bg-red-50 dark:bg-red-900/30' : ''}`}>
                        <td className="p-3">
                          <span className="font-mono text-xs font-medium text-indigo-700">{o.order_number}</span>
                          {overdue && <AlertTriangle size={12} className="inline text-red-500 ml-1"/>}
                        </td>
                        <td className="p-3">
                          <p className="text-sm font-medium leading-tight">{o.customer_name}</p>
                          {o.tracking_number && <p className="text-xs text-gray-400 dark:text-slate-500 flex items-center gap-1 mt-0.5"><Truck size={10}/>{o.tracking_number}</p>}
                        </td>
                        <td className="hidden sm:table-cell p-3 text-xs text-gray-500 dark:text-slate-400">
                          <p>{o.created_at ? new Date(o.created_at).toLocaleDateString('tr-TR') : '—'}</p>
                          {o.due_date && <p className={`mt-0.5 ${overdue ? 'text-red-600 font-medium' : ''}`}>Vade: {o.due_date}</p>}
                        </td>
                        <td className="p-3 text-right">
                          <p className="text-sm font-bold whitespace-nowrap">{fmt(o.total_amount, o.currency)}</p>
                          {o.remaining > 0 && o.remaining < o.total_amount && (
                            <p className="text-xs text-orange-600 whitespace-nowrap">Kalan: {fmt(o.remaining, o.currency)}</p>
                          )}
                        </td>
                        <td className="p-3"><StatusBadge status={o.status} /></td>
                        <td className="hidden sm:table-cell p-3">
                          {o.is_paid
                            ? <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-medium">✓ Ödendi</span>
                            : o.paid_total > 0
                              ? <span className="text-xs bg-orange-100 text-orange-700 px-2 py-0.5 rounded-full font-medium">Kısmi</span>
                              : <span className="text-xs text-gray-400 dark:text-slate-500">Bekliyor</span>}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {tab === 'customers' && (
        <div>
          <div className="space-y-3 mb-4">
            <div className="flex flex-wrap gap-1">
              {[['', 'Tümü'], ['A', 'A Sınıfı'], ['B', 'B Sınıfı'], ['C', 'C Sınıfı']].map(([k, l]) => (
                <button key={k} onClick={() => setCategoryFilter(k)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${categoryFilter === k ? 'bg-indigo-600 text-white' : 'bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-slate-300 hover:bg-gray-200 dark:hover:bg-slate-600'}`}>
                  {l}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-slate-500" />
                <input value={search} onChange={e => setSearch(e.target.value)}
                  placeholder="Firma ara…" className="w-full pl-8 pr-3 py-2 border rounded-xl text-sm dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100" />
              </div>
              {canAdd && (
                <button onClick={() => { setEditCustomer(null); setShowCustomerModal(true); }}
                  className="flex items-center gap-2 bg-indigo-600 text-white px-3 sm:px-4 py-2 rounded-xl text-sm font-medium hover:bg-indigo-700 whitespace-nowrap">
                  <Plus size={15}/><span className="hidden sm:inline">Yeni Müşteri</span><span className="sm:hidden">Yeni</span>
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredCustomers.length === 0 ? (
              <div className="col-span-3 text-center py-12 text-gray-400 dark:text-slate-500 text-sm">Müşteri bulunamadı</div>
            ) : filteredCustomers.map(c => {
              const catCfg = CATEGORY_CONFIG[c.category] || CATEGORY_CONFIG.B;
              return (
                <div key={c.id} onClick={() => setDetailCustomerId(c.id)} className={`bg-white dark:bg-slate-800 rounded-2xl border-2 p-4 cursor-pointer hover:shadow-md transition-shadow ${!c.is_active ? 'opacity-60' : ''} ${c.overdue_count > 0 ? 'border-red-200' : 'border-gray-200 dark:border-slate-700'}`}>
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-bold text-gray-900 dark:text-slate-100 truncate">{c.company_name}</h3>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium shrink-0 ${catCfg.color}`}>{c.category}</span>
                        {c.overdue_count > 0 && <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full flex items-center gap-1 shrink-0"><AlertTriangle size={10}/>{c.overdue_count}</span>}
                      </div>
                      {c.contact_person && <p className="text-xs text-gray-500 dark:text-slate-400 mt-0.5">{c.contact_person}</p>}
                    </div>
                    <div className="flex gap-1 shrink-0 ml-2">
                      {canEdit && <button onClick={e => { e.stopPropagation(); setEditCustomer(c); setShowCustomerModal(true); }} className="p-1.5 text-gray-400 dark:text-slate-500 hover:text-indigo-600 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-900/30"><Edit3 size={14}/></button>}
                      {canDelete && <button onClick={e => { e.stopPropagation(); handleDeleteCustomer(c); }} className="p-1.5 text-gray-400 dark:text-slate-500 hover:text-red-600 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/30"><Trash2 size={14}/></button>}
                    </div>
                  </div>

                  <div className="space-y-0.5 text-xs text-gray-500 dark:text-slate-400 mb-3">
                    {c.phone && <p className="flex items-center gap-1.5"><Phone size={11}/>{c.phone}</p>}
                    {c.email && <p className="flex items-center gap-1.5"><Mail size={11}/>{c.email}</p>}
                    {c.vkn && <p className="flex items-center gap-1.5"><Tag size={11}/>VKN: {c.vkn}{c.tax_office ? ` / ${c.tax_office}` : ''}</p>}
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-3 border-t dark:border-slate-700 text-sm">
                    <div><p className="text-xs text-gray-400 dark:text-slate-500">Açık Borç</p><p className={`font-bold ${c.total_debt > 0 ? 'text-red-600' : 'text-gray-400 dark:text-slate-500'}`}>{fmt(c.total_debt)}</p></div>
                    <div><p className="text-xs text-gray-400 dark:text-slate-500">Sipariş</p><p className="font-bold">{c.order_count}</p></div>
                    <div><p className="text-xs text-gray-400 dark:text-slate-500">Vade</p><p className="font-medium">{c.payment_term_days} gün</p></div>
                    <div><p className="text-xs text-gray-400 dark:text-slate-500">İskonto</p><p className="font-medium text-orange-600">{c.discount_rate > 0 ? `%${c.discount_rate}` : '—'}</p></div>
                  </div>

                  {c.credit_limit > 0 && (
                    <div className="mt-3">
                      <div className="flex justify-between text-xs text-gray-500 dark:text-slate-400 mb-1">
                        <span>Kredi Kullanımı</span>
                        <span>{fmt(c.total_debt)} / {fmt(c.credit_limit)}</span>
                      </div>
                      <div className="h-1.5 bg-gray-200 dark:bg-slate-600 rounded-full overflow-hidden">
                        <div className={`h-full rounded-full ${c.total_debt >= c.credit_limit ? 'bg-red-500' : c.total_debt >= c.credit_limit * 0.8 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                          style={{ width: `${Math.min(100, (c.total_debt / c.credit_limit) * 100)}%` }} />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {tab === 'portal' && (
        <div className="space-y-4">
          {/* Bağlı müşteri hesapları özeti */}
          <div className="bg-gradient-to-r from-indigo-50 dark:from-indigo-900/30 to-blue-50 dark:to-blue-900/30 border border-indigo-200 rounded-2xl p-5">
            <h3 className="font-bold text-indigo-900 text-sm mb-1">Müşteri Portal Erişimi</h3>
            <p className="text-xs text-indigo-700">
              Müşterileriniz <strong>stokfinans.com</strong>'a, B2B kartındaki e-posta ile kayıt olduklarında otomatik olarak
              bu hesaba bağlanır ve B2B alışveriş paneline erişir.
            </p>
            <div className="mt-3 grid grid-cols-1 sm:grid-cols-3 gap-3">
              {customers.filter(c => c.email).map(c => {
                const linked = activityLogs.some(l => l.btb_customer_id === c.id);
                return (
                  <div key={c.id} className={`bg-white dark:bg-slate-800 rounded-xl border p-3 ${linked ? 'border-emerald-200' : 'border-gray-200 dark:border-slate-700'}`}>
                    <div className="flex items-center gap-2 mb-1">
                      {linked
                        ? <span className="w-2 h-2 bg-emerald-500 rounded-full" />
                        : <span className="w-2 h-2 bg-gray-300 dark:bg-slate-600 rounded-full" />}
                      <p className="font-medium text-gray-900 dark:text-slate-100 text-xs truncate">{c.company_name}</p>
                    </div>
                    <p className="text-[11px] text-gray-500 dark:text-slate-400 truncate">{c.email}</p>
                    {linked
                      ? <p className="text-[10px] text-emerald-600 font-medium mt-0.5">Hesap aktif</p>
                      : <p className="text-[10px] text-gray-400 dark:text-slate-500 mt-0.5">Kayıt bekleniyor</p>}
                  </div>
                );
              })}
              {customers.filter(c => c.email).length === 0 && (
                <p className="text-xs text-indigo-700 col-span-3">Müşteri e-posta adresi girilmemiş. Müşteri kartında e-posta ekleyin.</p>
              )}
            </div>
          </div>

          {/* Aktivite akışı */}
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-gray-200 dark:border-slate-700 overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100 dark:border-slate-700 flex items-center justify-between">
              <h3 className="font-bold text-gray-800 dark:text-slate-200">Müşteri Aktiviteleri</h3>
              <button onClick={() => loadAll()} className="p-1.5 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700">
                <RefreshCw size={14} />
              </button>
            </div>
            {activityLogs.length === 0 ? (
              <div className="py-12 text-center text-gray-400 dark:text-slate-500 text-sm">
                Henüz aktivite yok.<br />
                <span className="text-xs">Müşterileriniz sisteme giriş yaptığında burada görünür.</span>
              </div>
            ) : (
              <div className="divide-y divide-gray-100 dark:divide-slate-700">
                {activityLogs.map(log => {
                  const actionLabels: Record<string, string> = {
                    login: 'Giriş yaptı',
                    view_products: 'Ürünleri inceledi',
                    checkout: 'Sipariş verdi',
                    view_orders: 'Siparişlerine baktı',
                    view_order_detail: 'Sipariş detayını gördü',
                  };
                  const actionColors: Record<string, string> = {
                    login: 'bg-blue-100 text-blue-700',
                    view_products: 'bg-gray-100 text-gray-600',
                    checkout: 'bg-emerald-100 text-emerald-700',
                    view_orders: 'bg-purple-100 text-purple-700',
                    view_order_detail: 'bg-purple-50 text-purple-600',
                  };
                  return (
                    <div key={log.id} className="px-5 py-3 flex items-center gap-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${actionColors[log.action] || 'bg-gray-100 text-gray-600'}`}>
                        {actionLabels[log.action] || log.action}
                      </span>
                      <span className="font-medium text-gray-800 dark:text-slate-200 text-sm flex-1 min-w-0 truncate">{log.company_name}</span>
                      {log.details?.order_number && (
                        <span className="text-xs font-mono bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-slate-300 px-2 py-0.5 rounded">{log.details.order_number}</span>
                      )}
                      {log.details?.count !== undefined && (
                        <span className="text-xs text-gray-400 dark:text-slate-500">{log.details.count} ürün</span>
                      )}
                      <span className="text-xs text-gray-400 dark:text-slate-500 shrink-0">
                        {log.created_at ? new Date(log.created_at).toLocaleString('tr-TR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—'}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* PLACEHOLDER - old portal content removed below */}
      {false && (
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-indigo-50 dark:from-indigo-900/30 to-purple-50 border border-indigo-200 rounded-2xl p-5">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <h3 className="font-bold text-indigo-900 text-sm mb-1">Müşteri Portal Bağlantısı</h3>
                <p className="text-xs text-indigo-700 mb-2">Bu adresi müşterilerinizle paylaşın. Kayıt olup sipariş verebilirler.</p>
                <code className="text-xs bg-white dark:bg-slate-800 border border-indigo-200 rounded-lg px-3 py-1.5 text-indigo-800 font-mono break-all">
                  {window.location.origin}/?portal=1&bayi={currentUser?.id}
                </code>
              </div>
              <button
                onClick={() => {
                  const url = `${window.location.origin}/?portal=1&bayi=${currentUser?.id}`;
                  navigator.clipboard.writeText(url).then(() => showToast('Bağlantı kopyalandı', 'success'));
                }}
                className="shrink-0 px-4 py-2 bg-indigo-600 text-white text-sm rounded-xl hover:bg-indigo-700 font-medium"
              >
                Kopyala
              </button>
            </div>
          </div>

          {/* Portal accounts table */}
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-gray-200 dark:border-slate-700 overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100 dark:border-slate-700 flex items-center justify-between">
              <h3 className="font-bold text-gray-800 dark:text-slate-200">Portal Hesapları</h3>
              <span className="text-xs text-gray-500 dark:text-slate-400">{portalAccounts.length} hesap</span>
            </div>
            {portalAccounts.length === 0 ? (
              <div className="py-12 text-center text-gray-400 dark:text-slate-500 text-sm">
                Henüz portal hesabı yok.<br />
                <span className="text-xs">Müşteriler portal bağlantısından kaydolduğunda burada görünür.</span>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-[540px]">
                  <thead className="bg-gray-50 dark:bg-slate-700/50">
                    <tr className="text-xs text-gray-500 dark:text-slate-400 uppercase tracking-wide">
                      <th className="text-left px-5 py-3">Firma / Hesap</th>
                      <th className="text-left px-5 py-3 hidden sm:table-cell">E-posta</th>
                      <th className="text-left px-5 py-3 hidden sm:table-cell">Son Giriş</th>
                      <th className="text-left px-5 py-3">Durum</th>
                      <th className="px-5 py-3"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-slate-700">
                    {portalAccounts.map(acc => (
                      <tr key={acc.id} className="hover:bg-gray-50 dark:hover:bg-slate-700">
                        <td className="px-5 py-3">
                          <p className="font-medium text-gray-900 dark:text-slate-100 text-sm">{acc.company_name}</p>
                          {acc.full_name && <p className="text-xs text-gray-500 dark:text-slate-400">{acc.full_name}</p>}
                          <p className="text-xs text-gray-500 dark:text-slate-400 sm:hidden">{acc.email}</p>
                        </td>
                        <td className="px-5 py-3 text-sm text-gray-600 dark:text-slate-400 hidden sm:table-cell">{acc.email}</td>
                        <td className="px-5 py-3 text-xs text-gray-500 dark:text-slate-400 hidden sm:table-cell">
                          {acc.last_login ? new Date(acc.last_login).toLocaleDateString('tr-TR') : '—'}
                        </td>
                        <td className="px-5 py-3">
                          {acc.is_active
                            ? <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-700"><CheckCircle size={11}/>Aktif</span>
                            : <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-700"><XCircle size={11}/>Askıya Alındı</span>
                          }
                        </td>
                        <td className="px-5 py-3 text-right">
                          {acc.is_active ? (
                            <button
                              onClick={async () => {
                                await apiRequest(`/btb/portal/accounts/${acc.id}/suspend`, { method: 'POST' });
                                showToast('Hesap askıya alındı', 'success');
                                loadAll();
                              }}
                              className="text-xs text-red-600 hover:text-red-800 font-medium px-2 py-1 rounded hover:bg-red-50 dark:hover:bg-red-900/30"
                            >Askıya Al</button>
                          ) : (
                            <button
                              onClick={async () => {
                                await apiRequest(`/btb/portal/accounts/${acc.id}/activate`, { method: 'POST' });
                                showToast('Hesap aktifleştirildi', 'success');
                                loadAll();
                              }}
                              className="text-xs text-emerald-600 hover:text-emerald-800 font-medium px-2 py-1 rounded hover:bg-emerald-50 dark:hover:bg-emerald-900/30"
                            >Aktifleştir</button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {selectedOrder && (
        <OrderDetailModal order={selectedOrder} onClose={() => setSelectedOrder(null)}
          onAction={handleOrderAction} currentUser={currentUser} />
      )}
      {detailCustomerId && (
        <CustomerDetailModal customerId={detailCustomerId} onClose={() => setDetailCustomerId(null)} showToast={showToast} />
      )}
      {showOrderModal && (
        <OrderModal customers={customers} products={products}
          onClose={() => setShowOrderModal(false)}
          onSaved={() => { setShowOrderModal(false); loadAll(); }}
          showToast={showToast} />
      )}
      {showCustomerModal && (
        <CustomerModal customer={editCustomer}
          onClose={() => { setShowCustomerModal(false); setEditCustomer(null); }}
          onSaved={() => { setShowCustomerModal(false); setEditCustomer(null); loadAll(); }}
          showToast={showToast} />
      )}
    </div>
  );
}
