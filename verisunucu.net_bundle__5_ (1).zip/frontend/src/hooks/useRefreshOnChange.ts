import { useEffect, useRef } from 'react';
import { refreshBus } from '../lib/refreshBus';

// silent=true → arka plan yenileme, loading spinner göstermez
export function useRefreshOnChange(fetchFn: (silent?: boolean) => void): void {
  const ref = useRef(fetchFn);
  ref.current = fetchFn;

  useEffect(() => {
    return refreshBus.subscribe(() => ref.current(true));
  }, []);
}
