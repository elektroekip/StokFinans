import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';

interface ZoomImgProps {
  src: string;
  alt?: string;
  className?: string;
  style?: React.CSSProperties;
  draggable?: boolean;
}

export function ZoomImg({ src, alt = '', className = '', style, draggable }: ZoomImgProps) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open]);

  return (
    <>
      <img
        src={src}
        alt={alt}
        className={`${className} cursor-zoom-in`}
        style={style}
        draggable={draggable}
        onClick={(e) => { e.stopPropagation(); setOpen(true); }}
      />
      {open && createPortal(
        <div
          className="fixed inset-0 z-[9999] bg-black/85 flex items-center justify-center cursor-zoom-out"
          onClick={() => setOpen(false)}
        >
          <img
            src={src}
            alt={alt}
            className="max-w-[90vw] max-h-[90vh] object-contain rounded-xl shadow-2xl"
            onClick={(e) => { e.stopPropagation(); setOpen(false); }}
          />
        </div>,
        document.body
      )}
    </>
  );
}
