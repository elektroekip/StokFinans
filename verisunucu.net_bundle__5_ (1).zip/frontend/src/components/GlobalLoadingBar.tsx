import { useEffect, useRef, useState } from 'react';

// ── Module-level request counter ──────────────────────────────────────────────
// api.ts interceptors call these directly (no React context needed).
let _count = 0;
const _subs = new Set<(active: boolean) => void>();

export function loadingStart() {
  _count++;
  if (_count === 1) _subs.forEach(f => f(true));
}

export function loadingEnd() {
  _count = Math.max(0, _count - 1);
  if (_count === 0) _subs.forEach(f => f(false));
}

// ── Component ─────────────────────────────────────────────────────────────────
type Phase = 'hidden' | 'growing' | 'completing' | 'fading';

export function GlobalLoadingBar() {
  const [phase, setPhase]       = useState<Phase>('hidden');
  const [progress, setProgress] = useState(0);
  const growTimer = useRef<ReturnType<typeof setInterval>>();
  const hideTimer = useRef<ReturnType<typeof setTimeout>>();
  const progressRef = useRef(0);

  useEffect(() => {
    const handler = (active: boolean) => {
      if (active) {
        clearInterval(growTimer.current);
        clearTimeout(hideTimer.current);
        progressRef.current = 8;
        setProgress(8);
        setPhase('growing');

        // Grows to ~88% asymptotically — never reaches 100% on its own
        growTimer.current = setInterval(() => {
          progressRef.current += (88 - progressRef.current) * 0.04;
          setProgress(progressRef.current);
        }, 120);
      } else {
        // Complete → fade
        clearInterval(growTimer.current);
        setProgress(100);
        setPhase('completing');
        hideTimer.current = setTimeout(() => {
          setPhase('fading');
          hideTimer.current = setTimeout(() => {
            setPhase('hidden');
            setProgress(0);
            progressRef.current = 0;
          }, 280);
        }, 220);
      }
    };

    _subs.add(handler);
    return () => {
      _subs.delete(handler);
      clearInterval(growTimer.current);
      clearTimeout(hideTimer.current);
    };
  }, []);

  if (phase === 'hidden') return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-[99999] h-[3px] pointer-events-none">
      <div
        className="h-full bg-indigo-500"
        style={{
          width: `${progress}%`,
          opacity: phase === 'fading' ? 0 : 1,
          transition:
            phase === 'completing'
              ? 'width 0.22s ease-in'
              : phase === 'fading'
              ? 'opacity 0.28s ease'
              : 'width 0.12s linear',
          boxShadow: '0 0 8px 1px rgba(99,102,241,0.55)',
        }}
      />
    </div>
  );
}
