// ============================================================
// Protected Route - Güvenli Rota
// ============================================================
// Login olmayan kullanıcıları login sayfasına yönlendir
//
// Seviye: SEVIYE 6 - Köprü Kurma
// Tarih: 28 Nisan 2026
// ============================================================

import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

interface ProtectedRouteProps {
  children: React.ReactNode;
}

/**
 * ProtectedRoute Component
 *
 * Eğer user varsa (login olduysa): children render et
 * Eğer user yoksa: /login sayfasına yönlendir
 *
 * Kullanım:
 * <ProtectedRoute>
 *   <Dashboard />
 * </ProtectedRoute>
 */
export default function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { isAuthenticated, isLoading } = useAuth();

  // Loading sırasında loading göster
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Authenticated değilse login'e yönlendir
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Authenticated ise component'i göster
  return <>{children}</>;
}
