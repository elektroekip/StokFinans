import React, { useState, useEffect, useCallback } from 'react';
import { useRefreshOnChange } from './hooks/useRefreshOnChange';
import api from './lib/api';
import {
  Truck, Plus, Package, RefreshCw, X, Edit2, Trash2,
  ArrowDownToLine, ArrowUpFromLine, ShoppingCart, History,
  Users, UserPlus, UserMinus, CheckCircle, AlertCircle,
  Loader2, Search, Minus, MoreVertical, MapPin, Warehouse, Download,
} from 'lucide-react';
import { exportAraclar } from './utils/exportExcel';

// ─── Types ────────────────────────────────────────────────────────────────────

interface Assignment {
  id: number; user_id: number; user_name: string;
  role: string; role_label: string; assigned_at: string;
}
interface Vehicle {
  id: number; plate: string; nickname?: string;
  status: 'parked' | 'on_tour'; assignments: Assignment[];
  notes?: string; total_quantity: number; distinct_products: number;
  updated_at?: string;
}
interface VehicleItem {
  id: number; product_id: number; product_name: string;
  unit_price: number; currency: string; quantity: number;
}
interface Product {
  id: number; name: string; quantity: number;
  price: number; currency?: string; barcode?: string;
}
interface Employee { id: number; full_name: string; email: string }
interface LogEntry {
  id: number; user_name: string; action: string;
  details?: string; vehicle_status?: string; created_at: string;
}

// ─── Constants ────────────────────────────────────────────────────────────────

const ROLE_OPTIONS = [
  { value: 'driver',    label: 'Şoför' },
  { value: 'helper',   label: 'Yardımcı' },
  { value: 'warehouse', label: 'Depo Sorumlusu' },
];
const ROLE_COLOR: Record<string, string> = {
  driver:    'bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300',
  helper:    'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300',
  warehouse: 'bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300',
};
const ACTION_META: Record<string, { label: string; dot: string }> = {
  load:              { label: 'Yüklendi',         dot: 'bg-emerald-500' },
  unload_depot:      { label: 'Depoya İade',       dot: 'bg-amber-500' },
  unload_sold:       { label: 'Satıldı',           dot: 'bg-blue-500' },
  updated:           { label: 'Güncellendi',        dot: 'bg-slate-400' },
  created:           { label: 'Oluşturuldu',        dot: 'bg-slate-400' },
  assignment_add:    { label: 'Çalışan Atandı',    dot: 'bg-purple-500' },
  assignment_remove: { label: 'Çalışan Çıkarıldı', dot: 'bg-red-500' },
  assignment_update: { label: 'Rol Değişti',       dot: 'bg-purple-400' },
};

// ─── Truck visual ─────────────────────────────────────────────────────────────
// truck.jpg: white box truck on white background (980×980).
// CSS filter gives it a blue tint on-tour, muted grey when parked.
// Count badge is absolutely positioned over the cargo box area (~left 60%).

const TruckSVG = ({ count, on }: { count: number; on: boolean }) => (
  <div className="relative w-full select-none overflow-hidden">
    {/* Truck image — CSS filter: blue tint on tour, desaturated when parked */}
    <img
      src="/truck.jpg"
      alt="Kamyon"
      draggable={false}
      className="w-full h-auto block"
      style={{
        filter: on
          ? 'sepia(1) saturate(3) hue-rotate(195deg) brightness(1.05)'
          : 'saturate(0.45) brightness(0.96)',
      }}
    />
    {/* Count badge — centred over the cargo box (left ~58% of image) */}
    <div
      className="absolute inset-0 flex items-center justify-center"
      style={{ paddingRight: '40%', paddingBottom: '12%' }}
    >
      <div className={`rounded-2xl px-4 py-2 text-center shadow-lg backdrop-blur-sm border ${
        on
          ? 'bg-blue-700/80 border-blue-500/40 text-white'
          : 'bg-black/45 border-white/10 text-white'
      }`}>
        <p className="text-base font-extrabold leading-none tracking-tight">
          {count > 0 ? `${count} adet` : 'Boş'}
        </p>
        <p className={`text-xs mt-1 font-semibold ${on ? 'text-blue-100' : 'text-slate-300'}`}>
          {count > 0 ? 'araç envanteri' : 'yüklü ürün yok'}
        </p>
      </div>
    </div>
  </div>
);

// ─── Modal ────────────────────────────────────────────────────────────────────
// Bottom-sheet on mobile, centered dialog on sm+.
// Header + scrollable body + sticky footer (separate prop so it never scrolls away).

interface ModalProps {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  footer?: React.ReactNode;
  subHeader?: React.ReactNode;
  wide?: boolean;
}

const Modal = ({ title, onClose, children, footer, subHeader, wide }: ModalProps) => (
  <div
    className="fixed inset-0 z-50 flex flex-col justify-end sm:justify-center sm:items-center sm:p-4 bg-black/50 backdrop-blur-sm"
    onClick={onClose}
  >
    <div
      className={`bg-white dark:bg-slate-900 w-full ${wide ? 'sm:max-w-2xl' : 'sm:max-w-md'} sm:rounded-2xl rounded-t-2xl shadow-2xl flex flex-col max-h-[92vh]`}
      onClick={e => e.stopPropagation()}
    >
      {/* Sticky header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
        <h2 className="font-bold text-slate-800 dark:text-slate-100 text-base truncate pr-2">{title}</h2>
        <button onClick={onClose} className="shrink-0 w-9 h-9 flex items-center justify-center rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 transition-colors">
          <X size={18}/>
        </button>
      </div>
      {/* Sticky sub-header (filters etc.) */}
      {subHeader && (
        <div className="border-b border-slate-100 dark:border-slate-800 shrink-0 bg-slate-50 dark:bg-slate-900/80">
          {subHeader}
        </div>
      )}
      {/* Scrollable body */}
      <div className="flex-1 overflow-y-auto px-5 py-4 overscroll-contain">{children}</div>
      {/* Sticky footer – always visible */}
      {footer && (
        <div className="px-5 py-4 border-t border-slate-100 dark:border-slate-800 shrink-0 bg-white dark:bg-slate-900 sm:rounded-b-2xl">
          {footer}
        </div>
      )}
    </div>
  </div>
);

// ─── Shared primitives ────────────────────────────────────────────────────────

const iCls = 'w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors';

const Btn = ({
  onClick, disabled, color = 'blue', variant = 'solid', children, className = '',
}: {
  onClick?: () => void; disabled?: boolean;
  color?: 'blue' | 'emerald' | 'amber' | 'red' | 'purple' | 'slate';
  variant?: 'solid' | 'outline';
  children: React.ReactNode;
  className?: string;
}) => {
  const solid: Record<string, string> = {
    blue:    'bg-blue-600 hover:bg-blue-700 text-white',
    emerald: 'bg-emerald-600 hover:bg-emerald-700 text-white',
    amber:   'bg-amber-500 hover:bg-amber-600 text-white',
    red:     'bg-red-600 hover:bg-red-700 text-white',
    purple:  'bg-purple-600 hover:bg-purple-700 text-white',
    slate:   'bg-slate-600 hover:bg-slate-700 text-white',
  };
  const outline: Record<string, string> = {
    blue:    'border border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-300 hover:bg-blue-50 dark:hover:bg-blue-900/20',
    emerald: 'border border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-900/20',
    amber:   'border border-amber-300 dark:border-amber-700 text-amber-700 dark:text-amber-300 hover:bg-amber-50 dark:hover:bg-amber-900/20',
    red:     'border border-red-300 dark:border-red-700 text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-900/20',
    purple:  'border border-purple-300 dark:border-purple-700 text-purple-700 dark:text-purple-300 hover:bg-purple-50 dark:hover:bg-purple-900/20',
    slate:   'border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800',
  };
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${variant === 'solid' ? solid[color] : outline[color]} ${className}`}
    >
      {children}
    </button>
  );
};

const Field = ({ label, children }: { label: string; children: React.ReactNode }) => (
  <div>
    <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5 uppercase tracking-wide">{label}</label>
    {children}
  </div>
);

const QtyInput = ({
  value, max, onChange,
}: { value: number; max: number; onChange: (n: number) => void }) => (
  <div className="flex items-center gap-1.5 shrink-0">
    <button
      type="button"
      onClick={() => onChange(Math.max(0, value - 1))}
      className="w-9 h-9 rounded-xl border border-slate-200 dark:border-slate-600 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-700 active:scale-95 transition-all"
    >
      <Minus size={14}/>
    </button>
    <input
      type="number" min={0} max={max}
      className="w-14 text-center border border-slate-200 dark:border-slate-600 rounded-xl py-1.5 text-sm font-semibold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
      value={value}
      onChange={e => onChange(Math.max(0, Math.min(max, Number(e.target.value) || 0)))}
    />
    <button
      type="button"
      onClick={() => onChange(Math.min(max, value + 1))}
      className="w-9 h-9 rounded-xl border border-slate-200 dark:border-slate-600 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-700 active:scale-95 transition-all"
    >
      <Plus size={14}/>
    </button>
  </div>
);

// ─── Main Component ───────────────────────────────────────────────────────────

interface VehicleViewProps {
  showToast?: (msg: string, type?: string) => void;
  currentUser?: any;
}

export default function VehicleView({ showToast, currentUser }: VehicleViewProps) {
  const toast = (msg: string, type?: string) => showToast?.(msg, type);
  const isPatron = !currentUser?.parentUserId && currentUser?.role !== 'calisan';

  // ── State ─────────────────────────────────────────────────────────────────

  const [vehicles,  setVehicles]  = useState<Vehicle[]>([]);
  const [loading,   setLoading]   = useState(true);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [products,  setProducts]  = useState<Product[]>([]);
  const [saving,    setSaving]    = useState(false);

  // active vehicle for context menus
  const [menuVehicle, setMenuVehicle] = useState<Vehicle | null>(null);

  // modal: which one is open
  type ModalKind = 'create' | 'edit' | 'inventory' | 'load' | 'unload' | 'log' | 'assign' | null;
  const [modal,        setModal]        = useState<ModalKind>(null);
  const [activeVehicle, setActiveVehicle] = useState<Vehicle | null>(null);

  // modal data
  const [inventoryItems, setInventoryItems] = useState<VehicleItem[]>([]);
  const [logEntries,     setLogEntries]     = useState<LogEntry[]>([]);
  const [innerLoading,   setInnerLoading]   = useState(false);

  // form state
  const [form,         setForm]         = useState({ plate: '', nickname: '', notes: '' });
  const [editForm,     setEditForm]     = useState({ plate: '', nickname: '', status: 'parked', notes: '' });
  const [loadSearch,   setLoadSearch]   = useState('');
  const [loadQtys,     setLoadQtys]     = useState<Record<number, number>>({});
  const [unloadQtys,   setUnloadQtys]   = useState<Record<number, number>>({});
  const [unloadDest,   setUnloadDest]   = useState<'depot' | 'sold'>('depot');
  const [unloadCustomer, setUnloadCustomer] = useState('');
  const [assignUserId, setAssignUserId] = useState(0);
  const [assignRole,   setAssignRole]   = useState('driver');

  // vehicle list controls
  const [plateSearch,    setPlateSearch]    = useState('');
  const [sortByActivity, setSortByActivity] = useState(false);

  // log filters (patron only)
  const [logFilterAction, setLogFilterAction] = useState('all');
  const [logFilterUser,   setLogFilterUser]   = useState('all');
  const [logFilterDate,   setLogFilterDate]   = useState('');

  // ── Data fetching ─────────────────────────────────────────────────────────

  const fetchVehicles = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const r = await api.get('/vehicles');
      setVehicles(r.data);
    } catch { toast('Araçlar yüklenemedi.', 'error'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    fetchVehicles();
    api.get('/products?page_size=500').then(r => setProducts(r.data?.items || r.data || [])).catch(() => {});
    if (isPatron) api.get('/vehicles/employees/list').then(r => setEmployees(r.data)).catch(() => {});
  }, []);
  useRefreshOnChange(fetchVehicles);

  // ── Open helpers ──────────────────────────────────────────────────────────

  const open = (kind: ModalKind, v?: Vehicle) => {
    setMenuVehicle(null);
    setActiveVehicle(v || null);
    setModal(kind);
    setInnerLoading(false);
    if (kind === 'edit' && v) {
      setEditForm({ plate: v.plate, nickname: v.nickname || '', status: v.status, notes: v.notes || '' });
    }
    if (kind === 'load')   { setLoadQtys({}); setLoadSearch(''); }
    if (kind === 'unload') { setUnloadQtys({}); setUnloadDest('depot'); setUnloadCustomer(''); }
    if (kind === 'assign') { setAssignUserId(0); setAssignRole('driver'); }
    if (kind === 'log')    { setLogFilterAction('all'); setLogFilterUser('all'); setLogFilterDate(''); }
  };

  const close = () => { setModal(null); setActiveVehicle(null); };

  // Load lazy data when modal opens
  useEffect(() => {
    if (!activeVehicle) return;
    if (modal === 'inventory' || modal === 'unload') {
      setInnerLoading(true);
      api.get(`/vehicles/${activeVehicle.id}/items`)
        .then(r => setInventoryItems(r.data))
        .catch(() => toast('Envanter yüklenemedi.', 'error'))
        .finally(() => setInnerLoading(false));
    }
    if (modal === 'log') {
      setInnerLoading(true);
      api.get(`/vehicles/${activeVehicle.id}/logs`)
        .then(r => setLogEntries(r.data))
        .catch(() => toast('Log yüklenemedi.', 'error'))
        .finally(() => setInnerLoading(false));
    }
  }, [modal, activeVehicle?.id]);

  // ── Actions ───────────────────────────────────────────────────────────────

  const toggleStatus = async (v: Vehicle) => {
    const next = v.status === 'parked' ? 'on_tour' : 'parked';
    try {
      await api.put(`/vehicles/${v.id}`, { status: next });
      setVehicles(vs => vs.map(x => x.id === v.id ? { ...x, status: next } : x));
    } catch (e: any) { toast(e?.response?.data?.detail || 'Durum değiştirilemedi.', 'error'); }
  };

  const handleCreate = async () => {
    if (!form.plate.trim()) { toast('Plaka zorunludur.', 'error'); return; }
    setSaving(true);
    try {
      await api.post('/vehicles', { plate: form.plate, nickname: form.nickname || null, notes: form.notes || null });
      toast('Araç eklendi.');
      close();
      setForm({ plate: '', nickname: '', notes: '' });
      fetchVehicles();
    } catch (e: any) { toast(e?.response?.data?.detail || 'Hata.', 'error'); }
    finally { setSaving(false); }
  };

  const handleEdit = async () => {
    if (!activeVehicle) return;
    setSaving(true);
    try {
      await api.put(`/vehicles/${activeVehicle.id}`, {
        plate: editForm.plate || undefined,
        nickname: editForm.nickname || null,
        status: editForm.status,
        notes: editForm.notes || null,
      });
      toast('Kaydedildi.');
      close();
      fetchVehicles();
    } catch (e: any) { toast(e?.response?.data?.detail || 'Hata.', 'error'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (v: Vehicle) => {
    setMenuVehicle(null);
    if (!confirm(`"${v.plate}" aracını silmek istediğinizden emin misiniz?`)) return;
    try {
      await api.delete(`/vehicles/${v.id}`);
      toast('Araç silindi.');
      fetchVehicles();
    } catch (e: any) {
      const detail = e?.response?.data?.detail || '';
      if (detail.includes('ürün var')) {
        if (confirm('Araçta ürün var. Yine de silmek istiyor musunuz?')) {
          await api.delete(`/vehicles/${v.id}?force=true`).then(() => { toast('Silindi.'); fetchVehicles(); })
            .catch(e2 => toast(e2?.response?.data?.detail || 'Silinemedi.', 'error'));
        }
      } else toast(detail || 'Silinemedi.', 'error');
    }
  };

  const handleLoad = async () => {
    if (!activeVehicle) return;
    const items = Object.entries(loadQtys).filter(([, q]) => q > 0).map(([pid, q]) => ({ product_id: +pid, quantity: q }));
    if (!items.length) { toast('En az bir ürün seçin.', 'error'); return; }
    setSaving(true);
    try {
      await api.post(`/vehicles/${activeVehicle.id}/load`, { items });
      toast('Araça yüklendi.');
      close();
      fetchVehicles();
      api.get('/products?page_size=500').then(r => setProducts(r.data?.items || r.data || [])).catch(() => {});
    } catch (e: any) { toast(e?.response?.data?.detail || 'Yükleme hatası.', 'error'); }
    finally { setSaving(false); }
  };

  const handleUnload = async () => {
    if (!activeVehicle) return;
    const items = Object.entries(unloadQtys).filter(([, q]) => q > 0).map(([pid, q]) => ({ product_id: +pid, quantity: q }));
    if (!items.length) { toast('En az bir ürün seçin.', 'error'); return; }
    if (unloadDest === 'sold' && !unloadCustomer.trim()) { toast('Müşteri adı gerekli.', 'error'); return; }
    setSaving(true);
    try {
      await api.post(`/vehicles/${activeVehicle.id}/unload`, {
        items, destination: unloadDest,
        customer_name: unloadDest === 'sold' ? unloadCustomer.trim() : undefined,
      });
      toast(unloadDest === 'sold' ? 'Satış kaydedildi.' : 'Depoya iade edildi.');
      close();
      fetchVehicles();
      api.get('/products?page_size=500').then(r => setProducts(r.data?.items || r.data || [])).catch(() => {});
    } catch (e: any) { toast(e?.response?.data?.detail || 'İşlem hatası.', 'error'); }
    finally { setSaving(false); }
  };

  const handleAddAssignment = async () => {
    if (!activeVehicle || !assignUserId) { toast('Çalışan seçin.', 'error'); return; }
    setSaving(true);
    try {
      const r = await api.post(`/vehicles/${activeVehicle.id}/assignments`, { user_id: assignUserId, role: assignRole });
      const newAsgn = r.data;
      const updated = [...(activeVehicle.assignments.filter(a => a.user_id !== assignUserId)), newAsgn];
      const updatedV = { ...activeVehicle, assignments: updated };
      setVehicles(vs => vs.map(v => v.id === activeVehicle.id ? updatedV : v));
      setActiveVehicle(updatedV);
      setAssignUserId(0);
      toast('Çalışan atandı.');
    } catch (e: any) { toast(e?.response?.data?.detail || 'Hata.', 'error'); }
    finally { setSaving(false); }
  };

  const handleRemoveAssignment = async (asgn: Assignment) => {
    if (!activeVehicle) return;
    try {
      await api.delete(`/vehicles/${activeVehicle.id}/assignments/${asgn.id}`);
      const updated = activeVehicle.assignments.filter(a => a.id !== asgn.id);
      const updatedV = { ...activeVehicle, assignments: updated };
      setVehicles(vs => vs.map(v => v.id === activeVehicle.id ? updatedV : v));
      setActiveVehicle(updatedV);
      toast('Çalışan kaldırıldı.');
    } catch (e: any) { toast(e?.response?.data?.detail || 'Hata.', 'error'); }
  };

  // ── Computed ──────────────────────────────────────────────────────────────

  const fmtRelTime = (iso?: string) => {
    if (!iso) return '';
    try {
      const diff = Date.now() - new Date(iso).getTime();
      const mins = Math.floor(diff / 60000);
      if (mins < 1)   return 'az önce';
      if (mins < 60)  return `${mins} dk önce`;
      const hrs = Math.floor(mins / 60);
      if (hrs < 24)   return `${hrs} sa önce`;
      const days = Math.floor(hrs / 24);
      if (days < 7)   return `${days} gün önce`;
      return new Date(iso).toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' });
    } catch { return ''; }
  };

  const displayedVehicles = [...vehicles]
    .filter(v => {
      if (!plateSearch.trim()) return true;
      const q = plateSearch.trim().toUpperCase();
      return v.plate.includes(q) || (v.nickname || '').toUpperCase().includes(q);
    })
    .sort((a, b) => {
      if (!sortByActivity) return 0;
      return (b.updated_at ? new Date(b.updated_at).getTime() : 0)
           - (a.updated_at ? new Date(a.updated_at).getTime() : 0);
    });

  const filteredProducts = products.filter(p =>
    p.quantity > 0 &&
    (p.name.toLowerCase().includes(loadSearch.toLowerCase()) || (p.barcode || '').includes(loadSearch))
  );

  const unloadTotal = inventoryItems.reduce((s, i) => s + (unloadQtys[i.product_id] || 0) * i.unit_price, 0);

  const unassignedEmps = employees.filter(e => !activeVehicle?.assignments.some(a => a.user_id === e.id));

  const fmtDate = (iso: string) => {
    try { return new Date(iso).toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' }); }
    catch { return iso; }
  };

  // ── Log filter computed values ────────────────────────────────────────────

  const logAllUsers = [...new Set(logEntries.map(l => l.user_name))].sort();

  const LOG_ACTION_CHIPS = [
    { value: 'all',               label: 'Tümü',             dot: 'bg-slate-400' },
    { value: 'load',              label: 'Yüklendi',          dot: 'bg-emerald-500' },
    { value: 'unload_sold',       label: 'Satıldı',           dot: 'bg-blue-500' },
    { value: 'unload_depot',      label: 'Depoya İade',       dot: 'bg-amber-500' },
    { value: 'assignment_add',    label: 'Çalışan Atandı',    dot: 'bg-purple-500' },
    { value: 'assignment_remove', label: 'Çalışan Çıkarıldı', dot: 'bg-red-500' },
    { value: 'assignment_update', label: 'Rol Değişti',       dot: 'bg-purple-400' },
    { value: 'updated',           label: 'Güncellendi',        dot: 'bg-slate-500' },
    { value: 'created',           label: 'Oluşturuldu',        dot: 'bg-slate-500' },
  ].filter(o => o.value === 'all' || logEntries.some(l => l.action === o.value));

  const filteredLogs = logEntries.filter(l => {
    if (logFilterAction !== 'all' && l.action !== logFilterAction) return false;
    if (logFilterUser !== 'all' && l.user_name !== logFilterUser) return false;
    if (logFilterDate && !l.created_at.startsWith(logFilterDate)) return false;
    return true;
  });

  const logByDate = filteredLogs.reduce((acc, l) => {
    const day = l.created_at.slice(0, 10);
    (acc[day] = acc[day] || []).push(l);
    return acc;
  }, {} as Record<string, LogEntry[]>);

  const logDatesSorted = Object.keys(logByDate).sort().reverse();

  const fmtDateHeader = (iso: string) => {
    try {
      const today     = new Date().toISOString().slice(0, 10);
      const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
      if (iso === today)     return 'Bugün';
      if (iso === yesterday) return 'Dün';
      return new Date(iso).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' });
    } catch { return iso; }
  };

  const hasLogFilters = logFilterAction !== 'all' || logFilterUser !== 'all' || !!logFilterDate;
  const clearLogFilters = () => { setLogFilterAction('all'); setLogFilterUser('all'); setLogFilterDate(''); };

  // ── Render helpers ────────────────────────────────────────────────────────

  const ActionRow = ({ v }: { v: Vehicle }) => (
    <div className="grid grid-cols-2 gap-2 p-4 border-t border-slate-100 dark:border-slate-800">
      <button onClick={() => open('inventory', v)} className="flex flex-col items-center gap-1 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors">
        <Package size={18} className="text-slate-600 dark:text-slate-300"/>
        <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">Envanter</span>
      </button>
      <button onClick={() => open('load', v)} className="flex flex-col items-center gap-1 py-3 rounded-xl bg-emerald-100 dark:bg-emerald-900/30 hover:bg-emerald-200 dark:hover:bg-emerald-900/50 transition-colors">
        <ArrowDownToLine size={18} className="text-emerald-700 dark:text-emerald-300"/>
        <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-300">Yükle</span>
      </button>
      <button
        onClick={() => open('unload', v)}
        className={`flex flex-col items-center gap-1 py-3 rounded-xl bg-amber-100 dark:bg-amber-900/30 hover:bg-amber-200 dark:hover:bg-amber-900/50 transition-colors ${!isPatron ? 'col-span-2' : ''}`}
      >
        <ArrowUpFromLine size={18} className="text-amber-700 dark:text-amber-300"/>
        <span className="text-xs font-semibold text-amber-700 dark:text-amber-300">Boşalt / Sat</span>
      </button>
      {isPatron && (
        <button onClick={() => open('log', v)} className="flex flex-col items-center gap-1 py-3 rounded-xl bg-indigo-100 dark:bg-indigo-900/30 hover:bg-indigo-200 dark:hover:bg-indigo-900/50 transition-colors">
          <History size={18} className="text-indigo-700 dark:text-indigo-300"/>
          <span className="text-xs font-semibold text-indigo-700 dark:text-indigo-300">Aktivite</span>
        </button>
      )}
      {isPatron && (
        <button onClick={() => open('assign', v)} className="col-span-2 flex items-center justify-center gap-2 py-3 rounded-xl bg-purple-100 dark:bg-purple-900/30 hover:bg-purple-200 dark:hover:bg-purple-900/50 transition-colors">
          <Users size={16} className="text-purple-700 dark:text-purple-300"/>
          <span className="text-sm font-semibold text-purple-700 dark:text-purple-300">
            Çalışanlar {v.assignments.length > 0 ? `(${v.assignments.length})` : ''}
          </span>
        </button>
      )}
    </div>
  );

  // ── Render ────────────────────────────────────────────────────────────────

  return (
    <div className="p-3 sm:p-6 max-w-4xl mx-auto pb-8">

      {/* ── Page header ── */}
      <div className="flex items-center gap-3 mb-4">
        <div className="flex-1 min-w-0">
          <h1 className="text-xl sm:text-2xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Truck size={22} className="text-blue-600 shrink-0"/>
            {isPatron ? 'Araç Yönetimi' : 'Araçlarım'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5 truncate">
            {isPatron ? 'Araç kayıt, yükleme ve envanter takibi' : 'Atandığınız araçlar ve işlemler'}
          </p>
        </div>
        <button onClick={fetchVehicles} className="w-10 h-10 flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 transition-colors shrink-0">
          <RefreshCw size={16}/>
        </button>
        <button
          onClick={() => exportAraclar(displayedVehicles.map((v: any) => ({
            plate: v.plate, brand: v.nickname || '', model: '', year: '', color: '',
            customer_name: v.status, mileage: '', notes: v.notes, created_at: v.created_at,
          })))}
          disabled={vehicles.length === 0}
          className="flex items-center gap-1.5 px-3 h-10 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded-xl text-sm transition-colors shrink-0"
          title="Excel olarak indir"
        >
          <Download size={15}/> <span className="hidden sm:inline">Excel</span>
        </button>
        {isPatron && (
          <button onClick={() => open('create')} className="flex items-center gap-1.5 px-3 sm:px-4 h-10 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold text-sm shadow transition-colors shrink-0">
            <Plus size={16}/> <span className="hidden sm:inline">Yeni Araç</span>
          </button>
        )}
      </div>

      {/* ── Search + sort controls ── */}
      <div className="flex gap-2 mb-5">
        {/* Plate / nickname search */}
        <div className="flex-1 relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"/>
          <input
            className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors placeholder:text-slate-400"
            placeholder="Plaka ara… (34 ABC 123)"
            value={plateSearch}
            onChange={e => setPlateSearch(e.target.value)}
          />
          {plateSearch && (
            <button
              onClick={() => setPlateSearch('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X size={14}/>
            </button>
          )}
        </div>
        {/* Sort by last activity toggle */}
        <button
          onClick={() => setSortByActivity(s => !s)}
          title="Son işleme göre sırala"
          className={`flex items-center gap-2 px-3 h-11 rounded-xl border font-semibold text-sm transition-colors shrink-0 ${
            sortByActivity
              ? 'bg-blue-600 border-blue-600 text-white shadow'
              : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700'
          }`}
        >
          {/* Custom checkbox tick */}
          <span className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-colors ${
            sortByActivity ? 'bg-white border-white' : 'border-slate-300 dark:border-slate-500'
          }`}>
            {sortByActivity && (
              <svg viewBox="0 0 10 8" className="w-2.5 h-2.5 fill-blue-600">
                <path d="M1 4l3 3 5-6"/>
              </svg>
            )}
          </span>
          <span className="hidden xs:inline">Son İşlem</span>
        </button>
      </div>

      {/* ── Vehicle list ── */}
      {loading ? (
        <div className="flex items-center justify-center py-20 text-slate-400">
          <Loader2 className="animate-spin mr-2"/> Yükleniyor…
        </div>
      ) : vehicles.length === 0 ? (
        <div className="text-center py-20">
          <Truck size={48} className="mx-auto text-slate-300 dark:text-slate-600 mb-3"/>
          <p className="text-slate-500 dark:text-slate-400 font-medium mb-4">
            {isPatron ? 'Henüz araç eklenmemiş.' : 'Henüz size araç atanmamış.'}
          </p>
          {isPatron && <Btn onClick={() => open('create')} color="blue">İlk Aracı Ekle</Btn>}
        </div>
      ) : displayedVehicles.length === 0 ? (
        <div className="text-center py-16">
          <Search size={40} className="mx-auto text-slate-300 dark:text-slate-600 mb-3"/>
          <p className="text-slate-500 dark:text-slate-400 font-medium">
            "<span className="font-bold text-slate-700 dark:text-slate-200">{plateSearch}</span>" ile eşleşen araç bulunamadı.
          </p>
          <button onClick={() => setPlateSearch('')} className="mt-3 text-sm font-semibold text-blue-600 dark:text-blue-400 hover:underline">
            Aramayı Temizle
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {displayedVehicles.map(v => (
            <div key={v.id} className={`bg-white dark:bg-slate-900 rounded-2xl shadow-sm border-2 overflow-hidden transition-colors ${
              v.status === 'on_tour' ? 'border-blue-200 dark:border-blue-800/60' : 'border-slate-200 dark:border-slate-700'
            }`}>

              {/* Card top */}
              <div className="flex items-start gap-2 p-4 pb-2">
                <div className="flex-1 min-w-0">
                  {/* Plate */}
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded border-2 border-slate-800 dark:border-slate-300 bg-amber-400 dark:bg-amber-500 font-mono font-extrabold text-slate-900 text-sm tracking-widest shadow-sm select-none">
                    <span className="text-xs font-bold text-red-700">TR</span>
                    <span>{v.plate}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    {v.nickname && <span className="text-sm text-slate-500 dark:text-slate-400 font-medium">{v.nickname}</span>}
                    {v.updated_at && (
                      <span className="text-xs text-slate-400 dark:text-slate-500">
                        Son işlem: {fmtRelTime(v.updated_at)}
                      </span>
                    )}
                  </div>
                </div>

                {/* Status + menu */}
                <div className="flex items-center gap-1.5 shrink-0">
                  {/* Status toggle */}
                  <button
                    onClick={() => toggleStatus(v)}
                    title="Durumu değiştir"
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                      v.status === 'on_tour'
                        ? 'bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 hover:bg-blue-200 dark:hover:bg-blue-900/60'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    {v.status === 'on_tour' ? <MapPin size={12}/> : <Warehouse size={12}/>}
                    {v.status === 'on_tour' ? 'Turda' : 'Parkta'}
                  </button>

                  {/* ⋮ Menu (patron) */}
                  {isPatron && (
                    <div className="relative">
                      <button
                        onClick={() => setMenuVehicle(menuVehicle?.id === v.id ? null : v)}
                        className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 transition-colors"
                      >
                        <MoreVertical size={16}/>
                      </button>
                      {menuVehicle?.id === v.id && (
                        <>
                          <div className="fixed inset-0 z-30" onClick={() => setMenuVehicle(null)}/>
                          <div className="absolute right-0 top-10 z-40 w-44 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl shadow-lg overflow-hidden">
                            <button onClick={() => open('edit', v)} className="w-full flex items-center gap-2.5 px-4 py-3 text-sm text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700">
                              <Edit2 size={14}/> Düzenle
                            </button>
                            <button onClick={() => handleDelete(v)} className="w-full flex items-center gap-2.5 px-4 py-3 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 border-t border-slate-100 dark:border-slate-700">
                              <Trash2 size={14}/> Sil
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* SVG */}
              <div className="px-3 pt-1 pb-2">
                <TruckSVG count={v.total_quantity} on={v.status === 'on_tour'}/>
              </div>

              {/* Assigned employees */}
              {v.assignments.length > 0 && (
                <div className="px-4 pb-3 flex flex-wrap gap-1.5">
                  {v.assignments.map(a => (
                    <span key={a.id} className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-medium ${ROLE_COLOR[a.role] || ROLE_COLOR.driver}`}>
                      <Users size={10}/> {a.user_name} · {a.role_label}
                    </span>
                  ))}
                </div>
              )}

              {/* Stats */}
              <div className="mx-4 mb-3 grid grid-cols-2 gap-2">
                <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-3 text-center">
                  <div className="text-2xl font-bold text-slate-800 dark:text-slate-100">{v.total_quantity}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">Toplam Adet</div>
                </div>
                <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-3 text-center">
                  <div className="text-2xl font-bold text-slate-800 dark:text-slate-100">{v.distinct_products}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">Farklı Ürün</div>
                </div>
              </div>

              {/* Action grid */}
              <ActionRow v={v}/>
            </div>
          ))}
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          MODALS
      ══════════════════════════════════════════════════════════════════════ */}

      {/* ── Create ── */}
      {modal === 'create' && (
        <Modal
          title="Yeni Araç Ekle"
          onClose={close}
          footer={
            <div className="flex gap-3">
              <Btn onClick={close} color="slate" variant="outline" className="flex-1">İptal</Btn>
              <Btn onClick={handleCreate} disabled={saving} color="blue" className="flex-1">
                {saving ? <Loader2 size={16} className="animate-spin"/> : <Plus size={16}/>} Ekle
              </Btn>
            </div>
          }
        >
          <div className="space-y-4">
            <Field label="Plaka *">
              <input autoFocus className={iCls} placeholder="34 ABC 123" value={form.plate}
                onChange={e => setForm(f => ({ ...f, plate: e.target.value.toUpperCase() }))}/>
            </Field>
            <Field label="Takma Ad (opsiyonel)">
              <input className={iCls} placeholder="Büyük Kamyon" value={form.nickname}
                onChange={e => setForm(f => ({ ...f, nickname: e.target.value }))}/>
            </Field>
            <Field label="Notlar">
              <textarea className={iCls} rows={2} value={form.notes}
                onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}/>
            </Field>
          </div>
        </Modal>
      )}

      {/* ── Edit ── */}
      {modal === 'edit' && activeVehicle && (
        <Modal
          title={`Düzenle — ${activeVehicle.plate}`}
          onClose={close}
          footer={
            <div className="flex gap-3">
              <Btn onClick={close} color="slate" variant="outline" className="flex-1">İptal</Btn>
              <Btn onClick={handleEdit} disabled={saving} color="blue" className="flex-1">
                {saving ? <Loader2 size={16} className="animate-spin"/> : <CheckCircle size={16}/>} Kaydet
              </Btn>
            </div>
          }
        >
          <div className="space-y-4">
            <Field label="Plaka">
              <input className={iCls} value={editForm.plate}
                onChange={e => setEditForm(f => ({ ...f, plate: e.target.value.toUpperCase() }))}/>
            </Field>
            <Field label="Takma Ad">
              <input className={iCls} placeholder="Büyük Kamyon" value={editForm.nickname}
                onChange={e => setEditForm(f => ({ ...f, nickname: e.target.value }))}/>
            </Field>
            <Field label="Durum">
              <select className={iCls} value={editForm.status} onChange={e => setEditForm(f => ({ ...f, status: e.target.value }))}>
                <option value="parked">Parkta</option>
                <option value="on_tour">Turda</option>
              </select>
            </Field>
            <Field label="Notlar">
              <textarea className={iCls} rows={2} value={editForm.notes}
                onChange={e => setEditForm(f => ({ ...f, notes: e.target.value }))}/>
            </Field>
          </div>
        </Modal>
      )}

      {/* ── Inventory ── */}
      {modal === 'inventory' && activeVehicle && (
        <Modal title={`Envanter — ${activeVehicle.plate}`} onClose={close} wide>
          {innerLoading ? (
            <div className="flex items-center justify-center py-10 text-slate-400"><Loader2 className="animate-spin"/></div>
          ) : inventoryItems.length === 0 ? (
            <div className="text-center py-10">
              <Package size={36} className="mx-auto text-slate-300 dark:text-slate-600 mb-2"/>
              <p className="text-slate-500 dark:text-slate-400 text-sm">Bu araçta ürün yok.</p>
            </div>
          ) : (
            <div className="space-y-1">
              {inventoryItems.map(item => (
                <div key={item.id} className="flex items-center justify-between py-3 border-b border-slate-100 dark:border-slate-800 last:border-0">
                  <div className="flex-1 min-w-0 pr-4">
                    <div className="font-semibold text-slate-800 dark:text-slate-100 text-sm">{item.product_name}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {item.unit_price.toLocaleString('tr-TR', { minimumFractionDigits: 2 })} {item.currency} / adet
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-xl font-bold text-blue-600 dark:text-blue-400">{item.quantity}</div>
                    <div className="text-xs text-slate-400">adet</div>
                  </div>
                </div>
              ))}
              <div className="flex items-center justify-between pt-3 font-bold">
                <span className="text-slate-600 dark:text-slate-300">Toplam</span>
                <span className="text-blue-600 dark:text-blue-400 text-lg">{inventoryItems.reduce((s, i) => s + i.quantity, 0)} adet</span>
              </div>
            </div>
          )}
        </Modal>
      )}

      {/* ── Load ── */}
      {modal === 'load' && activeVehicle && (
        <Modal
          title={`Yükle — ${activeVehicle.plate}`}
          onClose={close}
          wide
          footer={
            <div className="flex gap-3">
              <Btn onClick={close} color="slate" variant="outline" className="flex-1">İptal</Btn>
              <Btn onClick={handleLoad} disabled={saving} color="emerald" className="flex-1">
                {saving ? <Loader2 size={16} className="animate-spin"/> : <ArrowDownToLine size={16}/>} Araca Yükle
              </Btn>
            </div>
          }
        >
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-3">Depodan yüklemek istediğiniz miktarları girin.</p>
          <div className="relative mb-3">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
            <input className={`${iCls} pl-8`} placeholder="Ürün ara…" value={loadSearch} onChange={e => setLoadSearch(e.target.value)}/>
          </div>
          {filteredProducts.length === 0 ? (
            <p className="text-center py-8 text-slate-400 text-sm">Depoda stoklu ürün bulunamadı.</p>
          ) : (
            <div className="space-y-1">
              {filteredProducts.map(p => (
                <div key={p.id} className="flex items-center justify-between py-3 border-b border-slate-100 dark:border-slate-800 last:border-0">
                  <div className="flex-1 min-w-0 pr-3">
                    <div className="font-medium text-slate-800 dark:text-slate-100 text-sm">{p.name}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">Depoda: {p.quantity} adet</div>
                  </div>
                  <QtyInput
                    value={loadQtys[p.id] || 0}
                    max={p.quantity}
                    onChange={n => setLoadQtys(q => ({ ...q, [p.id]: n }))}
                  />
                </div>
              ))}
            </div>
          )}
        </Modal>
      )}

      {/* ── Unload / Sell ── */}
      {modal === 'unload' && activeVehicle && (
        <Modal
          title={`Boşalt — ${activeVehicle.plate}`}
          onClose={close}
          wide
          footer={
            <div className="space-y-3">
              {unloadDest === 'sold' && unloadTotal > 0 && (
                <div className="flex items-center justify-between px-3 py-2 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
                  <span className="text-sm font-semibold text-blue-700 dark:text-blue-300">Toplam Tutar</span>
                  <span className="text-base font-bold text-blue-700 dark:text-blue-300">
                    {unloadTotal.toLocaleString('tr-TR', { minimumFractionDigits: 2 })} ₺
                  </span>
                </div>
              )}
              <div className="flex gap-3">
                <Btn onClick={close} color="slate" variant="outline" className="flex-1">İptal</Btn>
                <Btn onClick={handleUnload} disabled={saving || inventoryItems.length === 0}
                  color={unloadDest === 'sold' ? 'blue' : 'amber'} className="flex-1">
                  {saving ? <Loader2 size={16} className="animate-spin"/> : unloadDest === 'sold' ? <ShoppingCart size={16}/> : <ArrowUpFromLine size={16}/>}
                  {unloadDest === 'sold' ? 'Satışı Kaydet' : 'İade Et'}
                </Btn>
              </div>
            </div>
          }
        >
          {/* Destination toggle */}
          <div className="grid grid-cols-2 gap-2 mb-4 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl">
            <button
              onClick={() => setUnloadDest('depot')}
              className={`flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                unloadDest === 'depot'
                  ? 'bg-amber-500 text-white shadow'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              <ArrowUpFromLine size={15}/> Depoya İade
            </button>
            <button
              onClick={() => setUnloadDest('sold')}
              className={`flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                unloadDest === 'sold'
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              <ShoppingCart size={15}/> Satıldı
            </button>
          </div>

          {/* Customer name (sold only) */}
          {unloadDest === 'sold' && (
            <Field label="Müşteri Adı *">
              <input autoFocus className={`${iCls} mb-4`} placeholder="Müşteri adını girin…"
                value={unloadCustomer} onChange={e => setUnloadCustomer(e.target.value)}/>
            </Field>
          )}

          {/* Items */}
          {innerLoading ? (
            <div className="flex items-center justify-center py-8 text-slate-400"><Loader2 className="animate-spin"/></div>
          ) : inventoryItems.length === 0 ? (
            <div className="text-center py-8">
              <AlertCircle size={32} className="mx-auto text-amber-400 mb-2"/>
              <p className="text-slate-500 dark:text-slate-400 text-sm">Araçta ürün yok.</p>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">Miktarları Belirleyin</span>
                <button
                  onClick={() => {
                    const all: Record<number, number> = {};
                    inventoryItems.forEach(i => { all[i.product_id] = i.quantity; });
                    setUnloadQtys(all);
                  }}
                  className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
                >
                  Tümünü Seç
                </button>
              </div>
              <div className="space-y-1">
                {inventoryItems.map(item => (
                  <div key={item.id} className="flex items-center justify-between py-3 border-b border-slate-100 dark:border-slate-800 last:border-0">
                    <div className="flex-1 min-w-0 pr-3">
                      <div className="font-medium text-slate-800 dark:text-slate-100 text-sm">{item.product_name}</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        Araçta: {item.quantity} · {item.unit_price.toLocaleString('tr-TR', { minimumFractionDigits: 2 })} {item.currency}
                      </div>
                    </div>
                    <QtyInput
                      value={unloadQtys[item.product_id] || 0}
                      max={item.quantity}
                      onChange={n => setUnloadQtys(q => ({ ...q, [item.product_id]: n }))}
                    />
                  </div>
                ))}
              </div>
            </>
          )}
        </Modal>
      )}

      {/* ── Log ── */}
      {modal === 'log' && activeVehicle && isPatron && (
        <Modal
          title={`Aktivite — ${activeVehicle.plate}`}
          onClose={close}
          wide
          subHeader={
            !innerLoading && logEntries.length > 0 ? (
              <div className="px-4 py-3 space-y-2.5">
                {/* Action type chips */}
                <div className="flex gap-1.5 overflow-x-auto pb-0.5" style={{ scrollbarWidth: 'none' }}>
                  {LOG_ACTION_CHIPS.map(o => (
                    <button
                      key={o.value}
                      onClick={() => setLogFilterAction(o.value)}
                      className={`shrink-0 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                        logFilterAction === o.value
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
                      }`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${logFilterAction === o.value ? 'bg-white/60' : o.dot}`}/>
                      {o.label}
                    </button>
                  ))}
                </div>
                {/* User + Date + Clear */}
                <div className="flex gap-2 items-center">
                  {logAllUsers.length > 1 && (
                    <select
                      value={logFilterUser}
                      onChange={e => setLogFilterUser(e.target.value)}
                      className="flex-1 min-w-0 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 truncate"
                    >
                      <option value="all">Tüm Kullanıcılar</option>
                      {logAllUsers.map(u => <option key={u} value={u}>{u}</option>)}
                    </select>
                  )}
                  <input
                    type="date"
                    value={logFilterDate}
                    onChange={e => setLogFilterDate(e.target.value)}
                    className="flex-1 min-w-0 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  {hasLogFilters && (
                    <button
                      onClick={clearLogFilters}
                      className="shrink-0 flex items-center gap-1 px-2.5 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 text-xs font-semibold transition-colors"
                    >
                      <X size={12}/> Temizle
                    </button>
                  )}
                </div>
                {/* Result count */}
                <p className="text-xs text-slate-400 dark:text-slate-500">
                  {filteredLogs.length === logEntries.length
                    ? `${logEntries.length} kayıt`
                    : `${filteredLogs.length} / ${logEntries.length} kayıt gösteriliyor`}
                </p>
              </div>
            ) : null
          }
        >
          {innerLoading ? (
            <div className="flex items-center justify-center py-12 text-slate-400">
              <Loader2 className="animate-spin mr-2"/> Yükleniyor…
            </div>
          ) : logEntries.length === 0 ? (
            <div className="text-center py-12">
              <History size={40} className="mx-auto text-slate-300 dark:text-slate-600 mb-3"/>
              <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Henüz aktivite kaydı yok.</p>
              <p className="text-slate-400 dark:text-slate-500 text-xs mt-1">Yükleme, boşaltma veya çalışan işlemleri burada görünür.</p>
            </div>
          ) : filteredLogs.length === 0 ? (
            <div className="text-center py-12">
              <Search size={36} className="mx-auto text-slate-300 dark:text-slate-600 mb-3"/>
              <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Filtrelerinize uygun kayıt bulunamadı.</p>
              <button onClick={clearLogFilters} className="mt-3 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline">
                Filtreleri Temizle
              </button>
            </div>
          ) : (
            <div className="space-y-5">
              {logDatesSorted.map(day => (
                <div key={day}>
                  {/* Date section header */}
                  <div className="flex items-center gap-3 mb-3">
                    <div className="h-px flex-1 bg-slate-200 dark:bg-slate-700"/>
                    <button
                      onClick={() => setLogFilterDate(logFilterDate === day ? '' : day)}
                      className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-colors ${
                        logFilterDate === day
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 hover:text-indigo-600 dark:hover:text-indigo-400'
                      }`}
                    >
                      {fmtDateHeader(day)}
                      <span className={`text-xs font-normal ${logFilterDate === day ? 'text-indigo-200' : 'text-slate-400'}`}>
                        · {logByDate[day].length} işlem
                      </span>
                    </button>
                    <div className="h-px flex-1 bg-slate-200 dark:bg-slate-700"/>
                  </div>
                  {/* Entries for this day */}
                  <div className="space-y-2">
                    {logByDate[day].map(l => {
                      const meta = ACTION_META[l.action] || { label: l.action, dot: 'bg-slate-400' };
                      const timeStr = (() => {
                        try { return new Date(l.created_at).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }); }
                        catch { return ''; }
                      })();
                      return (
                        <div key={l.id} className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700/60 shadow-sm">
                          {/* Action type + time */}
                          <div className="flex items-center justify-between gap-2 mb-2">
                            <div className="flex items-center gap-2 min-w-0">
                              <div className={`w-2 h-2 rounded-full shrink-0 ${meta.dot}`}/>
                              <span className="text-xs font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wide truncate">{meta.label}</span>
                            </div>
                            <span className="text-xs text-slate-400 dark:text-slate-500 font-mono shrink-0">{timeStr}</span>
                          </div>
                          {/* Actor badge — prominent, clickable to filter */}
                          <button
                            onClick={() => setLogFilterUser(logFilterUser === l.user_name ? 'all' : l.user_name)}
                            className={`mb-2 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold transition-colors ${
                              logFilterUser === l.user_name
                                ? 'bg-indigo-600 text-white'
                                : 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-800/50'
                            }`}
                          >
                            <Users size={10}/> {l.user_name}
                          </button>
                          {/* Details */}
                          {l.details && (
                            <p className="text-sm text-slate-600 dark:text-slate-300 break-words leading-relaxed">{l.details}</p>
                          )}
                          {/* Vehicle status */}
                          {l.vehicle_status && (
                            <div className="mt-1.5">
                              <span className={`text-xs px-1.5 py-0.5 rounded-full font-medium ${
                                l.vehicle_status === 'on_tour'
                                  ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-300'
                                  : 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400'
                              }`}>
                                {l.vehicle_status === 'on_tour' ? 'Turda' : 'Parkta'}
                              </span>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Modal>
      )}

      {/* ── Assignments ── */}
      {modal === 'assign' && activeVehicle && isPatron && (
        <Modal
          title={`Çalışanlar — ${activeVehicle.plate}`}
          onClose={close}
          wide
          footer={
            unassignedEmps.length > 0 ? (
              <div className="space-y-3">
                <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">Çalışan Ekle</p>
                <Field label="Çalışan">
                  <select className={iCls} value={assignUserId} onChange={e => setAssignUserId(+e.target.value)}>
                    <option value={0}>— Seçin —</option>
                    {unassignedEmps.map(e => <option key={e.id} value={e.id}>{e.full_name}</option>)}
                  </select>
                </Field>
                <Field label="Rol">
                  <select className={iCls} value={assignRole} onChange={e => setAssignRole(e.target.value)}>
                    {ROLE_OPTIONS.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
                  </select>
                </Field>
                <Btn onClick={handleAddAssignment} disabled={saving || !assignUserId} color="purple" className="w-full">
                  {saving ? <Loader2 size={16} className="animate-spin"/> : <UserPlus size={16}/>} Ata
                </Btn>
              </div>
            ) : employees.length > 0 ? (
              <p className="text-sm text-slate-400 dark:text-slate-500 text-center">Tüm çalışanlar bu araca atanmış.</p>
            ) : (
              <p className="text-sm text-slate-400 dark:text-slate-500 text-center">Henüz çalışan eklenmemiş.</p>
            )
          }
        >
          {activeVehicle.assignments.length === 0 ? (
            <div className="text-center py-6 text-slate-400 text-sm">Henüz atama yok.</div>
          ) : (
            <div className="space-y-2">
              {activeVehicle.assignments.map(a => (
                <div key={a.id} className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                  <div className={`shrink-0 w-9 h-9 rounded-xl flex items-center justify-center ${ROLE_COLOR[a.role] || ROLE_COLOR.driver}`}>
                    <Users size={16}/>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-slate-800 dark:text-slate-100 text-sm truncate">{a.user_name}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">{a.role_label}</div>
                  </div>
                  <button
                    onClick={() => handleRemoveAssignment(a)}
                    className="shrink-0 w-9 h-9 flex items-center justify-center rounded-xl hover:bg-red-50 dark:hover:bg-red-900/20 text-slate-400 hover:text-red-500 transition-colors"
                  >
                    <UserMinus size={16}/>
                  </button>
                </div>
              ))}
            </div>
          )}
        </Modal>
      )}

    </div>
  );
}
