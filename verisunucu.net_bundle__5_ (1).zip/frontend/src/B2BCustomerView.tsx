import { useState, useEffect, useCallback, useRef } from 'react';
import {
  ShoppingCart, Search, Package, LogOut, ChevronRight,
  Plus, Minus, X, CheckCircle, Clock, Truck, XCircle,
  AlertTriangle, FileText, ChevronDown, ChevronUp, User,
  Building2, CreditCard, RefreshCw, ShoppingBag
} from 'lucide-react';
import { apiRequest } from './lib/api';
import { useLang, makeT } from './lib/i18n';

interface CustomerInfo {
  id: number; company_name: string; contact_person?: string;
  email: string; discount_rate: number; credit_limit: number;
  payment_term_days: number; open_debt: number; bayi_user_id: number;
  user_full_name?: string;
}

interface Product {
  id: number; name: string; stock: number;
  list_price: number; customer_price: number;
  currency: string; category?: string; kdv_rate: number; barcode?: string;
  image_url?: string;
}

interface CartItem { product: Product; quantity: number; }

interface Order {
  id: number; order_number: string; status: string;
  total_amount: number; currency: string; is_paid: boolean;
  due_date?: string; created_at?: string;
  items: { product_name: string; quantity: number; unit_price: number; kdv_rate: number; }[];
}

const DICT: Record<string, string> = {
  'Çıkış': 'Log Out',
  'Ürünler': 'Products',
  'Siparişlerim': 'My Orders',
  'Ürün ara...': 'Search products...',
  'Sepet': 'Cart',
  'Sepete Ekle': 'Add to Cart',
  'Stokta yok': 'Out of stock',
  'Stok': 'Stock',
  'KDV hariç': 'Excl. VAT',
  'KDV dahil': 'Incl. VAT',
  'Yükleniyor...': 'Loading...',
  'Ürün bulunamadı': 'No products found',
  'Bu kategoride ürün yok': 'No products in this category',
  'Tümü': 'All',
  'Sepet boş': 'Cart is empty',
  'Ara toplam': 'Subtotal',
  'KDV': 'VAT',
  'Toplam': 'Total',
  'Sipariş Ver': 'Place Order',
  'Siparişi Onayla': 'Confirm Order',
  'Gönderiliyor...': 'Sending...',
  'Teslimat Adresi': 'Delivery Address',
  'Adres (opsiyonel)': 'Address (optional)',
  'İstenen Teslim Tarihi': 'Requested Delivery Date',
  'Not (opsiyonel)': 'Note (optional)',
  'Siparişle ilgili notlarınız...': 'Notes about the order...',
  'ürün': 'items',
  'Siparişiniz bayinize iletildi, onay bekleniyor': 'Your order has been submitted, awaiting approval',
  'Sipariş gönderilemedi': 'Could not send order',
  'Siparişler yükleniyor...': 'Loading orders...',
  'Henüz siparişiniz yok': 'No orders yet',
  'Sipariş No': 'Order No',
  'Tarih': 'Date',
  'Tutar': 'Amount',
  'Durum': 'Status',
  'Ödeme': 'Payment',
  'Onay Bekliyor': 'Pending Approval',
  'Taslak': 'Draft',
  'Onaylı': 'Confirmed',
  'Kargoda': 'Shipped',
  'Teslim': 'Delivered',
  'İptal': 'Cancelled',
  'Ödendi': 'Paid',
  'Bekliyor': 'Pending',
  'Kısmi': 'Partial',
  'Kredi Limiti:': 'Credit Limit:',
  'Kalan:': 'Remaining:',
  'Bilgiler yüklenemedi': 'Could not load information',
  'iskonto': 'discount',
  'Büyük görsel': 'Full image',
  'Ürünler yüklenemedi': 'Could not load products',
  'Siparişler yüklenemedi': 'Could not load orders',
  'Müşteri bilgileri yüklenemedi': 'Could not load customer information',
  'Vade:': 'Due:',
  'Açık Bakiye:': 'Open Balance:',
  'gün': 'days',
  'Hoş geldiniz,': 'Welcome,',
  'Ürün': 'Product',
  'Adet': 'Qty',
  'Birim': 'Unit',
  'Siparişiniz bayinizin onayını bekliyor. Onaylanınca hazırlanmaya başlanacak.': 'Your order is awaiting your dealer\'s approval. Preparation will begin once approved.',
  'Siparişiniz bayinize iletilecek ve onaylandıktan sonra hazırlanacaktır.': 'Your order will be forwarded to your dealer and prepared after approval.',
};

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: any }> = {
  pending_approval: { label: 'Onay Bekliyor', color: 'bg-orange-100 text-orange-700', icon: AlertTriangle },
  draft:     { label: 'Taslak',  color: 'bg-slate-100 text-slate-700',    icon: Clock },
  confirmed: { label: 'Onaylı',  color: 'bg-blue-100 text-blue-700',      icon: CheckCircle },
  shipped:   { label: 'Kargoda', color: 'bg-amber-100 text-amber-700',    icon: Truck },
  delivered: { label: 'Teslim',  color: 'bg-emerald-100 text-emerald-700',icon: CheckCircle },
  cancelled: { label: 'İptal',   color: 'bg-red-100 text-red-700',        icon: XCircle },
};

function StatusBadge({ status }: { status: string }) {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const cfg = STATUS_CONFIG[status] || { label: status, color: 'bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-slate-300', icon: Clock };
  const Icon = cfg.icon;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${cfg.color}`}>
      <Icon size={11} />{t(cfg.label)}
    </span>
  );
}

const fmt = (n: number) =>
  new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n) + ' ₺';

export default function B2BCustomerView({
  currentUser, onLogout, showToast,
}: {
  currentUser: any;
  onLogout: () => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'warning') => void;
}) {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const [view, setView] = useState<'shop' | 'orders'>('shop');
  const [customerInfo, setCustomerInfo] = useState<CustomerInfo | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [checkoutForm, setCheckoutForm] = useState({ notes: '', due_date: '', shipping_address: '' });
  const [submitting, setSubmitting] = useState(false);
  const [expandedOrder, setExpandedOrder] = useState<number | null>(null);
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);

  const loadCustomerInfo = useCallback(async () => {
    try {
      const data = await apiRequest('/btb/customer/me', { method: 'GET' });
      setCustomerInfo(data);
    } catch { showToast(t('Müşteri bilgileri yüklenemedi'), 'error'); }
  }, [showToast]);

  const loadProducts = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      if (search) params.set('q', search);
      if (selectedCategory) params.set('category', selectedCategory);
      const data = await apiRequest(`/btb/customer/products?${params}`, { method: 'GET' });
      setProducts(Array.isArray(data) ? data : []);
    } catch { showToast(t('Ürünler yüklenemedi'), 'error'); }
  }, [search, selectedCategory, showToast]);

  const loadCategories = useCallback(async () => {
    try {
      const data = await apiRequest('/btb/customer/categories', { method: 'GET' });
      const names = (Array.isArray(data) ? data : []).map((c: any) => c.name);
      setCategories(names);
    } catch {}
  }, []);

  const loadOrders = useCallback(async () => {
    try {
      const data = await apiRequest('/btb/customer/orders', { method: 'GET' });
      setOrders(Array.isArray(data) ? data : []);
    } catch { showToast(t('Siparişler yüklenemedi'), 'error'); }
  }, [showToast]);

  useEffect(() => {
    (async () => {
      setLoading(true);
      await Promise.all([loadCustomerInfo(), loadCategories()]);
      setLoading(false);
    })();
  }, [loadCustomerInfo, loadCategories]);

  useEffect(() => { if (view === 'shop') loadProducts(); }, [view, loadProducts]);
  useEffect(() => { if (view === 'orders') loadOrders(); }, [view, loadOrders]);

  // Search debounce
  const searchTimer = useRef<any>(null);
  const handleSearchChange = (val: string) => {
    setSearch(val);
    if (searchTimer.current) clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => loadProducts(), 400);
  };

  const cartCount = cart.reduce((s, i) => s + i.quantity, 0);
  const cartTotal = cart.reduce((s, i) => s + i.product.customer_price * i.quantity, 0);
  const cartKdv = cart.reduce((s, i) => s + i.product.customer_price * i.quantity * (i.product.kdv_rate / 100), 0);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const ex = prev.find(i => i.product.id === product.id);
      if (ex) return prev.map(i => i.product.id === product.id ? { ...i, quantity: i.quantity + 1 } : i);
      return [...prev, { product, quantity: 1 }];
    });
  };

  const updateQty = (productId: number, delta: number) => {
    setCart(prev => {
      const next = prev.map(i => i.product.id === productId ? { ...i, quantity: i.quantity + delta } : i)
        .filter(i => i.quantity > 0);
      return next;
    });
  };

  const removeFromCart = (productId: number) => setCart(prev => prev.filter(i => i.product.id !== productId));

  const handleCheckout = async () => {
    if (cart.length === 0) return;
    setSubmitting(true);
    try {
      const payload = {
        items: cart.map(i => ({ product_id: i.product.id, quantity: i.quantity })),
        notes: checkoutForm.notes,
        due_date: checkoutForm.due_date || undefined,
        shipping_address: checkoutForm.shipping_address,
      };
      await apiRequest('/btb/customer/checkout', { method: 'POST', body: JSON.stringify(payload) });
      showToast(t('Siparişiniz bayinize iletildi, onay bekleniyor'), 'success');
      setCart([]);
      setCheckoutOpen(false);
      setCartOpen(false);
      setView('orders');
      loadOrders();
    } catch (e: any) {
      showToast(e?.message || t('Sipariş gönderilemedi'), 'error');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-700/50 flex items-center justify-center">
      <div className="text-gray-400 dark:text-slate-500 text-sm">{t('Yükleniyor...')}</div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-700/50">
      {/* Header */}
      <header className="bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700 sticky top-0 z-40 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <Building2 size={16} className="text-indigo-600 shrink-0" />
              <span className="font-bold text-gray-900 dark:text-slate-100 text-sm truncate">
                {customerInfo?.company_name || 'B2B Portalı'}
              </span>
              {customerInfo && customerInfo.discount_rate > 0 && (
                <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-medium shrink-0">
                  %{customerInfo.discount_rate} {t('iskonto')}
                </span>
              )}
            </div>
            {currentUser?.full_name && (
              <p className="text-xs text-gray-400 dark:text-slate-500 mt-0.5">{t('Hoş geldiniz,')} {currentUser.full_name}</p>
            )}
          </div>

          {/* Nav */}
          <div className="flex items-center gap-1">
            <button onClick={() => setView('shop')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${view === 'shop' ? 'bg-indigo-100 text-indigo-700' : 'text-gray-500 dark:text-slate-400 hover:text-gray-800 dark:hover:text-slate-200'}`}>
              <Package size={13} className="inline mr-1" />{t('Ürünler')}
            </button>
            <button onClick={() => setView('orders')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition relative ${view === 'orders' ? 'bg-indigo-100 text-indigo-700' : 'text-gray-500 dark:text-slate-400 hover:text-gray-800 dark:hover:text-slate-200'}`}>
              <FileText size={13} className="inline mr-1" />{t('Siparişlerim')}
              {orders.filter(o => o.status === 'pending_approval').length > 0 && (
                <span className="absolute -top-1 -right-1 bg-orange-500 text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center">
                  {orders.filter(o => o.status === 'pending_approval').length}
                </span>
              )}
            </button>
          </div>

          {/* Cart button */}
          <button onClick={() => setCartOpen(true)}
            className="relative p-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 shrink-0">
            <ShoppingCart size={18} />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>

          <button onClick={onLogout} className="p-2 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700" title={t('Çıkış')}>
            <LogOut size={16} />
          </button>
        </div>
      </header>

      {/* Credit info bar */}
      {customerInfo && (customerInfo.open_debt > 0 || customerInfo.credit_limit > 0) && (
        <div className="bg-indigo-900 text-white px-4 py-2">
          <div className="max-w-6xl mx-auto flex flex-col sm:flex-row sm:items-center gap-2 text-xs">
            <span className="font-medium">{t('Açık Bakiye:')} <span className="text-amber-300">{fmt(customerInfo.open_debt)}</span></span>
            {customerInfo.credit_limit > 0 && (
              <span className="sm:ml-4">{t('Kredi Limiti:')} <span className="text-emerald-300">{fmt(customerInfo.credit_limit)}</span></span>
            )}
            <span className="sm:ml-4 text-indigo-300">{t('Vade:')} {customerInfo.payment_term_days} {t('gün')}</span>
          </div>
        </div>
      )}

      <div className="max-w-6xl mx-auto px-4 py-5">
        {/* SHOP VIEW */}
        {view === 'shop' && (
          <div>
            {/* Filters */}
            <div className="flex gap-3 mb-3">
              <div className="relative flex-1">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-slate-500" />
                <input
                  type="text"
                  placeholder={t('Ürün ara...')}
                  value={search}
                  onChange={e => { setSearch(e.target.value); }}
                  className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 bg-white dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100 dark:placeholder-slate-400"
                />
              </div>
              <button onClick={loadProducts} className="p-2.5 border border-gray-200 dark:border-slate-600 rounded-xl bg-white dark:bg-slate-700 hover:bg-gray-50 dark:hover:bg-slate-700 text-gray-500 dark:text-slate-400">
                <RefreshCw size={15} />
              </button>
            </div>

            {/* Kategori pilleri */}
            {categories.length > 0 && (
              <div className="flex gap-2 flex-wrap mb-4">
                <button
                  onClick={() => setSelectedCategory('')}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition ${!selectedCategory ? 'bg-indigo-600 text-white' : 'bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-slate-400 hover:bg-gray-200 dark:hover:bg-slate-600'}`}
                >{t('Tümü')} ({products.length})</button>
                {categories.map(c => (
                  <button key={c}
                    onClick={() => setSelectedCategory(c === selectedCategory ? '' : c)}
                    className={`px-3 py-1 rounded-full text-xs font-medium transition ${selectedCategory === c ? 'bg-indigo-600 text-white' : 'bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-slate-400 hover:bg-gray-200 dark:hover:bg-slate-600'}`}
                  >
                    {c} ({products.filter(p => p.category === c).length})
                  </button>
                ))}
              </div>
            )}

            {(() => {
              const filtered = products.filter(p => {
                const matchCat = !selectedCategory || p.category === selectedCategory;
                const matchQ = !search || p.name.toLowerCase().includes(search.toLowerCase());
                return matchCat && matchQ;
              });
              return filtered.length === 0 ? (
              <div className="py-16 text-center text-gray-400 dark:text-slate-500">
                <Package size={40} className="mx-auto mb-3 opacity-30" />
                <p className="text-sm">{products.length === 0 ? t('Ürün bulunamadı') : t('Bu kategoride ürün yok')}</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {filtered.map(p => {
                  const cartItem = cart.find(i => i.product.id === p.id);
                  const qty = cartItem?.quantity || 0;
                  return (
                    <div key={p.id} className="bg-white dark:bg-slate-800 rounded-2xl border border-gray-200 dark:border-slate-700 overflow-hidden hover:shadow-md transition-shadow">
                      {/* Ürün görseli */}
                      {p.image_url ? (
                        <div className="relative cursor-zoom-in" onClick={() => setZoomedImage(p.image_url!)}>
                          <img src={p.image_url} alt={p.name} className="w-full h-32 object-cover bg-gray-50 dark:bg-slate-700/50 hover:opacity-90 transition-opacity" />
                          {p.category && <span className="absolute top-2 left-2 text-[10px] bg-white/90 dark:bg-slate-800/90 text-gray-600 dark:text-slate-400 px-2 py-0.5 rounded-full shadow-sm">{p.category}</span>}
                          {p.customer_price < p.list_price && (
                            <span className="absolute top-2 right-2 text-[10px] bg-red-500 text-white px-2 py-0.5 rounded-full font-bold">
                              -%{Math.round((1 - p.customer_price / p.list_price) * 100)}
                            </span>
                          )}
                        </div>
                      ) : (
                        <div className="relative h-28 bg-gray-50 dark:bg-slate-700/50 flex items-center justify-center">
                          <Package size={32} className="text-gray-200 dark:text-slate-600" />
                          {p.category && <span className="absolute top-2 left-2 text-[10px] bg-white dark:bg-slate-800 text-gray-500 dark:text-slate-400 px-2 py-0.5 rounded-full border border-gray-100 dark:border-slate-700/50">{p.category}</span>}
                          {p.customer_price < p.list_price && (
                            <span className="absolute top-2 right-2 text-[10px] bg-red-500 text-white px-2 py-0.5 rounded-full font-bold">
                              -%{Math.round((1 - p.customer_price / p.list_price) * 100)}
                            </span>
                          )}
                        </div>
                      )}
                      <div className="p-3">
                        <h3 className="font-medium text-gray-900 dark:text-slate-100 text-sm leading-tight mb-2 line-clamp-2">{p.name}</h3>
                        {p.barcode && <p className="text-[10px] text-gray-400 dark:text-slate-500 mb-1">{p.barcode}</p>}
                        <div className="flex items-end justify-between mb-3">
                          <div>
                            <p className="text-base font-bold text-indigo-700">{fmt(p.customer_price)}</p>
                            {p.customer_price < p.list_price && (
                              <p className="text-xs text-gray-400 dark:text-slate-500 line-through">{fmt(p.list_price)}</p>
                            )}
                            <p className="text-[10px] text-gray-400 dark:text-slate-500">KDV %{p.kdv_rate ?? 18}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-[10px] text-gray-400 dark:text-slate-500">{t('Stok')}</p>
                            <span className={`text-xs font-medium ${p.stock < 5 ? 'text-red-600' : 'text-emerald-600'}`}>
                              {p.stock} adet
                            </span>
                          </div>
                        </div>

                        {qty === 0 ? (
                          <button
                            onClick={() => addToCart(p)}
                            className="w-full py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-700 transition flex items-center justify-center gap-1"
                          >
                            <Plus size={13} /> {t('Sepete Ekle')}
                          </button>
                        ) : (
                          <div className="flex items-center justify-between bg-indigo-50 dark:bg-indigo-900/30 rounded-xl px-2 py-1">
                            <button onClick={() => updateQty(p.id, -1)} className="w-7 h-7 rounded-lg bg-white dark:bg-slate-700 border border-indigo-200 dark:border-slate-600 flex items-center justify-center hover:bg-indigo-100 dark:hover:bg-indigo-900/30">
                              <Minus size={12} />
                            </button>
                            <span className="font-bold text-indigo-700 text-sm">{qty}</span>
                            <button onClick={() => updateQty(p.id, 1)} disabled={qty >= p.stock}
                              className="w-7 h-7 rounded-lg bg-white dark:bg-slate-700 border border-indigo-200 dark:border-slate-600 flex items-center justify-center hover:bg-indigo-100 dark:hover:bg-indigo-900/30 disabled:opacity-40">
                              <Plus size={12} />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            );
            })()}
          </div>
        )}

        {/* ORDERS VIEW */}
        {view === 'orders' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold text-gray-900 dark:text-slate-100">{t('Siparişlerim')}</h2>
              <button onClick={loadOrders} className="p-2 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700">
                <RefreshCw size={15} />
              </button>
            </div>
            {orders.length === 0 ? (
              <div className="py-16 text-center text-gray-400 dark:text-slate-500">
                <ShoppingBag size={40} className="mx-auto mb-3 opacity-30" />
                <p className="text-sm">{t('Henüz siparişiniz yok')}</p>
              </div>
            ) : (
              orders.map(o => (
                <div key={o.id} className="bg-white dark:bg-slate-800 rounded-2xl border border-gray-200 dark:border-slate-700">
                  <div
                    className="p-4 flex items-center gap-3 cursor-pointer"
                    onClick={() => setExpandedOrder(expandedOrder === o.id ? null : o.id)}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-xs bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-slate-300 px-2 py-0.5 rounded">{o.order_number}</span>
                        <StatusBadge status={o.status} />
                        {o.is_paid && <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">{t('Ödendi')}</span>}
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-xs text-gray-500 dark:text-slate-400">
                        <span>{o.created_at ? new Date(o.created_at).toLocaleDateString('tr-TR') : '—'}</span>
                        {o.due_date && <span>{t('Vade:')} {new Date(o.due_date).toLocaleDateString('tr-TR')}</span>}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="font-bold text-gray-900 dark:text-slate-100">{fmt(o.total_amount)}</p>
                      {expandedOrder === o.id ? <ChevronUp size={16} className="text-gray-400 dark:text-slate-500 mx-auto mt-1" /> : <ChevronDown size={16} className="text-gray-400 dark:text-slate-500 mx-auto mt-1" />}
                    </div>
                  </div>
                  {expandedOrder === o.id && (
                    <div className="border-t border-gray-100 dark:border-slate-700/50 px-4 pb-4 pt-3">
                      {o.status === 'pending_approval' && (
                        <div className="mb-3 bg-orange-50 dark:bg-orange-900/30 border border-orange-200 rounded-xl p-3 text-xs text-orange-800 flex items-center gap-2">
                          <AlertTriangle size={13} />
                          {t('Siparişiniz bayinizin onayını bekliyor. Onaylanınca hazırlanmaya başlanacak.')}
                        </div>
                      )}
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="text-gray-400 dark:text-slate-500 border-b dark:border-slate-700">
                            <th className="text-left pb-2">{t('Ürün')}</th>
                            <th className="text-right pb-2">{t('Adet')}</th>
                            <th className="text-right pb-2">{t('Birim')}</th>
                            <th className="text-right pb-2">{t('Toplam')}</th>
                          </tr>
                        </thead>
                        <tbody>
                          {o.items.map((item, idx) => (
                            <tr key={idx} className="border-b border-gray-50 dark:border-slate-700/50">
                              <td className="py-1.5 text-gray-700 dark:text-slate-300">{item.product_name}</td>
                              <td className="py-1.5 text-right dark:text-slate-300">{item.quantity}</td>
                              <td className="py-1.5 text-right dark:text-slate-300">{fmt(item.unit_price)}</td>
                              <td className="py-1.5 text-right font-medium dark:text-slate-200">{fmt(item.unit_price * item.quantity)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                      <div className="mt-2 text-right">
                        <span className="text-sm font-bold text-gray-900 dark:text-slate-100">{fmt(o.total_amount)}</span>
                        <span className="text-xs text-gray-400 dark:text-slate-500 ml-1">({t('KDV dahil')})</span>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Cart Sidebar */}
      {cartOpen && (
        <div className="fixed inset-0 z-50 flex">
          <div className="flex-1 bg-black/40" onClick={() => setCartOpen(false)} />
          <div className="w-full max-w-sm bg-white dark:bg-slate-800 h-full flex flex-col shadow-2xl">
            <div className="flex items-center justify-between px-5 py-4 border-b dark:border-slate-700">
              <h2 className="font-bold text-gray-900 dark:text-slate-100 flex items-center gap-2">
                <ShoppingCart size={18} /> {t('Sepet')} ({cartCount} {t('ürün')})
              </h2>
              <button onClick={() => setCartOpen(false)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700">
                <X size={18} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto px-5 py-3 space-y-3">
              {cart.length === 0 ? (
                <p className="text-gray-400 dark:text-slate-500 text-sm text-center py-8">{t('Sepet boş')}</p>
              ) : (
                cart.map(item => (
                  <div key={item.product.id} className="flex items-center gap-3 bg-gray-50 dark:bg-slate-700/50 rounded-xl p-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 dark:text-slate-200 leading-tight line-clamp-2">{item.product.name}</p>
                      <p className="text-xs text-indigo-600 font-bold mt-0.5">{fmt(item.product.customer_price)}</p>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button onClick={() => updateQty(item.product.id, -1)} className="w-7 h-7 rounded-lg border border-gray-200 dark:border-slate-600 bg-white dark:bg-slate-700 flex items-center justify-center text-gray-600 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700">
                        <Minus size={12} />
                      </button>
                      <span className="w-7 text-center text-sm font-bold dark:text-slate-100">{item.quantity}</span>
                      <button onClick={() => updateQty(item.product.id, 1)} disabled={item.quantity >= item.product.stock}
                        className="w-7 h-7 rounded-lg border border-gray-200 dark:border-slate-600 bg-white dark:bg-slate-700 flex items-center justify-center text-gray-600 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-700 disabled:opacity-40">
                        <Plus size={12} />
                      </button>
                      <button onClick={() => removeFromCart(item.product.id)} className="ml-1 text-gray-300 dark:text-slate-600 hover:text-red-500">
                        <X size={14} />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
            {cart.length > 0 && (
              <div className="border-t dark:border-slate-700 px-5 py-4 space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-slate-400">{t('Ara toplam')}</span>
                  <span className="dark:text-slate-200">{fmt(cartTotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600 dark:text-slate-400">{t('KDV')}</span>
                  <span className="dark:text-slate-200">{fmt(cartKdv)}</span>
                </div>
                <div className="flex justify-between font-bold dark:text-slate-100">
                  <span>{t('Toplam')}</span>
                  <span className="text-indigo-700 text-lg">{fmt(cartTotal + cartKdv)}</span>
                </div>
                <button
                  onClick={() => { setCartOpen(false); setCheckoutOpen(true); }}
                  className="w-full py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 flex items-center justify-center gap-2"
                >
                  {t('Sipariş Ver')} <ChevronRight size={16} />
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Checkout Modal */}
      {checkoutOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-white dark:bg-slate-800 rounded-2xl w-full max-w-md shadow-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b dark:border-slate-700">
              <h2 className="font-bold text-gray-900 dark:text-slate-100">{t('Sipariş Ver')}</h2>
              <button onClick={() => setCheckoutOpen(false)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700">
                <X size={18} />
              </button>
            </div>
            <div className="px-6 py-5 space-y-4">
              <div className="bg-orange-50 dark:bg-orange-900/30 border border-orange-200 rounded-xl p-3 text-xs text-orange-800 flex items-start gap-2">
                <AlertTriangle size={13} className="mt-0.5 shrink-0" />
                {t('Siparişiniz bayinize iletilecek ve onaylandıktan sonra hazırlanacaktır.')}
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1">{t('Teslimat Adresi')}</label>
                <input
                  type="text"
                  placeholder={t('Adres (opsiyonel)')}
                  value={checkoutForm.shipping_address}
                  onChange={e => setCheckoutForm(f => ({ ...f, shipping_address: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100 dark:placeholder-slate-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1">{t('İstenen Teslim Tarihi')}</label>
                <input
                  type="date"
                  value={checkoutForm.due_date}
                  onChange={e => setCheckoutForm(f => ({ ...f, due_date: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100 dark:placeholder-slate-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 dark:text-slate-300 mb-1">{t('Not (opsiyonel)')}</label>
                <textarea
                  rows={3}
                  placeholder={t('Siparişle ilgili notlarınız...')}
                  value={checkoutForm.notes}
                  onChange={e => setCheckoutForm(f => ({ ...f, notes: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 resize-none dark:bg-slate-700 dark:border-slate-600 dark:text-slate-100 dark:placeholder-slate-400"
                />
              </div>

              <div className="bg-gray-50 dark:bg-slate-700/50 rounded-xl p-3">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600 dark:text-slate-400">{cartCount} {t('ürün')}</span>
                  <span className="dark:text-slate-200">{fmt(cartTotal)}</span>
                </div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600 dark:text-slate-400">{t('KDV')}</span>
                  <span className="dark:text-slate-200">{fmt(cartKdv)}</span>
                </div>
                <div className="flex justify-between font-bold text-base pt-1 border-t border-gray-200 dark:border-slate-600 dark:text-slate-100">
                  <span>{t('Toplam')}</span>
                  <span className="text-indigo-700">{fmt(cartTotal + cartKdv)}</span>
                </div>
              </div>

              <button
                onClick={handleCheckout}
                disabled={submitting}
                className="w-full py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {submitting ? t('Gönderiliyor...') : t('Siparişi Onayla')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Görsel Zoom Overlay */}
      {zoomedImage && (
        <div
          className="fixed inset-0 z-[60] bg-black/85 flex items-center justify-center p-4 cursor-zoom-out"
          onClick={() => setZoomedImage(null)}
        >
          <img
            src={zoomedImage}
            alt={t('Büyük görsel')}
            className="max-w-full max-h-[90vh] rounded-2xl shadow-2xl object-contain"
            onClick={e => e.stopPropagation()}
          />
          <button
            onClick={() => setZoomedImage(null)}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/20 hover:bg-white/40 flex items-center justify-center text-white transition"
          >
            <X size={20} />
          </button>
        </div>
      )}
    </div>
  );
}
