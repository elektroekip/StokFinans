import React, { useState, useMemo, createContext, useContext, useEffect, useCallback, useRef } from 'react';
import api from './lib/api';
import SuperAdminPanel from './SuperAdminPanel';
import { WarrantyManagementView, DebtorLinkModal, PublicWarrantyPage, PublicDebtorPage } from './PhaseThreeViews';
import { ZoomImg } from './components/ZoomImg';
import { GlobalLoadingBar } from './components/GlobalLoadingBar';
import SupportView from './SupportView';
import KdvCalculator from './KdvCalculator';
import VehicleView from './VehicleView';
import BTBView from './BTBView';
import SupplierView from './SupplierView';
import PlasiyerView from './PlasiyerView';
import IntegrationsView from './IntegrationsView';
import B2BPortal from './B2BPortal';
import B2BCustomerView from './B2BCustomerView';
import SupplierOrderView from './SupplierOrderView';
import { refreshBus } from './lib/refreshBus';
import { useRefreshOnChange } from './hooks/useRefreshOnChange';
import {
  exportStok, exportFinansCariler, exportFinansIslemler,
  exportCariDetay, exportAktivite,
} from './utils/exportExcel';
import * as LucideIcons from 'lucide-react';
import {
  LayoutDashboard, Package, TrendingUp, Users, Settings,
  LogOut, CreditCard, Building2, UserCircle, Menu, X,
  Check, ArrowRight, BarChart3, Wallet, Box, ShieldAlert,
  Wind, Shield, Footprints, Disc, Layers, Car, BookOpen, FileText, Landmark, Calculator, Award, PieChart, History, AlertTriangle, FileDown, XCircle, AlertCircle, BarChart,
  Search, Plus, Minus, Edit, Trash, Image as ImageIcon, Barcode, Hash, UploadCloud, ArrowLeft, PlusCircle, MinusCircle, Camera, SlidersHorizontal, UserPlus, ShieldCheck, Lock, ChevronRight, Activity,
  Gift, Copy, Clock, ShieldBan, Moon, Sun, Globe, Eye, EyeOff, ArrowUp, ArrowDown, Palette, Save, Truck, Wrench, Zap, Tag, Star, Heart, Briefcase, ShoppingCart, Hammer,
  List, LayoutGrid, Rows3, GalleryHorizontal, FolderTree,
  Mail, CheckCircle, KeyRound, Database, Download, Upload, RefreshCw, Trash2,
  MessageCircle, Send, ChevronDown, Inbox,
  ScanLine, QrCode,
  Cpu, Wifi, WifiOff, PlugZap, DollarSign,
  Gauge, CalendarDays, Trophy, Percent, Flame, Target, TrendingDown, BarChart2,
  Phone, MapPin, MoreHorizontal, ArrowUpRight
} from 'lucide-react';

// --- Lucide ikon adı → bileşen haritası (dinamik kategoriler için) ---
// Backend'de kategori sadece ikon adını saklar; burada string'i bileşene çeviririz.
const ICON_LIBRARY: Record<string, any> = {
  Box, Wind, Shield, Disc, Layers, Footprints, Car, BookOpen, Building2, FileText,
  Landmark, Calculator, Award, PieChart, History, Package, Settings, Users,
  TrendingUp, Wallet, Gift, Truck, Wrench, Zap, Tag, Star, Heart, Briefcase,
  ShoppingCart, Hammer, BarChart3, BarChart, CreditCard, Activity, FileDown,
};
const ICON_NAMES = Object.keys(ICON_LIBRARY);
const iconFor = (name?: string) => {
  if (!name) return Package;
  if (ICON_LIBRARY[name]) return ICON_LIBRARY[name];
  const fromLucide = (LucideIcons as any)[name];
  return fromLucide || Package;
};

// --- Kategori renk paleti (Web Görünüm sayfasında seçilebilir) ---
const COLOR_PALETTE = [
  { name: 'İndigo',   color_class: 'text-indigo-600 dark:text-indigo-400',   bg_class: 'bg-indigo-100 dark:bg-indigo-900/30',   swatch: 'bg-indigo-500' },
  { name: 'Mavi',     color_class: 'text-blue-600 dark:text-blue-400',       bg_class: 'bg-blue-100 dark:bg-blue-900/30',       swatch: 'bg-blue-500' },
  { name: 'Gök',      color_class: 'text-sky-600 dark:text-sky-400',         bg_class: 'bg-sky-100 dark:bg-sky-900/30',         swatch: 'bg-sky-500' },
  { name: 'Zümrüt',   color_class: 'text-emerald-600 dark:text-emerald-400', bg_class: 'bg-emerald-100 dark:bg-emerald-900/30', swatch: 'bg-emerald-500' },
  { name: 'Kehribar', color_class: 'text-amber-600 dark:text-amber-400',     bg_class: 'bg-amber-100 dark:bg-amber-900/30',     swatch: 'bg-amber-500' },
  { name: 'Turuncu',  color_class: 'text-orange-600 dark:text-orange-400',   bg_class: 'bg-orange-100 dark:bg-orange-900/30',   swatch: 'bg-orange-500' },
  { name: 'Kırmızı',  color_class: 'text-red-600 dark:text-red-400',         bg_class: 'bg-red-100 dark:bg-red-900/30',         swatch: 'bg-red-500' },
  { name: 'Mor',      color_class: 'text-purple-600 dark:text-purple-400',   bg_class: 'bg-purple-100 dark:bg-purple-900/30',   swatch: 'bg-purple-500' },
  { name: 'Pembe',    color_class: 'text-pink-600 dark:text-pink-400',       bg_class: 'bg-pink-100 dark:bg-pink-900/30',       swatch: 'bg-pink-500' },
  { name: 'Gri',      color_class: 'text-slate-600 dark:text-slate-400',     bg_class: 'bg-slate-100 dark:bg-slate-800',        swatch: 'bg-slate-500' },
];

// --- YARDIMCI FONKSİYONLAR ---
const sortAlpha = (arr, key) => [...arr].sort((a, b) => String(a[key]).localeCompare(String(b[key]), 'tr-TR'));
const TX_TYPE_LABEL: Record<string, string> = {
  'satış': 'Satılmış',
  'sale': 'Satılmış',
  'borç': 'Borç',
  'debt': 'Borç',
  'ödeme': 'Tahsilat',
  'payment': 'Tahsilat',
  'gider': 'Gider',
  'expense': 'Gider',
  'senet': 'Senet',
  'kredi': 'Kredi',
  'loan': 'Kredi',
  'garanti': 'Garanti',
};
const txTypeLabel = (t?: string) => (t && TX_TYPE_LABEL[t]) || t || '-';
const TX_TYPE_TONE: Record<string, string> = {
  'satış':   'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-800/50',
  'sale':    'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-800/50',
  'borç':    'bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-400 border-red-100 dark:border-red-800/50',
  'debt':    'bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-400 border-red-100 dark:border-red-800/50',
  'ödeme':   'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 border-blue-100 dark:border-blue-800/50',
  'payment': 'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 border-blue-100 dark:border-blue-800/50',
  'gider':   'bg-amber-50 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 border-amber-100 dark:border-amber-800/50',
  'expense': 'bg-amber-50 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 border-amber-100 dark:border-amber-800/50',
  'senet':   'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 border-indigo-100 dark:border-indigo-800/50',
  'kredi':   'bg-purple-50 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400 border-purple-100 dark:border-purple-800/50',
  'loan':    'bg-purple-50 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400 border-purple-100 dark:border-purple-800/50',
  'garanti': 'bg-teal-50 dark:bg-teal-900/30 text-teal-700 dark:text-teal-400 border-teal-100 dark:border-teal-800/50',
};
const txTypeTone = (t?: string) => (t && TX_TYPE_TONE[t]) || 'bg-slate-50 dark:bg-slate-900/30 text-slate-700 dark:text-slate-400 border-slate-100 dark:border-slate-800/50';
const CURRENCIES = [
  { code: 'TRY', symbol: '₺', label: 'Türk Lirası' },
  { code: 'USD', symbol: '$', label: 'Dolar' },
  { code: 'EUR', symbol: '€', label: 'Euro' },
];
const formatMoney = (amount, currency = 'TRY') => {
  const c = (currency || 'TRY').toUpperCase();
  try {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: c }).format(amount);
  } catch {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(amount);
  }
};

// --- DİL SÖZLÜĞÜ (İNGİLİZCE) ---
const EN_DICT = {
  'Giriş Yap': 'Log In',
  'Ücretsiz Başla': 'Start for Free',
  'İşletmenizin Stok ve Finansını': 'Manage Your Stock and Finances',
  'Tek Noktadan': 'In One Place',
  'Yönetin': '',
  'Karmaşık Excel tablolarına elveda deyin. Çalışan izinleri, esnek grafikler, veresiye takibi ve detaylı raporlarla tam kontrolü elinize alın.': 'Say goodbye to complex Excel sheets. Take full control with employee permissions, flexible charts, credit tracking, and detailed reports.',
  'Hemen Hesap Oluştur': 'Create Account Now',
  'Tekrar Hoş Geldiniz': 'Welcome Back',
  'Aramıza Katılın': 'Join Us',
  'Yönetim paneline erişmek için giriş yapın.': 'Log in to access the management dashboard.',
  'Ücretsiz hesabınızı saniyeler içinde oluşturun.': 'Create your free account in seconds.',
  'Bayi (Kurucu)': 'Dealer (Founder)',
  'Çalışan': 'Employee',
  'İşletme Adı': 'Company Name',
  'Ad Soyad': 'Full Name',
  'E-posta Adresi': 'Email Address',
  'Şifre': 'Password',
  'Referans Kodu (Opsiyonel)': 'Referral Code (Optional)',
  'Sisteme Giriş Yap': 'Log In to System',
  'Hesabımı Oluştur': 'Create My Account',
  'Hesabınız yok mu?': 'Don\'t have an account?',
  'Zaten hesabınız var mı?': 'Already have an account?',
  'Kayıt Ol': 'Sign Up',
  'Hızlı Test Girişleri': 'Quick Test Logins',
  'Bayi (Patron)': 'Dealer (Boss)',
  'Personel (Sınırlı)': 'Staff (Limited)',
  
  // Sidebar & Modules
  'Ana Panel': 'Dashboard',
  'STOK YÖNETİMİ (A-Z)': 'STOCK MANAGEMENT (A-Z)',
  'Genel Ürünler': 'General Products',
  'Cam Rüzgarlığı': 'Window Deflectors',
  'Jant Kapağı': 'Hubcaps',
  'Kaput Rüzgarlığı': 'Hood Deflectors',
  'Pandizot': 'Rear Decks',
  'Paspas': 'Floor Mats',
  'Spoiler': 'Spoilers',
  'FİNANS & YÖNETİM (A-Z)': 'FINANCE & MGT. (A-Z)',
  'Firma Borçları': 'Company Debts',
  'Garanti Belgeleri': 'Warranties',
  'İşlem Geçmişi': 'Transaction History',
  'Kasa Defteri': 'Cash Book',
  'Krediler': 'Loans',
  'Gelişmiş Raporlar': 'Advanced Reports',
  'Senetler': 'Promissory Notes',
  'Veresiye (Müşteri)': 'Credit (Customer)',
  'SİSTEM AYARLARI': 'SYSTEM SETTINGS',
  'Personel Yönetimi': 'Staff Management',
  'İşletme Profili': 'Company Profile',
  'Web Görünüm': 'Web Appearance',
  'Abonelik & Davet Et': 'Subscription & Invites',
  'Ayarlar (Yetki Yok)': 'Settings (No Access)',
  'Çıkış Yap': 'Log Out',
  'Yeni Kategori': 'New Category',
  'Kategori Adı': 'Category Name',
  'İkon Seç': 'Choose Icon',
  'Renk Seç': 'Choose Color',
  'Sıra': 'Order',
  'Görünür': 'Visible',
  'Gizli': 'Hidden',
  'Görünürlüğü Aç/Kapat': 'Toggle Visibility',
  'Yukarı Taşı': 'Move Up',
  'Aşağı Taşı': 'Move Down',
  'Sil': 'Delete',
  'Düzenle': 'Edit',
  'Stok Kategorileri': 'Stock Categories',
  'Finans Kategorileri': 'Finance Categories',
  'Kategori başarıyla eklendi': 'Category added successfully',
  'Kategori güncellendi': 'Category updated',
  'Kategori silindi': 'Category deleted',
  'Bu kategoriyi silmek istediğinize emin misiniz?': 'Are you sure you want to delete this category?',
  'Kategoriler yükleniyor...': 'Loading categories...',
  'Henüz kategori yok': 'No categories yet',
  'Tip': 'Type',
  'Bu kategori şu anda menüde gizli': 'This category is currently hidden from the menu',
  
  // Dashboard Core
  'Aktif Modüller:': 'Active Modules:',
  'Stok Kısayolları': 'Stock Shortcuts',
  'Finans Kısayolları': 'Finance Shortcuts',
  'Kritik Stok Uyarıları': 'Critical Stock Alerts',
  'Panel Görünümü': 'Panel View',
  'STOK YÖNETİMİ & KATEGORİLER (A-Z)': 'STOCK MANAGEMENT & CATEGORIES (A-Z)',
  'FİNANS, RAPOR & YÖNETİM (A-Z)': 'FINANCE, REPORTS & MANAGEMENT (A-Z)',
  'Kritik Stok Uyarısı': 'Critical Stock Alert',
  'Aşağıdaki': 'The following',
  'ürün stok limitinin altında! (A-Z Sıralı)': 'products are below the stock limit! (A-Z Sorted)',
  'Tümünü İncele': 'View All',
  'Kategori': 'Category',
  'Ürün Modeli': 'Product Model',
  'Stok': 'Stock',
  'Durum': 'Status',
  'TÜKENDİ': 'OUT OF STOCK',
  'KRİTİK': 'CRITICAL',
  'Hoşgeldiniz': 'Welcome',
  'genel durum panelindesiniz.': 'you are in the general dashboard.',
  
  // Actions
  'Yeni Kayıt': 'New Record',
  'Ad, model veya barkod ara...': 'Search name, model, or barcode...',
  'Toplam': 'Total',
  'kayıt listeleniyor. Sıralama: A-Z.': 'records listed. Sorted: A-Z.',
  'Yönetimi': 'Management',
  'Sistem Aktif': 'System Active',
  'Değişiklikleri Kaydet': 'Save Changes',
  'Kaydı Tamamla': 'Complete Record',
  'İptal Et': 'Cancel',
  'Kaydı Düzenle': 'Edit Record',
  
  // History & Profile
  'Tüm Kategoriler': 'All Categories',
  'Stok İşlemleri': 'Stock Transactions',
  'Finans & Cari': 'Finance & Credit',
  'Sistem Ayarları': 'System Settings',
  'Görseli İncele': 'View Image',
  'Deneme Sürümü': 'Trial Version',
  'Gün': 'Days',
  'kalan ücretsiz kullanım süreniz.': 'remaining free trial duration.',

  // Landing Page
  'Banka Düzeyinde Güvenlik': 'Bank-Level Security',
  'İşletmenizi Büyütecek': 'The Uninterrupted',
  'Kesintisiz': 'Infrastructure',
  'Altyapı': 'to Grow Your Business',
  'Karmaşık süreçleri tek ekranda basitleştirin. Verileriniz üst düzey şifrelemeyle korunurken, işletmenizi dünyanın her yerinden %100 stabil ve güvenle yönetin.': 'Simplify complex processes on a single screen. Your data is protected with top-level encryption while you manage your business from anywhere with 100% stability.',
  'Sistemi Kullanmaya Başla': 'Get Started Now',
  'Tüm İşiniz Tek Ekranda': 'Everything in One Screen',
  'Stok, finans ve çalışan yönetimi için ihtiyacınız olan tüm araçlar hızlı, anlaşılır ve tek bir panelde.': 'All tools you need for stock, finance, and staff management — fast, clear, and in one dashboard.',
  '7/24 Kesintisiz Erişim': '24/7 Uninterrupted Access',
  'İşiniz asla yavaşlamaz. Bulut tabanlı stabil altyapımızla verilerinize her cihazdan anında ulaşın.': 'Your business never slows down. Access your data instantly from any device with our stable cloud infrastructure.',
  'Otomatik Yedekleme': 'Automatic Backup',
  'Gelişmiş bulut teknolojimizle bilgileriniz her saniye otomatik yedeklenir. Gözünüz arkada kalmasın.': 'Your data is automatically backed up every second with our advanced cloud technology. Never worry about data loss.',
  'Üst Düzey Şifreleme': 'Top-Level Encryption',
  'Tüm finansal verileriniz 256-bit şifreleme ve uluslararası güvenlik standartlarıyla yalnızca size aittir.': 'All your financial data belongs only to you, protected by 256-bit encryption and international security standards.',
  'Size Neler Sunuyoruz?': 'What Do We Offer?',
  'İşinizi büyütürken arkanızda duracak sağlam ve güvenilir bir ekosistem.': 'A solid and reliable ecosystem that stands behind you as your business grows.',
  'İşletme Modülleri': 'Business Modules',
  'Anlık Stok, Kategori ve Çoklu Depo Takibi': 'Real-time Stock, Category & Multi-Warehouse Tracking',
  'Gelir/Gider ve Karlılık Durum Analizi': 'Income/Expense & Profitability Analysis',
  'Müşteri Veresiye ve Cari Hesap Yönetimi': 'Customer Credit & Current Account Management',
  'Karar Almayı Kolaylaştıran Dinamik Raporlar': 'Dynamic Reports to Facilitate Decision Making',
  'Çalışan Performansı ve İzin/Rol Yönetimi': 'Employee Performance & Permission/Role Management',
  'Güvenlik & Kesintisizlik': 'Security & Uptime',
  '256-bit SSL sertifikaları ile uçtan uca şifreli iletişim': 'End-to-end encrypted communication with 256-bit SSL certificates',
  'Düzenli ve otomatik bulut yedekleme ile sıfır veri kaybı riski': 'Zero data loss risk with regular and automatic cloud backups',
  '%99.9 erişilebilirlik ile asla durmayan sistem performansı': '99.9% availability with never-stopping system performance',
  'Kötü niyetli girişimleri anında engelleyen akıllı koruma': 'Smart protection that instantly blocks malicious attempts',
  'Yalnızca yetkilendirdiğiniz personelin erişebildiği veri panelleri': 'Data panels accessible only to the personnel you authorize',
  '© 2026 StokFinans. Tüm hakları saklıdır.': '© 2026 StokFinans. All rights reserved.',
};

// --- API HATA MESAJI YARDIMCISI ---
// Pydantic v2, 422 hatalarında detail alanını [{type,loc,msg,input}] dizisi olarak döndürür.
// Bu helper her API hatasını güvenli bir şekilde string'e dönüştürür.
function apiErr(err: any, fallback = 'Bir hata oluştu'): string {
  const d = err?.response?.data?.detail;
  if (typeof d === 'string' && d) return d;
  if (Array.isArray(d) && d.length > 0) return d.map((e: any) => (typeof e === 'string' ? e : (e?.msg ?? JSON.stringify(e)))).join(', ');
  if (d && typeof d === 'object') return d.message ?? d.msg ?? fallback;
  const msg = err?.response?.data?.message || err?.message;
  return typeof msg === 'string' && msg ? msg : fallback;
}

// --- TOAST BİLDİRİM SİSTEMİ ---
const ToastContainer = ({ toasts }) => (
  <div className="fixed top-4 right-4 z-[200] flex flex-col gap-2 pointer-events-none">
    {toasts.map(t => (
      <div key={t.id} className={`pointer-events-auto flex items-start gap-3 px-4 py-3 rounded-xl shadow-xl text-sm font-bold text-white animate-in slide-in-from-right-4 duration-300 max-w-sm ${t.type === 'error' ? 'bg-red-600' : t.type === 'warning' ? 'bg-amber-500' : 'bg-emerald-600'}`}>
        <span className="text-base">{t.type === 'error' ? '✕' : t.type === 'warning' ? '⚠' : '✓'}</span>
        <span className="leading-snug">{t.msg}</span>
      </div>
    ))}
  </div>
);

// --- GLOBAL CONTEXT (Dil, Tema, Toast ve Kategoriler) ---
const AppContext = createContext();
const useAppContext = () => useContext(AppContext);

// --- DİNAMİK MODÜL HARİTASI (kategorilerden türetilir) ---
// Her bir kategori, bir menü/route'a karşılık gelir. Buradaki şekil
// eski hardcoded MODULE_CONFIG ile uyumludur, böylece GenericModuleView
// hiç değiştirilmeden çalışmaya devam eder.
function buildModuleConfig(categories: any[]): Record<string, any> {
  const cfg: Record<string, any> = {};
  for (const c of categories || []) {
    if (c.kind === 'stok') {
      cfg[c.key] = {
        type: 'stok',
        categoryFilter: c.name,
        defaultCategory: c.name,
        viewMode: c.view_mode || 'list',
      };
    } else if (c.kind === 'finans') {
      const tt = c.transaction_type ?? null;
      const nameSorted = tt === 'borç' || tt === 'garanti';
      // Bakiye-bazlı modüller müşteri özet listesi gösterir (grouped).
      // Kasa Defteri ve Garanti tek tek işlem listesi olarak kalır.
      const grouped = ['borç', 'gider', 'senet', 'kredi'].includes(tt as string);
      cfg[c.key] = {
        type: 'finans',
        transactionType: tt,
        customerLabel: c.customer_label || 'Cari',
        amountLabel: c.amount_label || 'Tutar (₺)',
        amountTone: c.amount_tone || 'slate',
        allowEditType: !!c.allow_edit_type,
        viewMode: c.view_mode || 'list',
        sortMode: nameSorted || grouped ? 'name_asc' : 'date_desc',
        grouped,
      };
    }
  }
  return cfg;
}

// Görünüm modu seçenekleri (her kategoriye özel)
const VIEW_MODES: { id: 'list' | 'grid' | 'masonry' | 'carousel' | 'category'; label: string; icon: any; desc: string }[] = [
  { id: 'list',     label: 'Liste',      icon: List,         desc: 'Satır satır tablo görünümü' },
  { id: 'grid',     label: 'Izgara',     icon: LayoutGrid,   desc: '3-4 sütunlu kart ızgarası' },
  { id: 'masonry',  label: 'Mozaik',     icon: Rows3,        desc: 'Pinterest tarzı dinamik dizilim' },
  { id: 'carousel', label: 'Kaydırmalı', icon: GalleryHorizontal, desc: 'Yatay kaydırılabilir kartlar' },
  { id: 'category', label: 'Kategori',   icon: FolderTree,   desc: 'Alt-kategoriye göre gruplanmış' },
];

function buildModuleMap(categories: any[]): Record<string, { title: string; icon: any; type: 'stok' | 'finans' }> {
  const map: Record<string, any> = {};
  for (const c of categories || []) {
    map[c.key] = { title: c.name, icon: iconFor(c.icon), type: c.kind === 'finans' ? 'finans' : 'stok' };
  }
  return map;
}

const SettingsToggle = () => {
  const { theme, toggleTheme, lang, toggleLang } = useAppContext();
  return (
    <div className="flex items-center gap-2">
      <button onClick={toggleLang} className="flex items-center justify-center w-14 h-9 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition font-black text-xs shadow-sm">
        <Globe size={14} className="mr-1 opacity-50" /> {lang.toUpperCase()}
      </button>
      <button onClick={toggleTheme} className="flex items-center justify-center w-10 h-9 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition shadow-sm">
        {theme === 'dark' ? <Sun size={18} className="text-amber-400" /> : <Moon size={18} className="text-indigo-600 dark:text-indigo-400" />}
      </button>
    </div>
  );
};

// --- MOCK VERİLER KALDIRILDI ---

// ============================================================
// QR / Barkod Tarayıcı Modal
// Native getUserMedia ile kamera yönetimi:
//   1. getUserMedia → tarayıcı izin dialogu tetiklenir
//   2. video.srcObject = stream → video kesin olarak görünür
//   3. BarcodeDetector (Chrome/Edge/Android) veya ZXing decodeFromStream fallback
// ============================================================
const QRScannerModal = ({
  onDetected,
  onClose,
  fillMode = false,
  title = 'Barkod / QR Tara',
}: {
  onDetected: (text: string) => void;
  onClose: () => void;
  fillMode?: boolean;
  title?: string;
}) => {
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const canvasRef = React.useRef<HTMLCanvasElement>(null);
  const streamRef = React.useRef<MediaStream | null>(null);
  const rafRef = React.useRef<number>(0);
  const zxingControlsRef = React.useRef<any>(null);
  const detectedRef = React.useRef(false);
  const mountedRef = React.useRef(true);
  const [cameras, setCameras] = useState<{ deviceId: string; label: string }[]>([]);
  const [activeCameraId, setActiveCameraId] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [detected, setDetected] = useState<string | null>(null);
  const [starting, setStarting] = useState(true);

  const stopEverything = () => {
    cancelAnimationFrame(rafRef.current);
    if (zxingControlsRef.current) {
      try { zxingControlsRef.current.stop(); } catch {}
      zxingControlsRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) videoRef.current.srcObject = null;
  };

  const handleDetected = (text: string) => {
    if (detectedRef.current || !mountedRef.current) return;
    detectedRef.current = true;
    setDetected(text);
    onDetected(text);
    if (fillMode) setTimeout(onClose, 700);
  };

  const startBarcodeDetection = (video: HTMLVideoElement, stream: MediaStream) => {
    // BarcodeDetector API — Chrome 83+, Edge, Samsung Internet, Chrome Android
    if ('BarcodeDetector' in window) {
      const bd = new (window as any).BarcodeDetector({
        formats: ['qr_code', 'ean_13', 'ean_8', 'code_128', 'code_39', 'code_93',
          'upc_a', 'upc_e', 'itf', 'data_matrix', 'aztec', 'pdf417', 'codabar'],
      });
      const tick = async () => {
        if (!mountedRef.current || detectedRef.current) return;
        if (video.readyState >= 2 && video.videoWidth > 0) {
          try {
            const codes = await bd.detect(video);
            if (codes.length > 0) { handleDetected(codes[0].rawValue); return; }
          } catch {}
        }
        rafRef.current = requestAnimationFrame(tick);
      };
      rafRef.current = requestAnimationFrame(tick);
      return;
    }

    // ZXing fallback — decodeFromStream, kamera stream'ini alıyor
    (async () => {
      try {
        const { BrowserMultiFormatReader } = await import('@zxing/browser');
        const reader = new BrowserMultiFormatReader();
        // video zaten srcObject ile stream'e bağlı; ZXing yeniden play() atmaz
        const controls = await reader.decodeFromStream(stream, video, (result) => {
          if (result) handleDetected(result.getText());
        });
        if (!mountedRef.current) { controls.stop(); return; }
        zxingControlsRef.current = controls;
      } catch (e) {
        // ZXing de başarısız olduysa canvas polling
        if (!canvasRef.current || !mountedRef.current) return;
        (async () => {
          const { BrowserMultiFormatReader } = await import('@zxing/browser');
          const reader = new BrowserMultiFormatReader();
          const canvas = canvasRef.current!;
          const tick = () => {
            if (!mountedRef.current || detectedRef.current) return;
            if (video.readyState >= 2 && video.videoWidth > 0) {
              canvas.width = video.videoWidth;
              canvas.height = video.videoHeight;
              const ctx = canvas.getContext('2d', { willReadFrequently: true });
              if (ctx) {
                ctx.drawImage(video, 0, 0);
                (reader as any).decodeFromCanvas(canvas)
                  .then((res: any) => { if (res) handleDetected(res.getText()); })
                  .catch(() => { rafRef.current = requestAnimationFrame(tick); });
                return;
              }
            }
            rafRef.current = requestAnimationFrame(tick);
          };
          rafRef.current = requestAnimationFrame(tick);
        })();
      }
    })();
  };

  const startCamera = async (deviceId?: string) => {
    if (!videoRef.current || !mountedRef.current) return;
    stopEverything();
    detectedRef.current = false;
    setDetected(null);
    setError(null);
    setStarting(true);

    const videoConstraints: MediaTrackConstraints = deviceId
      ? { deviceId: { exact: deviceId }, width: { ideal: 1280 }, height: { ideal: 720 } }
      : { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } };

    const tryGetStream = async (c: MediaTrackConstraints): Promise<MediaStream> =>
      navigator.mediaDevices.getUserMedia({ video: c });

    let stream: MediaStream;
    try {
      stream = await tryGetStream(videoConstraints);
    } catch (e: any) {
      if (e?.name === 'OverconstrainedError' && !deviceId) {
        // facingMode veya çözünürlük desteklenmiyorsa kısıtsız dene
        try { stream = await navigator.mediaDevices.getUserMedia({ video: true }); }
        catch (e2: any) { showCameraError(e2); return; }
      } else {
        showCameraError(e);
        return;
      }
    }

    if (!mountedRef.current) { stream!.getTracks().forEach(t => t.stop()); return; }

    streamRef.current = stream!;
    const video = videoRef.current;
    video.srcObject = stream!;

    try { await video.play(); } catch {}
    if (!mountedRef.current) return;

    setStarting(false);
    if (deviceId) setActiveCameraId(deviceId);

    // İzin alındıktan sonra gerçek device listesi gelir
    try {
      const devs = await navigator.mediaDevices.enumerateDevices();
      if (!mountedRef.current) return;
      const cams = devs.filter(d => d.kind === 'videoinput' && d.deviceId);
      if (cams.length > 1) {
        setCameras(cams.map((d, i) => ({ deviceId: d.deviceId, label: d.label || `Kamera ${i + 1}` })));
        if (!deviceId) {
          const settings = stream!.getVideoTracks()[0]?.getSettings();
          setActiveCameraId(settings?.deviceId || '');
        }
      }
    } catch {}

    startBarcodeDetection(video, stream!);
  };

  const showCameraError = (e: any) => {
    if (!mountedRef.current) return;
    const n = e?.name ?? '';
    if (n === 'NotAllowedError' || n === 'PermissionDeniedError')
      setError('Kamera izni reddedildi. Tarayıcı adres çubuğundaki kilit/kamera ikonuna tıklayıp izin verin, sonra sayfayı yenileyin.');
    else if (n === 'NotFoundError' || n === 'DevicesNotFoundError')
      setError('Kamera bulunamadı. Cihazınızda kamera olduğundan emin olun.');
    else if (n === 'NotReadableError' || n === 'TrackStartError')
      setError('Kamera başka bir uygulama tarafından kullanılıyor. Diğer sekmeleri veya uygulamaları kapatıp tekrar deneyin.');
    else
      setError(`Kamera açılamadı${n ? ` (${n})` : ''}. Sayfayı yenileyip tekrar deneyin.`);
    setStarting(false);
  };

  useEffect(() => {
    mountedRef.current = true;

    if (!navigator.mediaDevices?.getUserMedia) {
      setError('Bu tarayıcı kamera erişimini desteklemiyor. Chrome, Edge veya Safari kullanın.');
      setStarting(false);
      return;
    }

    if (!window.isSecureContext && window.location.hostname !== 'localhost') {
      setError('Kamera yalnızca güvenli bağlantılarda (HTTPS) çalışır.');
      setStarting(false);
      return;
    }

    startCamera();

    return () => {
      mountedRef.current = false;
      cancelAnimationFrame(rafRef.current);
      stopEverything();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="fixed inset-0 z-[200] flex flex-col bg-black" role="dialog" aria-modal="true">
      <div className="flex items-center justify-between px-4 py-3 bg-black/80 border-b border-white/10 shrink-0">
        <div className="flex items-center gap-2 text-white">
          <ScanLine size={20} className="text-indigo-400" />
          <span className="font-bold text-sm">{title}</span>
          {starting && !error && <span className="text-slate-400 text-xs ml-1">Başlatılıyor...</span>}
        </div>
        <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition">
          <X size={20} />
        </button>
      </div>

      <div className="flex-1 relative overflow-hidden">
        <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover" autoPlay muted playsInline />
        <canvas ref={canvasRef} className="hidden" />

        {/* Karartma overlay */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute inset-x-0 top-0 bg-black/55" style={{ bottom: 'calc(50% + 128px)' }} />
          <div className="absolute inset-x-0 bottom-0 bg-black/55" style={{ top: 'calc(50% + 128px)' }} />
          <div className="absolute left-0 bg-black/55" style={{ top: 'calc(50% - 128px)', bottom: 'calc(50% - 128px)', right: 'calc(50% + 128px)' }} />
          <div className="absolute right-0 bg-black/55" style={{ top: 'calc(50% - 128px)', bottom: 'calc(50% - 128px)', left: 'calc(50% + 128px)' }} />
        </div>

        {/* Tarama çerçevesi */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="relative w-64 h-64">
            <div className="absolute top-0 left-0 w-10 h-10 border-t-4 border-l-4 border-indigo-400 rounded-tl-xl" />
            <div className="absolute top-0 right-0 w-10 h-10 border-t-4 border-r-4 border-indigo-400 rounded-tr-xl" />
            <div className="absolute bottom-0 left-0 w-10 h-10 border-b-4 border-l-4 border-indigo-400 rounded-bl-xl" />
            <div className="absolute bottom-0 right-0 w-10 h-10 border-b-4 border-r-4 border-indigo-400 rounded-br-xl" />
            {!error && !detected && (
              <div className="absolute left-2 right-2 h-0.5 bg-indigo-400 shadow-[0_0_10px_3px_rgba(99,102,241,0.5)] scanner-line" />
            )}
            {detected && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-20 h-20 rounded-full bg-emerald-500/90 flex items-center justify-center shadow-xl">
                  <Check size={40} className="text-white" />
                </div>
              </div>
            )}
          </div>
        </div>

        {error && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/80 p-8">
            <div className="text-center space-y-4 max-w-xs">
              <div className="w-16 h-16 rounded-full bg-red-500/20 border border-red-500/30 flex items-center justify-center mx-auto">
                <X size={28} className="text-red-400" />
              </div>
              <p className="text-red-300 font-medium text-sm leading-relaxed">{error}</p>
              <button onClick={onClose} className="px-6 py-2.5 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-sm font-bold transition">
                Kapat
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="bg-black/80 border-t border-white/10 shrink-0 px-4 py-4 space-y-3">
        {cameras.length > 1 && (
          <select
            value={activeCameraId}
            onChange={e => startCamera(e.target.value)}
            className="w-full text-sm rounded-xl border border-white/10 bg-white/5 text-slate-200 px-3 py-2 outline-none"
          >
            {cameras.map(c => <option key={c.deviceId} value={c.deviceId}>{c.label}</option>)}
          </select>
        )}
        {detected ? (
          <div className="flex items-center gap-2 bg-emerald-900/40 border border-emerald-700/50 rounded-xl px-4 py-2.5">
            <Check size={16} className="text-emerald-400 shrink-0" />
            <span className="text-emerald-300 font-mono text-sm truncate">{detected}</span>
          </div>
        ) : !error && (
          <p className="text-center text-slate-400 text-sm">
            {starting ? 'Kamera izni bekleniyor...' : 'QR kodu veya barkodu çerçeve içine tutun'}
          </p>
        )}
      </div>
    </div>
  );
};

// ============================================================
// Tarama Sonucu — Ürün Hızlı Görünüm Modal
// ============================================================
const ProductQuickViewModal = ({
  product, onClose, canEdit, canViewCost, onEdit,
}: {
  product: any; onClose: () => void; canEdit: boolean; canViewCost: boolean; onEdit?: () => void;
}) => {
  const C: Record<string, string> = { TRY: '₺', USD: '$', EUR: '€' };
  const sym = (c: string) => C[c] || c;
  const isLow = product.quantity <= (product.min_stock_alert ?? 5);
  return (
    <div className="fixed inset-0 z-[150] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-2xl w-full sm:max-w-sm overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between p-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-900/40 flex items-center justify-center">
              <QrCode size={16} className="text-indigo-600 dark:text-indigo-400" />
            </div>
            <span className="font-bold text-slate-800 dark:text-white text-sm">Tarama Sonucu</span>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 transition"><X size={18} /></button>
        </div>
        <div className="p-4 space-y-4">
          <div className="flex gap-3 items-start">
            {product.image_url ? (
              <ZoomImg src={product.image_url} alt={product.name} className="w-16 h-16 rounded-xl object-cover bg-slate-100 dark:bg-slate-800 shrink-0" />
            ) : (
              <div className="w-16 h-16 rounded-xl bg-indigo-50 dark:bg-indigo-900/20 flex items-center justify-center shrink-0">
                <Package size={28} className="text-indigo-400" />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <h3 className="font-black text-slate-800 dark:text-white text-base leading-tight">{product.name}</h3>
              {product.category && <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">{product.category}{product.subcategory ? ` · ${product.subcategory}` : ''}</p>}
              {product.barcode && product.barcode !== '-' && (
                <span className="text-xs font-mono text-slate-400 dark:text-slate-500 mt-1 bg-slate-50 dark:bg-slate-800 px-2 py-0.5 rounded-lg inline-block">{product.barcode}</span>
              )}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-emerald-50 dark:bg-emerald-900/20 rounded-xl p-3 border border-emerald-100 dark:border-emerald-800/30">
              <p className="text-[10px] text-emerald-600 dark:text-emerald-500 font-bold uppercase tracking-wider mb-1">Satış Fiyatı</p>
              <p className="text-lg font-black text-emerald-700 dark:text-emerald-400">{sym(product.currency || 'TRY')}{(product.price ?? 0).toLocaleString('tr-TR', { minimumFractionDigits: 2 })}</p>
            </div>
            {canViewCost && (
              <div className="bg-amber-50 dark:bg-amber-900/20 rounded-xl p-3 border border-amber-100 dark:border-amber-800/30">
                <p className="text-[10px] text-amber-600 dark:text-amber-500 font-bold uppercase tracking-wider mb-1">Alış Fiyatı</p>
                <p className="text-lg font-black text-amber-700 dark:text-amber-400">{sym(product.cost_currency || product.currency || 'TRY')}{(product.cost ?? 0).toLocaleString('tr-TR', { minimumFractionDigits: 2 })}</p>
              </div>
            )}
            <div className={`${!canViewCost ? 'col-span-2' : ''} ${isLow ? 'bg-red-50 dark:bg-red-900/20 border-red-100 dark:border-red-800/30' : 'bg-indigo-50 dark:bg-indigo-900/20 border-indigo-100 dark:border-indigo-800/30'} rounded-xl p-3 border`}>
              <p className={`text-[10px] font-bold uppercase tracking-wider mb-1 ${isLow ? 'text-red-600 dark:text-red-500' : 'text-indigo-600 dark:text-indigo-500'}`}>Stok</p>
              <p className={`text-lg font-black ${isLow ? 'text-red-700 dark:text-red-400' : 'text-indigo-700 dark:text-indigo-400'}`}>
                {product.quantity} adet {isLow && <span className="text-xs ml-1">⚠ Kritik</span>}
              </p>
            </div>
          </div>
          <div className="flex gap-2 pt-1">
            <button onClick={onClose} className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 font-bold text-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition">Kapat</button>
            {canEdit && onEdit && (
              <button onClick={onEdit} className="flex-1 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm transition flex items-center justify-center gap-2">
                <Edit size={16} /> Düzenle
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// --- BİLEŞENLER ---

// --- Landing Page Yardımcı Bileşenleri ---
const FeatureCard = ({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) => (
  <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 hover:shadow-md transition-shadow">
    <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-xl flex items-center justify-center mb-4">
      {icon}
    </div>
    <h3 className="text-xl font-bold mb-2 text-slate-800 dark:text-white">{title}</h3>
    <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed">{desc}</p>
  </div>
);

const ListItem = ({ text }: { text: string }) => (
  <li className="flex items-start gap-3">
    <CheckCircle size={18} className="text-green-500 mt-0.5 shrink-0" />
    <span className="text-slate-700 dark:text-slate-300">{text}</span>
  </li>
);

// 1. Karşılama Sayfası (Landing Page)
const LandingPage = ({ setView }) => {
  const { t } = useAppContext();
  const [siteInfo, setSiteInfo] = React.useState<any>(null);
  React.useEffect(() => {
    import('./lib/api').then(({ default: apiMod }) => {
      apiMod.get('/public/site-info').then(r => setSiteInfo(r.data)).catch(() => {});
    });
  }, []);
  const hasContact = siteInfo && (siteInfo.company_name || siteInfo.phone || siteInfo.email || siteInfo.address || siteInfo.about_text);
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col font-sans transition-colors duration-300">

      {/* Üst Menü */}
      <nav className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 py-4 flex justify-between items-center sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <img src="/logo.png" alt="StokFinans" className="w-8 h-8 object-contain" />
          <span className="text-xl sm:text-2xl font-black tracking-tight text-indigo-600 dark:text-indigo-400">StokFinans</span>
        </div>
        <div className="flex items-center gap-2 sm:gap-4">
          <SettingsToggle />
          <button onClick={() => setView('login')} className="hidden sm:block px-4 py-2 text-slate-600 dark:text-slate-300 font-medium hover:text-indigo-600 dark:hover:text-indigo-400 transition">{t('Giriş Yap')}</button>
          <button onClick={() => setView('register')} className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg transition-colors shadow-sm text-sm sm:text-base">
            {t('Ücretsiz Başla')}
          </button>
        </div>
      </nav>

      {/* Ana İçerik */}
      <main className="flex-1 flex flex-col items-center px-4 py-16 sm:py-20">

        {/* Hero Section */}
        <div className="text-center max-w-4xl mx-auto mb-20 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 text-xs font-bold mb-6 border border-emerald-200 dark:border-emerald-800">
            <ShieldCheck size={14} className="text-emerald-500" />
            {t('Banka Düzeyinde Güvenlik')}
          </div>
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-slate-900 dark:text-white mb-6 tracking-tight leading-tight">
            {t('İşletmenizi Büyütecek')} <span className="text-indigo-600 dark:text-indigo-400">{t('Kesintisiz')}</span> {t('Altyapı')}
          </h1>
          <p className="text-lg sm:text-xl text-slate-600 dark:text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed">
            {t('Karmaşık süreçleri tek ekranda basitleştirin. Verileriniz üst düzey şifrelemeyle korunurken, işletmenizi dünyanın her yerinden %100 stabil ve güvenle yönetin.')}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={() => setView('register')} className="px-8 py-3.5 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200 dark:shadow-indigo-900/20 flex items-center justify-center gap-2">
              {t('Sistemi Kullanmaya Başla')} <ArrowRight size={20} />
            </button>
          </div>
        </div>

        {/* Özellikler Grid */}
        <div className="w-full max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-150">
          <FeatureCard
            icon={<Layers size={24} />}
            title={t('Tüm İşiniz Tek Ekranda')}
            desc={t('Stok, finans ve çalışan yönetimi için ihtiyacınız olan tüm araçlar hızlı, anlaşılır ve tek bir panelde.')}
          />
          <FeatureCard
            icon={<Activity size={24} />}
            title={t('7/24 Kesintisiz Erişim')}
            desc={t('İşiniz asla yavaşlamaz. Bulut tabanlı stabil altyapımızla verilerinize her cihazdan anında ulaşın.')}
          />
          <FeatureCard
            icon={<Database size={24} />}
            title={t('Otomatik Yedekleme')}
            desc={t('Gelişmiş bulut teknolojimizle bilgileriniz her saniye otomatik yedeklenir. Gözünüz arkada kalmasın.')}
          />
          <FeatureCard
            icon={<ShieldCheck size={24} />}
            title={t('Üst Düzey Şifreleme')}
            desc={t('Tüm finansal verileriniz 256-bit şifreleme ve uluslararası güvenlik standartlarıyla yalnızca size aittir.')}
          />
        </div>

        {/* Detaylı Sistem İçeriği */}
        <div className="w-full max-w-5xl mx-auto bg-white dark:bg-slate-900 rounded-3xl p-8 sm:p-12 shadow-xl border border-slate-100 dark:border-slate-800 animate-in fade-in slide-in-from-bottom-10 duration-700 delay-300">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white mb-4">{t('Size Neler Sunuyoruz?')}</h2>
            <p className="text-slate-600 dark:text-slate-400">{t('İşinizi büyütürken arkanızda duracak sağlam ve güvenilir bir ekosistem.')}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-10">
            <div className="bg-slate-50 dark:bg-slate-950/50 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 hover:border-indigo-200 dark:hover:border-indigo-800 transition-colors">
              <h3 className="text-lg font-bold mb-6 flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
                <Layers size={22} /> {t('İşletme Modülleri')}
              </h3>
              <ul className="space-y-4">
                <ListItem text={t('Anlık Stok, Kategori ve Çoklu Depo Takibi')} />
                <ListItem text={t('Gelir/Gider ve Karlılık Durum Analizi')} />
                <ListItem text={t('Müşteri Veresiye ve Cari Hesap Yönetimi')} />
                <ListItem text={t('Karar Almayı Kolaylaştıran Dinamik Raporlar')} />
                <ListItem text={t('Çalışan Performansı ve İzin/Rol Yönetimi')} />
              </ul>
            </div>

            <div className="bg-slate-50 dark:bg-slate-950/50 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 hover:border-indigo-200 dark:hover:border-indigo-800 transition-colors">
              <h3 className="text-lg font-bold mb-6 flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
                <ShieldCheck size={22} /> {t('Güvenlik & Kesintisizlik')}
              </h3>
              <ul className="space-y-4">
                <ListItem text={t('256-bit SSL sertifikaları ile uçtan uca şifreli iletişim')} />
                <ListItem text={t('Düzenli ve otomatik bulut yedekleme ile sıfır veri kaybı riski')} />
                <ListItem text={t('%99.9 erişilebilirlik ile asla durmayan sistem performansı')} />
                <ListItem text={t('Kötü niyetli girişimleri anında engelleyen akıllı koruma')} />
                <ListItem text={t('Yalnızca yetkilendirdiğiniz personelin erişebildiği veri panelleri')} />
              </ul>
            </div>
          </div>
        </div>

        {/* Hakkımızda & İletişim */}
        {hasContact && (
          <div className="w-full max-w-5xl mx-auto mt-20 animate-in fade-in slide-in-from-bottom-10 duration-700 delay-500">

            {/* Bölüm başlığı */}
            <div className="text-center mb-12">
              <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 text-xs font-bold mb-4 border border-indigo-200 dark:border-indigo-800">
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                {siteInfo.company_name || t('Şirket')}
              </span>
              <h2 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white mb-3">{t('Hakkımızda')}</h2>
              {siteInfo.contact_person && (
                <p className="text-slate-500 dark:text-slate-400 text-base">{siteInfo.contact_person}</p>
              )}
            </div>

            {/* Hakkımızda metni — tam genişlik, paragraf destekli */}
            {siteInfo.about_text && (
              <div className="bg-gradient-to-br from-indigo-50 to-slate-50 dark:from-indigo-950/40 dark:to-slate-900 rounded-3xl p-8 sm:p-10 border border-indigo-100 dark:border-indigo-900/40 mb-8">
                {siteInfo.about_text.split('\n').filter((l: string) => l.trim()).map((para: string, i: number) => (
                  <p key={i} className="text-slate-700 dark:text-slate-300 text-base leading-relaxed mb-4 last:mb-0">{para}</p>
                ))}
              </div>
            )}

            {/* Adres + Çalışma saatleri — yan yana kartlar */}
            {(siteInfo.address || siteInfo.working_hours) && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
                {siteInfo.address && (
                  <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-100 dark:border-slate-800 shadow-sm flex gap-4 items-start">
                    <div className="w-11 h-11 rounded-2xl bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center shrink-0 mt-0.5">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-emerald-600 dark:text-emerald-400"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">{t('Adresimiz')}</p>
                      {siteInfo.address.split('\n').filter((l: string) => l.trim()).map((line: string, i: number) => (
                        <p key={i} className="text-slate-700 dark:text-slate-300 text-sm leading-relaxed">{line}</p>
                      ))}
                    </div>
                  </div>
                )}
                {siteInfo.working_hours && (
                  <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-100 dark:border-slate-800 shadow-sm flex gap-4 items-start">
                    <div className="w-11 h-11 rounded-2xl bg-sky-100 dark:bg-sky-900/30 flex items-center justify-center shrink-0 mt-0.5">
                      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-sky-600 dark:text-sky-400"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-2">{t('Çalışma Saatleri')}</p>
                      {siteInfo.working_hours.split('\n').filter((l: string) => l.trim()).map((line: string, i: number) => (
                        <p key={i} className="text-slate-700 dark:text-slate-300 text-sm leading-relaxed">{line}</p>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* İletişim butonları — yatay grid */}
            {(siteInfo.phone || siteInfo.whatsapp_number || siteInfo.email || siteInfo.instagram_url) && (
              <div>
                <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest text-center mb-5">{t('İletişime Geçin')}</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  {siteInfo.phone && (
                    <a href={`tel:${siteInfo.phone.replace(/\s/g, '')}`}
                      className="flex flex-col items-center gap-3 px-4 py-5 bg-white dark:bg-slate-900 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 rounded-2xl text-slate-700 dark:text-slate-200 font-semibold text-sm transition-all shadow-sm hover:shadow group">
                      <span className="w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-900/40 group-hover:bg-indigo-200 dark:group-hover:bg-indigo-800/60 flex items-center justify-center transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-indigo-600 dark:text-indigo-400"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.07 11.5a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3 .82h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.09 8.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 21 16z"/></svg>
                      </span>
                      <span className="text-center">
                        <span className="block text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider mb-0.5">{t('Telefon')}</span>
                        {siteInfo.phone}
                      </span>
                    </a>
                  )}
                  {siteInfo.whatsapp_number && (
                    <a href={`https://wa.me/${siteInfo.whatsapp_number.replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer"
                      className="flex flex-col items-center gap-3 px-4 py-5 bg-white dark:bg-slate-900 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 border border-slate-200 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-700 rounded-2xl text-slate-700 dark:text-slate-200 font-semibold text-sm transition-all shadow-sm hover:shadow group">
                      <span className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-900/40 group-hover:bg-emerald-200 dark:group-hover:bg-emerald-800/60 flex items-center justify-center transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="currentColor" className="text-emerald-600 dark:text-emerald-400"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/></svg>
                      </span>
                      <span className="text-center">
                        <span className="block text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider mb-0.5">WhatsApp</span>
                        {t('Hemen Yaz')}
                      </span>
                    </a>
                  )}
                  {siteInfo.email && (
                    <a href={`mailto:${siteInfo.email}`}
                      className="flex flex-col items-center gap-3 px-4 py-5 bg-white dark:bg-slate-900 hover:bg-sky-50 dark:hover:bg-sky-950/60 border border-slate-200 dark:border-slate-800 hover:border-sky-300 dark:hover:border-sky-700 rounded-2xl text-slate-700 dark:text-slate-200 font-semibold text-sm transition-all shadow-sm hover:shadow group">
                      <span className="w-12 h-12 rounded-2xl bg-sky-100 dark:bg-sky-900/40 group-hover:bg-sky-200 dark:group-hover:bg-sky-800/60 flex items-center justify-center transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-sky-600 dark:text-sky-400"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                      </span>
                      <span className="text-center">
                        <span className="block text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider mb-0.5">{t('E-posta')}</span>
                        {siteInfo.email}
                      </span>
                    </a>
                  )}
                  {siteInfo.instagram_url && (
                    <a href={siteInfo.instagram_url} target="_blank" rel="noopener noreferrer"
                      className="flex flex-col items-center gap-3 px-4 py-5 bg-white dark:bg-slate-900 hover:bg-pink-50 dark:hover:bg-pink-950/60 border border-slate-200 dark:border-slate-800 hover:border-pink-300 dark:hover:border-pink-700 rounded-2xl text-slate-700 dark:text-slate-200 font-semibold text-sm transition-all shadow-sm hover:shadow group">
                      <span className="w-12 h-12 rounded-2xl bg-gradient-to-br from-pink-100 to-purple-100 dark:from-pink-900/40 dark:to-purple-900/40 group-hover:from-pink-200 group-hover:to-purple-200 flex items-center justify-center transition-all">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="currentColor" className="text-pink-600 dark:text-pink-400"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
                      </span>
                      <span className="text-center">
                        <span className="block text-xs text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider mb-0.5">Instagram</span>
                        {t('Takip Et')}
                      </span>
                    </a>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="py-8 text-center text-slate-500 dark:text-slate-400 text-sm border-t border-slate-200 dark:border-slate-800">
        <p>{t('© 2026 StokFinans. Tüm hakları saklıdır.')}</p>
      </footer>
    </div>
  );
};

// 2. Giriş & Kayıt Sayfaları
const noticeColorMap: Record<string, string> = {
  indigo: 'bg-indigo-50 dark:bg-indigo-900/20 border-indigo-200 dark:border-indigo-700/60 text-indigo-800 dark:text-indigo-300',
  green:  'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-700/60 text-green-800 dark:text-green-300',
  amber:  'bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-700/60 text-amber-800 dark:text-amber-300',
  red:    'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-700/60 text-red-800 dark:text-red-300',
  sky:    'bg-sky-50 dark:bg-sky-900/20 border-sky-200 dark:border-sky-700/60 text-sky-800 dark:text-sky-300',
};

const AuthPage = ({ setView, isLogin, setCurrentUser }) => {
  const { t } = useAppContext();
  const [role, setRole] = useState('bayi');
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);
  const [expiredNotice, setExpiredNotice] = useState(false);
  const [registeredEmail, setRegisteredEmail] = useState('');
  const [verifyStep, setVerifyStep] = useState<'form' | 'pending' | 'success' | 'error' | 'cancel-info'>('form');
  const [verifyMsg, setVerifyMsg] = useState('');
  const [noticeBox, setNoticeBox] = useState<{is_enabled:boolean;title:string;message:string;color:string}|null>(null);
  const [termsBox, setTermsBox] = useState<{is_enabled:boolean;content:string}|null>(null);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [resendLoading, setResendLoading] = useState(false);
  const [resendDone, setResendDone] = useState(false);
  const [verifySessionEnded, setVerifySessionEnded] = useState(false);
  // E-posta düzeltme (doğrulama bekleme ekranı)
  const [editEmailOpen, setEditEmailOpen] = useState(false);
  const [editEmailValue, setEditEmailValue] = useState('');
  const [editEmailPassword, setEditEmailPassword] = useState('');
  const [editEmailLoading, setEditEmailLoading] = useState(false);
  const [editEmailError, setEditEmailError] = useState('');
  const [editEmailDone, setEditEmailDone] = useState(false);
  // Şifre sıfırlama durumları
  const [forgotStep, setForgotStep] = useState<'hidden' | 'email-form' | 'sent' | 'reset-form' | 'reset-success' | 'reset-error'>('hidden');
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotMsg, setForgotMsg] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [resetLoading, setResetLoading] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [newPassword2, setNewPassword2] = useState('');

  useEffect(() => {
    try {
      if (sessionStorage.getItem('session_expired') === '1') {
        setExpiredNotice(true);
        sessionStorage.removeItem('session_expired');
      }
      const pendingEmail = sessionStorage.getItem('email_verification_pending');
      if (pendingEmail !== null) {
        sessionStorage.removeItem('email_verification_pending');
        setRegisteredEmail(pendingEmail);
        setVerifyStep('pending');
        if (sessionStorage.getItem('email_verification_session_ended') === '1') {
          sessionStorage.removeItem('email_verification_session_ended');
          setVerifySessionEnded(true);
        }
      }
    } catch {}
    // Kayıt sayfasında duyuru kutusunu ve şartları çek
    if (!isLogin) {
      api.get('/auth/register-notice').then(r => {
        if (r.data?.is_enabled) setNoticeBox(r.data);
      }).catch(() => {});
      api.get('/auth/terms').then(r => {
        setTermsBox({ is_enabled: !!r.data?.is_enabled, content: r.data?.content || '' });
      }).catch(() => {});
    }
    // URL'de ?action= varsa akışı belirle
    const params = new URLSearchParams(window.location.search);
    const token = params.get('token');
    const action = params.get('action');
    if (token && (action === 'verify' || action === 'confirm-email-change')) {
      setVerifyStep('pending');
      api.post(`/auth/verify-email?token=${encodeURIComponent(token)}`).then(r => {
        if (r.data?.access_token) {
          localStorage.setItem('access_token', r.data.access_token);
        }
        window.history.replaceState({}, '', window.location.pathname);
        if (r.data?.user && r.data?.access_token) {
          const user = r.data.user;
          setCurrentUser({
            id: user.id,
            role: user.role === 'bayi_sahibi' ? 'bayi_sahibi' : 'calisan',
            name: user.full_name,
            email: user.email,
            permissions: Array.isArray(user.permissions) ? user.permissions : [],
            parent_user_id: user.parent_user_id ?? null,
            myRefCode: user.ref_code,
            subDays: user.sub_days,
            isSuperAdmin: !!user.is_super_admin,
          });
          setView(user.is_super_admin ? 'superAdmin' : 'customerDashboard');
        } else {
          setVerifyStep('success');
          setVerifyMsg(r.data?.message || (action === 'confirm-email-change' ? 'E-posta adresiniz başarıyla güncellendi.' : 'E-posta başarıyla doğrulandı.'));
        }
      }).catch(err => {
        setVerifyStep('error');
        setVerifyMsg(apiErr(err, 'Doğrulama başarısız oldu.'));
        window.history.replaceState({}, '', window.location.pathname);
      });
    } else if (token && action === 'reset-password') {
      // Şifre sıfırlama linki
      setResetToken(token);
      setForgotStep('reset-form');
      window.history.replaceState({}, '', window.location.pathname);
    } else if (action === 'cancel-email-change') {
      // Eski adrese gönderilen güvenlik uyarı mailindeki "Talebi İptal Et" linki
      setVerifyStep('cancel-info');
      setVerifyMsg('Hesabınız için bir e-posta değiştirme talebi yapıldı. Bu talebi siz yapmadıysanız, lütfen mevcut e-posta adresinizle giriş yapın ve doğrulama ekranındaki "Talebi İptal Et" butonunu kullanarak değişikliği iptal edin. Ardından şifrenizi de değiştirmenizi öneririz. Hesabınıza erişemiyorsanız destek ekibimizle iletişime geçin.');
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, [isLogin]);

  const handleLogin = async (e) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);
    const formData = new FormData(e.target);
    const email = formData.get('email')?.toString().trim();
    const password = formData.get('password')?.toString().trim();
    const company_name = formData.get('company')?.toString().trim();
    const full_name = formData.get('fullname')?.toString().trim();
    const ref_code = formData.get('refCode')?.toString().trim().toUpperCase();

    try {
      if (isLogin) {
        const response = await api.post('/auth/login', { email, password });
        localStorage.setItem('access_token', response.data.access_token);
        if (response.data.refresh_token) localStorage.setItem('refresh_token', response.data.refresh_token);
        const user = response.data.user;
        setCurrentUser({
          id: user.id,
          role: user.role === 'bayi_sahibi' ? 'bayi_sahibi' : 'calisan',
          name: user.full_name,
          email: user.email,
          permissions: Array.isArray(user.permissions) ? user.permissions : [],
          parent_user_id: user.parent_user_id ?? null,
          myRefCode: user.ref_code,
          subDays: user.sub_days,
          isSuperAdmin: !!user.is_super_admin,
        });
        setView(user.is_super_admin ? 'superAdmin' : 'customerDashboard');
      } else {
        const response = await api.post('/auth/register', {
          email,
          password,
          full_name: role === 'bayi' ? (company_name || 'Bayi Yöneticisi') : full_name,
          company_name: role === 'bayi' ? company_name : null,
          role: role === 'bayi' ? 'bayi_sahibi' : 'calisan',
          ref_code: ref_code || null
        });

        if (response.data.email_verification_required) {
          // Token'ı sakla — JWT korumalı resend-verification endpoint'i kullanabilmek için
          localStorage.setItem('access_token', response.data.access_token);
          setRegisteredEmail(email || '');
          setVerifyStep('pending');
          return;
        }

        localStorage.setItem('access_token', response.data.access_token);
        if (response.data.refresh_token) localStorage.setItem('refresh_token', response.data.refresh_token);
        const user = response.data.user;
        setCurrentUser({
          id: user.id,
          role: user.role === 'bayi_sahibi' ? 'bayi_sahibi' : 'calisan',
          name: user.full_name,
          email: user.email,
          permissions: Array.isArray(user.permissions) ? user.permissions : [],
          parent_user_id: user.parent_user_id ?? null,
          myRefCode: user.ref_code,
          subDays: user.sub_days,
          isSuperAdmin: !!user.is_super_admin,
        });
        setView(user.is_super_admin ? 'superAdmin' : 'customerDashboard');
      }
    } catch (error) {
      const resp = error.response?.data;
      const detail = resp?.detail;
      if (error.response?.status === 403 && detail && typeof detail === 'object' && detail.code === 'email_not_verified') {
        setRegisteredEmail(detail.email || email || '');
        setVerifyStep('pending');
      } else if (typeof detail === 'string' && detail) {
        setErrorMsg(detail);
      } else if (detail?.message) {
        setErrorMsg(detail.message);
      } else {
        setErrorMsg(t('Sunucuya bağlanılamadı. Lütfen daha sonra tekrar deneyin.'));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    setResendLoading(true);
    setResendDone(false);
    try {
      await api.post('/auth/resend-verification-public', { email: registeredEmail });
      setResendDone(true);
    } catch {}
    setResendLoading(false);
  };

  const openEditEmail = () => {
    setEditEmailOpen(true);
    setEditEmailValue('');
    setEditEmailPassword('');
    setEditEmailError('');
    setEditEmailDone(false);
    setResendDone(false);
  };

  const closeEditEmail = () => {
    setEditEmailOpen(false);
    setEditEmailError('');
    setEditEmailLoading(false);
  };

  const handleUpdateUnverifiedEmail = async (e) => {
    e.preventDefault();
    setEditEmailError('');
    const currentEmail = (registeredEmail || '').trim().toLowerCase();
    if (!currentEmail) {
      setEditEmailError('Mevcut e-posta adresiniz tespit edilemedi. Lütfen tekrar giriş yapmayı deneyin.');
      return;
    }
    const newEmail = editEmailValue.trim().toLowerCase();
    if (!newEmail || !editEmailPassword) {
      setEditEmailError('E-posta ve şifre alanları zorunludur.');
      return;
    }
    if (newEmail === currentEmail) {
      setEditEmailError('Yeni e-posta mevcut adresinizle aynı.');
      return;
    }
    setEditEmailLoading(true);
    try {
      const res = await api.post('/auth/update-unverified-email', {
        current_email: registeredEmail,
        password: editEmailPassword,
        new_email: newEmail,
      });
      const updated = res.data?.new_email || newEmail;
      setRegisteredEmail(updated);
      setEditEmailOpen(false);
      setEditEmailDone(true);
      setEditEmailValue('');
      setEditEmailPassword('');
    } catch (err: any) {
      setEditEmailError(apiErr(err, 'E-posta güncellenemedi. Lütfen tekrar deneyin.'));
    } finally {
      setEditEmailLoading(false);
    }
  };

  const handleForgotSubmit = async (e) => {
    e.preventDefault();
    setResetLoading(true);
    setForgotMsg('');
    try {
      await api.post('/auth/forgot-password', { email: forgotEmail });
      setForgotStep('sent');
    } catch (err: any) {
      const detail = err.response?.data?.detail;
      setForgotMsg(typeof detail === 'string' ? detail : 'Bir hata oluştu, lütfen tekrar deneyin.');
    } finally {
      setResetLoading(false);
    }
  };

  const handleResetSubmit = async (e) => {
    e.preventDefault();
    setForgotMsg('');
    if (newPassword !== newPassword2) {
      setForgotMsg('Şifreler eşleşmiyor.');
      return;
    }
    if (newPassword.length < 6) {
      setForgotMsg('Şifre en az 6 karakter olmalıdır.');
      return;
    }
    setResetLoading(true);
    try {
      await api.post('/auth/reset-password', { token: resetToken, new_password: newPassword });
      setForgotStep('reset-success');
    } catch (err: any) {
      const detail = err.response?.data?.detail;
      setForgotMsg(typeof detail === 'string' ? detail : 'Şifre sıfırlama başarısız oldu.');
      setForgotStep('reset-error');
    } finally {
      setResetLoading(false);
    }
  };

  // ── E-POSTA DOĞRULAMA EKRANLARI ──────────────────────────────
  if (verifyStep === 'pending') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 p-8 text-center">
          <div className="flex justify-center mb-4 text-sky-500"><Mail size={52} /></div>
          <h2 className="text-2xl font-black text-slate-800 dark:text-white mb-2">E-postanızı Doğrulayın</h2>
          {verifySessionEnded && (
            <div className="mb-4 p-3 rounded-xl bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 text-amber-800 dark:text-amber-300 text-sm font-semibold">
              Oturumunuz, e-posta adresiniz henüz doğrulanmadığı için sonlandırıldı.
            </div>
          )}
          <p className="text-slate-500 dark:text-slate-400 text-sm mb-4">
            <span className="font-bold text-slate-700 dark:text-slate-200">{registeredEmail}</span> adresine bir doğrulama bağlantısı gönderdik. Gelen kutunuzu kontrol edin (spam klasörünü de).
          </p>
          {resendDone && (
            <div className="mb-3 p-3 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700 text-green-700 dark:text-green-300 text-sm font-semibold">Doğrulama e-postası tekrar gönderildi.</div>
          )}
          {editEmailDone && (
            <div className="mb-3 p-3 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700 text-green-700 dark:text-green-300 text-sm font-semibold">E-posta adresiniz güncellendi. Yeni adrese doğrulama bağlantısı gönderildi.</div>
          )}
          {!editEmailOpen ? (
            <>
              <button onClick={handleResend} disabled={resendLoading} className="text-indigo-600 dark:text-indigo-400 text-sm font-bold hover:underline disabled:opacity-50">
                {resendLoading ? 'Gönderiliyor...' : 'Tekrar gönder'}
              </button>
              <div className="mt-3">
                <button onClick={openEditEmail} className="text-indigo-600 dark:text-indigo-400 text-sm font-bold hover:underline">
                  E-posta adresini düzelt
                </button>
              </div>
              <div className="mt-6">
                <button onClick={() => setView('login')} className="text-slate-400 dark:text-slate-500 text-sm hover:underline">Giriş sayfasına dön</button>
              </div>
            </>
          ) : (
            <form onSubmit={handleUpdateUnverifiedEmail} className="mt-2 text-left space-y-3">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                E-postanızı yanlış mı yazdınız? Yeni adresinizi ve hesap şifrenizi girin; doğrulama bağlantısı yeni adrese gönderilecek.
              </p>
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Yeni e-posta</label>
                <input
                  type="email"
                  value={editEmailValue}
                  onChange={(e) => setEditEmailValue(e.target.value)}
                  required
                  autoFocus
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="dogru-adres@ornek.com"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Hesap şifresi</label>
                <input
                  type="password"
                  value={editEmailPassword}
                  onChange={(e) => setEditEmailPassword(e.target.value)}
                  required
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="••••••"
                />
              </div>
              {editEmailError && (
                <div className="p-2 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 text-red-700 dark:text-red-300 text-xs font-semibold">
                  {editEmailError}
                </div>
              )}
              <div className="flex gap-2">
                <button
                  type="submit"
                  disabled={editEmailLoading}
                  className="flex-1 bg-indigo-600 text-white font-bold py-2 rounded-xl hover:bg-indigo-700 transition disabled:opacity-50 text-sm"
                >
                  {editEmailLoading ? 'Güncelleniyor...' : 'Güncelle ve gönder'}
                </button>
                <button
                  type="button"
                  onClick={closeEditEmail}
                  disabled={editEmailLoading}
                  className="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold py-2 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition disabled:opacity-50 text-sm"
                >
                  Vazgeç
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    );
  }

  if (verifyStep === 'success') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 p-8 text-center">
          <div className="flex justify-center mb-4 text-green-500"><CheckCircle size={52} /></div>
          <h2 className="text-2xl font-black text-slate-800 dark:text-white mb-2">E-posta Doğrulandı!</h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">{verifyMsg}</p>
          <button onClick={() => { setVerifyStep('form'); setView('login'); }} className="w-full bg-indigo-600 text-white font-bold py-3 rounded-xl hover:bg-indigo-700 transition">
            Giriş Yap
          </button>
        </div>
      </div>
    );
  }

  if (verifyStep === 'error') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 p-8 text-center">
          <div className="flex justify-center mb-4 text-red-500"><ShieldBan size={52} /></div>
          <h2 className="text-2xl font-black text-slate-800 dark:text-white mb-2">Doğrulama Başarısız</h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">{verifyMsg}</p>
          <button onClick={() => { setVerifyStep('form'); setView('login'); }} className="w-full bg-indigo-600 text-white font-bold py-3 rounded-xl hover:bg-indigo-700 transition">
            Giriş Sayfasına Dön
          </button>
        </div>
      </div>
    );
  }

  if (verifyStep === 'cancel-info') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 p-8 text-center">
          <div className="flex justify-center mb-4 text-red-500"><ShieldBan size={52} /></div>
          <h2 className="text-2xl font-black text-slate-800 dark:text-white mb-2">E-posta Değişikliği Talebini İptal Et</h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm mb-6 text-left">{verifyMsg}</p>
          <button onClick={() => { setVerifyStep('form'); setView('login'); }} className="w-full bg-indigo-600 text-white font-bold py-3 rounded-xl hover:bg-indigo-700 transition">
            Giriş Yap
          </button>
        </div>
      </div>
    );
  }

  // ── ŞİFRE SIFIRLAMA EKRANLARI ────────────────────────────────
  if (forgotStep === 'email-form') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 p-8">
          <div className="flex justify-center mb-4 text-indigo-500"><Mail size={48} /></div>
          <h2 className="text-2xl font-black text-center text-slate-800 dark:text-white mb-2">Şifremi Unuttum</h2>
          <p className="text-center text-slate-500 dark:text-slate-400 text-sm mb-6">
            Kayıtlı e-posta adresinizi girin, şifre sıfırlama bağlantısı gönderelim.
          </p>
          {forgotMsg && (
            <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800/50 text-red-600 dark:text-red-400 text-sm font-bold rounded-xl">{forgotMsg}</div>
          )}
          <form onSubmit={handleForgotSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">E-posta Adresi</label>
              <input
                type="email" required
                value={forgotEmail} onChange={e => setForgotEmail(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-indigo-600 outline-none transition"
                placeholder="ornek@mail.com"
              />
            </div>
            <button type="submit" disabled={resetLoading} className="w-full bg-indigo-600 text-white font-bold py-3.5 rounded-xl hover:bg-indigo-700 transition shadow-lg disabled:opacity-50">
              {resetLoading ? 'Gönderiliyor...' : 'Sıfırlama Bağlantısı Gönder'}
            </button>
          </form>
          <div className="mt-5 text-center">
            <button onClick={() => setForgotStep('hidden')} className="text-slate-400 dark:text-slate-500 text-sm hover:underline">Giriş sayfasına dön</button>
          </div>
        </div>
      </div>
    );
  }

  if (forgotStep === 'sent') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 p-8 text-center">
          <div className="flex justify-center mb-4 text-sky-500"><Mail size={52} /></div>
          <h2 className="text-2xl font-black text-slate-800 dark:text-white mb-2">Bağlantı Gönderildi</h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">
            <span className="font-bold text-slate-700 dark:text-slate-200">{forgotEmail}</span> adresine şifre sıfırlama bağlantısı gönderdik. Gelen kutunuzu ve spam klasörünü kontrol edin.
          </p>
          <p className="text-slate-400 dark:text-slate-500 text-xs mb-6">Bağlantı 1 saat geçerlidir.</p>
          <button onClick={() => { setForgotStep('hidden'); setView('login'); }} className="w-full bg-indigo-600 text-white font-bold py-3 rounded-xl hover:bg-indigo-700 transition">
            Giriş Sayfasına Dön
          </button>
        </div>
      </div>
    );
  }

  if (forgotStep === 'reset-form') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 p-8">
          <div className="flex justify-center mb-4 text-indigo-500"><KeyRound size={48} /></div>
          <h2 className="text-2xl font-black text-center text-slate-800 dark:text-white mb-2">Yeni Şifre Belirle</h2>
          <p className="text-center text-slate-500 dark:text-slate-400 text-sm mb-6">En az 6 karakter içeren yeni şifrenizi girin.</p>
          {forgotMsg && (
            <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800/50 text-red-600 dark:text-red-400 text-sm font-bold rounded-xl">{forgotMsg}</div>
          )}
          <form onSubmit={handleResetSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Yeni Şifre</label>
              <input
                type="password" required minLength={6}
                value={newPassword} onChange={e => setNewPassword(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-indigo-600 outline-none transition"
                placeholder="••••••••"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">Yeni Şifre (Tekrar)</label>
              <input
                type="password" required minLength={6}
                value={newPassword2} onChange={e => setNewPassword2(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-indigo-600 outline-none transition"
                placeholder="••••••••"
              />
            </div>
            <button type="submit" disabled={resetLoading} className="w-full bg-indigo-600 text-white font-bold py-3.5 rounded-xl hover:bg-indigo-700 transition shadow-lg disabled:opacity-50">
              {resetLoading ? 'Kaydediliyor...' : 'Şifremi Güncelle'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  if (forgotStep === 'reset-success') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 p-8 text-center">
          <div className="flex justify-center mb-4 text-green-500"><CheckCircle size={52} /></div>
          <h2 className="text-2xl font-black text-slate-800 dark:text-white mb-2">Şifreniz Güncellendi!</h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">Yeni şifrenizle giriş yapabilirsiniz.</p>
          <button onClick={() => { setForgotStep('hidden'); setView('login'); }} className="w-full bg-indigo-600 text-white font-bold py-3 rounded-xl hover:bg-indigo-700 transition">
            Giriş Yap
          </button>
        </div>
      </div>
    );
  }

  if (forgotStep === 'reset-error') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 p-8 text-center">
          <div className="flex justify-center mb-4 text-red-500"><ShieldBan size={52} /></div>
          <h2 className="text-2xl font-black text-slate-800 dark:text-white mb-2">Sıfırlama Başarısız</h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">{forgotMsg}</p>
          <button onClick={() => { setForgotStep('email-form'); setForgotMsg(''); }} className="w-full bg-indigo-600 text-white font-bold py-3 rounded-xl hover:bg-indigo-700 transition mb-3">
            Yeniden Dene
          </button>
          <button onClick={() => { setForgotStep('hidden'); setView('login'); }} className="text-slate-400 dark:text-slate-500 text-sm hover:underline">
            Giriş sayfasına dön
          </button>
        </div>
      </div>
    );
  }

  // ── ANA AUTH FORMU ────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center p-4 relative transition-colors duration-300">
      <div className="absolute top-4 right-4 sm:top-8 sm:right-8 z-50">
         <SettingsToggle />
      </div>

      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 p-8 animate-in zoom-in-95 duration-300 mt-12 sm:mt-0">
        <div className="flex justify-center mb-6"><img src="/logo.png" alt="StokFinans" className="w-16 h-16 object-contain drop-shadow-md" /></div>
        <h2 className="text-3xl font-black text-center text-slate-800 dark:text-white mb-2">{isLogin ? t('Tekrar Hoş Geldiniz') : t('Aramıza Katılın')}</h2>
        <p className="text-center text-slate-500 dark:text-slate-400 mb-6 text-sm">{isLogin ? t('Yönetim paneline erişmek için giriş yapın.') : t('Ücretsiz hesabınızı saniyeler içinde oluşturun.')}</p>

        {expiredNotice && (
          <div className="mb-5 p-3.5 rounded-xl bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800/60 text-amber-800 dark:text-amber-300 text-sm font-semibold flex items-start gap-2">
            <span className="mt-0.5">⚠️</span>
            <span>Oturum süreniz doldu. Lütfen tekrar giriş yapın.</span>
          </div>
        )}

        {!isLogin && noticeBox && (
          <div className={`mb-5 p-3.5 rounded-xl border text-sm ${noticeColorMap[noticeBox.color] ?? noticeColorMap.indigo}`}>
            {noticeBox.title && <p className="font-bold mb-0.5">{noticeBox.title}</p>}
            <p style={{whiteSpace:'pre-line'}}>{noticeBox.message}</p>
          </div>
        )}

        {!isLogin && (
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1.5 rounded-xl mb-6">
            <button type="button" onClick={() => setRole('bayi')} className={`flex-1 py-2.5 text-sm font-bold rounded-lg transition-all ${role === 'bayi' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}>{t('Bayi (Kurucu)')}</button>
            <button type="button" onClick={() => setRole('calisan')} className={`flex-1 py-2.5 text-sm font-bold rounded-lg transition-all ${role === 'calisan' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-300 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}>{t('Çalışan')}</button>
          </div>
        )}

        {errorMsg && (
           <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800/50 text-red-600 dark:text-red-400 text-sm font-bold rounded-xl flex items-start gap-2">
             <ShieldBan size={18} className="shrink-0 mt-0.5" />
             <span>{errorMsg}</span>
           </div>
        )}

        <form className="space-y-4" onSubmit={handleLogin}>
          {!isLogin && role === 'bayi' && (
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">{t('İşletme Adı')}</label>
              <input type="text" name="company" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-indigo-600 outline-none transition" placeholder="Örn: Etiket Oto Aksesuar" required />
            </div>
          )}
          {!isLogin && role === 'calisan' && (
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">{t('Ad Soyad')}</label>
              <input type="text" name="fullname" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-indigo-600 outline-none transition" placeholder="Adınız Soyadınız" required />
            </div>
          )}
          <div>
            <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">{t('E-posta Adresi')}</label>
            <input type="email" name="email" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-indigo-600 outline-none transition" placeholder="ornek@mail.com" required />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300">{t('Şifre')}</label>
              {isLogin && (
                <button type="button" onClick={() => setForgotStep('email-form')} className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold hover:underline">
                  Şifremi Unuttum
                </button>
              )}
            </div>
            <input type="password" name="password" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-indigo-600 outline-none transition" placeholder="••••••••" required minLength="6" />
          </div>
          
          {!isLogin && role === 'bayi' && (
             <div className="pt-2">
               <label className="block text-sm font-bold text-indigo-700 dark:text-indigo-400 mb-1 flex items-center gap-1"><Gift size={16}/> {t('Referans Kodu (Opsiyonel)')}</label>
               <input type="text" name="refCode" className="w-full px-4 py-3 bg-indigo-50/50 dark:bg-indigo-900/20 text-slate-800 dark:text-slate-100 rounded-xl border border-indigo-100 dark:border-indigo-800 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-indigo-600 outline-none transition font-bold uppercase" placeholder="KOD GİRİN, +10 GÜN KAZANIN!" />
             </div>
          )}

          {!isLogin && termsBox?.is_enabled && (
            <div className="flex items-start gap-3 pt-1">
              <button
                type="button"
                onClick={() => setTermsAccepted(v => !v)}
                className={`mt-0.5 w-5 h-5 rounded border-2 flex-shrink-0 flex items-center justify-center transition-colors ${termsAccepted ? 'bg-indigo-600 border-indigo-600' : 'border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800'}`}
                aria-checked={termsAccepted}
                role="checkbox"
              >
                {termsAccepted && (
                  <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 12 12" stroke="currentColor" strokeWidth={2.5}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M2 6l3 3 5-5" />
                  </svg>
                )}
              </button>
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-snug">
                <button
                  type="button"
                  onClick={() => setShowTermsModal(true)}
                  className="text-indigo-600 dark:text-indigo-400 font-semibold hover:underline"
                >
                  Kullanım Şartları ve Gizlilik Politikası
                </button>
                'nı okudum, onaylıyorum.
              </p>
            </div>
          )}

          <button
            type="submit"
            disabled={loading || (!isLogin && termsBox?.is_enabled === true && !termsAccepted)}
            className="w-full bg-indigo-600 text-white font-bold py-3.5 rounded-xl hover:bg-indigo-700 transition shadow-lg shadow-indigo-200 dark:shadow-indigo-900/20 mt-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? t('İşleniyor...') : isLogin ? t('Sisteme Giriş Yap') : t('Hesabımı Oluştur')}
          </button>
        </form>

        {showTermsModal && termsBox && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => setShowTermsModal(false)}>
            <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-lg w-full max-h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-700">
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-base">Kullanım Şartları ve Gizlilik Politikası</h3>
                <button onClick={() => setShowTermsModal(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
                </button>
              </div>
              <div className="px-6 py-4 overflow-y-auto flex-1 text-sm text-slate-600 dark:text-slate-300 whitespace-pre-wrap leading-relaxed">
                {termsBox.content || 'İçerik bulunamadı.'}
              </div>
              <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-700 flex justify-end gap-3">
                <button onClick={() => { setTermsAccepted(true); setShowTermsModal(false); }} className="px-5 py-2 bg-indigo-600 text-white text-sm font-bold rounded-xl hover:bg-indigo-700 transition">
                  Okudum, Onaylıyorum
                </button>
                <button onClick={() => setShowTermsModal(false)} className="px-4 py-2 text-sm text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition">
                  Kapat
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="mt-6 text-center text-slate-500 dark:text-slate-400 text-sm font-medium">
          {isLogin ? t('Hesabınız yok mu?') : t('Zaten hesabınız var mı?')} 
          <button onClick={() => setView(isLogin ? 'register' : 'login')} className="text-indigo-600 dark:text-indigo-400 font-bold ml-1 hover:underline">{isLogin ? t('Kayıt Ol') : t('Giriş Yap')}</button>
        </div>
      </div>
    </div>
  );
};

// 3. ÖZEL MODÜLLER 

// Bekleyen e-posta doğrulama bağlantısı için kalan süreyi insan dostu formatta döner.
// Örn: "7 saat 12 dakika", "23 dakika", "30 saniye". Süre dolmuşsa null döner.
const formatPendingEmailRemaining = (expiresAtIso: string | null | undefined): string | null => {
  if (!expiresAtIso) return null;
  const expiresAt = new Date(expiresAtIso).getTime();
  if (Number.isNaN(expiresAt)) return null;
  const diffMs = expiresAt - Date.now();
  if (diffMs <= 0) return null;
  const totalSeconds = Math.floor(diffMs / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  if (days > 0) {
    return hours > 0 ? `${days} gün ${hours} saat` : `${days} gün`;
  }
  if (hours > 0) {
    return minutes > 0 ? `${hours} saat ${minutes} dakika` : `${hours} saat`;
  }
  if (minutes > 0) {
    return `${minutes} dakika`;
  }
  return `${totalSeconds} saniye`;
};

// 3.1 İşletme Profili ve Ayarlar
const ProfileSettingsView = () => {
  const { t, showToast } = useAppContext();
  const logout = () => {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    try { sessionStorage.removeItem('lastView'); } catch {}
    window.location.href = '/';
  };
  const [fullName, setFullName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [companyAddress, setCompanyAddress] = useState('');
  const [companyPhone, setCompanyPhone] = useState('');
  const [email, setEmail] = useState('');
  const [saving, setSaving] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [isEmailVerified, setIsEmailVerified] = useState<boolean | null>(null);
  const [resending, setResending] = useState(false);
  const [pendingEmail, setPendingEmail] = useState<string | null>(null);

  // Şifre değiştirme
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newPassword2, setNewPassword2] = useState('');
  const [changingPassword, setChangingPassword] = useState(false);

  // Tehlike bölgesi modal state'leri
  const [dangerModal, setDangerModal] = useState<'reset' | 'delete' | null>(null);
  const [dangerPassword, setDangerPassword] = useState('');
  const [dangerConfirmText, setDangerConfirmText] = useState('');
  const [dangerBusy, setDangerBusy] = useState(false);
  const [pendingEmailExpiresAt, setPendingEmailExpiresAt] = useState<string | null>(null);
  const [showChangeEmailForm, setShowChangeEmailForm] = useState(false);
  const [newEmail, setNewEmail] = useState('');
  const [changeEmailPassword, setChangeEmailPassword] = useState('');
  const [changingEmail, setChangingEmail] = useState(false);
  const [cancelingEmailChange, setCancelingEmailChange] = useState(false);
  const [isEmployee, setIsEmployee] = useState(false);

  useEffect(() => {
    api.get('/auth/profile').then(res => {
      setFullName(res.data.full_name || '');
      setCompanyName(res.data.company_name || '');
      setCompanyAddress(res.data.company_address || '');
      setCompanyPhone(res.data.company_phone || '');
      setEmail(res.data.email || '');
      setIsEmailVerified(res.data.is_email_verified ?? null);
      setPendingEmail(res.data.pending_email || null);
      setPendingEmailExpiresAt(res.data.pending_email_expires_at || null);
      setIsEmployee(!!res.data.parent_user_id);
      setLoaded(true);
    }).catch(() => setLoaded(true));
  }, []);

  const handleResendVerification = async () => {
    try {
      setResending(true);
      await api.post('/auth/resend-verification');
      showToast('Doğrulama e-postası gönderildi');
    } catch (err: any) {
      showToast(err.response?.data?.detail || 'E-posta gönderilemedi', 'error');
    } finally {
      setResending(false);
    }
  };

  const handleCancelEmailChange = async () => {
    if (!window.confirm('Bekleyen e-posta değiştirme isteğini iptal etmek istediğinize emin misiniz?')) return;
    try {
      setCancelingEmailChange(true);
      const res = await api.delete('/auth/change-email');
      setPendingEmail(null);
      setPendingEmailExpiresAt(null);
      showToast(res.data?.message || 'E-posta değiştirme isteği iptal edildi');
    } catch (err: any) {
      showToast(err.response?.data?.detail || 'İptal işlemi başarısız oldu', 'error');
    } finally {
      setCancelingEmailChange(false);
    }
  };

  const handleChangeEmail = async () => {
    if (!newEmail.trim()) { showToast('Yeni e-posta adresi boş olamaz', 'error'); return; }
    if (!changeEmailPassword) { showToast('Mevcut şifrenizi girin', 'error'); return; }
    try {
      setChangingEmail(true);
      const res = await api.post('/auth/change-email', {
        new_email: newEmail.trim(),
        password: changeEmailPassword,
      });
      setPendingEmail(res.data.pending_email || newEmail.trim());
      setPendingEmailExpiresAt(res.data.pending_email_expires_at || null);
      setShowChangeEmailForm(false);
      setNewEmail('');
      setChangeEmailPassword('');
      showToast(res.data.message || 'Doğrulama e-postası gönderildi');
    } catch (err: any) {
      showToast(err.response?.data?.detail || 'E-posta değiştirilemedi', 'error');
    } finally {
      setChangingEmail(false);
    }
  };

  const handleSave = async () => {
    if (!fullName.trim()) { showToast('Ad Soyad boş olamaz', 'error'); return; }
    if (companyAddress.length > 500) { showToast('Adres en fazla 500 karakter olabilir', 'error'); return; }
    if (companyPhone.length > 50) { showToast('Telefon en fazla 50 karakter olabilir', 'error'); return; }
    try {
      setSaving(true);
      await api.put('/auth/profile', {
        full_name: fullName.trim(),
        company_name: companyName.trim() || null,
        company_address: companyAddress.trim(),
        company_phone: companyPhone.trim(),
      });
      showToast('Profil güncellendi');
    } catch (err: any) {
      showToast(err.response?.data?.detail || 'Güncelleme sırasında hata oluştu', 'error');
    } finally {
      setSaving(false);
    }
  };

  const closeDangerModal = () => {
    setDangerModal(null);
    setDangerPassword('');
    setDangerConfirmText('');
  };

  const handleResetAccount = async () => {
    if (dangerConfirmText !== 'SIFIRLA') { showToast('Onay metni hatalı', 'error'); return; }
    if (!dangerPassword) { showToast('Şifrenizi girin', 'error'); return; }
    try {
      setDangerBusy(true);
      await api.post('/auth/account/reset', { password: dangerPassword });
      closeDangerModal();
      showToast('Hesap içeriğiniz sıfırlandı. Tüm veriler temizlendi.', 'success');
    } catch (err: any) {
      showToast(err.response?.data?.detail || 'Sıfırlama başarısız', 'error');
    } finally {
      setDangerBusy(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (dangerConfirmText !== 'SİL') { showToast('Onay metni hatalı', 'error'); return; }
    if (!dangerPassword) { showToast('Şifrenizi girin', 'error'); return; }
    try {
      setDangerBusy(true);
      await api.delete('/auth/account', { data: { password: dangerPassword } });
      closeDangerModal();
      showToast('Hesabınız silindi. Çıkış yapılıyor...', 'success');
      setTimeout(() => logout(), 1500);
    } catch (err: any) {
      showToast(err.response?.data?.detail || 'Silme başarısız', 'error');
    } finally {
      setDangerBusy(false);
    }
  };

  const handleChangePassword = async () => {
    if (!currentPassword) { showToast('Mevcut şifrenizi girin', 'error'); return; }
    if (newPassword.length < 8) { showToast('Yeni şifre en az 8 karakter olmalı', 'error'); return; }
    if (newPassword !== newPassword2) { showToast('Yeni şifreler eşleşmiyor', 'error'); return; }
    try {
      setChangingPassword(true);
      await api.post('/auth/change-password', {
        current_password: currentPassword,
        new_password: newPassword,
      });
      setCurrentPassword('');
      setNewPassword('');
      setNewPassword2('');
      showToast('Şifreniz güncellendi', 'success');
    } catch (err: any) {
      showToast(err.response?.data?.detail || 'Şifre değiştirilemedi', 'error');
    } finally {
      setChangingPassword(false);
    }
  };

  const FIELD = 'w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 outline-none focus:ring-2 focus:ring-indigo-500 transition text-sm';
  const DANGER_INP = 'w-full px-3 py-2.5 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 rounded-lg border border-slate-300 dark:border-slate-600 outline-none focus:ring-2 focus:ring-red-500 transition text-sm';

  return (
    <div className="max-w-2xl space-y-6 animate-in slide-in-from-bottom-4 duration-300">

      {/* ── Tehlike Bölgesi Modal ── */}
      {dangerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-red-200 dark:border-red-900 w-full max-w-md">
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-100 dark:bg-red-900/40 flex items-center justify-center shrink-0">
                {dangerModal === 'reset'
                  ? <RefreshCw size={18} className="text-red-600 dark:text-red-400" />
                  : <Trash2 size={18} className="text-red-600 dark:text-red-400" />}
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-white text-base">
                  {dangerModal === 'reset' ? 'Hesabı Sıfırla' : 'Hesabı Komple Sil'}
                </h3>
                <p className="text-xs text-red-600 dark:text-red-400 font-semibold">Bu işlem geri alınamaz</p>
              </div>
            </div>
            <div className="p-6 space-y-4">
              {dangerModal === 'reset' ? (
                <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl p-4 text-sm text-amber-800 dark:text-amber-300 space-y-1">
                  <p className="font-bold">Silinecekler:</p>
                  <ul className="list-disc list-inside space-y-0.5 text-xs">
                    <li>Tüm ürünler ve stok bilgileri</li>
                    <li>Tüm satış / borç / alacak işlemleri</li>
                    <li>Tüm garanti kayıtları</li>
                    <li>Kategoriler ve yedekler</li>
                    <li>Eşleşmiş cihazlar (cihaz kaydı korunur, eşleşme kaldırılır)</li>
                  </ul>
                  <p className="font-bold mt-2">Korunacaklar:</p>
                  <ul className="list-disc list-inside space-y-0.5 text-xs">
                    <li>Hesabınız ve giriş bilgileriniz</li>
                    <li>Personel hesapları</li>
                    <li>Abonelik bilgileriniz</li>
                  </ul>
                </div>
              ) : (
                <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-xl p-4 text-sm text-red-800 dark:text-red-300 space-y-1">
                  <p className="font-bold">Kalıcı olarak silinecekler:</p>
                  <ul className="list-disc list-inside space-y-0.5 text-xs">
                    <li>Tüm ürünler, işlemler, garantiler, kategoriler</li>
                    {!isEmployee && <li>Tüm personel hesapları</li>}
                    <li>Hesabınızın kendisi (e-posta, şifre, abonelik)</li>
                  </ul>
                  {!isEmployee && (
                    <p className="text-xs font-bold mt-2 text-red-700 dark:text-red-400">
                      ⚠ Diğer bayilerin verileri etkilenmez.
                    </p>
                  )}
                </div>
              )}
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1.5">
                  Onaylamak için{' '}
                  <code className="bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded font-mono text-red-600 dark:text-red-400">
                    {dangerModal === 'reset' ? 'SIFIRLA' : 'SİL'}
                  </code>{' '}
                  yazın
                </label>
                <input value={dangerConfirmText} onChange={e => setDangerConfirmText(e.target.value)}
                  placeholder={dangerModal === 'reset' ? 'SIFIRLA' : 'SİL'}
                  className={DANGER_INP} autoComplete="off" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1.5">Hesap şifreniz</label>
                <input type="password" value={dangerPassword} onChange={e => setDangerPassword(e.target.value)}
                  placeholder="••••••••" className={DANGER_INP}
                  onKeyDown={e => e.key === 'Enter' && (dangerModal === 'reset' ? handleResetAccount() : handleDeleteAccount())} />
              </div>
            </div>
            <div className="p-6 pt-0 flex gap-3">
              <button
                onClick={dangerModal === 'reset' ? handleResetAccount : handleDeleteAccount}
                disabled={dangerBusy || dangerConfirmText !== (dangerModal === 'reset' ? 'SIFIRLA' : 'SİL')}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-40 text-white font-bold rounded-xl text-sm transition flex items-center justify-center gap-2"
              >
                {dangerBusy
                  ? <><div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" /> İşleniyor...</>
                  : dangerModal === 'reset' ? <><RefreshCw size={14} /> Sıfırla</> : <><Trash2 size={14} /> Kalıcı Olarak Sil</>}
              </button>
              <button onClick={closeDangerModal} disabled={dangerBusy}
                className="px-5 py-2.5 text-sm font-semibold text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition disabled:opacity-40">
                İptal
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Sayfa Başlığı ── */}
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center shrink-0">
          <UserCircle size={26} />
        </div>
        <div>
          <h1 className="text-2xl font-black text-slate-800 dark:text-white">Hesabım</h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Hesap bilgilerinizi ve güvenlik ayarlarınızı yönetin.</p>
        </div>
      </div>

      {!loaded ? (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-10 text-center text-slate-400 animate-pulse">Yükleniyor...</div>
      ) : (
        <>
          {/* ── Bölüm 1: Profil Bilgileri ── */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
              <UserCircle size={17} className="text-indigo-500 shrink-0" />
              <h2 className="font-bold text-slate-800 dark:text-white text-sm">Profil Bilgileri</h2>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">Ad Soyad / Yetkili</label>
                  <input type="text" value={fullName} onChange={e => setFullName(e.target.value)} className={FIELD} />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">İşletme Adı</label>
                  <input type="text" value={companyName} onChange={e => setCompanyName(e.target.value)} className={FIELD} />
                </div>
                <div>
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">İşyeri Telefonu</label>
                  <input type="tel" value={companyPhone} onChange={e => setCompanyPhone(e.target.value)} maxLength={50}
                    placeholder="0212 555 00 00" className={FIELD} />
                </div>
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">İşyeri Adresi</label>
                <textarea value={companyAddress} onChange={e => setCompanyAddress(e.target.value)} maxLength={500} rows={3}
                  placeholder="Açık adres (mahalle, cadde, no, ilçe / il)"
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 rounded-xl border border-slate-200 dark:border-slate-700 outline-none focus:ring-2 focus:ring-indigo-500 transition resize-y text-sm" />
                <div className="text-right text-xs text-slate-400 mt-1">{companyAddress.length} / 500</div>
              </div>
              <div className="flex justify-end pt-2">
                <button onClick={handleSave} disabled={saving}
                  className="px-6 py-2.5 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition shadow-sm flex items-center gap-2 disabled:opacity-50 text-sm">
                  <Check size={16} /> {saving ? 'Kaydediliyor...' : 'Değişiklikleri Kaydet'}
                </button>
              </div>
            </div>
          </div>

          {/* ── Bölüm 2: Güvenlik ── */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
              <Shield size={17} className="text-indigo-500 shrink-0" />
              <h2 className="font-bold text-slate-800 dark:text-white text-sm">Güvenlik</h2>
            </div>
            <div className="p-6 space-y-6">

              {/* E-posta */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-bold text-slate-700 dark:text-slate-300">E-Posta</label>
                  {isEmailVerified === true && !pendingEmail && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400">
                      <CheckCircle size={12} /> Doğrulandı
                    </span>
                  )}
                  {isEmailVerified === false && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400">
                      <AlertTriangle size={12} /> Doğrulanmadı
                    </span>
                  )}
                </div>
                <input type="email" value={email} disabled
                  className="w-full px-4 py-3 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-500 rounded-xl border border-slate-200 dark:border-slate-700 outline-none cursor-not-allowed text-sm" />
                {isEmailVerified === false && !pendingEmail && (
                  <button onClick={handleResendVerification} disabled={resending}
                    className="mt-2 inline-flex items-center gap-2 text-sm font-semibold text-indigo-600 dark:text-indigo-400 hover:underline disabled:opacity-50 disabled:no-underline">
                    <Mail size={14} /> {resending ? 'Gönderiliyor...' : 'Doğrulama e-postasını yeniden gönder'}
                  </button>
                )}
                {pendingEmail && (() => {
                  const remaining = formatPendingEmailRemaining(pendingEmailExpiresAt);
                  const isExpired = remaining === null;
                  const containerClasses = isExpired
                    ? 'mt-2 p-3 bg-rose-50 dark:bg-rose-900/20 border border-rose-200 dark:border-rose-700 rounded-xl text-sm'
                    : 'mt-2 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 rounded-xl text-sm';
                  const textClasses = isExpired
                    ? 'flex items-start gap-2 text-rose-700 dark:text-rose-400'
                    : 'flex items-start gap-2 text-amber-700 dark:text-amber-400';
                  const cancelButtonClasses = isExpired
                    ? 'inline-flex items-center gap-1 text-xs font-bold text-rose-800 dark:text-rose-300 hover:text-rose-900 dark:hover:text-rose-200 underline disabled:opacity-50 disabled:no-underline'
                    : 'inline-flex items-center gap-1 text-xs font-bold text-amber-800 dark:text-amber-300 hover:text-amber-900 dark:hover:text-amber-200 underline disabled:opacity-50 disabled:no-underline';
                  return (
                    <div className={containerClasses}>
                      <div className={textClasses}>
                        <AlertTriangle size={14} className="shrink-0 mt-0.5" />
                        <div className="flex-1">
                          {isExpired ? (
                            <>
                              <span className="font-semibold">Doğrulama bağlantısının süresi doldu:</span>{' '}
                              <span className="font-mono">{pendingEmail}</span> adresine gönderdiğimiz bağlantı artık geçerli değil.
                              {!isEmployee && <> Lütfen bekleyen isteği iptal edip yeni bir doğrulama e-postası göndermek üzere tekrar deneyin.</>}
                            </>
                          ) : (
                            <>
                              <span className="font-semibold">Onay bekleniyor:</span>{' '}
                              <span className="font-mono">{pendingEmail}</span> adresine doğrulama e-postası gönderildi. Yeni adresiniz doğrulanana kadar mevcut adresiniz aktif kalır.
                              {remaining && (
                                <div className="mt-1 text-xs font-medium opacity-90">
                                  Doğrulama bağlantısının süresi <span className="font-bold">{remaining}</span> içinde dolacak.
                                </div>
                              )}
                            </>
                          )}
                          {!isEmployee && (
                            <div className="mt-2">
                              <button onClick={handleCancelEmailChange} disabled={cancelingEmailChange} className={cancelButtonClasses}>
                                {cancelingEmailChange ? 'İptal ediliyor...' : isExpired ? 'İsteği iptal et ve tekrar dene' : 'E-posta değiştirme isteğini iptal et'}
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })()}
                {!isEmployee && !showChangeEmailForm && (
                  <button onClick={() => { setShowChangeEmailForm(true); setNewEmail(''); setChangeEmailPassword(''); }}
                    className="mt-2 inline-flex items-center gap-2 text-sm font-semibold text-indigo-600 dark:text-indigo-400 hover:underline">
                    <Mail size={14} /> E-posta adresini değiştir
                  </button>
                )}
                {!isEmployee && showChangeEmailForm && (
                  <div className="mt-3 p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl space-y-3">
                    <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide">E-posta Değiştir</p>
                    <div>
                      <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1">Yeni E-posta Adresi</label>
                      <input type="email" value={newEmail} onChange={e => setNewEmail(e.target.value)} placeholder="yeni@email.com"
                        className="w-full px-3 py-2 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 rounded-lg border border-slate-200 dark:border-slate-700 outline-none focus:ring-2 focus:ring-indigo-500 transition text-sm" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1">Mevcut Şifreniz (Onay)</label>
                      <input type="password" value={changeEmailPassword} onChange={e => setChangeEmailPassword(e.target.value)} placeholder="••••••••"
                        className="w-full px-3 py-2 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 rounded-lg border border-slate-200 dark:border-slate-700 outline-none focus:ring-2 focus:ring-indigo-500 transition text-sm" />
                    </div>
                    <div className="flex gap-2">
                      <button onClick={handleChangeEmail} disabled={changingEmail}
                        className="px-4 py-2 bg-indigo-600 text-white text-sm font-bold rounded-lg hover:bg-indigo-700 transition disabled:opacity-50 flex items-center gap-1">
                        <Mail size={13} /> {changingEmail ? 'Gönderiliyor...' : 'Doğrulama Gönder'}
                      </button>
                      <button onClick={() => setShowChangeEmailForm(false)}
                        className="px-4 py-2 text-sm font-semibold text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition">
                        İptal
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Şifre Değiştir */}
              <div className="pt-5 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2 mb-4">
                  <KeyRound size={16} className="text-slate-500 dark:text-slate-400" />
                  <h3 className="font-bold text-slate-700 dark:text-slate-300 text-sm">Şifre Değiştir</h3>
                </div>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1.5">Mevcut Şifre</label>
                    <input type="password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)}
                      placeholder="••••••••" className={FIELD} />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1.5">Yeni Şifre</label>
                    <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)}
                      placeholder="En az 8 karakter" className={FIELD} />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1.5">Yeni Şifre Tekrar</label>
                    <input type="password" value={newPassword2} onChange={e => setNewPassword2(e.target.value)}
                      placeholder="••••••••" className={FIELD}
                      onKeyDown={e => e.key === 'Enter' && handleChangePassword()} />
                  </div>
                  <div className="flex justify-end pt-1">
                    <button onClick={handleChangePassword} disabled={changingPassword}
                      className="px-5 py-2.5 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition shadow-sm flex items-center gap-2 disabled:opacity-50 text-sm">
                      <KeyRound size={15} /> {changingPassword ? 'Güncelleniyor...' : 'Şifreyi Güncelle'}
                    </button>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* ── Bölüm 3: Tehlike Bölgesi ── */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-red-200 dark:border-red-900/60 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-red-100 dark:border-red-900/40 bg-red-50 dark:bg-red-950/20 flex items-center gap-3">
              <AlertCircle size={17} className="text-red-600 dark:text-red-400 shrink-0" />
              <div>
                <h3 className="font-bold text-red-700 dark:text-red-400 text-sm">Tehlike Bölgesi</h3>
                <p className="text-xs text-red-500 dark:text-red-500">Bu işlemler geri alınamaz. Dikkatli olun.</p>
              </div>
            </div>
            <div className="p-6 space-y-4">
              {!isEmployee && (
                <div className="flex items-start justify-between gap-4 p-4 rounded-xl border border-amber-200 dark:border-amber-800/50 bg-amber-50 dark:bg-amber-950/10">
                  <div>
                    <p className="font-bold text-slate-800 dark:text-white text-sm">Hesabı Sıfırla</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      Tüm ürünleri, işlemleri, garantileri ve verileri siler. Hesabınız ve personelleriniz korunur.
                    </p>
                  </div>
                  <button onClick={() => { setDangerModal('reset'); setDangerPassword(''); setDangerConfirmText(''); }}
                    className="shrink-0 px-4 py-2 bg-amber-100 hover:bg-amber-200 dark:bg-amber-900/40 dark:hover:bg-amber-900/60 text-amber-800 dark:text-amber-300 font-bold rounded-lg text-sm transition flex items-center gap-1.5">
                    <RefreshCw size={13} /> Sıfırla
                  </button>
                </div>
              )}
              <div className="flex items-start justify-between gap-4 p-4 rounded-xl border border-red-200 dark:border-red-800/50 bg-red-50 dark:bg-red-950/10">
                <div>
                  <p className="font-bold text-slate-800 dark:text-white text-sm">
                    {isEmployee ? 'Hesabımı Sil' : 'Hesabı Komple Sil'}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    {isEmployee
                      ? 'Kendi hesabınızı kalıcı olarak siler. Firmanın verileri etkilenmez.'
                      : 'Tüm verileri, personelleri ve hesabı kalıcı olarak siler. Geri alınamaz.'}
                  </p>
                </div>
                <button onClick={() => { setDangerModal('delete'); setDangerPassword(''); setDangerConfirmText(''); }}
                  className="shrink-0 px-4 py-2 bg-red-100 hover:bg-red-200 dark:bg-red-900/40 dark:hover:bg-red-900/60 text-red-700 dark:text-red-300 font-bold rounded-lg text-sm transition flex items-center gap-1.5">
                  <Trash2 size={13} /> {isEmployee ? 'Hesabı Sil' : 'Komple Sil'}
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

// 3.2 Gelişmiş Raporlar Görünümü
// Tıklanabilir metrik kartı: tıklanınca drill-down detay modalı açar.
const MetricCard = ({ title, total, count, icon: Icon, tone, onClick, hint }: any) => {
  const toneMap: Record<string, { bg: string; fg: string; ring: string }> = {
    emerald: { bg: 'bg-emerald-100 dark:bg-emerald-900/30', fg: 'text-emerald-600 dark:text-emerald-400', ring: 'hover:border-emerald-300 dark:hover:border-emerald-700' },
    red:     { bg: 'bg-red-100 dark:bg-red-900/30',         fg: 'text-red-600 dark:text-red-400',         ring: 'hover:border-red-300 dark:hover:border-red-700' },
    blue:    { bg: 'bg-blue-100 dark:bg-blue-900/30',       fg: 'text-blue-600 dark:text-blue-400',       ring: 'hover:border-blue-300 dark:hover:border-blue-700' },
    amber:   { bg: 'bg-amber-100 dark:bg-amber-900/30',     fg: 'text-amber-600 dark:text-amber-400',     ring: 'hover:border-amber-300 dark:hover:border-amber-700' },
    indigo:  { bg: 'bg-indigo-100 dark:bg-indigo-900/30',   fg: 'text-indigo-600 dark:text-indigo-400',   ring: 'hover:border-indigo-300 dark:hover:border-indigo-700' },
    purple:  { bg: 'bg-purple-100 dark:bg-purple-900/30',   fg: 'text-purple-600 dark:text-purple-400',   ring: 'hover:border-purple-300 dark:hover:border-purple-700' },
    teal:    { bg: 'bg-teal-100 dark:bg-teal-900/30',       fg: 'text-teal-600 dark:text-teal-400',       ring: 'hover:border-teal-300 dark:hover:border-teal-700' },
    slate:   { bg: 'bg-slate-100 dark:bg-slate-800',        fg: 'text-slate-600 dark:text-slate-300',     ring: 'hover:border-slate-300 dark:hover:border-slate-700' },
  };
  const c = toneMap[tone] || toneMap.slate;
  return (
    <button
      type="button"
      onClick={onClick}
      className={`text-left bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4 transition-all ${c.ring} hover:shadow-md hover:-translate-y-0.5`}
    >
      <div className={`w-14 h-14 ${c.bg} ${c.fg} rounded-2xl flex items-center justify-center shrink-0`}>
        <Icon size={28} />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 truncate">{title}</p>
        <h3 className="text-xl font-black text-slate-800 dark:text-white tracking-tight truncate">{total}</h3>
        <p className="text-[11px] font-bold text-slate-400 mt-0.5">{count} {hint || 'kayıt'} • Detay için tıkla</p>
      </div>
    </button>
  );
};

// Drill-down modalı: belirli işlem tipinde dönem listesini gösterir.
// Breakdown ile aynı kesit penceresini kullanmak için startDate (ISO) parametresi alır;
// yoksa days ile fallback yapar.
const TxDetailModal = ({ open, onClose, title, txTypes, days, startDate, periodLabel }: any) => {
  const { t } = useAppContext();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open) return;
    const run = async () => {
      try {
        setLoading(true);
        const seen = new Set<number>();
        const all: any[] = [];
        for (const tt of txTypes) {
          const params: any = { transaction_type: tt, page_size: 1000 };
          if (startDate) params.start_date = startDate;
          else params.days = days;
          const r = await api.get('/finance/transactions', { params });
          (r.data?.items || []).forEach((it: any) => {
            if (!seen.has(it.id)) {
              seen.add(it.id);
              all.push(it);
            }
          });
        }
        all.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        setItems(all);
      } catch (err) {
        console.error('Detay yüklenemedi', err);
        setItems([]);
      } finally {
        setLoading(false);
      }
    };
    run();
  }, [open, txTypes?.join('|'), days, startDate]);

  if (!open) return null;
  const total = items.reduce((s, it) => s + Number(it.amount || 0), 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl w-full max-w-3xl max-h-[85vh] flex flex-col">
        <div className="flex items-center justify-between p-6 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h3 className="text-lg font-black text-slate-800 dark:text-white">{title}</h3>
            <p className="text-xs font-bold text-slate-500 dark:text-slate-400 mt-1">
              {periodLabel} • {items.length} kayıt • Toplam {formatMoney(total)}
            </p>
          </div>
          <button onClick={onClose} className="w-9 h-9 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500">
            <X size={20} />
          </button>
        </div>
        <div className="overflow-y-auto p-2">
          {loading ? (
            <div className="p-12 text-center text-slate-500 animate-pulse">{t('Veriler Yükleniyor...')}</div>
          ) : items.length === 0 ? (
            <div className="p-12 text-center text-slate-500 text-sm">Bu dönemde kayıt bulunamadı.</div>
          ) : (
            <ul className="divide-y divide-slate-100 dark:divide-slate-800">
              {items.map((it: any) => (
                <li key={it.id} className="flex items-center justify-between gap-3 px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-xl">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-slate-800 dark:text-white truncate">{it.customer_name}</span>
                      <span className={`text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded border ${txTypeTone(it.transaction_type)}`}>
                        {txTypeLabel(it.transaction_type)}
                      </span>
                    </div>
                    {it.notes && <div className="text-[12px] text-slate-500 italic line-clamp-1 mt-0.5">{it.notes}</div>}
                    <div className="text-[11px] text-slate-400 mt-0.5">{new Date(it.created_at).toLocaleString('tr-TR')}</div>
                  </div>
                  <div className="font-black text-slate-800 dark:text-white text-right shrink-0">
                    {formatMoney(it.amount, it.currency || 'TRY')}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button onClick={onClose} className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition">
            Kapat
          </button>
        </div>
      </div>
    </div>
  );
};

const PERIODS: { id: 'today' | 'week' | 'month' | 'year'; label: string; days: number }[] = [
  { id: 'today', label: 'Bugün',   days: 1 },
  { id: 'week',  label: 'Bu Hafta', days: 7 },
  { id: 'month', label: 'Bu Ay',    days: 30 },
  { id: 'year',  label: 'Bu Yıl',   days: 365 },
];

const ReportsDashboardView = () => {
  const { t } = useAppContext();
  const [period, setPeriod] = useState<'today' | 'week' | 'month' | 'year'>('month');
  const [breakdown, setBreakdown] = useState<any>(null);
  const [data, setData] = useState<any>(null);
  const [chartData, setChartData] = useState<any[]>([]);
  const [topProducts, setTopProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [drill, setDrill] = useState<{ title: string; types: string[] } | null>(null);

  const periodObj = PERIODS.find(p => p.id === period) || PERIODS[2];

  useEffect(() => {
    const fetchReports = async () => {
      try {
        setLoading(true);
        const [bdRes, dashRes, chartRes, topRes] = await Promise.all([
          api.get('/dashboard/finance-breakdown', { params: { period } }),
          api.get('/dashboard', { params: { days: periodObj.days } }),
          api.get('/dashboard/chart-data', { params: { chart_type: 'sales', days: 14 } }),
          api.get('/dashboard/top-products', { params: { sort_by: 'profit', limit: 5 } }),
        ]);
        setBreakdown(bdRes.data);
        setData(dashRes.data);
        setChartData(chartRes.data?.data || []);
        setTopProducts(Array.isArray(topRes.data) ? topRes.data : []);
      } catch (error) {
        console.error('Error fetching report data:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchReports();
  }, [period]);

  const stats = data?.stats;
  const performance = data?.performance;
  const bd = breakdown?.breakdown || {};
  const periodLabel = periodObj.label;

  const cards = [
    { key: 'satış',   title: `${periodLabel} Satışlar (Satılmış)`, total: bd['satış']?.total,   count: bd['satış']?.count,   icon: TrendingUp, tone: 'emerald', types: bd['satış']?.types   || ['satış','sale'] },
    { key: 'borç',    title: `${periodLabel} Verilen Veresiye`,   total: bd['borç']?.total,    count: bd['borç']?.count,    icon: Wallet,     tone: 'red',     types: bd['borç']?.types    || ['borç','debt'] },
    { key: 'ödeme',   title: `${periodLabel} Ödenen / Tahsilat`,  total: bd['ödeme']?.total,   count: bd['ödeme']?.count,   icon: MinusCircle, tone: 'blue',    types: bd['ödeme']?.types   || ['ödeme','payment'] },
    { key: 'gider',   title: `${periodLabel} Firma Borcu / Gider`, total: bd['gider']?.total,   count: bd['gider']?.count,   icon: FileDown,   tone: 'amber',   types: bd['gider']?.types   || ['gider','expense'] },
    { key: 'senet',   title: `${periodLabel} Senetler`,            total: bd['senet']?.total,   count: bd['senet']?.count,   icon: BarChart,   tone: 'indigo',  types: bd['senet']?.types   || ['senet'] },
    { key: 'kredi',   title: `${periodLabel} Krediler`,            total: bd['kredi']?.total,   count: bd['kredi']?.count,   icon: Activity,   tone: 'purple',  types: bd['kredi']?.types   || ['kredi','loan'] },
    // Garanti kartı: sadece eski 'garanti' transaction_type'lı işlem varsa görünür.
    // (Yeni kullanıcılarda fin_garanti kategorisi kaldırıldığı için 0 ise gizliyoruz.)
    ...((bd['garanti']?.count ?? 0) > 0
      ? [{ key: 'garanti', title: `${periodLabel} Garantiler`, total: bd['garanti']?.total, count: bd['garanti']?.count, icon: Package, tone: 'teal', types: bd['garanti']?.types || ['garanti'] }]
      : []),
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div>
          <h2 className="text-2xl font-black text-slate-800 dark:text-white">{t('Gelişmiş Finans Raporları')}</h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">
            Her metrik kartına tıklayarak ilgili işlemleri görebilirsiniz.
          </p>
        </div>
        <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
          {PERIODS.map(p => (
            <button
              key={p.id}
              onClick={() => setPeriod(p.id)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition ${
                period === p.id
                  ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
              }`}
            >{p.label}</button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="p-12 text-center text-slate-500 animate-pulse">{t('Veriler Yükleniyor...')}</div>
      ) : (
        <>
          {/* Üst özet (tıklanabilir değil) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-gradient-to-br from-indigo-500 to-indigo-700 text-white p-5 rounded-2xl shadow-md">
              <p className="text-xs font-bold uppercase tracking-wider opacity-80 mb-1">Açık Müşteri Borcu</p>
              <h3 className="text-2xl font-black tracking-tight">{formatMoney(breakdown?.outstanding_debt || 0)}</h3>
              <p className="text-[11px] font-bold opacity-70 mt-1">Verilen veresiye − tahsilat</p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1">Tahmini Kar (Dönem)</p>
              <h3 className="text-2xl font-black text-emerald-600 dark:text-emerald-400 tracking-tight">{formatMoney(stats?.total_revenue?.value || 0)}</h3>
              <p className="text-[11px] font-bold text-slate-400 mt-1">Ortalama kar marjı bazlı</p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1">Müşteri Sayısı</p>
              <h3 className="text-2xl font-black text-blue-600 dark:text-blue-400 tracking-tight">{stats?.total_customers?.value || 0}</h3>
              <p className="text-[11px] font-bold text-slate-400 mt-1">{periodLabel} işlem yapan</p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1">Kritik Stok</p>
              <h3 className="text-2xl font-black text-purple-600 dark:text-purple-400 tracking-tight">{stats?.critical_stock_count?.value || 0} Ürün</h3>
              <p className="text-[11px] font-bold text-slate-400 mt-1">Min. seviye altında</p>
            </div>
          </div>

          {/* Tıklanabilir tip kartları */}
          <div>
            <h3 className="text-sm font-black text-slate-700 dark:text-slate-300 mb-3 uppercase tracking-wider">
              Detaylı Finans Dağılımı — {periodLabel}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {cards.map(card => (
                <MetricCard
                  key={card.key}
                  title={card.title}
                  total={formatMoney(card.total || 0)}
                  count={card.count || 0}
                  icon={card.icon}
                  tone={card.tone}
                  hint="işlem"
                  onClick={() => setDrill({ title: card.title, types: card.types })}
                />
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-6 flex items-center gap-2"><BarChart size={20} className="text-indigo-500"/> {t('Satış Grafiği (Son Günler)')}</h3>
              <div className="flex items-end gap-1 border-b border-slate-100 dark:border-slate-800" style={{ height: '200px' }}>
                {chartData.map((item, i) => {
                  const maxVal = chartData.reduce((acc, curr) => Math.max(acc, curr.sales), 1);
                  const barPx = Math.max((item.sales / maxVal) * 168, item.sales > 0 ? 4 : 0);
                  return (
                    <div key={i} className="flex-1 flex flex-col items-center justify-end gap-1 group pb-1">
                      <div className="w-full bg-indigo-500 rounded-t-sm relative" style={{ height: `${barPx}px` }}>
                        <span className="absolute -top-7 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 bg-slate-800 text-white text-[10px] font-bold px-1.5 py-0.5 rounded whitespace-nowrap transition-opacity z-10 pointer-events-none">{formatMoney(item.sales)}</span>
                      </div>
                      <span className="text-[10px] font-medium text-slate-400 leading-none">{new Date(item.date).getDate()}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <h3 className="text-lg font-bold text-slate-800 dark:text-white mb-4 flex items-center gap-2"><Award size={20} className="text-emerald-500"/> En Kârlı Ürünler</h3>
              {topProducts.length === 0 ? (
                <div className="p-4 text-center text-slate-500 text-sm">Ürün bulunamadı.</div>
              ) : (
                <div className="space-y-3">
                  {topProducts.map((p: any, i: number) => {
                    const rankColors = ['text-amber-500','text-slate-400','text-orange-400','text-slate-400','text-slate-400'];
                    return (
                      <div key={i} className="flex items-center justify-between gap-3 py-2 border-b border-slate-100 dark:border-slate-800 last:border-0">
                        <div className="flex items-center gap-3 min-w-0">
                          <span className={`text-sm font-black w-5 shrink-0 ${rankColors[i] || 'text-slate-400'}`}>#{i + 1}</span>
                          <div className="min-w-0">
                            <p className="font-semibold text-slate-800 dark:text-slate-200 text-sm truncate">{p.name}</p>
                            <p className="text-xs text-slate-500 truncate">{p.category}</p>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">%{p.margin_pct?.toFixed(1) ?? '—'}</p>
                          <p className="text-[11px] text-slate-400">{p.quantity} adet</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </>
      )}

      <TxDetailModal
        open={!!drill}
        onClose={() => setDrill(null)}
        title={drill?.title || ''}
        txTypes={drill?.types || []}
        days={periodObj.days}
        startDate={breakdown?.start_date}
        periodLabel={periodLabel}
      />
    </div>
  );
};

// 3.2.b Web Görünüm — Bayinin kendi kategorilerini yönettiği ekran
// =====================================================================
// ONBOARDING WIZARD — Yeni bayiye ilk giriş deneyimi
// =====================================================================

const ONBOARDING_KEY = (uid: number) => `sf_ob_v1_${uid}`;

const FEATURE_TOUR_ITEMS = [
  { icon: Package,  bg: 'bg-indigo-100 dark:bg-indigo-900/40',  text: 'text-indigo-600 dark:text-indigo-400',  title: 'Stok & Ürün Yönetimi',   desc: 'Ürünler, kategoriler ve barkod okuyucu ile tam stok kontrolü sağlayın.' },
  { icon: Wallet,   bg: 'bg-emerald-100 dark:bg-emerald-900/40', text: 'text-emerald-600 dark:text-emerald-400', title: 'Finans & Veresiye',        desc: 'Müşteri borçları, senet, kredi, gider ve cari hesap bakiyesi.' },
  { icon: Shield,   bg: 'bg-blue-100 dark:bg-blue-900/40',       text: 'text-blue-600 dark:text-blue-400',       title: 'Garanti Belgeleri',       desc: 'QR kodlu dijital garanti belgesi oluşturun; WhatsApp\'tan gönderin.' },
  { icon: Car,      bg: 'bg-amber-100 dark:bg-amber-900/40',     text: 'text-amber-600 dark:text-amber-400',     title: 'Araç & Teslimat',         desc: 'Araçlara stok yükleyin, teslimatlarda kayıt alın ve log\'u izleyin.' },
  { icon: Users,    bg: 'bg-purple-100 dark:bg-purple-900/40',   text: 'text-purple-600 dark:text-purple-400',   title: 'Çalışan Yönetimi',        desc: 'Çalışanları davet edin, her modül için özel erişim izni belirleyin.' },
  { icon: PieChart, bg: 'bg-rose-100 dark:bg-rose-900/40',       text: 'text-rose-600 dark:text-rose-400',       title: 'Raporlar & Analiz',       desc: 'Günlük/aylık gelir-gider grafikleri ve kategori bazlı satış analizi.' },
  { icon: Database, bg: 'bg-slate-200 dark:bg-slate-700',        text: 'text-slate-700 dark:text-slate-300',     title: 'Güvenli Yedekleme',       desc: 'Tüm verilerinizi tek tıkla şifreli dosyaya yedekleyin ve geri yükleyin.' },
  { icon: Palette,  bg: 'bg-orange-100 dark:bg-orange-900/40',   text: 'text-orange-600 dark:text-orange-400',   title: 'Web Görünüm',             desc: 'Sidebar menüsü ve ana panel kısayollarını tamamen özelleştirin.' },
];

const OBToggle = ({ checked, onChange, disabled }: { checked: boolean; onChange: () => void; disabled?: boolean }) => (
  <button type="button" onClick={onChange} disabled={disabled}
    className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors duration-200 focus:outline-none disabled:opacity-40 ${checked ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-600'}`}>
    <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform duration-200 ${checked ? 'translate-x-6' : 'translate-x-1'}`} />
  </button>
);

const OnboardingWizard = ({ currentUser, onComplete }: { currentUser: any; onComplete: () => void }) => {
  const { categories, refetchCategories, showToast } = useAppContext();
  const [step, setStep] = useState(0);
  const [busyId, setBusyId] = useState<number | null>(null);

  const stokCats = (categories || []).filter((c: any) => c.kind === 'stok').sort((a: any, b: any) => a.display_order - b.display_order);
  const finansCats = (categories || []).filter((c: any) => c.kind === 'finans').sort((a: any, b: any) => a.display_order - b.display_order);

  const STEPS = ['Hoş Geldiniz', 'Özellikler', 'Kategoriler', 'Hazır!'];
  const TOTAL = STEPS.length;

  const next = () => setStep(s => Math.min(s + 1, TOTAL - 1));
  const prev = () => setStep(s => Math.max(s - 1, 0));

  const toggleCat = async (cat: any) => {
    setBusyId(cat.id);
    try {
      await api.put(`/categories/${cat.id}`, { is_visible: !cat.is_visible });
      await refetchCategories();
    } catch { showToast('Güncelleme başarısız', 'error'); }
    finally { setBusyId(null); }
  };

  const toggleAllKind = async (kind: 'stok' | 'finans', visible: boolean) => {
    const list = kind === 'stok' ? stokCats : finansCats;
    for (const c of list) {
      try { await api.put(`/categories/${c.id}`, { is_visible: visible }); } catch {}
    }
    await refetchCategories();
  };

  const greeting = (() => {
    const h = new Date().getHours();
    if (h < 12) return 'Günaydın';
    if (h < 18) return 'İyi günler';
    return 'İyi akşamlar';
  })();

  const firstName = (currentUser?.name || '').split(' ')[0];

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-3 sm:p-6">
      <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-2xl flex flex-col max-h-[92svh] overflow-hidden">

        {/* Header */}
        <div className="shrink-0 px-6 pt-5 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 bg-indigo-600 rounded-xl flex items-center justify-center shadow-sm shadow-indigo-200 dark:shadow-none">
                <Package size={15} className="text-white" />
              </div>
              <span className="font-black text-slate-800 dark:text-white text-sm tracking-tight">StokFinans</span>
            </div>
            <button onClick={onComplete} className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 font-bold transition px-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">
              Geç
            </button>
          </div>
          {/* Step progress bar */}
          <div className="flex gap-1.5">
            {STEPS.map((_, i) => (
              <div key={i} className={`h-1.5 rounded-full transition-all duration-500 ${i < step ? 'bg-indigo-400' : i === step ? 'bg-indigo-600' : 'bg-slate-200 dark:bg-slate-700'} ${i === step ? 'flex-[3]' : 'flex-1'}`} />
            ))}
          </div>
          <p className="text-[11px] text-slate-400 mt-1.5 font-semibold tracking-wide uppercase">{STEPS[step]} — {step + 1}/{TOTAL}</p>
        </div>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto scrollbar-thin">

          {/* ── Step 0: Welcome ── */}
          {step === 0 && (
            <div className="p-8 sm:p-10 text-center flex flex-col items-center gap-5">
              <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl flex items-center justify-center shadow-xl shadow-indigo-200 dark:shadow-indigo-900/40 animate-in zoom-in duration-500">
                <Package size={44} className="text-white" strokeWidth={2} />
              </div>
              <div>
                <h1 className="text-3xl sm:text-4xl font-black text-slate-800 dark:text-white leading-tight">
                  {greeting},<br /><span className="text-indigo-600 dark:text-indigo-400">{firstName}! 👋</span>
                </h1>
                <p className="text-slate-500 dark:text-slate-400 mt-3 text-base leading-relaxed max-w-sm mx-auto">
                  StokFinans'a hoş geldiniz. İşletmenizin stok ve finansını kolayca yönetmek için tasarlandı.
                </p>
              </div>
              <div className="grid grid-cols-3 gap-3 w-full max-w-sm mt-2">
                {[
                  { n: '8+', l: 'Modül' },
                  { n: '∞', l: 'Ürün' },
                  { n: '7/24', l: 'Erişim' },
                ].map(item => (
                  <div key={item.l} className="bg-slate-50 dark:bg-slate-800 rounded-2xl p-3 text-center">
                    <p className="text-xl font-black text-indigo-600 dark:text-indigo-400">{item.n}</p>
                    <p className="text-xs font-bold text-slate-500 dark:text-slate-400 mt-0.5">{item.l}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── Step 1: Feature Tour ── */}
          {step === 1 && (
            <div className="p-6">
              <div className="text-center mb-6">
                <h2 className="text-xl font-black text-slate-800 dark:text-white">Neler var?</h2>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Tüm bu özellikler hesabınızda hazır ve aktif.</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {FEATURE_TOUR_ITEMS.map((f, i) => {
                  const FIcon = f.icon;
                  return (
                    <div key={i} className="flex items-start gap-3.5 p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 hover:border-indigo-200 dark:hover:border-indigo-800 transition">
                      <div className={`w-10 h-10 ${f.bg} ${f.text} rounded-xl flex items-center justify-center shrink-0`}>
                        <FIcon size={20} strokeWidth={2.2} />
                      </div>
                      <div className="min-w-0">
                        <p className="font-bold text-slate-800 dark:text-white text-sm">{f.title}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">{f.desc}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ── Step 2: Category Customization ── */}
          {step === 2 && (
            <div className="p-6 space-y-5">
              <div className="text-center">
                <h2 className="text-xl font-black text-slate-800 dark:text-white">Menünüzü Özelleştirin</h2>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1.5 max-w-sm mx-auto">
                  Sidebar'da ve ana panelde hangi kategorilerin görüneceğini seçin. İstediğiniz zaman <span className="font-bold text-indigo-600 dark:text-indigo-400">Web Görünüm</span>'den yeni kategori ekleyip, sıralayıp, ikon ve renk seçerek istediğiniz gibi planlayabilirsiniz.
                </p>
              </div>

              {/* Stok kategorileri */}
              <div className="bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
                <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900/50">
                  <span className="font-black text-slate-700 dark:text-slate-300 text-sm flex items-center gap-2">
                    <Box size={15} className="text-indigo-500" /> Stok Kategorileri
                    <span className="text-xs font-bold text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full">{stokCats.length}</span>
                  </span>
                  <div className="flex gap-2">
                    <button onClick={() => toggleAllKind('stok', true)} className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline">Tümünü Aç</button>
                    <span className="text-slate-300 dark:text-slate-600">|</span>
                    <button onClick={() => toggleAllKind('stok', false)} className="text-[11px] font-bold text-slate-500 hover:underline">Tümünü Kapat</button>
                  </div>
                </div>
                <div className="divide-y divide-slate-100 dark:divide-slate-700/50">
                  {stokCats.map((c: any) => {
                    const Ic = iconFor(c.icon);
                    return (
                      <div key={c.id} className={`flex items-center gap-3 px-4 py-3 transition ${!c.is_visible ? 'opacity-50' : ''}`}>
                        <div className={`w-8 h-8 ${c.bg_class} ${c.color_class} rounded-lg flex items-center justify-center shrink-0`}>
                          <Ic size={16} strokeWidth={2.3} />
                        </div>
                        <span className="flex-1 font-semibold text-slate-700 dark:text-slate-300 text-sm">{c.name}</span>
                        <OBToggle checked={!!c.is_visible} onChange={() => toggleCat(c)} disabled={busyId === c.id} />
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Finans kategorileri */}
              <div className="bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
                <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900/50">
                  <span className="font-black text-slate-700 dark:text-slate-300 text-sm flex items-center gap-2">
                    <Wallet size={15} className="text-emerald-500" /> Finans Kategorileri
                    <span className="text-xs font-bold text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full">{finansCats.length}</span>
                  </span>
                  <div className="flex gap-2">
                    <button onClick={() => toggleAllKind('finans', true)} className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 hover:underline">Tümünü Aç</button>
                    <span className="text-slate-300 dark:text-slate-600">|</span>
                    <button onClick={() => toggleAllKind('finans', false)} className="text-[11px] font-bold text-slate-500 hover:underline">Tümünü Kapat</button>
                  </div>
                </div>
                <div className="divide-y divide-slate-100 dark:divide-slate-700/50">
                  {finansCats.map((c: any) => {
                    const Ic = iconFor(c.icon);
                    return (
                      <div key={c.id} className={`flex items-center gap-3 px-4 py-3 transition ${!c.is_visible ? 'opacity-50' : ''}`}>
                        <div className={`w-8 h-8 ${c.bg_class} ${c.color_class} rounded-lg flex items-center justify-center shrink-0`}>
                          <Ic size={16} strokeWidth={2.3} />
                        </div>
                        <span className="flex-1 font-semibold text-slate-700 dark:text-slate-300 text-sm">{c.name}</span>
                        <OBToggle checked={!!c.is_visible} onChange={() => toggleCat(c)} disabled={busyId === c.id} />
                      </div>
                    );
                  })}
                </div>
              </div>

              <p className="text-xs text-slate-400 text-center">Değişiklikler anında kaydedilir. Web Görünüm'den yeni kategori ekleyebilir, ikon/renk seçebilir ve sıralamayı dilediğiniz gibi ayarlayabilirsiniz.</p>
            </div>
          )}

          {/* ── Step 3: Done ── */}
          {step === 3 && (
            <div className="p-8 sm:p-10 flex flex-col items-center text-center gap-5">
              <div className="w-24 h-24 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center animate-in zoom-in duration-500">
                <Check size={48} strokeWidth={3} />
              </div>
              <div>
                <h2 className="text-3xl font-black text-slate-800 dark:text-white">Hazırsınız! 🎉</h2>
                <p className="text-slate-500 dark:text-slate-400 mt-2 text-base max-w-sm mx-auto">
                  Sistemi keşfetmeye başlayabilirsiniz. İlk adım olarak ürün eklemenizi tavsiye ederiz.
                </p>
              </div>
              <div className="w-full max-w-sm space-y-2 text-left">
                {[
                  '📦 Sol menüden bir stok kategorisi seçin ve ürün ekleyin',
                  '💰 Finans sekmesinden müşteri borçlarını takip edin',
                  '⚙️ Web Görünüm\'den menüyü istediğiniz gibi özelleştirin',
                  '👥 Ayarlar > Çalışanlar\'dan ekip arkadaşlarınızı davet edin',
                ].map((tip, i) => (
                  <div key={i} className="flex items-start gap-2.5 p-3 bg-slate-50 dark:bg-slate-800 rounded-xl text-sm text-slate-600 dark:text-slate-400">
                    {tip}
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="shrink-0 px-6 py-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <button onClick={prev} disabled={step === 0}
            className="px-4 py-2.5 text-slate-500 dark:text-slate-400 font-bold text-sm hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition disabled:opacity-0">
            ← Geri
          </button>
          {step < TOTAL - 1 ? (
            <button onClick={next}
              className="px-7 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl transition text-sm shadow-sm shadow-indigo-200 dark:shadow-none">
              {step === 0 ? 'Keşfedelim →' : step === 2 ? 'Harika Görünüyor →' : 'Devam →'}
            </button>
          ) : (
            <button onClick={onComplete}
              className="px-7 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition text-sm shadow-sm">
              Panele Geç →
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

// =====================================================================
// Bu sayfa, sidebar ve ana paneldeki kısayolların hangi kategorilerden
// (stok ve finans) oluşacağını tamamen bayinin kontrolüne verir.
// Eklenen kategoriler anında menüye yansır.
// =====================================================================
// --- Dashboard Ayarları: Canlı Önizleme Kartı ---
const WidgetPreviewCard = ({ widget, hero }: {
  widget: DashWidget;
  hero: { gradient: string; chartColor: string; label: string };
}) => {
  const wDef = WIDGET_DEFS[widget.type];
  const WIcon = wDef?.icon || Hash;

  // Deterministik sahte bar verileri (widget ID'sine dayalı)
  const seedBars = (seed: string, count: number) => {
    let h = 0;
    for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) & 0xffffffff;
    return Array.from({ length: count }, () => {
      h = (h * 1664525 + 1013904223) & 0xffffffff;
      return 0.18 + ((h >>> 0) / 0xffffffff) * 0.82;
    });
  };
  const bars = seedBars(widget.id, 12);

  if (widget.type === 'donut') {
    return (
      <div className={`bg-gradient-to-br ${hero.gradient} rounded-xl border border-white/10 flex flex-col h-full overflow-hidden`} style={{ minHeight: 64 }}>
        <div className="px-2 pt-1.5 pb-0 flex items-center gap-1">
          <WIcon size={7} className="text-white/50 shrink-0" />
          <p className="text-[7px] font-bold text-white/50 truncate uppercase tracking-wide leading-none">{widget.title}</p>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <svg viewBox="0 0 40 26" className="w-9 h-7">
            <circle cx="20" cy="22" r="11" fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="5" />
            {[['#34d399', 20, 0],['#f87171', 14, -20],['#60a5fa', 10, -34],['#fbbf24', 8, -44]].map(([c, d, o], i) => (
              <circle key={i} cx="20" cy="22" r="11" fill="none" stroke={c as string}
                strokeWidth="5" strokeLinecap="round"
                strokeDasharray={`${Number(d) * 0.55} 100`}
                strokeDashoffset={Number(o) * 0.55}
                transform="rotate(-90 20 22)" />
            ))}
          </svg>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden" style={{ minHeight: 64 }}>
      <div className="px-2 pt-1.5 pb-0.5 flex items-center gap-1 shrink-0">
        <WIcon size={7} className="text-slate-400 shrink-0" />
        <p className="text-[7px] font-bold text-slate-400 truncate uppercase tracking-wide leading-none">{widget.title}</p>
      </div>
      <div className="flex-1 px-2 pb-2 flex flex-col justify-end min-h-0">
        {(widget.type === 'stat') && (
          <div>
            <div className="h-3.5 w-14 rounded mb-1" style={{ background: hero.chartColor + '55' }} />
            <div className="h-1.5 w-9 bg-slate-100 dark:bg-slate-800 rounded" />
          </div>
        )}
        {widget.type === 'gauge' && (
          <div className="flex items-end gap-1">
            <div className="h-3.5 w-10 rounded" style={{ background: hero.chartColor + '55' }} />
            <div className="h-1.5 w-4 bg-slate-100 dark:bg-slate-800 rounded mb-0.5" />
          </div>
        )}
        {widget.type === 'sparkline' && (
          <div className="relative flex-1 flex flex-col justify-end">
            <div className="absolute inset-0">
              <svg viewBox="0 0 60 20" preserveAspectRatio="none" className="w-full h-full opacity-20">
                <polyline points={bars.slice(0,7).map((b,i)=>`${i*10},${20*(1-b)}`).join(' ')}
                  fill="none" stroke={hero.chartColor} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <div className="z-10">
              <div className="h-3.5 w-12 rounded mb-0.5" style={{ background: hero.chartColor + '60' }} />
              <div className="h-1.5 w-7 bg-slate-100 dark:bg-slate-800 rounded" />
            </div>
          </div>
        )}
        {widget.type === 'line' && (
          <svg viewBox="0 0 60 18" preserveAspectRatio="none" className="w-full h-8">
            <polyline points={bars.slice(0,7).map((b,i)=>`${i*10},${18*(1-b)}`).join(' ')}
              fill="none" stroke={hero.chartColor} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            {widget.sources.length > 1 && (
              <polyline points={bars.slice(2,9).map((b,i)=>`${i*10},${18*(1-b*0.7)}`).join(' ')}
                fill="none" stroke={SERIES_PALETTE[1]} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            )}
          </svg>
        )}
        {widget.type === 'bar' && (
          <div className="flex items-end gap-[2px] h-8">
            {bars.slice(0,7).map((b,i) => (
              <div key={i} className="flex-1 rounded-[2px]"
                style={{ height: `${b*100}%`, background: hero.chartColor + (i%2===0 ? 'cc':'77') }} />
            ))}
          </div>
        )}
        {widget.type === 'activity' && (
          <div className="space-y-1.5 flex-1 flex flex-col justify-end">
            {bars.slice(0,3).map((b,i) => (
              <div key={i} className="flex items-center gap-1">
                <div className="w-2.5 h-2.5 rounded bg-slate-100 dark:bg-slate-800 shrink-0" />
                <div className="h-1.5 rounded bg-slate-100 dark:bg-slate-800" style={{ width: `${b*100}%` }} />
              </div>
            ))}
          </div>
        )}
        {widget.type === 'top' && (
          <div className="space-y-1.5 flex-1 flex flex-col justify-end">
            {[bars[0], bars[1]*0.78, bars[2]*0.55].map((b,i) => (
              <div key={i} className="flex items-center gap-1">
                <span className="text-[6px] text-slate-300 dark:text-slate-600 font-black w-2 shrink-0 text-right">{i+1}</span>
                <div className="h-1.5 rounded flex-1 overflow-hidden bg-slate-100 dark:bg-slate-800">
                  <div className="h-full rounded" style={{ width: `${b*100}%`, background: SERIES_PALETTE[i%SERIES_PALETTE.length]+'bb' }} />
                </div>
              </div>
            ))}
          </div>
        )}
        {widget.type === 'calendar' && (
          <div className="flex-1 flex items-end pt-1">
            <div className="grid gap-[1.5px] w-full" style={{ gridTemplateColumns:'repeat(13,1fr)', gridTemplateRows:'repeat(3,1fr)' }}>
              {Array.from({length:39},(_,i) => {
                const b = bars[i % bars.length];
                return (
                  <div key={i} className="rounded-[1px]" style={{ aspectRatio:'1',
                    background: b > 0.35 ? hero.chartColor + Math.round(b*210).toString(16).padStart(2,'0') : 'rgba(148,163,184,0.2)' }} />
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const WebSettingsView = ({ onReplayOnboarding, currentUserId }: { onReplayOnboarding?: () => void; currentUserId?: number } = {}) => {
  const { t, showToast, categories, categoriesLoading, refetchCategories } = useAppContext();

  const [editing, setEditing] = useState<any | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [formKind, setFormKind] = useState<'stok' | 'finans'>('stok');
  const [formName, setFormName] = useState('');
  const [formIcon, setFormIcon] = useState('Package');
  const [iconSearch, setIconSearch] = useState('');
  const [formColorIdx, setFormColorIdx] = useState(0);
  const [formVisible, setFormVisible] = useState(true);
  const [formTxType, setFormTxType] = useState('borç');
  const [formCustomerLabel, setFormCustomerLabel] = useState('');
  const [formAmountLabel, setFormAmountLabel] = useState('');
  const [formAmountTone, setFormAmountTone] = useState('slate');
  const [formViewMode, setFormViewMode] = useState<'list' | 'grid' | 'masonry' | 'carousel' | 'category'>('list');
  const [busyId, setBusyId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [prevTab, setPrevTab] = useState<'dashboard' | 'sidebar'>('dashboard');
  const [settingsTab, setSettingsTab] = useState<'kategoriler' | 'dashboard' | 'isletme'>('kategoriler');

  // İşletme Bilgileri state
  const [bCompanyName, setBCompanyName] = useState('');
  const [bCompanyPhone, setBCompanyPhone] = useState('');
  const [bCompanyAddress, setBCompanyAddress] = useState('');
  const [bFullName, setBFullName] = useState('');
  const [bLoading, setBLoading] = useState(false);
  const [bSaving, setBSaving] = useState(false);

  // Load company info when tab is opened
  useEffect(() => {
    if (settingsTab !== 'isletme') return;
    setBLoading(true);
    api.get('/auth/profile').then(r => {
      setBCompanyName(r.data.company_name || '');
      setBCompanyPhone(r.data.company_phone || '');
      setBCompanyAddress(r.data.company_address || '');
      setBFullName(r.data.full_name || '');
    }).catch(() => {}).finally(() => setBLoading(false));
  }, [settingsTab]);

  // Delete-with-products conflict modal state
  const [deleteConflict, setDeleteConflict] = useState<{ cat: any; count: number } | null>(null);
  const [moveToId, setMoveToId] = useState<number | ''>('');
  const [deleting, setDeleting] = useState(false);

  const { layout: dashLayout, setLayout: setDashLayout } = useDashboardLayout(currentUserId ?? null);
  const [editingWidget, setEditingWidget] = useState<DashWidget | null>(null);
  const [showAddWidget, setShowAddWidget] = useState(false);

  const stokList = (categories || []).filter((c: any) => c.kind === 'stok')
    .sort((a: any, b: any) => (a.display_order - b.display_order));
  const finansList = (categories || []).filter((c: any) => c.kind === 'finans')
    .sort((a: any, b: any) => (a.display_order - b.display_order));

  const filteredIconNames = iconSearch.trim()
    ? ICON_NAMES.filter(n => n.toLowerCase().includes(iconSearch.toLowerCase()))
    : ICON_NAMES;

  const resetForm = () => {
    setEditing(null);
    setFormKind('stok');
    setFormName('');
    setFormIcon('Package');
    setIconSearch('');
    setFormColorIdx(0);
    setFormVisible(true);
    setFormTxType('borç');
    setFormCustomerLabel('');
    setFormAmountLabel('');
    setFormAmountTone('slate');
    setFormViewMode('list');
  };

  const openNew = (kind: 'stok' | 'finans') => {
    resetForm();
    setFormKind(kind);
    if (kind === 'finans') {
      setFormCustomerLabel('Müşteri / Cari');
      setFormAmountLabel('Tutar (₺)');
    }
    setShowForm(true);
  };

  const openEdit = (cat: any) => {
    setEditing(cat);
    setFormKind(cat.kind);
    setFormName(cat.name);
    setFormIcon(cat.icon || 'Package');
    setIconSearch('');
    const idx = COLOR_PALETTE.findIndex((p) => p.color_class === cat.color_class);
    setFormColorIdx(idx >= 0 ? idx : 0);
    setFormVisible(!!cat.is_visible);
    setFormTxType(cat.transaction_type || 'borç');
    setFormCustomerLabel(cat.customer_label || '');
    setFormAmountLabel(cat.amount_label || '');
    setFormAmountTone(cat.amount_tone || 'slate');
    setFormViewMode((cat.view_mode as any) || 'list');
    setShowForm(true);
  };

  const handleSubmit = async () => {
    if (!formName.trim()) { showToast('Kategori adı boş olamaz', 'error'); return; }
    const palette = COLOR_PALETTE[formColorIdx] || COLOR_PALETTE[0];
    // New categories get max display_order + 10 so they appear at the end
    const kindList = formKind === 'stok' ? stokList : finansList;
    const maxOrder = kindList.reduce((m: number, c: any) => Math.max(m, c.display_order || 0), 0);
    const payload: any = {
      kind: formKind,
      name: formName.trim(),
      icon: formIcon,
      color_class: palette.color_class,
      bg_class: palette.bg_class,
      is_visible: formVisible,
      view_mode: formViewMode,
      display_order: editing ? undefined : maxOrder + 10,
    };
    if (editing) delete payload.display_order;
    if (formKind === 'finans') {
      payload.transaction_type = formTxType || null;
      payload.customer_label = formCustomerLabel || null;
      payload.amount_label = formAmountLabel || null;
      payload.amount_tone = formAmountTone || null;
    }
    try {
      setSaving(true);
      if (editing) {
        await api.put(`/categories/${editing.id}`, payload);
        showToast(t('Kategori güncellendi'));
      } else {
        await api.post('/categories', payload);
        showToast(t('Kategori başarıyla eklendi'));
      }
      setShowForm(false);
      resetForm();
      await refetchCategories();
    } catch (err: any) {
      showToast(err.response?.data?.detail || err.response?.data?.error || 'Hata oluştu', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (cat: any) => {
    if (!confirm(`"${cat.name}" kategorisini silmek istediğinize emin misiniz?`)) return;
    try {
      setBusyId(cat.id);
      await api.delete(`/categories/${cat.id}`);
      showToast('Kategori silindi');
      await refetchCategories();
    } catch (err: any) {
      const status = err?.response?.status;
      const detail: string = err?.response?.data?.detail || 'Hata oluştu';
      if (status === 409) {
        // Extract product count from error message "Bu kategoride X ürün var..."
        const match = detail.match(/(\d+)\s*ürün/);
        const count = match ? parseInt(match[1], 10) : 1;
        setMoveToId('');
        setDeleteConflict({ cat, count });
      } else {
        showToast(detail, 'error');
      }
    } finally {
      setBusyId(null);
    }
  };

  const confirmDeleteWithMove = async () => {
    if (!deleteConflict) return;
    setDeleting(true);
    try {
      const params: any = {};
      if (moveToId) params.move_products_to = moveToId;
      await api.delete(`/categories/${deleteConflict.cat.id}`, { params });
      showToast('Kategori silindi' + (moveToId ? ', ürünler taşındı' : ''));
      setDeleteConflict(null);
      await refetchCategories();
    } catch (err: any) {
      showToast(err?.response?.data?.detail || 'Silme başarısız', 'error');
    } finally {
      setDeleting(false);
    }
  };

  const toggleVisible = async (cat: any) => {
    try {
      setBusyId(cat.id);
      await api.put(`/categories/${cat.id}`, { is_visible: !cat.is_visible });
      await refetchCategories();
    } catch (err: any) {
      showToast(err.response?.data?.detail || 'Hata oluştu', 'error');
    } finally {
      setBusyId(null);
    }
  };

  const moveOrder = async (cat: any, dir: -1 | 1) => {
    const list = (categories || []).filter((c: any) => c.kind === cat.kind)
      .sort((a: any, b: any) => (a.display_order - b.display_order));
    const idx = list.findIndex((c: any) => c.id === cat.id);
    const targetIdx = idx + dir;
    if (targetIdx < 0 || targetIdx >= list.length) return;
    const a = list[idx], b = list[targetIdx];
    // If display_order values are equal, assign unique ones first
    const orderA = a.display_order || idx * 10;
    const orderB = b.display_order || targetIdx * 10;
    try {
      setBusyId(cat.id);
      await api.post('/categories/reorder', {
        items: [
          { id: a.id, display_order: orderB === orderA ? orderA + 1 : orderB },
          { id: b.id, display_order: orderA === orderB ? orderB - 1 : orderA },
        ],
      });
      await refetchCategories();
    } catch (err: any) {
      showToast(err.response?.data?.detail || 'Sıralama hatası', 'error');
    } finally {
      setBusyId(null);
    }
  };

  const handleSeedDefaults = async () => {
    try {
      setSeeding(true);
      const r = await api.post('/categories/seed-defaults');
      const added = r.data?.added ?? 0;
      showToast(added > 0 ? `${added} varsayılan kategori eklendi` : 'Tüm varsayılanlar zaten mevcut');
      if (added > 0) await refetchCategories();
    } catch (err: any) {
      showToast(err.response?.data?.detail || 'Hata oluştu', 'error');
    } finally {
      setSeeding(false);
    }
  };

  const renderRow = (cat: any, list: any[]) => {
    const Icon = iconFor(cat.icon);
    const idx = list.findIndex((c: any) => c.id === cat.id);
    return (
      <div key={cat.id} className={`flex items-center gap-3 sm:gap-4 p-3 sm:p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl transition-all ${cat.is_visible ? '' : 'opacity-60'}`}>
        <div className={`w-11 h-11 ${cat.bg_class} ${cat.color_class} rounded-xl flex items-center justify-center shrink-0 shadow-inner`}>
          <Icon size={20} strokeWidth={2.5} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-bold text-slate-800 dark:text-white truncate">{cat.name}</div>
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium flex items-center gap-2 flex-wrap mt-0.5">
            <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 rounded font-mono">{cat.key}</span>
            {(() => {
              const vm = VIEW_MODES.find(v => v.id === (cat.view_mode || 'list'));
              if (!vm) return null;
              const VmIcon = vm.icon;
              return <span className="px-1.5 py-0.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 rounded inline-flex items-center gap-1"><VmIcon size={11} /> {vm.label}</span>;
            })()}
            {cat.kind === 'finans' && cat.transaction_type && (
              <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 rounded text-slate-600 dark:text-slate-400">{cat.transaction_type}</span>
            )}
            {!cat.is_visible && <span className="text-amber-600 dark:text-amber-400">• Gizli</span>}
          </div>
        </div>
        <div className="flex items-center gap-0.5 shrink-0">
          <button onClick={() => moveOrder(cat, -1)} disabled={busyId === cat.id || idx === 0} title="Yukarı Taşı"
            className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition disabled:opacity-30"><ArrowUp size={15} /></button>
          <button onClick={() => moveOrder(cat, 1)} disabled={busyId === cat.id || idx === list.length - 1} title="Aşağı Taşı"
            className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition disabled:opacity-30"><ArrowDown size={15} /></button>
          <button onClick={() => toggleVisible(cat)} disabled={busyId === cat.id} title={cat.is_visible ? 'Gizle' : 'Göster'}
            className="p-2 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-900/20 transition disabled:opacity-40">
            {cat.is_visible ? <Eye size={15} /> : <EyeOff size={15} />}
          </button>
          <button onClick={() => openEdit(cat)} title="Düzenle"
            className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition"><Edit size={15} /></button>
          <button onClick={() => handleDelete(cat)} disabled={busyId === cat.id} title="Sil"
            className="p-2 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 transition disabled:opacity-40"><Trash size={15} /></button>
        </div>
      </div>
    );
  };

  const EmptyState = ({ kind }: { kind: 'stok' | 'finans' }) => (
    <div className="p-10 text-center space-y-4">
      <div className="w-14 h-14 bg-slate-100 dark:bg-slate-800 rounded-2xl flex items-center justify-center mx-auto">
        {kind === 'stok' ? <Box size={28} className="text-slate-400" /> : <Wallet size={28} className="text-slate-400" />}
      </div>
      <div>
        <p className="font-bold text-slate-600 dark:text-slate-400">Henüz kategori yok</p>
        <p className="text-sm text-slate-400 mt-1">Yeni kategori ekleyin veya varsayılanları yükleyin.</p>
      </div>
      <button onClick={handleSeedDefaults} disabled={seeding}
        className="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-sm font-bold rounded-xl transition disabled:opacity-50">
        <RefreshCw size={15} className={seeding ? 'animate-spin' : ''} /> Varsayılanları Yükle
      </button>
    </div>
  );

  return (
    <div className="max-w-5xl space-y-6 animate-in fade-in duration-300">
      {/* HEADER */}
      <div className="bg-white dark:bg-slate-900 p-6 md:p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center shrink-0"><Palette size={32} /></div>
          <div className="flex-1 min-w-0">
            <h2 className="text-2xl font-black text-slate-800 dark:text-white">Web Görünüm</h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium mt-0.5">Sidebar ve ana paneldeki kategori kısayollarını buradan yönetin. Sıralama, ikon, renk ve görünüm tarzını özelleştirin.</p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {onReplayOnboarding && (
              <button onClick={onReplayOnboarding}
                className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/20 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 rounded-xl transition"
                title="Tanıtım turunu tekrar göster">
                <Eye size={15} />
                <span className="hidden sm:inline">Tanıtım Turunu Göster</span>
              </button>
            )}
            <button onClick={handleSeedDefaults} disabled={seeding}
              className="flex items-center gap-2 px-3 py-2 text-sm font-bold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition disabled:opacity-50"
              title="Eksik varsayılan kategorileri geri yükle">
              <RefreshCw size={15} className={seeding ? 'animate-spin' : ''} />
              <span className="hidden sm:inline">Varsayılanları Geri Yükle</span>
            </button>
          </div>
        </div>
      </div>

      {/* SAYFA SEÇİCİ */}
      <div className="flex gap-1 p-1.5 bg-slate-100 dark:bg-slate-800 rounded-2xl">
        {([
          { id: 'kategoriler', label: 'Kategoriler & Görünüm', short: 'Kategoriler', icon: Palette },
          { id: 'dashboard',   label: 'Ana Panel',             short: 'Ana Panel',   icon: LayoutDashboard },
          { id: 'isletme',     label: 'İşletme Bilgileri',     short: 'İşletme',     icon: Building2 },
        ] as const).map(({ id, label, short, icon: Icon }) => (
          <button key={id} onClick={() => setSettingsTab(id)}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-sm font-bold transition-all ${
              settingsTab === id
                ? 'bg-white dark:bg-slate-900 text-slate-800 dark:text-white shadow-sm'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300'
            }`}>
            <Icon size={15} />
            <span className="hidden sm:inline">{label}</span>
            <span className="sm:hidden">{short}</span>
          </button>
        ))}
      </div>

      {/* ===== KATEGORİLER SAYFASI ===== */}
      {settingsTab === 'kategoriler' && <>

      {/* CANLI ÖNİZLEME */}
      {(() => {
        const visibleStok = stokList.filter((c: any) => c.is_visible);
        const visibleFinans = finansList.filter((c: any) => c.is_visible);
        return (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
            {/* Tab header */}
            <div className="flex border-b border-slate-200 dark:border-slate-800">
              {([['dashboard', 'Ana Panel Önizlemesi', LayoutGrid], ['sidebar', 'Sidebar Önizlemesi', List]] as const).map(([id, label, Icon]) => (
                <button key={id} onClick={() => setPrevTab(id)}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 text-sm font-bold transition ${prevTab === id ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-400 border-b-2 border-indigo-600' : 'text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
                  <Icon size={15} /> {label}
                </button>
              ))}
            </div>

            {/* Dashboard tab */}
            {prevTab === 'dashboard' && (
              <div className="p-5 space-y-5 bg-slate-50 dark:bg-slate-950/50">
                {visibleStok.length > 0 && (
                  <div>
                    <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-3 flex items-center gap-1.5"><Box size={12} className="text-indigo-500" /> Stok & Kategoriler</p>
                    <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-7 gap-2">
                      {visibleStok.map((c: any) => {
                        const Ic = iconFor(c.icon);
                        return (
                          <div key={c.id} className="bg-white dark:bg-slate-900 p-3 h-24 flex flex-col items-center justify-center text-center rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
                            <div className={`w-10 h-10 ${c.bg_class} ${c.color_class} rounded-xl flex items-center justify-center mb-2 shadow-inner`}><Ic size={18} strokeWidth={2.5} /></div>
                            <span className="text-[10px] font-bold text-slate-700 dark:text-slate-300 leading-tight line-clamp-2">{c.name}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
                {visibleFinans.length > 0 && (
                  <div>
                    <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-3 flex items-center gap-1.5"><Wallet size={12} className="text-emerald-500" /> Finans & Yönetim</p>
                    <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-8 gap-2">
                      {visibleFinans.map((c: any) => {
                        const Ic = iconFor(c.icon);
                        return (
                          <div key={c.id} className="bg-white dark:bg-slate-900 p-3 h-24 flex flex-col items-center justify-center text-center rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
                            <div className={`w-10 h-10 ${c.bg_class} ${c.color_class} rounded-xl flex items-center justify-center mb-2 shadow-inner`}><Ic size={18} strokeWidth={2.5} /></div>
                            <span className="text-[10px] font-bold text-slate-700 dark:text-slate-300 leading-tight line-clamp-2">{c.name}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
                {visibleStok.length === 0 && visibleFinans.length === 0 && (
                  <div className="py-10 text-center text-slate-400 text-sm">Görünür kategori yok — görünürlük açık olan kategoriler burada görünür.</div>
                )}
              </div>
            )}

            {/* Sidebar tab */}
            {prevTab === 'sidebar' && (
              <div className="p-5">
                <div className="max-w-xs mx-auto bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 p-3 space-y-3">
                  {visibleStok.length > 0 && (
                    <div>
                      <p className="text-[9px] font-black uppercase text-slate-400 tracking-widest mb-1.5 px-1">Stok</p>
                      <div className="space-y-0.5">
                        {visibleStok.slice(0, 7).map((c: any) => {
                          const Ic = iconFor(c.icon);
                          return (
                            <div key={c.id} className="flex items-center gap-2.5 px-2.5 py-2 rounded-xl bg-white dark:bg-slate-900/70">
                              <div className={`w-7 h-7 ${c.bg_class} ${c.color_class} rounded-lg flex items-center justify-center shrink-0`}><Ic size={14} strokeWidth={2.5} /></div>
                              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 truncate">{c.name}</span>
                            </div>
                          );
                        })}
                        {visibleStok.length > 7 && <p className="text-[10px] text-slate-400 px-3 py-1">+{visibleStok.length - 7} daha...</p>}
                      </div>
                    </div>
                  )}
                  {visibleFinans.length > 0 && (
                    <div>
                      <p className="text-[9px] font-black uppercase text-slate-400 tracking-widest mb-1.5 px-1">Finans</p>
                      <div className="space-y-0.5">
                        {visibleFinans.slice(0, 5).map((c: any) => {
                          const Ic = iconFor(c.icon);
                          return (
                            <div key={c.id} className="flex items-center gap-2.5 px-2.5 py-2 rounded-xl bg-white dark:bg-slate-900/70">
                              <div className={`w-7 h-7 ${c.bg_class} ${c.color_class} rounded-lg flex items-center justify-center shrink-0`}><Ic size={14} strokeWidth={2.5} /></div>
                              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 truncate">{c.name}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                  {visibleStok.length === 0 && visibleFinans.length === 0 && (
                    <p className="text-xs text-slate-400 text-center py-4">Görünür kategori yok</p>
                  )}
                </div>
              </div>
            )}
          </div>
        );
      })()}

      {/* STOK KATEGORİLERİ */}
      <div className="bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-black text-slate-800 dark:text-white flex items-center gap-2">
            <Box size={20} className="text-indigo-500" /> Stok Kategorileri
            <span className="text-xs font-bold text-slate-500 bg-slate-200 dark:bg-slate-700 px-2 py-0.5 rounded-full">{stokList.length}</span>
          </h3>
          <button onClick={() => openNew('stok')} className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white text-sm font-bold rounded-xl hover:bg-indigo-700 transition shadow-sm">
            <Plus size={16} /> Yeni Kategori
          </button>
        </div>
        {categoriesLoading ? (
          <div className="p-8 text-center text-slate-400 animate-pulse">Kategoriler yükleniyor...</div>
        ) : stokList.length === 0 ? (
          <EmptyState kind="stok" />
        ) : (
          <div className="space-y-2">{stokList.map((c: any) => renderRow(c, stokList))}</div>
        )}
      </div>

      {/* FİNANS KATEGORİLERİ */}
      <div className="bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-black text-slate-800 dark:text-white flex items-center gap-2">
            <Wallet size={20} className="text-emerald-500" /> Finans Kategorileri
            <span className="text-xs font-bold text-slate-500 bg-slate-200 dark:bg-slate-700 px-2 py-0.5 rounded-full">{finansList.length}</span>
          </h3>
          <button onClick={() => openNew('finans')} className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white text-sm font-bold rounded-xl hover:bg-emerald-700 transition shadow-sm">
            <Plus size={16} /> Yeni Kategori
          </button>
        </div>
        {categoriesLoading ? (
          <div className="p-8 text-center text-slate-400 animate-pulse">Kategoriler yükleniyor...</div>
        ) : finansList.length === 0 ? (
          <EmptyState kind="finans" />
        ) : (
          <div className="space-y-2">{finansList.map((c: any) => renderRow(c, finansList))}</div>
        )}
      </div>

      </> /* end kategoriler */}

      {/* ===== ANA PANEL SAYFASI ===== */}
      {settingsTab === 'dashboard' && currentUserId && (() => {
        const hero = HERO_CONFIGS[dashLayout.heroColor] || HERO_CONFIGS.indigo;
        return (
          <div className="grid lg:grid-cols-[1fr_380px] gap-4 items-start">

            {/* SOL: Düzenleyici */}
            <div className="space-y-5">

              {/* Renk teması */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5">
                <p className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                  <Palette size={12} /> Panel Renk Teması
                </p>
                <div className="flex flex-wrap gap-2">
                  {HERO_COLORS.map(color => {
                    const cfg = HERO_CONFIGS[color];
                    const active = dashLayout.heroColor === color;
                    return (
                      <button key={color} onClick={() => setDashLayout({ ...dashLayout, heroColor: color })}
                        className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-bold border-2 transition ${active ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-slate-300 dark:hover:border-slate-600'}`}>
                        <div className={`w-3.5 h-3.5 rounded-full ${cfg.dot}`} />
                        {cfg.label}
                        {active && <Check size={12} className="text-indigo-500" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Widget listesi */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <p className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                    <LayoutGrid size={12} /> Widget'lar
                    <span className="ml-1 text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 px-1.5 py-0.5 rounded-full">{dashLayout.widgets.length}</span>
                  </p>
                  <button onClick={() => setShowAddWidget(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition">
                    <Plus size={13} /> Widget Ekle
                  </button>
                </div>
                <div className="space-y-2">
                  {dashLayout.widgets.map((w, idx) => {
                    const wDef = WIDGET_DEFS[w.type];
                    const WIcon = wDef.icon;
                    return (
                      <div key={w.id} className="flex items-center gap-2.5 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 group">
                        {/* Sıra butonları */}
                        <div className="flex flex-col gap-0.5 shrink-0">
                          <button disabled={idx === 0} onClick={() => {
                            const ws = [...dashLayout.widgets];
                            [ws[idx - 1], ws[idx]] = [ws[idx], ws[idx - 1]];
                            setDashLayout({ ...dashLayout, widgets: ws });
                          }} className="p-0.5 text-slate-300 dark:text-slate-600 hover:text-slate-600 dark:hover:text-slate-300 disabled:opacity-20 transition">
                            <ArrowUp size={12} />
                          </button>
                          <button disabled={idx === dashLayout.widgets.length - 1} onClick={() => {
                            const ws = [...dashLayout.widgets];
                            [ws[idx], ws[idx + 1]] = [ws[idx + 1], ws[idx]];
                            setDashLayout({ ...dashLayout, widgets: ws });
                          }} className="p-0.5 text-slate-300 dark:text-slate-600 hover:text-slate-600 dark:hover:text-slate-300 disabled:opacity-20 transition">
                            <ArrowDown size={12} />
                          </button>
                        </div>
                        {/* İkon */}
                        <div className="w-7 h-7 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center shrink-0">
                          <WIcon size={13} />
                        </div>
                        {/* Bilgi */}
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-bold text-slate-800 dark:text-white truncate leading-tight">{w.title}</p>
                          <div className="flex items-center gap-1 mt-0.5 flex-wrap">
                            <span className="text-[9px] text-slate-400 font-medium">{wDef.label}</span>
                            <span className="text-[9px] text-slate-300 dark:text-slate-600">·</span>
                            {w.sources.slice(0,2).map((s, si) => {
                              const sd = SOURCE_DEFS[s];
                              return (
                                <span key={s} className="text-[9px] font-bold truncate" style={{ color: si === 0 ? '#6366f1' : SERIES_PALETTE[si % SERIES_PALETTE.length] }}>{sd?.label || s}</span>
                              );
                            })}
                            {w.sources.length > 2 && <span className="text-[9px] text-slate-400">+{w.sources.length - 2}</span>}
                            <span className="text-[9px] text-slate-300 dark:text-slate-600">·</span>
                            <span className="text-[9px] text-slate-400">{w.span} kol</span>
                          </div>
                        </div>
                        {/* Span (kolon) hızlı seçici */}
                        <div className="flex gap-0.5 shrink-0">
                          {([1, 2, 3, 4] as ColSpan[]).map(s => (
                            <button key={s} onClick={() => {
                              const ws = dashLayout.widgets.map(x => x.id === w.id ? { ...x, span: s } : x);
                              setDashLayout({ ...dashLayout, widgets: ws });
                            }}
                              className={`w-5 h-5 rounded text-[9px] font-black transition ${w.span === s ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-700 text-slate-400 dark:text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-600'}`}>
                              {s}
                            </button>
                          ))}
                        </div>
                        {/* Aksiyonlar */}
                        <button onClick={() => setEditingWidget({ ...w })}
                          className="p-1.5 text-slate-300 dark:text-slate-600 hover:text-indigo-600 dark:hover:text-indigo-400 transition rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-900/20">
                          <Edit size={13} />
                        </button>
                        <button onClick={() => setDashLayout({ ...dashLayout, widgets: dashLayout.widgets.filter(x => x.id !== w.id) })}
                          className="p-1.5 text-slate-300 dark:text-slate-600 hover:text-red-500 dark:hover:text-red-400 transition rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20">
                          <Trash size={13} />
                        </button>
                      </div>
                    );
                  })}
                  {dashLayout.widgets.length === 0 && (
                    <div className="text-center py-10 text-slate-400 dark:text-slate-500 text-sm font-medium">
                      Hiç widget yok. Yukarıdan "Widget Ekle" ile başlayın.
                    </div>
                  )}
                </div>
                <button onClick={() => setDashLayout(JSON.parse(JSON.stringify(DEFAULT_DASH_LAYOUT)))}
                  className="w-full mt-4 py-2 text-xs font-bold text-slate-400 dark:text-slate-500 border border-dashed border-slate-200 dark:border-slate-700 rounded-xl hover:border-slate-300 dark:hover:border-slate-600 hover:text-slate-500 dark:hover:text-slate-400 transition">
                  Varsayılana Döndür
                </button>
              </div>
            </div>

            {/* SAĞ: Canlı Önizleme — sticky */}
            <div className="lg:sticky lg:top-4">
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4">
                <p className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                  <Eye size={12} /> Canlı Önizleme
                </p>
                <div className="border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden bg-slate-50 dark:bg-slate-800/30 p-2.5 space-y-2">
                  {/* Mini hero */}
                  <div className={`bg-gradient-to-br ${hero.gradient} rounded-lg p-3 relative overflow-hidden`}>
                    <div className="absolute -top-4 -right-4 w-12 h-12 bg-white/5 rounded-full pointer-events-none" />
                    <p className="text-white/50 text-[7px] font-bold uppercase tracking-wider leading-none mb-0.5">Bayi Paneli</p>
                    <p className="text-white font-black text-xs leading-tight">Panel Önizlemesi</p>
                    <p className="text-white/40 text-[7px] mt-0.5">Tema: {hero.label}</p>
                  </div>
                  {/* Widget grid */}
                  {dashLayout.widgets.length > 0 ? (
                    <div className="grid gap-1" style={{ gridTemplateColumns: 'repeat(4, minmax(0, 1fr))' }}>
                      {dashLayout.widgets.map(w => (
                        <div key={w.id} style={{ gridColumn: `span ${Math.min(w.span, 4)}` }}>
                          <WidgetPreviewCard widget={w} hero={hero} />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-slate-400 dark:text-slate-500 text-xs font-medium">
                      Widget ekleyerek önizlemeyi görebilirsiniz.
                    </div>
                  )}
                </div>
                <p className="text-[9px] text-slate-400 dark:text-slate-500 text-center mt-2">
                  Düzenlemeler kaydedilirken önizleme güncellenir
                </p>
              </div>
            </div>

          </div>
        );
      })()}

      {/* ===== İŞLETME BİLGİLERİ SAYFASI ===== */}
      {settingsTab === 'isletme' && (
        <div className="space-y-5">
          {bLoading ? (
            <div className="py-16 flex items-center justify-center text-slate-400 animate-pulse">
              <RefreshCw size={22} className="animate-spin mr-2" /> Yükleniyor...
            </div>
          ) : (
            <>
              {/* Ad Soyad */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-4">
                <p className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                  <UserCircle size={12} /> Kişisel Bilgiler
                </p>
                <div>
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1.5">Ad Soyad</label>
                  <input
                    value={bFullName}
                    onChange={e => setBFullName(e.target.value)}
                    maxLength={255}
                    placeholder="Ad Soyad"
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                  />
                </div>
              </div>

              {/* Şirket Bilgileri */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-4">
                <p className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                  <Building2 size={12} /> İşletme Bilgileri
                </p>
                <div>
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1.5">İşletme / Şirket Adı</label>
                  <input
                    value={bCompanyName}
                    onChange={e => setBCompanyName(e.target.value)}
                    maxLength={255}
                    placeholder="Şirket Adı"
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1.5 flex items-center gap-1"><Phone size={11} /> İşletme Telefonu</label>
                  <input
                    type="tel"
                    value={bCompanyPhone}
                    onChange={e => setBCompanyPhone(e.target.value)}
                    maxLength={50}
                    placeholder="+90 555 000 00 00"
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1.5 flex items-center gap-1"><MapPin size={11} /> İşletme Adresi</label>
                  <textarea
                    value={bCompanyAddress}
                    onChange={e => setBCompanyAddress(e.target.value)}
                    maxLength={500}
                    rows={3}
                    placeholder="Adres..."
                    className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-sm resize-none"
                  />
                </div>
              </div>

              {/* Kaydet */}
              <button
                disabled={bSaving}
                onClick={async () => {
                  if (!bFullName.trim()) { showToast('Ad soyad boş olamaz', 'error'); return; }
                  try {
                    setBSaving(true);
                    await api.put('/auth/profile', {
                      full_name: bFullName.trim(),
                      company_name: bCompanyName.trim() || null,
                      company_phone: bCompanyPhone.trim() || null,
                      company_address: bCompanyAddress.trim() || null,
                    });
                    showToast('İşletme bilgileri kaydedildi');
                  } catch (err: any) {
                    showToast(err.response?.data?.detail || 'Kayıt başarısız', 'error');
                  } finally {
                    setBSaving(false);
                  }
                }}
                className="w-full flex items-center justify-center gap-2 py-3 px-5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white font-bold rounded-xl transition shadow-sm text-sm">
                {bSaving ? <RefreshCw size={15} className="animate-spin" /> : <Save size={15} />}
                {bSaving ? 'Kaydediliyor...' : 'Kaydet'}
              </button>
            </>
          )}
        </div>
      )}

      {/* Widget Düzenle / Ekle Modalı */}
      {(editingWidget || showAddWidget) && (() => {
        const isAdd = showAddWidget && !editingWidget;
        const draft: DashWidget = editingWidget || { id: `w${Date.now()}`, type: 'stat', sources: ['sales'], span: 1, title: 'Yeni Widget' };
        const wDef = WIDGET_DEFS[draft.type];
        const validSources = wDef?.validSources || [];
        const maxSrc = wDef?.maxSources || 1;
        const canAddMore = draft.sources.length < maxSrc;

        const toggleSource = (s: DataSourceId) => {
          const selected = draft.sources.includes(s);
          let next: DataSourceId[];
          if (selected) {
            next = draft.sources.filter(x => x !== s);
            if (!next.length) next = [validSources.find(x => x !== s) || validSources[0]];
          } else {
            if (!canAddMore) return;
            next = [...draft.sources, s];
          }
          setEditingWidget({ ...draft, sources: next.filter(x => validSources.includes(x)) });
        };

        const switchType = (t: WidgetType) => {
          const newValid = WIDGET_DEFS[t].validSources;
          const kept = draft.sources.filter(s => newValid.includes(s));
          const newSources = kept.length ? kept : [newValid[0]];
          setEditingWidget({ ...draft, type: t, sources: newSources });
        };

        const save = () => {
          const validSrcs = draft.sources.filter(s => validSources.includes(s));
          const final: DashWidget = { ...draft, sources: validSrcs.length ? validSrcs : [validSources[0]] };
          if (isAdd) {
            setDashLayout({ ...dashLayout, widgets: [...dashLayout.widgets, final] });
          } else {
            setDashLayout({ ...dashLayout, widgets: dashLayout.widgets.map(w => w.id === final.id ? final : w) });
          }
          setEditingWidget(null);
          setShowAddWidget(false);
        };

        const groups = validSources.reduce((acc, s) => {
          const g = SOURCE_DEFS[s]?.group || 'Diğer';
          if (!acc[g]) acc[g] = [];
          acc[g].push(s);
          return acc;
        }, {} as Record<string, DataSourceId[]>);

        return (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[200] p-4" onClick={() => { setEditingWidget(null); setShowAddWidget(false); }}>
            <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-md flex flex-col max-h-[90svh]" onClick={e => e.stopPropagation()}>
              {/* Header */}
              <div className="px-6 pt-6 pb-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
                <h3 className="font-black text-slate-800 dark:text-white text-lg">{isAdd ? 'Widget Ekle' : 'Widget Düzenle'}</h3>
              </div>

              <div className="flex-1 overflow-y-auto scrollbar-thin px-6 py-5 space-y-5">
                {/* Başlık */}
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1.5">Başlık</label>
                  <input value={draft.title} onChange={e => setEditingWidget({ ...draft, title: e.target.value })}
                    className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-medium" />
                </div>

                {/* Widget Türü */}
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1.5">Widget Türü</label>
                  <div className="grid grid-cols-3 gap-2">
                    {(Object.keys(WIDGET_DEFS) as WidgetType[]).map(t => {
                      const def = WIDGET_DEFS[t];
                      const TIcon = def.icon;
                      const active = draft.type === t;
                      return (
                        <button key={t} onClick={() => switchType(t)}
                          className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 text-[11px] font-bold transition ${active ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300' : 'border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-slate-300 dark:hover:border-slate-600'}`}>
                          <TIcon size={18} />
                          {def.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Veri Kaynakları — çoklu seçim */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase">
                      Veri Kaynakları
                    </label>
                    <span className="text-[10px] text-slate-400 font-medium">
                      {draft.sources.length}/{maxSrc} seçili
                    </span>
                  </div>

                  {/* Seçili kaynaklar — pill'ler */}
                  {draft.sources.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {draft.sources.map((s, i) => {
                        const def = SOURCE_DEFS[s];
                        return (
                          <div key={s} className="flex items-center gap-1.5 text-[11px] font-bold px-2.5 py-1 rounded-full border border-indigo-300 dark:border-indigo-700 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300">
                            <div className="w-2 h-2 rounded-full shrink-0" style={{ background: i === 0 ? '#6366f1' : SERIES_PALETTE[i % SERIES_PALETTE.length] }} />
                            {def?.label}
                            <button onClick={() => toggleSource(s)} className="ml-0.5 text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-200 transition">
                              <X size={10} />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Kaynak seçici grid — gruplu */}
                  <div className="space-y-3 max-h-52 overflow-y-auto scrollbar-thin">
                    {Object.entries(groups).map(([grp, srcs]) => (
                      <div key={grp}>
                        <p className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1.5">{grp}</p>
                        <div className="grid grid-cols-2 gap-1.5">
                          {srcs.map(s => {
                            const sDef = SOURCE_DEFS[s];
                            const SIcon = sDef?.icon || Hash;
                            const selected = draft.sources.includes(s);
                            const disabled = !selected && !canAddMore;
                            return (
                              <button key={s} disabled={disabled} onClick={() => toggleSource(s)}
                                className={`flex items-center gap-2 p-2.5 rounded-xl border-2 text-xs font-bold transition ${
                                  selected
                                    ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300'
                                    : disabled
                                    ? 'border-slate-100 dark:border-slate-800 text-slate-300 dark:text-slate-700 cursor-not-allowed opacity-50'
                                    : 'border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-indigo-300 dark:hover:border-indigo-700 hover:text-indigo-600 dark:hover:text-indigo-400'
                                }`}>
                                {selected
                                  ? <Check size={11} className="shrink-0 text-indigo-500" />
                                  : <SIcon size={11} className="shrink-0" />}
                                <span className="truncate">{sDef?.label}</span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                  {maxSrc > 1 && (
                    <p className="text-[10px] text-slate-400 mt-2">
                      Bu widget türüne max {maxSrc} kaynak eklenebilir.{' '}
                      {maxSrc > 1 && draft.sources.length > 1 && 'Birden fazla kaynak seçildiğinde çakışan grafik veya liste gösterilir.'}
                    </p>
                  )}
                </div>

                {/* Genişlik */}
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase mb-1.5">Genişlik (kolon)</label>
                  <div className="flex gap-2">
                    {([1, 2, 3, 4] as ColSpan[]).map(s => (
                      <button key={s} onClick={() => setEditingWidget({ ...draft, span: s })}
                        className={`flex-1 py-2 rounded-xl border-2 text-sm font-black transition ${draft.span === s ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-300' : 'border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-slate-300 dark:hover:border-slate-600'}`}>
                        {s}
                      </button>
                    ))}
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1.5">4 kolon = tam genişlik, 1 = en küçük</p>
                </div>
              </div>

              {/* Footer */}
              <div className="flex gap-3 px-6 py-4 border-t border-slate-100 dark:border-slate-800 shrink-0">
                <button onClick={() => { setEditingWidget(null); setShowAddWidget(false); }}
                  className="flex-1 py-2.5 text-sm font-bold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition">
                  İptal
                </button>
                <button onClick={save}
                  className="flex-1 py-2.5 text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition">
                  {isAdd ? 'Ekle' : 'Kaydet'}
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* DELETE CONFLICT MODAL — kategoride ürün var */}
      {deleteConflict && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[200] p-4" onClick={() => !deleting && setDeleteConflict(null)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-start gap-3 mb-4">
              <div className="w-10 h-10 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-xl flex items-center justify-center shrink-0">
                <AlertTriangle size={20} />
              </div>
              <div>
                <h3 className="font-black text-slate-800 dark:text-white">Kategoride Ürün Var</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                  <span className="font-bold text-slate-700 dark:text-slate-300">"{deleteConflict.cat.name}"</span> kategorisinde{' '}
                  <span className="font-bold text-red-600 dark:text-red-400">{deleteConflict.count} ürün</span> bulunuyor.
                  Silmeden önce ürünleri taşıyın.
                </p>
              </div>
            </div>
            <div className="space-y-3">
              <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase">Ürünleri Taşı</label>
              <select value={moveToId} onChange={e => setMoveToId(e.target.value ? Number(e.target.value) : '')}
                className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 font-medium">
                <option value="">— Hedef kategori seçin —</option>
                {stokList.filter((c: any) => c.id !== deleteConflict.cat.id).map((c: any) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
              <p className="text-xs text-slate-400">Seçim yapmazsanız ürünler "kategorisiz" kalır.</p>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setDeleteConflict(null)} disabled={deleting}
                className="flex-1 py-3 text-slate-600 dark:text-slate-400 font-bold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition disabled:opacity-50">
                İptal
              </button>
              <button onClick={confirmDeleteWithMove} disabled={deleting}
                className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl transition flex items-center justify-center gap-2 disabled:opacity-50">
                {deleting ? <RefreshCw size={16} className="animate-spin" /> : <Trash size={16} />}
                {deleting ? 'Siliniyor...' : 'Sil ve Taşı'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FORM MODALI */}
      {showForm && (
        <div className="fixed inset-0 bg-slate-900/70 dark:bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center z-[100] p-0 sm:p-4 animate-in fade-in duration-200" onClick={() => setShowForm(false)}>
          <div className="bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-2xl flex flex-col max-h-[92svh] sm:max-h-[calc(100vh-2rem)]" onClick={(e) => e.stopPropagation()}>
            <div className="shrink-0 px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 ${COLOR_PALETTE[formColorIdx]?.bg_class} ${COLOR_PALETTE[formColorIdx]?.color_class} rounded-lg flex items-center justify-center`}>
                  {React.createElement(iconFor(formIcon), { size: 16, strokeWidth: 2.5 })}
                </div>
                <h3 className="text-lg font-black text-slate-800 dark:text-white">
                  {editing ? 'Düzenle' : 'Yeni Kategori'} — {formKind === 'stok' ? 'Stok' : 'Finans'}
                </h3>
              </div>
              <button onClick={() => setShowForm(false)} className="text-slate-400 hover:text-slate-700 dark:hover:text-white p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"><X size={20} /></button>
            </div>

            <div className="flex-1 overflow-y-auto scrollbar-thin">
            <div className="p-6 space-y-5">
              {/* AD */}
              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">Kategori Adı</label>
                <input type="text" value={formName} onChange={(e) => setFormName(e.target.value)} autoFocus
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium"
                  placeholder="Örn: Cam Rüzgarlığı, Yedek Parça, ..." />
              </div>

              {/* İKON */}
              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">İkon Seç</label>
                <div className="relative mb-2">
                  <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                  <input type="text" value={iconSearch} onChange={e => setIconSearch(e.target.value)}
                    placeholder="İkon ara..."
                    className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500 transition" />
                </div>
                <div className="grid grid-cols-6 sm:grid-cols-9 gap-2 max-h-44 overflow-y-auto p-2 bg-slate-50 dark:bg-slate-800/30 rounded-xl border border-slate-200 dark:border-slate-700 scrollbar-thin">
                  {filteredIconNames.length === 0 ? (
                    <div className="col-span-full text-center text-xs text-slate-400 py-4">İkon bulunamadı</div>
                  ) : filteredIconNames.map((name) => {
                    const Ic = iconFor(name);
                    const active = formIcon === name;
                    return (
                      <button key={name} type="button" onClick={() => setFormIcon(name)}
                        title={name}
                        className={`aspect-square flex items-center justify-center rounded-lg transition ${active ? 'bg-indigo-600 text-white shadow' : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 border border-slate-200 dark:border-slate-700'}`}>
                        <Ic size={18} />
                      </button>
                    );
                  })}
                </div>
                <p className="mt-1 text-[11px] text-slate-400">Seçilen: <span className="font-mono font-bold">{formIcon}</span></p>
              </div>

              {/* RENK */}
              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">Renk Seç</label>
                <div className="flex flex-wrap gap-2">
                  {COLOR_PALETTE.map((p, i) => (
                    <button key={p.name} type="button" onClick={() => setFormColorIdx(i)}
                      title={p.name}
                      className={`w-9 h-9 rounded-xl ${p.swatch} flex items-center justify-center transition ${formColorIdx === i ? 'ring-4 ring-offset-2 ring-indigo-500 dark:ring-offset-slate-900 scale-110' : 'hover:scale-110 opacity-80 hover:opacity-100'}`}>
                      {formColorIdx === i && <Check size={16} className="text-white" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* GÖRÜNÜRLÜK */}
              <div>
                <label className="flex items-center gap-3 cursor-pointer select-none">
                  <input type="checkbox" checked={formVisible} onChange={(e) => setFormVisible(e.target.checked)}
                    className="w-5 h-5 rounded accent-indigo-600" />
                  <span className="font-bold text-slate-700 dark:text-slate-300">
                    {formVisible ? 'Görünür' : 'Gizli'}
                  </span>
                  <span className="text-xs text-slate-500">— {formVisible ? 'Sidebar ve ana panelde gösterilir' : 'Menüde görünmez'}</span>
                </label>
              </div>

              {/* GÖRÜNÜM MODU */}
              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2 uppercase">Görünüm Tarzı</label>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                  {VIEW_MODES.map((vm) => {
                    const VmIcon = vm.icon;
                    const active = formViewMode === vm.id;
                    return (
                      <button key={vm.id} type="button" onClick={() => setFormViewMode(vm.id)}
                        title={vm.desc}
                        className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 transition text-center ${active ? 'bg-indigo-50 dark:bg-indigo-900/30 border-indigo-500 text-indigo-700 dark:text-indigo-300 shadow-sm' : 'bg-white dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-indigo-300 dark:hover:border-indigo-700'}`}>
                        <VmIcon size={18} strokeWidth={active ? 2.6 : 2} />
                        <span className="text-[10px] font-bold leading-tight">{vm.label}</span>
                      </button>
                    );
                  })}
                </div>
                <p className="mt-1.5 text-[11px] text-slate-400 italic">{VIEW_MODES.find(v => v.id === formViewMode)?.desc}</p>
              </div>

              {/* FİNANS-ÖZEL ALANLAR */}
              {formKind === 'finans' && (
                <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                  <p className="text-xs font-bold text-slate-400 uppercase">Finans Özellikleri</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">İşlem Tipi</label>
                      <select value={formTxType} onChange={(e) => setFormTxType(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 font-medium">
                        <option value="borç">borç</option>
                        <option value="gider">gider</option>
                        <option value="senet">senet</option>
                        <option value="kredi">kredi</option>
                        <option value="garanti">garanti</option>
                        <option value="tahsilat">tahsilat</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">Bakiye Rengi</label>
                      <select value={formAmountTone} onChange={(e) => setFormAmountTone(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 font-medium">
                        <option value="red">Kırmızı (borç)</option>
                        <option value="amber">Kehribar</option>
                        <option value="indigo">İndigo</option>
                        <option value="purple">Mor</option>
                        <option value="emerald">Zümrüt (tahsilat)</option>
                        <option value="slate">Gri</option>
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">Müşteri/Cari Etiketi</label>
                      <input type="text" value={formCustomerLabel} onChange={(e) => setFormCustomerLabel(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
                        placeholder="Örn: Müşteri Adı, Firma Unvanı" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">Tutar Etiketi</label>
                      <input type="text" value={formAmountLabel} onChange={(e) => setFormAmountLabel(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
                        placeholder="Örn: Borç Tutarı (₺)" />
                    </div>
                  </div>
                </div>
              )}

              {/* ÖNİZLEME */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2 uppercase">Önizleme</label>
                <div className="flex items-center gap-4">
                  {/* Sidebar item preview */}
                  <div className="flex items-center gap-2.5 px-3 py-2 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700">
                    <div className={`w-7 h-7 ${COLOR_PALETTE[formColorIdx]?.bg_class} ${COLOR_PALETTE[formColorIdx]?.color_class} rounded-lg flex items-center justify-center`}>
                      {React.createElement(iconFor(formIcon), { size: 15, strokeWidth: 2.5 })}
                    </div>
                    <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">{formName || 'Kategori Adı'}</span>
                  </div>
                  {/* Card preview */}
                  <div className={`w-14 h-14 ${COLOR_PALETTE[formColorIdx]?.bg_class} ${COLOR_PALETTE[formColorIdx]?.color_class} rounded-2xl flex items-center justify-center shadow-inner`}>
                    {React.createElement(iconFor(formIcon), { size: 26, strokeWidth: 2.5 })}
                  </div>
                </div>
              </div>
            </div>
            </div>

            <div className="shrink-0 flex justify-end gap-3 px-6 py-4 border-t border-slate-100 dark:border-slate-800">
              <button onClick={() => setShowForm(false)} disabled={saving}
                className="px-5 py-3 text-slate-600 dark:text-slate-400 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition disabled:opacity-50">
                İptal
              </button>
              <button onClick={handleSubmit} disabled={saving}
                className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition flex items-center gap-2 disabled:opacity-50">
                <Save size={18} /> {saving ? 'Kaydediliyor...' : 'Kaydet'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// 3.3 İşlem Geçmişi (Kategorili ve Fotoğraflı)
const HistoryLogView = () => {
  const { t } = useAppContext();
  const [filterCategory, setFilterCategory] = useState('Tümü');
  const [selectedImage, setSelectedImage] = useState(null);
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchActivities = async () => {
      try {
        setLoading(true);
        const res = await api.get('/dashboard/activities', { params: { limit: 50 } });
        // Map backend types to frontend icons
        const iconMap = {
          'product': Box,
          'transaction': Wallet,
          'report': FileText,
          'system': Settings,
          'auth': UserCircle,
          'file': ImageIcon
        };
        const colorMap = {
          'product': 'text-blue-500',
          'transaction': 'text-emerald-500',
          'report': 'text-purple-500',
          'system': 'text-slate-500',
          'auth': 'text-amber-500',
          'file': 'text-indigo-500'
        };
        const bgMap = {
          'product': 'bg-blue-100 dark:bg-blue-900/50',
          'transaction': 'bg-emerald-100 dark:bg-emerald-900/50',
          'report': 'bg-purple-100 dark:bg-purple-900/50',
          'system': 'bg-slate-100 dark:bg-slate-900/50',
          'auth': 'bg-amber-100 dark:bg-amber-900/50',
          'file': 'bg-indigo-100 dark:bg-indigo-900/50'
        };

        const mappedLogs = (res.data.items || []).map(log => ({
          id: log.id,
          user: log.user,
          action: log.action,
          detail: log.detail,
          time: new Date(log.time).toLocaleString(),
          type: log.type,
          category: log.category,
          icon: iconMap[log.type] || Activity,
          color: colorMap[log.type] || 'text-slate-500',
          bg: bgMap[log.type] || 'bg-slate-100 dark:bg-slate-900/50',
          image: null // We could attach files if backend supported it in logs
        }));
        setLogs(mappedLogs);
      } catch (error) {
        console.error("Error fetching activities:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchActivities();
  }, []);

  const filteredLogs = filterCategory === 'Tümü' ? logs : logs.filter(log => log.category === filterCategory);

  return (
    <div className="max-w-5xl space-y-6 animate-in slide-in-from-right-4 duration-300">
      <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-xl flex items-center justify-center shrink-0"><History size={24} /></div>
          <div>
            <h2 className="text-2xl font-black text-slate-800 dark:text-white">{t('İşlem Geçmişi')}</h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Sistemdeki tüm hareketler ve değişiklik kayıtları.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2 w-full sm:w-auto flex-wrap">
          <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0 hide-scrollbar">
            {['Tümü', 'İşlem', 'Stok İşlemleri', 'Finans & Cari', 'Sistem Ayarları'].map(cat => (
               <button key={cat} onClick={() => setFilterCategory(cat)} className={`px-4 py-2 rounded-lg text-sm font-bold whitespace-nowrap transition ${filterCategory === cat ? 'bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-400' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800'}`}>
                 {cat}
               </button>
            ))}
          </div>
          <button
            onClick={() => exportAktivite(filteredLogs)}
            disabled={filteredLogs.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded-xl transition text-sm shrink-0"
            title="Excel olarak indir"
          >
            <Download size={15} /> Excel
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm relative">
        <div className="absolute left-10 sm:left-11 top-10 bottom-10 w-0.5 bg-slate-100 dark:bg-slate-800"></div>
        {loading ? (
          <div className="p-12 text-center text-slate-500 animate-pulse">{t('Veriler Yükleniyor...')}</div>
        ) : filteredLogs.length > 0 ? (
        <div className="space-y-8 relative z-10">
          {filteredLogs.map(log => (
            <div key={log.id} className="flex gap-4 sm:gap-6 group">
              <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center shrink-0 ${log.bg} ${log.color} ring-4 ring-white dark:ring-slate-900 shadow-sm mt-1 transition-transform group-hover:scale-110`}>
                <log.icon size={20} />
              </div>
              <div className="flex-1 bg-slate-50 dark:bg-slate-800/50 p-4 sm:p-5 rounded-2xl border border-slate-100 dark:border-slate-800 hover:border-indigo-200 dark:hover:border-indigo-800/50 transition-colors">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-800 dark:text-white">{log.action}</span>
                    <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded">{log.category}</span>
                  </div>
                  <span className="text-xs font-bold text-slate-400 flex items-center gap-1"><Clock size={12}/> {log.time}</span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed mb-3">{log.detail}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
                    <div className="w-5 h-5 bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 rounded-full flex items-center justify-center font-bold">{log.user.charAt(0)}</div>
                    {log.user}
                  </div>
                  {log.image && (
                     <button onClick={() => setSelectedImage(log.image)} className="flex items-center gap-1 text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline">
                       <ImageIcon size={14}/> Görseli İncele
                     </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
        ) : (
          <div className="p-12 text-center text-slate-500">{t('İşlem geçmişi bulunamadı.')}</div>
        )}
      </div>

      {selectedImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm" onClick={() => setSelectedImage(null)}>
           <div className="relative max-w-3xl w-full bg-white dark:bg-slate-900 rounded-2xl overflow-hidden shadow-2xl p-2" onClick={e => e.stopPropagation()}>
              <img src={selectedImage} alt="İşlem Detayı" className="w-full h-auto rounded-xl max-h-[80vh] object-contain bg-slate-100 dark:bg-slate-800" />
              <button onClick={() => setSelectedImage(null)} className="absolute top-4 right-4 w-10 h-10 bg-black/50 text-white rounded-full flex items-center justify-center hover:bg-black/70 transition">
                 <X size={24} />
              </button>
           </div>
        </div>
      )}
    </div>
  );
};

// 3.4 Cari Detay Görünümü (Belge/Fotoğraflı)
const CariDetailView = ({ cari, onBack, moduleTitle, permissions }) => {
  const { showToast } = useAppContext();
  const [isTxModalOpen, setTxModalOpen] = useState(false);
  const [txType, setTxType] = useState('borc');
  const [txImagePreview, setTxImagePreview] = useState(null);
  const [txImageFile, setTxImageFile] = useState<File | null>(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [cariLoading, setCariLoading] = useState(true);
  const [cariTxAmount, setCariTxAmount] = useState('');
  const [cariTxDesc, setCariTxDesc] = useState('');
  const [cariTxSaving, setCariTxSaving] = useState(false);

  const mapTxItems = (items) => {
    const sorted = [...items].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
    let runningBalance = 0;
    return sorted.map(tx => {
      const isDebt = ['borç','debt','gider','senet','kredi','garanti'].includes(tx.transaction_type);
      const borc = isDebt ? tx.amount : 0;
      const alacak = isDebt ? 0 : tx.amount;
      runningBalance += borc - alacak;
      return { id: tx.id, date: new Date(tx.created_at).toLocaleDateString('tr-TR'), desc: tx.notes || tx.transaction_type, borc, alacak, bakiye: runningBalance, image: tx.image_url || null };
    }).reverse();
  };

  const loadCariTx = async (silent = false) => {
    try {
      if (!silent) setCariLoading(true);
      const params: any = { customer_name: cari.title, exact_customer: true, days: 3650, page_size: 100 };
      if (cari.ledgerType) params.ledger_type = cari.ledgerType;
      const res = await api.get('/finance/transactions', { params });
      setTransactions(mapTxItems(res.data.items || []));
    } catch (err) {
      console.error('Cari tx error:', err);
    } finally {
      setCariLoading(false);
    }
  };

  useEffect(() => { loadCariTx(); }, [cari.title]);
  useRefreshOnChange(loadCariTx);

  const handleCariTxSave = async () => {
    const amt = parseFloat(cariTxAmount);
    if (isNaN(amt) || amt <= 0) { showToast('Geçerli bir tutar girin', 'error'); return; }
    try {
      setCariTxSaving(true);
      const debtType = (cari.ledgerType && ['borç','gider','senet','kredi'].includes(cari.ledgerType))
        ? cari.ledgerType
        : 'borç';
      const res = await api.post('/finance/transactions', {
        transaction_type: txType === 'borc' ? debtType : 'ödeme',
        customer_name: cari.title,
        amount: amt,
        currency: cari.currency || 'TRY',
        notes: cariTxDesc.trim() || null,
      });
      const txId = res.data?.transaction?.id;
      if (txImageFile && txId) {
        const fd = new FormData();
        fd.append('file', txImageFile);
        try {
          await api.post(`/files/transaction/${txId}/attachment`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
        } catch (imgErr) {
          console.warn('Belge yüklenemedi:', imgErr);
        }
      }
      showToast('İşlem kaydedildi');
      setCariTxAmount('');
      setCariTxDesc('');
      setTxImagePreview(null);
      setTxImageFile(null);
      setTxModalOpen(false);
      await loadCariTx();
    } catch (err: any) {
      showToast('Hata: ' + (err.response?.data?.detail || err.message), 'error');
    } finally {
      setCariTxSaving(false);
    }
  };

  const handleOpenModal = (type) => {
    setTxType(type);
    setTxImagePreview(null);
    setTxImageFile(null);
    setCariTxAmount('');
    setCariTxDesc('');
    setTxModalOpen(true);
  };

  const handleImageUpload = (e) => {
    if (e.target.files && e.target.files[0]) {
      const f = e.target.files[0];
      setTxImageFile(f);
      setTxImagePreview(URL.createObjectURL(f));
    }
  };

  return (
    <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 rounded-xl transition hover:bg-slate-100 dark:hover:bg-slate-700"><ArrowLeft size={20} /></button>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-800 dark:text-white">{cari.title}</h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">{moduleTitle} / GSM: <span className="text-indigo-600 dark:text-indigo-400 font-bold">{cari.phone}</span> / VKN: {cari.vkn}</p>
          </div>
        </div>
        <div className="flex gap-2 w-full sm:w-auto flex-wrap">
          <button
            onClick={() => exportCariDetay(transactions, cari.title)}
            disabled={transactions.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded-xl transition text-sm shrink-0"
            title="Excel olarak indir"
          >
            <Download size={15} /> Excel
          </button>
          {permissions?.canAdd && (
            <>
              <button onClick={() => handleOpenModal('tahsilat')} className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 font-bold rounded-xl hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition border border-emerald-100 dark:border-emerald-800/50"><MinusCircle size={18} /> Tahsilat Gir</button>
              <button onClick={() => handleOpenModal('borc')} className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-400 font-bold rounded-xl hover:bg-red-100 dark:hover:bg-red-900/50 transition border border-red-100 dark:border-red-800/50"><PlusCircle size={18} /> Borçlandır</button>
            </>
          )}
        </div>
      </div>
      
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-left border-collapse min-w-[700px]">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 text-xs uppercase border-b border-slate-200 dark:border-slate-700 tracking-wider">
                <th className="p-4 pl-6 font-bold">İşlem Tarihi</th>
                <th className="p-4 font-bold">Açıklama / İşlem Özeti</th>
                <th className="p-4 font-bold text-center">Belge</th>
                <th className="p-4 font-bold text-red-500">Borç (₺)</th>
                <th className="p-4 font-bold text-emerald-500">Alacak (₺)</th>
                <th className="p-4 pr-6 font-bold text-right text-indigo-600 dark:text-indigo-400">Güncel Bakiye</th>
              </tr>
            </thead>
            <tbody>
              {cariLoading ? (
                <tr><td colSpan={6} className="p-12 text-center text-slate-500 animate-pulse">Yükleniyor...</td></tr>
              ) : transactions.length === 0 ? (
                <tr><td colSpan={6} className="p-12 text-center text-slate-500">Bu cariye ait işlem bulunamadı.</td></tr>
              ) : transactions.map((tx, idx) => (
                <tr key={tx.id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                  <td className="p-4 pl-6 text-slate-600 dark:text-slate-400 font-medium">{tx.date}</td>
                  <td className="p-4 font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                    {tx.borc > 0 ? <PlusCircle size={14} className="text-red-400"/> : <MinusCircle size={14} className="text-emerald-400"/>}
                    {tx.desc}
                  </td>
                  <td className="p-4 text-center">
                    {tx.image ? (
                       <button onClick={() => setSelectedImage(tx.image)} className="p-1.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 rounded-lg transition" title="Görseli İncele">
                          <ImageIcon size={18} />
                       </button>
                    ) : (
                       <span className="text-slate-300 dark:text-slate-700">-</span>
                    )}
                  </td>
                  <td className="p-4 text-red-600 dark:text-red-400 font-bold bg-red-50/30 dark:bg-red-900/10">{tx.borc > 0 ? formatMoney(tx.borc) : '-'}</td>
                  <td className="p-4 text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-50/30 dark:bg-emerald-900/10">{tx.alacak > 0 ? formatMoney(tx.alacak) : '-'}</td>
                  <td className="p-4 pr-6 text-right font-black text-slate-800 dark:text-white">{formatMoney(tx.bakiye)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedImage && (
        <div className="fixed inset-0 bg-slate-900/80 dark:bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-[100]" onClick={() => setSelectedImage(null)}>
           <div className="relative max-w-3xl w-full flex flex-col items-center animate-in zoom-in-95" onClick={e => e.stopPropagation()}>
              <div className="w-full flex justify-end mb-4">
                 <button onClick={() => setSelectedImage(null)} className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white backdrop-blur transition"><X size={24}/></button>
              </div>
              <img src={selectedImage} alt="İşlem Görseli" className="w-full h-auto max-h-[80vh] object-contain rounded-xl shadow-2xl" />
           </div>
        </div>
      )}

      {isTxModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 dark:bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 z-[100]">
          <div className="bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl max-w-md w-full animate-in slide-in-from-bottom-4 sm:zoom-in-95 duration-200 shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[92svh] sm:max-h-[calc(100vh-2rem)]">
            <div className="shrink-0 flex items-center justify-between px-5 sm:px-6 pt-5 sm:pt-6 pb-4 border-b border-slate-100 dark:border-slate-800">
              <h3 className={`text-xl font-black ${txType === 'borc' ? 'text-red-600 dark:text-red-400' : 'text-emerald-600 dark:text-emerald-400'} flex items-center gap-2`}>
                {txType === 'borc' ? <PlusCircle/> : <MinusCircle/>}
                {txType === 'borc' ? 'Yeni Borç Kaydı' : 'Tahsilat Ekle'}
              </h3>
              <button onClick={() => setTxModalOpen(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-lg"><X size={20}/></button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 sm:px-6 py-4 scrollbar-thin">
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase">İşlem Tutarı (₺)</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-slate-400">₺</span>
                  <input type="number" value={cariTxAmount} onChange={e => setCariTxAmount(e.target.value)} className={`w-full pl-8 pr-4 py-3 bg-slate-50 dark:bg-slate-800/50 border rounded-xl outline-none transition font-bold text-lg dark:text-white ${txType === 'borc' ? 'focus:border-red-500 focus:ring-2 focus:ring-red-200 dark:focus:ring-red-900 border-red-100 dark:border-red-900/30' : 'focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 dark:focus:ring-emerald-900 border-emerald-100 dark:border-emerald-900/30'}`} placeholder="0.00" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase">Açıklama</label>
                <input type="text" value={cariTxDesc} onChange={e => setCariTxDesc(e.target.value)} className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium" placeholder="İşlem detayı yazın..." />
              </div>
              <div>
                 <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase">İşlem Tarihi</label>
                 <input type="date" defaultValue={new Date().toISOString().split('T')[0]} className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium" />
              </div>

              <div className="pt-2">
                 <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2 uppercase">Belge / Fatura (Opsiyonel)</label>
                 {!txImagePreview ? (
                    <div className="border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl p-6 flex flex-col items-center justify-center text-center bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer relative">
                       <UploadCloud size={32} className="text-indigo-400 dark:text-indigo-500 mb-2"/>
                       <p className="text-sm font-bold text-slate-700 dark:text-slate-300">Fotoğraf Çek veya Yükle</p>
                       <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Sadece görsel formatları</p>
                       <input type="file" accept="image/*" onChange={handleImageUpload} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                    </div>
                 ) : (
                    <div className="relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 group">
                       <img src={txImagePreview} alt="Önizleme" className="w-full h-40 object-cover opacity-90" />
                       <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
                          <button onClick={() => setTxImagePreview(null)} className="px-4 py-2 bg-red-600 text-white font-bold rounded-lg text-sm flex items-center gap-2"><Trash size={16}/> Kaldır</button>
                       </div>
                    </div>
                 )}
              </div>
            </div>
            </div>{/* /scrollable content */}

            <div className="shrink-0 flex justify-end gap-3 px-5 sm:px-6 py-4 border-t border-slate-100 dark:border-slate-800">
              <button onClick={() => setTxModalOpen(false)} disabled={cariTxSaving} className="px-5 py-2.5 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition font-bold disabled:opacity-50">İptal</button>
              <button onClick={handleCariTxSave} disabled={cariTxSaving} className={`px-6 py-2.5 text-white rounded-xl font-bold transition shadow-lg disabled:opacity-50 ${txType === 'borc' ? 'bg-red-600 hover:bg-red-700 shadow-red-200 dark:shadow-red-900/20' : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200 dark:shadow-emerald-900/20'}`}>{cariTxSaving ? 'Kaydediliyor...' : 'Kaydet ve İşle'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// 3.5 Çalışan Yönetimi — granüler izinler
// İzin formatı:
//   "dashboard"
//   "products.<view|add|edit|delete>"
//   "finance.<veresiye|firma|senet|kredi|kasa|garanti>.<view|add|edit|delete>"
//   "reports.view", "profile.view"
type ActionKey = 'view' | 'add' | 'edit' | 'delete' | 'view_cost';
const PRODUCT_ACTIONS: ActionKey[] = ['view', 'add', 'edit', 'delete', 'view_cost'];
const FINANCE_TYPE_KEYS = ['veresiye', 'firma', 'senet', 'kredi', 'kasa', 'garanti'] as const;
type FinanceTypeKey = typeof FINANCE_TYPE_KEYS[number];
const FINANCE_ACTIONS: ActionKey[] = ['view', 'add', 'edit', 'delete'];

// Backend'deki transaction_type → permission alt-tip eşlemesi
const FINANCE_TXTYPE_TO_KEY: Record<string, FinanceTypeKey> = {
  'borç': 'veresiye', 'borc': 'veresiye',
  'gider': 'firma', 'expense': 'firma',
  'senet': 'senet',
  'kredi': 'kredi',
  'garanti': 'garanti',
};
const financeKeyOf = (transactionType: string | null | undefined): FinanceTypeKey => {
  if (transactionType == null || transactionType === '') return 'kasa';
  return FINANCE_TXTYPE_TO_KEY[transactionType] || 'kasa';
};

const ACTION_LABEL: Record<ActionKey, string> = {
  view: 'Görüntüle', add: 'Ekle', edit: 'Düzenle', delete: 'Sil', view_cost: 'Alış Fiyatı',
};

const FINANCE_TYPE_LABEL: Record<FinanceTypeKey, string> = {
  veresiye: 'Veresiye Defteri',
  firma:    'Firma Borcu / Gider',
  senet:    'Senet Defteri',
  kredi:    'Kredi Defteri',
  kasa:     'Kasa Defteri',
  garanti:  'Garanti Defteri',
};

// Düz etiketler (yetki rozeti vs için)
const PERMISSION_LABELS: Record<string, string> = {
  dashboard:      'Ana Panel',
  'reports.view': 'Gelişmiş Raporlar',
  'profile.view': 'Profilim',
};
const BTB_ACTIONS: ActionKey[] = ['view', 'add', 'edit', 'delete'];
const SUPPLIER_ACTIONS: ActionKey[] = ['view', 'add', 'edit', 'delete'];
const PLASIYER_ACTIONS: ActionKey[] = ['view', 'manage'] as any;
const INTEGRATIONS_ACTIONS: ActionKey[] = ['view', 'add', 'edit', 'delete'];

PRODUCT_ACTIONS.forEach(a => { PERMISSION_LABELS[`products.${a}`] = `Stok – ${ACTION_LABEL[a]}`; });
FINANCE_TYPE_KEYS.forEach(t => FINANCE_ACTIONS.forEach(a => {
  PERMISSION_LABELS[`finance.${t}.${a}`] = `${FINANCE_TYPE_LABEL[t]} – ${ACTION_LABEL[a]}`;
}));
BTB_ACTIONS.forEach(a => { PERMISSION_LABELS[`btb.${a}`] = `B2B Sipariş – ${ACTION_LABEL[a]}`; });
SUPPLIER_ACTIONS.forEach(a => { PERMISSION_LABELS[`supplier.${a}`] = `Toptancı/Tedarikçi – ${ACTION_LABEL[a]}`; });
PERMISSION_LABELS['plasiyer.view'] = 'Plasiyer – Görüntüle';
PERMISSION_LABELS['plasiyer.manage'] = 'Plasiyer – Ziyaret/Plan Yönet';
INTEGRATIONS_ACTIONS.forEach(a => { PERMISSION_LABELS[`integrations.${a}`] = `Entegrasyonlar – ${ACTION_LABEL[a]}`; });

// UI grup yapısı — EmployeeManagementView'da kart-kart render edilir
type PermGroup = { key: string; label: string; description: string; perms: string[]; actions?: ActionKey[] };
const PERMISSION_GROUPS: PermGroup[] = [
  { key: 'dashboard', label: 'Ana Panel', description: 'Genel özet ve günlük istatistikler.', perms: ['dashboard'] },
  { key: 'products',  label: 'Stok / Ürünler', description: 'Tüm stok kategorileri (ürün listeleri, ekleme, düzenleme, silme).', perms: PRODUCT_ACTIONS.map(a => `products.${a}`), actions: PRODUCT_ACTIONS },
  ...FINANCE_TYPE_KEYS.map((t): PermGroup => ({
    key: `finance.${t}`, label: FINANCE_TYPE_LABEL[t],
    description: t === 'kasa' ? 'Tüm gelir/gider kayıtları (Kasa Defteri).' : 'İşlem ekleme, düzenleme, silme yetkileri.',
    perms: FINANCE_ACTIONS.map(a => `finance.${t}.${a}`), actions: FINANCE_ACTIONS,
  })),
  { key: 'btb', label: 'B2B Sipariş', description: 'Kurumsal müşteri siparişleri, stok ve tahsilat yönetimi.', perms: BTB_ACTIONS.map(a => `btb.${a}`), actions: BTB_ACTIONS },
  { key: 'supplier', label: 'Toptancı / Tedarikçi', description: 'Toptancıdan alım siparişleri, mal kabul ve borç takibi.', perms: SUPPLIER_ACTIONS.map(a => `supplier.${a}`), actions: SUPPLIER_ACTIONS },
  { key: 'plasiyer', label: 'Plasiyer / Saha Satış', description: 'Müşteri ziyareti, GPS check-in/out ve plan yönetimi.', perms: ['plasiyer.view', 'plasiyer.manage'] },
  { key: 'integrations', label: 'Entegrasyonlar', description: 'ERP webhook, sanal POS ve DBS banka entegrasyonu.', perms: INTEGRATIONS_ACTIONS.map(a => `integrations.${a}`), actions: INTEGRATIONS_ACTIONS },
  { key: 'reports', label: 'Gelişmiş Raporlar', description: 'Finansal raporlar ve performans grafikleri.', perms: ['reports.view'] },
  { key: 'profile', label: 'Profilim', description: 'Personelin kendi adı/şifresi (genelde açık tutun).', perms: ['profile.view'] },
];

const ALL_PERMISSIONS: string[] = PERMISSION_GROUPS.flatMap(g => g.perms);

// Yetki kontrol yardımcıları
const isOwner = (u: any) => !!u && (u.role === 'bayi_sahibi' || u.isSuperAdmin) && !u.parent_user_id;
// Legacy fallback: eski "products" / "finance" / "reports" / "profile" stringleri
// kullanıcının izin listesinde kalmışsa, granüler izin sorgularını da karşılasın.
const _expandLegacyPerm = (perm: string, list: string[]): boolean => {
  if (list.includes('products') && perm.startsWith('products.')) return true;
  if (list.includes('finance') && perm.startsWith('finance.')) return true;
  if (list.includes('reports') && perm === 'reports.view') return true;
  if (list.includes('profile') && perm === 'profile.view') return true;
  return false;
};
const hasPerm = (u: any, perm: string) => {
  if (isOwner(u)) return true;
  const list: string[] = Array.isArray(u?.permissions) ? u.permissions : [];
  if (list.includes(perm)) return true;
  return _expandLegacyPerm(perm, list);
};
const hasAnyPerm = (u: any, perms: string[]) => perms.some(p => hasPerm(u, p));

const EmployeeManagementView = () => {
  const { showToast } = useAppContext();
  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<any | null>(null); // {kind, id, ...}
  const [empEmail, setEmpEmail] = useState('');
  const [empName, setEmpName] = useState('');
  const [empPerms, setEmpPerms] = useState<string[]>(['dashboard', 'products', 'finance']);
  const [editPerms, setEditPerms] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [rows, setRows] = useState<any[]>([]);
  const [allowed, setAllowed] = useState<string[]>(ALL_PERMISSIONS);

  const loadEmployees = useCallback(async () => {
    try {
      setLoading(true);
      const res = await api.get('/auth/employees');
      setRows(res.data.items || []);
      if (Array.isArray(res.data.allowed_permissions)) setAllowed(res.data.allowed_permissions);
    } catch (err: any) {
      showToast(err.response?.data?.detail || 'Personel listesi yüklenemedi', 'error');
    } finally { setLoading(false); }
  }, [showToast]);

  useEffect(() => { loadEmployees(); }, [loadEmployees]);

  const togglePerm = (list: string[], setList: (v: string[]) => void, perm: string) => {
    if (list.includes(perm)) setList(list.filter(p => p !== perm));
    else setList([...list, perm]);
  };

  const submitInvite = async () => {
    if (!empEmail.trim() || !empName.trim()) { showToast('E-posta ve isim zorunludur', 'error'); return; }
    if (!empEmail.includes('@')) { showToast('Geçerli bir e-posta giriniz', 'error'); return; }
    try {
      setSaving(true);
      await api.post('/auth/employees', {
        email: empEmail.trim(),
        full_name: empName.trim(),
        permissions: empPerms,
      });
      showToast(`${empName.trim()} davet edildi. Personel bu e-posta ile kayıt olduğunda hesabı otomatik bağlanacak.`);
      setIsInviteOpen(false);
      setEmpEmail(''); setEmpName(''); setEmpPerms(['dashboard', 'products', 'finance']);
      loadEmployees();
    } catch (err: any) {
      showToast(err.response?.data?.detail || 'Personel daveti oluşturulamadı', 'error');
    } finally { setSaving(false); }
  };

  const submitPermsUpdate = async () => {
    if (!editTarget) return;
    try {
      setSaving(true);
      const url = editTarget.kind === 'invite'
        ? `/auth/employees/invite/${editTarget.id}/permissions`
        : `/auth/employees/${editTarget.id}/permissions`;
      await api.patch(url, { permissions: editPerms });
      showToast('Yetkiler güncellendi');
      setEditTarget(null);
      loadEmployees();
    } catch (err: any) {
      showToast(err.response?.data?.detail || 'Yetkiler güncellenemedi', 'error');
    } finally { setSaving(false); }
  };

  const removeRow = async (row: any) => {
    const msg = row.kind === 'invite'
      ? `${row.full_name || row.email} için bekleyen davet iptal edilecek. Onaylıyor musunuz?`
      : `${row.full_name || row.email} hesabı pasifleştirilecek (artık giriş yapamayacak). Onaylıyor musunuz?`;
    if (!window.confirm(msg)) return;
    try {
      const url = row.kind === 'invite'
        ? `/auth/employees/invite/${row.id}`
        : `/auth/employees/${row.id}`;
      await api.delete(url);
      showToast(row.kind === 'invite' ? 'Davet iptal edildi' : 'Hesap pasifleştirildi');
      loadEmployees();
    } catch (err: any) {
      showToast(err.response?.data?.detail || 'İşlem başarısız', 'error');
    }
  };

  const statusBadge = (row: any) => {
    if (row.kind === 'invite') {
      return <span className="px-3 py-1 rounded-lg text-xs font-bold border bg-amber-50 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-800">Davet Bekliyor</span>;
    }
    if (row.status === 'active') {
      return <span className="px-3 py-1 rounded-lg text-xs font-bold border bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800">Aktif</span>;
    }
    return <span className="px-3 py-1 rounded-lg text-xs font-bold border bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700">Pasif</span>;
  };

  const PermBox = ({ list, setList }: { list: string[]; setList: (v: string[]) => void }) => {
    // Sadece backend'in izin verdiği grupları göster
    const visibleGroups = PERMISSION_GROUPS
      .map(g => ({ ...g, perms: g.perms.filter(p => allowed.includes(p)) }))
      .filter(g => g.perms.length > 0);

    const toggleOne = (perm: string, checked: boolean) => {
      const next = new Set(list);
      if (checked) next.add(perm); else next.delete(perm);
      // Akıllı bağlama: add/edit/delete seçiliyse view'ı otomatik aç (kullanım kolaylığı)
      if (checked && /\.(add|edit|delete)$/.test(perm)) {
        const viewPerm = perm.replace(/\.(add|edit|delete)$/, '.view');
        if (allowed.includes(viewPerm)) next.add(viewPerm);
      }
      setList(Array.from(next));
    };
    const toggleGroupAll = (g: typeof visibleGroups[number], checked: boolean) => {
      const next = new Set(list);
      g.perms.forEach(p => { if (checked) next.add(p); else next.delete(p); });
      setList(Array.from(next));
    };
    const toggleAllAll = (checked: boolean) => {
      setList(checked ? [...allowed] : []);
    };

    const allSelected = allowed.length > 0 && allowed.every(p => list.includes(p));

    return (
      <div className="space-y-3">
        {/* HEPSİNİ SEÇ MASTER */}
        <label className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition ${allSelected ? 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-300 dark:border-emerald-700' : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 hover:border-emerald-200'}`}>
          <input type="checkbox" checked={allSelected} onChange={e => toggleAllAll(e.target.checked)} className="w-4 h-4 accent-emerald-600" />
          <span className="text-sm font-black text-slate-700 dark:text-slate-200">Tüm yetkileri ver (Patron eşdeğeri)</span>
        </label>

        {visibleGroups.map(g => {
          const groupActions = (g.actions && g.actions.length > 0) ? g.actions : (['view'] as ActionKey[]);
          const groupAllOn = g.perms.every(p => list.includes(p));
          const someOn = g.perms.some(p => list.includes(p));
          return (
            <div key={g.key} className={`p-4 rounded-xl border ${someOn ? 'bg-indigo-50/40 dark:bg-indigo-900/10 border-indigo-200 dark:border-indigo-800' : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700'}`}>
              <div className="flex items-start justify-between gap-3 mb-3">
                <div>
                  <p className="text-sm font-black text-slate-800 dark:text-white">{g.label}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{g.description}</p>
                </div>
                <label className="flex items-center gap-2 shrink-0 cursor-pointer">
                  <input type="checkbox" checked={groupAllOn} onChange={e => toggleGroupAll(g, e.target.checked)} className="w-4 h-4 accent-indigo-600" />
                  <span className="text-xs font-bold text-indigo-700 dark:text-indigo-300">Hepsi</span>
                </label>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {groupActions.map(act => {
                  const perm = g.perms.find(p => p.endsWith(`.${act}`)) || (g.perms.length === 1 ? g.perms[0] : null);
                  if (!perm || !allowed.includes(perm)) return null;
                  const on = list.includes(perm);
                  return (
                    <label key={perm} className={`flex items-center gap-2 px-3 py-2 rounded-lg border cursor-pointer transition ${on ? 'bg-indigo-100 dark:bg-indigo-900/40 border-indigo-300 dark:border-indigo-600' : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 hover:border-indigo-200'}`}>
                      <input type="checkbox" checked={on} onChange={e => toggleOne(perm, e.target.checked)} className="w-4 h-4 accent-indigo-600" />
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{ACTION_LABEL[act] || act}</span>
                    </label>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-4">
           <div className="w-12 h-12 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-xl flex items-center justify-center shrink-0"><Users size={24} /></div>
           <div>
             <h2 className="text-2xl font-black text-slate-800 dark:text-white">Personel Yönetimi</h2>
             <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">E-posta ile davet edin, hangi sayfalara erişeceklerini siz belirleyin.</p>
           </div>
        </div>
        <button onClick={() => setIsInviteOpen(true)} className="flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 transition text-white font-bold rounded-xl w-full sm:w-auto justify-center shadow-md shadow-indigo-200 dark:shadow-indigo-900/20">
          <UserPlus size={18} /> Yeni Personel Davet Et
        </button>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 text-xs uppercase border-b border-slate-200 dark:border-slate-700 tracking-wider">
                <th className="p-4 pl-6 font-bold">Personel Adı</th>
                <th className="p-4 font-bold">E-Posta</th>
                <th className="p-4 font-bold">Yetkili Sayfa Sayısı</th>
                <th className="p-4 font-bold">Durum</th>
                <th className="p-4 pr-6 font-bold text-right">İşlemler</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={5} className="p-12 text-center text-slate-400 text-sm">Yükleniyor...</td></tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan={5} className="p-12 text-center text-slate-400 text-sm">Henüz personel davet edilmedi. "Yeni Personel Davet Et" butonuyla başlayın.</td></tr>
              ) : rows.map((row: any) => (
                <tr key={`${row.kind}-${row.id}`} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                  <td className="p-4 pl-6 font-black text-slate-800 dark:text-white">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 flex items-center justify-center text-xs font-bold">{(row.full_name || '?').charAt(0).toUpperCase()}</div>
                      {row.full_name || '—'}
                    </div>
                  </td>
                  <td className="p-4 text-slate-600 dark:text-slate-400 font-medium">{row.email}</td>
                  <td className="p-4 text-slate-600 dark:text-slate-400 font-medium">{(row.permissions || []).length} / {allowed.length}</td>
                  <td className="p-4">{statusBadge(row)}</td>
                  <td className="p-4 pr-6 text-right">
                    <div className="flex justify-end gap-2">
                      <button onClick={() => { setEditTarget(row); setEditPerms(Array.isArray(row.permissions) ? [...row.permissions] : []); }} className="text-indigo-600 dark:text-indigo-400 font-bold text-xs flex items-center gap-1 px-3 py-2 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition"><Settings size={14}/> Yetkileri Düzenle</button>
                      <button onClick={() => removeRow(row)} className="text-red-600 dark:text-red-400 font-bold text-xs flex items-center gap-1 px-3 py-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 transition"><X size={14}/> {row.kind === 'invite' ? 'İptal' : 'Sil'}</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* DAVET MODAL */}
      {isInviteOpen && (
        <div className="fixed inset-0 bg-slate-900/60 dark:bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 z-[100]">
           <div className="bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl max-w-2xl w-full animate-in slide-in-from-bottom-4 sm:zoom-in-95 shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[92svh] sm:max-h-[calc(100vh-2rem)]">
              <div className="shrink-0 flex justify-between items-center px-5 sm:px-8 pt-5 sm:pt-7 pb-4 border-b border-slate-100 dark:border-slate-800">
                <h3 className="text-xl font-black text-slate-800 dark:text-white flex items-center gap-2"><UserPlus className="text-indigo-600 dark:text-indigo-400"/> Sisteme Personel Davet Et</h3>
                <button onClick={() => setIsInviteOpen(false)} className="text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 p-2 rounded-xl"><X size={20}/></button>
              </div>
              <div className="flex-1 overflow-y-auto px-5 sm:px-8 py-5 scrollbar-thin">
              <div className="space-y-5">
                <div className="p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl text-amber-800 dark:text-amber-300 text-sm">
                  Personel kendi şifresini, vereceğiniz e-posta ile kayıt olurken belirleyecek. Hesabı otomatik olarak firmanıza bağlanır.
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2 uppercase">Ad Soyad</label>
                  <input type="text" value={empName} onChange={e => setEmpName(e.target.value)} className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium" placeholder="Ahmet Yılmaz" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2 uppercase">Personelin E-Posta Adresi</label>
                  <input type="email" value={empEmail} onChange={e => setEmpEmail(e.target.value)} className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium" placeholder="personel@sirketiniz.com" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2 uppercase">Erişebileceği Sayfalar</label>
                  <PermBox list={empPerms} setList={setEmpPerms} />
                </div>
              </div>
              </div>{/* /scrollable content */}
              <div className="shrink-0 flex justify-end gap-3 px-5 sm:px-8 py-4 border-t border-slate-100 dark:border-slate-800">
                <button onClick={() => setIsInviteOpen(false)} disabled={saving} className="px-5 py-2.5 text-slate-600 dark:text-slate-400 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition">Vazgeç</button>
                <button disabled={saving} onClick={submitInvite} className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold flex items-center gap-2 disabled:opacity-50">{saving ? 'Gönderiliyor...' : 'Daveti Oluştur'} <ArrowRight size={16}/></button>
              </div>
           </div>
        </div>
      )}

      {/* YETKİ DÜZENLEME MODAL */}
      {editTarget && (
        <div className="fixed inset-0 bg-slate-900/60 dark:bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 z-[100]">
           <div className="bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl max-w-2xl w-full animate-in slide-in-from-bottom-4 sm:zoom-in-95 shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[92svh] sm:max-h-[calc(100vh-2rem)]">
              <div className="shrink-0 flex justify-between items-center px-5 sm:px-8 pt-5 sm:pt-7 pb-4 border-b border-slate-100 dark:border-slate-800">
                <h3 className="text-xl font-black text-slate-800 dark:text-white flex items-center gap-2"><Settings className="text-indigo-600 dark:text-indigo-400"/> Yetkileri Düzenle</h3>
                <button onClick={() => setEditTarget(null)} className="text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 p-2 rounded-xl"><X size={20}/></button>
              </div>
              <div className="flex-1 overflow-y-auto px-5 sm:px-8 py-5 scrollbar-thin">
              <div className="space-y-5">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
                  <p className="text-sm font-bold text-slate-700 dark:text-slate-200">{editTarget.full_name || '—'}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{editTarget.email}</p>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2 uppercase">Erişebileceği Sayfalar</label>
                  <PermBox list={editPerms} setList={setEditPerms} />
                </div>
              </div>
              </div>{/* /scrollable content */}
              <div className="shrink-0 flex justify-end gap-3 px-5 sm:px-8 py-4 border-t border-slate-100 dark:border-slate-800">
                <button onClick={() => setEditTarget(null)} disabled={saving} className="px-5 py-2.5 text-slate-600 dark:text-slate-400 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition">Vazgeç</button>
                <button disabled={saving} onClick={submitPermsUpdate} className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold flex items-center gap-2 disabled:opacity-50">{saving ? 'Kaydediliyor...' : 'Yetkileri Kaydet'} <ArrowRight size={16}/></button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
}

// 3.55 Yedekleme Sistemi (Bayi)
const BackupView = () => {
  const { t, showToast } = useAppContext();
  const [backups, setBackups] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<any>(null);
  const [confirmRestore, setConfirmRestore] = useState<File | null>(null);
  const [backupLimit] = useState({ max: 3 });
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const loadBackups = async () => {
    setLoading(true);
    try {
      const r = await api.get('/backup/list');
      setBackups(r.data || []);
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Yedekler yüklenemedi', 'error');
    } finally { setLoading(false); }
  };

  useEffect(() => { loadBackups(); }, []);

  const createBackup = async () => {
    setCreating(true);
    try {
      const r = await api.post('/backup/create');
      showToast('Yedek başarıyla oluşturuldu', 'success');
      // Otomatik indirme
      try {
        const dl = await api.get(`/backup/download/${r.data.id}`, { responseType: 'blob' });
        const blob = new Blob([dl.data], { type: 'application/octet-stream' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = r.data.filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
      } catch {}
      await loadBackups();
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Yedek oluşturulamadı', 'error');
    } finally { setCreating(false); }
  };

  const downloadBackup = async (b: any) => {
    try {
      const r = await api.get(`/backup/download/${b.id}`, { responseType: 'blob' });
      const blob = new Blob([r.data], { type: 'application/octet-stream' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = b.filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'İndirme başarısız', 'error');
    }
  };

  const deleteBackup = async (b: any) => {
    try {
      await api.delete(`/backup/${b.id}`);
      showToast('Yedek silindi', 'success');
      setConfirmDelete(null);
      await loadBackups();
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Silme başarısız', 'error');
    }
  };

  const handleFilePicked = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) setConfirmRestore(f);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const doRestore = async () => {
    if (!confirmRestore) return;
    setRestoring(true);
    try {
      const fd = new FormData();
      fd.append('file', confirmRestore);
      const r = await api.post('/backup/restore', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      const counts = r.data?.tables || {};
      const total = Object.values(counts).reduce((a: any, b: any) => a + (b || 0), 0);
      showToast(`Geri yükleme tamamlandı (${total} kayıt, ${r.data?.files_restored || 0} dosya)`, 'success');
      setConfirmRestore(null);
      await loadBackups();
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Geri yükleme başarısız', 'error');
    } finally { setRestoring(false); }
  };

  const fmtSize = (n: number) => {
    if (!n) return '0 B';
    const u = ['B','KB','MB','GB'];
    let i = 0; let v = n;
    while (v >= 1024 && i < u.length-1) { v /= 1024; i++; }
    return `${v.toFixed(v < 10 ? 2 : 1)} ${u[i]}`;
  };

  const fmtDate = (s: string) => {
    try { return new Date(s).toLocaleString('tr-TR'); } catch { return s; }
  };

  return (
    <div className="space-y-6">
      {/* Bilgi Kartı */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-indigo-100 dark:bg-indigo-900/40 flex items-center justify-center text-indigo-600 dark:text-indigo-400 shrink-0">
            <Database size={24}/>
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100 mb-1">Yedekleme</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
              İşletmenizin tüm verilerini (ürünler, işlemler, kategoriler, görseller, garanti belgeleri, araçlar, personel kayıtları) <strong>şifreli tek dosya</strong> olarak indirebilir; daha sonra yükleyerek geri yükleyebilirsiniz. Yedek dosyaları güçlü şifreleme ile korunur.
            </p>
            {/* Sunucu limiti göstergesi */}
            <div className="mt-3 flex items-center gap-3">
              <div className="flex-1 bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                <div
                  className={`h-2 rounded-full transition-all ${
                    backups.length >= backupLimit.max ? 'bg-red-500' : backups.length >= 2 ? 'bg-amber-400' : 'bg-emerald-500'
                  }`}
                  style={{ width: `${Math.min(100, (backups.length / backupLimit.max) * 100)}%` }}
                />
              </div>
              <span className={`text-xs font-semibold whitespace-nowrap ${
                backups.length >= backupLimit.max ? 'text-red-600 dark:text-red-400' : 'text-slate-500 dark:text-slate-400'
              }`}>
                {backups.length} / {backupLimit.max} yedek
              </span>
            </div>
            {backups.length >= backupLimit.max && (
              <p className="text-xs text-amber-700 dark:text-amber-400 mt-1.5">
                Sunucuda {backupLimit.max} yedek limiti doldu. Yeni yedek alındığında en eski yedek otomatik silinir.
              </p>
            )}
          </div>
        </div>
        <div className="flex flex-wrap gap-3 mt-5 pt-5 border-t border-slate-100 dark:border-slate-800">
          <button onClick={createBackup} disabled={creating}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 text-white text-sm font-bold hover:bg-indigo-700 disabled:opacity-50 transition shadow-sm">
            <Download size={16}/> {creating ? 'Oluşturuluyor...' : 'Yeni Yedek Oluştur ve İndir'}
          </button>
          <input ref={fileInputRef} type="file" accept=".sfb" onChange={handleFilePicked} className="hidden"/>
          <button onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-sm font-bold hover:bg-slate-50 dark:hover:bg-slate-700 transition">
            <Upload size={16}/> Yedek Dosyası Yükle (.sfb)
          </button>
          <button onClick={loadBackups} disabled={loading}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-slate-500 dark:text-slate-400 text-sm font-bold hover:text-slate-700 dark:hover:text-slate-200 transition">
            <RefreshCw size={14} className={loading ? 'animate-spin' : ''}/> Yenile
          </button>
        </div>
      </div>

      {/* Yedek Listesi */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <h3 className="font-bold text-slate-800 dark:text-slate-100">Yedek Geçmişi</h3>
          <span className="text-xs text-slate-400">{backups.length} yedek</span>
        </div>
        {loading ? (
          <div className="p-12 text-center text-slate-400">Yükleniyor...</div>
        ) : backups.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <Database size={32} className="mx-auto mb-3 opacity-40"/>
            <p className="text-sm">Henüz yedek oluşturmadınız.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {backups.map(b => (
              <div key={b.id} className="px-6 py-4 flex items-center gap-4 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                <div className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 shrink-0">
                  <FileText size={18}/>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm text-slate-800 dark:text-slate-100 truncate">{b.filename}</p>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {fmtDate(b.created_at)} • {fmtSize(b.size_bytes)}
                    {b.restored_at && <span className="ml-2 text-emerald-600 dark:text-emerald-400">• Geri yüklendi: {fmtDate(b.restored_at)}</span>}
                  </p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button onClick={() => downloadBackup(b)} title="İndir"
                    className="p-2 rounded-lg text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition">
                    <Download size={16}/>
                  </button>
                  <button onClick={() => setConfirmDelete(b)} title="Sil"
                    className="p-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 transition">
                    <Trash2 size={16}/>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Sil onay */}
      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => setConfirmDelete(null)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-md w-full p-6" onClick={e => e.stopPropagation()}>
            <h3 className="font-bold text-slate-800 dark:text-slate-100 mb-2">Yedek silinsin mi?</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-5">
              <strong>{confirmDelete.filename}</strong> kalıcı olarak silinecek. Bu işlem geri alınamaz.
            </p>
            <div className="flex justify-end gap-3">
              <button onClick={() => setConfirmDelete(null)} className="px-4 py-2 text-sm text-slate-500 hover:text-slate-700 dark:hover:text-slate-200">İptal</button>
              <button onClick={() => deleteBackup(confirmDelete)} className="px-5 py-2 bg-red-600 text-white text-sm font-bold rounded-xl hover:bg-red-700">Sil</button>
            </div>
          </div>
        </div>
      )}

      {/* Geri yükle onay */}
      {confirmRestore && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => !restoring && setConfirmRestore(null)}>
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-md w-full p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-900/40 flex items-center justify-center text-amber-600 dark:text-amber-400 shrink-0">
                <AlertTriangle size={20}/>
              </div>
              <h3 className="font-bold text-slate-800 dark:text-slate-100">Geri yükleme onayı</h3>
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-2">
              Yüklenen dosya: <strong className="text-slate-700 dark:text-slate-200">{confirmRestore.name}</strong>
            </p>
            <p className="text-sm text-red-600 dark:text-red-400 mb-5 leading-relaxed">
              <strong>DİKKAT:</strong> İşletmenizin tüm mevcut verileri (ürünler, işlemler, kategoriler, personel kayıtları, geçmiş) silinecek ve yedekteki verilerle değiştirilecektir. Bu işlem geri alınamaz.
            </p>
            <div className="flex justify-end gap-3">
              <button onClick={() => setConfirmRestore(null)} disabled={restoring}
                className="px-4 py-2 text-sm text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 disabled:opacity-50">İptal</button>
              <button onClick={doRestore} disabled={restoring}
                className="px-5 py-2 bg-red-600 text-white text-sm font-bold rounded-xl hover:bg-red-700 disabled:opacity-50">
                {restoring ? 'Geri yükleniyor...' : 'Onaylıyorum, Geri Yükle'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Cihaz Kamera Paneli — cihaz kartının altında açılan canlı görüntü
const DeviceCameraPanel = ({ deviceId }: { deviceId: string }) => {
  const [frame, setFrame] = React.useState<{ jpeg_b64: string; codes: string[]; timestamp: number } | null>(null);
  const [err, setErr] = React.useState('');
  const intervalRef = React.useRef<any>(null);

  React.useEffect(() => {
    let active = true;
    const poll = async () => {
      try {
        const r = await api.get(`/camera/${deviceId}/latest`, { _noBar: true } as any);
        if (active) { setFrame(r.data); setErr(''); }
      } catch (e: any) {
        if (active) setErr(e?.response?.status === 404 ? 'Görüntü bekleniyor…' : 'Bağlantı hatası');
      }
    };
    poll();
    intervalRef.current = setInterval(poll, 600);
    return () => { active = false; clearInterval(intervalRef.current); };
  }, [deviceId]);

  const age = frame ? Math.round((Date.now() / 1000) - frame.timestamp) : null;

  return (
    <div className="mt-3 border-t border-slate-100 dark:border-slate-700 pt-3">
      <div className="flex items-center gap-2 mb-2">
        <Camera size={14} className="text-indigo-500 shrink-0" />
        <span className="text-xs font-bold text-slate-700 dark:text-slate-200">Canlı Kamera</span>
        {age !== null && (
          <span className="ml-auto text-[10px] text-slate-400">{age}s önce</span>
        )}
      </div>

      {err && !frame && (
        <p className="text-xs text-slate-400 italic">{err}</p>
      )}

      {frame && (
        <div className="flex gap-3 items-start">
          <img
            src={`data:image/jpeg;base64,${frame.jpeg_b64}`}
            alt="Kamera görüntüsü"
            className="rounded-lg border border-slate-200 dark:border-slate-700 bg-black"
            style={{ width: 160, height: 120, imageRendering: 'pixelated', objectFit: 'contain' }}
          />
          <div className="flex-1 min-w-0">
            <p className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 mb-1 uppercase tracking-wide">
              Okunan Kodlar
            </p>
            {frame.codes.length === 0 ? (
              <p className="text-xs text-slate-400 italic">Henüz kod tespit edilmedi</p>
            ) : (
              <ul className="space-y-1">
                {frame.codes.map((c, i) => (
                  <li key={i} className="font-mono text-xs bg-emerald-50 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-300 rounded-lg px-2 py-1 break-all">
                    {c}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

// 3.5b Cihaz Yönetimi (ESP8266 / ESP32)
const DevicesView = ({ showToast, currentUser }: any) => {
  type MyDevice = {
    id: number;
    device_id: string;
    device_type: string;
    is_paired: boolean;
    is_active: boolean;
    firmware_version: string | null;
    ip_address: string | null;
    wifi_ssid: string | null;
    wifi_rssi: number | null;
    last_seen: string | null;
    pending_firmware_version: string | null;
    paired_at: string | null;
    notes: string | null;
  };

  const [devices, setDevices] = React.useState<MyDevice[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [pairId, setPairId] = React.useState('');
  const [pairing, setPairing] = React.useState(false);
  const [removing, setRemoving] = React.useState<string | null>(null);
  const [cameraOpen, setCameraOpen] = React.useState<string | null>(null);

  const isOnline = (last_seen: string | null) => {
    if (!last_seen) return false;
    return (Date.now() - new Date(last_seen).getTime()) < 90_000;
  };

  const fetchDevices = React.useCallback(async () => {
    setLoading(true);
    try {
      const r = await api.get('/devices/my');
      setDevices(r.data || []);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Cihazlar yüklenemedi', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  React.useEffect(() => { fetchDevices(); }, [fetchDevices]);

  const pairDevice = async () => {
    if (!pairId.trim()) { showToast('Cihaz ID girin', 'warning'); return; }
    setPairing(true);
    try {
      await api.post('/devices/pair', { device_id: pairId.trim() });
      showToast('Cihaz başarıyla eşleştirildi!', 'success');
      setPairId('');
      fetchDevices();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Eşleşme başarısız', 'error');
    } finally {
      setPairing(false);
    }
  };

  const removeDevice = async (deviceId: string) => {
    setRemoving(deviceId);
    try {
      await api.delete(`/devices/${deviceId}`);
      showToast('Cihaz kaldırıldı', 'success');
      fetchDevices();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'İşlem başarısız', 'error');
    } finally {
      setRemoving(null);
    }
  };

  const formatUptime = (s: number | null) => {
    if (!s) return '—';
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    if (h > 0) return `${h}s ${m}dk`;
    return `${m}dk`;
  };

  const formatTs = (s: string | null) => {
    if (!s) return '—';
    try {
      return new Date(s).toLocaleString('tr-TR', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    } catch { return s; }
  };

  return (
    <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-6">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center shrink-0">
          <Cpu size={26} />
        </div>
        <div>
          <h1 className="text-2xl font-black text-slate-800 dark:text-white">Cihazlar</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">ESP8266 / ESP32 cihazlarınızı yönetin</p>
        </div>
      </div>

      {/* Cihaz Eşleştirme */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-5">
        <h2 className="text-sm font-bold text-slate-700 dark:text-slate-200 mb-3 flex items-center gap-2">
          <PlugZap size={16} className="text-indigo-500" /> Yeni Cihaz Ekle
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
          Cihazın üzerinde yazan <strong>Device ID</strong>'yi girerek cihazınızı sisteminize bağlayın. Cihazın WiFi'ye bağlı ve aktif olması gerekir.
        </p>
        <div className="flex gap-3">
          <input
            value={pairId}
            onChange={e => setPairId(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && pairDevice()}
            placeholder="Cihaz ID (ör: DEV-A1B2C3D4)"
            className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            onClick={pairDevice}
            disabled={pairing}
            className="shrink-0 inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-sm transition disabled:opacity-50"
          >
            <PlugZap size={16} /> {pairing ? 'Eşleşiyor…' : 'Eşleştir'}
          </button>
        </div>
      </div>

      {/* Cihaz Listesi */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-slate-800">
          <h2 className="text-sm font-bold text-slate-700 dark:text-slate-200 flex items-center gap-2">
            <Wifi size={16} className="text-indigo-500" /> Eşleştirilmiş Cihazlar
            <span className="text-xs text-slate-400 font-normal">({devices.length})</span>
          </h2>
          <button onClick={fetchDevices} disabled={loading}
            className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition">
            <RefreshCw size={14} className={loading ? 'animate-spin text-indigo-500' : 'text-slate-500'} />
          </button>
        </div>

        {loading && (
          <div className="py-12 text-center text-slate-400 text-sm">Yükleniyor…</div>
        )}

        {!loading && devices.length === 0 && (
          <div className="py-12 text-center">
            <Cpu size={40} className="mx-auto mb-3 text-slate-300 dark:text-slate-600" />
            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Henüz cihaz eklenmemiş</p>
            <p className="text-slate-400 dark:text-slate-500 text-xs mt-1">Yukarıdaki formdan cihaz ID'sini girerek başlayın</p>
          </div>
        )}

        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {devices.map(d => {
            const online = isOnline(d.last_seen);
            return (
              <div key={d.id} className="px-5 py-4 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className={`mt-0.5 w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${online ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'}`}>
                      {online ? <Wifi size={20} /> : <WifiOff size={20} />}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-sm font-bold text-slate-800 dark:text-white">{d.device_id}</span>
                        <span className="text-[11px] px-2 py-0.5 rounded-full font-bold bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300">{d.device_type}</span>
                        <span className={`text-[11px] px-2 py-0.5 rounded-full font-bold ${online ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300' : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'}`}>
                          {online ? 'Çevrimiçi' : 'Çevrimdışı'}
                        </span>
                      </div>
                      <div className="mt-2 grid grid-cols-2 sm:grid-cols-3 gap-x-6 gap-y-1 text-xs text-slate-500 dark:text-slate-400">
                        <span><span className="font-semibold text-slate-600 dark:text-slate-300">IP:</span> {d.ip_address || '—'}</span>
                        <span><span className="font-semibold text-slate-600 dark:text-slate-300">WiFi:</span> {d.wifi_ssid ? `${d.wifi_ssid} (${d.wifi_rssi ?? '?'} dBm)` : '—'}</span>
                        <span><span className="font-semibold text-slate-600 dark:text-slate-300">Firmware:</span> {d.firmware_version || '—'}</span>
                        <span><span className="font-semibold text-slate-600 dark:text-slate-300">Son görülme:</span> {formatTs(d.last_seen)}</span>
                        <span><span className="font-semibold text-slate-600 dark:text-slate-300">Eşleşme:</span> {formatTs(d.paired_at)}</span>
                        {d.pending_firmware_version && (
                          <span className="text-amber-600 dark:text-amber-400 font-bold">
                            Bekleyen OTA: {d.pending_firmware_version}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {online && d.device_type?.includes('32') && (
                      <button
                        onClick={() => setCameraOpen(cameraOpen === d.device_id ? null : d.device_id)}
                        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                          cameraOpen === d.device_id
                            ? 'bg-indigo-600 text-white'
                            : 'bg-indigo-100 text-indigo-700 hover:bg-indigo-200 dark:bg-indigo-900/40 dark:text-indigo-300'
                        }`}
                      >
                        <Camera size={13} /> {cameraOpen === d.device_id ? 'Kapat' : 'Kamera'}
                      </button>
                    )}
                    <button
                      onClick={() => removeDevice(d.device_id)}
                      disabled={removing === d.device_id}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-red-100 text-red-700 hover:bg-red-200 dark:bg-red-900/40 dark:text-red-300 dark:hover:bg-red-900/60 rounded-lg text-xs font-bold transition disabled:opacity-50"
                    >
                      <Trash size={13} /> {removing === d.device_id ? 'Kaldırılıyor…' : 'Kaldır'}
                    </button>
                  </div>
                </div>

                {cameraOpen === d.device_id && (
                  <DeviceCameraPanel deviceId={d.device_id} />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Bilgi */}
      <div className="bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800 rounded-2xl p-5">
        <h3 className="text-sm font-bold text-indigo-800 dark:text-indigo-300 mb-2 flex items-center gap-2">
          <AlertCircle size={15} /> Nasıl Çalışır?
        </h3>
        <ul className="text-xs text-indigo-700 dark:text-indigo-400 space-y-1 list-disc list-inside">
          <li>Cihaz ilk açıldığında WiFiManager ile ağa bağlanır ve sisteme kayıt olur.</li>
          <li>Cihaz ekranındaki <strong>Device ID</strong>'yi yukarıdaki forma girerek eşleştirin.</li>
          <li>Eşleşme sonrası cihaz 30 saniyede bir durum bilgisi gönderir.</li>
          <li>Barkod taratarak ürün bilgisi (fiyat, stok, açıklama) çekebilirsiniz.</li>
          <li>Süper admin panelinden OTA güncellemesi gönderebilirsiniz.</li>
        </ul>
      </div>
    </div>
  );
};

// 3.6 Abonelik ve Referans Yönetimi (IP Korumalı)
const SubscriptionView = ({ currentUser, expired = false, onPaymentSuccess }: any) => {
  const { t, showToast } = useAppContext();
  const [copied, setCopied] = useState(false);
  const [packages, setPackages] = useState<any[]>([]);
  const [meStatus, setMeStatus] = useState<any>(null);
  const [loadingPkg, setLoadingPkg] = useState(true);
  const [busySlug, setBusySlug] = useState<string | null>(null);
  const [iframeData, setIframeData] = useState<{ url: string; oid: string; pkg: any; testMode: boolean } | null>(null);
  const [paymentStatus, setPaymentStatus] = useState<string>('pending');
  const [history, setHistory] = useState<any[]>([]);

  const reload = useCallback(async () => {
    try {
      setLoadingPkg(true);
      const [pkgRes, meRes, hRes] = await Promise.all([
        api.get('/subscription/packages'),
        api.get('/subscription/me'),
        api.get('/subscription/payments/me'),
      ]);
      setPackages(pkgRes.data || []);
      setMeStatus(meRes.data);
      setHistory(hRes.data?.items || []);
    } catch (e: any) {
      console.error(e);
    } finally {
      setLoadingPkg(false);
    }
  }, []);

  useEffect(() => { reload(); }, [reload]);

  // İframe açıkken her 3 sn'de bir ödeme durumunu sorgula
  useEffect(() => {
    if (!iframeData) return;
    let stopped = false;
    const tick = async () => {
      if (stopped) return;
      try {
        const r = await api.get(`/subscription/payments/${iframeData.oid}`, { _silent: true } as any);
        setPaymentStatus(r.data.status);
        if (r.data.status === 'success') {
          stopped = true;
          showToast('Ödeme başarılı! Aboneliğiniz aktif.', 'success');
          setIframeData(null);
          await reload();
          if (onPaymentSuccess) onPaymentSuccess();
        } else if (r.data.status === 'failed') {
          stopped = true;
          showToast(r.data.error_message || 'Ödeme başarısız oldu.', 'error');
        }
      } catch (e) { /* ignore */ }
    };
    const id = setInterval(tick, 3000);
    return () => { stopped = true; clearInterval(id); };
  }, [iframeData, reload, showToast, onPaymentSuccess]);

  const startCheckout = async (slug: string) => {
    setBusySlug(slug);
    setPaymentStatus('pending');
    try {
      const r = await api.post('/subscription/checkout', { package_slug: slug });
      setIframeData({ url: r.data.iframe_url, oid: r.data.merchant_oid, pkg: packages.find(p => p.slug === slug), testMode: !!r.data.test_mode });
    } catch (e: any) {
      const msg = e?.response?.data?.detail || 'Ödeme başlatılamadı';
      showToast(msg, 'error');
    } finally {
      setBusySlug(null);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(currentUser?.myRefCode || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const colorMap: Record<string, string> = {
    slate: 'from-slate-500 to-slate-700',
    indigo: 'from-indigo-500 to-blue-700',
    amber: 'from-amber-500 to-orange-600',
  };
  const ringColor: Record<string, string> = {
    slate: 'border-slate-300', indigo: 'border-indigo-500', amber: 'border-amber-500',
  };

  const days = meStatus?.days_remaining ?? currentUser?.subDays ?? 0;
  const myPkg = meStatus?.package;
  const isExpired = expired || days <= 0;

  return (
    <div className="max-w-6xl space-y-6 animate-in slide-in-from-bottom-4 duration-300">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-4">
           <div className="w-14 h-14 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center shrink-0"><CreditCard size={28} /></div>
           <div>
             <h2 className="text-2xl font-black text-slate-800 dark:text-white">{t('Abonelik & Paketler')}</h2>
             <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">Paketleri karşılaştırın, kart ile güvenle ödeme yapın.</p>
           </div>
        </div>
        <div className="flex items-center gap-3">
          <div className={`px-4 py-2 rounded-xl text-sm font-bold ${isExpired ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400'}`}>
            {isExpired ? 'Aboneliğiniz Sona Erdi' : `Kalan Süre: ${days} gün`}
          </div>
          {myPkg && <div className="px-4 py-2 rounded-xl text-sm font-bold bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400">{myPkg.name}</div>}
        </div>
      </div>

      {isExpired && (
        <div className="bg-gradient-to-r from-red-500 to-orange-500 p-4 rounded-2xl text-white font-bold flex items-center gap-3 shadow-lg">
          <ShieldBan size={28}/>
          <div>
            <p className="text-lg">Aboneliğinizin süresi doldu — ürün ekleme ve finans kaydı durduruldu.</p>
            <p className="text-orange-100 text-sm font-medium">Aşağıdan bir paket seçip kart ile ödemeyi tamamlayarak hesabınızı saniyeler içinde aktive edebilirsiniz.</p>
          </div>
        </div>
      )}

      {/* Mevcut kullanım kotası */}
      {meStatus && myPkg && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { label: 'Stok / Ürün', used: meStatus.products_used, limit: meStatus.products_limit, unl: meStatus.products_unlimited, color: 'indigo' },
            { label: 'Finans Kaydı', used: meStatus.transactions_used, limit: meStatus.transactions_limit, unl: meStatus.transactions_unlimited, color: 'emerald' },
            { label: 'Destek Talebi (Aylık)', used: meStatus.support_tickets_used, limit: meStatus.support_tickets_limit, unl: meStatus.support_tickets_unlimited, color: 'violet' },
          ].map((q, i) => {
            const pct = q.unl ? 25 : Math.min(100, Math.round(((q.used || 0) / Math.max(1, q.limit || 1)) * 100));
            return (
              <div key={i} className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-bold text-slate-700 dark:text-slate-300">{q.label}</span>
                  <span className="text-sm font-bold text-slate-500">{q.used} / {q.unl ? '∞' : q.limit}</span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2.5 overflow-hidden">
                  <div className={`h-2.5 rounded-full ${pct >= 90 ? 'bg-red-500' : pct >= 70 ? 'bg-amber-500' : 'bg-' + q.color + '-500'}`} style={{ width: `${pct}%` }}/>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Paketler */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {loadingPkg && [1,2,3].map(i => <div key={i} className="h-96 bg-slate-100 dark:bg-slate-800 rounded-3xl animate-pulse"/>)}
        {!loadingPkg && packages.map(p => {
          const isCurrent = myPkg?.slug === p.slug && !isExpired;
          const grad = colorMap[p.color_class || 'slate'] || colorMap.slate;
          return (
            <div key={p.slug} className={`relative bg-white dark:bg-slate-900 rounded-3xl border-2 ${p.is_featured ? ringColor[p.color_class || 'indigo'] : 'border-slate-200 dark:border-slate-800'} shadow-sm overflow-hidden flex flex-col`}>
              {p.is_featured && <div className="absolute top-4 right-4 px-3 py-1 rounded-full bg-indigo-600 text-white text-xs font-bold uppercase tracking-wider">En Popüler</div>}
              {isCurrent && <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-emerald-600 text-white text-xs font-bold uppercase tracking-wider">Aktif</div>}
              <div className={`bg-gradient-to-br ${grad} p-8 text-white`}>
                <h3 className="text-2xl font-black mb-1">{p.name}</h3>
                <p className="text-white/80 text-sm font-medium mb-4 min-h-[2.5rem]">{p.description}</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-5xl font-black tracking-tight">{p.price_try.toLocaleString('tr-TR')}₺</span>
                  <span className="text-white/80 font-bold">/ {p.duration_days} gün</span>
                </div>
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <ul className="space-y-3 mb-6 flex-1">
                  {(p.features || []).map((f: string, i: number) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-slate-700 dark:text-slate-300">
                      <Check size={18} className="text-emerald-500 shrink-0 mt-0.5"/>
                      <span>{f}</span>
                    </li>
                  ))}
                  <li className="flex items-start gap-2 text-sm text-slate-700 dark:text-slate-300">
                    <Check size={18} className="text-violet-500 shrink-0 mt-0.5"/>
                    <span>Aylık <strong>{p.max_support_tickets == null ? 'Sınırsız' : p.max_support_tickets}</strong> destek talebi</span>
                  </li>
                </ul>
                <button
                  disabled={busySlug === p.slug}
                  onClick={() => startCheckout(p.slug)}
                  className={`w-full py-3.5 font-bold rounded-xl transition shadow-md disabled:opacity-50 disabled:cursor-not-allowed ${isCurrent ? 'bg-emerald-600 hover:bg-emerald-700 text-white' : 'bg-slate-900 dark:bg-indigo-600 hover:bg-slate-800 dark:hover:bg-indigo-700 text-white'}`}
                >
                  {busySlug === p.slug ? 'Yönlendiriliyor…' : isCurrent ? 'Süreyi Uzat (+30 gün)' : 'Bu Paketi Seç'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Davet Sistemi */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-indigo-600 to-blue-700 p-8 rounded-2xl text-white shadow-xl relative overflow-hidden">
          <div className="absolute -right-10 -top-10 opacity-10 pointer-events-none"><Gift size={200}/></div>
          <div className="relative z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-white font-bold text-xs uppercase tracking-wider mb-6 backdrop-blur-sm border border-white/10">
              Kazan - Kazan Sistemi
            </div>
            <h3 className="text-2xl font-black mb-3 leading-tight">Arkadaşlarınızı Davet Edin,<br/>Sürenizi 10 Gün Uzatın!</h3>
            <p className="text-indigo-100 font-medium text-sm mb-6 leading-relaxed">
              Referans kodunuz ile kaydolan her yeni bayi için aboneliğinize <b>+10 gün</b> eklenir. Davet ettiğiniz arkadaşınız da 14 yerine <b>24 gün</b> deneme süresiyle başlar.
            </p>
            <div className="bg-black/20 p-4 rounded-xl border border-white/10 backdrop-blur-md mb-4">
              <label className="block text-indigo-200 text-xs font-bold uppercase tracking-wider mb-2">Size Özel Referans Kodunuz</label>
              <div className="flex gap-2">
                <div className="flex-1 bg-white text-indigo-900 font-black text-xl px-4 py-3 rounded-lg text-center tracking-widest flex items-center justify-center">
                  {currentUser?.myRefCode || 'KOD_YOK'}
                </div>
                <button onClick={copyToClipboard} className={`px-4 py-3 rounded-lg font-bold flex items-center gap-2 transition ${copied ? 'bg-emerald-500 text-white' : 'bg-indigo-500 hover:bg-indigo-400 text-white'}`}>
                  {copied ? <Check size={20}/> : <Copy size={20}/>}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Ödeme Geçmişi */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800">
          <h3 className="text-lg font-black text-slate-800 dark:text-white mb-4 flex items-center gap-2">
            <CreditCard size={20}/> Ödeme Geçmişi
          </h3>
          {history.length === 0 && <p className="text-sm text-slate-500">Henüz ödeme yapılmamış.</p>}
          {history.length > 0 && (
            <div className="space-y-2 max-h-72 overflow-y-auto">
              {history.map((h) => (
                <div key={h.id} className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                  <div>
                    <p className="font-bold text-slate-800 dark:text-slate-200 text-sm">{h.package_slug.toUpperCase()} • {h.amount_try}₺</p>
                    <p className="text-xs text-slate-500">{h.created_at ? new Date(h.created_at).toLocaleString('tr-TR') : '-'}</p>
                  </div>
                  <span className={`text-xs font-bold px-2.5 py-1 rounded-lg ${h.status === 'success' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' : h.status === 'failed' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'}`}>
                    {h.status === 'success' ? 'Başarılı' : h.status === 'failed' ? 'Başarısız' : 'Beklemede'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* PayTR iframe modal */}
      {iframeData && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-[100] p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-2xl flex flex-col max-h-[95vh]">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h3 className="font-black text-slate-800 dark:text-white">{iframeData.pkg?.name} • {iframeData.pkg?.price_try}₺</h3>
                <p className="text-xs text-slate-500">Ödeme No: {iframeData.oid} {iframeData.testMode && '• TEST MODU'}</p>
              </div>
              <button onClick={() => setIframeData(null)} className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 p-2"><X size={22}/></button>
            </div>
            <div className="flex-1 overflow-hidden">
              <iframe src={iframeData.url} className="w-full h-[700px] max-h-[80vh] border-0" title="PayTR Ödeme"/>
            </div>
            <div className="px-6 py-3 text-xs text-center font-medium text-slate-500 border-t border-slate-200 dark:border-slate-800">
              Durum: {paymentStatus === 'success' ? 'Başarılı ✓' : paymentStatus === 'failed' ? 'Başarısız ✗' : 'Bekliyor… (otomatik kontrol ediliyor)'}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// 3.7 Dinamik Genel Liste Modülü (Stok & Finans için Arama/Ekleme ile)
// =====================================================================
// MODÜL YAPILANDIRMASI: Her bir menü ID'si için davranış kuralı
// =====================================================================
// Bu config tablosu, hangi menüye basınca ne olacağını belirler:
// - type: 'stok' veya 'finans' (hangi API'ye gider)
// - categoryFilter: ürünleri/işlemleri bu değere göre filtreler
// - transactionType: yeni işlem oluştururken kullanılacak tip
// - amountLabel / customerLabel: form ve listedeki etiketler
// - amountTone: bakiye renk tonu (kırmızı borç, yeşil tahsilat)
const MODULE_CONFIG: Record<string, any> = {
  // STOK MODÜLLERİ -----------------------------------------------------
  stock_general:   { type: 'stok',   categoryFilter: 'Genel Ürünler',     defaultCategory: 'Genel Ürünler',    sortMode: 'name_asc' },
  stock_cam:       { type: 'stok',   categoryFilter: 'Cam Rüzgarlığı',    defaultCategory: 'Cam Rüzgarlığı',   sortMode: 'name_asc' },
  stock_kaput:     { type: 'stok',   categoryFilter: 'Kaput Rüzgarlığı',  defaultCategory: 'Kaput Rüzgarlığı', sortMode: 'name_asc' },
  stock_jant:      { type: 'stok',   categoryFilter: 'Jant Kapağı',       defaultCategory: 'Jant Kapağı',      sortMode: 'name_asc' },
  stock_pandizot:  { type: 'stok',   categoryFilter: 'Pandizot',          defaultCategory: 'Pandizot',         sortMode: 'name_asc' },
  stock_paspas:    { type: 'stok',   categoryFilter: 'Paspas',            defaultCategory: 'Paspas',           sortMode: 'name_asc' },
  stock_spoiler:   { type: 'stok',   categoryFilter: 'Spoiler',           defaultCategory: 'Spoiler',          sortMode: 'name_asc' },

  // FİNANS MODÜLLERİ ---------------------------------------------------
  fin_veresiye:    { type: 'finans', transactionType: 'borç',     customerLabel: 'Müşteri Adı',      amountLabel: 'Borç Tutarı (₺)',     amountTone: 'red',     allowEditType: false, sortMode: 'name_asc', grouped: true },
  fin_firma:       { type: 'finans', transactionType: 'gider',    customerLabel: 'Firma Unvanı',     amountLabel: 'Borç Tutarı (₺)',     amountTone: 'amber',   allowEditType: false, sortMode: 'name_asc', grouped: true },
  fin_senet:       { type: 'finans', transactionType: 'senet',    customerLabel: 'Borçlu / Alacaklı',amountLabel: 'Senet Tutarı (₺)',    amountTone: 'indigo',  allowEditType: false, sortMode: 'name_asc', grouped: true },
  fin_kredi:       { type: 'finans', transactionType: 'kredi',    customerLabel: 'Banka / Kurum',    amountLabel: 'Kredi Tutarı (₺)',    amountTone: 'purple',  allowEditType: false, sortMode: 'name_asc', grouped: true },
  fin_kasa:        { type: 'finans', transactionType: null,       customerLabel: 'Cari',             amountLabel: 'Tutar (₺)',           amountTone: 'slate',   allowEditType: true,  sortMode: 'date_desc' },
  fin_garanti:     { type: 'finans', transactionType: 'garanti',  customerLabel: 'Müşteri Adı',      amountLabel: 'Garanti Tutarı (₺)',  amountTone: 'emerald', allowEditType: false, sortMode: 'name_asc' },
};

// 3.7 Dinamik Genel Liste Modülü (Stok & Finans için tam CRUD)
const GenericModuleView = ({ moduleId, title, icon: Icon, type, currentUser }) => {
  const { t, showToast, categories } = useAppContext();
  // Önce kullanıcının kendi (dinamik) kategori ayarları, yoksa eski hardcoded MODULE_CONFIG, yoksa minimal varsayılan.
  const dynamicCfg = useMemo(() => buildModuleConfig(categories || []), [categories]);
  const cfg = (moduleId && (dynamicCfg[moduleId] || MODULE_CONFIG[moduleId])) || { type, defaultCategory: title };

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedCari, setSelectedCari] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingItem, setEditingItem] = useState(null);
  const [quickSellTarget, setQuickSellTarget] = useState<any>(null);
  // Yetki türetme: granüler model. Patron → her şey açık.
  // Stok modülleri products.* iznine, finans modülleri ise cfg.transactionType'tan
  // türetilen finance.<tip>.* iznine bakar.
  const _isStok = (cfg?.type === 'stok' || type === 'stok');
  const _financeKey = _isStok ? null : financeKeyOf(cfg?.transactionType);
  const _viewPerm   = _isStok ? 'products.view'   : `finance.${_financeKey}.view`;
  const _addPerm    = _isStok ? 'products.add'    : `finance.${_financeKey}.add`;
  const _editPerm   = _isStok ? 'products.edit'   : `finance.${_financeKey}.edit`;
  const _deletePerm = _isStok ? 'products.delete' : `finance.${_financeKey}.delete`;
  const _canView   = hasPerm(currentUser, _viewPerm);
  const _canAdd    = hasPerm(currentUser, _addPerm);
  const _canEdit   = hasPerm(currentUser, _editPerm);
  const _canDelete = hasPerm(currentUser, _deletePerm);
  // Legacy uyumluluk: eski kod p.canAdd / p.canEdit / p.canDelete / p.allowedModules === 'all' kullanıyor.
  const p: any = isOwner(currentUser)
    ? { canAdd: true, canEdit: true, canDelete: true, canView: true, allowedModules: 'all' }
    : { canAdd: _canAdd, canEdit: _canEdit, canDelete: _canDelete, canView: _canView, allowedModules: _canView ? ['stok'] : [] };

  const [rawData, setRawData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // ----- ORTAK FORM ALANLARI -------------------------------------------
  const [formTitle, setFormTitle] = useState('');         // Stok: ürün adı, Finans: müşteri adı
  // Stok alanları
  const [formCategory, setFormCategory] = useState('');
  const [formSubcategory, setFormSubcategory] = useState('');
  const [formExtraCategories, setFormExtraCategories] = useState<string[]>([]);
  const [formExtraInput, setFormExtraInput] = useState('');
  const [formBarcode, setFormBarcode] = useState('');
  const [formBuyPrice, setFormBuyPrice] = useState('');
  const [formSellPrice, setFormSellPrice] = useState('');
  const [formCurrency, setFormCurrency] = useState('TRY');
  const [formCostCurrency, setFormCostCurrency] = useState('TRY');
  const [formAmount, setFormAmount] = useState('');
  const [formMinStock, setFormMinStock] = useState('5');
  // Finans alanları
  const [formTxType, setFormTxType] = useState(cfg.transactionType || 'borç');
  const [formTxAmount, setFormTxAmount] = useState('');
  const [formTxCurrency, setFormTxCurrency] = useState('TRY');
  const [formNotes, setFormNotes] = useState('');
  // Faz 3: KDV (Numeric, % olarak; amount KDV DAHİL gross varsayılır)
  const [formKdvRate, setFormKdvRate] = useState<string>('0');
  // Faz 3: Slip Gönder modal — cari (müşteri) listesi için
  const [debtorLinkTarget, setDebtorLinkTarget] = useState<string | null>(null);
  // Resim (stok için)
  const [formImageFile, setFormImageFile] = useState<File | null>(null);
  const [formImagePreview, setFormImagePreview] = useState<string | null>(null);
  // Barkod tarayıcı (form için)
  const [barcodeScanOpen, setBarcodeScanOpen] = useState(false);
  // Liste barkod tarayıcı
  const [listScanOpen, setListScanOpen] = useState(false);

  // ----- LİSTE: ARAMA, ALT-ETİKET FİLTRESİ, SAYFALAMA ------------------
  const [subcategoryFilter, setSubcategoryFilter] = useState<string | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<string>('');
  const [allCategories, setAllCategories] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const PAGE_SIZE = 24;

  const fetchAllCategories = async () => {
    if (cfg.type !== 'stok') return;
    try {
      const r = await api.get('/products/distinct-categories');
      setAllCategories(Array.isArray(r.data?.items) ? r.data.items : []);
    } catch (e) {
      console.error('distinct-categories fetch error:', e);
    }
  };

  // Modal her açıldığında formu doldur (yeni veya düzenleme)
  useEffect(() => {
    if (!isModalOpen) return;
    setFormImageFile(null);
    if (cfg.type === 'stok') {
      if (editingItem) {
        setFormTitle(editingItem.title || '');
        setFormCategory(editingItem.category || cfg.defaultCategory || '');
        setFormSubcategory(editingItem.subcategory || '');
        setFormExtraCategories(Array.isArray(editingItem.extraCategories) ? [...editingItem.extraCategories] : []);
        setFormExtraInput('');
        setFormBarcode(editingItem.barcode === '-' ? '' : (editingItem.barcode || ''));
        setFormBuyPrice(editingItem.buyPrice?.toString() || '');
        setFormSellPrice(editingItem.sellPrice?.toString() || '');
        setFormCurrency((editingItem.currency || 'TRY').toUpperCase());
        setFormCostCurrency((editingItem.costCurrency || editingItem.currency || 'TRY').toUpperCase());
        setFormAmount(editingItem.amount?.toString() || '');
        setFormMinStock(editingItem.min_stock_alert?.toString() || '5');
        setFormImagePreview(editingItem.imageUrl || null);
      } else {
        setFormTitle('');
        setFormCategory('');
        setFormSubcategory('');
        setFormExtraCategories([]);
        setFormExtraInput('');
        setFormBarcode('');
        setFormBuyPrice('');
        setFormSellPrice('');
        setFormCurrency('TRY');
        setFormCostCurrency('TRY');
        setFormAmount('');
        setFormMinStock('5');
        setFormImagePreview(null);
      }
    } else {
      // FİNANS modu
      if (editingItem) {
        setFormTitle(editingItem.title || '');
        setFormTxType(editingItem.type || cfg.transactionType || 'borç');
        setFormTxAmount(editingItem.balance?.toString() || '');
        setFormTxCurrency((editingItem.currency || 'TRY').toUpperCase());
        setFormNotes(editingItem.notes || '');
        setFormKdvRate(editingItem.kdv_rate != null ? String(editingItem.kdv_rate) : '0');
      } else {
        setFormTitle('');
        setFormTxType(cfg.transactionType || 'borç');
        setFormTxAmount('');
        setFormTxCurrency('TRY');
        setFormNotes('');
        setFormKdvRate('0');
      }
    }
  }, [isModalOpen, editingItem, cfg.type, cfg.defaultCategory, cfg.transactionType]);

  // ----- VERİ ÇEKME ----------------------------------------------------
  const fetchData = async (silent = false) => {
    try {
      if (!silent) setLoading(true);
      if (cfg.type === 'stok') {
        const params: any = { page_size: 1000 };
        if (categoryFilter && categoryFilter.trim()) params.category = categoryFilter;
        const response = await api.get('/products', { params });
        const products = response.data.items || [];
        setRawData(products.map(p => ({
          id: p.id,
          barcode: p.barcode || '-',
          title: p.name,
          category: p.category || cfg.defaultCategory,
          subcategory: p.subcategory || '',
          extraCategories: Array.isArray(p.extra_categories) ? p.extra_categories : [],
          currency: (p.currency || 'TRY').toUpperCase(),
          costCurrency: (p.cost_currency || p.currency || 'TRY').toUpperCase(),
          buyPrice: p.cost ?? p.price * 0.7,
          sellPrice: p.price,
          amount: p.quantity,
          min_stock_alert: p.min_stock_alert ?? 5,
          imageUrl: p.image_url ? `${p.image_url}?v=${encodeURIComponent(p.updated_at || p.created_at || '')}` : null,
        })));
      } else if (cfg.grouped && cfg.transactionType) {
        // FİNANS — Cari (müşteri) bazlı özet listesi
        const r = await api.get('/finance/customers/summary', {
          params: { transaction_type: cfg.transactionType },
        });
        const items = r.data?.items || [];
        setRawData(items.map((it: any, idx: number) => ({
          id: `cari:${it.name}`,            // grouped row için unique key
          cariName: it.name,
          title: it.name,
          balance: it.balance,              // net borç (= toplam borç − tahsilat)
          totalDebt: it.total_debt,
          totalPaid: it.total_paid,
          txnCount: it.txn_count,
          currency: (it.currency || 'TRY').toUpperCase(),
          type: cfg.transactionType,
          ledgerType: cfg.transactionType,
          notes: '',
          date: it.first_at,                // ilk oluşturma tarihi
          lastAt: it.last_at,
          barcode: '-',
        })));
      } else {
        // FİNANS — düz işlem listesi (Kasa, Garanti)
        const params: any = { page_size: 1000, days: 365 };
        if (cfg.transactionType) params.transaction_type = cfg.transactionType;
        const response = await api.get('/finance/transactions', { params });
        const txs = response.data.items || [];
        setRawData(txs.map(tx => ({
          id: tx.id,
          title: tx.customer_name,
          balance: tx.amount,
          currency: (tx.currency || 'TRY').toUpperCase(),
          type: tx.transaction_type,
          notes: tx.notes || '',
          date: tx.created_at,
          barcode: '-',
          kdv_rate: tx.kdv_rate != null ? Number(tx.kdv_rate) : 0,
        })));
      }
    } catch (error) {
      console.error('Module fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { setSelectedCari(null); fetchData(); fetchAllCategories(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [moduleId]);
  useEffect(() => { if (cfg.type === 'stok') { fetchData(); } /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [categoryFilter]);
  useRefreshOnChange(fetchData);

  // QR tarama sonrası "Düzenle" tıklanınca: sessionStorage'dan bekleyen ürünü bul ve formu aç
  useEffect(() => {
    if (!rawData.length || cfg.type !== 'stok') return;
    const pendingId = sessionStorage.getItem('pendingProductEdit');
    if (!pendingId) return;
    const id = parseInt(pendingId);
    const product = rawData.find((r: any) => r.id === id);
    if (product) {
      sessionStorage.removeItem('pendingProductEdit');
      setEditingItem(product);
      setIsModalOpen(true);
    }
  }, [rawData]); // eslint-disable-line react-hooks/exhaustive-deps

  // ----- KAYDET (Yeni / Düzenle) ---------------------------------------
  const handleSave = async () => {
    if (cfg.type === 'stok') {
      if (!formTitle.trim()) { showToast('Lütfen ürün adını girin', 'error'); return; }
      const canViewCost = hasPerm(currentUser, 'products.view_cost');
      const sellPrice = parseFloat(formSellPrice);
      const buyPrice = canViewCost ? parseFloat(formBuyPrice) : (editingItem?.buyPrice ?? 0);
      const qty = parseInt(formAmount);
      const minStock = parseInt(formMinStock) || 5;
      if (isNaN(sellPrice) || sellPrice <= 0) { showToast("Satış fiyatı 0'dan büyük olmalıdır", 'error'); return; }
      if (canViewCost && (isNaN(buyPrice) || buyPrice <= 0)) { showToast("Alış fiyatı 0'dan büyük olmalıdır", 'error'); return; }
      if (isNaN(qty) || qty < 0) { showToast("Stok miktarı 0 veya daha büyük olmalıdır", 'error'); return; }
      // Ana kategori, sekmeden gelir (formCategory artık readonly).
      // Düzenlemede mevcut ürünün kategorisi korunur — sekme dışı bir ürün başka
      // bir sekmede açılırsa orijinal kategorisi değişmez.
      const mainCat = (editingItem?.category && String(editingItem.category).trim())
        || cfg.defaultCategory
        || cfg.categoryFilter
        || (formCategory && formCategory.trim())
        || 'Genel';
      const cleanedExtras = Array.from(new Set(
        (formExtraCategories || [])
          .map(c => (c || '').trim())
          .filter(c => c && c.toLowerCase() !== mainCat.toLowerCase())
      ));
      const payload: any = {
        name: formTitle.trim(),
        category: mainCat,
        subcategory: formSubcategory.trim() || null,
        extra_categories: cleanedExtras,
        price: sellPrice,
        ...(canViewCost ? { cost: buyPrice } : {}),
        currency: formCurrency || 'TRY',
        cost_currency: formCostCurrency || 'TRY',
        quantity: qty,
        min_stock_alert: minStock,
      };
      if (formBarcode.trim()) payload.barcode = formBarcode.trim();
      try {
        setSaving(true);
        let productId = editingItem?.id;
        if (editingItem) {
          await api.put(`/products/${editingItem.id}`, payload);
        } else {
          const resp = await api.post('/products', payload);
          productId = resp.data.product?.id;
        }
        if (formImageFile && productId) {
          const fd = new FormData();
          fd.append('file', formImageFile);
          try {
            await api.post(`/files/product/${productId}/image`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
          } catch (imgErr) {
            console.warn('Resim yüklenemedi:', imgErr);
          }
        }
        showToast(editingItem ? 'Ürün güncellendi' : 'Ürün eklendi');
        setIsModalOpen(false); setEditingItem(null); await fetchData(); fetchAllCategories();
      } catch (err: any) {
        const d = err.response?.data?.detail;
        const msg = Array.isArray(d) ? d.map((e: any) => `${e.loc?.join('.')}: ${e.msg}`).join('\n') : (d || err.message || 'Kayıt sırasında hata oluştu');
        showToast(`Hata: ${msg}`, 'error');
      } finally { setSaving(false); }
    } else if (cfg.grouped) {
      // FİNANS — Cari (müşteri) yönetimi: yalnız ad+para birimi+açıklama
      if (!formTitle.trim()) { showToast('Lütfen ' + (cfg.customerLabel || 'müşteri') + ' adını girin', 'error'); return; }
      try {
        setSaving(true);
        if (editingItem) {
          await api.put('/finance/customers/rename', {
            old_name: editingItem.cariName || editingItem.title,
            new_name: formTitle.trim(),
            transaction_type: cfg.transactionType,
            currency: formTxCurrency || 'TRY',
            notes: formNotes.trim() || null,
          });
        } else {
          await api.post('/finance/customers', {
            customer_name: formTitle.trim(),
            transaction_type: cfg.transactionType,
            currency: formTxCurrency || 'TRY',
            notes: formNotes.trim() || null,
          });
        }
        showToast(editingItem ? (cfg.customerLabel || 'Cari') + ' güncellendi' : (cfg.customerLabel || 'Cari') + ' eklendi');
        setIsModalOpen(false); setEditingItem(null); await fetchData();
      } catch (err: any) {
        const d = err.response?.data?.detail;
        const msg = Array.isArray(d) ? d.map((e: any) => `${e.loc?.join('.')}: ${e.msg}`).join('\n') : (d || err.message || 'Kayıt sırasında hata oluştu');
        showToast(`Hata: ${msg}`, 'error');
      } finally { setSaving(false); }
    } else {
      // FİNANS — düz işlem ekleme/düzenleme (Kasa, Garanti)
      if (!formTitle.trim()) { showToast('Lütfen ' + (cfg.customerLabel || 'müşteri') + ' adını girin', 'error'); return; }
      const amt = parseFloat(formTxAmount);
      if (isNaN(amt) || amt <= 0) { showToast("Tutar 0'dan büyük olmalıdır", 'error'); return; }
      try {
        setSaving(true);
        const _kdv = Math.max(0, Math.min(100, parseFloat(formKdvRate) || 0));
        if (editingItem) {
          await api.put(`/finance/transactions/${editingItem.id}`, {
            customer_name: formTitle.trim(),
            amount: amt,
            currency: formTxCurrency || 'TRY',
            notes: formNotes.trim() || null,
            kdv_rate: _kdv,
          });
        } else {
          await api.post('/finance/transactions', {
            transaction_type: formTxType || cfg.transactionType || 'borç',
            customer_name: formTitle.trim(),
            amount: amt,
            currency: formTxCurrency || 'TRY',
            notes: formNotes.trim() || null,
            kdv_rate: _kdv,
          });
        }
        showToast(editingItem ? 'İşlem güncellendi' : 'İşlem kaydedildi');
        setIsModalOpen(false); setEditingItem(null); await fetchData();
      } catch (err: any) {
        const d = err.response?.data?.detail;
        const msg = Array.isArray(d) ? d.map((e: any) => `${e.loc?.join('.')}: ${e.msg}`).join('\n') : (d || err.message || 'Kayıt sırasında hata oluştu');
        showToast(`Hata: ${msg}`, 'error');
      } finally { setSaving(false); }
    }
  };

  // ----- SİL ----------------------------------------------------------
  const handleDelete = async (item: any) => {
    const confirmMsg = cfg.grouped
      ? `"${item.title}" carisini ve TÜM borç/tahsilat hareketlerini silmek istediğinizden emin misiniz?`
      : `"${item.title}" kaydını silmek istediğinizden emin misiniz?`;
    if (!window.confirm(confirmMsg)) return;
    try {
      if (cfg.type === 'stok') {
        await api.delete(`/products/${item.id}`);
      } else if (cfg.grouped) {
        await api.delete(`/finance/customers/${encodeURIComponent(item.cariName || item.title)}`, {
          params: { transaction_type: cfg.transactionType },
        });
      } else {
        await api.delete(`/finance/transactions/${item.id}`);
      }
      showToast('Kayıt silindi');
      await fetchData();
    } catch (err: any) {
      const msg = err.response?.data?.detail || err.message || 'Silme sırasında hata oluştu';
      showToast(`Hata: ${msg}`, 'error');
    }
  };

  const handleAdjustStock = async (item: any, delta: number) => {
    try {
      await api.post(`/products/${item.id}/adjust-stock`, { delta });
      showToast(delta > 0 ? `+${delta} stok eklendi` : `${delta} stok düşüldü`);
      await fetchData();
    } catch (err: any) {
      const d = err.response?.data?.detail;
      const msg = Array.isArray(d) ? d.map((e: any) => e.msg).join(', ') : (d || err.message || 'Stok güncellenemedi');
      showToast(`Hata: ${msg}`, 'error');
    }
  };

  const handleQuickSell = async (productId: number, quantity: number, customerName: string) => {
    try {
      const r = await api.post(`/products/${productId}/quick-sell`, {
        quantity,
        customer_name: customerName.trim() || 'Hızlı Satış',
      });
      const tot = r.data?.total ?? 0;
      const cur = r.data?.transaction?.currency || 'TRY';
      showToast(`Satış kaydedildi: ${formatMoney(tot, cur)} (${quantity} adet)`);
      await fetchData();
      setQuickSellTarget(null);
    } catch (err: any) {
      const d = err.response?.data?.detail;
      const msg = Array.isArray(d) ? d.map((e: any) => e.msg).join(', ') : (d || err.message || 'Satış başarısız');
      showToast(`Hata: ${msg}`, 'error');
    }
  };

  const sortMode: 'name_asc' | 'date_desc' =
    cfg.sortMode || (cfg.type === 'finans' ? 'date_desc' : 'name_asc');
  const filteredRows = rawData.filter(item => {
    const term = searchTerm.toLowerCase();
    const matchesSearch =
      item.title.toLowerCase().includes(term) ||
      (item.barcode && item.barcode.includes(searchTerm)) ||
      (item.subcategory && item.subcategory.toLowerCase().includes(term));
    const matchesSub = !subcategoryFilter || (item.subcategory || '') === subcategoryFilter;
    // Ana kategori (sekme) eşitliği — extra_categories artık alt etiket; ana kategori bleed olmaz
    const matchesCat = !categoryFilter
      || (item.category || '').toLowerCase() === categoryFilter.toLowerCase();
    return matchesSearch && matchesSub && matchesCat;
  });
  const filteredData = sortMode === 'date_desc'
    ? [...filteredRows].sort((a, b) => {
        const ta = a.date ? new Date(a.date).getTime() : 0;
        const tb = b.date ? new Date(b.date).getTime() : 0;
        if (tb !== ta) return tb - ta;
        return (b.id || 0) - (a.id || 0);
      })
    : sortAlpha(filteredRows, 'title');

  const subcategoryOptions = Array.from(new Set(
    rawData.map((r: any) => (r.subcategory || '').trim()).filter(Boolean)
  )).sort((a: string, b: string) => a.localeCompare(b, 'tr-TR'));

  // Arama/filtre dropdown'u SADECE ana kategorileri (sekme isimleri) gösterir.
  // Alt kategoriler / marka-tür / etiketler buraya katılmaz; onlar Filtre çubuğundan filtrelenir.
  const categoryOptions = Array.from(new Set([
    ...allCategories,
    ...rawData.map((r: any) => (r.category || '').trim()),
  ].filter(Boolean))).sort((a: string, b: string) => a.localeCompare(b, 'tr-TR'));

  const totalPages = Math.max(1, Math.ceil(filteredData.length / PAGE_SIZE));
  const safePage = Math.min(currentPage, totalPages);
  const paginatedData = filteredData.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

  useEffect(() => { setCurrentPage(1); }, [searchTerm, subcategoryFilter, categoryFilter, moduleId]);
  // Modüle ilk girişte filtre, modülün kendi kategorisine kilitlenir.
  // Örn: "Paspas" sekmesinde sadece Paspas kategorisindeki ürünler görünür.
  // Kullanıcı dropdown'dan başka kategori (ya da "Tüm Kategoriler") seçebilir.
  useEffect(() => { setCategoryFilter(cfg.categoryFilter || ''); setSubcategoryFilter(null); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [moduleId]);

  // Finans için "Yönet" tıklandı: cari detay görünümü
  if (cfg.type === 'finans' && selectedCari) {
    return <CariDetailView cari={selectedCari} onBack={() => { setSelectedCari(null); fetchData(); }} moduleTitle={t(title)} permissions={p} />;
  }

  const toneClass = (tone: string) => {
    switch (tone) {
      case 'red':     return 'text-red-600 dark:text-red-400';
      case 'amber':   return 'text-amber-600 dark:text-amber-400';
      case 'indigo':  return 'text-indigo-600 dark:text-indigo-400';
      case 'purple':  return 'text-purple-600 dark:text-purple-400';
      case 'emerald': return 'text-emerald-600 dark:text-emerald-400';
      default:        return 'text-slate-800 dark:text-white';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center shrink-0"><Icon size={28} /></div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-800 dark:text-white">{t(title)} {t('Yönetimi')}</h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">
              {t('Toplam')} {filteredData.length} {t('kayıt listeleniyor.')} {sortMode === 'date_desc' ? t('Sıralama: Yeniden eskiye.') : t('Sıralama: A-Z.')}
            </p>
          </div>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
          <div className="flex gap-2 w-full sm:w-64">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input type="text" placeholder={t('Ara...')} value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition text-sm font-medium" />
            </div>
            {cfg.type === 'stok' && (
              <button type="button" onClick={() => setListScanOpen(true)} title="Barkod / QR Tara"
                className="flex items-center justify-center w-11 rounded-xl bg-indigo-50 dark:bg-indigo-900/30 border border-indigo-200 dark:border-indigo-800/50 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition shrink-0">
                <ScanLine size={18} />
              </button>
            )}
          </div>
          {listScanOpen && (
            <QRScannerModal
              fillMode={true}
              title="Ürün Ara (QR / Barkod)"
              onDetected={(text) => { setSearchTerm(text); setListScanOpen(false); }}
              onClose={() => setListScanOpen(false)}
            />
          )}
          {cfg.type === 'stok' && categoryOptions.length > 0 && (
            <div className="relative w-full sm:w-52">
              <FolderTree className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={18} />
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="w-full pl-10 pr-8 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition text-sm font-bold appearance-none cursor-pointer"
              >
                <option value="">Tüm Kategoriler</option>
                {categoryOptions.map((opt: string) => (
                  <option key={opt} value={opt}>{opt}</option>
                ))}
              </select>
              <ChevronRight className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 rotate-90 pointer-events-none" size={16} />
            </div>
          )}
          <button
            onClick={() => {
              if (cfg.type === 'stok') {
                exportStok(filteredData, t(title), hasPerm(currentUser, 'products.view_cost'));
              } else if (cfg.grouped) {
                exportFinansCariler(filteredData, t(title));
              } else {
                exportFinansIslemler(filteredData, t(title));
              }
            }}
            title="Excel olarak indir"
            className="flex items-center gap-1.5 px-3 py-2.5 bg-emerald-600 hover:bg-emerald-700 transition text-white font-bold rounded-xl shadow-md shadow-emerald-200 dark:shadow-emerald-900/20 shrink-0 text-sm"
          >
            <Download size={16} /> <span className="hidden sm:inline">Excel</span>
          </button>
          {(p.canAdd || p.allowedModules === 'all') && (
            <button onClick={() => { setEditingItem(null); setIsModalOpen(true); }}
              className="flex justify-center items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 transition text-white font-bold rounded-xl shadow-md shadow-indigo-200 dark:shadow-indigo-900/20 shrink-0">
              <Plus size={18} /> {t('Yeni Kayıt')}
            </button>
          )}
        </div>
      </div>

      {/* Alt-etiket (marka/tür) chip filtresi — sadece stok ve seçenek varsa */}
      {cfg.type === 'stok' && subcategoryOptions.length > 0 && (
        <div className="bg-white dark:bg-slate-900 px-4 py-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-2 overflow-x-auto scrollbar-thin">
          <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider shrink-0 mr-1">Filtre:</span>
          <button
            onClick={() => setSubcategoryFilter(null)}
            className={`px-3 py-1.5 rounded-full text-xs font-bold transition shrink-0 ${
              !subcategoryFilter
                ? 'bg-indigo-600 text-white shadow'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >Tümü</button>
          {subcategoryOptions.map((opt: string) => (
            <button
              key={opt}
              onClick={() => setSubcategoryFilter(subcategoryFilter === opt ? null : opt)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold transition shrink-0 ${
                subcategoryFilter === opt
                  ? 'bg-indigo-600 text-white shadow'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >{opt}</button>
          ))}
        </div>
      )}

      {/* === İçerik (görünüm modu kategoriden gelir) === */}
      {(() => {
        const viewMode: 'list' | 'grid' | 'masonry' | 'carousel' | 'category' = (cfg.viewMode as any) || 'list';

        // Ortak kart bileşeni — hem stok hem finans için
        const ItemCard = ({ row, compact = false }: { row: any; compact?: boolean }) => (
          <div className="group bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden hover:shadow-lg hover:border-indigo-300 dark:hover:border-indigo-700 transition-all flex flex-col">
            {cfg.type === 'stok' && (
              <div className="aspect-square bg-slate-100 dark:bg-slate-800 relative overflow-hidden">
                {row.imageUrl ? (
                  <ZoomImg src={row.imageUrl} alt={row.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-300 dark:text-slate-600"><ImageIcon size={48} /></div>
                )}
                <span className={`absolute top-2 right-2 px-2 py-1 rounded-lg font-bold text-[11px] shadow ${row.amount === 0 ? 'bg-red-500 text-white' : row.amount < 5 ? 'bg-amber-500 text-white' : 'bg-emerald-500 text-white'}`}>{row.amount} {t('Adet')}</span>
              </div>
            )}
            <div className={`p-4 flex flex-col gap-2 flex-1 ${cfg.type === 'finans' ? 'bg-gradient-to-br from-white to-slate-50 dark:from-slate-900 dark:to-slate-800/30' : ''}`}>
              <div className="font-bold text-slate-800 dark:text-white truncate" title={row.title}>{row.title}</div>
              {cfg.type === 'stok' ? (
                <>
                  <div className="text-xs text-slate-400 font-mono truncate">{row.barcode}</div>
                  <div className="flex flex-wrap gap-1">
                    {row.subcategory && (
                      <span className="text-[10px] uppercase tracking-wider font-bold inline-block px-2 py-0.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded border border-indigo-100 dark:border-indigo-800/50">{row.subcategory}</span>
                    )}
                    {Array.isArray(row.extraCategories) && row.extraCategories.slice(0, 3).map((c: string) => (
                      <span key={c} className="text-[10px] uppercase tracking-wider font-bold inline-block px-2 py-0.5 bg-amber-50 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 rounded border border-amber-200 dark:border-amber-800/50">{c}</span>
                    ))}
                    {Array.isArray(row.extraCategories) && row.extraCategories.length > 3 && (
                      <span className="text-[10px] font-bold text-slate-400">+{row.extraCategories.length - 3}</span>
                    )}
                  </div>
                  {!compact && (
                    <div className="flex items-baseline justify-between mt-auto pt-2 border-t border-slate-100 dark:border-slate-800">
                      <span className="text-[11px] text-slate-400">{t('Satış')}</span>
                      <span className="font-black text-emerald-600 dark:text-emerald-400 text-base">{formatMoney(row.sellPrice, row.currency)}</span>
                    </div>
                  )}
                </>
              ) : (
                <>
                  <div className={`text-[11px] uppercase tracking-wider font-bold inline-block px-2 py-0.5 rounded border self-start ${txTypeTone(row.type)}`}>{txTypeLabel(row.type)}</div>
                  {row.notes && <div className="text-[11px] text-slate-500 italic line-clamp-2">{row.notes}</div>}
                  <div className={`mt-auto pt-2 border-t border-slate-100 dark:border-slate-800 font-black text-lg ${toneClass(cfg.amountTone)}`}>{formatMoney(row.balance, row.currency)}</div>
                  <div className="text-[11px] text-slate-400">{new Date(row.date).toLocaleDateString('tr-TR')}</div>
                </>
              )}
              {cfg.type === 'stok' && (p.canEdit || p.allowedModules === 'all') && (
                <div className="flex gap-1">
                  <button
                    onClick={() => setQuickSellTarget(row)}
                    disabled={(row.amount || 0) <= 0}
                    className="flex-1 py-1.5 text-[11px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-900/40 hover:bg-emerald-200 dark:hover:bg-emerald-900/60 rounded-lg transition flex items-center justify-center gap-1 disabled:opacity-30 disabled:cursor-not-allowed"
                    title="Hızlı Sat"
                  >
                    <ShoppingCart size={12} /> Sat
                  </button>
                  <button
                    onClick={() => handleAdjustStock(row, +1)}
                    className="py-1.5 px-2 text-[11px] font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 dark:hover:bg-blue-900/40 rounded-lg transition"
                    title="Stok +1"
                  >
                    <Plus size={12} />
                  </button>
                  <button
                    onClick={() => handleAdjustStock(row, -1)}
                    disabled={(row.amount || 0) <= 0}
                    className="py-1.5 px-2 text-[11px] font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 hover:bg-amber-100 dark:hover:bg-amber-900/40 rounded-lg transition disabled:opacity-30 disabled:cursor-not-allowed"
                    title="Stok -1"
                  >
                    <Minus size={12} />
                  </button>
                </div>
              )}
              <div className="flex gap-1 -mb-1">
                {(p.canEdit || p.allowedModules === 'all') && (
                  <button onClick={() => { setEditingItem(row); setIsModalOpen(true); }} className="flex-1 py-1.5 text-xs font-bold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-100 dark:hover:bg-indigo-900/30 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg transition flex items-center justify-center gap-1">
                    <Edit size={12} /> {t('Düzenle')}
                  </button>
                )}
                {(p.canDelete || p.allowedModules === 'all') && (
                  <button onClick={() => handleDelete(row)} className="py-1.5 px-2 text-xs font-bold text-red-500 bg-red-50 dark:bg-red-900/20 hover:bg-red-100 dark:hover:bg-red-900/40 rounded-lg transition" title={t('Sil')}>
                    <Trash size={12} />
                  </button>
                )}
                {cfg.type === 'finans' && (
                  <button onClick={() => setSelectedCari(row)} className="py-1.5 px-2 text-xs font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/20 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 rounded-lg transition" title="Yönet">
                    <ChevronRight size={12} />
                  </button>
                )}
              </div>
            </div>
          </div>
        );

        if (loading) return <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-12 text-center text-slate-500 animate-pulse">{t('Veriler Yükleniyor...')}</div>;
        if (filteredData.length === 0) return <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-12 text-center text-slate-500">Bulunamadı.</div>;

        if (viewMode === 'grid') {
          return (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {paginatedData.map((row) => <ItemCard key={row.id} row={row} />)}
            </div>
          );
        }

        if (viewMode === 'masonry') {
          return (
            <div className="columns-2 sm:columns-3 lg:columns-4 gap-4 [column-fill:_balance]">
              {paginatedData.map((row, idx) => (
                <div key={row.id} className="break-inside-avoid mb-4" style={{ minHeight: cfg.type === 'stok' ? `${260 + (idx % 3) * 40}px` : 'auto' }}>
                  <ItemCard row={row} />
                </div>
              ))}
            </div>
          );
        }

        if (viewMode === 'carousel') {
          return (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm">
              <div className="flex gap-4 overflow-x-auto snap-x snap-mandatory pb-2 scrollbar-thin">
                {paginatedData.map((row) => (
                  <div key={row.id} className="snap-start shrink-0 w-56">
                    <ItemCard row={row} />
                  </div>
                ))}
              </div>
            </div>
          );
        }

        if (viewMode === 'category') {
          // İlk harfe göre alt-grup oluştur (Stok için: A, B, C... grupları; Finans için: tarih ay-yıl)
          const groups: Record<string, any[]> = {};
          const labels: Record<string, string> = {};
          for (const row of filteredData) {
            let key: string; let label: string;
            if (cfg.type === 'stok') {
              key = (row.title || '?').trim().charAt(0).toUpperCase() || '?';
              label = `${key} ile başlayanlar`;
            } else {
              const d = new Date(row.date);
              if (isNaN(d.getTime())) { key = '0000-00'; label = '—'; }
              else {
                const mm = String(d.getMonth() + 1).padStart(2, '0');
                key = `${d.getFullYear()}-${mm}`;
                label = `${mm}.${d.getFullYear()}`;
              }
            }
            (groups[key] ||= []).push(row);
            labels[key] = label;
          }
          const orderedKeys = Object.keys(groups).sort((a, b) => cfg.type === 'finans' ? b.localeCompare(a) : a.localeCompare(b));
          return (
            <div className="space-y-6">
              {orderedKeys.map((gk) => (
                <div key={gk} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 sm:p-5 shadow-sm">
                  <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-100 dark:border-slate-800">
                    <div className="w-9 h-9 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-xl flex items-center justify-center font-black text-sm">{cfg.type === 'stok' ? gk : labels[gk].slice(0, 2)}</div>
                    <h3 className="font-black text-slate-800 dark:text-white">{labels[gk]}</h3>
                    <span className="text-xs text-slate-400 font-bold">({groups[gk].length})</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                    {groups[gk].map((row) => <ItemCard key={row.id} row={row} compact />)}
                  </div>
                </div>
              ))}
            </div>
          );
        }

        // Varsayılan: LIST (klasik tablo)
        return (
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto scrollbar-thin">
          {loading ? (
            <div className="p-12 text-center text-slate-500 animate-pulse">{t('Veriler Yükleniyor...')}</div>
          ) : (
            <table className="w-full text-left border-collapse min-w-[800px]">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 text-xs uppercase border-b border-slate-200 dark:border-slate-700 tracking-wider">
                  {cfg.type === 'stok' ? (
                    <><th className="p-4 pl-6 font-bold w-1/3">{t('Ürün Modeli')}</th><th className="p-4 font-bold">Barkod</th><th className="p-4 font-bold">Alış / Satış</th><th className="p-4 font-bold text-center">{t('Stok')}</th></>
                  ) : (
                    <><th className="p-4 pl-6 font-bold">{cfg.customerLabel || 'Cari'}</th><th className="p-4 font-bold">{cfg.grouped ? 'İlk Kayıt' : 'Tarih'}</th><th className="p-4 font-bold text-right">{cfg.grouped ? 'Toplam Borç' : (cfg.amountLabel || 'Tutar')}</th></>
                  )}
                  <th className="p-4 pr-6 text-right font-bold">İşlemler</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {paginatedData.length > 0 ? paginatedData.map(row => (
                  <tr key={row.id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition group">
                    <td className="p-4 pl-6">
                      <div className="flex items-center gap-3">
                        {cfg.type === 'stok' && (
                          row.imageUrl ? (
                            <ZoomImg src={row.imageUrl} alt="" className="w-10 h-10 rounded-lg object-cover border border-slate-200 dark:border-slate-700 shrink-0"/>
                          ) : (
                            <div className="w-10 h-10 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-300 dark:text-slate-600 shrink-0"><ImageIcon size={16}/></div>
                          )
                        )}
                        <div>
                          <div className="font-bold text-slate-800 dark:text-slate-100 mb-0.5">{row.title}</div>
                          {cfg.type === 'stok' && (
                            <div className="flex flex-wrap gap-1">
                              <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded border border-slate-200 dark:border-slate-700">{row.category}</span>
                              {row.subcategory && (
                                <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded border border-indigo-100 dark:border-indigo-800/50">{row.subcategory}</span>
                              )}
                              {Array.isArray(row.extraCategories) && row.extraCategories.map((c: string) => (
                                <span key={c} className="text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 bg-amber-50 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 rounded border border-amber-200 dark:border-amber-800/50">{c}</span>
                              ))}
                            </div>
                          )}
                          {cfg.type === 'finans' && !cfg.grouped && <span className={`text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded border ${txTypeTone(row.type)}`}>{txTypeLabel(row.type)}</span>}
                          {cfg.type === 'finans' && cfg.grouped && (
                            <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded border bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800/50">
                              {row.txnCount || 0} hareket
                            </span>
                          )}
                          {cfg.type === 'finans' && row.notes && <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 italic">{row.notes}</div>}
                        </div>
                      </div>
                    </td>

                    {cfg.type === 'stok' ? (
                      <>
                        <td className="p-4 text-slate-500 dark:text-slate-400 font-mono text-xs">{row.barcode}</td>
                        <td className="p-4 text-xs font-bold text-slate-600 dark:text-slate-300">
                          <div className="flex flex-col gap-0.5">
                            {hasPerm(currentUser, 'products.view_cost') && (
                              <span className="text-slate-400">Alış: {formatMoney(row.buyPrice, row.costCurrency || row.currency)}</span>
                            )}
                            <span className="text-emerald-600 dark:text-emerald-400">Satış: {formatMoney(row.sellPrice, row.currency)}</span>
                            {hasPerm(currentUser, 'products.view_cost') && row.costCurrency && row.costCurrency !== row.currency && (
                              <span className="text-[10px] text-amber-600 dark:text-amber-400 font-bold">Çapraz Kur</span>
                            )}
                          </div>
                        </td>
                        <td className="p-4 text-center">
                          <span className={`px-3 py-1 rounded-lg font-bold text-xs shadow-sm ${row.amount === 0 ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 border border-red-200 dark:border-red-800/50' : row.amount < 5 ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 border border-amber-200 dark:border-amber-800/50' : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-800/50'}`}>
                            {row.amount} Adet
                          </span>
                        </td>
                      </>
                    ) : (
                      <>
                        <td className="p-4">
                          <div className="font-medium text-slate-600 dark:text-slate-300">{new Date(row.date).toLocaleDateString('tr-TR')}</div>
                        </td>
                        <td className={`p-4 font-black text-right text-base ${cfg.grouped && row.balance < 0 ? 'text-emerald-600 dark:text-emerald-400' : toneClass(cfg.amountTone)}`}>
                          {formatMoney(Math.abs(row.balance ?? 0), row.currency)}
                          {cfg.grouped && row.balance < 0 && <span className="block text-[10px] font-bold uppercase tracking-wider text-emerald-500">Alacak</span>}
                          {cfg.grouped && row.balance === 0 && <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">Kapalı</span>}
                        </td>
                      </>
                    )}

                    <td className="p-4 pr-6 text-right align-middle">
                      <div className="flex justify-end gap-1 opacity-70 group-hover:opacity-100 transition-opacity">
                        {cfg.type === 'stok' && (p.canEdit || p.allowedModules === 'all') && (
                          <>
                            <button
                              onClick={() => setQuickSellTarget(row)}
                              disabled={(row.amount || 0) <= 0}
                              className="p-2 text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/20 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 rounded-lg transition disabled:opacity-30 disabled:cursor-not-allowed"
                              title="Hızlı Sat"
                            >
                              <ShoppingCart size={16}/>
                            </button>
                            <button
                              onClick={() => handleAdjustStock(row, +1)}
                              className="p-2 text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 dark:hover:bg-blue-900/40 rounded-lg transition"
                              title="Stok +1"
                            >
                              <Plus size={16}/>
                            </button>
                            <button
                              onClick={() => handleAdjustStock(row, -1)}
                              disabled={(row.amount || 0) <= 0}
                              className="p-2 text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 hover:bg-amber-100 dark:hover:bg-amber-900/40 rounded-lg transition disabled:opacity-30 disabled:cursor-not-allowed"
                              title="Stok -1"
                            >
                              <Minus size={16}/>
                            </button>
                          </>
                        )}
                        {(p.canEdit || p.allowedModules === 'all') && (
                          <button onClick={() => { setEditingItem(row); setIsModalOpen(true); }} className="p-2 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg transition" title="Düzenle">
                            <Edit size={16}/>
                          </button>
                        )}
                        {(p.canDelete || p.allowedModules === 'all') && (
                          <button onClick={() => handleDelete(row)} className="p-2 text-slate-500 dark:text-slate-400 hover:bg-red-50 dark:hover:bg-red-900/30 hover:text-red-600 dark:hover:text-red-400 rounded-lg transition" title="Sil">
                            <Trash size={16}/>
                          </button>
                        )}
                        {cfg.type === 'finans' && cfg.grouped && (
                          <button onClick={() => setDebtorLinkTarget(row.cariName || row.title)} className="p-2 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/30 rounded-lg transition inline-flex items-center gap-1 text-xs font-bold" title="Müşteriye anlık borç/ödeme linki gönder">
                            <Mail size={14}/> Slip
                          </button>
                        )}
                        {cfg.type === 'finans' && (
                          <button onClick={() => setSelectedCari(row)} className="p-2 ml-1 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-lg transition inline-flex items-center gap-1 text-xs font-bold" title="Cari Detay">
                            Yönet <ChevronRight size={14}/>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                )) : (
                  <tr><td colSpan={5} className="p-12 text-center text-slate-500">Bulunamadı.</td></tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>
        );
      })()}

      {/* Sayfalandırma — kategori görünümünde gizli (gruplama uygulanır) */}
      {!loading && cfg.viewMode !== 'category' && filteredData.length > PAGE_SIZE && (() => {
        const pages: (number | string)[] = [];
        const tp = totalPages;
        const cur = safePage;
        const push = (v: number | string) => pages.push(v);
        const range = (a: number, b: number) => { for (let i = a; i <= b; i++) push(i); };
        if (tp <= 7) range(1, tp);
        else {
          push(1);
          if (cur > 4) push('…');
          range(Math.max(2, cur - 1), Math.min(tp - 1, cur + 1));
          if (cur < tp - 3) push('…');
          push(tp);
        }
        return (
          <div className="bg-white dark:bg-slate-900 px-4 py-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-wrap items-center justify-between gap-3">
            <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {(safePage - 1) * PAGE_SIZE + 1}–{Math.min(safePage * PAGE_SIZE, filteredData.length)} / {filteredData.length} kayıt
            </div>
            <div className="flex items-center gap-1 flex-wrap">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={safePage <= 1}
                className="px-3 py-1.5 text-xs font-bold rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed transition"
              >‹ Önceki</button>
              {pages.map((pg, i) => (
                typeof pg === 'number' ? (
                  <button
                    key={`p-${pg}`}
                    onClick={() => setCurrentPage(pg)}
                    className={`min-w-[34px] px-2.5 py-1.5 text-xs font-bold rounded-lg transition ${
                      pg === safePage
                        ? 'bg-indigo-600 text-white shadow'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >{pg}</button>
                ) : (
                  <span key={`e-${i}`} className="px-2 text-slate-400 text-xs">…</span>
                )
              ))}
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={safePage >= totalPages}
                className="px-3 py-1.5 text-xs font-bold rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed transition"
              >Sonraki ›</button>
            </div>
          </div>
        );
      })()}

      {/* Modal: Yeni / Düzenleme Formu */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 dark:bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 z-[100]">
          <div className="bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl max-w-lg w-full animate-in slide-in-from-bottom-4 sm:zoom-in-95 duration-200 shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[92svh] sm:max-h-[calc(100vh-2rem)]">
            <div className="shrink-0 flex justify-between items-center px-5 sm:px-8 pt-5 sm:pt-7 pb-4 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-xl font-black text-slate-800 dark:text-white flex items-center gap-2">
                <div className="w-8 h-8 bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 rounded-lg flex items-center justify-center">
                  {editingItem ? <Edit size={16}/> : <Plus size={16}/>}
                </div>
                {editingItem
                  ? (cfg.grouped ? `${cfg.customerLabel || 'Cari'} Düzenle` : t('Kaydı Düzenle'))
                  : (cfg.grouped ? `Yeni ${cfg.customerLabel || 'Cari'}` : t('Yeni Kayıt'))}
              </h3>
              <button onClick={() => { setIsModalOpen(false); setEditingItem(null); }} className="text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 p-2 rounded-xl transition"><X size={20}/></button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 sm:px-8 py-5 scrollbar-thin">
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">
                  {cfg.type === 'stok' ? t('Ürün Modeli') : (cfg.customerLabel || 'Müşteri / Firma Adı')}
                </label>
                <input type="text" value={formTitle} onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium" />
              </div>

              {cfg.type === 'stok' && (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">Ana Kategori</label>
                      <input
                        type="text"
                        value={(editingItem?.category || formCategory || cfg.defaultCategory || cfg.categoryFilter || '').toString()}
                        readOnly
                        disabled
                        title="Ana kategori, içinde bulunduğunuz sekmeden gelir ve değiştirilemez"
                        className="w-full px-4 py-3 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 rounded-xl outline-none font-medium cursor-not-allowed"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">Marka / Tür</label>
                      <input
                        type="text"
                        list="dl-subcategories"
                        value={formSubcategory}
                        onChange={(e) => setFormSubcategory(e.target.value)}
                        placeholder="Yazın veya seçin..."
                        className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium"
                      />
                      <datalist id="dl-subcategories">
                        {subcategoryOptions.map((s: string) => <option key={s} value={s} />)}
                      </datalist>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">Alt Kategoriler / Etiketler (bu kategorideki özellikler)</label>
                    <div className="flex flex-wrap gap-1.5 px-3 py-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl min-h-[48px] focus-within:ring-2 focus-within:ring-indigo-500">
                      {formExtraCategories.map((c: string) => (
                        <span key={c} className="inline-flex items-center gap-1 px-2.5 py-1 bg-indigo-100 dark:bg-indigo-900/40 text-indigo-700 dark:text-indigo-300 rounded-lg text-xs font-bold">
                          {c}
                          <button
                            type="button"
                            onClick={() => setFormExtraCategories(formExtraCategories.filter(x => x !== c))}
                            className="hover:text-indigo-900 dark:hover:text-indigo-100"
                            aria-label={`${c} kaldır`}
                          >
                            <X size={12} />
                          </button>
                        </span>
                      ))}
                      <input
                        type="text"
                        list="dl-extra-categories"
                        value={formExtraInput}
                        onChange={(e) => {
                          const v = e.target.value;
                          if (v.includes(',')) {
                            const parts = v.split(',').map(s => s.trim()).filter(Boolean);
                            const mainLower = (formCategory || '').trim().toLowerCase();
                            const lowerSet = new Set(formExtraCategories.map(c => c.toLowerCase()));
                            const adds: string[] = [];
                            for (const p of parts) {
                              const pl = p.toLowerCase();
                              if (pl !== mainLower && !lowerSet.has(pl)) {
                                lowerSet.add(pl);
                                adds.push(p);
                              }
                            }
                            if (adds.length) setFormExtraCategories([...formExtraCategories, ...adds]);
                            setFormExtraInput('');
                          } else {
                            setFormExtraInput(v);
                          }
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            const val = formExtraInput.trim();
                            const vl = val.toLowerCase();
                            const mainLower = (formCategory || '').trim().toLowerCase();
                            if (val && vl !== mainLower && !formExtraCategories.some(c => c.toLowerCase() === vl)) {
                              setFormExtraCategories([...formExtraCategories, val]);
                            }
                            setFormExtraInput('');
                          } else if (e.key === 'Backspace' && !formExtraInput && formExtraCategories.length > 0) {
                            setFormExtraCategories(formExtraCategories.slice(0, -1));
                          }
                        }}
                        onBlur={() => {
                          const val = formExtraInput.trim();
                          const vl = val.toLowerCase();
                          const mainLower = (formCategory || '').trim().toLowerCase();
                          if (val && vl !== mainLower && !formExtraCategories.some(c => c.toLowerCase() === vl)) {
                            setFormExtraCategories([...formExtraCategories, val]);
                          }
                          setFormExtraInput('');
                        }}
                        placeholder={formExtraCategories.length === 0 ? 'Yazıp Enter veya virgül...' : ''}
                        className="flex-1 min-w-[120px] bg-transparent outline-none text-sm font-medium text-slate-800 dark:text-slate-100"
                      />
                      <datalist id="dl-extra-categories">
                        {Array.from(new Set([...allCategories, ...categoryOptions]))
                          .filter((c: string) => {
                            const cl = c.toLowerCase();
                            const main = (formCategory || '').trim().toLowerCase();
                            return cl !== main && !formExtraCategories.some(e => e.toLowerCase() === cl);
                          })
                          .map((c: string) => <option key={c} value={c} />)}
                      </datalist>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">Barkod No</label>
                    <div className="relative flex gap-2">
                      <div className="relative flex-1">
                        <Barcode size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
                        <input type="text" value={formBarcode} onChange={(e) => setFormBarcode(e.target.value)}
                          className="w-full pl-9 pr-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium" placeholder="Okutun veya yazın..." />
                      </div>
                      <button type="button" onClick={() => setBarcodeScanOpen(true)}
                        title="Kamerayla Tara"
                        className="flex items-center justify-center w-12 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white transition shrink-0">
                        <Camera size={18} />
                      </button>
                    </div>
                    {barcodeScanOpen && (
                      <QRScannerModal
                        fillMode={true}
                        title="Barkod Tara"
                        onDetected={(text) => { setFormBarcode(text); setBarcodeScanOpen(false); }}
                        onClose={() => setBarcodeScanOpen(false)}
                      />
                    )}
                  </div>
                  <div className="border-t border-slate-100 dark:border-slate-800 pt-4 mt-2 grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2 uppercase">Alış Para Birimi</label>
                      <div className="flex gap-1.5">
                        {CURRENCIES.map(c => (
                          <button
                            key={c.code}
                            type="button"
                            onClick={() => setFormCostCurrency(c.code)}
                            className={`flex-1 px-2 py-2 rounded-xl text-xs font-bold transition border ${
                              formCostCurrency === c.code
                                ? 'bg-amber-600 text-white border-amber-600 shadow'
                                : 'bg-slate-50 dark:bg-slate-800/50 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                            }`}
                          >{c.symbol} {c.code}</button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2 uppercase">Satış Para Birimi</label>
                      <div className="flex gap-1.5">
                        {CURRENCIES.map(c => (
                          <button
                            key={c.code}
                            type="button"
                            onClick={() => setFormCurrency(c.code)}
                            className={`flex-1 px-2 py-2 rounded-xl text-xs font-bold transition border ${
                              formCurrency === c.code
                                ? 'bg-indigo-600 text-white border-indigo-600 shadow'
                                : 'bg-slate-50 dark:bg-slate-800/50 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                            }`}
                          >{c.symbol} {c.code}</button>
                        ))}
                      </div>
                    </div>
                  </div>
                  {formCostCurrency !== formCurrency && (
                    <div className="rounded-xl bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-2.5 text-[11px] font-bold text-amber-700 dark:text-amber-300 flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-md bg-amber-200 dark:bg-amber-800/60">Çapraz Kur</span>
                      <span>Alış {formCostCurrency} ile, satış {formCurrency} ile yapılacak. Kar marjı tek para birimine çevrilince hesaplanır.</span>
                    </div>
                  )}
                  <div className={`grid gap-3 ${hasPerm(currentUser, 'products.view_cost') ? 'grid-cols-4' : 'grid-cols-3'}`}>
                    {hasPerm(currentUser, 'products.view_cost') && (
                    <div>
                      <label className="block text-[10px] font-bold text-amber-600 dark:text-amber-400 mb-1 uppercase">Alış ({CURRENCIES.find(c => c.code === formCostCurrency)?.symbol || '₺'})</label>
                      <input type="number" value={formBuyPrice} onChange={(e) => setFormBuyPrice(e.target.value)}
                        className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:border-amber-500 transition font-bold" placeholder="0.00" />
                    </div>
                    )}
                    <div>
                      <label className="block text-[10px] font-bold text-indigo-600 dark:text-indigo-400 mb-1 uppercase">Satış ({CURRENCIES.find(c => c.code === formCurrency)?.symbol || '₺'})</label>
                      <input type="number" value={formSellPrice} onChange={(e) => setFormSellPrice(e.target.value)}
                        className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-indigo-700 dark:text-indigo-400 rounded-xl outline-none focus:border-indigo-500 transition font-bold" placeholder="0.00" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase">Stok</label>
                      <input type="number" value={formAmount} onChange={(e) => setFormAmount(e.target.value)}
                        className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-emerald-700 dark:text-emerald-400 rounded-xl outline-none focus:border-indigo-500 transition font-bold" placeholder="0" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-amber-500 mb-1 uppercase">Min. Uyarı</label>
                      <input type="number" value={formMinStock} onChange={(e) => setFormMinStock(e.target.value)}
                        className="w-full px-3 py-2.5 bg-slate-50 dark:bg-slate-800/50 border border-amber-200 dark:border-amber-900/50 text-amber-700 dark:text-amber-400 rounded-xl outline-none focus:border-amber-500 transition font-bold" placeholder="5" min="0" />
                    </div>
                  </div>
                  <div className="border-t border-slate-100 dark:border-slate-800 pt-4 mt-2">
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-2 uppercase">Ürün Fotoğrafı</label>
                    <div className="flex items-center gap-4">
                      {formImagePreview ? (
                        <img src={formImagePreview} alt="Önizleme" className="w-16 h-16 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"/>
                      ) : (
                        <div className="w-16 h-16 rounded-xl bg-slate-100 dark:bg-slate-800 border-2 border-dashed border-slate-300 dark:border-slate-600 flex items-center justify-center text-slate-400 shrink-0"><ImageIcon size={22}/></div>
                      )}
                      <label className="cursor-pointer flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition text-sm">
                        <UploadCloud size={16}/> Fotoğraf Seç
                        <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if(f){setFormImageFile(f);setFormImagePreview(URL.createObjectURL(f));} }} />
                      </label>
                      {formImageFile && <span className="text-xs text-slate-400 truncate max-w-[120px]">{formImageFile.name}</span>}
                    </div>
                  </div>
                </>
              )}

              {cfg.type === 'finans' && (
                <>
                  {cfg.allowEditType && !editingItem && !cfg.grouped && (
                    <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">İşlem Türü</label>
                      <select value={formTxType} onChange={(e) => setFormTxType(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium">
                        <option value="borç">Borç</option>
                        <option value="ödeme">Ödeme / Tahsilat</option>
                        <option value="satış">Satış</option>
                        <option value="gider">Gider (Firma Borcu)</option>
                        <option value="senet">Senet</option>
                        <option value="kredi">Kredi</option>
                      </select>
                    </div>
                  )}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">Para Birimi</label>
                    <div className="flex gap-2">
                      {CURRENCIES.map(c => (
                        <button
                          key={c.code}
                          type="button"
                          onClick={() => setFormTxCurrency(c.code)}
                          className={`flex-1 px-3 py-2 rounded-xl text-sm font-bold transition border ${
                            formTxCurrency === c.code
                              ? 'bg-indigo-600 text-white border-indigo-600 shadow'
                              : 'bg-slate-50 dark:bg-slate-800/50 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
                          }`}
                        >{c.symbol} {c.code}</button>
                      ))}
                    </div>
                  </div>
                  {!cfg.grouped && (
                    <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">
                        {(cfg.amountLabel || 'Tutar').replace(/\s*\(.*\)\s*$/, '')} ({CURRENCIES.find(c => c.code === formTxCurrency)?.symbol || '₺'}) — KDV Dahil
                      </label>
                      <input type="number" step="0.01" value={formTxAmount} onChange={(e) => setFormTxAmount(e.target.value)}
                        className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-bold" placeholder="0.00" />
                    </div>
                  )}
                  {!cfg.grouped && (
                    <div>
                      <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">KDV Oranı</label>
                      <div className="flex flex-wrap gap-1.5 mb-2">
                        {['0', '1', '8', '10', '18', '20'].map(r => (
                          <button
                            key={r}
                            type="button"
                            onClick={() => setFormKdvRate(r)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold border ${
                              formKdvRate === r
                                ? 'bg-indigo-600 text-white border-indigo-600'
                                : 'bg-slate-50 dark:bg-slate-800/50 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                            }`}
                          >
                            %{r}
                          </button>
                        ))}
                        <input
                          type="number"
                          min="0"
                          max="100"
                          step="0.01"
                          value={formKdvRate}
                          onChange={(e) => setFormKdvRate(e.target.value)}
                          className="w-20 px-2 py-1.5 rounded-lg text-xs font-bold bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 outline-none focus:ring-2 focus:ring-indigo-500"
                          placeholder="Özel"
                        />
                      </div>
                      {(() => {
                        const gross = parseFloat(formTxAmount) || 0;
                        const rate = Math.max(0, Math.min(100, parseFloat(formKdvRate) || 0));
                        const net = rate > 0 ? gross / (1 + rate / 100) : gross;
                        const kdv = gross - net;
                        const cur = CURRENCIES.find(c => c.code === formTxCurrency)?.symbol || '₺';
                        const fmt = (n: number) => n.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                        return (
                          <div className="rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 p-3 grid grid-cols-3 gap-2 text-xs">
                            <div>
                              <div className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400">KDV Hariç</div>
                              <div className="font-bold text-slate-800 dark:text-slate-100">{cur} {fmt(net)}</div>
                            </div>
                            <div>
                              <div className="text-[10px] uppercase font-bold text-amber-600 dark:text-amber-400">KDV (%{rate})</div>
                              <div className="font-bold text-amber-700 dark:text-amber-300">{cur} {fmt(kdv)}</div>
                            </div>
                            <div>
                              <div className="text-[10px] uppercase font-bold text-indigo-600 dark:text-indigo-400">KDV Dahil</div>
                              <div className="font-bold text-indigo-700 dark:text-indigo-300">{cur} {fmt(gross)}</div>
                            </div>
                          </div>
                        );
                      })()}
                    </div>
                  )}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">Açıklama / Not</label>
                    <textarea value={formNotes} onChange={(e) => setFormNotes(e.target.value)} rows={3}
                      className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition font-medium resize-none"
                      placeholder={cfg.grouped ? 'Cari hakkında not (opsiyonel)' : 'İşlem detayı, açıklama...'} />
                  </div>
                  {cfg.grouped && !editingItem && (
                    <p className="text-xs text-slate-500 dark:text-slate-400 -mt-2 leading-relaxed">
                      Borç ve tahsilat hareketlerini eklemek için kayıt sonrası <strong>Yönet</strong> butonunu kullanın.
                    </p>
                  )}
                </>
              )}
            </div>
            </div>{/* /scrollable content */}

            <div className="shrink-0 flex justify-end gap-3 px-5 sm:px-8 py-4 border-t border-slate-100 dark:border-slate-800">
              <button onClick={() => { setIsModalOpen(false); setEditingItem(null); }} disabled={saving}
                className="px-5 py-3 text-slate-600 dark:text-slate-400 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition disabled:opacity-50">
                {t('İptal Et')}
              </button>
              <button onClick={handleSave} disabled={saving}
                className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition flex items-center gap-2 disabled:opacity-50">
                <Check size={18}/> {saving ? 'Kaydediliyor...' : (editingItem ? t('Değişiklikleri Kaydet') : t('Kaydı Tamamla'))}
              </button>
            </div>
          </div>
        </div>
      )}

      {quickSellTarget && (
        <QuickSellModal
          target={quickSellTarget}
          onClose={() => setQuickSellTarget(null)}
          onConfirm={handleQuickSell}
        />
      )}

      {debtorLinkTarget && (
        <DebtorLinkModal
          customerName={debtorLinkTarget}
          onClose={() => setDebtorLinkTarget(null)}
          showToast={showToast}
        />
      )}
    </div>
  );
};

const QuickSellModal = ({ target, onClose, onConfirm }: { target: any; onClose: () => void; onConfirm: (id: number, qty: number, customer: string) => Promise<void> }) => {
  const [qty, setQty] = useState('1');
  const [customer, setCustomer] = useState('');
  const [busy, setBusy] = useState(false);
  const max = target.amount || 0;
  const qtyNum = Math.max(0, Math.min(parseInt(qty) || 0, max));
  const total = qtyNum * (target.sellPrice || 0);
  const sym = (CURRENCIES.find(c => c.code === (target.currency || 'TRY'))?.symbol) || '₺';

  const submit = async () => {
    if (qtyNum <= 0) return;
    setBusy(true);
    try { await onConfirm(target.id, qtyNum, customer); }
    finally { setBusy(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-0 sm:p-4" onClick={onClose}>
      <div className="bg-white dark:bg-slate-900 rounded-t-2xl sm:rounded-2xl shadow-2xl w-full max-w-md flex flex-col max-h-[92svh] sm:max-h-[calc(100vh-2rem)]" onClick={(e) => e.stopPropagation()}>
        <div className="shrink-0 flex items-center justify-between px-5 sm:px-6 pt-5 sm:pt-6 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <ShoppingCart size={20}/>
            </div>
            <div>
              <div className="font-black text-slate-800 dark:text-white text-lg leading-tight">Hızlı Satış</div>
              <div className="text-xs text-slate-500 dark:text-slate-400 truncate max-w-[200px] sm:max-w-[260px]" title={target.title}>{target.title}</div>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"><X size={18}/></button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 sm:px-6 py-4 scrollbar-thin">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-3">
              <div className="text-[10px] uppercase font-bold text-slate-500 mb-1">Mevcut Stok</div>
              <div className="font-black text-slate-800 dark:text-white text-lg">{max} adet</div>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-3">
              <div className="text-[10px] uppercase font-bold text-slate-500 mb-1">Birim Fiyat</div>
              <div className="font-black text-emerald-600 dark:text-emerald-400 text-lg">{sym}{(target.sellPrice || 0).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">Satış Adedi</label>
            <div className="flex items-center gap-2">
              <button type="button" onClick={() => setQty(String(Math.max(1, qtyNum - 1)))} disabled={qtyNum <= 1} className="w-11 h-11 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-black hover:bg-slate-200 dark:hover:bg-slate-700 transition disabled:opacity-30">−</button>
              <input
                type="number"
                min={1}
                max={max}
                value={qty}
                onChange={(e) => setQty(e.target.value)}
                className="flex-1 text-center px-4 py-3 text-xl font-black bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white rounded-xl outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <button type="button" onClick={() => setQty(String(Math.min(max, qtyNum + 1)))} disabled={qtyNum >= max} className="w-11 h-11 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-black hover:bg-slate-200 dark:hover:bg-slate-700 transition disabled:opacity-30">+</button>
              <button type="button" onClick={() => setQty(String(max))} disabled={max <= 0} className="px-3 h-11 rounded-xl bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold hover:bg-emerald-200 dark:hover:bg-emerald-900/60 transition disabled:opacity-30">Tümü</button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase">Müşteri Adı (opsiyonel)</label>
            <input
              type="text"
              value={customer}
              onChange={(e) => setCustomer(e.target.value)}
              placeholder="Boş bırakılırsa &quot;Hızlı Satış&quot; olarak kaydedilir"
              className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition font-medium"
            />
          </div>

          <div className="rounded-xl bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800/60 p-4 flex items-center justify-between">
            <div>
              <div className="text-[10px] uppercase font-bold text-emerald-700 dark:text-emerald-400">Toplam Tutar</div>
              <div className="text-[11px] text-emerald-600/80 dark:text-emerald-400/80 font-bold">Kasa defterine işlenecek</div>
            </div>
            <div className="text-2xl font-black text-emerald-700 dark:text-emerald-300">{sym}{total.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
          </div>
        </div>
        </div>{/* /scrollable content */}

        <div className="shrink-0 flex justify-end gap-3 px-5 sm:px-6 py-4 border-t border-slate-100 dark:border-slate-800">
          <button onClick={onClose} disabled={busy} className="px-5 py-3 text-slate-600 dark:text-slate-400 font-bold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition disabled:opacity-50">İptal</button>
          <button onClick={submit} disabled={busy || qtyNum <= 0} className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition flex items-center gap-2 disabled:opacity-50">
            <Check size={18}/> {busy ? 'Kaydediliyor...' : 'Satışı Onayla'}
          </button>
        </div>
      </div>
    </div>
  );
};

// --- ANA YÖNETİM & NAVİGASYON (DASHBOARD LAYOUT) ---
const DashboardLayout = ({ children, activeMenu, setView, currentUser }) => {
  const { t, categories, showToast } = useAppContext();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [openGroups, setOpenGroups] = useState<Set<string>>(() => new Set<string>());
  const [globalScanOpen, setGlobalScanOpen] = useState(false);
  const [scannedProduct, setScannedProduct] = useState<any>(null);
  const [scanLoading, setScanLoading] = useState(false);

  const handleGlobalScan = async (barcode: string) => {
    setGlobalScanOpen(false);
    setScanLoading(true);
    try {
      const res = await api.get(`/products/barcode/${encodeURIComponent(barcode)}`);
      setScannedProduct(res.data);
    } catch (e: any) {
      const status = e?.response?.status;
      if (status === 404) showToast(`"${barcode}" barkodlu ürün bulunamadı.`, 'error');
      else if (status === 403) showToast('Bu ürünü görüntüleme yetkiniz yok.', 'error');
      else showToast('Tarama hatası. Tekrar deneyin.', 'error');
    } finally {
      setScanLoading(false);
    }
  };
  const toggleGroup = (label: string) => setOpenGroups(prev => {
    const next = new Set(prev);
    if (next.has(label)) next.delete(label); else next.add(label);
    return next;
  });
  const isPatron = currentUser?.role === 'bayi_sahibi';

  // Dinamik stok ve finans menüleri — Web Görünüm ayarlarından gelir.
  // Sadece "is_visible" kategoriler menüde gösterilir; sıralama display_order'a göre.
  const visibleCategories = (categories || []).filter((c: any) => c.is_visible);
  const stockItems = visibleCategories
    .filter((c: any) => c.kind === 'stok')
    .sort((a: any, b: any) => (a.display_order - b.display_order) || String(a.name).localeCompare(String(b.name), 'tr-TR'))
    .map((c: any) => ({ type: 'link', id: c.key, label: c.name, icon: iconFor(c.icon) }));

  const dynamicFinance = visibleCategories
    .filter((c: any) => c.kind === 'finans')
    .map((c: any) => ({ type: 'link', id: c.key, label: c.name, icon: iconFor(c.icon), display_order: c.display_order }));

  // Sabit (kategori-dışı) finans bölümleri: işlem geçmişi & raporlar & garanti belgeleri.
  const financeItems = [
    ...dynamicFinance,
    { type: 'link', id: 'btb', label: 'BTB Yönetim', icon: Briefcase, display_order: 8700, perm: 'btb.view' },
    { type: 'link', id: 'supplier_orders', label: 'Toptancı Sipariş', icon: ShoppingCart, display_order: 8725 },
    { type: 'link', id: 'plasiyer', label: 'Plasiyer / Saha', icon: MapPin, display_order: 8800, perm: 'plasiyer.view' },
    { type: 'link', id: 'integrations', label: 'Entegrasyonlar', icon: Zap, display_order: 8850, perm: 'integrations.view' },
    { type: 'link', id: 'warranty', label: 'Garanti Belgeleri', icon: Shield, display_order: 8900 },
    { type: 'link', id: 'kdv_hesap', label: 'KDV Hesaplayıcı', icon: Calculator, display_order: 8800 },
    { type: 'link', id: 'fin_gecmis', label: 'İşlem Geçmişi', icon: History, display_order: 9000 },
    { type: 'link', id: 'fin_raporlar', label: 'Gelişmiş Raporlar', icon: PieChart, display_order: 9100 },
  ].sort((a: any, b: any) => ((a.display_order || 0) - (b.display_order || 0)) || String(a.label).localeCompare(String(b.label), 'tr-TR'));

  // Çalışan için granüler izin filtresi (patron her şeyi görür)
  const canSee = (perm: string) => hasPerm(currentUser, perm);

  // Stok kategorileri products.view iznine bağlı
  const stockMenuItems = canSee('products.view') ? stockItems : [];

  // Finans kategorileri her bir alt tipin .view iznine bağlı; cfg.transactionType'tan key türetilir
  const dynCategories = (categories || []) as any[];
  const financeMenuItems = financeItems.filter((it: any) => {
    if (it.id === 'fin_gecmis') {
      // İşlem geçmişi: en az bir finans tipi izni varsa görünür
      return FINANCE_TYPE_KEYS.some(t => canSee(`finance.${t}.view`));
    }
    if (it.id === 'fin_raporlar') return canSee('reports.view');
    if (it.id === 'warranty') {
      // Garanti belgeleri: patron veya en az bir finans .view izni olan çalışan
      return isPatron || FINANCE_TYPE_KEYS.some(t => canSee(`finance.${t}.view`));
    }
    if (it.id === 'kdv_hesap') {
      // KDV Hesaplayıcı: patron veya en az bir finans izni olan çalışan
      return isPatron || FINANCE_TYPE_KEYS.some(t => canSee(`finance.${t}.view`));
    }
    if (it.perm) return canSee(it.perm);
    // Dinamik finans kategorisi → kendi transactionType -> key
    const cat = dynCategories.find(c => c.key === it.id);
    const key = financeKeyOf(cat?.transaction_type ?? cat?.transactionType);
    return canSee(`finance.${key}.view`);
  });

  let menuItems: any[] = [];
  if (canSee('dashboard')) {
    menuItems.push({ type: 'link', id: 'customerDashboard', label: 'Ana Panel', icon: LayoutDashboard });
  }
  if (stockMenuItems.length > 0) {
    menuItems.push({ type: 'header', label: 'STOK YÖNETİMİ (A-Z)' }, ...stockMenuItems);
  }
  if (financeMenuItems.length > 0) {
    menuItems.push({ type: 'header', label: 'FİNANS & YÖNETİM (A-Z)' }, ...financeMenuItems);
  }

  // Sistem ayarları header'ı
  const systemItems: any[] = [];
  if (isPatron) {
    systemItems.push(
      { type: 'link', id: 'employees', label: 'Personel Yönetimi', icon: Users },
      { type: 'link', id: 'profile', label: 'Hesabım', icon: UserCircle },
      { type: 'link', id: 'web_settings', label: 'Web Görünüm', icon: Palette },
      { type: 'link', id: 'backup', label: 'Yedekleme', icon: Database },
      { type: 'link', id: 'vehicles', label: 'Araç Yönetimi', icon: Truck },
      { type: 'link', id: 'devices', label: 'Cihazlar', icon: Cpu },
      { type: 'link', id: 'subscription', label: 'Abonelik & Davet Et', icon: Gift }
    );
  } else if (canSee('profile.view')) {
    systemItems.push({ type: 'link', id: 'profile', label: 'Hesabım', icon: UserCircle });
    systemItems.push({ type: 'link', id: 'vehicles', label: 'Araçlarım', icon: Truck });
  }
  if (systemItems.length > 0) {
    menuItems.push({ type: 'header', label: 'SİSTEM AYARLARI' }, ...systemItems);
  }

  // Destek & Talepler — tüm kullanıcılar
  menuItems.push(
    { type: 'header', label: 'DESTEK' },
    { type: 'link', id: 'support', label: 'Destek & Talepler', icon: MessageCircle }
  );
  // Çalışanın hiç izni yoksa, en azından bilgilendirici bir kilitli buton göster
  if (!isPatron && menuItems.length === 0) {
    menuItems.push({ type: 'link', id: 'profile_locked', label: 'Yetki Verilmedi', icon: Lock });
  }

  // Sidebar collapsible groups
  const sidebarGroups: { label: string; items: any[] }[] = [];
  if (stockMenuItems.length > 0) sidebarGroups.push({ label: 'STOK YÖNETİMİ', items: stockMenuItems });
  if (financeMenuItems.length > 0) sidebarGroups.push({ label: 'FİNANS & YÖNETİM', items: financeMenuItems });
  if (systemItems.length > 0) sidebarGroups.push({ label: 'SİSTEM AYARLARI', items: systemItems });
  sidebarGroups.push({ label: 'DESTEK', items: [{ type: 'link', id: 'support', label: 'Destek & Talepler', icon: MessageCircle }] });

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex transition-colors duration-300">
      {sidebarOpen && <div className="fixed inset-0 bg-slate-900/60 dark:bg-black/60 backdrop-blur-sm z-40 md:hidden" onClick={() => setSidebarOpen(false)} />}
      
      <aside className={`fixed inset-y-0 left-0 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 w-72 transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 transition-transform duration-300 ease-out z-50 flex flex-col shadow-2xl border-r border-slate-200 dark:border-slate-800`}>
        <div className="p-6 flex items-center gap-3 border-b border-slate-200 dark:border-slate-800 shrink-0 bg-white dark:bg-slate-900 z-10 shadow-sm">
          <div className="w-10 h-10 rounded-xl overflow-hidden shadow-lg shadow-indigo-500/30 dark:shadow-indigo-900/50 shrink-0"><img src="/logo.png" alt="StokFinans" className="w-full h-full object-contain" /></div>
          <div>
            <span className="text-xl font-black tracking-tight leading-none block text-slate-900 dark:text-white">StokFinans</span>
            <span className="text-[10px] text-indigo-600 dark:text-indigo-300 font-bold tracking-widest uppercase">{isPatron ? t('Bayi (Patron)') : t('Çalışan')}</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar pb-6 pt-2">
          {canSee('dashboard') && (
            <button
              onClick={() => { setView('customerDashboard'); setSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3 mx-3 rounded-xl transition-all font-medium ${activeMenu === 'customerDashboard' ? 'bg-indigo-600 text-white shadow-md shadow-indigo-900/20' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200'}`}
              style={{ width: 'calc(100% - 24px)' }}
            >
              <LayoutDashboard size={18} className={activeMenu === 'customerDashboard' ? 'text-white' : 'text-slate-400 dark:text-slate-500'} />
              <span className="text-sm">{t('Ana Panel')}</span>
            </button>
          )}

          {sidebarGroups.map(group => {
            const isOpen = openGroups.has(group.label) || group.items.some((i: any) => i.id === activeMenu);
            const hasActive = group.items.some((i: any) => i.id === activeMenu);
            return (
              <div key={group.label}>
                <button
                  onClick={() => toggleGroup(group.label)}
                  className={`w-full flex items-center justify-between px-5 pt-5 pb-2 text-[10px] font-bold tracking-wider uppercase cursor-pointer transition-colors ${hasActive ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300'}`}
                >
                  <span>{t(group.label)}</span>
                  <ChevronDown size={12} className={`transition-transform duration-200 ${isOpen ? '' : '-rotate-90'}`} />
                </button>
                {isOpen && group.items.map((item: any) => (
                  <button
                    key={item.id}
                    onClick={() => { setView(item.id); setSidebarOpen(false); }}
                    className={`w-full flex items-center gap-3 px-4 py-3 mx-3 rounded-xl transition-all font-medium ${activeMenu === item.id ? 'bg-indigo-600 text-white shadow-md shadow-indigo-900/20' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200'}`}
                    style={{ width: 'calc(100% - 24px)' }}
                  >
                    <item.icon size={18} className={activeMenu === item.id ? 'text-white' : 'text-slate-400 dark:text-slate-500'} />
                    <span className="text-sm">{t(item.label)}</span>
                  </button>
                ))}
              </div>
            );
          })}
        </div>

        <div className="p-5 border-t border-slate-200 dark:border-slate-800 shrink-0 bg-white dark:bg-slate-900">
          <div className="mb-4 px-2 flex items-center gap-3">
             <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400"><UserCircle size={24}/></div>
             <div className="overflow-hidden">
               <p className="text-slate-900 dark:text-white font-bold text-sm truncate">{currentUser?.name}</p>
             </div>
          </div>
          <button onClick={() => setView('landing')} className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-100/50 dark:bg-slate-800/50 text-red-500 dark:text-red-400 border border-slate-200 dark:border-slate-800 hover:bg-red-500 hover:text-white hover:border-red-500 transition-all font-bold text-sm">
            <LogOut size={16} /> {t('Çıkış Yap')}
          </button>
        </div>
      </aside>

      <div className="flex-1 md:ml-72 flex flex-col min-h-screen max-w-full w-full">
        <header className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 h-16 flex items-center justify-between px-4 sm:px-6 sticky top-0 z-30 shadow-sm transition-colors duration-300">
          <div className="flex items-center gap-4">
             <button onClick={() => setSidebarOpen(true)} className="md:hidden text-slate-600 dark:text-slate-300 p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition"><Menu size={24} /></button>
             <h2 className="text-lg sm:text-xl font-black text-slate-800 dark:text-white truncate">{t(menuItems.find(m => m.id === activeMenu)?.label || 'Ana Panel')}</h2>
          </div>
          <div className="flex items-center gap-2">
            {canSee('products.view') && (
              <button
                onClick={() => setGlobalScanOpen(true)}
                disabled={scanLoading}
                title="Barkod / QR Tara"
                className="flex items-center justify-center w-10 h-9 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 transition shadow-sm disabled:opacity-50"
              >
                {scanLoading ? <RefreshCw size={18} className="animate-spin" /> : <ScanLine size={18} />}
              </button>
            )}
            <span className="hidden sm:inline-block px-3 py-1 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 text-xs font-bold rounded-lg border border-indigo-100 dark:border-indigo-800/50">{t('Sistem Aktif')}</span>
            <SettingsToggle />
          </div>
        </header>
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-x-hidden text-slate-800 dark:text-slate-200">
          {children}
        </main>
      </div>

      {/* Global QR/Barkod Tarayıcı */}
      {globalScanOpen && (
        <QRScannerModal
          title="Ürün Tara (QR / Barkod)"
          onDetected={handleGlobalScan}
          onClose={() => setGlobalScanOpen(false)}
        />
      )}

      {/* Tarama Sonucu Modalı */}
      {scannedProduct && (
        <ProductQuickViewModal
          product={scannedProduct}
          canViewCost={canSee('products.view_cost')}
          canEdit={canSee('products.edit')}
          onClose={() => setScannedProduct(null)}
          onEdit={() => {
            const prod = scannedProduct;
            setScannedProduct(null);
            // Ürünün kategorisine ait modül sayfasına git ve düzenleme formunu aç
            const cat = (categories || []).find((c: any) =>
              c.kind === 'stok' && (c.name === prod.category || c.key === prod.category)
            );
            try { sessionStorage.setItem('pendingProductEdit', String(prod.id)); } catch {}
            if (cat) {
              setView(cat.key);
            } else {
              const firstStock = (categories || []).find((c: any) => c.kind === 'stok');
              if (firstStock) setView(firstStock.key);
            }
          }}
        />
      )}
    </div>
  );
};

// --- Dashboard Layout Sistemi (Bayi Sahibi) ---
const DASH_LAYOUT_KEY = (uid: number) => `sf_dl_${uid}`;

type WidgetType = 'stat' | 'line' | 'bar' | 'donut' | 'activity' | 'sparkline' | 'gauge' | 'top' | 'calendar' | 'quickactions' | 'messages';
type DataSourceId =
  // Satış & gelir (stat + grafik)
  | 'sales' | 'revenue'
  // Grafik trendleri
  | 'tx_trend' | 'customer_trend'
  // Sayım istatistikleri (stat)
  | 'products' | 'critical' | 'customers' | 'categories' | 'tx_count'
  // Satış detay (finans kırılım)
  | 'sales_count' | 'debt_count' | 'payment_count'
  // Finans tutarları (finans kırılım)
  | 'outstanding_debt' | 'debt_total' | 'payment_total'
  | 'expense_total' | 'senet_total' | 'kredi_total' | 'warranty_val'
  // Grafik / pasta
  | 'fin_break' | 'fin_break_ext'
  // Aktivite akışı
  | 'activities'
  // Performans metrikleri (gauge)
  | 'profit_margin' | 'critical_pct' | 'inventory_turnover'
  // Performans istatistikleri (stat)
  | 'daily_avg' | 'weekly_avg'
  // Sıralı listeler (top widget)
  | 'top_by_value' | 'top_low_stock' | 'top_profit' | 'top_finance'
  // Takvim ısı haritası
  | 'cal_sales' | 'cal_tx'
  // Sparkline (grafik + stat)
  | 'sparkline_sales' | 'sparkline_revenue' | 'sparkline_tx'
  // Statik widget kaynakları
  | 'quick_actions' | 'pending_tasks';

type ColSpan = 1 | 2 | 3 | 4;
type HeroColor = 'indigo' | 'purple' | 'emerald' | 'rose' | 'amber' | 'slate';

interface DashWidget { id: string; type: WidgetType; sources: DataSourceId[]; span: ColSpan; title: string; }
interface DashLayout  { heroColor: HeroColor; widgets: DashWidget[]; }

const SERIES_PALETTE = ['#818cf8','#34d399','#fb7185','#fbbf24','#60a5fa','#c084fc','#fb923c','#22d3ee'];

const DEFAULT_DASH_LAYOUT: DashLayout = {
  heroColor: 'indigo',
  widgets: [
    { id: 'w1',  type: 'sparkline', sources: ['sparkline_sales'],    span: 1, title: 'Satış Trendi' },
    { id: 'w2',  type: 'sparkline', sources: ['sparkline_revenue'],  span: 1, title: 'Gelir Trendi' },
    { id: 'w3',  type: 'gauge',     sources: ['profit_margin'],      span: 1, title: 'Kar Marjı' },
    { id: 'w4',  type: 'stat',      sources: ['products', 'critical', 'categories'], span: 1, title: 'Stok Özeti' },
    { id: 'w5',  type: 'line',      sources: ['sales', 'revenue'],   span: 3, title: 'Satış & Gelir' },
    { id: 'w6',  type: 'donut',     sources: ['fin_break'],          span: 1, title: 'Finans Dağılımı' },
    { id: 'w7',  type: 'top',       sources: ['top_by_value'],       span: 2, title: 'En Değerli Ürünler' },
    { id: 'w8',  type: 'top',       sources: ['top_profit'],         span: 2, title: 'En Kârlı Ürünler' },
    { id: 'w9',  type: 'calendar',  sources: ['cal_sales'],          span: 4, title: 'Satış Takvimi' },
    { id: 'w10', type: 'activity',  sources: ['activities'],         span: 2, title: 'Son Aktiviteler' },
  ],
};

const HERO_COLORS: HeroColor[] = ['indigo', 'purple', 'emerald', 'rose', 'amber', 'slate'];
const HERO_CONFIGS: Record<HeroColor, { gradient: string; glow: string; chartColor: string; label: string; dot: string }> = {
  indigo:  { gradient: 'from-indigo-600 via-indigo-700 to-indigo-900',    glow: 'shadow-indigo-300/40',  chartColor: '#818cf8', label: 'İndigo',    dot: 'bg-indigo-500' },
  purple:  { gradient: 'from-purple-600 via-purple-700 to-purple-900',    glow: 'shadow-purple-300/40',  chartColor: '#c084fc', label: 'Mor',        dot: 'bg-purple-500' },
  emerald: { gradient: 'from-emerald-600 via-emerald-700 to-emerald-900', glow: 'shadow-emerald-300/40', chartColor: '#34d399', label: 'Yeşil',      dot: 'bg-emerald-500' },
  rose:    { gradient: 'from-rose-600 via-rose-700 to-rose-900',          glow: 'shadow-rose-300/40',    chartColor: '#fb7185', label: 'Kırmızı',    dot: 'bg-rose-500' },
  amber:   { gradient: 'from-amber-500 via-amber-600 to-amber-800',       glow: 'shadow-amber-300/40',   chartColor: '#fbbf24', label: 'Amber',      dot: 'bg-amber-500' },
  slate:   { gradient: 'from-slate-700 via-slate-800 to-slate-950',       glow: 'shadow-slate-400/30',   chartColor: '#94a3b8', label: 'Koyu Gri',   dot: 'bg-slate-600' },
};

const STAT_SOURCES: DataSourceId[] = [
  'sales', 'revenue', 'outstanding_debt',
  'products', 'critical', 'customers', 'categories', 'tx_count',
  'sales_count', 'debt_count', 'payment_count',
  'debt_total', 'payment_total', 'expense_total',
  'senet_total', 'kredi_total', 'warranty_val',
  'daily_avg', 'weekly_avg',
];
const CHART_SOURCES: DataSourceId[] = ['sales', 'revenue', 'tx_trend', 'customer_trend'];
const DONUT_SOURCES: DataSourceId[] = ['fin_break', 'fin_break_ext'];
const GAUGE_SOURCES: DataSourceId[] = ['profit_margin', 'critical_pct', 'inventory_turnover'];
const TOP_SOURCES: DataSourceId[] = ['top_by_value', 'top_low_stock', 'top_profit', 'top_finance'];
const SPARKLINE_SOURCES: DataSourceId[] = ['sparkline_sales', 'sparkline_revenue', 'sparkline_tx'];
const CALENDAR_SOURCES: DataSourceId[] = ['cal_sales', 'cal_tx'];

const WIDGET_DEFS: Record<WidgetType, { label: string; icon: any; validSources: DataSourceId[]; maxSources: number }> = {
  stat:      { label: 'Sayı Kartı',      icon: Hash,         validSources: STAT_SOURCES,      maxSources: 4 },
  line:      { label: 'Çizgi Grafik',    icon: TrendingUp,   validSources: CHART_SOURCES,     maxSources: 4 },
  bar:       { label: 'Bar Grafik',      icon: BarChart,     validSources: CHART_SOURCES,     maxSources: 3 },
  donut:     { label: 'Pasta Grafik',    icon: PieChart,     validSources: DONUT_SOURCES,     maxSources: 1 },
  activity:  { label: 'Aktivite Akışı',  icon: Activity,     validSources: ['activities'],    maxSources: 1 },
  sparkline: { label: 'Sparkline Kart',  icon: BarChart2,    validSources: SPARKLINE_SOURCES, maxSources: 1 },
  gauge:     { label: 'Gösterge',        icon: Gauge,        validSources: GAUGE_SOURCES,     maxSources: 1 },
  top:       { label: 'Sıralama Listesi',icon: Trophy,       validSources: TOP_SOURCES,       maxSources: 1 },
  calendar:     { label: 'Takvim Haritası',  icon: CalendarDays,   validSources: CALENDAR_SOURCES,    maxSources: 1 },
  quickactions: { label: 'Hızlı İşlemler',  icon: Zap,            validSources: ['quick_actions'],   maxSources: 1 },
  messages:     { label: 'Bekleyen Görevler',icon: MessageCircle,  validSources: ['pending_tasks'],   maxSources: 1 },
};

const SOURCE_DEFS: Record<DataSourceId, { label: string; icon: any; isMoney: boolean; group: string }> = {
  // Satış & Gelir
  sales:            { label: 'Satış Tutarı',          icon: TrendingUp,    isMoney: true,  group: 'Satış' },
  revenue:          { label: 'Tahmini Gelir',          icon: DollarSign,    isMoney: true,  group: 'Satış' },
  sales_count:      { label: 'Satış Adedi',            icon: Hash,          isMoney: false, group: 'Satış' },
  tx_count:         { label: 'İşlem Sayısı',           icon: Hash,          isMoney: false, group: 'Satış' },
  daily_avg:        { label: 'Günlük Ort. Satış',      icon: TrendingUp,    isMoney: true,  group: 'Satış' },
  weekly_avg:       { label: 'Haftalık Ort. Satış',    icon: TrendingUp,    isMoney: true,  group: 'Satış' },
  // Borç & Ödeme
  outstanding_debt: { label: 'Açık Borç Bakiyesi',    icon: AlertTriangle, isMoney: true,  group: 'Finans' },
  debt_total:       { label: 'Toplam Borç',            icon: AlertTriangle, isMoney: true,  group: 'Finans' },
  payment_total:    { label: 'Toplam Ödeme',           icon: DollarSign,    isMoney: true,  group: 'Finans' },
  expense_total:    { label: 'Toplam Gider',           icon: Wallet,        isMoney: true,  group: 'Finans' },
  senet_total:      { label: 'Senet Tutarı',           icon: FileText,      isMoney: true,  group: 'Finans' },
  kredi_total:      { label: 'Kredi Tutarı',           icon: Landmark,      isMoney: true,  group: 'Finans' },
  warranty_val:     { label: 'Garanti Tutarı',         icon: Award,         isMoney: true,  group: 'Finans' },
  debt_count:       { label: 'Borç Adedi',             icon: Hash,          isMoney: false, group: 'Finans' },
  payment_count:    { label: 'Ödeme Adedi',            icon: Hash,          isMoney: false, group: 'Finans' },
  // Stok & Müşteri
  products:         { label: 'Ürün Sayısı',            icon: Package,       isMoney: false, group: 'Stok' },
  critical:         { label: 'Kritik Stok',            icon: AlertTriangle, isMoney: false, group: 'Stok' },
  categories:       { label: 'Kategori Sayısı',        icon: Tag,           isMoney: false, group: 'Stok' },
  customers:        { label: 'Müşteri Sayısı',         icon: Users,         isMoney: false, group: 'Müşteri' },
  // Grafik trendleri
  tx_trend:         { label: 'İşlem Trendi',           icon: BarChart,      isMoney: false, group: 'Grafik' },
  customer_trend:   { label: 'Müşteri Trendi',         icon: Users,         isMoney: false, group: 'Grafik' },
  // Pasta & Aktivite
  fin_break:        { label: 'Finans Dağılımı (4)',    icon: PieChart,      isMoney: true,  group: 'Pasta' },
  fin_break_ext:    { label: 'Finans Dağılımı (7)',    icon: PieChart,      isMoney: true,  group: 'Pasta' },
  activities:       { label: 'Son Aktiviteler',        icon: Activity,      isMoney: false, group: 'Sistem' },
  // Performans / Gauge
  profit_margin:    { label: 'Kar Marjı (%)',          icon: Percent,       isMoney: false, group: 'Performans' },
  critical_pct:     { label: 'Kritik Stok Oranı (%)', icon: AlertTriangle, isMoney: false, group: 'Performans' },
  inventory_turnover:{ label: 'Stok Devir Hızı',      icon: RefreshCw,     isMoney: false, group: 'Performans' },
  // Sıralama listeleri (top)
  top_by_value:     { label: 'En Değerli Ürünler',    icon: Trophy,        isMoney: false, group: 'Sıralama' },
  top_low_stock:    { label: 'Kritik Stok Listesi',   icon: AlertTriangle, isMoney: false, group: 'Sıralama' },
  top_profit:       { label: 'En Kârlı Ürünler',      icon: Flame,         isMoney: false, group: 'Sıralama' },
  top_finance:      { label: 'Finans Kategorileri',   icon: PieChart,      isMoney: false, group: 'Sıralama' },
  // Sparkline kartlar
  sparkline_sales:  { label: 'Satış Sparkline',       icon: BarChart2,     isMoney: true,  group: 'Sparkline' },
  sparkline_revenue:{ label: 'Gelir Sparkline',       icon: BarChart2,     isMoney: true,  group: 'Sparkline' },
  sparkline_tx:     { label: 'İşlem Sparkline',       icon: BarChart2,     isMoney: false, group: 'Sparkline' },
  // Takvim
  cal_sales:        { label: 'Satış Takvimi',         icon: CalendarDays,  isMoney: true,  group: 'Takvim' },
  cal_tx:           { label: 'İşlem Takvimi',         icon: CalendarDays,  isMoney: false, group: 'Takvim' },
  // Statik
  quick_actions:    { label: 'Hızlı İşlemler',        icon: Zap,           isMoney: false, group: 'Statik' },
  pending_tasks:    { label: 'Bekleyen Görevler',      icon: MessageCircle, isMoney: false, group: 'Statik' },
};

const SPAN_CLASSES: Record<ColSpan, string> = {
  1: 'col-span-1',
  2: 'col-span-1 sm:col-span-2',
  3: 'col-span-1 sm:col-span-2 lg:col-span-3',
  4: 'col-span-1 sm:col-span-2 lg:col-span-4',
};
const CHART_H: Record<ColSpan, number> = { 1: 160, 2: 200, 3: 220, 4: 240 };

const migrateWidget = (w: any): DashWidget => {
  const type: WidgetType = w.type in WIDGET_DEFS ? w.type : 'stat';
  const validSrcs = WIDGET_DEFS[type].validSources;
  const rawSources: DataSourceId[] = Array.isArray(w.sources)
    ? (w.sources as string[]).filter(s => s in SOURCE_DEFS) as DataSourceId[]
    : w.source && w.source in SOURCE_DEFS
      ? [w.source as DataSourceId]
      : [];
  const sources = rawSources.filter(s => validSrcs.includes(s));
  return { id: w.id, type, sources: sources.length ? sources : [validSrcs[0]], span: w.span || 1, title: w.title || '' };
};

const useDashboardLayout = (userId: number | null) => {
  const DEF = (): DashLayout => JSON.parse(JSON.stringify(DEFAULT_DASH_LAYOUT));

  const readLocal = (): DashLayout => {
    if (!userId) return DEF();
    try {
      const raw = localStorage.getItem(DASH_LAYOUT_KEY(userId));
      if (!raw) return DEF();
      const parsed = JSON.parse(raw);
      return {
        heroColor: parsed.heroColor || 'indigo',
        widgets: Array.isArray(parsed.widgets) ? parsed.widgets.map(migrateWidget) : DEF().widgets,
      };
    } catch { return DEF(); }
  };

  const [layout, setLayoutState] = useState<DashLayout>(readLocal);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Startup: pull from backend, prefer over localStorage if exists
  useEffect(() => {
    if (!userId) return;
    api.get('/auth/dashboard-layout', { _silent: true } as any).then(res => {
      const remote = res.data?.dashboard_layout;
      if (remote && remote.widgets && Array.isArray(remote.widgets)) {
        const hydrated: DashLayout = {
          heroColor: remote.heroColor || 'indigo',
          widgets: remote.widgets.map(migrateWidget),
        };
        setLayoutState(hydrated);
        try { localStorage.setItem(DASH_LAYOUT_KEY(userId), JSON.stringify(hydrated)); } catch {}
      }
    }).catch(() => {});
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  const setLayout = (next: DashLayout) => {
    setLayoutState(next);
    if (userId) {
      try { localStorage.setItem(DASH_LAYOUT_KEY(userId), JSON.stringify(next)); } catch {}
      // Debounced backend save — 1.5s after last change
      if (saveTimer.current) clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(() => {
        api.put('/auth/dashboard-layout', { dashboard_layout: next }, { _silent: true } as any).catch(() => {});
      }, 1500);
    }
  };

  return { layout, setLayout };
};

const AnimatedCounter = ({ value, prefix = '', suffix = '', duration = 1200 }: { value: number; prefix?: string; suffix?: string; duration?: number }) => {
  const [display, setDisplay] = useState(0);
  const startRef = useRef<number | null>(null);
  const rafRef = useRef<number>(0);
  useEffect(() => {
    startRef.current = null;
    cancelAnimationFrame(rafRef.current);
    const animate = (ts: number) => {
      if (!startRef.current) startRef.current = ts;
      const p = Math.min((ts - startRef.current) / duration, 1);
      setDisplay(Math.round((1 - Math.pow(1 - p, 3)) * value));
      if (p < 1) rafRef.current = requestAnimationFrame(animate);
    };
    rafRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(rafRef.current);
  }, [value, duration]);
  return <span>{prefix}{display.toLocaleString('tr-TR')}{suffix}</span>;
};

const SVGLineChart = ({ data, color, height = 120 }: { data: { label: string; value: number }[]; color: string; height?: number }) => {
  const [mounted, setMounted] = useState(false);
  const [hovIdx, setHovIdx] = useState<number | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => { const t = setTimeout(() => setMounted(true), 80); return () => clearTimeout(t); }, []);

  if (!data || data.length < 2) return <div style={{ height }} className="w-full" />;

  const vals = data.map(d => d.value);
  const min = Math.min(...vals), max = Math.max(...vals);
  const range = max - min || 1;
  const W = 400, H = height;
  const PL = 40, PR = 12, PT = 16, PB = 28;
  const cW = W - PL - PR, cH = H - PT - PB;

  const pts: [number, number][] = data.map((d, i) => [
    PL + (i / (data.length - 1)) * cW,
    PT + (1 - (d.value - min) / range) * cH,
  ]);

  let linePath = `M ${pts[0][0]},${pts[0][1]}`;
  for (let i = 1; i < pts.length; i++) {
    const [px, py] = pts[i - 1], [cx2, cy2] = pts[i], mid = (px + cx2) / 2;
    linePath += ` C ${mid},${py} ${mid},${cy2} ${cx2},${cy2}`;
  }
  const baseY = PT + cH;
  const areaPath = `${linePath} L ${pts[pts.length - 1][0]},${baseY} L ${pts[0][0]},${baseY} Z`;
  const gId = `glc_${color.replace('#', '')}`;

  const fmtY = (v: number) => v >= 1000 ? `₺${(v / 1000).toFixed(0)}K` : v > 0 ? `₺${v.toFixed(0)}` : '₺0';
  const gridLevels = [1, 0.5, 0];

  const step = Math.max(1, Math.floor(data.length / 4));
  const labelIdx = data.map((_, i) => i).filter(i => i % step === 0 || i === data.length - 1);

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const xScaled = ((e.clientX - rect.left) / rect.width) * W;
    let nearest = 0, minDist = Infinity;
    pts.forEach(([x], i) => { const d = Math.abs(x - xScaled); if (d < minDist) { minDist = d; nearest = i; } });
    setHovIdx(nearest);
  };

  const hi = hovIdx;

  return (
    <div className="relative select-none" onMouseLeave={() => setHovIdx(null)}>
      {/* overflow-hidden sadece SVG'yi sarar; tooltip dışarıda kalır */}
      <div className="overflow-hidden w-full">
        <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="w-full" style={{ height, display: 'block' }} onMouseMove={handleMouseMove}>
          <defs>
            <linearGradient id={gId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%"   stopColor={color} stopOpacity={0.55} />
              <stop offset="55%"  stopColor={color} stopOpacity={0.18} />
              <stop offset="100%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>

          {/* Grid yatay çizgiler + Y ekseni etiketleri */}
          {gridLevels.map((f, i) => {
            const y = PT + (1 - f) * cH;
            return (
              <g key={i}>
                <line x1={PL} y1={y} x2={W - PR} y2={y}
                  stroke="rgba(148,163,184,0.2)" strokeWidth="1"
                  strokeDasharray={f === 1 || f === 0 ? '' : '3 4'} />
                <text x={PL - 5} y={y + 3.5} textAnchor="end" fontSize="8" fill="#94a3b8" fontWeight="600">
                  {fmtY(min + f * range)}
                </text>
              </g>
            );
          })}

          {/* X ekseni etiketleri */}
          {labelIdx.map(i => (
            <text key={i} x={pts[i][0]} y={H - 6}
              textAnchor={i === 0 ? 'start' : i === data.length - 1 ? 'end' : 'middle'}
              fontSize="8" fill="#94a3b8" fontWeight="600">
              {data[i].label}
            </text>
          ))}

          {/* Dikey cursor çizgisi */}
          {hi !== null && (
            <line x1={pts[hi][0]} y1={PT} x2={pts[hi][0]} y2={baseY}
              stroke="rgba(148,163,184,0.4)" strokeWidth="1" strokeDasharray="3 3" />
          )}

          {/* Alan dolgusu */}
          <path d={areaPath} fill={`url(#${gId})`} style={{ opacity: mounted ? 1 : 0, transition: 'opacity 0.7s ease' }} />

          {/* Glow çizgisi — SVG opacity ile, CSS blur yok (taşmaz) */}
          <path d={linePath} fill="none" stroke={color} strokeWidth="10" strokeLinecap="round" opacity={0.12}
            style={{ strokeDasharray: 1500, strokeDashoffset: mounted ? 0 : 1500, transition: 'stroke-dashoffset 1.4s ease' }} />

          {/* Ana çizgi */}
          <path d={linePath} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round"
            style={{ strokeDasharray: 1500, strokeDashoffset: mounted ? 0 : 1500, transition: 'stroke-dashoffset 1.3s ease' }} />

          {/* Veri noktaları */}
          {pts.map(([x, y], i) => {
            const isLast = i === pts.length - 1;
            const isHov  = i === hi;
            const r = isHov ? 5.5 : isLast ? 4.5 : 2.5;
            return (
              <g key={i} style={{ opacity: mounted ? 1 : 0, transition: `opacity 0.3s ease ${(0.9 + i * 0.04).toFixed(2)}s` }}>
                {isLast && (
                  <>
                    <circle cx={x} cy={y} r={r + 4} fill={color} opacity={0.2}>
                      <animate attributeName="r" values={`${r + 3};${r + 10};${r + 3}`} dur="2.4s" repeatCount="indefinite" />
                      <animate attributeName="opacity" values="0.25;0;0.25" dur="2.4s" repeatCount="indefinite" />
                    </circle>
                    <circle cx={x} cy={y} r={r + 1} fill="none" stroke={color} strokeWidth="1.5" opacity={0.5} />
                  </>
                )}
                <circle cx={x} cy={y} r={r}
                  fill={isHov || isLast ? color : 'white'}
                  stroke={color}
                  strokeWidth={isHov ? 2 : 1.5} />
              </g>
            );
          })}
        </svg>
      </div>

      {/* Tooltip — overflow-hidden dışında, relative div içinde */}
      {hi !== null && mounted && (
        <div className="absolute pointer-events-none z-20"
          style={{
            left: `${((pts[hi][0] / W) * 100).toFixed(1)}%`,
            top:  `${((pts[hi][1] / H) * 100).toFixed(1)}%`,
            transform: 'translate(-50%, calc(-100% - 10px))',
          }}>
          <div className="bg-slate-900/90 backdrop-blur-sm border border-white/20 text-white rounded-xl px-3 py-2 shadow-2xl text-center whitespace-nowrap">
            <p className="text-[9px] font-bold text-white/50 uppercase tracking-wider mb-0.5">{data[hi].label}</p>
            <p className="text-sm font-black">{formatMoney(data[hi].value)}</p>
          </div>
          <div className="w-0 h-0 mx-auto border-l-[5px] border-l-transparent border-r-[5px] border-r-transparent border-t-[5px] border-t-slate-900/90" />
        </div>
      )}
    </div>
  );
};

const SVGBarChart = ({ data, color, height = 100 }: { data: { label: string; value: number }[]; color: string; height?: number }) => {
  const [mounted, setMounted] = useState(false);
  const [hovIdx, setHovIdx] = useState<number | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  useEffect(() => { const t = setTimeout(() => setMounted(true), 80); return () => clearTimeout(t); }, []);
  if (!data || data.length < 2) return <div style={{ height }} className="w-full" />;
  const vals = data.map(d => d.value);
  const max = Math.max(...vals, 1);
  const W = 400, H = height, PL = 40, PR = 12, PT = 10, PB = 28;
  const cW = W - PL - PR, cH = H - PT - PB;
  const gap = cW / data.length;
  const barW = Math.max(4, gap * 0.55);
  const fmtY = (v: number) => v >= 1000 ? `₺${(v / 1000).toFixed(0)}K` : v > 0 ? `₺${v.toFixed(0)}` : '₺0';
  const step = Math.max(1, Math.floor(data.length / 4));
  const labelIdx = data.map((_, i) => i).filter(i => i % step === 0 || i === data.length - 1);
  const hi = hovIdx;
  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const xScaled = ((e.clientX - rect.left) / rect.width) * W;
    let nearest = 0, minDist = Infinity;
    data.forEach((_, i) => { const d = Math.abs(PL + (i + 0.5) * gap - xScaled); if (d < minDist) { minDist = d; nearest = i; } });
    setHovIdx(nearest);
  };
  return (
    <div className="relative select-none" onMouseLeave={() => setHovIdx(null)}>
      <div className="overflow-hidden w-full">
        <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="w-full" style={{ height, display: 'block' }} onMouseMove={handleMouseMove}>
          {[0, 0.5, 1].map((f, i) => {
            const y = PT + (1 - f) * cH;
            return (
              <g key={i}>
                <line x1={PL} y1={y} x2={W - PR} y2={y} stroke="rgba(148,163,184,0.2)" strokeWidth="1" strokeDasharray={f === 0 || f === 1 ? '' : '3 4'} />
                <text x={PL - 5} y={y + 3.5} textAnchor="end" fontSize="8" fill="#94a3b8" fontWeight="600">{fmtY(f * max)}</text>
              </g>
            );
          })}
          {labelIdx.map(i => (
            <text key={i} x={PL + (i + 0.5) * gap} y={H - 6} textAnchor="middle" fontSize="8" fill="#94a3b8" fontWeight="600">{data[i].label}</text>
          ))}
          {hi !== null && <line x1={PL + (hi + 0.5) * gap} y1={PT} x2={PL + (hi + 0.5) * gap} y2={PT + cH} stroke="rgba(148,163,184,0.4)" strokeWidth="1" strokeDasharray="3 3" />}
          {data.map((d, i) => {
            const barH = mounted ? (d.value / max) * cH : 0;
            const barX = PL + (i + 0.5) * gap - barW / 2;
            const barY = PT + cH - barH;
            const isHov = i === hi;
            return (
              <g key={i}>
                <rect x={barX} y={barY} width={barW} height={barH} rx={3}
                  fill={color} opacity={isHov ? 1 : 0.85}
                  style={{ transition: `height 0.6s cubic-bezier(0.34,1.56,0.64,1) ${(i * 0.025).toFixed(2)}s, y 0.6s cubic-bezier(0.34,1.56,0.64,1) ${(i * 0.025).toFixed(2)}s, opacity 0.15s` }} />
                {isHov && <rect x={barX} y={barY} width={barW} height={barH} rx={3} fill="none" stroke="white" strokeWidth="1" />}
              </g>
            );
          })}
        </svg>
      </div>
      {hi !== null && mounted && (() => {
        const barH = (data[hi].value / max) * cH;
        const bx = PL + (hi + 0.5) * gap;
        const by = PT + cH - barH;
        return (
          <div className="absolute pointer-events-none z-20" style={{ left: `${(bx / W * 100).toFixed(1)}%`, top: `${(by / H * 100).toFixed(1)}%`, transform: 'translate(-50%, calc(-100% - 8px))' }}>
            <div className="bg-slate-900/90 backdrop-blur-sm border border-white/20 text-white rounded-xl px-3 py-2 shadow-2xl text-center whitespace-nowrap">
              <p className="text-[9px] font-bold text-white/50 uppercase tracking-wider mb-0.5">{data[hi].label}</p>
              <p className="text-sm font-black">{formatMoney(data[hi].value)}</p>
            </div>
            <div className="w-0 h-0 mx-auto border-l-[5px] border-l-transparent border-r-[5px] border-r-transparent border-t-[5px] border-t-slate-900/90" />
          </div>
        );
      })()}
    </div>
  );
};

type ChartSeries = { label: string; color: string; data: { label: string; value: number }[]; isMoney: boolean };

const SVGMultiLineChart = ({ series, height = 120 }: { series: ChartSeries[]; height?: number }) => {
  const [mounted, setMounted] = useState(false);
  const [hovIdx, setHovIdx] = useState<number | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  useEffect(() => { const t = setTimeout(() => setMounted(true), 80); return () => clearTimeout(t); }, []);
  if (!series.length || !series[0].data || series[0].data.length < 2) return <div style={{ height }} className="w-full" />;
  const refs = series[0].data;
  const n = refs.length;
  const W = 400, H = height;
  const PL = 12, PR = 12, PT = 12;
  const PB = series.length > 1 ? 36 : 26;
  const cW = W - PL - PR, cH = H - PT - PB;

  const seriesPts = series.map(s => {
    const vals = s.data.map(d => d.value);
    const mn = Math.min(...vals), mx = Math.max(...vals), rng = mx - mn || 1;
    return s.data.map((d, i) => [PL + (i / (n - 1)) * cW, PT + (1 - (d.value - mn) / rng) * cH] as [number, number]);
  });

  const buildPath = (pts: [number, number][]) => {
    let p = `M ${pts[0][0]},${pts[0][1]}`;
    for (let i = 1; i < pts.length; i++) {
      const [px, py] = pts[i - 1], [cx2, cy2] = pts[i], mid = (px + cx2) / 2;
      p += ` C ${mid},${py} ${mid},${cy2} ${cx2},${cy2}`;
    }
    return p;
  };

  const step = Math.max(1, Math.floor(n / 4));
  const labelIdx = refs.map((_, i) => i).filter(i => i % step === 0 || i === n - 1);
  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const xS = ((e.clientX - rect.left) / rect.width) * W;
    let near = 0, md = Infinity;
    seriesPts[0].forEach(([x], i) => { const d = Math.abs(x - xS); if (d < md) { md = d; near = i; } });
    setHovIdx(near);
  };
  const hi = hovIdx;
  const legendY = H - (PB - 7);

  return (
    <div className="relative select-none" onMouseLeave={() => setHovIdx(null)}>
      <div className="overflow-hidden w-full">
        <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="w-full" style={{ height, display: 'block' }} onMouseMove={handleMouseMove}>
          {[0, 0.5, 1].map((f, i) => (
            <line key={i} x1={PL} y1={PT + (1 - f) * cH} x2={W - PR} y2={PT + (1 - f) * cH}
              stroke="rgba(148,163,184,0.2)" strokeWidth="1" strokeDasharray={f === 0 || f === 1 ? '' : '3 4'} />
          ))}
          {labelIdx.map(i => (
            <text key={i} x={seriesPts[0][i][0]} y={PT + cH + 12}
              textAnchor={i === 0 ? 'start' : i === n - 1 ? 'end' : 'middle'}
              fontSize="8" fill="#94a3b8" fontWeight="600">{refs[i].label}</text>
          ))}
          {hi !== null && seriesPts[0][hi] && (
            <line x1={seriesPts[0][hi][0]} y1={PT} x2={seriesPts[0][hi][0]} y2={PT + cH}
              stroke="rgba(148,163,184,0.4)" strokeWidth="1" strokeDasharray="3 3" />
          )}
          {series.map((s, si) => {
            const pts = seriesPts[si];
            const path = buildPath(pts);
            return (
              <g key={si} style={{ opacity: mounted ? 1 : 0, transition: `opacity ${0.5 + si * 0.1}s ease` }}>
                <path d={path} fill="none" stroke={s.color} strokeWidth="8" opacity={0.08} strokeLinecap="round" />
                <path d={path} fill="none" stroke={s.color} strokeWidth="2" strokeLinecap="round"
                  style={{ strokeDasharray: 1500, strokeDashoffset: mounted ? 0 : 1500, transition: `stroke-dashoffset ${1.2 + si * 0.2}s ease` }} />
                {pts.map(([x, y], i) => {
                  const isLast = i === pts.length - 1, isHov = i === hi;
                  if (!isLast && !isHov) return null;
                  return <circle key={i} cx={x} cy={y} r={isHov ? 4.5 : 3} fill={s.color} stroke="white" strokeWidth="1.5"
                    style={{ opacity: mounted ? 1 : 0, transition: 'opacity 0.3s ease' }} />;
                })}
              </g>
            );
          })}
          {series.length > 1 && (() => {
            let lx = PL;
            return series.map((s, i) => {
              const el = (
                <g key={i}>
                  <circle cx={lx + 4} cy={legendY} r={3.5} fill={s.color} />
                  <text x={lx + 11} y={legendY + 3.5} fontSize="8" fill="#94a3b8" fontWeight="700">{s.label}</text>
                </g>
              );
              lx += s.label.length * 5.2 + 18;
              return el;
            });
          })()}
        </svg>
      </div>
      {hi !== null && mounted && seriesPts[0][hi] && (
        <div className="absolute pointer-events-none z-20"
          style={{ left: `${((seriesPts[0][hi][0] / W) * 100).toFixed(1)}%`, top: `${((seriesPts[0][hi][1] / H) * 100).toFixed(1)}%`, transform: 'translate(-50%, calc(-100% - 10px))' }}>
          <div className="bg-slate-900/90 backdrop-blur-sm border border-white/20 text-white rounded-xl px-3 py-2 shadow-2xl whitespace-nowrap">
            <p className="text-[9px] font-bold text-white/50 uppercase tracking-wider mb-1">{refs[hi].label}</p>
            {series.map((s, si) => (
              <div key={si} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full shrink-0" style={{ background: s.color }} />
                <span className="text-[10px] text-white/60">{s.label}:</span>
                <span className="text-[10px] font-black">{s.isMoney ? formatMoney(s.data[hi]?.value || 0) : (s.data[hi]?.value || 0).toLocaleString('tr-TR')}</span>
              </div>
            ))}
          </div>
          <div className="w-0 h-0 mx-auto border-l-[5px] border-l-transparent border-r-[5px] border-r-transparent border-t-[5px] border-t-slate-900/90" />
        </div>
      )}
    </div>
  );
};

const SVGMultiBarChart = ({ series, height = 100 }: { series: ChartSeries[]; height?: number }) => {
  const [mounted, setMounted] = useState(false);
  const [hovIdx, setHovIdx] = useState<number | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  useEffect(() => { const t = setTimeout(() => setMounted(true), 80); return () => clearTimeout(t); }, []);
  if (!series.length || !series[0].data || series[0].data.length < 2) return <div style={{ height }} className="w-full" />;
  const refs = series[0].data;
  const n = refs.length, m = series.length;
  const W = 400, H = height;
  const PL = 12, PR = 12, PT = 10;
  const PB = m > 1 ? 36 : 26;
  const cW = W - PL - PR, cH = H - PT - PB;
  const gap = cW / n, groupW = gap * 0.82, barW = groupW / m;
  const allVals = series.flatMap(s => s.data.map(d => d.value));
  const globalMax = Math.max(...allVals, 1);
  const step = Math.max(1, Math.floor(n / 4));
  const labelIdx = refs.map((_, i) => i).filter(i => i % step === 0 || i === n - 1);
  const hi = hovIdx;
  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const xS = ((e.clientX - rect.left) / rect.width) * W;
    let near = 0, md = Infinity;
    refs.forEach((_, i) => { const d = Math.abs(PL + (i + 0.5) * gap - xS); if (d < md) { md = d; near = i; } });
    setHovIdx(near);
  };
  const legendY = H - (PB - 7);
  return (
    <div className="relative select-none" onMouseLeave={() => setHovIdx(null)}>
      <div className="overflow-hidden w-full">
        <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="w-full" style={{ height, display: 'block' }} onMouseMove={handleMouseMove}>
          {[0, 0.5, 1].map((f, i) => (
            <line key={i} x1={PL} y1={PT + (1 - f) * cH} x2={W - PR} y2={PT + (1 - f) * cH}
              stroke="rgba(148,163,184,0.2)" strokeWidth="1" strokeDasharray={f === 0 || f === 1 ? '' : '3 4'} />
          ))}
          {labelIdx.map(i => (
            <text key={i} x={PL + (i + 0.5) * gap} y={PT + cH + 12} textAnchor="middle"
              fontSize="8" fill="#94a3b8" fontWeight="600">{refs[i].label}</text>
          ))}
          {hi !== null && <line x1={PL + (hi + 0.5) * gap} y1={PT} x2={PL + (hi + 0.5) * gap} y2={PT + cH} stroke="rgba(148,163,184,0.4)" strokeWidth="1" strokeDasharray="3 3" />}
          {refs.map((_, i) => {
            const gStart = PL + i * gap + (gap - groupW) / 2;
            return series.map((s, si) => {
              const val = s.data[i]?.value || 0;
              const bH = mounted ? (val / globalMax) * cH : 0;
              const bX = gStart + si * barW, bY = PT + cH - bH;
              return (
                <rect key={`${i}-${si}`} x={bX} y={bY} width={Math.max(barW - 1.5, 1)} height={bH} rx={2}
                  fill={s.color} opacity={i === hi ? 1 : 0.85}
                  style={{ transition: `height 0.6s cubic-bezier(0.34,1.56,0.64,1) ${(i * 0.02 + si * 0.04).toFixed(2)}s, y 0.6s cubic-bezier(0.34,1.56,0.64,1) ${(i * 0.02 + si * 0.04).toFixed(2)}s` }} />
              );
            });
          })}
          {m > 1 && (() => {
            let lx = PL;
            return series.map((s, i) => {
              const el = (
                <g key={i}>
                  <rect x={lx} y={legendY - 4} width={10} height={7} rx={1.5} fill={s.color} opacity={0.85} />
                  <text x={lx + 13} y={legendY + 3} fontSize="8" fill="#94a3b8" fontWeight="700">{s.label}</text>
                </g>
              );
              lx += s.label.length * 5.2 + 18;
              return el;
            });
          })()}
        </svg>
      </div>
      {hi !== null && mounted && (
        <div className="absolute pointer-events-none z-20"
          style={{ left: `${((PL + (hi + 0.5) * gap) / W * 100).toFixed(1)}%`, top: '4px', transform: 'translate(-50%, 0)' }}>
          <div className="bg-slate-900/90 backdrop-blur-sm border border-white/20 text-white rounded-xl px-3 py-2 shadow-2xl whitespace-nowrap">
            <p className="text-[9px] font-bold text-white/50 uppercase tracking-wider mb-1">{refs[hi].label}</p>
            {series.map((s, si) => {
              const val = s.data[hi]?.value || 0;
              return (
                <div key={si} className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-sm shrink-0" style={{ background: s.color }} />
                  <span className="text-[10px] text-white/60">{s.label}:</span>
                  <span className="text-[10px] font-black">{s.isMoney ? formatMoney(val) : val.toLocaleString('tr-TR')}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

const SVGDonutChart = ({ segments }: { segments: { label: string; value: number; color: string }[] }) => {
  const [mounted, setMounted] = useState(false);
  useEffect(() => { const t = setTimeout(() => setMounted(true), 120); return () => clearTimeout(t); }, []);
  const sum = segments.reduce((a, s) => a + s.value, 0) || 1;
  const R = 56, r = 34, cx = 72, cy = 72;
  let start = -Math.PI / 2;
  const arcs = segments.map(s => {
    const ang = (s.value / sum) * 2 * Math.PI;
    const end = start + ang;
    const x1 = cx + R * Math.cos(start), y1 = cy + R * Math.sin(start);
    const x2 = cx + R * Math.cos(end),   y2 = cy + R * Math.sin(end);
    const ix1 = cx + r * Math.cos(end),  iy1 = cy + r * Math.sin(end);
    const ix2 = cx + r * Math.cos(start), iy2 = cy + r * Math.sin(start);
    const lg = ang > Math.PI ? 1 : 0;
    const d = `M ${x1} ${y1} A ${R} ${R} 0 ${lg} 1 ${x2} ${y2} L ${ix1} ${iy1} A ${r} ${r} 0 ${lg} 0 ${ix2} ${iy2} Z`;
    start = end;
    return { ...s, d };
  });
  const top3 = [...segments].sort((a, b) => b.value - a.value).slice(0, 3);
  return (
    <div className="flex items-center gap-3 min-w-0">
      <svg viewBox="0 0 144 144" className="w-24 h-24 shrink-0">
        {arcs.map((a, i) => <path key={i} d={a.d} fill={a.color} style={{ opacity: mounted ? 1 : 0, transition: `opacity 0.4s ease ${(i * 0.1).toFixed(1)}s` }} />)}
        <circle cx={cx} cy={cy} r={r - 2} className="fill-white dark:fill-slate-900" style={{ fill: 'rgba(15,23,42,0.5)' }} />
        <text x={cx} y={cy - 5} textAnchor="middle" fontSize="9" fontWeight="700" fill="#94a3b8">Toplam</text>
        <text x={cx} y={cy + 9} textAnchor="middle" fontSize="11" fontWeight="900" fill="white">{`₺${(sum / 1000).toFixed(1)}K`}</text>
      </svg>
      <div className="space-y-1.5 flex-1 min-w-0">
        {top3.map((s, i) => (
          <div key={i} className="flex items-center gap-2 text-xs min-w-0">
            <div className="w-2 h-2 rounded-full shrink-0" style={{ background: s.color }} />
            <span className="text-white/60 truncate flex-1">{s.label}</span>
            <span className="font-black text-white shrink-0">{formatMoney(s.value)}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

// --- SVG Sparkline (mini arka plan çizgisi + büyük sayı) ---
const SVGSparkline = ({ data, color, value, label, isMoney, trend }: {
  data: { label: string; value: number }[];
  color: string;
  value: number;
  label: string;
  isMoney: boolean;
  trend?: number | null;
}) => {
  const [mounted, setMounted] = useState(false);
  useEffect(() => { const t = setTimeout(() => setMounted(true), 100); return () => clearTimeout(t); }, []);

  const W = 300, H = 60;
  let linePath = '', areaPath = '';
  if (data.length >= 2) {
    const vals = data.map(d => d.value);
    const min = Math.min(...vals), max = Math.max(...vals);
    const range = max - min || 1;
    const pts: [number, number][] = data.map((d, i) => [
      (i / (data.length - 1)) * W,
      H - 4 - ((d.value - min) / range) * (H - 8),
    ]);
    linePath = `M ${pts[0][0]},${pts[0][1]}`;
    for (let i = 1; i < pts.length; i++) {
      const [px, py] = pts[i - 1], [cx, cy] = pts[i], mid = (px + cx) / 2;
      linePath += ` C ${mid},${py} ${mid},${cy} ${cx},${cy}`;
    }
    areaPath = `${linePath} L ${W},${H} L 0,${H} Z`;
  }

  const trendUp = trend != null && trend >= 0;
  const gId = `sp_${color.replace('#', '')}`;
  return (
    <div className="relative overflow-hidden w-full h-full">
      {data.length >= 2 && (
        <div className="absolute inset-0 pointer-events-none" style={{ opacity: mounted ? 1 : 0, transition: 'opacity 0.6s' }}>
          <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="w-full h-full" style={{ display: 'block' }}>
            <defs>
              <linearGradient id={gId} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={color} stopOpacity={0.18} />
                <stop offset="100%" stopColor={color} stopOpacity={0} />
              </linearGradient>
            </defs>
            <path d={areaPath} fill={`url(#${gId})`} />
            <path d={linePath} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity={0.6} />
          </svg>
        </div>
      )}
      <div className="relative z-10 p-4 flex flex-col justify-between h-full">
        <div className="flex items-center gap-1.5">
          <BarChart2 size={11} style={{ color }} />
          <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider truncate">{label}</span>
        </div>
        <div>
          <p className="text-2xl font-black text-slate-800 dark:text-white leading-none">
            <AnimatedCounter value={value} prefix={isMoney ? '₺' : ''} />
          </p>
          {trend != null && (
            <div className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full mt-1 w-fit ${trendUp ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400' : 'bg-red-50 dark:bg-red-900/20 text-red-500 dark:text-red-400'}`}>
              {trendUp ? <ArrowUp size={9} /> : <ArrowDown size={9} />}
              {Math.abs(trend).toFixed(1)}%
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// --- SVG Gauge (yarım daire gösterge) ---
const SVGGauge = ({ value, max = 100, color, label, unit = '%' }: {
  value: number;
  max?: number;
  color: string;
  label: string;
  unit?: string;
}) => {
  const [mounted, setMounted] = useState(false);
  useEffect(() => { const t = setTimeout(() => setMounted(true), 150); return () => clearTimeout(t); }, []);

  const pct = Math.min(Math.max(value / max, 0), 1);
  const R = 44, cx = 60, cy = 58;
  const circumference = Math.PI * R; // yarım çember
  const dashArray = circumference;
  const dashOffset = circumference * (1 - (mounted ? pct : 0));

  const getArcColor = (p: number) => {
    if (p >= 0.7) return '#34d399';  // yeşil
    if (p >= 0.4) return '#fbbf24';  // sarı
    return '#f87171';                 // kırmızı
  };
  const arcColor = color || getArcColor(pct);

  const displayVal = max === 100 ? value.toFixed(1) : value.toFixed(2);

  return (
    <div className="flex flex-col items-center justify-center h-full py-3 gap-1">
      <svg viewBox="0 0 120 68" className="w-full max-w-[140px]" style={{ overflow: 'visible' }}>
        {/* arka plan yayı */}
        <path
          d={`M ${cx - R},${cy} A ${R},${R} 0 0,1 ${cx + R},${cy}`}
          fill="none"
          stroke="currentColor"
          strokeWidth="10"
          strokeLinecap="round"
          className="text-slate-100 dark:text-slate-800"
        />
        {/* değer yayı */}
        <path
          d={`M ${cx - R},${cy} A ${R},${R} 0 0,1 ${cx + R},${cy}`}
          fill="none"
          stroke={arcColor}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={`${dashArray}`}
          strokeDashoffset={`${dashOffset}`}
          style={{ transition: 'stroke-dashoffset 1.2s cubic-bezier(0.34,1.56,0.64,1)', transformOrigin: `${cx}px ${cy}px` }}
        />
        {/* değer etiketi */}
        <text x={cx} y={cy - 6} textAnchor="middle" fontSize="18" fontWeight="900" fill="currentColor" className="text-slate-800 dark:text-white" style={{ fill: arcColor }}>
          {displayVal}
        </text>
        <text x={cx} y={cy + 8} textAnchor="middle" fontSize="9" fill="currentColor" className="text-slate-400 dark:text-slate-500">
          {unit}
        </text>
      </svg>
      <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider text-center truncate px-2">{label}</p>
    </div>
  );
};

// --- SVG Calendar Heatmap (günlük yoğunluk ızgarası) ---
const SVGCalendarHeatmap = ({ data, color, isMoney }: {
  data: { date: string; value: number }[];
  color: string;
  isMoney: boolean;
}) => {
  if (!data || data.length === 0) {
    return <div className="flex-1 flex items-center justify-center text-slate-400 dark:text-slate-500 text-sm">Veri yükleniyor…</div>;
  }
  const maxVal = Math.max(...data.map(d => d.value), 1);
  const CELL = 14, GAP = 2;
  const weeks = Math.ceil(data.length / 7);
  const W = weeks * (CELL + GAP), H = 7 * (CELL + GAP);

  const colFor = (val: number) => {
    if (val === 0) return 'rgba(148,163,184,0.2)';
    const pct = val / maxVal;
    const hexColor = color.replace('#', '');
    const r = parseInt(hexColor.slice(0, 2), 16);
    const g = parseInt(hexColor.slice(2, 4), 16);
    const b = parseInt(hexColor.slice(4, 6), 16);
    const alpha = 0.15 + pct * 0.85;
    return `rgba(${r},${g},${b},${alpha})`;
  };

  const cells = data.map((d, i) => {
    const week = Math.floor(i / 7);
    const day = i % 7;
    return { ...d, x: week * (CELL + GAP), y: day * (CELL + GAP), val: d.value };
  });

  const fmtDate = (s: string) => {
    try { return new Date(s).toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' }); }
    catch { return s; }
  };

  return (
    <div className="overflow-x-auto w-full scrollbar-thin pb-1">
      <svg viewBox={`0 0 ${W} ${H}`} style={{ width: Math.max(W, 200), height: H + 4, display: 'block', minWidth: '100%' }}>
        {cells.map((c, i) => (
          <g key={i}>
            <rect
              x={c.x} y={c.y}
              width={CELL} height={CELL}
              rx={3} ry={3}
              fill={colFor(c.val)}
            >
              <title>{fmtDate(c.date)}: {isMoney ? `₺${c.val.toLocaleString('tr-TR')}` : c.val.toLocaleString('tr-TR')}</title>
            </rect>
          </g>
        ))}
      </svg>
    </div>
  );
};

// --- Tek widget render bileşeni ---
type AllData = {
  overview: any;
  salesChart: { label: string; value: number }[];
  revenueChart: { label: string; value: number }[];
  txChart: { label: string; value: number }[];
  customerChart: { label: string; value: number }[];
  finBreak: any;
  activities: any[];
  topByValue: any[];
  topLowStock: any[];
  topProfit: any[];
  calSales: { date: string; value: number }[];
  calTx: { date: string; value: number }[];
};

const DashWidgetBox = ({ widget, allData, hero, onNavigate }: {
  widget: DashWidget;
  allData: AllData | null;
  hero: typeof HERO_CONFIGS.indigo;
  onNavigate?: (view: string) => void;
}) => {
  const primarySrc = widget.sources[0] || 'sales';
  const srcDef = SOURCE_DEFS[primarySrc] || SOURCE_DEFS.sales;
  const WidIcon = srcDef.icon;
  const chartH = CHART_H[widget.span];

  // Corporate card base — attığın cardBaseClass ile birebir
  const CC = "bg-white dark:bg-slate-900 rounded-xl shadow-[0_2px_10px_rgba(0,0,0,0.02)] dark:shadow-none border border-slate-200 dark:border-slate-800 transition-all duration-200 hover:border-blue-500/30 dark:hover:border-blue-500/50 flex flex-col";
  const LBL = "text-sm font-medium uppercase tracking-wider text-slate-500 dark:text-slate-400";

  if (!allData) {
    return (
      <div className={`${CC} items-center justify-center`} style={{ minHeight: 100 }}>
        <RefreshCw size={18} className="animate-spin text-slate-300 dark:text-slate-600" />
      </div>
    );
  }

  const stats = allData.overview?.stats;
  const perf = allData.overview?.performance;
  const fb = allData.finBreak?.breakdown;

  // Stat value resolver
  const resolveStatMap = (): Partial<Record<DataSourceId, { value: number; trend: number | null }>> => ({
    sales:            { value: Math.round(stats?.total_sales?.value || 0),       trend: stats?.total_sales?.percentage_change ?? null },
    revenue:          { value: Math.round(stats?.total_revenue?.value || 0),     trend: stats?.total_revenue?.percentage_change ?? null },
    sales_count:      { value: fb?.satış?.count || 0,                            trend: null },
    tx_count:         { value: (fb?.satış?.count||0)+(fb?.borç?.count||0)+(fb?.ödeme?.count||0)+(fb?.gider?.count||0), trend: null },
    outstanding_debt: { value: Math.round(stats?.outstanding_debt?.value || 0),  trend: stats?.outstanding_debt?.percentage_change ?? null },
    debt_total:       { value: Math.round(fb?.borç?.total || 0),                 trend: null },
    payment_total:    { value: Math.round(fb?.ödeme?.total || 0),                trend: null },
    expense_total:    { value: Math.round(fb?.gider?.total || 0),                trend: null },
    senet_total:      { value: Math.round(fb?.senet?.total || 0),                trend: null },
    kredi_total:      { value: Math.round(fb?.kredi?.total || 0),                trend: null },
    warranty_val:     { value: Math.round(fb?.garanti?.total || 0),              trend: null },
    debt_count:       { value: fb?.borç?.count || 0,                             trend: null },
    payment_count:    { value: fb?.ödeme?.count || 0,                            trend: null },
    products:         { value: stats?.total_products?.value || 0,                trend: null },
    critical:         { value: stats?.critical_stock_count?.value || 0,          trend: null },
    categories:       { value: stats?.total_categories?.value || 0,              trend: null },
    customers:        { value: stats?.total_customers?.value || 0,               trend: null },
    daily_avg:        { value: Math.round(perf?.daily_average_sales || 0),       trend: null },
    weekly_avg:       { value: Math.round(perf?.weekly_average_sales || 0),      trend: null },
  });

  // Chart data resolver
  const chartDataFor = (src: DataSourceId) => ({
    sales:          allData.salesChart,
    revenue:        allData.revenueChart,
    tx_trend:       allData.txChart,
    customer_trend: allData.customerChart,
  } as Partial<Record<DataSourceId, { label: string; value: number }[]>>)[src] || allData.salesChart;

  switch (widget.type) {

    case 'stat': {
      const statMap = resolveStatMap();
      const single = widget.sources.length === 1;
      if (single) {
        const src = widget.sources[0];
        const { value = 0, trend = null } = statMap[src] || {};
        const isMoney = SOURCE_DEFS[src]?.isMoney;
        const trendUp = trend != null && trend >= 0;
        return (
          <div className={`${CC} p-6`}>
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                <WidIcon size={18} />
                <h4 className={`${LBL} truncate`}>{widget.title}</h4>
              </div>
              <MoreHorizontal size={18} className="text-slate-400 shrink-0" />
            </div>
            <div className="mt-auto">
              <div className="flex items-baseline gap-3">
                <h2 className="text-3xl font-semibold text-slate-900 dark:text-white tracking-tight">
                  <AnimatedCounter value={value} prefix={isMoney ? '₺' : ''} />
                </h2>
                {trend != null && (
                  <span className={`flex items-center text-xs font-medium px-2 py-0.5 rounded-md ${trendUp ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10' : 'text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-500/10'}`}>
                    {trendUp ? <ArrowUpRight size={14} className="mr-0.5" /> : <TrendingDown size={14} className="mr-0.5" />}
                    %{Math.abs(trend).toFixed(1)}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-2">{SOURCE_DEFS[src]?.label}</p>
            </div>
          </div>
        );
      }
      // Multi-stat
      return (
        <div className={`${CC} p-6`}>
          <h4 className={`${LBL} mb-5 truncate`}>{widget.title}</h4>
          <div className="flex flex-col divide-y divide-slate-100 dark:divide-slate-800 flex-1">
            {widget.sources.map((src, i) => {
              const { value = 0, trend = null } = statMap[src] || {};
              const def = SOURCE_DEFS[src];
              const SIcon = def?.icon || Hash;
              const isMoney = def?.isMoney;
              const trendUp = trend != null && trend >= 0;
              return (
                <div key={src} className="flex items-center gap-2.5 py-3 first:pt-0 last:pb-0">
                  <SIcon size={14} style={{ color: SERIES_PALETTE[i % SERIES_PALETTE.length] }} className="shrink-0" />
                  <span className="text-xs text-slate-500 dark:text-slate-400 flex-1 truncate">{def?.label}</span>
                  <div className="flex items-center gap-1.5">
                    {trend != null && (
                      <span className={`text-[10px] font-semibold ${trendUp ? 'text-emerald-500' : 'text-red-500'}`}>
                        {trendUp ? '↑' : '↓'}{Math.abs(trend).toFixed(1)}%
                      </span>
                    )}
                    <span className="font-semibold text-sm text-slate-800 dark:text-white whitespace-nowrap">
                      {isMoney ? `₺${value.toLocaleString('tr-TR')}` : value.toLocaleString('tr-TR')}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      );
    }

    case 'line':
    case 'bar': {
      const multiSeries: ChartSeries[] = widget.sources.map((src, i) => ({
        label: SOURCE_DEFS[src]?.label || src,
        color: i === 0 ? '#2563eb' : SERIES_PALETTE[i % SERIES_PALETTE.length],
        data: chartDataFor(src),
        isMoney: SOURCE_DEFS[src]?.isMoney || false,
      }));
      const isSingle = widget.sources.length === 1;
      const totalVal = multiSeries[0]?.data.reduce((s, d) => s + d.value, 0) || 0;
      const isMoney = SOURCE_DEFS[widget.sources[0]]?.isMoney;
      return (
        <div className={CC}>
          <div className="flex justify-between items-start px-6 pt-6 pb-3">
            <div>
              <h4 className={LBL}>{widget.title}</h4>
              <h2 className="text-2xl font-semibold text-slate-900 dark:text-white mt-1 tracking-tight">
                {isMoney ? `₺${Math.round(totalVal).toLocaleString('tr-TR')}` : totalVal.toLocaleString('tr-TR')}
              </h2>
            </div>
          </div>
          <div className="overflow-hidden">
            {isSingle
              ? (widget.type === 'line'
                  ? <SVGLineChart data={multiSeries[0].data} color="#2563eb" height={chartH} />
                  : <SVGBarChart data={multiSeries[0].data} color="#2563eb" height={chartH} />)
              : (widget.type === 'line'
                  ? <SVGMultiLineChart series={multiSeries} height={chartH} />
                  : <SVGMultiBarChart series={multiSeries} height={chartH} />)
            }
          </div>
        </div>
      );
    }

    case 'donut': {
      const isExt = widget.sources[0] === 'fin_break_ext';
      const segs4 = fb ? [
        { label: 'Satışlar', value: fb.satış?.total  || 0, color: '#34d399' },
        { label: 'Borçlar',  value: fb.borç?.total   || 0, color: '#f87171' },
        { label: 'Ödemeler', value: fb.ödeme?.total  || 0, color: '#60a5fa' },
        { label: 'Giderler', value: fb.gider?.total  || 0, color: '#fbbf24' },
      ] : [];
      const segs7 = fb ? [...segs4,
        { label: 'Senet',   value: fb.senet?.total   || 0, color: '#a78bfa' },
        { label: 'Kredi',   value: fb.kredi?.total   || 0, color: '#fb923c' },
        { label: 'Garanti', value: fb.garanti?.total || 0, color: '#22d3ee' },
      ] : [];
      const segments = (isExt ? segs7 : segs4).filter(s => s.value > 0);
      return (
        <div className={`${CC}`}>
          <div className="flex justify-between items-center px-6 pt-6 pb-2">
            <h4 className={LBL}>{widget.title}</h4>
            <WidIcon size={16} className="text-slate-400" />
          </div>
          <div className="flex-1 flex items-center min-h-[96px]">
            {segments.length > 0 ? <SVGDonutChart segments={segments} /> : (
              <div className="w-full text-center text-slate-400 dark:text-slate-500 text-sm p-4">Henüz veri yok</div>
            )}
          </div>
        </div>
      );
    }

    case 'activity': {
      const activities = allData.activities || [];
      const dotColors: Record<string, string> = { product: '#22c55e', transaction: '#3b82f6', auth: '#f87171', file: '#f59e0b', user: '#a78bfa' };
      return (
        <div className={`${CC} p-6`}>
          <div className="flex justify-between items-center mb-5">
            <h4 className={LBL}>{widget.title}</h4>
            <Activity size={16} className="text-slate-400" />
          </div>
          {activities.length === 0 ? (
            <div className="flex-1 flex items-center justify-center text-slate-400 dark:text-slate-500 text-sm">Henüz aktivite yok</div>
          ) : (
            <div className="relative border-l border-slate-200 dark:border-slate-700 ml-2 space-y-5 overflow-y-auto flex-1">
              {activities.slice(0, 6).map((a: any, i: number) => {
                const dot = dotColors[a.type] || '#94a3b8';
                return (
                  <div key={i} className="relative pl-4">
                    <span className="absolute -left-[5px] top-1.5 w-2 h-2 rounded-full ring-4 ring-white dark:ring-slate-900" style={{ background: dot }} />
                    <p className="text-sm font-medium text-slate-800 dark:text-slate-200">{a.action}</p>
                    {a.detail && <p className="text-xs text-slate-500 mt-0.5 font-mono truncate">{a.detail}</p>}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      );
    }

    case 'sparkline': {
      const sparkMap: Partial<Record<DataSourceId, { data: { label: string; value: number }[]; value: number; trend: number | null; isMoney: boolean }>> = {
        sparkline_sales:   { data: allData.salesChart,   value: Math.round(stats?.total_sales?.value || 0),   trend: stats?.total_sales?.percentage_change ?? null,   isMoney: true  },
        sparkline_revenue: { data: allData.revenueChart, value: Math.round(stats?.total_revenue?.value || 0), trend: stats?.total_revenue?.percentage_change ?? null,  isMoney: true  },
        sparkline_tx:      { data: allData.txChart,      value: allData.txChart.reduce((s: number, d: any) => s + d.value, 0), trend: null, isMoney: false },
      };
      const sp = sparkMap[primarySrc] || sparkMap.sparkline_sales!;
      const trendUp = sp.trend != null && sp.trend >= 0;
      const sparkPts = sp.data.length > 1 ? sp.data : [];
      const maxV = Math.max(...sparkPts.map(d => d.value), 1);
      const svgW = 100, svgH = 30;
      const toX = (i: number) => (i / Math.max(sparkPts.length - 1, 1)) * svgW;
      const toY = (v: number) => svgH - (v / maxV) * svgH * 0.9;
      const polyPts = sparkPts.map((d, i) => `${toX(i)},${toY(d.value)}`).join(' ');
      const areaPts = sparkPts.length > 0 ? `${toX(0)},${svgH} ${polyPts} ${toX(sparkPts.length - 1)},${svgH}` : '';
      const displayVal = sp.isMoney ? `₺${sp.value.toLocaleString('tr-TR')}` : sp.value.toLocaleString('tr-TR');
      return (
        <div className={`${CC} p-6`}>
          <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400 mb-4">
            <WidIcon size={18} />
            <h4 className={`${LBL} truncate`}>{widget.title}</h4>
          </div>
          <div className="mt-auto relative w-full h-16 flex items-end justify-between">
            <div className="absolute top-0 left-0">
              <h2 className="text-3xl font-semibold text-slate-900 dark:text-white tracking-tight">{displayVal}</h2>
              {sp.trend != null && (
                <span className={`inline-flex items-center text-xs font-medium px-1.5 py-0.5 rounded-md mt-1 ${trendUp ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-500/10' : 'text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-500/10'}`}>
                  {trendUp ? <ArrowUpRight size={12} className="mr-0.5" /> : <TrendingDown size={12} className="mr-0.5" />}
                  %{Math.abs(sp.trend).toFixed(1)}
                </span>
              )}
            </div>
            {sparkPts.length > 1 && (
              <svg viewBox={`0 0 ${svgW} ${svgH}`} preserveAspectRatio="none" className="w-2/3 h-10 ml-auto opacity-80">
                <defs>
                  <linearGradient id={`spg_${widget.id}`} x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.2" />
                    <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
                  </linearGradient>
                </defs>
                <polygon points={areaPts} fill={`url(#spg_${widget.id})`} />
                <polyline points={polyPts} fill="none" stroke="#3b82f6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                {sparkPts.length > 0 && <circle cx={toX(sparkPts.length - 1)} cy={toY(sparkPts[sparkPts.length - 1].value)} r="3" fill="#3b82f6" />}
              </svg>
            )}
          </div>
        </div>
      );
    }

    case 'gauge': {
      const gaugeMap: Partial<Record<DataSourceId, { value: number; max: number; unit: string; color: string; label: string; sub: string }>> = {
        profit_margin:     { value: perf?.profit_margin_average || 0,   max: 100, unit: '%', color: '#2563eb', label: 'Aylık Kota',     sub: 'Ortalama kar marjı' },
        critical_pct:      { value: stats?.total_products?.value > 0 ? Math.round((stats?.critical_stock_count?.value || 0) / stats.total_products.value * 100) : 0, max: 100, unit: '%', color: '#f87171', label: 'Kritik Stok', sub: 'Kritik stok oranı' },
        inventory_turnover:{ value: perf?.inventory_turnover || 0, max: Math.max(10, Math.ceil((perf?.inventory_turnover || 0) * 1.5)), unit: 'x', color: '#2563eb', label: 'Stok Devri', sub: 'Stok devir hızı' },
      };
      const gd = gaugeMap[primarySrc] || gaugeMap.profit_margin!;
      const pct = Math.min(gd.value / gd.max, 1);
      // GoalWidget arc: M 10 50 A 40 40 0 0 1 90 50 → arcLen ≈ Math.PI * 40 ≈ 125.6
      const arcLen = Math.PI * 40;
      const arcOffset = arcLen * (1 - pct);
      const displayVal = gd.unit === '%' ? `%${Math.round(gd.value)}` : `${gd.value.toFixed(1)}${gd.unit}`;
      return (
        <div className={`${CC} p-6`}>
          <div className="flex justify-between items-start mb-4">
            <div>
              <h4 className={LBL}>{widget.title}</h4>
              <p className="text-xs text-slate-400 mt-1">{gd.sub}</p>
            </div>
            <Target size={18} className="text-slate-400" />
          </div>
          <div className="relative w-full flex justify-center mt-2">
            <svg viewBox="0 0 100 50" className="w-48 overflow-visible">
              <path d="M 10 50 A 40 40 0 0 1 90 50" fill="none" stroke="currentColor" strokeWidth="6" strokeLinecap="round" className="text-slate-100 dark:text-slate-800" />
              <path d="M 10 50 A 40 40 0 0 1 90 50" fill="none" stroke={gd.color} strokeWidth="6" strokeLinecap="round"
                strokeDasharray={arcLen} strokeDashoffset={arcOffset}
                style={{ transition: 'stroke-dashoffset 1.2s cubic-bezier(.34,1.56,.64,1)' }} />
            </svg>
            <div className="absolute bottom-0 left-0 right-0 text-center">
              <span className="text-2xl font-semibold text-slate-900 dark:text-white">{displayVal}</span>
            </div>
          </div>
          <div className="text-center mt-4 border-t border-slate-100 dark:border-slate-800 pt-3">
            <p className="text-xs text-slate-500">{gd.label}</p>
          </div>
        </div>
      );
    }

    case 'top': {
      const isFinance = primarySrc === 'top_finance';
      const isPct = primarySrc === 'top_profit';
      const isCount = primarySrc === 'top_low_stock';
      let topItems: any[] = [];
      if (isFinance) {
        topItems = fb ? [
          { name: 'Satışlar', value: fb.satış?.total || 0, sub: `${fb.satış?.count || 0} işlem`, color: '#34d399' },
          { name: 'Borçlar',  value: fb.borç?.total  || 0, sub: `${fb.borç?.count  || 0} işlem`, color: '#f87171' },
          { name: 'Ödemeler', value: fb.ödeme?.total || 0, sub: `${fb.ödeme?.count || 0} işlem`, color: '#60a5fa' },
          { name: 'Giderler', value: fb.gider?.total || 0, sub: `${fb.gider?.count || 0} işlem`, color: '#fbbf24' },
          { name: 'Senet',    value: fb.senet?.total || 0, sub: `${fb.senet?.count || 0} işlem`, color: '#a78bfa' },
          { name: 'Kredi',    value: fb.kredi?.total || 0, sub: `${fb.kredi?.count || 0} işlem`, color: '#fb923c' },
        ].filter(x => x.value > 0).sort((a, b) => b.value - a.value) : [];
      } else if (primarySrc === 'top_by_value') {
        topItems = (allData.topByValue || []).map((p: any, i: number) => ({ name: p.name, value: p.value, sub: `${p.quantity} adet`, color: SERIES_PALETTE[i % SERIES_PALETTE.length] }));
      } else if (primarySrc === 'top_low_stock') {
        topItems = (allData.topLowStock || []).map((p: any, i: number) => ({ name: p.name, value: p.quantity, sub: `Min: ${p.min_stock}`, color: p.pct < 50 ? '#f87171' : p.pct < 80 ? '#fbbf24' : '#34d399' }));
      } else if (primarySrc === 'top_profit') {
        topItems = (allData.topProfit || []).map((p: any, i: number) => ({ name: p.name, value: p.margin_pct, sub: `₺${p.cost?.toFixed(0)} → ₺${p.price?.toFixed(0)}`, color: SERIES_PALETTE[i % SERIES_PALETTE.length] }));
      }
      const fmtV = (v: number) => isFinance || (!isPct && !isCount) ? `₺${Math.round(v).toLocaleString('tr-TR')}` : isPct ? `%${v.toFixed(1)}` : v.toLocaleString('tr-TR');
      return (
        <div className={`${CC} p-6`}>
          <div className="flex justify-between items-center mb-5">
            <h4 className={LBL}>{widget.title}</h4>
            <Award size={16} className="text-slate-400" />
          </div>
          {topItems.length === 0 ? (
            <div className="flex-1 flex items-center justify-center text-slate-400 dark:text-slate-500 text-sm">Henüz veri yok</div>
          ) : (
            <div className="space-y-4 mt-auto">
              {topItems.slice(0, 5).map((item: any, i: number) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-xs font-semibold text-slate-600 dark:text-slate-300 shrink-0">
                      {(item.name || '?').charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <h5 className="text-sm font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[130px]">{item.name}</h5>
                      {item.sub && <p className="text-[11px] text-slate-500">{item.sub}</p>}
                    </div>
                  </div>
                  <span className="text-sm font-medium text-slate-900 dark:text-white shrink-0 ml-2">{fmtV(item.value)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      );
    }

    case 'calendar': {
      const calData = primarySrc === 'cal_tx' ? allData.calTx : allData.calSales;
      const isMoney = primarySrc === 'cal_sales';
      const totalVal = calData.reduce((s: number, d: any) => s + d.value, 0);
      const activeDays = calData.filter((d: any) => d.value > 0).length;
      // CSS grid renk seviyeleri — CalendarHeatmapWidget'la birebir
      const maxVal = Math.max(...calData.map((d: any) => d.value), 1);
      const calLevel = (v: number) => v === 0 ? 0 : v < maxVal * 0.33 ? 1 : v < maxVal * 0.66 ? 2 : 3;
      const calColor = (lv: number) => {
        switch (lv) {
          case 1: return 'bg-blue-100 dark:bg-blue-900/30';
          case 2: return 'bg-blue-300 dark:bg-blue-700/50';
          case 3: return 'bg-blue-600 dark:bg-blue-500';
          default: return 'bg-slate-100 dark:bg-slate-800';
        }
      };
      // Son 84 günü al, 12 hafta × 7 gün grid-rows-7 grid-flow-col
      const last84 = calData.slice(-84);
      const gridData = Array.from({ length: 84 }, (_, i) => calLevel(last84[i]?.value || 0));
      return (
        <div className={CC}>
          <div className="flex justify-between items-start px-6 pt-6 pb-3">
            <div>
              <h4 className={LBL}>{widget.title}</h4>
              <p className="text-xs text-slate-400 mt-1">{activeDays} aktif gün • son 90 gün</p>
            </div>
            <span className="text-sm font-semibold text-slate-900 dark:text-white shrink-0">
              {isMoney ? `₺${Math.round(totalVal).toLocaleString('tr-TR')}` : totalVal.toLocaleString('tr-TR')}
            </span>
          </div>
          <div className="flex-1 px-6 pb-4 overflow-x-auto">
            <div className="grid grid-rows-7 grid-flow-col gap-1 min-w-[280px]">
              {gridData.map((lv, i) => (
                <div key={i} className={`w-3.5 h-3.5 rounded-sm ${calColor(lv)} cursor-pointer hover:border hover:border-blue-400 box-border transition-colors`} />
              ))}
            </div>
          </div>
        </div>
      );
    }

    case 'quickactions': {
      const actions = [
        { icon: Plus,      label: 'Yeni Fatura',  view: 'transactions' },
        { icon: FileText,  label: 'Raporlar',      view: 'dashboard' },
        { icon: Users,     label: 'Müşteriler',    view: 'customers' },
        { icon: Settings,  label: 'Ayarlar',       view: 'settings' },
      ];
      return (
        <div className={`${CC} p-6`}>
          <h4 className={`${LBL} mb-5`}>{widget.title || 'Hızlı İşlemler'}</h4>
          <div className="grid grid-cols-2 gap-3 mt-auto">
            {actions.map((a, i) => {
              const AIcon = a.icon;
              return (
                <button key={i} onClick={() => onNavigate?.(a.view)}
                  className="flex items-center gap-2 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 transition-colors text-sm font-medium">
                  <AIcon size={18} />
                  <span>{a.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      );
    }

    case 'messages': {
      const acts = (allData.activities || []).slice(0, 3);
      const isHigh = (a: any) => a.type === 'auth' || a.status === 'warning';
      const fmtTime = (t: any) => t ? new Date(t).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }) : '';
      return (
        <div className={`${CC} p-6`}>
          <div className="flex justify-between items-center mb-5">
            <div className="flex items-center gap-2">
              <h4 className={LBL}>{widget.title || 'Bekleyen Görevler'}</h4>
              {acts.length > 0 && (
                <span className="bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400 text-[10px] font-bold px-1.5 py-0.5 rounded">{acts.length}</span>
              )}
            </div>
          </div>
          {acts.length === 0 ? (
            <div className="flex-1 flex items-center justify-center text-slate-400 dark:text-slate-500 text-sm">Aktivite yok</div>
          ) : (
            <>
              <div className="space-y-4">
                {acts.map((a: any, i: number) => (
                  <div key={i} className="cursor-pointer border-b border-slate-100 dark:border-slate-800/60 pb-3 last:border-0 last:pb-0">
                    <div className="flex justify-between items-start mb-1">
                      <h5 className="text-sm font-semibold text-slate-800 dark:text-slate-200 line-clamp-1 pr-2">{a.action}</h5>
                      <span className="text-[10px] text-slate-400 whitespace-nowrap shrink-0">{fmtTime(a.time)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-500">{a.detail || a.type}</span>
                      {isHigh(a) && <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0" />}
                    </div>
                  </div>
                ))}
              </div>
              <button onClick={() => onNavigate?.('dashboard')}
                className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs font-medium text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors text-left w-full">
                Tümünü Görüntüle →
              </button>
            </>
          )}
        </div>
      );
    }

    default: return null;
  }
};

const PatronDashboard = ({ currentUser, layout, setLayout, dashboardData, onNavigate }: {
  currentUser: any;
  layout: DashLayout;
  setLayout: (l: DashLayout) => void;
  dashboardData: any;
  onNavigate?: (view: string) => void;
}) => {
  const hero = HERO_CONFIGS[layout.heroColor] || HERO_CONFIGS.indigo;
  const [allData, setAllData] = useState<AllData | null>(null);

  const greeting = (() => {
    const h = new Date().getHours();
    return h < 12 ? 'Günaydın' : h < 18 ? 'İyi Günler' : 'İyi Akşamlar';
  })();
  const todayStr = new Date().toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  useEffect(() => {
    const load = async () => {
      if (!dashboardData) return;
      try {
        const [saleChart, fb, act, topVal, topLow, topPro, calChart] = await Promise.all([
          api.get('/dashboard/chart-data', { params: { chart_type: 'sales', days: 14 } }),
          api.get('/dashboard/finance-breakdown', { params: { period: 'month' } }),
          api.get('/dashboard/activities', { params: { limit: 10 } }),
          api.get('/dashboard/top-products', { params: { sort_by: 'stock_value', limit: 5 } }),
          api.get('/dashboard/top-products', { params: { sort_by: 'low_stock', limit: 5 } }),
          api.get('/dashboard/top-products', { params: { sort_by: 'profit', limit: 5 } }),
          api.get('/dashboard/chart-data', { params: { chart_type: 'sales', days: 90 } }),
        ]);
        const mapField = (res: any, field: string) =>
          (res.data?.data || []).map((d: any) => ({ label: d.date.slice(5), value: d[field] ?? 0 }));
        const mapCal = (res: any, field: string) =>
          (res.data?.data || []).map((d: any) => ({ date: d.date, value: d[field] ?? 0 }));
        setAllData({
          overview:     dashboardData,
          salesChart:   mapField(saleChart, 'sales'),
          revenueChart: mapField(saleChart, 'revenue'),
          txChart:      mapField(saleChart, 'transactions'),
          customerChart:mapField(saleChart, 'customers'),
          finBreak:     fb.data,
          activities:   act.data?.items || [],
          topByValue:   topVal.data || [],
          topLowStock:  topLow.data || [],
          topProfit:    topPro.data || [],
          calSales:     mapCal(calChart, 'sales'),
          calTx:        mapCal(calChart, 'transactions'),
        });
      } catch (e) {
        console.error('PatronDashboard load error', e);
        setAllData({ overview: dashboardData, salesChart: [], revenueChart: [], txChart: [], customerChart: [], finBreak: null, activities: [], topByValue: [], topLowStock: [], topProfit: [], calSales: [], calTx: [] });
      }
    };
    load();
  }, [dashboardData]);

  return (
    <div className="space-y-6">
      {/* HERO */}
      <div className={`relative bg-gradient-to-br ${hero.gradient} rounded-3xl overflow-hidden shadow-2xl ${hero.glow}`}>
        <div className="absolute -top-20 -right-20 w-72 h-72 bg-white/5 rounded-full pointer-events-none" />
        <div className="absolute -bottom-24 -left-16 w-80 h-80 bg-white/5 rounded-full pointer-events-none" />
        <div className="absolute top-1/3 right-1/3 w-48 h-48 bg-white/5 rounded-full pointer-events-none" />
        <div className="relative z-10 p-6 sm:p-10">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
            <div>
              <p className="text-white/60 font-semibold text-sm mb-0.5">{greeting},</p>
              <h1 className="text-3xl sm:text-4xl font-black text-white leading-tight">{currentUser?.name || currentUser?.full_name} 👋</h1>
              <p className="text-white/40 text-xs mt-1.5 font-medium">{todayStr}</p>
            </div>
            <span className="inline-flex self-start items-center gap-1.5 text-xs font-bold text-white/60 bg-white/10 px-3 py-1.5 rounded-full border border-white/10">
              <LayoutDashboard size={12} /> Bayi Paneli
            </span>
          </div>
        </div>
      </div>

      {/* WİDGET IZGARASI */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {layout.widgets.map(widget => (
          <div key={widget.id} className={SPAN_CLASSES[widget.span]}>
            <DashWidgetBox widget={widget} allData={allData} hero={hero} onNavigate={onNavigate} />
          </div>
        ))}
      </div>
    </div>
  );
};

// 4. Müşteri Ana Paneli (Dashboard)
const CustomerDashboard = ({ setView, currentUser }) => {
  const { t, categories } = useAppContext();
  const isPatron = currentUser?.role === 'bayi_sahibi';
  const { layout, setLayout } = useDashboardLayout(isPatron ? (currentUser?.id ?? null) : null);
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const response = await api.get('/dashboard');
        setDashboardData(response.data);
      } catch (error) {
        console.error("Dashboard error:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchDashboard();
  }, []);

  // Kısayol ızgaraları artık bayinin Web Görünüm ayarlarından gelir.
  const visibleCategories = (categories || []).filter((c: any) => c.is_visible);
  const stockGrid = visibleCategories
    .filter((c: any) => c.kind === 'stok')
    .sort((a: any, b: any) => (a.display_order - b.display_order) || String(a.name).localeCompare(String(b.name), 'tr-TR'))
    .map((c: any) => ({ label: c.name, icon: iconFor(c.icon), color: c.color_class, bg: c.bg_class, id: c.key }));

  const dynamicFinanceGrid = visibleCategories
    .filter((c: any) => c.kind === 'finans')
    .map((c: any) => ({ label: c.name, icon: iconFor(c.icon), color: c.color_class, bg: c.bg_class, id: c.key, display_order: c.display_order }));

  const financeGrid = [
    ...dynamicFinanceGrid,
    { label: 'İşlem Geçmişi', icon: History, color: 'text-slate-600 dark:text-slate-400', bg: 'bg-slate-100 dark:bg-slate-800', id: 'fin_gecmis', display_order: 9000 },
    { label: 'Gelişmiş Raporlar', icon: PieChart, color: 'text-purple-600 dark:text-purple-400', bg: 'bg-purple-100 dark:bg-purple-900/30', id: 'fin_raporlar', display_order: 9100 },
  ].sort((a: any, b: any) => ((a.display_order || 0) - (b.display_order || 0)) || String(a.label).localeCompare(String(b.label), 'tr-TR'));

  if (loading) {
    return <div className="p-8 text-center text-slate-500 animate-pulse">{t('Yükleniyor...')}</div>;
  }

  const criticalAlerts = dashboardData?.critical_alerts?.alerts || [];
  const showAlerts  = true;
  const showStock   = true;
  const showFinance = true;

  return (
    <div className="space-y-8 animate-in fade-in duration-300 pb-10 max-w-7xl mx-auto">

      {/* Bayi sahibi → gelişmiş hero panel */}
      {isPatron ? (
        <PatronDashboard currentUser={currentUser} layout={layout} setLayout={setLayout} dashboardData={dashboardData} onNavigate={setView} />
      ) : (
        /* Çalışan için sade başlık */
        <div className="bg-indigo-600 dark:bg-indigo-700 rounded-3xl p-6 sm:p-10 text-white shadow-xl shadow-indigo-200 dark:shadow-none relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none"><TrendingUp size={200}/></div>
          <div className="relative z-10">
            <h1 className="text-3xl sm:text-4xl font-black mb-2">{t('Hoşgeldiniz')}, {currentUser?.name} 👋</h1>
            <p className="text-indigo-200 dark:text-indigo-100 font-medium text-lg">{t('genel durum panelindesiniz.')}</p>
          </div>
        </div>
      )}

      {showAlerts && criticalAlerts.length > 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-red-200 dark:border-red-900/50 shadow-sm overflow-hidden animate-in fade-in">
          <div className="bg-red-50 dark:bg-red-900/10 p-5 sm:px-6 flex flex-col sm:flex-row sm:items-center gap-4 border-b border-red-100 dark:border-red-900/30">
            <div className="w-12 h-12 bg-red-100 dark:bg-red-900/50 rounded-2xl flex items-center justify-center shrink-0 shadow-inner"><AlertTriangle className="text-red-600 dark:text-red-400" size={24} /></div>
            <div>
              <h5 className="text-xl font-black text-slate-800 dark:text-white">{t('Kritik Stok Uyarıları')}</h5>
              <p className="text-sm text-red-600 dark:text-red-400 font-bold">{t('Aşağıdaki')} {criticalAlerts.length} {t('ürün stok limitinin altında! (A-Z Sıralı)')}</p>
            </div>
            <button className="sm:ml-auto px-4 py-2 bg-white dark:bg-slate-800 border border-red-200 dark:border-red-800/50 text-red-600 dark:text-red-400 text-sm font-bold rounded-xl hover:bg-red-50 dark:hover:bg-slate-700 transition shadow-sm">{t('Tümünü İncele')}</button>
          </div>
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-left border-collapse min-w-[600px]">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 text-[10px] uppercase border-b border-slate-200 dark:border-slate-800 tracking-wider">
                  <th className="p-3 pl-6 font-bold w-1/4">{t('Kategori')}</th>
                  <th className="p-3 font-bold w-1/2">{t('Ürün Modeli')}</th>
                  <th className="p-3 font-bold text-center">{t('Stok')}</th>
                  <th className="p-3 font-bold text-center pr-6">{t('Durum')}</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {criticalAlerts.slice(0, 5).map((item, idx) => (
                  <tr key={item.product_id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                    <td className="p-3 pl-6"><span className="bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-md font-bold text-[10px] text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">{item.category}</span></td>
                    <td className="p-3 font-bold text-slate-800 dark:text-slate-100">{item.product_name}</td>
                    <td className="p-3 text-center"><span className={`inline-block min-w-[2rem] px-2 py-1 rounded-md font-bold text-xs text-white shadow-sm ${item.current_stock===0?'bg-red-500':'bg-amber-500'}`}>{item.current_stock}</span></td>
                    <td className="p-3 text-center pr-6">
                      {item.current_stock===0 ? <span className="inline-flex items-center text-red-600 dark:text-red-400 font-black text-xs bg-red-50 dark:bg-red-900/20 px-2 py-1 rounded-md"><XCircle size={14} className="mr-1.5"/> {t('TÜKENDİ')}</span> : <span className="inline-flex items-center text-amber-600 dark:text-amber-400 font-black text-xs bg-amber-50 dark:bg-amber-900/20 px-2 py-1 rounded-md"><AlertCircle size={14} className="mr-1.5"/> {t('KRİTİK')}</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showAlerts && criticalAlerts.length === 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-emerald-200 dark:border-emerald-900/50 shadow-sm overflow-hidden animate-in fade-in p-6 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-emerald-100 dark:bg-emerald-900/50 rounded-full mb-4">
            <Check className="text-emerald-600 dark:text-emerald-400" size={32} />
          </div>
          <h5 className="text-xl font-black text-slate-800 dark:text-white mb-2">{t('Kritik Stok Uyarısı Yok')}</h5>
          <p className="text-slate-500 dark:text-slate-400 font-medium">{t('Tüm ürünlerinizin stoğu yeterli seviyede.')}</p>
        </div>
      )}

      {showStock && (
        <div className="animate-in fade-in">
          <h6 className="text-slate-500 dark:text-slate-400 font-black tracking-widest uppercase mb-4 text-xs flex items-center gap-2 pl-2"><Box size={16} className="text-indigo-500"/> {t('STOK YÖNETİMİ & KATEGORİLER (A-Z)')}</h6>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-3 sm:gap-4">
            {stockGrid.map((item, idx) => (
              <button key={idx} onClick={() => setView(item.id)} className="bg-white dark:bg-slate-900 p-5 h-36 flex flex-col items-center justify-center text-center rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:-translate-y-1.5 hover:shadow-md hover:border-indigo-200 dark:hover:border-indigo-800 transition-all group">
                <div className={`w-14 h-14 ${item.bg} ${item.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-inner`}><item.icon size={26} strokeWidth={2.5} /></div>
                <span className="text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-300 leading-tight group-hover:text-indigo-700 dark:group-hover:text-indigo-400">{t(item.label)}</span>
              </button>
            ))}
          </div>
        </div>
      )}
      
      {showFinance && (
        <div className="animate-in fade-in">
          <h6 className="text-slate-500 dark:text-slate-400 font-black tracking-widest uppercase mb-4 text-xs flex items-center gap-2 pl-2"><Wallet size={16} className="text-emerald-500"/> {t('FİNANS, RAPOR & YÖNETİM (A-Z)')}</h6>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-3 sm:gap-4">
            {financeGrid.map((item, idx) => (
              <button key={idx} onClick={() => setView(item.id)} className="bg-white dark:bg-slate-900 p-5 h-36 flex flex-col items-center justify-center text-center rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:-translate-y-1.5 hover:shadow-md hover:border-indigo-200 dark:hover:border-indigo-800 transition-all group">
                <div className={`w-14 h-14 ${item.bg} ${item.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-inner`}><item.icon size={26} strokeWidth={2.5} /></div>
                <span className="text-xs sm:text-sm font-bold text-slate-700 dark:text-slate-300 leading-tight group-hover:text-indigo-700 dark:group-hover:text-indigo-400">{t(item.label)}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};


// --- ANA UYGULAMA YÖNLENDİRİCİSİ (APP ROUTER) ---
export default function App() {
  const [currentView, setCurrentView] = useState('landing');
  const [currentUser, setCurrentUser] = useState(null);
  const [isInitializing, setIsInitializing] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);

  // Dil ve Tema (Dark Mode) State Yönetimi (Sistem Hatırlatması İçin)
  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'light');
  const [lang, setLang] = useState(() => localStorage.getItem('lang') || 'tr');

  useEffect(() => {
    localStorage.setItem('theme', theme);
    // Sync dark class to <html> so browser-native UI (scrollbars, selects, etc.) uses the correct color-scheme
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('lang', lang);
  }, [lang]);

  // Otomatik Giriş (Auto-Login) Kontrolü
  useEffect(() => {
    const checkAuth = async () => {
      // E-posta doğrulama veya şifre sıfırlama linki tıklandıysa — auto-login'i atla, login sayfasına yönlendir
      const urlParams = new URLSearchParams(window.location.search);
      const urlAction = urlParams.get('action');
      const urlToken = urlParams.get('token');
      if (urlToken && (urlAction === 'verify' || urlAction === 'reset-password' || urlAction === 'confirm-email-change')) {
        setCurrentView('login');
        setIsInitializing(false);
        return;
      }
      // 'cancel-email-change' uyarı bağlantısı token taşımaz; yine de login akışını göstermeliyiz
      if (urlAction === 'cancel-email-change') {
        setCurrentView('login');
        setIsInitializing(false);
        return;
      }

      // Refresh token 403 (email_not_verified) nedeniyle yönlendirildiyse — login sayfasına git
      try {
        if (sessionStorage.getItem('email_verification_pending') !== null) {
          setCurrentView('login');
          setIsInitializing(false);
          return;
        }
      } catch {}


      const token = localStorage.getItem('access_token');
      if (token) {
        try {
          const response = await api.get('/auth/profile');
          const user = response.data;
          // Doğrulanmamış token ile auto-login olmasın
          if (user.is_email_verified === false) {
            localStorage.removeItem('access_token');
            setIsInitializing(false);
            return;
          }
          setCurrentUser({
            id: user.id,
            role: user.role === 'bayi_sahibi' ? 'bayi_sahibi' : 'calisan',
            name: user.full_name,
            email: user.email,
            permissions: Array.isArray(user.permissions) ? user.permissions : [],
            parent_user_id: user.parent_user_id ?? null,
            myRefCode: user.ref_code,
            subDays: user.sub_days,
            isSuperAdmin: !!user.is_super_admin,
          });
          if (user.is_super_admin) {
            setCurrentView('superAdmin');
          } else {
            const STATIC_VIEWS = new Set(['customerDashboard', 'profile', 'employees', 'subscription', 'fin_raporlar', 'fin_gecmis', 'warranty', 'kdv_hesap', 'support', 'web_settings', 'backup', 'devices', 'vehicles']);
            const savedView = sessionStorage.getItem('lastView');
            setCurrentView((savedView && STATIC_VIEWS.has(savedView)) ? savedView : 'customerDashboard');
          }
        } catch (error) {
          console.error("Auto-login failed:", error);
          localStorage.removeItem('access_token');
        }
      }
      setIsInitializing(false);
    };

    checkAuth();
  }, []);

  // Anlık veri güncellemesi: 2 saniyede bir backend'den ts kontrol eder,
  // değişiklik varsa tüm view'ları refreshBus üzerinden uyarır.
  useEffect(() => {
    if (!currentUser) return;
    let lastTs = 0;
    const id = setInterval(async () => {
      try {
        const res = await api.get('/events/latest', { _silent: true } as any);
        const ts: number = res.data?.ts ?? 0;
        if (ts > 0 && ts !== lastTs) {
          if (lastTs !== 0) refreshBus.emit();
          lastTs = ts;
        }
      } catch {
        // ağ hatası — sessizce devam et
      }
    }, 2000);
    return () => clearInterval(id);
  }, [currentUser]);

  const [toasts, setToasts] = useState([]);
  const showToast = (msg: any, type: 'success' | 'error' | 'warning' = 'success') => {
    let safeMsg: string;
    if (typeof msg === 'string') {
      safeMsg = msg;
    } else if (Array.isArray(msg)) {
      safeMsg = msg.map((e: any) => (typeof e === 'string' ? e : (e?.msg ?? JSON.stringify(e)))).join(', ');
    } else if (msg && typeof msg === 'object') {
      safeMsg = msg.message ?? msg.msg ?? msg.detail ?? JSON.stringify(msg);
    } else {
      safeMsg = String(msg ?? 'Bir hata oluştu');
    }
    const id = Date.now();
    setToasts(prev => [...prev, { id, msg: safeMsg, type }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 4000);
  };

  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');
  const toggleLang = () => {
    setLang(prev => {
      const next = prev === 'tr' ? 'en' : 'tr';
      localStorage.setItem('lang', next);
      window.dispatchEvent(new Event('langchange'));
      return next;
    });
  };
  const t = (text) => lang === 'tr' ? text : (EN_DICT[text] || text);

  // --- Dinamik kategoriler (Web Görünüm) — context'te paylaşılır ---
  const [categories, setCategories] = useState<any[]>([]);
  const [categoriesLoading, setCategoriesLoading] = useState(false);

  const refetchCategories = useCallback(async () => {
    if (!localStorage.getItem('access_token')) return;
    try {
      setCategoriesLoading(true);
      const res = await api.get('/categories');
      setCategories(res.data.items || []);
    } catch (e) {
      console.error('Kategoriler yüklenemedi:', e);
    } finally {
      setCategoriesLoading(false);
    }
  }, []);

  // Kullanıcı giriş yaptığında / değiştiğinde kategorileri yükle
  useEffect(() => {
    if (currentUser?.id) {
      refetchCategories();
    } else {
      setCategories([]);
    }
  }, [currentUser?.id, refetchCategories]);

  // İlk giriş yapan bayi sahibine onboarding göster
  useEffect(() => {
    if (!currentUser?.id || currentUser?.isSuperAdmin || currentUser?.role === 'calisan') return;
    if (!localStorage.getItem(ONBOARDING_KEY(currentUser.id))) {
      setShowOnboarding(true);
    }
  }, [currentUser?.id]);

  // Tümü eklenmiş Liste Modülleri — artık dinamik (kullanıcının kategorilerinden türer)
  // ÖNEMLİ: Bu hook erken return'den ÖNCE çağrılmalı (Rules of Hooks).
  const moduleMap = useMemo(() => buildModuleMap(categories), [categories]);

  // Subscription auto-sync: login sonrası /subscription/me'den canlı sub_days al
  // ÖNEMLİ: Hook'lar koşulsuz olmalı — erken return'den ÖNCE çağrılır
  useEffect(() => {
    if (!currentUser?.id || currentUser?.isSuperAdmin) return;
    let cancelled = false;
    (async () => {
      try {
        const r = await api.get('/subscription/me');
        if (cancelled) return;
        if (typeof r.data?.days_remaining === 'number') {
          setCurrentUser((prev: any) => prev ? { ...prev, subDays: r.data.days_remaining, packageSlug: r.data.package_slug, packageName: r.data.package?.name } : prev);
        }
      } catch (e) { /* ignore */ }
    })();
    return () => { cancelled = true; };
  }, [currentUser?.id, currentUser?.isSuperAdmin]);

  const refreshSubscription = useCallback(async () => {
    try {
      const r = await api.get('/subscription/me');
      if (typeof r.data?.days_remaining === 'number') {
        setCurrentUser((prev: any) => prev ? { ...prev, subDays: r.data.days_remaining, packageSlug: r.data.package_slug, packageName: r.data.package?.name } : prev);
      }
    } catch (e) { /* ignore */ }
  }, []);

  // Rules of Hooks: useCallback erken return'den ÖNCE çağrılmalı
  const navigateTo = useCallback((view: string) => {
    const AUTH_VIEWS = new Set(['landing', 'login', 'register']);
    if (!AUTH_VIEWS.has(view)) {
      try { sessionStorage.setItem('lastView', view); } catch {}
    }
    setCurrentView(view);
  }, []);

  if (isInitializing) {
    return <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 text-indigo-600 dark:text-indigo-400 font-bold">Yükleniyor...</div>;
  }

  const handleLogout = () => {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    try { sessionStorage.removeItem('lastView'); } catch {}
    setCurrentUser(null);
    setCurrentView('landing');
  };

  if (currentUser && (currentUser as any).role === 'btb_musteri') {
    return (
      <B2BCustomerView
        currentUser={currentUser}
        onLogout={handleLogout}
        showToast={showToast}
      />
    );
  }

  const renderView = () => {
    // Süper yönetici girişinde tüm normal modüller bypass edilir; sadece süper admin paneli görünür.
    if (currentUser?.isSuperAdmin) {
      return <SuperAdminPanel currentUser={currentUser} onLogout={handleLogout} showToast={showToast} />;
    }
    // Süresi dolmuş kullanıcı: sadece subscription view, başka view'e gitmesi engellenir
    // NOT: Çalışan (role==='calisan') paneli BLOKLAMAZ — abonelik patron'a aittir, çalışan ödeme yapamaz.
    // Backend zaten çalışan istekleri için patron'un abonelik durumuna göre 402 döner.
    if (currentUser && !currentUser.isSuperAdmin && currentUser.role !== 'calisan' && (currentUser.subDays ?? 0) <= 0) {
      return (
        <DashboardLayout activeMenu="subscription" setView={navigateTo} currentUser={currentUser}>
          <SubscriptionView currentUser={currentUser} expired={true} onPaymentSuccess={refreshSubscription} />
        </DashboardLayout>
      );
    }
    if (moduleMap[currentView]) {
      const mod = moduleMap[currentView];
      return <DashboardLayout activeMenu={currentView} setView={navigateTo} currentUser={currentUser}><GenericModuleView moduleId={currentView} title={mod.title} icon={mod.icon} type={mod.type} currentUser={currentUser} /></DashboardLayout>;
    }
    switch (currentView) {
      case 'landing': return <LandingPage setView={navigateTo} />;
      case 'login': return <AuthPage setView={navigateTo} isLogin={true} setCurrentUser={setCurrentUser} />;
      case 'register': return <AuthPage setView={navigateTo} isLogin={false} setCurrentUser={setCurrentUser} />;
      case 'customerDashboard': return <DashboardLayout activeMenu="customerDashboard" setView={navigateTo} currentUser={currentUser}><CustomerDashboard setView={navigateTo} currentUser={currentUser} /></DashboardLayout>;
      case 'profile': return <DashboardLayout activeMenu="profile" setView={navigateTo} currentUser={currentUser}><ProfileSettingsView /></DashboardLayout>;
      case 'employees': return <DashboardLayout activeMenu="employees" setView={navigateTo} currentUser={currentUser}><EmployeeManagementView /></DashboardLayout>;
      case 'subscription': return <DashboardLayout activeMenu="subscription" setView={navigateTo} currentUser={currentUser}><SubscriptionView currentUser={currentUser} onPaymentSuccess={refreshSubscription}/></DashboardLayout>;
      case 'fin_raporlar': return <DashboardLayout activeMenu="fin_raporlar" setView={navigateTo} currentUser={currentUser}><ReportsDashboardView /></DashboardLayout>;
      case 'fin_gecmis': return <DashboardLayout activeMenu="fin_gecmis" setView={navigateTo} currentUser={currentUser}><HistoryLogView /></DashboardLayout>;
      case 'warranty': return <DashboardLayout activeMenu="warranty" setView={navigateTo} currentUser={currentUser}><WarrantyManagementView showToast={showToast} /></DashboardLayout>;
      case 'kdv_hesap': return <DashboardLayout activeMenu="kdv_hesap" setView={navigateTo} currentUser={currentUser}><KdvCalculator /></DashboardLayout>;
      case 'support': return <DashboardLayout activeMenu="support" setView={navigateTo} currentUser={currentUser}><SupportView currentUser={currentUser} showToast={showToast} /></DashboardLayout>;
      case 'web_settings': return <DashboardLayout activeMenu="web_settings" setView={navigateTo} currentUser={currentUser}><WebSettingsView currentUserId={currentUser?.id} onReplayOnboarding={() => { if (currentUser) { localStorage.removeItem(ONBOARDING_KEY(currentUser.id)); setShowOnboarding(true); } }} /></DashboardLayout>;
      case 'backup': return <DashboardLayout activeMenu="backup" setView={navigateTo} currentUser={currentUser}><BackupView /></DashboardLayout>;
      case 'devices': return <DashboardLayout activeMenu="devices" setView={navigateTo} currentUser={currentUser}><DevicesView showToast={showToast} currentUser={currentUser} /></DashboardLayout>;
      case 'vehicles': return <DashboardLayout activeMenu="vehicles" setView={navigateTo} currentUser={currentUser}><VehicleView showToast={showToast} currentUser={currentUser} /></DashboardLayout>;
      case 'btb': return <DashboardLayout activeMenu="btb" setView={navigateTo} currentUser={currentUser}><BTBView currentUser={currentUser} showToast={showToast} navigateTo={navigateTo} /></DashboardLayout>;
      case 'supplier_orders': return <DashboardLayout activeMenu="supplier_orders" setView={navigateTo} currentUser={currentUser}><SupplierOrderView currentUser={currentUser} showToast={showToast} /></DashboardLayout>;
      case 'supplier': return <DashboardLayout activeMenu="supplier" setView={navigateTo} currentUser={currentUser}><SupplierView currentUser={currentUser} showToast={showToast} /></DashboardLayout>;
      case 'plasiyer': return <DashboardLayout activeMenu="plasiyer" setView={navigateTo} currentUser={currentUser}><PlasiyerView currentUser={currentUser} showToast={showToast} /></DashboardLayout>;
      case 'integrations': return <DashboardLayout activeMenu="integrations" setView={navigateTo} currentUser={currentUser}><IntegrationsView showToast={showToast} /></DashboardLayout>;
      default: return currentUser
        ? <DashboardLayout activeMenu="customerDashboard" setView={navigateTo} currentUser={currentUser}><CustomerDashboard setView={navigateTo} currentUser={currentUser} /></DashboardLayout>
        : <LandingPage setView={navigateTo} />;
    }
  };

  return (
    <AppContext.Provider value={{ theme, toggleTheme, lang, toggleLang, t, showToast, categories, categoriesLoading, refetchCategories }}>
      <div className={`min-h-screen font-sans selection:bg-indigo-100 selection:text-indigo-900 ${theme === 'dark' ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'}`}>
        <GlobalLoadingBar />
        {renderView()}
        {showOnboarding && currentUser && (
          <OnboardingWizard
            currentUser={currentUser}
            onComplete={() => {
              localStorage.setItem(ONBOARDING_KEY(currentUser.id), '1');
              setShowOnboarding(false);
            }}
          />
        )}
        <ToastContainer toasts={toasts} />
      </div>
    </AppContext.Provider>
  );
}