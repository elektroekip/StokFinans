// ============================================================
// Auth Context - Kimlik Doğrulama Durumu Yönetimi
// ============================================================
// React Context API ile user state ve token yönetimi
//
// Seviye: SEVIYE 6 - Köprü Kurma
// Tarih: 28 Nisan 2026
// ============================================================

import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import api, { authApi } from "../lib/api";

// ============================================================
// Type Definitions
// ============================================================

interface User {
  id: number;
  email: string;
  full_name: string;
  role: string;
  ref_code?: string;
  sub_days: number;
  is_email_verified?: boolean;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (data: any) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: (silent?: boolean) => Promise<void>;
}

// ============================================================
// Context Oluştur
// ============================================================

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// ============================================================
// Auth Provider Component
// ============================================================

/**
 * AuthProvider: App'ı sarmalayan provider
 *
 * localStorage'da user varsa, otomatik olarak yükle
 * useAuth hook'u ile her yerde user state'e erişilebilir
 */
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // ============================================================
  // Startup: localStorage'dan user yükle
  // ============================================================

  useEffect(() => {
    const loadUserFromStorage = async () => {
      try {
        const storedUser = localStorage.getItem("user");
        const accessToken = localStorage.getItem("access_token");

        if (storedUser && accessToken) {
          // localStorage'dan user parse et
          const parsedUser = JSON.parse(storedUser);
          setUser(parsedUser);
        }
      } catch (error) {
        console.error("localStorage'dan user yükleme hatası:", error);
        localStorage.removeItem("user");
        localStorage.removeItem("access_token");
        localStorage.removeItem("refresh_token");
      } finally {
        setIsLoading(false);
      }
    };

    loadUserFromStorage();
  }, []);

  // ============================================================
  // Login
  // ============================================================

  const login = async (email: string, password: string) => {
    try {
      setIsLoading(true);
      const response = await authApi.login(email, password);

      const {
        access_token,
        refresh_token,
        user: userData,
      } = response.data;

      // Token'ları localStorage'a kaydet
      localStorage.setItem("access_token", access_token);
      localStorage.setItem("refresh_token", refresh_token);
      localStorage.setItem("user", JSON.stringify(userData));

      // State güncelle
      setUser(userData);
    } finally {
      setIsLoading(false);
    }
  };

  // ============================================================
  // Register
  // ============================================================

  const register = async (data: any) => {
    try {
      setIsLoading(true);
      const response = await authApi.register(data);

      const {
        access_token,
        refresh_token,
        user: userData,
      } = response.data;

      // Token'ları localStorage'a kaydet
      localStorage.setItem("access_token", access_token);
      localStorage.setItem("refresh_token", refresh_token);
      localStorage.setItem("user", JSON.stringify(userData));

      // State güncelle
      setUser(userData);
    } finally {
      setIsLoading(false);
    }
  };

  // ============================================================
  // Logout
  // ============================================================

  const logout = async () => {
    try {
      await authApi.logout();
      setUser(null);
    } catch (error) {
      console.error("Logout hatası:", error);
    }
  };

  // ============================================================
  // Refresh User (Profile'ı güncelle)
  // ============================================================

  const refreshUser = useCallback(async (silent = false) => {
    try {
      const response = silent
        ? await api.get('/auth/profile', { _silent: true } as any)
        : await authApi.getProfile();
      const userData = response.data;

      // localStorage güncelle
      localStorage.setItem("user", JSON.stringify(userData));

      // State güncelle
      setUser(userData);
    } catch (error) {
      // Geçici ağ hatalarında oturumu kapatma; 401 gibi gerçek
      // kimlik doğrulama hataları zaten global response interceptor
      // tarafından ele alınıyor (token temizleniyor ve sayfa yenileniyor).
      console.error("User refresh hatası:", error);
    }
  }, []);

  // ============================================================
  // Context Value
  // ============================================================

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    register,
    logout,
    refreshUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// ============================================================
// useAuth Hook
// ============================================================

/**
 * useAuth: Herhangi bir component'te auth state'e erişmek için
 *
 * const { user, login, logout, isAuthenticated } = useAuth();
 */
export const useAuth = () => {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error("useAuth, AuthProvider içinde kullanılmalı");
  }

  return context;
};

export default AuthContext;
