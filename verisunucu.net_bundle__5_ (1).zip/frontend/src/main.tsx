import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import { PublicWarrantyPage, PublicDebtorPage } from './PhaseThreeViews'

// Faz 3: Public path yakalama — App / login akışından ÖNCE.
// /garanti/<token> ve /borc/<token> giriş gerektirmez, doğrudan public sayfa render edilir.
function Root() {
  const path = typeof window !== 'undefined' ? window.location.pathname : '';
  const wm = path.match(/^\/garanti\/([A-Za-z0-9_-]+)\/?$/);
  if (wm) return <PublicWarrantyPage token={wm[1]} />;
  const dm = path.match(/^\/borc\/([A-Za-z0-9_-]+)\/?$/);
  if (dm) return <PublicDebtorPage token={dm[1]} />;
  return <App />;
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Root />
  </StrictMode>,
)
