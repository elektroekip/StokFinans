import { useState, useEffect, useCallback } from 'react';
import { useRefreshOnChange } from './hooks/useRefreshOnChange';
import { api } from './lib/api';
import {
  MapPin, Clock, CheckCircle2, XCircle, Phone, Calendar, Plus, Navigation,
  UserCheck, AlertCircle, TrendingUp, List, ClipboardList
} from 'lucide-react';

// ── Types ──────────────────────────────────────────────────────
interface PlasiyerStats {
  total_visits_today: number;
  total_visits_this_month: number;
  planned_today: number;
  done_today: number;
  orders_taken_this_month: number;
}
interface Visit {
  id: number;
  user_id: number;
  btb_customer_id: number | null;
  customer_name: string;
  latitude: number | null;
  longitude: number | null;
  address_label: string | null;
  check_in_at: string;
  check_out_at: string | null;
  duration_minutes: number | null;
  notes: string | null;
  result: string;
  btb_order_id: number | null;
}
interface VisitPlan {
  id: number;
  user_id: number;
  btb_customer_id: number | null;
  customer_name: string;
  planned_date: string;
  planned_order: number;
  notes: string | null;
  status: string;
}
interface BtbCustomer { id: number; company_name: string; phone: string | null; }

// ── Helpers ────────────────────────────────────────────────────
const RESULT_CONFIG: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  visited:     { label: 'Ziyaret Edildi', color: 'bg-emerald-100 text-emerald-700', icon: <CheckCircle2 size={12} /> },
  no_answer:   { label: 'Cevap Yok',     color: 'bg-gray-100 text-gray-600',       icon: <XCircle size={12} /> },
  postponed:   { label: 'Ertelendi',     color: 'bg-amber-100 text-amber-700',     icon: <Clock size={12} /> },
  order_taken: { label: 'Sipariş Alındı',color: 'bg-blue-100 text-blue-700',       icon: <TrendingUp size={12} /> },
};
const PLAN_STATUS_CONFIG: Record<string, { label: string; color: string }> = {
  planned: { label: 'Planlandı', color: 'bg-slate-100 text-slate-600' },
  done:    { label: 'Tamamlandı',color: 'bg-emerald-100 text-emerald-700' },
  skipped: { label: 'Atlandı',   color: 'bg-red-100 text-red-600' },
};

function fmtTime(iso: string | null) {
  if (!iso) return '—';
  return new Date(iso).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
}
function fmtDate(iso: string | null) {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('tr-TR');
}
function todayStr() {
  return new Date().toISOString().split('T')[0];
}

// ── Check-in Modal ─────────────────────────────────────────────
function CheckInModal({
  customers, onSave, onClose,
}: {
  customers: BtbCustomer[];
  onSave: (data: any) => Promise<void>;
  onClose: () => void;
}) {
  const [form, setForm] = useState({
    btb_customer_id: '' as string | number,
    customer_name: '',
    latitude: '' as string | number,
    longitude: '' as string | number,
    address_label: '',
    notes: '',
    result: 'visited',
  });
  const [locating, setLocating] = useState(false);

  const locateMe = () => {
    setLocating(true);
    navigator.geolocation?.getCurrentPosition(
      (pos) => {
        setForm(f => ({
          ...f,
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          address_label: `${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)}`,
        }));
        setLocating(false);
      },
      () => setLocating(false),
      { timeout: 10000 }
    );
  };

  const handleCust = (id: string) => {
    const c = customers.find(c => String(c.id) === id);
    setForm(f => ({ ...f, btb_customer_id: id ? Number(id) : '', customer_name: c?.company_name || '' }));
  };

  const handleSubmit = async () => {
    if (!form.customer_name.trim()) return;
    await onSave({
      btb_customer_id: form.btb_customer_id || null,
      customer_name: form.customer_name,
      latitude: form.latitude ? Number(form.latitude) : null,
      longitude: form.longitude ? Number(form.longitude) : null,
      address_label: form.address_label || null,
      notes: form.notes || null,
      result: form.result,
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-5 border-b">
          <h2 className="font-semibold text-lg flex items-center gap-2"><MapPin size={18} className="text-blue-500" />Ziyaret Kaydı</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl">×</button>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-700">Müşteri Seç</label>
            <select value={String(form.btb_customer_id)} onChange={e => handleCust(e.target.value)}
              className="mt-1 w-full border rounded-lg px-3 py-2 text-sm">
              <option value="">-- BTB Müşterisi Seç --</option>
              {customers.map(c => <option key={c.id} value={c.id}>{c.company_name}</option>)}
            </select>
          </div>
          {!form.btb_customer_id && (
            <div>
              <label className="text-sm font-medium text-gray-700">Veya Müşteri Adı Yaz</label>
              <input value={form.customer_name} onChange={e => setForm(f => ({ ...f, customer_name: e.target.value }))}
                placeholder="Firma / şahıs adı" className="mt-1 w-full border rounded-lg px-3 py-2 text-sm" />
            </div>
          )}
          <div>
            <label className="text-sm font-medium text-gray-700">Konum</label>
            <div className="flex gap-2 mt-1">
              <input value={String(form.address_label)} onChange={e => setForm(f => ({ ...f, address_label: e.target.value }))}
                placeholder="Adres / konum bilgisi" className="flex-1 border rounded-lg px-3 py-2 text-sm" />
              <button onClick={locateMe} disabled={locating}
                className="flex items-center gap-1 px-3 py-2 bg-blue-50 text-blue-600 rounded-lg text-sm hover:bg-blue-100 disabled:opacity-50">
                <Navigation size={14} />{locating ? '...' : 'GPS'}
              </button>
            </div>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">Sonuç</label>
            <select value={form.result} onChange={e => setForm(f => ({ ...f, result: e.target.value }))}
              className="mt-1 w-full border rounded-lg px-3 py-2 text-sm">
              {Object.entries(RESULT_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">Notlar</label>
            <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
              rows={2} className="mt-1 w-full border rounded-lg px-3 py-2 text-sm" />
          </div>
        </div>
        <div className="flex gap-3 p-5 border-t">
          <button onClick={onClose} className="flex-1 py-2 border rounded-lg text-sm text-gray-600 hover:bg-gray-50">İptal</button>
          <button onClick={handleSubmit} className="flex-1 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">
            Check-in Yap
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Plan Modal ─────────────────────────────────────────────────
function PlanModal({
  customers, onSave, onClose,
}: {
  customers: BtbCustomer[];
  onSave: (data: any) => Promise<void>;
  onClose: () => void;
}) {
  const [form, setForm] = useState({
    btb_customer_id: '' as string | number,
    customer_name: '',
    planned_date: todayStr(),
    planned_order: 1,
    notes: '',
  });

  const handleCust = (id: string) => {
    const c = customers.find(c => String(c.id) === id);
    setForm(f => ({ ...f, btb_customer_id: id ? Number(id) : '', customer_name: c?.company_name || '' }));
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-5 border-b">
          <h2 className="font-semibold text-lg flex items-center gap-2"><ClipboardList size={18} className="text-purple-500" />Ziyaret Planı Ekle</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl">×</button>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-700">Müşteri</label>
            <select value={String(form.btb_customer_id)} onChange={e => handleCust(e.target.value)}
              className="mt-1 w-full border rounded-lg px-3 py-2 text-sm">
              <option value="">-- Müşteri Seç --</option>
              {customers.map(c => <option key={c.id} value={c.id}>{c.company_name}</option>)}
            </select>
          </div>
          {!form.btb_customer_id && (
            <div>
              <label className="text-sm font-medium text-gray-700">Veya Adı Yaz</label>
              <input value={form.customer_name} onChange={e => setForm(f => ({ ...f, customer_name: e.target.value }))}
                className="mt-1 w-full border rounded-lg px-3 py-2 text-sm" />
            </div>
          )}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-medium text-gray-700">Tarih</label>
              <input type="date" value={form.planned_date} onChange={e => setForm(f => ({ ...f, planned_date: e.target.value }))}
                className="mt-1 w-full border rounded-lg px-3 py-2 text-sm" />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700">Sıra</label>
              <input type="number" min={1} value={form.planned_order} onChange={e => setForm(f => ({ ...f, planned_order: Number(e.target.value) }))}
                className="mt-1 w-full border rounded-lg px-3 py-2 text-sm" />
            </div>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700">Not</label>
            <input value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
              className="mt-1 w-full border rounded-lg px-3 py-2 text-sm" />
          </div>
        </div>
        <div className="flex gap-3 p-5 border-t">
          <button onClick={onClose} className="flex-1 py-2 border rounded-lg text-sm text-gray-600 hover:bg-gray-50">İptal</button>
          <button onClick={() => onSave({
            btb_customer_id: form.btb_customer_id || null,
            customer_name: form.customer_name,
            planned_date: form.planned_date,
            planned_order: form.planned_order,
            notes: form.notes || null,
          })} className="flex-1 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700">
            Ekle
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main ───────────────────────────────────────────────────────
export default function PlasiyerView({
  currentUser, showToast,
}: {
  currentUser: any;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}) {
  const [tab, setTab] = useState<'visits' | 'plans'>('visits');
  const [stats, setStats] = useState<PlasiyerStats | null>(null);
  const [visits, setVisits] = useState<Visit[]>([]);
  const [plans, setPlans] = useState<VisitPlan[]>([]);
  const [customers, setCustomers] = useState<BtbCustomer[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCheckIn, setShowCheckIn] = useState(false);
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [dateFilter, setDateFilter] = useState(todayStr());
  const [activeVisitId, setActiveVisitId] = useState<number | null>(null);

  const fetchAll = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const [sRes, vRes, pRes, cRes] = await Promise.all([
        api.get('/plasiyer/stats'),
        api.get('/plasiyer/visits', { params: { date: dateFilter, limit: 100 } }),
        api.get('/plasiyer/plans', { params: { date: dateFilter } }),
        api.get('/btb/customers', { params: { active_only: true, limit: 200 } }),
      ]);
      setStats(sRes.data);
      setVisits(vRes.data);
      setPlans(pRes.data);
      setCustomers(cRes.data);
      const open = vRes.data.find((v: Visit) => !v.check_out_at);
      setActiveVisitId(open?.id ?? null);
    } catch {
      showToast('Veriler yüklenemedi', 'error');
    } finally {
      setLoading(false);
    }
  }, [dateFilter]);

  useEffect(() => { fetchAll(); }, [fetchAll]);
  useRefreshOnChange(fetchAll);

  const handleCheckIn = async (data: any) => {
    try {
      await api.post('/plasiyer/visits', data);
      setShowCheckIn(false);
      showToast('Check-in yapıldı', 'success');
      fetchAll();
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Hata', 'error');
    }
  };

  const handleCheckOut = async (visitId: number) => {
    try {
      await api.post(`/plasiyer/visits/${visitId}/checkout`, { result: 'visited' });
      showToast('Check-out yapıldı', 'success');
      fetchAll();
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Hata', 'error');
    }
  };

  const handlePlanSave = async (data: any) => {
    try {
      await api.post('/plasiyer/plans', data);
      setShowPlanModal(false);
      showToast('Plan eklendi', 'success');
      fetchAll();
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Hata', 'error');
    }
  };

  const handlePlanStatus = async (plan: VisitPlan, status: string) => {
    try {
      await api.put(`/plasiyer/plans/${plan.id}`, { status });
      showToast('Plan güncellendi', 'success');
      fetchAll();
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Hata', 'error');
    }
  };

  const handleDeletePlan = async (planId: number) => {
    try {
      await api.delete(`/plasiyer/plans/${planId}`);
      showToast('Plan silindi', 'success');
      fetchAll();
    } catch (e: any) {
      showToast(e.response?.data?.detail || 'Hata', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {[
          { label: 'Bugünkü Ziyaret', val: stats?.total_visits_today ?? 0, icon: <MapPin size={20} className="text-blue-500" /> },
          { label: 'Bu Ay Ziyaret', val: stats?.total_visits_this_month ?? 0, icon: <TrendingUp size={20} className="text-indigo-500" /> },
          { label: 'Bugün Planlı', val: stats?.planned_today ?? 0, icon: <ClipboardList size={20} className="text-purple-500" /> },
          { label: 'Bugün Tamamlandı', val: stats?.done_today ?? 0, icon: <CheckCircle2 size={20} className="text-emerald-500" /> },
          { label: 'Bu Ay Sipariş', val: stats?.orders_taken_this_month ?? 0, icon: <UserCheck size={20} className="text-orange-500" /> },
        ].map((s, i) => (
          <div key={i} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-2">{s.icon}<span className="text-xl font-bold">{s.val}</span></div>
            <p className="text-xs text-gray-500">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Active visit banner */}
      {activeVisitId && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse" />
            <span className="text-blue-800 font-medium">Aktif ziyaret devam ediyor</span>
          </div>
          <button onClick={() => handleCheckOut(activeVisitId)}
            className="w-full sm:w-auto px-4 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">
            Check-out Yap
          </button>
        </div>
      )}

      {/* Controls */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-3 sm:p-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex gap-1 bg-gray-100 rounded-lg p-1">
            <button onClick={() => setTab('visits')}
              className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${tab === 'visits' ? 'bg-white shadow text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}>
              <List size={14} className="inline mr-1" />Ziyaretler
            </button>
            <button onClick={() => setTab('plans')}
              className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${tab === 'plans' ? 'bg-white shadow text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}>
              <ClipboardList size={14} className="inline mr-1" />Planlar
            </button>
          </div>
          <div className="flex items-center gap-2">
            <input type="date" value={dateFilter} onChange={e => setDateFilter(e.target.value)}
              className="flex-1 sm:flex-none border rounded-lg px-3 py-2 text-sm" />
            {tab === 'visits' ? (
              <button onClick={() => setShowCheckIn(true)} disabled={!!activeVisitId}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50 whitespace-nowrap">
                <Plus size={16} />Check-in
              </button>
            ) : (
              <button onClick={() => setShowPlanModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700 whitespace-nowrap">
                <Plus size={16} />Plan Ekle
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Content */}
      {tab === 'visits' && (
        <div className="space-y-3">
          {loading && <div className="text-center py-8 text-gray-400">Yükleniyor…</div>}
          {!loading && visits.length === 0 && (
            <div className="text-center py-16 text-gray-400">
              <MapPin size={40} className="mx-auto mb-3 opacity-30" />
              <p>Seçilen tarihte ziyaret yok</p>
            </div>
          )}
          {visits.map(v => {
            const rc = RESULT_CONFIG[v.result] || RESULT_CONFIG['visited'];
            return (
              <div key={v.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-gray-900">{v.customer_name}</span>
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${rc.color}`}>
                        {rc.icon}{rc.label}
                      </span>
                    </div>
                    {v.address_label && (
                      <div className="flex items-center gap-1 text-xs text-gray-500 mb-1">
                        <MapPin size={11} />{v.address_label}
                      </div>
                    )}
                    <div className="flex items-center gap-3 text-xs text-gray-500">
                      <span className="flex items-center gap-1"><Clock size={11} />Giriş: {fmtTime(v.check_in_at)}</span>
                      {v.check_out_at && <span>Çıkış: {fmtTime(v.check_out_at)}</span>}
                      {v.duration_minutes != null && <span>({v.duration_minutes} dk)</span>}
                    </div>
                    {v.notes && <p className="text-xs text-gray-500 mt-1 italic">{v.notes}</p>}
                  </div>
                  {!v.check_out_at && (
                    <button onClick={() => handleCheckOut(v.id)}
                      className="px-3 py-1 bg-blue-50 text-blue-600 rounded-lg text-xs font-medium hover:bg-blue-100">
                      Check-out
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {tab === 'plans' && (
        <div className="space-y-3">
          {loading && <div className="text-center py-8 text-gray-400">Yükleniyor…</div>}
          {!loading && plans.length === 0 && (
            <div className="text-center py-16 text-gray-400">
              <Calendar size={40} className="mx-auto mb-3 opacity-30" />
              <p>Seçilen tarihte plan yok</p>
            </div>
          )}
          {plans.sort((a, b) => a.planned_order - b.planned_order).map(p => {
            const sc = PLAN_STATUS_CONFIG[p.status] || PLAN_STATUS_CONFIG['planned'];
            return (
              <div key={p.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 flex-shrink-0 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center text-sm font-bold">
                      {p.planned_order}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900">{p.customer_name}</p>
                      {p.notes && <p className="text-xs text-gray-500">{p.notes}</p>}
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium whitespace-nowrap ${sc.color}`}>{sc.label}</span>
                  </div>
                  {p.status === 'planned' && (
                    <div className="flex items-center gap-2 sm:flex-shrink-0">
                      <button onClick={() => handlePlanStatus(p, 'done')}
                        className="flex-1 sm:flex-none px-2 py-1.5 bg-emerald-50 text-emerald-600 rounded-lg text-xs hover:bg-emerald-100">Tamamlandı</button>
                      <button onClick={() => handlePlanStatus(p, 'skipped')}
                        className="flex-1 sm:flex-none px-2 py-1.5 bg-red-50 text-red-600 rounded-lg text-xs hover:bg-red-100">Atlandı</button>
                      <button onClick={() => handleDeletePlan(p.id)}
                        className="flex-1 sm:flex-none px-2 py-1.5 bg-gray-50 text-gray-500 rounded-lg text-xs hover:bg-gray-100">Sil</button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showCheckIn && (
        <CheckInModal customers={customers} onSave={handleCheckIn} onClose={() => setShowCheckIn(false)} />
      )}
      {showPlanModal && (
        <PlanModal customers={customers} onSave={handlePlanSave} onClose={() => setShowPlanModal(false)} />
      )}
    </div>
  );
}
