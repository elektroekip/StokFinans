import React, { useState, useCallback } from 'react';
import { Calculator, Copy, Check, Plus, Trash2, RefreshCw, ChevronDown, ArrowLeftRight } from 'lucide-react';

// ── Constants ─────────────────────────────────────────────────────────────────

const KDV_PRESETS = [
  { label: '%0',  value: 0 },
  { label: '%1',  value: 1 },
  { label: '%8',  value: 8 },
  { label: '%10', value: 10 },
  { label: '%18', value: 18 },
  { label: '%20', value: 20 },
];

type Direction = 'from_gross' | 'from_net';

interface TableRow {
  id: number;
  description: string;
  amount: string;
  rate: number;
  direction: Direction;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function fmt(n: number): string {
  return n.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function calcBreakdown(amount: number, rate: number, direction: Direction) {
  if (direction === 'from_gross') {
    const net = amount / (1 + rate / 100);
    const kdv = amount - net;
    return { net, kdv, gross: amount };
  } else {
    const kdv = amount * (rate / 100);
    const gross = amount + kdv;
    return { net: amount, kdv, gross };
  }
}

// ── Copy button ───────────────────────────────────────────────────────────────

const CopyBtn: React.FC<{ text: string }> = ({ text }) => {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(text).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  return (
    <button onClick={copy} className="ml-1 p-1 rounded text-slate-400 hover:text-indigo-500 transition-colors" title="Kopyala">
      {copied ? <Check size={13} className="text-green-500" /> : <Copy size={13} />}
    </button>
  );
};

// ── Single calculator ─────────────────────────────────────────────────────────

const SingleCalc: React.FC = () => {
  const [amountStr, setAmountStr] = useState('');
  const [rate, setRate] = useState(18);
  const [customRate, setCustomRate] = useState('');
  const [isCustom, setIsCustom] = useState(false);
  const [direction, setDirection] = useState<Direction>('from_gross');

  const effectiveRate = isCustom ? (parseFloat(customRate) || 0) : rate;
  const amount = parseFloat(amountStr.replace(',', '.')) || 0;
  const { net, kdv, gross } = calcBreakdown(amount, effectiveRate, direction);

  const selectRate = (v: number) => { setRate(v); setIsCustom(false); };

  const reset = () => { setAmountStr(''); setRate(18); setCustomRate(''); setIsCustom(false); };

  const hasValue = amount > 0;

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-indigo-500 px-6 py-4 flex items-center gap-3">
        <Calculator size={22} className="text-white" />
        <h2 className="text-white font-bold text-lg">KDV Hesaplayıcı</h2>
      </div>

      <div className="p-6 space-y-5">
        {/* Direction toggle */}
        <div className="flex items-center gap-2">
          <span className="text-sm text-slate-500 dark:text-slate-400 shrink-0">Hesaplama yönü:</span>
          <div className="flex gap-1 bg-slate-100 dark:bg-slate-700/60 rounded-lg p-1">
            <button
              onClick={() => setDirection('from_gross')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${direction === 'from_gross' ? 'bg-white dark:bg-slate-600 text-indigo-600 dark:text-indigo-300 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300'}`}
            >
              KDV Dahil → Hariç
            </button>
            <button
              onClick={() => setDirection('from_net')}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${direction === 'from_net' ? 'bg-white dark:bg-slate-600 text-indigo-600 dark:text-indigo-300 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300'}`}
            >
              KDV Hariç → Dahil
            </button>
          </div>
        </div>

        {/* Amount input */}
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">
            {direction === 'from_gross' ? 'KDV Dahil Tutar (₺)' : 'KDV Hariç Tutar (₺)'}
          </label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold">₺</span>
            <input
              type="number"
              min="0"
              step="0.01"
              value={amountStr}
              onChange={e => setAmountStr(e.target.value)}
              placeholder="0,00"
              className="w-full pl-8 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-700 text-slate-800 dark:text-white text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-400 placeholder:text-slate-300 dark:placeholder:text-slate-500"
            />
          </div>
        </div>

        {/* KDV rate */}
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">KDV Oranı</label>
          <div className="flex flex-wrap gap-2">
            {KDV_PRESETS.map(p => (
              <button
                key={p.value}
                onClick={() => selectRate(p.value)}
                className={`px-4 py-2 rounded-xl text-sm font-bold border-2 transition-all ${
                  !isCustom && rate === p.value
                    ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 shadow-sm'
                    : 'border-slate-200 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:border-indigo-300 dark:hover:border-indigo-600'
                }`}
              >
                {p.label}
              </button>
            ))}
            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsCustom(true)}
                className={`px-4 py-2 rounded-xl text-sm font-bold border-2 transition-all ${
                  isCustom
                    ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 shadow-sm'
                    : 'border-slate-200 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:border-indigo-300'
                }`}
              >
                Özel
              </button>
              {isCustom && (
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={customRate}
                  onChange={e => setCustomRate(e.target.value)}
                  placeholder="%"
                  autoFocus
                  className="w-20 px-3 py-2 rounded-xl border-2 border-indigo-400 bg-slate-50 dark:bg-slate-700 text-slate-800 dark:text-white text-sm font-bold focus:outline-none focus:ring-2 focus:ring-indigo-400"
                />
              )}
            </div>
          </div>
        </div>

        {/* Divider */}
        {hasValue && <div className="border-t border-slate-100 dark:border-slate-700" />}

        {/* Results */}
        {hasValue ? (
          <div className="space-y-3">
            <div className="grid grid-cols-3 gap-3">
              {/* Net */}
              <div className="bg-slate-50 dark:bg-slate-700/50 rounded-xl p-4 border border-slate-200 dark:border-slate-600">
                <p className="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">KDV Hariç</p>
                <div className="flex items-center justify-between">
                  <p className="text-xl font-black text-slate-800 dark:text-white">{fmt(net)}<span className="text-sm ml-1 text-slate-400">₺</span></p>
                  <CopyBtn text={fmt(net)} />
                </div>
              </div>

              {/* KDV */}
              <div className="bg-orange-50 dark:bg-orange-950/20 rounded-xl p-4 border border-orange-200 dark:border-orange-800/50">
                <p className="text-xs font-semibold text-orange-400 dark:text-orange-500 uppercase tracking-wider mb-1">KDV (%{effectiveRate})</p>
                <div className="flex items-center justify-between">
                  <p className="text-xl font-black text-orange-600 dark:text-orange-400">{fmt(kdv)}<span className="text-sm ml-1 text-orange-400">₺</span></p>
                  <CopyBtn text={fmt(kdv)} />
                </div>
              </div>

              {/* Gross */}
              <div className="bg-indigo-50 dark:bg-indigo-950/30 rounded-xl p-4 border border-indigo-200 dark:border-indigo-700/50">
                <p className="text-xs font-semibold text-indigo-400 dark:text-indigo-500 uppercase tracking-wider mb-1">KDV Dahil</p>
                <div className="flex items-center justify-between">
                  <p className="text-xl font-black text-indigo-700 dark:text-indigo-300">{fmt(gross)}<span className="text-sm ml-1 text-indigo-400">₺</span></p>
                  <CopyBtn text={fmt(gross)} />
                </div>
              </div>
            </div>

            {/* Formula pill */}
            <div className="flex items-center justify-center gap-2 text-xs text-slate-400 dark:text-slate-500 bg-slate-50 dark:bg-slate-700/30 rounded-lg py-2 px-4">
              <span className="font-medium text-slate-600 dark:text-slate-300">{fmt(net)} ₺</span>
              <span>+</span>
              <span className="font-medium text-orange-500">{fmt(kdv)} ₺ KDV</span>
              <span>=</span>
              <span className="font-medium text-indigo-600 dark:text-indigo-400">{fmt(gross)} ₺</span>
            </div>
          </div>
        ) : (
          <div className="text-center py-6 text-slate-300 dark:text-slate-600">
            <Calculator size={36} className="mx-auto mb-2 opacity-50" />
            <p className="text-sm">Tutar girin, KDV breakdown otomatik hesaplanır</p>
          </div>
        )}

        {/* Reset */}
        {hasValue && (
          <div className="flex justify-end">
            <button onClick={reset} className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors px-3 py-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700">
              <RefreshCw size={13} /> Temizle
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// ── Multi-row table calculator ─────────────────────────────────────────────────

let rowId = 1;
function newRow(): TableRow {
  return { id: rowId++, description: '', amount: '', rate: 18, direction: 'from_gross' };
}

const TableCalc: React.FC = () => {
  const [rows, setRows] = useState<TableRow[]>([newRow()]);

  const updateRow = (id: number, patch: Partial<TableRow>) =>
    setRows(rs => rs.map(r => r.id === id ? { ...r, ...patch } : r));

  const addRow = () => setRows(rs => [...rs, newRow()]);
  const removeRow = (id: number) => setRows(rs => rs.length > 1 ? rs.filter(r => r.id !== id) : rs);

  const totals = rows.reduce(
    (acc, row) => {
      const amt = parseFloat(row.amount.replace(',', '.')) || 0;
      if (amt <= 0) return acc;
      const { net, kdv, gross } = calcBreakdown(amt, row.rate, row.direction);
      return { net: acc.net + net, kdv: acc.kdv + kdv, gross: acc.gross + gross };
    },
    { net: 0, kdv: 0, gross: 0 }
  );

  const hasAny = rows.some(r => (parseFloat(r.amount.replace(',', '.')) || 0) > 0);

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
      <div className="bg-gradient-to-r from-emerald-600 to-teal-500 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Calculator size={20} className="text-white" />
          <h2 className="text-white font-bold text-lg">Çoklu Kalem Hesaplayıcı</h2>
        </div>
        <button
          onClick={addRow}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-white/20 hover:bg-white/30 text-white rounded-lg text-sm font-semibold transition-colors"
        >
          <Plus size={14} /> Satır Ekle
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wide">
              <th className="text-left px-4 py-3 font-semibold">Açıklama</th>
              <th className="text-left px-4 py-3 font-semibold">Tutar (₺)</th>
              <th className="text-left px-4 py-3 font-semibold">Yön</th>
              <th className="text-left px-4 py-3 font-semibold">KDV %</th>
              <th className="text-right px-4 py-3 font-semibold">KDV Hariç</th>
              <th className="text-right px-4 py-3 font-semibold text-orange-500">KDV</th>
              <th className="text-right px-4 py-3 font-semibold text-indigo-500">KDV Dahil</th>
              <th className="px-3" />
            </tr>
          </thead>
          <tbody>
            {rows.map((row, idx) => {
              const amt = parseFloat(row.amount.replace(',', '.')) || 0;
              const { net, kdv, gross } = calcBreakdown(amt, row.rate, row.direction);
              const hasAmt = amt > 0;
              return (
                <tr key={row.id} className={`border-b border-slate-100 dark:border-slate-700/60 ${idx % 2 === 0 ? '' : 'bg-slate-50/50 dark:bg-slate-700/20'}`}>
                  <td className="px-4 py-2.5">
                    <input
                      type="text"
                      value={row.description}
                      onChange={e => updateRow(row.id, { description: e.target.value })}
                      placeholder={`Kalem ${idx + 1}`}
                      className="w-full min-w-[120px] rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 px-2.5 py-1.5 text-slate-800 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400"
                    />
                  </td>
                  <td className="px-4 py-2.5">
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={row.amount}
                      onChange={e => updateRow(row.id, { amount: e.target.value })}
                      placeholder="0.00"
                      className="w-28 rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 px-2.5 py-1.5 text-slate-800 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400"
                    />
                  </td>
                  <td className="px-4 py-2.5">
                    <select
                      value={row.direction}
                      onChange={e => updateRow(row.id, { direction: e.target.value as Direction })}
                      className="rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 px-2 py-1.5 text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-400"
                    >
                      <option value="from_gross">KDV Dahil</option>
                      <option value="from_net">KDV Hariç</option>
                    </select>
                  </td>
                  <td className="px-4 py-2.5">
                    <select
                      value={row.rate}
                      onChange={e => updateRow(row.id, { rate: Number(e.target.value) })}
                      className="rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-700 px-2 py-1.5 text-sm font-semibold text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-400"
                    >
                      {KDV_PRESETS.map(p => (
                        <option key={p.value} value={p.value}>{p.label}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono font-semibold text-slate-700 dark:text-slate-200 text-sm">
                    {hasAmt ? `${fmt(net)} ₺` : '—'}
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono font-semibold text-orange-500 text-sm">
                    {hasAmt ? `${fmt(kdv)} ₺` : '—'}
                  </td>
                  <td className="px-4 py-2.5 text-right font-mono font-semibold text-indigo-600 dark:text-indigo-400 text-sm">
                    {hasAmt ? `${fmt(gross)} ₺` : '—'}
                  </td>
                  <td className="px-3 py-2.5">
                    <button
                      onClick={() => removeRow(row.id)}
                      disabled={rows.length === 1}
                      className="p-1.5 rounded-lg text-slate-300 dark:text-slate-600 hover:text-red-500 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                    >
                      <Trash2 size={14} />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
          {hasAny && (
            <tfoot>
              <tr className="bg-slate-800 dark:bg-slate-900 text-white">
                <td colSpan={4} className="px-4 py-3 text-sm font-bold text-slate-300">TOPLAM</td>
                <td className="px-4 py-3 text-right font-mono font-black text-white text-sm">{fmt(totals.net)} ₺</td>
                <td className="px-4 py-3 text-right font-mono font-black text-orange-300 text-sm">{fmt(totals.kdv)} ₺</td>
                <td className="px-4 py-3 text-right font-mono font-black text-indigo-300 text-sm">{fmt(totals.gross)} ₺</td>
                <td className="px-3" />
              </tr>
            </tfoot>
          )}
        </table>
      </div>
    </div>
  );
};

// ── Quick reference table ────────────────────────────────────────────────────

const ReferenceTable: React.FC = () => {
  const [baseAmt, setBaseAmt] = useState('1000');
  const amt = parseFloat(baseAmt.replace(',', '.')) || 1000;

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
      <div className="bg-gradient-to-r from-slate-700 to-slate-600 px-6 py-4 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <Calculator size={18} className="text-white" />
          <h2 className="text-white font-bold">Oran Karşılaştırma Tablosu</h2>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-slate-300 text-sm">Baz tutar:</span>
          <div className="relative">
            <span className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400 text-sm">₺</span>
            <input
              type="number"
              value={baseAmt}
              onChange={e => setBaseAmt(e.target.value)}
              className="w-28 pl-6 pr-2 py-1.5 rounded-lg bg-white/10 border border-white/20 text-white text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-white/40 placeholder:text-white/40"
              placeholder="1000"
            />
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-700/50 text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wide">
              <th className="text-left px-4 py-3 font-semibold">KDV Oranı</th>
              <th className="text-right px-4 py-3 font-semibold">KDV Hariç</th>
              <th className="text-right px-4 py-3 font-semibold text-orange-500">KDV Tutarı</th>
              <th className="text-right px-4 py-3 font-semibold text-indigo-500">KDV Dahil</th>
              <th className="text-right px-4 py-3 font-semibold">Ters (Dahil → Hariç)</th>
            </tr>
          </thead>
          <tbody>
            {KDV_PRESETS.filter(p => p.value > 0).map((p, idx) => {
              const { net, kdv, gross } = calcBreakdown(amt, p.value, 'from_net');
              const { net: rNet, kdv: rKdv } = calcBreakdown(amt, p.value, 'from_gross');
              return (
                <tr key={p.value} className={`border-b border-slate-100 dark:border-slate-700/60 ${idx % 2 === 0 ? '' : 'bg-slate-50/50 dark:bg-slate-700/20'}`}>
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center px-3 py-1 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 rounded-full text-xs font-black">{p.label}</span>
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-semibold text-slate-700 dark:text-slate-200">{fmt(amt)} ₺</td>
                  <td className="px-4 py-3 text-right font-mono font-semibold text-orange-500">{fmt(kdv)} ₺</td>
                  <td className="px-4 py-3 text-right font-mono font-semibold text-indigo-600 dark:text-indigo-400">{fmt(gross)} ₺</td>
                  <td className="px-4 py-3 text-right font-mono text-slate-500 dark:text-slate-400 text-xs">
                    {fmt(amt)} → <span className="font-semibold text-slate-700 dark:text-slate-200">{fmt(rNet)} ₺</span> + {fmt(rKdv)} ₺
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ── Main export ───────────────────────────────────────────────────────────────

const KdvCalculator: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900/40 rounded-xl flex items-center justify-center">
          <Calculator size={20} className="text-indigo-600 dark:text-indigo-400" />
        </div>
        <div>
          <h1 className="text-xl font-black text-slate-800 dark:text-white">KDV Hesaplayıcı</h1>
          <p className="text-sm text-slate-400 dark:text-slate-500">KDV dahil/hariç dönüşümü ve çoklu kalem hesaplama</p>
        </div>
      </div>

      {/* Two columns on large screens */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <SingleCalc />
        <TableCalc />
      </div>

      {/* Full-width reference */}
      <ReferenceTable />
    </div>
  );
};

export default KdvCalculator;
