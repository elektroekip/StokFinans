import { useState, useEffect, useCallback } from 'react';
import { useRefreshOnChange } from './hooks/useRefreshOnChange';
import { api } from './lib/api';
import { useLang, makeT } from './lib/i18n';

const DICT: Record<string, string> = {
  'ERP / Muhasebe Webhook': 'ERP / Accounting Webhook',
  'Toplam Webhook': 'Total Webhooks',
  'Aktif Webhook': 'Active Webhooks',
  'Başarılı Log': 'Successful Logs',
  'Hatalı Log': 'Error Logs',
  'Webhook Ekle': 'Add Webhook',
  'Yükleniyor…': 'Loading…',
  'Henüz webhook yok': 'No webhooks yet',
  'ERP/muhasebe yazılımınıza anlık bildirim göndermek için webhook ekleyin': 'Add a webhook to send instant notifications to your ERP/accounting software',
  'Aktif': 'Active',
  'Pasif': 'Inactive',
  'Test Et': 'Test',
  'Test ediliyor…': 'Testing…',
  'Webhook başarıyla tetiklendi': 'Webhook triggered successfully',
  'Son tetiklenme:': 'Last triggered:',
  'Son Gönderim Logları': 'Recent Send Logs',
  'Olay': 'Event',
  'Durum': 'Status',
  'HTTP': 'HTTP',
  'Süre': 'Duration',
  'Tarih': 'Date',
  'Başarılı': 'Success',
  'Hata': 'Error',
  'Webhook Düzenle': 'Edit Webhook',
  'Yeni Webhook': 'New Webhook',
  'Ad': 'Name',
  'Logo Tiger, Mikro vb.': 'Logo Tiger, Mikro etc.',
  'Webhook URL': 'Webhook URL',
  'Secret Key': 'Secret Key',
  'isteğe bağlı — HMAC imzalama': 'optional — HMAC signing',
  'Güvenlik anahtarı': 'Security key',
  'Tetikleyici Olaylar': 'Trigger Events',
  'İptal': 'Cancel',
  'Kaydet': 'Save',
  'Kaydediliyor…': 'Saving…',
  'Kaydedildi': 'Saved',
  'Silindi': 'Deleted',
  'Bu webhook silinsin mi?': 'Delete this webhook?',
  'Veriler yüklenemedi': 'Could not load data',
  'Test hatası': 'Test error',
};
import {
  Webhook, Plus, Trash2, Edit3, CheckCircle2,
  XCircle, RefreshCw,
} from 'lucide-react';

// ── Types ──────────────────────────────────────────────────────
interface ErpWebhook {
  id: number; name: string; event_types: string[]; url: string;
  is_active: boolean; last_triggered_at: string | null; last_http_status: number | null;
}
interface ErpSyncLog {
  id: number; webhook_id: number | null; event_type: string;
  http_status_code: number | null; success: boolean; duration_ms: number | null; created_at: string;
}

const ALL_EVENTS = [
  'order.confirmed', 'order.shipped', 'order.delivered', 'order.cancelled',
  'stock.updated', 'customer.created', 'payment.received',
];

function fmtDt(iso: string | null) {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

// ── ERP Webhook Modal ─────────────────────────────────────────
function WebhookModal({ webhook, onSave, onClose }: {
  webhook?: ErpWebhook; onSave: (d: any) => Promise<void>; onClose: () => void;
}) {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const [form, setForm] = useState({
    name: webhook?.name || '',
    url: webhook?.url || '',
    secret_key: '',
    is_active: webhook?.is_active ?? true,
    event_types: webhook?.event_types || [] as string[],
  });
  const [saving, setSaving] = useState(false);

  const toggle = (evt: string) => setForm(f => ({
    ...f,
    event_types: f.event_types.includes(evt) ? f.event_types.filter(e => e !== evt) : [...f.event_types, evt],
  }));

  const handleSave = async () => {
    setSaving(true);
    try { await onSave({ ...form, secret_key: form.secret_key || undefined }); }
    finally { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl w-full max-w-lg">
        <div className="flex items-center justify-between p-5 border-b border-gray-100 dark:border-slate-700">
          <h2 className="font-semibold text-lg text-gray-900 dark:text-slate-100 flex items-center gap-2">
            <Webhook size={18} className="text-indigo-500" />
            {webhook ? t('Webhook Düzenle') : t('Yeni Webhook')}
          </h2>
          <button onClick={onClose} className="text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 text-xl">×</button>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-700 dark:text-slate-300">{t('Ad')}</label>
            <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              placeholder={t('Logo Tiger, Mikro vb.')}
              className="mt-1 w-full border border-gray-200 dark:border-slate-600 rounded-lg px-3 py-2 text-sm bg-white dark:bg-slate-700 text-gray-900 dark:text-slate-100 placeholder-gray-400 dark:placeholder-slate-500" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700 dark:text-slate-300">{t('Webhook URL')}</label>
            <input value={form.url} onChange={e => setForm(f => ({ ...f, url: e.target.value }))}
              placeholder="https://erp.sirketiniz.com/webhook"
              className="mt-1 w-full border border-gray-200 dark:border-slate-600 rounded-lg px-3 py-2 text-sm bg-white dark:bg-slate-700 text-gray-900 dark:text-slate-100 placeholder-gray-400 dark:placeholder-slate-500" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700 dark:text-slate-300">{t('Secret Key')} <span className="text-gray-400 dark:text-slate-500 font-normal">({t('isteğe bağlı — HMAC imzalama')})</span></label>
            <input value={form.secret_key} onChange={e => setForm(f => ({ ...f, secret_key: e.target.value }))}
              placeholder={t('Güvenlik anahtarı')} type="password"
              className="mt-1 w-full border border-gray-200 dark:border-slate-600 rounded-lg px-3 py-2 text-sm bg-white dark:bg-slate-700 text-gray-900 dark:text-slate-100 placeholder-gray-400 dark:placeholder-slate-500" />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-700 dark:text-slate-300 block mb-2">{t('Tetikleyici Olaylar')}</label>
            <div className="grid grid-cols-2 gap-2">
              {ALL_EVENTS.map(evt => (
                <label key={evt} className="flex items-center gap-2 text-sm cursor-pointer">
                  <input type="checkbox" checked={form.event_types.includes(evt)} onChange={() => toggle(evt)} className="rounded" />
                  <code className="text-xs bg-gray-100 dark:bg-slate-700 text-gray-700 dark:text-slate-300 px-1.5 py-0.5 rounded">{evt}</code>
                </label>
              ))}
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm cursor-pointer text-gray-700 dark:text-slate-300">
            <input type="checkbox" checked={form.is_active} onChange={e => setForm(f => ({ ...f, is_active: e.target.checked }))} className="rounded" />
            {t('Aktif')}
          </label>
        </div>
        <div className="flex gap-3 p-5 border-t border-gray-100 dark:border-slate-700">
          <button onClick={onClose}
            className="flex-1 py-2 border border-gray-200 dark:border-slate-600 rounded-lg text-sm text-gray-600 dark:text-slate-400 hover:bg-gray-50 dark:hover:bg-slate-700">
            {t('İptal')}
          </button>
          <button onClick={handleSave} disabled={saving}
            className="flex-1 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 disabled:opacity-50">
            {saving ? t('Kaydediliyor…') : t('Kaydet')}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main ───────────────────────────────────────────────────────
export default function IntegrationsView({
  showToast,
}: {
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}) {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const [webhooks, setWebhooks] = useState<ErpWebhook[]>([]);
  const [logs, setLogs] = useState<ErpSyncLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [webhookModal, setWebhookModal] = useState<ErpWebhook | null | 'new'>(null);
  const [testingId, setTestingId] = useState<number | null>(null);

  const fetchAll = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const [wRes, lRes] = await Promise.all([
        api.get('/integrations/erp/webhooks'),
        api.get('/integrations/erp/logs', { params: { limit: 50 } }),
      ]);
      setWebhooks(wRes.data);
      setLogs(lRes.data);
    } catch { showToast(t('Veriler yüklenemedi'), 'error'); }
    finally { setLoading(false); }
  }, [showToast]);

  useEffect(() => { fetchAll(); }, [fetchAll]);
  useRefreshOnChange(fetchAll);

  const testWebhook = async (id: number) => {
    setTestingId(id);
    try {
      const res = await api.post(`/integrations/erp/webhooks/${id}/test`);
      showToast(
        res.data.success ? t('Webhook başarıyla tetiklendi') : `Webhook hatası: ${res.data.message}`,
        res.data.success ? 'success' : 'error',
      );
      fetchAll();
    } catch (e: any) { showToast(e.response?.data?.detail || t('Test hatası'), 'error'); }
    finally { setTestingId(null); }
  };

  const deleteWebhook = async (id: number) => {
    if (!confirm(t('Bu webhook silinsin mi?'))) return;
    try { await api.delete(`/integrations/erp/webhooks/${id}`); showToast(t('Silindi'), 'success'); fetchAll(); }
    catch (e: any) { showToast(e.response?.data?.detail || t('Hata'), 'error'); }
  };

  const saveWebhook = async (data: any) => {
    try {
      if (webhookModal && webhookModal !== 'new')
        await api.put(`/integrations/erp/webhooks/${(webhookModal as ErpWebhook).id}`, data);
      else
        await api.post('/integrations/erp/webhooks', data);
      setWebhookModal(null); showToast(t('Kaydedildi'), 'success'); fetchAll();
    } catch (e: any) { showToast(e.response?.data?.detail || t('Hata'), 'error'); }
  };

  const activeCount = webhooks.filter(w => w.is_active).length;
  const successCount = logs.filter(l => l.success).length;
  const errorCount = logs.filter(l => !l.success).length;

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: t('Toplam Webhook'), val: webhooks.length, color: 'text-indigo-600 dark:text-indigo-400', bg: 'bg-indigo-50 dark:bg-indigo-900/30' },
          { label: t('Aktif Webhook'),  val: activeCount,     color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-emerald-50 dark:bg-emerald-900/30' },
          { label: t('Başarılı Log'),   val: successCount,    color: 'text-blue-600 dark:text-blue-400', bg: 'bg-blue-50 dark:bg-blue-900/30' },
          { label: t('Hatalı Log'),     val: errorCount,      color: errorCount > 0 ? 'text-red-600 dark:text-red-400' : 'text-gray-400 dark:text-slate-500', bg: 'bg-red-50 dark:bg-red-900/30' },
        ].map((s, i) => (
          <div key={i} className="bg-white dark:bg-slate-800 rounded-xl p-4 border border-gray-100 dark:border-slate-700">
            <p className={`text-2xl font-bold ${s.color}`}>{s.val}</p>
            <p className="text-xs text-gray-500 dark:text-slate-400 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Webhooks */}
      <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-100 dark:border-slate-700">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 dark:border-slate-700">
          <div className="flex items-center gap-2">
            <Webhook size={18} className="text-indigo-500" />
            <h3 className="font-semibold text-gray-900 dark:text-slate-100">{t('ERP / Muhasebe Webhook')}</h3>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={fetchAll} className="p-2 text-gray-400 dark:text-slate-500 hover:text-gray-600 dark:hover:text-slate-300 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700">
              <RefreshCw size={15} className={loading ? 'animate-spin' : ''} />
            </button>
            <button onClick={() => setWebhookModal('new')}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700">
              <Plus size={14} />{t('Webhook Ekle')}
            </button>
          </div>
        </div>

        <div className="p-5">
          {loading && (
            <p className="text-center text-gray-400 dark:text-slate-500 py-8">{t('Yükleniyor…')}</p>
          )}
          {!loading && webhooks.length === 0 && (
            <div className="text-center py-14 text-gray-400 dark:text-slate-500">
              <Webhook size={44} className="mx-auto mb-3 opacity-25" />
              <p className="font-medium text-sm">{t('Henüz webhook yok')}</p>
              <p className="text-xs mt-1">{t('ERP/muhasebe yazılımınıza anlık bildirim göndermek için webhook ekleyin')}</p>
            </div>
          )}

          <div className="space-y-3">
            {webhooks.map(wh => (
              <div key={wh.id} className="border border-gray-200 dark:border-slate-700 rounded-xl p-4 hover:bg-gray-50 dark:hover:bg-slate-700/50 transition-colors">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="font-medium text-gray-900 dark:text-slate-100">{wh.name}</span>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${wh.is_active ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400' : 'bg-gray-100 dark:bg-slate-700 text-gray-500 dark:text-slate-400'}`}>
                        {wh.is_active ? t('Aktif') : t('Pasif')}
                      </span>
                      {wh.last_http_status && (
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${wh.last_http_status < 300 ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400' : 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400'}`}>
                          HTTP {wh.last_http_status}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 dark:text-slate-400 font-mono truncate">{wh.url}</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {wh.event_types.map(e => (
                        <code key={e} className="text-xs bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 px-1.5 py-0.5 rounded">{e}</code>
                      ))}
                    </div>
                    {wh.last_triggered_at && (
                      <p className="text-xs text-gray-400 dark:text-slate-500 mt-1.5">{t('Son tetiklenme:')} {fmtDt(wh.last_triggered_at)}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button onClick={() => testWebhook(wh.id)} disabled={testingId === wh.id}
                      className="px-3 py-1.5 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg text-xs font-medium hover:bg-blue-100 dark:hover:bg-blue-900/50 disabled:opacity-50">
                      {testingId === wh.id ? t('Test ediliyor…') : t('Test Et')}
                    </button>
                    <button onClick={() => setWebhookModal(wh)}
                      className="p-1.5 text-gray-400 dark:text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg hover:bg-indigo-50 dark:hover:bg-indigo-900/30">
                      <Edit3 size={14} />
                    </button>
                    <button onClick={() => deleteWebhook(wh.id)}
                      className="p-1.5 text-red-400 dark:text-red-500 hover:text-red-600 dark:hover:text-red-400 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/30">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Logs */}
      {logs.length > 0 && (
        <div className="bg-white dark:bg-slate-800 rounded-xl border border-gray-100 dark:border-slate-700">
          <div className="px-5 py-4 border-b border-gray-100 dark:border-slate-700">
            <h3 className="font-semibold text-gray-900 dark:text-slate-100">{t('Son Gönderim Logları')}</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[500px] text-sm">
              <thead className="bg-gray-50 dark:bg-slate-700/50">
                <tr>
                  {[t('Olay'), t('Durum'), t('HTTP'), t('Süre'), t('Tarih')].map(h => (
                    <th key={h} className="text-left px-4 py-3 text-xs font-medium text-gray-500 dark:text-slate-400">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-slate-700">
                {logs.map(l => (
                  <tr key={l.id} className="hover:bg-gray-50 dark:hover:bg-slate-700/50">
                    <td className="px-4 py-3">
                      <code className="text-xs text-gray-700 dark:text-slate-300 bg-gray-100 dark:bg-slate-700 px-1.5 py-0.5 rounded">{l.event_type}</code>
                    </td>
                    <td className="px-4 py-3">
                      {l.success
                        ? <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1 text-xs"><CheckCircle2 size={13} />{t('Başarılı')}</span>
                        : <span className="text-red-500 dark:text-red-400 flex items-center gap-1 text-xs"><XCircle size={13} />{t('Hata')}</span>}
                    </td>
                    <td className="px-4 py-3 text-gray-600 dark:text-slate-400 text-xs">{l.http_status_code || '—'}</td>
                    <td className="px-4 py-3 text-gray-500 dark:text-slate-400 text-xs">{l.duration_ms ? `${l.duration_ms}ms` : '—'}</td>
                    <td className="px-4 py-3 text-gray-400 dark:text-slate-500 text-xs">{fmtDt(l.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {webhookModal && (
        <WebhookModal
          webhook={webhookModal !== 'new' ? webhookModal : undefined}
          onSave={saveWebhook}
          onClose={() => setWebhookModal(null)}
        />
      )}
    </div>
  );
}
