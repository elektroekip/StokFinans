import React, { useCallback, useEffect, useState } from 'react';
import api from './lib/api';
import {
  Activity, AlertCircle, AlertTriangle, CheckCircle2, Clock,
  Database, HardDrive, Network, RefreshCw, Server, Wifi,
} from 'lucide-react';

interface Props {
  showToast: (m: string, t?: string) => void;
  onOpenTopology: () => void;
}

interface NodeStatus {
  status: 'ok' | 'warn' | 'error' | 'unknown';
  label?: string;
  latency_ms?: number;
  load?: number;
  ram_pct?: number;
  disk_pct?: number;
}

interface SnapshotData {
  nodes: Record<string, NodeStatus>;
  system: { load: number; ram_pct: number };
}

interface StatsData {
  event_counts: Record<string, number>;
  total_events: number;
  recent_events: Array<{
    id: number;
    event_type: string;
    from_node: string;
    to_node?: string;
    message: string;
    created_at: string;
  }>;
  hours: number;
}

const EVENT_LABELS: Record<string, { label: string; color: string; emoji: string }> = {
  upload:    { label: 'Yükleme',  color: '#22c55e', emoji: '🟢' },
  download:  { label: 'İndirme', color: '#3b82f6', emoji: '🔵' },
  replicate: { label: 'Replika', color: '#f97316', emoji: '🟠' },
  backup:    { label: 'Yedek',   color: '#eab308', emoji: '🟡' },
  delete:    { label: 'Silme',   color: '#ef4444', emoji: '🔴' },
  health:    { label: 'Sağlık',  color: '#a855f7', emoji: '🟣' },
  error:     { label: 'Hata',    color: '#ef4444', emoji: '💀' },
};

const NODE_META: Record<string, { label: string; icon: any; group: string }> = {
  nginx:       { label: 'Nginx Proxy',  icon: Wifi,      group: 'Ağ' },
  'backend-s1':{ label: 'FastAPI S1',   icon: Server,    group: 'Sunucu' },
  'backend-s2':{ label: 'FastAPI S2',   icon: Server,    group: 'Sunucu' },
  postgres:    { label: 'PostgreSQL',   icon: Database,  group: 'Veritabanı' },
  'minio-s1':  { label: 'MinIO S1',     icon: HardDrive, group: 'Depolama' },
  'minio-s2':  { label: 'MinIO S2',     icon: HardDrive, group: 'Depolama' },
  sftp:        { label: 'SFTP/FTP',     icon: HardDrive, group: 'Depolama' },
  's3-ext':    { label: 'Harici S3',    icon: Network,   group: 'Dış' },
};

const STATUS_STYLE: Record<string, { text: string; dot: string; bg: string }> = {
  ok:      { text: 'text-emerald-600 dark:text-emerald-400', dot: 'bg-emerald-500', bg: 'bg-emerald-50 dark:bg-emerald-900/20' },
  warn:    { text: 'text-amber-600 dark:text-amber-400',     dot: 'bg-amber-400',   bg: 'bg-amber-50 dark:bg-amber-900/20' },
  error:   { text: 'text-red-600 dark:text-red-400',         dot: 'bg-red-500 animate-pulse', bg: 'bg-red-50 dark:bg-red-900/20' },
  unknown: { text: 'text-slate-400',                         dot: 'bg-slate-400',   bg: 'bg-slate-50 dark:bg-slate-800/40' },
};

const fmtDt = (s: string) => {
  try { return new Date(s).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }); }
  catch { return s; }
};

export default function SystemOverview({ showToast, onOpenTopology }: Props) {
  const [snapshot, setSnapshot] = useState<SnapshotData | null>(null);
  const [stats, setStats] = useState<StatsData | null>(null);
  const [alertCount, setAlertCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [snapRes, statsRes, alertRes] = await Promise.all([
        api.get('/topology/snapshot'),
        api.get('/topology/stats', { params: { hours: 24 } }),
        api.get('/topology/alert-count'),
      ]);
      setSnapshot(snapRes.data);
      setStats(statsRes.data);
      setAlertCount(alertRes.data.alerts);
      setFetchError(null);
      setLastRefresh(new Date());
    } catch (err: any) {
      const msg = err?.response ? `HTTP ${err.response.status}` : 'Sunucuya ulaşılamıyor';
      setFetchError(msg);
      // stale data intentionally kept — don't clear snapshot/stats
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const t = setInterval(load, 30000);
    return () => clearInterval(t);
  }, [load]);

  const nodes = snapshot?.nodes ?? {};
  const allNodeIds = Object.keys(NODE_META);
  const totalNodes = allNodeIds.length;
  const healthyNodes = allNodeIds.filter(id => nodes[id]?.status === 'ok').length;
  const errorCount = allNodeIds.filter(id => nodes[id]?.status === 'error').length;
  const warnCount  = allNodeIds.filter(id => nodes[id]?.status === 'warn').length;

  const errEvents = stats?.event_counts['error'] ?? 0;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h2 className="text-xl font-black text-slate-800 dark:text-white tracking-tight">Genel Bakış</h2>
          <p className="text-xs text-slate-400 font-medium mt-0.5">
            Son güncelleme: {lastRefresh.toLocaleTimeString('tr-TR')} · 30 saniyede bir otomatik yenilenir
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenTopology}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 transition"
          >
            <Network size={13} /> Canlı Haritayı Aç ▸
          </button>
          <button
            onClick={load}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold transition"
          >
            <RefreshCw size={13} className={loading ? 'animate-spin' : ''} /> Yenile
          </button>
        </div>
      </div>

      {/* Stale-data warning banner */}
      {fetchError && (
        <div className="flex items-center gap-3 px-4 py-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 rounded-xl text-sm">
          <AlertTriangle size={15} className="text-amber-600 dark:text-amber-400 shrink-0" />
          <span className="text-amber-800 dark:text-amber-300 font-semibold">
            Veriler yenilenemiyor ({fetchError}) — son başarılı veri gösteriliyor
          </span>
          <button onClick={load} className="ml-auto text-xs font-bold text-amber-700 dark:text-amber-400 hover:underline shrink-0">Tekrar dene</button>
        </div>
      )}

      {/* Summary stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-900/30 flex items-center justify-center shrink-0">
            <CheckCircle2 size={18} className="text-emerald-600 dark:text-emerald-400" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase text-slate-400 tracking-wider">Sağlıklı Node</div>
            <div className="text-2xl font-black text-slate-800 dark:text-white">
              {healthyNodes}<span className="text-slate-400 text-lg font-bold">/{totalNodes}</span>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-50 dark:bg-red-900/30 flex items-center justify-center shrink-0">
            <AlertCircle size={18} className="text-red-600 dark:text-red-400" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase text-slate-400 tracking-wider">Kritik Uyarı</div>
            <div className="text-2xl font-black text-slate-800 dark:text-white">{alertCount}</div>
            {errorCount > 0 && <div className="text-[10px] text-red-500 font-bold">{errorCount} node hatalı</div>}
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-900/30 flex items-center justify-center shrink-0">
            <AlertTriangle size={18} className="text-amber-600 dark:text-amber-400" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase text-slate-400 tracking-wider">Uyarı</div>
            <div className="text-2xl font-black text-slate-800 dark:text-white">{warnCount}</div>
            <div className="text-[10px] text-slate-400 font-medium">node sarı durumda</div>
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-900/30 flex items-center justify-center shrink-0">
            <Activity size={18} className="text-indigo-600 dark:text-indigo-400" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase text-slate-400 tracking-wider">24s Olay</div>
            <div className="text-2xl font-black text-slate-800 dark:text-white">{stats?.total_events ?? '—'}</div>
            {errEvents > 0 && <div className="text-[10px] text-red-500 font-bold">{errEvents} hata</div>}
          </div>
        </div>
      </div>

      {/* System load (self node) */}
      {snapshot?.system && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-4">
          <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider mb-3">Anlık Sistem Yükü (S1)</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="flex justify-between text-xs text-slate-500 mb-1.5">
                <span className="font-bold">CPU Yük (1dk)</span>
                <span className="font-mono font-bold">{snapshot.system.load}</span>
              </div>
              <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.min(snapshot.system.load * 25, 100)}%`,
                    background: snapshot.system.load > 3 ? '#ef4444' : snapshot.system.load > 1.5 ? '#f59e0b' : '#8b5cf6',
                  }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-xs text-slate-500 mb-1.5">
                <span className="font-bold">RAM Kullanımı</span>
                <span className="font-mono font-bold">%{snapshot.system.ram_pct}</span>
              </div>
              <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${snapshot.system.ram_pct}%`,
                    background: snapshot.system.ram_pct > 85 ? '#ef4444' : snapshot.system.ram_pct > 70 ? '#f59e0b' : '#22c55e',
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Two-column: node list + event counts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Node status list */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <h3 className="text-xs font-black uppercase text-slate-500 tracking-wider">Node Durumları</h3>
            <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Anlık
            </div>
          </div>
          <div className="divide-y divide-slate-50 dark:divide-slate-800/60">
            {allNodeIds.map(id => {
              const meta = NODE_META[id];
              const st = nodes[id];
              const statusKey = st?.status ?? 'unknown';
              const style = STATUS_STYLE[statusKey];
              const Icon = meta.icon;
              return (
                <div key={id} className={`flex items-center gap-3 px-4 py-2.5 ${style.bg}`}>
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${style.bg}`}>
                    <Icon size={13} className={style.text} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{meta.label}</span>
                      <span className="text-[10px] text-slate-400 font-medium">{meta.group}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      {st?.load !== undefined && (
                        <span className="text-[10px] text-slate-500">CPU: {st.load}</span>
                      )}
                      {st?.ram_pct !== undefined && (
                        <span className="text-[10px] text-slate-500">RAM: %{st.ram_pct}</span>
                      )}
                      {st?.disk_pct !== undefined && (
                        <span className={`text-[10px] ${st.disk_pct > 80 ? 'text-red-500 font-bold' : 'text-slate-500'}`}>Disk: %{st.disk_pct}</span>
                      )}
                      {st?.latency_ms !== undefined && st.latency_ms > 0 && (
                        <span className="text-[10px] text-slate-500">{st.latency_ms}ms</span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <span className={`w-2 h-2 rounded-full ${style.dot}`} />
                    <span className={`text-[10px] font-bold uppercase ${style.text}`}>
                      {statusKey === 'ok' ? 'Sağlıklı' : statusKey === 'warn' ? 'Uyarı' : statusKey === 'error' ? 'Hata' : 'Bilinmiyor'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 24h event stats */}
        <div className="flex flex-col gap-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex-1">
            <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-xs font-black uppercase text-slate-500 tracking-wider">Son 24 Saat — Olay Dağılımı</h3>
            </div>
            <div className="p-4 space-y-2.5">
              {stats ? (
                Object.entries(EVENT_LABELS).map(([key, cfg]) => {
                  const cnt = stats.event_counts[key] ?? 0;
                  const maxCnt = Math.max(...Object.values(stats.event_counts), 1);
                  return (
                    <div key={key}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="flex items-center gap-1.5 font-semibold text-slate-600 dark:text-slate-300">
                          <span>{cfg.emoji}</span> {cfg.label}
                        </span>
                        <span className="font-mono font-bold" style={{ color: cfg.color }}>{cnt}</span>
                      </div>
                      <div className="h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-700"
                          style={{ width: `${(cnt / maxCnt) * 100}%`, background: cfg.color }}
                        />
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-xs text-slate-400 text-center py-4">Yükleniyor…</div>
              )}
            </div>
          </div>

          {/* Quick stats */}
          <div className="grid grid-cols-3 gap-3">
            {(['backend-s1', 'postgres', 'minio-s1'] as const).map(id => {
              const meta = NODE_META[id];
              const st = nodes[id];
              const col = st?.status === 'ok' ? '#22c55e' : st?.status === 'warn' ? '#eab308' : st?.status === 'error' ? '#ef4444' : '#64748b';
              return (
                <div key={id} className="bg-slate-900 rounded-xl border border-slate-700/50 p-3 text-center">
                  <div className="flex items-center justify-center gap-1 mb-1.5">
                    <span className="w-1.5 h-1.5 rounded-full" style={{ background: col }} />
                    <span className="text-[10px] font-bold text-slate-400 truncate">{meta?.label}</span>
                  </div>
                  {st?.disk_pct !== undefined ? (
                    <div className="text-lg font-black" style={{ color: col }}>%{st.disk_pct}</div>
                  ) : st?.ram_pct !== undefined ? (
                    <div className="text-lg font-black" style={{ color: col }}>%{st.ram_pct}</div>
                  ) : st?.latency_ms !== undefined ? (
                    <div className="text-lg font-black" style={{ color: col }}>{st.latency_ms}ms</div>
                  ) : (
                    <div className="text-[10px] text-slate-600 font-mono">—</div>
                  )}
                  <div className="text-[9px] text-slate-600 mt-0.5">
                    {st?.disk_pct !== undefined ? 'disk' : st?.ram_pct !== undefined ? 'ram' : st?.latency_ms !== undefined ? 'latency' : ''}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Recent alerts / events */}
      {stats && stats.recent_events.length > 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <h3 className="text-xs font-black uppercase text-slate-500 tracking-wider flex items-center gap-2">
              <Clock size={12} /> Son Olaylar
            </h3>
            <button
              onClick={onOpenTopology}
              className="text-[11px] font-bold text-indigo-500 hover:text-indigo-700 transition flex items-center gap-1"
            >
              Canlı akışı gör ▸
            </button>
          </div>
          <div className="divide-y divide-slate-50 dark:divide-slate-800/40">
            {stats.recent_events.slice(0, 10).map(ev => {
              const cfg = EVENT_LABELS[ev.event_type] ?? { emoji: '⚪', color: '#94a3b8', label: ev.event_type };
              const isErr = ev.event_type === 'error';
              return (
                <div key={ev.id} className={`flex items-center gap-3 px-4 py-2.5 ${isErr ? 'bg-red-50/50 dark:bg-red-900/10' : ''}`}>
                  <span className="shrink-0">{cfg.emoji}</span>
                  <span className="text-[10px] text-slate-400 font-mono shrink-0 w-20">{fmtDt(ev.created_at)}</span>
                  <span className="text-[11px] font-bold text-slate-400 shrink-0">
                    {ev.from_node}{ev.to_node ? ` → ${ev.to_node}` : ''}
                  </span>
                  <span className="text-[11px] truncate" style={{ color: cfg.color }}>{ev.message}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
