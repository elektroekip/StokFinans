import { useState, useEffect, useCallback } from 'react';
import { useRefreshOnChange } from './hooks/useRefreshOnChange';
import {
  ShoppingCart, Building2, Plus, Search, CheckCircle, XCircle,
  Clock, AlertTriangle, Banknote, FileCheck, Truck, Edit3, Trash2,
  Tag, Phone, Mail, Package,
} from 'lucide-react';
import { apiRequest } from './lib/api';

// ─── Types ────────────────────────────────────────────────────

interface Supplier {
  id: number; company_name: string; contact_person?: string;
  phone?: string; email?: string; vkn?: string; tax_office?: string;
  address?: string; notes?: string; payment_term_days: number;
  is_active: boolean; order_count: number; total_payable: number;
  created_at?: string;
}

interface PurchaseItem {
  id: number; product_id?: number; product_name: string;
  unit_price: number; currency: string; quantity: number;
  kdv_rate: number; line_total: number;
}

interface PurchaseOrder {
  id: number; supplier_id: number; supplier_name: string;
  order_number: string; status: string;
  notes?: string; expected_date?: string;
  subtotal: number; kdv_amount: number; total_amount: number; currency: string;
  transaction_id?: number; is_paid: boolean; paid_at?: string;
  created_at?: string; items: PurchaseItem[];
}

interface Product { id: number; name: string; quantity: number; price: number; cost?: number; }

// ─── Constants ────────────────────────────────────────────────

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: any }> = {
  draft:    { label: 'Taslak',    color: 'bg-slate-100 text-slate-700',    icon: Clock },
  ordered:  { label: 'Sipariş Verildi', color: 'bg-blue-100 text-blue-700', icon: FileCheck },
  received: { label: 'Teslim Alındı', color: 'bg-emerald-100 text-emerald-700', icon: CheckCircle },
  cancelled:{ label: 'İptal',     color: 'bg-red-100 text-red-700',        icon: XCircle },
};

const fmt = (n: number, cur = 'TRY') =>
  new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n) +
  (cur === 'USD' ? ' $' : cur === 'EUR' ? ' €' : ' ₺');

function StatusBadge({ status }: { status: string }) {
  const cfg = STATUS_CONFIG[status] || { label: status, color: 'bg-gray-100 text-gray-700', icon: Clock };
  const Icon = cfg.icon;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${cfg.color}`}>
      <Icon size={11}/>{cfg.label}
    </span>
  );
}

// ─── Stats Bar ────────────────────────────────────────────────

function StatsBar({ stats }: { stats: any }) {
  const cards = [
    { label: 'Aktif Alımlar', value: stats.active_purchases, icon: ShoppingCart, color: 'text-blue-600' },
    { label: 'Ödenecek Borç', value: fmt(stats.total_payable), icon: Banknote, color: 'text-amber-600' },
    { label: 'Bu Ay Alınan', value: stats.received_this_month, icon: CheckCircle, color: 'text-emerald-600' },
    { label: 'Tedarikçiler', value: stats.supplier_count, icon: Building2, color: 'text-indigo-600' },
  ];
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
      {cards.map(c => {
        const Icon = c.icon;
        return (
          <div key={c.label} className="bg-white rounded-xl border border-gray-200 p-3">
            <div className="flex items-center gap-2 mb-1">
              <Icon size={15} className={c.color}/>
              <span className="text-xs text-gray-500 truncate">{c.label}</span>
            </div>
            <p className={`text-lg font-bold ${c.color}`}>{c.value}</p>
          </div>
        );
      })}
    </div>
  );
}

// ─── Purchase Detail Modal ────────────────────────────────────

function PurchaseDetailModal({ order, onClose, onAction }: {
  order: PurchaseOrder; onClose: () => void;
  onAction: (id: number, action: string) => void;
}) {
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="p-4 border-b flex items-start justify-between bg-gray-50 rounded-t-2xl">
          <div>
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <h2 className="font-bold text-lg">#{order.order_number}</h2>
              <StatusBadge status={order.status} />
              {order.is_paid && <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-medium">✓ Ödendi</span>}
            </div>
            <p className="text-sm text-gray-600">{order.supplier_name}</p>
            {order.expected_date && <p className="text-xs text-gray-500 mt-0.5">Beklenen: {order.expected_date}</p>}
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl ml-4">✕</button>
        </div>

        <div className="p-4 space-y-4">
          {/* Kalemler */}
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Kalemler</p>
            <div className="border rounded-xl overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left p-2 text-xs text-gray-500">Ürün</th>
                    <th className="text-right p-2 text-xs text-gray-500">Adet</th>
                    <th className="text-right p-2 text-xs text-gray-500">Birim Fiyat</th>
                    <th className="text-right p-2 text-xs text-gray-500">KDV%</th>
                    <th className="text-right p-2 text-xs text-gray-500">Tutar</th>
                  </tr>
                </thead>
                <tbody>
                  {order.items.map(it => (
                    <tr key={it.id} className="border-t">
                      <td className="p-2 font-medium">{it.product_name}</td>
                      <td className="p-2 text-right">{it.quantity}</td>
                      <td className="p-2 text-right">{fmt(it.unit_price, it.currency)}</td>
                      <td className="p-2 text-right text-gray-400">%{it.kdv_rate}</td>
                      <td className="p-2 text-right font-medium">{fmt(it.line_total, it.currency)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Özet */}
          <div className="bg-gray-50 rounded-xl p-3 space-y-1 text-sm">
            <div className="flex justify-between text-gray-600"><span>Ara Toplam (KDV Hariç)</span><span>{fmt(order.subtotal, order.currency)}</span></div>
            <div className="flex justify-between text-gray-500"><span>Toplam KDV</span><span>{fmt(order.kdv_amount, order.currency)}</span></div>
            <div className="flex justify-between font-bold text-base border-t pt-1"><span>Genel Toplam</span><span>{fmt(order.total_amount, order.currency)}</span></div>
          </div>

          {order.notes && (
            <div className="text-sm text-gray-600 bg-yellow-50 rounded-xl p-3">
              <span className="font-medium text-yellow-800">Not: </span>{order.notes}
            </div>
          )}

          {/* Aksiyon */}
          <div className="flex flex-wrap gap-2 pt-2 border-t">
            {order.status === 'draft' && (
              <>
                <button onClick={() => onAction(order.id, 'order')} className="flex-1 bg-blue-600 text-white rounded-xl py-2 text-sm font-medium hover:bg-blue-700">Siparişi Gönder</button>
                <button onClick={() => onAction(order.id, 'delete')} className="px-4 border border-red-200 text-red-600 rounded-xl py-2 text-sm hover:bg-red-50">Sil</button>
              </>
            )}
            {order.status === 'ordered' && (
              <>
                <button onClick={() => onAction(order.id, 'receive')} className="flex-1 bg-emerald-600 text-white rounded-xl py-2 text-sm font-medium hover:bg-emerald-700"><Package size={14} className="inline mr-1"/>Malı Teslim Al</button>
                <button onClick={() => onAction(order.id, 'cancel')} className="px-4 border border-red-200 text-red-600 rounded-xl py-2 text-sm hover:bg-red-50">İptal</button>
              </>
            )}
            {order.status === 'received' && !order.is_paid && (
              <button onClick={() => onAction(order.id, 'mark-paid')} className="flex-1 bg-teal-600 text-white rounded-xl py-2 text-sm font-medium hover:bg-teal-700">Ödendi İşaretle</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Purchase Create Modal ────────────────────────────────────

const EMPTY_ITEM = { product_id: null as number | null, product_name: '', unit_price: '', quantity: '1', kdv_rate: '18' };

function PurchaseModal({ suppliers, products, onClose, onSaved, showToast }: {
  suppliers: Supplier[]; products: Product[];
  onClose: () => void; onSaved: () => void; showToast: (m: string, t: string) => void;
}) {
  const [form, setForm] = useState({ supplier_id: '', notes: '', expected_date: '', currency: 'TRY' });
  const [items, setItems] = useState([{ ...EMPTY_ITEM }]);
  const [saving, setSaving] = useState(false);

  const subtotal = items.reduce((acc, it) => acc + (parseFloat(it.unit_price) || 0) * (parseInt(it.quantity) || 0), 0);
  const kdv = items.reduce((acc, it) => {
    const base = (parseFloat(it.unit_price) || 0) * (parseInt(it.quantity) || 0);
    return acc + base * (parseFloat(it.kdv_rate) || 0) / 100;
  }, 0);

  function setItem(idx: number, key: string, val: string) {
    setItems(prev => prev.map((it, i) => i === idx ? { ...it, [key]: val } : it));
  }

  function selectProduct(idx: number, pid: string) {
    const prod = products.find(p => p.id === parseInt(pid));
    if (prod) {
      setItems(prev => prev.map((it, i) => i === idx
        ? { ...it, product_id: prod.id, product_name: prod.name, unit_price: (prod.cost || prod.price).toString() } : it));
    } else {
      setItems(prev => prev.map((it, i) => i === idx ? { ...it, product_id: null } : it));
    }
  }

  async function handleSubmit() {
    if (!form.supplier_id) { showToast('Tedarikçi seçin', 'error'); return; }
    if (items.some(it => !it.product_name)) { showToast('Tüm kalemleri doldurun', 'error'); return; }
    setSaving(true);
    try {
      await apiRequest('/supplier/purchases', {
        method: 'POST',
        body: JSON.stringify({
          ...form,
          supplier_id: parseInt(form.supplier_id),
          items: items.map(it => ({
            product_id: it.product_id || null,
            product_name: it.product_name,
            unit_price: parseFloat(it.unit_price) || 0,
            quantity: parseInt(it.quantity) || 1,
            kdv_rate: parseFloat(it.kdv_rate) || 0,
            currency: form.currency,
          })),
        }),
      });
      showToast('Satın alma siparişi oluşturuldu', 'success');
      onSaved();
    } catch (e: any) { showToast(e.message || 'Hata', 'error'); }
    finally { setSaving(false); }
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="p-4 border-b flex items-center justify-between bg-gray-50 rounded-t-2xl">
          <h2 className="font-bold text-lg">Yeni Satın Alma Siparişi</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl">✕</button>
        </div>
        <div className="p-4 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <label className="text-xs font-medium text-gray-600 mb-1 block">Tedarikçi *</label>
              <select value={form.supplier_id} onChange={e => setForm(f => ({ ...f, supplier_id: e.target.value }))}
                className="w-full border rounded-xl px-3 py-2 text-sm">
                <option value="">— Tedarikçi Seçin —</option>
                {suppliers.filter(s => s.is_active).map(s => <option key={s.id} value={s.id}>{s.company_name}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-gray-600 mb-1 block">Tahmini Teslim</label>
              <input type="date" value={form.expected_date} onChange={e => setForm(f => ({ ...f, expected_date: e.target.value }))}
                className="w-full border rounded-xl px-3 py-2 text-sm" />
            </div>
            <div>
              <label className="text-xs font-medium text-gray-600 mb-1 block">Para Birimi</label>
              <select value={form.currency} onChange={e => setForm(f => ({ ...f, currency: e.target.value }))}
                className="w-full border rounded-xl px-3 py-2 text-sm">
                <option value="TRY">TRY ₺</option>
                <option value="USD">USD $</option>
                <option value="EUR">EUR €</option>
              </select>
            </div>
          </div>

          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Kalemler</p>
            <div className="space-y-2">
              {items.map((item, idx) => (
                <div key={idx} className="border rounded-xl p-3 bg-gray-50">
                  <div className="grid grid-cols-12 gap-2 mb-2">
                    <div className="col-span-5">
                      <label className="text-xs text-gray-500 mb-0.5 block">Ürün Seç</label>
                      <select value={item.product_id?.toString() || ''} onChange={e => selectProduct(idx, e.target.value)}
                        className="w-full border rounded-lg px-2 py-1.5 text-sm bg-white">
                        <option value="">Manuel giriş</option>
                        {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                      </select>
                    </div>
                    <div className="col-span-5">
                      <label className="text-xs text-gray-500 mb-0.5 block">Ürün Adı *</label>
                      <input value={item.product_name} onChange={e => setItem(idx, 'product_name', e.target.value)}
                        placeholder="Ürün adı" className="w-full border rounded-lg px-2 py-1.5 text-sm bg-white" />
                    </div>
                    <div className="col-span-2 flex items-end justify-end">
                      {items.length > 1 && (
                        <button onClick={() => setItems(p => p.filter((_, i) => i !== idx))}
                          className="text-red-400 hover:text-red-600 p-1.5 border border-red-200 rounded-lg"><Trash2 size={14}/></button>
                      )}
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="text-xs text-gray-500 mb-0.5 block">Alış Fiyatı</label>
                      <input type="number" step="0.01" value={item.unit_price} onChange={e => setItem(idx, 'unit_price', e.target.value)}
                        placeholder="0.00" className="w-full border rounded-lg px-2 py-1.5 text-sm bg-white" />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-0.5 block">Adet</label>
                      <input type="number" min="1" value={item.quantity} onChange={e => setItem(idx, 'quantity', e.target.value)}
                        className="w-full border rounded-lg px-2 py-1.5 text-sm bg-white" />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 mb-0.5 block">KDV %</label>
                      <select value={item.kdv_rate} onChange={e => setItem(idx, 'kdv_rate', e.target.value)}
                        className="w-full border rounded-lg px-2 py-1.5 text-sm bg-white">
                        {['0','1','10','18','20'].map(v => <option key={v} value={v}>%{v}</option>)}
                      </select>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <button onClick={() => setItems(p => [...p, { ...EMPTY_ITEM }])}
              className="mt-2 w-full border-2 border-dashed border-gray-300 text-gray-500 rounded-xl py-2 text-sm hover:bg-gray-50 flex items-center justify-center gap-2">
              <Plus size={14}/>Kalem Ekle
            </button>
          </div>

          <div className="bg-indigo-50 rounded-xl p-3 text-sm space-y-1">
            <div className="flex justify-between text-gray-600"><span>Ara Toplam</span><span>{fmt(subtotal, form.currency)}</span></div>
            <div className="flex justify-between text-gray-500"><span>KDV</span><span>{fmt(kdv, form.currency)}</span></div>
            <div className="flex justify-between font-bold border-t pt-1"><span>Toplam</span><span>{fmt(subtotal + kdv, form.currency)}</span></div>
          </div>

          <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
            placeholder="Not (opsiyonel)" rows={2} className="w-full border rounded-xl px-3 py-2 text-sm resize-none" />

          <div className="flex gap-3">
            <button onClick={handleSubmit} disabled={saving}
              className="flex-1 bg-indigo-600 text-white rounded-xl py-2.5 font-medium hover:bg-indigo-700 disabled:opacity-50">
              {saving ? 'Kaydediliyor…' : 'Sipariş Oluştur'}
            </button>
            <button onClick={onClose} className="px-6 border rounded-xl text-gray-600 hover:bg-gray-50">İptal</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Supplier Modal ───────────────────────────────────────────

function SupplierModal({ supplier, onClose, onSaved, showToast }: {
  supplier?: Supplier | null; onClose: () => void;
  onSaved: () => void; showToast: (m: string, t: string) => void;
}) {
  const [form, setForm] = useState({
    company_name: supplier?.company_name || '',
    contact_person: supplier?.contact_person || '',
    phone: supplier?.phone || '',
    email: supplier?.email || '',
    vkn: supplier?.vkn || '',
    tax_office: supplier?.tax_office || '',
    address: supplier?.address || '',
    notes: supplier?.notes || '',
    payment_term_days: supplier?.payment_term_days?.toString() || '30',
    is_active: supplier?.is_active ?? true,
  });
  const [saving, setSaving] = useState(false);

  async function handleSubmit() {
    if (!form.company_name) { showToast('Firma adı zorunlu', 'error'); return; }
    setSaving(true);
    try {
      const payload = { ...form, payment_term_days: parseInt(form.payment_term_days) || 30 };
      if (supplier) {
        await apiRequest(`/supplier/suppliers/${supplier.id}`, { method: 'PUT', body: JSON.stringify(payload) });
        showToast('Tedarikçi güncellendi', 'success');
      } else {
        await apiRequest('/supplier/suppliers', { method: 'POST', body: JSON.stringify(payload) });
        showToast('Tedarikçi eklendi', 'success');
      }
      onSaved();
    } catch (e: any) { showToast(e.message || 'Hata', 'error'); }
    finally { setSaving(false); }
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="p-4 border-b flex items-center justify-between bg-gray-50 rounded-t-2xl">
          <h2 className="font-bold text-lg">{supplier ? 'Tedarikçiyi Düzenle' : 'Yeni Tedarikçi'}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl">✕</button>
        </div>
        <div className="p-4 space-y-3">
          <input value={form.company_name} onChange={e => setForm(f => ({ ...f, company_name: e.target.value }))}
            placeholder="Firma Adı *" className="w-full border rounded-xl px-3 py-2 text-sm" />
          <div className="grid grid-cols-2 gap-2">
            <input value={form.contact_person} onChange={e => setForm(f => ({ ...f, contact_person: e.target.value }))}
              placeholder="Yetkili Kişi" className="border rounded-xl px-3 py-2 text-sm" />
            <input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
              placeholder="Telefon" className="border rounded-xl px-3 py-2 text-sm" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <input value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
              placeholder="E-posta" className="border rounded-xl px-3 py-2 text-sm" />
            <input value={form.vkn} onChange={e => setForm(f => ({ ...f, vkn: e.target.value }))}
              placeholder="VKN / TCKN" className="border rounded-xl px-3 py-2 text-sm" />
          </div>
          <input value={form.tax_office} onChange={e => setForm(f => ({ ...f, tax_office: e.target.value }))}
            placeholder="Vergi Dairesi" className="w-full border rounded-xl px-3 py-2 text-sm" />
          <textarea value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))}
            placeholder="Adres" rows={2} className="w-full border rounded-xl px-3 py-2 text-sm resize-none" />
          <div>
            <label className="text-xs text-gray-500 mb-1 block">Vade (Gün)</label>
            <input type="number" min="0" value={form.payment_term_days}
              onChange={e => setForm(f => ({ ...f, payment_term_days: e.target.value }))}
              className="w-full border rounded-xl px-3 py-2 text-sm" />
          </div>
          <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
            placeholder="Not" rows={2} className="w-full border rounded-xl px-3 py-2 text-sm resize-none" />
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.is_active} onChange={e => setForm(f => ({ ...f, is_active: e.target.checked }))} className="rounded" />
            Aktif Tedarikçi
          </label>
          <div className="flex gap-3 pt-2">
            <button onClick={handleSubmit} disabled={saving}
              className="flex-1 bg-indigo-600 text-white rounded-xl py-2.5 font-medium hover:bg-indigo-700 disabled:opacity-50">
              {saving ? 'Kaydediliyor…' : supplier ? 'Güncelle' : 'Tedarikçi Ekle'}
            </button>
            <button onClick={onClose} className="px-6 border rounded-xl text-gray-600 hover:bg-gray-50">İptal</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────

interface Props {
  currentUser: any;
  showToast: (msg: string, type: string) => void;
}

export default function SupplierView({ currentUser, showToast }: Props) {
  const [tab, setTab] = useState<'purchases' | 'suppliers'>('purchases');
  const [stats, setStats] = useState<any>(null);
  const [purchases, setPurchases] = useState<PurchaseOrder[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');
  const [search, setSearch] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<PurchaseOrder | null>(null);
  const [showPurchaseModal, setShowPurchaseModal] = useState(false);
  const [showSupplierModal, setShowSupplierModal] = useState(false);
  const [editSupplier, setEditSupplier] = useState<Supplier | null>(null);

  const canAdd = currentUser?.role === 'bayi_sahibi' || currentUser?.permissions?.includes('supplier.add');
  const canEdit = currentUser?.role === 'bayi_sahibi' || currentUser?.permissions?.includes('supplier.edit');
  const canDelete = currentUser?.role === 'bayi_sahibi' || currentUser?.permissions?.includes('supplier.delete');

  const loadAll = useCallback(async () => {
    try {
      const [s, p, sup, prods] = await Promise.all([
        apiRequest('/supplier/stats'),
        apiRequest('/supplier/purchases'),
        apiRequest('/supplier/suppliers'),
        apiRequest('/products'),
      ]);
      setStats(s);
      setPurchases(Array.isArray(p) ? p : []);
      setSuppliers(Array.isArray(sup) ? sup : []);
      const rawP = prods?.items || prods;
      setProducts(Array.isArray(rawP) ? rawP : []);
    } catch (e: any) { showToast(e.message || 'Yükleme hatası', 'error'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);
  useRefreshOnChange(loadAll);

  async function handleAction(orderId: number, action: string) {
    try {
      if (action === 'delete') {
        if (!confirm('Bu sipariş silinsin mi?')) return;
        await apiRequest(`/supplier/purchases/${orderId}`, { method: 'DELETE' });
        setSelectedOrder(null);
        showToast('Silindi', 'success');
      } else {
        await apiRequest(`/supplier/purchases/${orderId}/${action}`, { method: 'POST' });
        const labels: Record<string, string> = {
          order: 'Sipariş gönderildi', receive: 'Mal teslim alındı, stok güncellendi',
          cancel: 'İptal edildi', 'mark-paid': 'Ödendi işaretlendi',
        };
        showToast(labels[action] || 'Güncellendi', 'success');
      }
      if (selectedOrder && action !== 'delete') {
        const updated = await apiRequest(`/supplier/purchases/${orderId}`);
        setSelectedOrder(updated);
      }
      loadAll();
    } catch (e: any) { showToast(e.message || 'Hata', 'error'); }
  }

  async function handleDeleteSupplier(s: Supplier) {
    if (!confirm(`"${s.company_name}" silinsin mi?`)) return;
    try {
      await apiRequest(`/supplier/suppliers/${s.id}`, { method: 'DELETE' });
      showToast('Tedarikçi silindi', 'success');
      loadAll();
    } catch (e: any) { showToast(e.message || 'Hata', 'error'); }
  }

  const filteredPurchases = purchases.filter(o => {
    if (statusFilter && o.status !== statusFilter) return false;
    if (search && !o.order_number.toLowerCase().includes(search.toLowerCase()) &&
        !o.supplier_name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const filteredSuppliers = suppliers.filter(s =>
    !search || s.company_name.toLowerCase().includes(search.toLowerCase()) ||
    (s.contact_person || '').toLowerCase().includes(search.toLowerCase())
  );

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"/>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Toptancı / Tedarikçi</h1>
          <p className="text-sm text-gray-500 mt-0.5">Alım siparişleri, mal kabul ve toptancı borç takibi</p>
        </div>
      </div>

      {stats && <StatsBar stats={stats} />}

      <div className="flex gap-1 bg-gray-100 rounded-xl p-1 mb-5 w-fit">
        {(['purchases', 'suppliers'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-5 py-2 rounded-lg text-sm font-medium transition-colors ${tab === t ? 'bg-white text-indigo-700 shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}>
            {t === 'purchases' ? `Alımlar (${purchases.length})` : `Tedarikçiler (${suppliers.length})`}
          </button>
        ))}
      </div>

      {tab === 'purchases' && (
        <div>
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <div className="flex gap-1 flex-wrap">
              {[['', 'Tümü'], ...Object.entries(STATUS_CONFIG).map(([k, v]) => [k, v.label])].map(([k, l]) => (
                <button key={k} onClick={() => setStatusFilter(k)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${statusFilter === k ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                  {l}
                </button>
              ))}
            </div>
            <div className="flex-1 min-w-48 relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"/>
              <input value={search} onChange={e => setSearch(e.target.value)}
                placeholder="Sipariş no veya tedarikçi ara…" className="w-full pl-8 pr-3 py-2 border rounded-xl text-sm" />
            </div>
            {canAdd && (
              <button onClick={() => setShowPurchaseModal(true)}
                className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-indigo-700">
                <Plus size={15}/>Yeni Alım
              </button>
            )}
          </div>

          <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-left p-3 text-xs font-semibold text-gray-500">Sipariş No</th>
                  <th className="text-left p-3 text-xs font-semibold text-gray-500">Tedarikçi</th>
                  <th className="text-left p-3 text-xs font-semibold text-gray-500">Tarih / Beklenen</th>
                  <th className="text-right p-3 text-xs font-semibold text-gray-500">Tutar</th>
                  <th className="text-left p-3 text-xs font-semibold text-gray-500">Durum</th>
                  <th className="text-left p-3 text-xs font-semibold text-gray-500">Ödeme</th>
                </tr>
              </thead>
              <tbody>
                {filteredPurchases.length === 0 ? (
                  <tr><td colSpan={6} className="text-center py-12 text-gray-400 text-sm">Alım siparişi bulunamadı</td></tr>
                ) : filteredPurchases.map(o => (
                  <tr key={o.id} onClick={() => setSelectedOrder(o)}
                    className="border-t cursor-pointer hover:bg-indigo-50 transition-colors">
                    <td className="p-3"><span className="font-mono text-sm font-medium text-indigo-700">{o.order_number}</span></td>
                    <td className="p-3"><p className="text-sm font-medium">{o.supplier_name}</p></td>
                    <td className="p-3 text-xs text-gray-500">
                      <p>{o.created_at ? new Date(o.created_at).toLocaleDateString('tr-TR') : '—'}</p>
                      {o.expected_date && <p className="mt-0.5">Beklenen: {o.expected_date}</p>}
                    </td>
                    <td className="p-3 text-right font-bold text-sm">{fmt(o.total_amount, o.currency)}</td>
                    <td className="p-3"><StatusBadge status={o.status}/></td>
                    <td className="p-3">
                      {o.is_paid
                        ? <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-medium">✓ Ödendi</span>
                        : o.status === 'received'
                          ? <span className="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-medium">Bekliyor</span>
                          : <span className="text-xs text-gray-400">—</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'suppliers' && (
        <div>
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <div className="flex-1 min-w-48 relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"/>
              <input value={search} onChange={e => setSearch(e.target.value)}
                placeholder="Tedarikçi ara…" className="w-full pl-8 pr-3 py-2 border rounded-xl text-sm" />
            </div>
            {canAdd && (
              <button onClick={() => { setEditSupplier(null); setShowSupplierModal(true); }}
                className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-indigo-700">
                <Plus size={15}/>Yeni Tedarikçi
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredSuppliers.length === 0 ? (
              <div className="col-span-3 text-center py-12 text-gray-400 text-sm">Tedarikçi bulunamadı</div>
            ) : filteredSuppliers.map(s => (
              <div key={s.id} className={`bg-white rounded-2xl border-2 p-4 ${!s.is_active ? 'opacity-60' : ''} ${s.total_payable > 0 ? 'border-amber-200' : 'border-gray-200'}`}>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-gray-900 truncate">{s.company_name}</h3>
                    {s.contact_person && <p className="text-xs text-gray-500 mt-0.5">{s.contact_person}</p>}
                  </div>
                  <div className="flex gap-1 shrink-0 ml-2">
                    {canEdit && <button onClick={() => { setEditSupplier(s); setShowSupplierModal(true); }} className="p-1.5 text-gray-400 hover:text-indigo-600 rounded-lg hover:bg-indigo-50"><Edit3 size={14}/></button>}
                    {canDelete && <button onClick={() => handleDeleteSupplier(s)} className="p-1.5 text-gray-400 hover:text-red-600 rounded-lg hover:bg-red-50"><Trash2 size={14}/></button>}
                  </div>
                </div>
                <div className="space-y-0.5 text-xs text-gray-500 mb-3">
                  {s.phone && <p className="flex items-center gap-1.5"><Phone size={11}/>{s.phone}</p>}
                  {s.email && <p className="flex items-center gap-1.5"><Mail size={11}/>{s.email}</p>}
                  {s.vkn && <p className="flex items-center gap-1.5"><Tag size={11}/>VKN: {s.vkn}{s.tax_office ? ` / ${s.tax_office}` : ''}</p>}
                </div>
                <div className="grid grid-cols-2 gap-2 pt-3 border-t text-sm">
                  <div><p className="text-xs text-gray-400">Ödenmemiş Borç</p><p className={`font-bold ${s.total_payable > 0 ? 'text-amber-600' : 'text-gray-400'}`}>{fmt(s.total_payable)}</p></div>
                  <div><p className="text-xs text-gray-400">Toplam Alım</p><p className="font-bold">{s.order_count}</p></div>
                  <div><p className="text-xs text-gray-400">Vade</p><p className="font-medium">{s.payment_term_days} gün</p></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {selectedOrder && (
        <PurchaseDetailModal order={selectedOrder} onClose={() => setSelectedOrder(null)} onAction={handleAction} />
      )}
      {showPurchaseModal && (
        <PurchaseModal suppliers={suppliers} products={products}
          onClose={() => setShowPurchaseModal(false)}
          onSaved={() => { setShowPurchaseModal(false); loadAll(); }}
          showToast={showToast} />
      )}
      {showSupplierModal && (
        <SupplierModal supplier={editSupplier}
          onClose={() => { setShowSupplierModal(false); setEditSupplier(null); }}
          onSaved={() => { setShowSupplierModal(false); setEditSupplier(null); loadAll(); }}
          showToast={showToast} />
      )}
    </div>
  );
}
