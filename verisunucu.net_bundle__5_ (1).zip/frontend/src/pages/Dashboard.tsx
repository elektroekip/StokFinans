import { useState, useEffect, useCallback } from "react";
import { dashboardApi, authApi } from "../lib/api";
import { useAuth } from "../context/AuthContext";
import { exportStokUyarilari } from "../utils/exportExcel";
import { useRefreshOnChange } from "../hooks/useRefreshOnChange";

const getBannerKey = (userId?: number) =>
  `verificationBannerDismissed_${userId ?? "guest"}`;

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return "Günaydın";
  if (h < 18) return "İyi Günler";
  return "İyi Akşamlar";
}

function getTodayLabel() {
  return new Date().toLocaleDateString("tr-TR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

const MOTIVATIONAL = [
  "Bugün harika satışlar için hazır mısın?",
  "Her büyük başarı küçük adımlarla başlar.",
  "Stoklarını takip et, kazancını artır!",
  "Bugün de işler yolunda — devam et!",
  "Başarılı bir gün seni bekliyor.",
];

function getMotivational() {
  return MOTIVATIONAL[new Date().getDay() % MOTIVATIONAL.length];
}

const SEVERITY_TR: Record<string, string> = {
  critical: "Kritik",
  medium: "Orta",
  low: "Düşük",
};

export default function Dashboard() {
  const [stats, setStats] = useState<any>(null);
  const [alerts, setAlerts] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const [days, setDays] = useState(30);
  const [showVerificationBanner, setShowVerificationBanner] = useState(false);
  const [resendLoading, setResendLoading] = useState(false);
  const [resendDone, setResendDone] = useState(false);
  const [resendError, setResendError] = useState("");

  const { user, refreshUser } = useAuth();

  useEffect(() => {
    if (user?.is_email_verified === true) {
      setShowVerificationBanner(false);
      return;
    }
    if (
      user?.is_email_verified === false &&
      !sessionStorage.getItem(getBannerKey(user?.id))
    ) {
      setShowVerificationBanner(true);
    }
  }, [user]);

  useEffect(() => {
    if (user?.is_email_verified !== false) return;
    let cancelled = false;
    const check = () => {
      if (cancelled) return;
      if (document.visibilityState !== "visible") return;
      refreshUser(true).catch(() => {});
    };
    check();
    const intervalId = window.setInterval(check, 30000);
    window.addEventListener("focus", check);
    document.addEventListener("visibilitychange", check);
    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
      window.removeEventListener("focus", check);
      document.removeEventListener("visibilitychange", check);
    };
  }, [user?.is_email_verified, refreshUser]);

  const handleDismissBanner = () => {
    sessionStorage.setItem(getBannerKey(user?.id), "1");
    setShowVerificationBanner(false);
  };

  const handleResendVerification = async () => {
    if (resendLoading || resendDone) return;
    setResendError("");
    try {
      setResendLoading(true);
      await authApi.resendVerification();
      setResendDone(true);
      sessionStorage.setItem(getBannerKey(user?.id), "1");
      setShowVerificationBanner(false);
    } catch {
      setResendError("E-posta gönderilemedi, lütfen tekrar deneyin.");
    } finally {
      setResendLoading(false);
    }
  };

  const loadDashboard = useCallback(async (silent = false) => {
    try {
      if (!silent) setIsLoading(true);
      setError("");
      const [statsResponse, alertsResponse] = await Promise.all([
        dashboardApi.getStats(days),
        dashboardApi.getCriticalStockAlerts(),
      ]);
      setStats(statsResponse.data);
      setAlerts(alertsResponse.data);
    } catch (err: any) {
      setError("Dashboard yüklenirken hata oluştu");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [days]);

  useEffect(() => { loadDashboard(); }, [loadDashboard]);
  useRefreshOnChange(loadDashboard);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50 dark:bg-slate-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-500 dark:text-slate-400">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900 p-4 md:p-8 space-y-6">

      {/* Email Doğrulama Banner */}
      {showVerificationBanner && (
        <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-700 rounded-xl px-4 py-3">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-1 min-w-0">
              <span className="text-amber-500 text-xl flex-shrink-0">&#9888;</span>
              <p className="text-amber-800 dark:text-amber-300 text-sm">
                E-posta adresiniz henüz doğrulanmadı. Lütfen gelen kutunuzu kontrol edin.
              </p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                onClick={handleResendVerification}
                disabled={resendLoading}
                className="text-sm font-semibold text-amber-700 bg-amber-100 hover:bg-amber-200 disabled:opacity-60 border border-amber-300 rounded-lg px-3 py-1 transition-colors whitespace-nowrap"
              >
                {resendLoading ? "Gönderiliyor..." : "Yeniden gönder"}
              </button>
              <button
                onClick={handleDismissBanner}
                className="text-amber-500 hover:text-amber-700 text-lg font-bold leading-none p-1"
                aria-label="Kapat"
              >
                &times;
              </button>
            </div>
          </div>
          {resendError && (
            <p role="alert" className="text-red-700 text-sm mt-2 pl-8">{resendError}</p>
          )}
        </div>
      )}

      {/* Error Alert */}
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-xl">
          {error}
        </div>
      )}

      {/* ── Welcome Card ────────────────────────────────────────── */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-700 p-6 md:p-8 text-white shadow-lg">
        {/* Decorative circles */}
        <div className="pointer-events-none absolute -top-10 -right-10 w-48 h-48 rounded-full bg-white/5" />
        <div className="pointer-events-none absolute -bottom-12 -left-6 w-36 h-36 rounded-full bg-white/5" />

        <p className="text-indigo-200 text-sm font-medium mb-1">{getTodayLabel()}</p>
        <h1 className="text-2xl md:text-3xl font-bold mb-1">
          {getGreeting()},{" "}
          <span className="text-white">{user?.full_name?.split(" ")[0] ?? "Hoşgeldiniz"}</span>
        </h1>
        <p className="text-indigo-200 text-sm">{getMotivational()}</p>
      </div>

      {/* ── Quick Actions ────────────────────────────────────────── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <QuickAction
          href="/products"
          icon={
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/></svg>
          }
          label="Ürün Ekle"
          color="indigo"
        />
        <QuickAction
          href="/transactions"
          icon={
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
          }
          label="Yeni Satış"
          color="emerald"
        />
        <QuickAction
          href="/products"
          icon={
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
          }
          label="Stok Güncelle"
          color="sky"
        />
        <QuickAction
          href="/debts"
          icon={
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
          }
          label="Borç Takibi"
          color="violet"
        />
      </div>

      {/* ── Days Filter + Stats ──────────────────────────────────── */}
      <div>
        {/* Segmented control */}
        <div className="flex gap-0.5 bg-slate-200 dark:bg-slate-700 rounded-xl p-1 w-fit mb-5">
          {[7, 30, 90].map((d) => (
            <button
              key={d}
              onClick={() => setDays(d)}
              className={`px-5 py-2 rounded-lg text-sm font-medium transition-all ${
                days === d
                  ? "bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm"
                  : "text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              }`}
            >
              {d} gün
            </button>
          ))}
        </div>

        {/* Stat cards */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <StatCard
              label={stats.total_products.label}
              value={stats.total_products.value}
              trend={stats.total_products.trend}
              change={stats.total_products.percentage_change}
              color="indigo"
              icon={
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/></svg>
              }
            />
            <StatCard
              label={stats.total_sales.label}
              value={`₺${stats.total_sales.value.toLocaleString("tr-TR", { maximumFractionDigits: 2 })}`}
              trend={stats.total_sales.trend}
              change={stats.total_sales.percentage_change}
              color="emerald"
              icon={
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>
              }
            />
            <StatCard
              label={stats.total_revenue.label}
              value={`₺${stats.total_revenue.value.toLocaleString("tr-TR", { maximumFractionDigits: 2 })}`}
              trend={stats.total_revenue.trend}
              change={stats.total_revenue.percentage_change}
              color="sky"
              icon={
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
              }
            />
          </div>
        )}
      </div>

      {/* ── Stock Alerts ─────────────────────────────────────────── */}
      {alerts && (
        <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700 p-6">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-indigo-500"><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/></svg>
              Stok Durumu
            </h2>
            <div className="flex items-center gap-2">
              {alerts.total_alerts > 0 && (
                <span
                  className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    alerts.priority === "high"
                      ? "bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400"
                      : alerts.priority === "medium"
                      ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-950/40 dark:text-yellow-400"
                      : "bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400"
                  }`}
                >
                  {alerts.total_alerts} uyarı
                </span>
              )}
              {alerts.alerts.length > 0 && (
                <button
                  onClick={() => exportStokUyarilari(alerts.alerts.map((a: any) => ({
                    title: a.product_name, category: a.category,
                    amount: a.current_stock, min_stock_alert: a.min_alert_level,
                  })))}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg transition text-xs"
                  title="Excel olarak indir"
                >
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                  Excel
                </button>
              )}
            </div>
          </div>

          {alerts.alerts.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-100 dark:border-slate-700">
                    <th className="text-left py-2 px-3 text-gray-500 dark:text-slate-400 font-medium">Ürün</th>
                    <th className="text-left py-2 px-3 text-gray-500 dark:text-slate-400 font-medium">Kategori</th>
                    <th className="text-center py-2 px-3 text-gray-500 dark:text-slate-400 font-medium">Stok</th>
                    <th className="text-center py-2 px-3 text-gray-500 dark:text-slate-400 font-medium">Min.</th>
                    <th className="text-center py-2 px-3 text-gray-500 dark:text-slate-400 font-medium">Eksiklik</th>
                    <th className="text-left py-2 px-3 text-gray-500 dark:text-slate-400 font-medium">Durum</th>
                  </tr>
                </thead>
                <tbody>
                  {alerts.alerts.map((alert: any) => (
                    <tr key={alert.product_id} className="border-b border-gray-50 dark:border-slate-700/50 hover:bg-gray-50 dark:hover:bg-slate-700/30 transition-colors">
                      <td className="py-3 px-3 font-medium text-gray-900 dark:text-white">{alert.product_name}</td>
                      <td className="py-3 px-3 text-gray-500 dark:text-slate-400">{alert.category}</td>
                      <td className="py-3 px-3 text-center font-semibold text-gray-900 dark:text-white">{alert.current_stock}</td>
                      <td className="py-3 px-3 text-center text-gray-500 dark:text-slate-400">{alert.min_alert_level}</td>
                      <td className="py-3 px-3 text-center text-red-600 dark:text-red-400 font-bold">
                        -{alert.shortage}
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                            alert.severity === "critical"
                              ? "bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400"
                              : alert.severity === "medium"
                              ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-950/40 dark:text-yellow-400"
                              : "bg-blue-100 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400"
                          }`}
                        >
                          {SEVERITY_TR[alert.severity] ?? alert.severity}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="flex items-center gap-4 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800 rounded-xl px-5 py-4">
              <div className="w-10 h-10 rounded-full bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center shrink-0">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="text-emerald-600 dark:text-emerald-400"><polyline points="20 6 9 17 4 12"/></svg>
              </div>
              <div>
                <p className="font-semibold text-emerald-800 dark:text-emerald-300">Harika iş!</p>
                <p className="text-sm text-emerald-700 dark:text-emerald-400">Tüm stoklar sağlıklı durumda. Kritik uyarı bulunmuyor.</p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Stat Card ────────────────────────────────────────────────────

const colorMap = {
  indigo: {
    border: "border-t-indigo-500",
    iconBg: "bg-indigo-50 dark:bg-indigo-950/40",
    icon: "text-indigo-600 dark:text-indigo-400",
    up: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
    down: "bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400",
    flat: "bg-gray-100 text-gray-600 dark:bg-slate-700 dark:text-slate-400",
  },
  emerald: {
    border: "border-t-emerald-500",
    iconBg: "bg-emerald-50 dark:bg-emerald-950/40",
    icon: "text-emerald-600 dark:text-emerald-400",
    up: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
    down: "bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400",
    flat: "bg-gray-100 text-gray-600 dark:bg-slate-700 dark:text-slate-400",
  },
  sky: {
    border: "border-t-sky-500",
    iconBg: "bg-sky-50 dark:bg-sky-950/40",
    icon: "text-sky-600 dark:text-sky-400",
    up: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400",
    down: "bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400",
    flat: "bg-gray-100 text-gray-600 dark:bg-slate-700 dark:text-slate-400",
  },
};

interface StatCardProps {
  label: string;
  value: string | number;
  trend?: "up" | "down" | "flat";
  change?: number;
  color: keyof typeof colorMap;
  icon: React.ReactNode;
}

function StatCard({ label, value, trend = "flat", change = 0, color, icon }: StatCardProps) {
  const c = colorMap[color];
  const trendClass = trend === "up" ? c.up : trend === "down" ? c.down : c.flat;
  const trendArrow = trend === "up" ? "↑" : trend === "down" ? "↓" : "→";

  return (
    <div className={`bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700 border-t-4 ${c.border} p-5 flex items-start gap-4`}>
      <div className={`w-11 h-11 rounded-xl ${c.iconBg} ${c.icon} flex items-center justify-center shrink-0`}>
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-gray-500 dark:text-slate-400 text-xs font-medium mb-1 truncate">{label}</p>
        <p className="text-2xl font-bold text-gray-900 dark:text-white mb-2 truncate">{value}</p>
        {change !== 0 && (
          <span className={`inline-flex items-center gap-0.5 text-xs font-semibold px-2 py-0.5 rounded-full ${trendClass}`}>
            {trendArrow} {Math.abs(change)}%
          </span>
        )}
      </div>
    </div>
  );
}

// ── Quick Action ────────────────────────────────────────────────

const qaColorMap = {
  indigo: "bg-indigo-50 dark:bg-indigo-950/30 hover:bg-indigo-100 dark:hover:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 border-indigo-100 dark:border-indigo-800",
  emerald: "bg-emerald-50 dark:bg-emerald-950/30 hover:bg-emerald-100 dark:hover:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border-emerald-100 dark:border-emerald-800",
  sky: "bg-sky-50 dark:bg-sky-950/30 hover:bg-sky-100 dark:hover:bg-sky-950/50 text-sky-700 dark:text-sky-300 border-sky-100 dark:border-sky-800",
  violet: "bg-violet-50 dark:bg-violet-950/30 hover:bg-violet-100 dark:hover:bg-violet-950/50 text-violet-700 dark:text-violet-300 border-violet-100 dark:border-violet-800",
};

interface QuickActionProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  color: keyof typeof qaColorMap;
}

function QuickAction({ href, icon, label, color }: QuickActionProps) {
  return (
    <a
      href={href}
      className={`flex items-center gap-3 px-4 py-3.5 rounded-xl border font-medium text-sm transition-colors ${qaColorMap[color]}`}
    >
      {icon}
      {label}
    </a>
  );
}
