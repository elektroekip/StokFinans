/**
 * Faz 3 — Bayi paneli için yeni view'lar:
 *   - WarrantyManagementView: garanti belgeleri CRUD (sidebar'a "Garanti Belgeleri")
 *   - DebtorLinkModal: bir müşteri için public borç linki üret/listele
 *   - PublicWarrantyPage: müşterinin tarayıcıdan açtığı garanti detayı (auth yok)
 *   - PublicDebtorPage: müşterinin tarayıcıdan açtığı cari ekstresi (auth yok)
 *
 * App.tsx içinde:
 *   - URL path /garanti/<token> veya /borc/<token> ise direkt public sayfa render edilir.
 *   - Sidebar'a "Garanti Belgeleri" tabı eklenir; activeMenu === 'warranty' ise bu view.
 *   - Müşteri listesinde her satıra "Slip Gönder" → DebtorLinkModal açılır.
 */
import { useState, useEffect, useRef, FormEvent } from 'react';
import { useRefreshOnChange } from './hooks/useRefreshOnChange';
import { withSilentRefresh } from './lib/refreshBus';
import axios from 'axios';
import {
  Shield, Plus, Search, X, Send, QrCode, Trash2, Edit2, RefreshCw,
  CheckCircle2, XCircle, Clock, Link2, Copy, MessageCircle, Calendar,
  Phone, User as UserIcon, Package as PackageIcon, FileText, AlertTriangle,
} from 'lucide-react';

import { api } from './lib/api';
import { ZoomImg } from './components/ZoomImg';
import { useLang, makeT } from './lib/i18n';

// ============================================================
// API SHAPES
// ============================================================

export interface WarrantyOut {
  id: number;
  product_name: string;
  product_image_url: string | null;
  customer_name: string;
  customer_phone: string | null;
  duration_label: string;
  duration_days: number;
  start_date: string;
  end_date: string;
  public_token: string;
  notes: string | null;
  created_at: string;
  updated_at: string;
  is_expired: boolean;
  days_remaining: number;
}

export interface DebtorLinkOut {
  id: number;
  customer_name: string;
  public_token: string;
  public_url: string;
  wa_url: string | null;
  expires_at: string | null;
  last_viewed_at: string | null;
  view_count: number;
  created_at: string;
}

const DURATION_OPTIONS = ['1 ay', '3 ay', '6 ay', '7 ay', '1 yıl', '2 yıl', '3 yıl', 'Özel'];

const fmtDate = (iso: string) => {
  try {
    return new Date(iso).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  } catch {
    return iso;
  }
};

const fmtDateTime = (iso: string) => {
  try {
    return new Date(iso).toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  } catch {
    return iso;
  }
};

// ============================================================
// i18n DICTIONARY
// ============================================================

const DICT: Record<string, string> = {
  // Warranty management
  'Garanti Belgeleri': 'Warranty Documents',
  'Yeni Garanti': 'New Warranty',
  'Garanti belgesi silindi': 'Warranty document deleted',
  'Silinemedi': 'Could not delete',
  'QR oluşturulamadı': 'Could not generate QR',
  'Kaydedildi': 'Saved',
  'Kaydedilemedi': 'Could not save',
  'Garantiler yüklenemedi': 'Could not load warranties',
  'Link oluşturulamadı': 'Could not create link',
  'Ürün adı zorunlu': 'Product name required',
  'Müşteri adı zorunlu': 'Customer name required',
  'Özel süre için gün sayısı zorunlu': 'Day count required for custom duration',
  'Ürün Adı': 'Product Name',
  'Ürün Adı *': 'Product Name *',
  'Müşteri Adı': 'Customer Name',
  'Müşteri Adı Soyadı *': 'Customer Full Name *',
  'Garanti Süresi': 'Warranty Period',
  'Garanti Süresi (etikette gösterilir)': 'Warranty Period (shown on label)',
  'Garanti Durumu': 'Warranty Status',
  'Geçerli': 'Valid',
  'Süresi Dolmuş': 'Expired',
  'Yakında Dolacak': 'Expiring Soon',
  'QR Kod': 'QR Code',
  'WhatsApp': 'WhatsApp',
  'Düzenle': 'Edit',
  'Sil': 'Delete',
  'Kaydet': 'Save',
  'İptal': 'Cancel',
  'Yükleniyor...': 'Loading...',
  'Henüz garanti belgesi yok': 'No warranty documents yet',
  'Resim 10 MB\'dan büyük olamaz': 'Image cannot exceed 10 MB',
  'Aktif': 'Active',
  'Süresi Bitenler': 'Expired',
  'Tümü': 'All',
  'Ara': 'Search',
  'Yenile': 'Refresh',
  'Ürün/müşteri/telefon ara...': 'Search product/customer/phone...',
  'Müşterilere verdiğiniz ürünlerin garanti belgelerini yönetin, QR ile takip ettirin, WhatsApp ile gönderin.':
    'Manage warranty documents for products you give to customers, track with QR, send via WhatsApp.',
  'Bu kategoride garanti belgesi yok. Yukarıdan "Yeni Garanti" ile ekleyebilirsiniz.':
    'No warranty documents in this category. Add one with "New Warranty" above.',
  'Süresi Bitti': 'Expired',
  'gün kaldı': 'days left',
  'QR': 'QR',
  'Gönder': 'Send',
  'Garanti QR Kodu': 'Warranty QR Code',
  'Müşteri bu QR\'ı tarayarak veya doğrudan tıklayarak garanti durumunu anlık görebilir.':
    'The customer can scan this QR or click it directly to see the warranty status in real time.',
  'Garanti Belgesini Gönder': 'Send Warranty Document',
  'Garanti Belgesini Düzenle': 'Edit Warranty Document',
  'Yeni Garanti Belgesi': 'New Warranty Document',
  'Ürün Resmi': 'Product Image',
  'Müşteri\'nin garanti sayfasında göreceği görsel. Max 10 MB.': 'The image the customer will see on the warranty page. Max 10 MB.',
  'Telefon (opsiyonel)': 'Phone (optional)',
  'Gün Sayısı *': 'Day Count *',
  'Başlangıç Tarihi': 'Start Date',
  'Notlar (opsiyonel)': 'Notes (optional)',
  'Kaydediliyor...': 'Saving...',
  'Güncelle': 'Update',
  'Oluştur': 'Create',
  // Debtor links
  'Linkler yüklenemedi': 'Could not load links',
  'Borç Slip Linki — ': 'Debt Slip Link — ',
  'Link Süresi': 'Link Duration',
  'Oluşturuluyor...': 'Creating...',
  'Yeni Link Oluştur': 'Create New Link',
  'Mevcut Linkler': 'Existing Links',
  'Henüz oluşturulmuş link yok.': 'No links created yet.',
  'Link kopyalandı': 'Link copied',
  'Kopyalandı': 'Copied',
  'Kopyalanamadı': 'Could not copy',
  'Kopyala': 'Copy',
  'Linki Kopyala': 'Copy Link',
  'Link oluşturuldu': 'Link created',
  'Link silindi': 'Link deleted',
  'Bu linki silmek istediğinizden emin misiniz?': 'Are you sure you want to delete this link?',
  'süresiz': 'no expiry',
  'Süresi Bitti': 'Expired',
  'Görüntülenme: ': 'Views: ',
  // ShareModal
  'Public Link (her yerde paylaşılabilir)': 'Public Link (shareable anywhere)',
  'Mesaj Metni': 'Message Text',
  'WhatsApp ile Aç': 'Open in WhatsApp',
  'Müşteri telefonu yok — link kopyalayın.': 'No customer phone — copy the link.',
  'Kapat': 'Close',
  // PublicWarrantyPage
  'Garanti Belgesi': 'Warranty Document',
  'Belge Bulunamadı': 'Document Not Found',
  'Süresi Bitmiş': 'Expired',
  'Aktif Garanti': 'Active Warranty',
  'Ürün': 'Product',
  'Müşteri': 'Customer',
  'Garanti Süresi': 'Warranty Period',
  'Başlangıç': 'Start',
  'Bitiş': 'End',
  'Kalan Süre': 'Remaining',
  'Bayi': 'Dealer',
  'Bayi Telefon': 'Dealer Phone',
  'Notlar': 'Notes',
  'Garanti belgesi bulunamadı.': 'Warranty document not found.',
  // PublicDebtorPage
  'Cari Hesap Ekstresi': 'Account Statement',
  'Toplam Borç': 'Total Debt',
  'Toplam Ödeme': 'Total Payment',
  'Net Bakiye': 'Net Balance',
  'Erişilemiyor': 'Inaccessible',
  'Bu linkin süresi dolmuş. Bayinizden yeni bir link talep ediniz.': 'This link has expired. Request a new link from your dealer.',
  'Hesap bilgisi alınamadı.': 'Could not retrieve account information.',
  'Henüz işlem yok.': 'No transactions yet.',
  'Son İşlemler': 'Recent Transactions',
  '15s\'de bir yenilenir': 'refreshes every 15s',
  'Sorularınız için bayinizi arayın: ': 'For questions, call your dealer: ',
  'garanti silmek istediğinizden emin misiniz?': 'are you sure you want to delete this warranty?',
  // confirm dialog (inline string interpolation handled in code)
  'garanti belgesini silmek istediğinizden emin misiniz?': 'warranty document — are you sure you want to delete it?',
};

// ============================================================
// WARRANTY MANAGEMENT VIEW (Bayi paneli)
// ============================================================

interface WarrantyMgrProps {
  showToast: (msg: string, type?: 'success' | 'error' | 'warning') => void;
}

export function WarrantyManagementView({ showToast }: WarrantyMgrProps) {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const [items, setItems] = useState<WarrantyOut[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'active' | 'expired' | 'all'>('active');
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<WarrantyOut | null>(null);
  const [showQr, setShowQr] = useState<{ w: WarrantyOut; url: string } | null>(null);
  const [showShare, setShowShare] = useState<{ w: WarrantyOut; text: string; wa_url: string | null; public_url: string } | null>(null);

  const load = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const res = await api.get<WarrantyOut[]>('/warranty', {
        params: { status: tab, q: search || undefined },
      });
      setItems(res.data);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || t('Garantiler yüklenemedi'), 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);
  useRefreshOnChange(load);

  const handleSearch = (e: FormEvent) => {
    e.preventDefault();
    load();
  };

  const remove = async (w: WarrantyOut) => {
    if (!confirm(`"${w.product_name}" garanti belgesini silmek istediğinizden emin misiniz?`)) return;
    try {
      await api.delete(`/warranty/${w.id}`);
      showToast(t('Garanti belgesi silindi'), 'success');
      load();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || t('Silinemedi'), 'error');
    }
  };

  const openQr = async (w: WarrantyOut) => {
    try {
      const res = await api.get(`/warranty/${w.id}/qr.png`, {
        params: { base_url: window.location.origin },
        responseType: 'blob',
      });
      const url = URL.createObjectURL(res.data);
      setShowQr({ w, url });
    } catch (e: any) {
      showToast(t('QR oluşturulamadı'), 'error');
    }
  };

  const openShare = async (w: WarrantyOut) => {
    try {
      const fd = new FormData();
      fd.append('base_url', window.location.origin);
      const res = await api.post(`/warranty/${w.id}/whatsapp-link`, fd);
      setShowShare({ w, ...res.data });
    } catch (e: any) {
      showToast(e?.response?.data?.detail || t('Link oluşturulamadı'), 'error');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Shield className="text-indigo-500" /> {t('Garanti Belgeleri')}
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {t('Müşterilere verdiğiniz ürünlerin garanti belgelerini yönetin, QR ile takip ettirin, WhatsApp ile gönderin.')}
          </p>
        </div>
        <button
          onClick={() => { setEditing(null); setShowForm(true); }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-medium shadow"
        >
          <Plus size={18} /> {t('Yeni Garanti')}
        </button>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800 p-4">
        <div className="flex flex-wrap items-center gap-2 mb-3">
          {(['active', 'expired', 'all'] as const).map(tabKey => (
            <button
              key={tabKey}
              onClick={() => setTab(tabKey)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium ${
                tab === tabKey
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              {tabKey === 'active' ? t('Aktif') : tabKey === 'expired' ? t('Süresi Bitenler') : t('Tümü')}
            </button>
          ))}
          <form onSubmit={handleSearch} className="ml-auto flex items-center gap-2">
            <div className="relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t('Ürün/müşteri/telefon ara...')}
                className="pl-9 pr-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm w-64 text-slate-900 dark:text-white"
              />
            </div>
            <button type="submit" className="px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-sm">{t('Ara')}</button>
            <button type="button" onClick={load} className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300" title={t('Yenile')}>
              <RefreshCw size={16} />
            </button>
          </form>
        </div>

        {loading ? (
          <div className="py-12 text-center text-slate-400">{t('Yükleniyor...')}</div>
        ) : items.length === 0 ? (
          <div className="py-12 text-center text-slate-400">
            {t('Bu kategoride garanti belgesi yok. Yukarıdan "Yeni Garanti" ile ekleyebilirsiniz.')}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {items.map(w => (
              <div key={w.id} className={`rounded-xl border p-3 flex flex-col gap-2 ${
                w.is_expired
                  ? 'bg-rose-50/40 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/50'
                  : 'bg-white dark:bg-slate-800/40 border-slate-200 dark:border-slate-700'
              }`}>
                <div className="flex gap-3">
                  {w.product_image_url ? (
                    <ZoomImg src={w.product_image_url} alt={w.product_name} className="w-20 h-20 object-cover rounded-lg border border-slate-200 dark:border-slate-700" />
                  ) : (
                    <div className="w-20 h-20 rounded-lg bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-400">
                      <PackageIcon size={28} />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-slate-900 dark:text-white truncate">{w.product_name}</div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
                      <UserIcon size={12} /> {w.customer_name}
                    </div>
                    {w.customer_phone && (
                      <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1">
                        <Phone size={12} /> {w.customer_phone}
                      </div>
                    )}
                    <div className={`text-xs mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-full ${
                      w.is_expired
                        ? 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300'
                        : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300'
                    }`}>
                      {w.is_expired ? <XCircle size={12} /> : <CheckCircle2 size={12} />}
                      {w.is_expired ? t('Süresi Bitti') : `${w.days_remaining} ${t('gün kaldı')}`}
                    </div>
                  </div>
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400 flex flex-wrap gap-x-3 gap-y-1">
                  <span className="inline-flex items-center gap-1"><Clock size={12} /> {w.duration_label}</span>
                  <span className="inline-flex items-center gap-1"><Calendar size={12} /> {fmtDate(w.start_date)} → {fmtDate(w.end_date)}</span>
                </div>
                <div className="flex items-center gap-1 mt-1">
                  <button onClick={() => openQr(w)} title={t('QR Kod')} className="flex-1 inline-flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs">
                    <QrCode size={14} /> {t('QR')}
                  </button>
                  <button onClick={() => openShare(w)} title={t('WhatsApp')} className="flex-1 inline-flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 text-xs">
                    <MessageCircle size={14} /> {t('Gönder')}
                  </button>
                  <button onClick={() => { setEditing(w); setShowForm(true); }} title={t('Düzenle')} className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">
                    <Edit2 size={14} />
                  </button>
                  <button onClick={() => remove(w)} title={t('Sil')} className="p-1.5 rounded-lg bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showForm && (
        <WarrantyFormModal
          editing={editing}
          onClose={() => setShowForm(false)}
          onSaved={() => { setShowForm(false); load(); showToast(t('Kaydedildi'), 'success'); }}
          showToast={showToast}
        />
      )}
      {showQr && (
        <Modal onClose={() => { URL.revokeObjectURL(showQr.url); setShowQr(null); }} title={t('Garanti QR Kodu')}>
          <div className="flex flex-col items-center gap-3 p-2">
            <img src={showQr.url} alt="QR" className="w-64 h-64 bg-white p-2 rounded-lg" />
            <div className="text-xs text-slate-500 dark:text-slate-400 text-center break-all">
              {t('Müşteri bu QR\'ı tarayarak veya doğrudan tıklayarak garanti durumunu anlık görebilir.')}
            </div>
            <a
              href={`${window.location.origin}/garanti/${showQr.w.public_token}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-indigo-600 dark:text-indigo-400 underline break-all text-center"
            >
              {window.location.origin}/garanti/{showQr.w.public_token}
            </a>
          </div>
        </Modal>
      )}
      {showShare && (
        <ShareModal data={showShare} onClose={() => setShowShare(null)} showToast={showToast} />
      )}
    </div>
  );
}

// ============================================================
// WARRANTY FORM MODAL
// ============================================================

interface FormProps {
  editing: WarrantyOut | null;
  onClose: () => void;
  onSaved: () => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'warning') => void;
}

function WarrantyFormModal({ editing, onClose, onSaved, showToast }: FormProps) {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const isCustom = editing?.duration_label === 'Özel';
  const [productName, setProductName] = useState(editing?.product_name || '');
  const [customerName, setCustomerName] = useState(editing?.customer_name || '');
  const [customerPhone, setCustomerPhone] = useState(editing?.customer_phone || '');
  const [durationLabel, setDurationLabel] = useState(editing?.duration_label || '1 yıl');
  const [customDays, setCustomDays] = useState<number>(isCustom ? (editing?.duration_days || 30) : 30);
  const [startDate, setStartDate] = useState(
    editing?.start_date ? new Date(editing.start_date).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10)
  );
  const [notes, setNotes] = useState(editing?.notes || '');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(editing?.product_image_url || null);
  const [saving, setSaving] = useState(false);

  const handleImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 10 * 1024 * 1024) {
      showToast(t('Resim 10 MB\'dan büyük olamaz'), 'error');
      return;
    }
    setImageFile(f);
    setImagePreview(URL.createObjectURL(f));
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!productName.trim()) { showToast(t('Ürün adı zorunlu'), 'error'); return; }
    if (!customerName.trim()) { showToast(t('Müşteri adı zorunlu'), 'error'); return; }
    if (durationLabel === 'Özel' && (!customDays || customDays <= 0)) {
      showToast(t('Özel süre için gün sayısı zorunlu'), 'error'); return;
    }

    const fd = new FormData();
    fd.append('product_name', productName.trim());
    fd.append('customer_name', customerName.trim());
    if (customerPhone.trim()) fd.append('customer_phone', customerPhone.trim());
    fd.append('duration_label', durationLabel);
    if (durationLabel === 'Özel') fd.append('duration_days', String(customDays));
    fd.append('start_date', new Date(startDate).toISOString());
    if (notes.trim()) fd.append('notes', notes.trim());
    if (imageFile) fd.append('image', imageFile);

    setSaving(true);
    try {
      if (editing) {
        await api.put(`/warranty/${editing.id}`, fd);
      } else {
        await api.post('/warranty', fd);
      }
      onSaved();
    } catch (err: any) {
      showToast(err?.response?.data?.detail || t('Kaydedilemedi'), 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal onClose={onClose} title={editing ? t('Garanti Belgesini Düzenle') : t('Yeni Garanti Belgesi')}>
      <form onSubmit={submit} className="space-y-3">
        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">{t('Ürün Adı *')}</label>
          <input value={productName} onChange={e => setProductName(e.target.value)} required className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white" />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">{t('Ürün Resmi')}</label>
          <div className="flex items-center gap-3">
            {imagePreview && <img src={imagePreview} alt="" className="w-16 h-16 object-cover rounded-lg border border-slate-200 dark:border-slate-700" />}
            <input type="file" accept="image/*" onChange={handleImage} className="text-xs text-slate-600 dark:text-slate-300" />
          </div>
          <p className="text-[11px] text-slate-400 mt-1">{t('Müşteri\'nin garanti sayfasında göreceği görsel. Max 10 MB.')}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">{t('Müşteri Adı Soyadı *')}</label>
            <input value={customerName} onChange={e => setCustomerName(e.target.value)} required className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white" />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">{t('Telefon (opsiyonel)')}</label>
            <input value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} placeholder="05xx xxx xx xx" className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white" />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">{t('Garanti Süresi')}</label>
            <select value={durationLabel} onChange={e => setDurationLabel(e.target.value)} className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white">
              {DURATION_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
            </select>
          </div>
          {durationLabel === 'Özel' && (
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">{t('Gün Sayısı *')}</label>
              <input type="number" min={1} max={36500} value={customDays} onChange={e => setCustomDays(Number(e.target.value))} required className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white" />
            </div>
          )}
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">{t('Başlangıç Tarihi')}</label>
            <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white" />
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Notlar (opsiyonel)</label>
          <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white" />
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <button type="button" onClick={onClose} className="px-4 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">İptal</button>
          <button type="submit" disabled={saving} className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-medium">
            {saving ? 'Kaydediliyor...' : editing ? 'Güncelle' : 'Oluştur'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

// ============================================================
// DEBTOR LINK MODAL (müşteri için anlık borç slip linki)
// ============================================================

interface DebtorLinkModalProps {
  customerName: string;
  onClose: () => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'warning') => void;
}

export function DebtorLinkModal({ customerName, onClose, showToast }: DebtorLinkModalProps) {
  const [expiresIn, setExpiresIn] = useState<number>(7);
  const [creating, setCreating] = useState(false);
  const [links, setLinks] = useState<DebtorLinkOut[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const res = await api.get<DebtorLinkOut[]>('/finance/debtor-links', {
        params: { customer_name: customerName, base_url: window.location.origin },
      });
      setLinks(res.data);
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Linkler yüklenemedi', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);
  useRefreshOnChange(load);

  const create = async () => {
    setCreating(true);
    try {
      await api.post<DebtorLinkOut>('/finance/debtor-links', {
        customer_name: customerName,
        expires_in_days: expiresIn || null,
        base_url: window.location.origin,
      });
      showToast('Link oluşturuldu', 'success');
      load();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Link oluşturulamadı', 'error');
    } finally {
      setCreating(false);
    }
  };

  const remove = async (id: number) => {
    if (!confirm('Bu linki silmek istediğinizden emin misiniz?')) return;
    try {
      await api.delete(`/finance/debtor-links/${id}`);
      showToast('Link silindi');
      load();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || 'Silinemedi', 'error');
    }
  };

  const copy = (text: string) => {
    navigator.clipboard?.writeText(text).then(
      () => showToast('Kopyalandı'),
      () => showToast('Kopyalanamadı', 'error'),
    );
  };

  return (
    <Modal onClose={onClose} title={`Borç Slip Linki — ${customerName}`} wide>
      <div className="space-y-4">
        <div className="rounded-xl border border-indigo-200 dark:border-indigo-900/50 bg-indigo-50/50 dark:bg-indigo-950/20 p-3">
          <div className="text-sm text-slate-700 dark:text-slate-200 mb-2">
            Bu müşteriye özel anlık borç ekstresi linki oluşturun. Link açıldığında müşteri kendi borcunu, ödemelerini ve net bakiyesini canlı olarak görür (her 15 saniyede otomatik yenilenir).
          </div>
          <div className="flex flex-wrap items-end gap-2">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Link Süresi</label>
              <select value={expiresIn} onChange={e => setExpiresIn(Number(e.target.value))} className="px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm">
                <option value={1}>1 gün</option>
                <option value={7}>7 gün</option>
                <option value={30}>30 gün</option>
                <option value={90}>90 gün</option>
                <option value={0}>Süresiz</option>
              </select>
            </div>
            <button onClick={create} disabled={creating} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-sm font-medium">
              <Link2 size={16} /> {creating ? 'Oluşturuluyor...' : 'Yeni Link Oluştur'}
            </button>
          </div>
        </div>

        <div>
          <div className="text-xs uppercase tracking-wide text-slate-500 dark:text-slate-400 mb-2 flex items-center gap-2">
            <Clock size={12} /> Mevcut Linkler
          </div>
          {loading ? (
            <div className="py-6 text-center text-slate-400">Yükleniyor...</div>
          ) : links.length === 0 ? (
            <div className="py-6 text-center text-slate-400 text-sm">Henüz oluşturulmuş link yok.</div>
          ) : (
            <div className="space-y-2">
              {links.map(l => {
                const isExpired = l.expires_at ? new Date(l.expires_at) < new Date() : false;
                return (
                  <div key={l.id} className={`rounded-lg border p-3 ${
                    isExpired
                      ? 'bg-rose-50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/50'
                      : 'bg-white dark:bg-slate-800/40 border-slate-200 dark:border-slate-700'
                  }`}>
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                        <Calendar size={12} /> {fmtDateTime(l.created_at)}
                        {l.expires_at ? (
                          <span className={isExpired ? 'text-rose-600' : ''}>
                            {' '}— bitiş: {fmtDateTime(l.expires_at)}
                          </span>
                        ) : (
                          <span> — süresiz</span>
                        )}
                        {isExpired && <span className="ml-2 inline-flex items-center gap-1 text-rose-600"><AlertTriangle size={12} /> Süresi Bitti</span>}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        Görüntülenme: {l.view_count}
                        {l.last_viewed_at && ` (son: ${fmtDateTime(l.last_viewed_at)})`}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <input readOnly value={l.public_url} className="flex-1 px-2 py-1.5 rounded bg-slate-100 dark:bg-slate-900 text-xs text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700" />
                      <button onClick={() => copy(l.public_url)} title="Linki Kopyala" className="p-1.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200">
                        <Copy size={14} />
                      </button>
                      {l.wa_url && (
                        <a href={l.wa_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 px-2 py-1.5 rounded bg-emerald-500 hover:bg-emerald-600 text-white text-xs">
                          <MessageCircle size={14} /> WhatsApp
                        </a>
                      )}
                      <button onClick={() => remove(l.id)} title="Sil" className="p-1.5 rounded bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
}

// ============================================================
// SHARE MODAL (Warranty WhatsApp link)
// ============================================================

interface ShareModalProps {
  data: { w: WarrantyOut; text: string; wa_url: string | null; public_url: string };
  onClose: () => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'warning') => void;
}

function ShareModal({ data, onClose, showToast }: ShareModalProps) {
  const copy = (txt: string) => {
    navigator.clipboard?.writeText(txt).then(
      () => showToast('Kopyalandı'),
      () => showToast('Kopyalanamadı', 'error'),
    );
  };
  return (
    <Modal onClose={onClose} title="Garanti Belgesini Gönder">
      <div className="space-y-3">
        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Public Link (her yerde paylaşılabilir)</label>
          <div className="flex items-center gap-2">
            <input readOnly value={data.public_url} className="flex-1 px-2 py-1.5 rounded bg-slate-100 dark:bg-slate-900 text-xs text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700" />
            <button onClick={() => copy(data.public_url)} className="p-1.5 rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200" title="Kopyala">
              <Copy size={14} />
            </button>
          </div>
        </div>
        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Mesaj Metni</label>
          <textarea readOnly value={data.text} rows={6} className="w-full px-2 py-1.5 rounded bg-slate-100 dark:bg-slate-900 text-xs text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700" />
        </div>
        <div className="flex justify-end gap-2 pt-2">
          {data.wa_url ? (
            <a href={data.wa_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium">
              <MessageCircle size={16} /> WhatsApp ile Aç
            </a>
          ) : (
            <span className="text-xs text-slate-500 dark:text-slate-400 self-center">Müşteri telefonu yok — link kopyalayın.</span>
          )}
          <button onClick={onClose} className="px-4 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-sm">Kapat</button>
        </div>
      </div>
    </Modal>
  );
}

// ============================================================
// MODAL HELPER
// ============================================================

function Modal({ children, onClose, title, wide }: { children: React.ReactNode; onClose: () => void; title: string; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className={`bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full ${wide ? 'max-w-3xl' : 'max-w-xl'} my-8`}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800">
          <h3 className="text-base font-semibold text-slate-900 dark:text-white">{title}</h3>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"><X size={18} /></button>
        </div>
        <div className="p-4">
          {children}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// PUBLIC WARRANTY PAGE (auth yok)
// ============================================================

const publicAxios = axios.create({ baseURL: '/api/v1' });

interface PublicWarrantyData {
  product_name: string;
  product_image_url: string | null;
  customer_name: string;
  duration_label: string;
  duration_days: number;
  start_date: string;
  end_date: string;
  is_expired: boolean;
  days_remaining: number;
  notes: string | null;
  bayi_name: string;
  bayi_phone: string | null;
}

export function PublicWarrantyPage({ token }: { token: string }) {
  const [data, setData] = useState<PublicWarrantyData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    publicAxios.get<PublicWarrantyData>(`/public/warranty/${token}`)
      .then(res => setData(res.data))
      .catch(err => { const d = err?.response?.data?.detail; setError(Array.isArray(d) ? d.map((x: any) => x?.msg ?? String(x)).join(', ') : (typeof d === 'string' && d ? d : 'Garanti belgesi bulunamadı.')); })
      .finally(() => setLoading(false));
  }, [token]);

  if (loading) return <PublicShell><div className="text-center text-slate-500">Yükleniyor...</div></PublicShell>;
  if (error || !data) return (
    <PublicShell>
      <div className="text-center py-8">
        <XCircle className="mx-auto text-rose-500 mb-3" size={48} />
        <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">Belge Bulunamadı</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400">{error}</p>
      </div>
    </PublicShell>
  );

  return (
    <PublicShell>
      <div className="text-center mb-4">
        <Shield className={`mx-auto mb-2 ${data.is_expired ? 'text-rose-500' : 'text-emerald-500'}`} size={40} />
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Garanti Belgesi</h2>
        <div className={`inline-flex items-center gap-1.5 mt-2 px-3 py-1 rounded-full text-sm font-medium ${
          data.is_expired
            ? 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300'
            : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300'
        }`}>
          {data.is_expired ? <XCircle size={16} /> : <CheckCircle2 size={16} />}
          {data.is_expired ? 'Süresi Bitmiş' : 'Aktif Garanti'}
        </div>
      </div>

      {data.product_image_url && (
        <ZoomImg src={data.product_image_url} alt={data.product_name} className="w-full max-h-64 object-contain rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 mb-4" />
      )}

      <div className="space-y-2 text-sm">
        <Row label="Ürün" value={data.product_name} />
        <Row label="Müşteri" value={data.customer_name} />
        <Row label="Garanti Süresi" value={`${data.duration_label} (${data.duration_days} gün)`} />
        <Row label="Başlangıç" value={fmtDate(data.start_date)} />
        <Row label="Bitiş" value={fmtDate(data.end_date)} />
        {!data.is_expired && (
          <Row label="Kalan Süre" value={`${data.days_remaining} gün`} highlight />
        )}
        <Row label="Bayi" value={data.bayi_name} />
        {data.bayi_phone && <Row label="Bayi Telefon" value={data.bayi_phone} />}
        {data.notes && (
          <div className="pt-2">
            <div className="text-xs text-slate-500 dark:text-slate-400 mb-1">Notlar</div>
            <div className="rounded-lg bg-slate-50 dark:bg-slate-800 p-2 text-slate-700 dark:text-slate-200 text-xs whitespace-pre-wrap">{data.notes}</div>
          </div>
        )}
      </div>
    </PublicShell>
  );
}

function Row({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex justify-between items-start gap-3 py-1.5 border-b border-slate-100 dark:border-slate-800 last:border-b-0">
      <div className="text-slate-500 dark:text-slate-400">{label}</div>
      <div className={`font-medium text-right ${highlight ? 'text-emerald-600 dark:text-emerald-400 text-base' : 'text-slate-900 dark:text-white'}`}>{value}</div>
    </div>
  );
}

// ============================================================
// PUBLIC DEBTOR PAGE (auth yok, otomatik yenilenir)
// ============================================================

interface PublicTxn {
  id: number;
  transaction_type: string;
  amount: number;
  currency: string;
  description: string | null;
  created_at: string;
}

interface PublicDebtorData {
  customer_name: string;
  bayi_name: string;
  bayi_phone: string | null;
  total_debt: number;
  total_paid: number;
  balance: number;
  transaction_count: number;
  transactions: PublicTxn[];
  expires_at: string | null;
  server_time: string;
}

export function PublicDebtorPage({ token }: { token: string }) {
  const [data, setData] = useState<PublicDebtorData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const intervalRef = useRef<number | null>(null);

  const load = (silent = false) => {
    if (!silent) setLoading(true); else setRefreshing(true);
    publicAxios.get<PublicDebtorData>(`/public/debtor/${token}`)
      .then(res => { setData(res.data); setError(null); })
      .catch(err => {
        const status = err?.response?.status;
        if (status === 410) setError('Bu linkin süresi dolmuş. Bayinizden yeni bir link talep ediniz.');
        else { const d = err?.response?.data?.detail; setError(Array.isArray(d) ? d.map((x: any) => x?.msg ?? String(x)).join(', ') : (typeof d === 'string' && d ? d : 'Hesap bilgisi alınamadı.')); }
        if (status === 410 && intervalRef.current) {
          clearInterval(intervalRef.current);
          intervalRef.current = null;
        }
      })
      .finally(() => { setLoading(false); setRefreshing(false); });
  };

  useEffect(() => {
    load();
    intervalRef.current = window.setInterval(() => withSilentRefresh(() => load(true)), 15000);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
    // eslint-disable-next-line
  }, [token]);

  if (loading) return <PublicShell><div className="text-center text-slate-500">Yükleniyor...</div></PublicShell>;
  if (error || !data) return (
    <PublicShell>
      <div className="text-center py-8">
        <XCircle className="mx-auto text-rose-500 mb-3" size={48} />
        <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">Erişilemiyor</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400">{error}</p>
      </div>
    </PublicShell>
  );

  const fmtMoney = (n: number, cur = 'TRY') => {
    try { return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: cur, maximumFractionDigits: 2 }).format(n); }
    catch { return `${n.toFixed(2)} ${cur}`; }
  };

  return (
    <PublicShell wide>
      <div className="text-center mb-4">
        <FileText className="mx-auto text-indigo-500 mb-2" size={40} />
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Cari Hesap Ekstresi</h2>
        <div className="text-sm text-slate-500 dark:text-slate-400">{data.bayi_name}</div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
        <SummaryCard label="Toplam Borç" value={fmtMoney(data.total_debt)} tone="rose" />
        <SummaryCard label="Toplam Ödeme" value={fmtMoney(data.total_paid)} tone="emerald" />
        <SummaryCard label="Net Bakiye" value={fmtMoney(data.balance)} tone={data.balance > 0 ? 'rose' : 'emerald'} large />
      </div>

      <div className="rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        <div className="px-3 py-2 bg-slate-50 dark:bg-slate-800/60 text-xs uppercase tracking-wide text-slate-500 dark:text-slate-400 flex items-center justify-between">
          <span>Son İşlemler ({data.transaction_count})</span>
          <span className="inline-flex items-center gap-1">
            <RefreshCw size={11} className={refreshing ? 'animate-spin' : ''} />
            {fmtDateTime(data.server_time)} (15s'de bir yenilenir)
          </span>
        </div>
        <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-96 overflow-auto">
          {data.transactions.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-sm">Henüz işlem yok.</div>
          ) : data.transactions.map(t => {
            const isPay = ['ödeme', 'odeme', 'payment', 'tahsilat'].includes((t.transaction_type || '').toLowerCase());
            return (
              <div key={t.id} className="px-3 py-2 flex items-start justify-between gap-3 text-sm">
                <div className="min-w-0">
                  <div className="font-medium text-slate-800 dark:text-slate-200 capitalize">{t.transaction_type}</div>
                  {t.description && <div className="text-xs text-slate-500 dark:text-slate-400 truncate">{t.description}</div>}
                  <div className="text-xs text-slate-400">{fmtDateTime(t.created_at)}</div>
                </div>
                <div className={`font-semibold whitespace-nowrap ${isPay ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                  {isPay ? '+' : '−'} {fmtMoney(t.amount, t.currency)}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {data.bayi_phone && (
        <div className="mt-4 text-center text-xs text-slate-500 dark:text-slate-400">
          Sorularınız için bayinizi arayın: <a href={`tel:${data.bayi_phone}`} className="text-indigo-600 dark:text-indigo-400 font-medium">{data.bayi_phone}</a>
        </div>
      )}
    </PublicShell>
  );
}

function SummaryCard({ label, value, tone, large }: { label: string; value: string; tone: 'rose' | 'emerald'; large?: boolean }) {
  const toneClass = tone === 'rose'
    ? 'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900/50 text-rose-700 dark:text-rose-300'
    : 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900/50 text-emerald-700 dark:text-emerald-300';
  return (
    <div className={`rounded-xl border p-3 text-center ${toneClass}`}>
      <div className="text-xs uppercase tracking-wide opacity-80">{label}</div>
      <div className={`font-bold mt-1 ${large ? 'text-2xl' : 'text-lg'}`}>{value}</div>
    </div>
  );
}

// ============================================================
// PUBLIC SHELL (basit layout, theme/lang context'siz)
// ============================================================

function PublicShell({ children, wide }: { children: React.ReactNode; wide?: boolean }) {
  // Sistem teması veya localStorage tema kullanıcının önceden kaydettiği tema
  const isDark = (() => {
    try {
      const saved = localStorage.getItem('theme');
      if (saved === 'dark') return true;
      if (saved === 'light') return false;
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch { return false; }
  })();
  return (
    <div className={isDark ? 'dark' : ''}>
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 py-6 px-3">
        <div className={`mx-auto bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-5 ${wide ? 'max-w-2xl' : 'max-w-md'}`}>
          <div className="flex items-center justify-center gap-2 mb-4 pb-3 border-b border-slate-200 dark:border-slate-800">
            <div className="text-xl font-bold text-indigo-600 dark:text-indigo-400">StokFinans</div>
          </div>
          {children}
        </div>
        <div className="text-center text-xs text-slate-400 mt-4">
          StokFinans • {new Date().getFullYear()}
        </div>
      </div>
    </div>
  );
}
