import React, { useState, useEffect, useRef } from 'react';
import api from './lib/api';
import { useRefreshOnChange } from './hooks/useRefreshOnChange';
import {
  MessageCircle, Plus, Send, X,
  Inbox, RefreshCw, Phone, HeadphonesIcon
} from 'lucide-react';
import { useLang, makeT } from './lib/i18n';

// ── Types ─────────────────────────────────────────────────────────────────────

interface Ticket {
  id: number;
  subject: string;
  category: string;
  category_label: string;
  status: string;
  status_label: string;
  created_at: string;
  updated_at: string;
  message_count: number;
  last_message_at: string | null;
}

interface Message {
  id: number;
  is_from_admin: boolean;
  body: string;
  created_at: string;
  sender_name: string | null;
}

interface TicketDetail extends Ticket {
  messages: Message[];
}

interface Props {
  currentUser: any;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

// ── i18n ──────────────────────────────────────────────────────────────────────

const DICT: Record<string, string> = {
  'Destek': 'Support',
  'Destek & Talepler': 'Support & Requests',
  'Müşteri Desteği': 'Customer Support',
  'Yeni Talep': 'New Request',
  'Yeni Destek Talebi': 'New Support Request',
  'Tüm Talepler': 'All Requests',
  'Tümü': 'All',
  'Açık': 'Open',
  'İşlemde': 'In Progress',
  'Çözüldü': 'Resolved',
  'Kapalı': 'Closed',
  'Konu': 'Subject',
  'Konu *': 'Subject *',
  'Kategori': 'Category',
  'Açıklama *': 'Description *',
  'Mesaj': 'Message',
  'Gönder': 'Send',
  'İptal': 'Cancel',
  'Talep oluşturulamadı.': 'Could not create request.',
  'Talebiniz oluşturuldu!': 'Your request was created!',
  'Mesaj gönderilemedi.': 'Could not send message.',
  'Konu ve mesaj zorunludur.': 'Subject and message are required.',
  'Talepler yüklenemedi.': 'Could not load requests.',
  'Talep detayı yüklenemedi.': 'Could not load request details.',
  'Yanıtla': 'Reply',
  'Bekliyor': 'Pending',
  'Henüz talep yok': 'No requests yet',
  '"Yeni Talep" ile destek alın.': 'Use "New Request" to get support.',
  'Mesajınızı yazın...': 'Write a message...',
  'Yükleniyor...': 'Loading...',
  'İletişim': 'Contact',
  'Sorularınız için bizi arayabilir, WhatsApp\'tan yazabilir veya Instagram\'dan ulaşabilirsiniz.': 'You can call us, message us on WhatsApp, or reach us on Instagram for your questions.',
  'Berat Bayramkıvrak': 'Berat Bayramkıvrak',
  'WhatsApp ile Yaz': 'Message on WhatsApp',
  'Instagram\'da Takip Et': 'Follow on Instagram',
  'Destek Ekibi': 'Support Team',
  'Ctrl+Enter ile gönder': 'Send with Ctrl+Enter',
  'Bu talep kapatılmış. Yeni sorun için yeni talep açın.': 'This request is closed. Open a new request for a new issue.',
  'Hata Bildirimi': 'Bug Report',
  'Talep': 'Request',
  'Öneri': 'Suggestion',
  'Diğer': 'Other',
  'Kısaca neyle ilgili yardım istiyorsunuz?': 'Briefly, what do you need help with?',
  'Sorununuzu veya önerinizi detaylıca açıklayın...': 'Describe your issue or suggestion in detail...',
};

// ── Constants ─────────────────────────────────────────────────────────────────

const CATEGORIES = [
  { value: 'bug', label: 'Hata Bildirimi' },
  { value: 'request', label: 'Talep' },
  { value: 'suggestion', label: 'Öneri' },
  { value: 'other', label: 'Diğer' },
];

const STATUS_TABS = [
  { value: 'all', label: 'Tümü' },
  { value: 'open', label: 'Açık' },
  { value: 'in_progress', label: 'İşlemde' },
  { value: 'closed', label: 'Kapalı' },
];

const STATUS_CONFIG: Record<string, { label: string; color: string; dot: string }> = {
  Açık:     { label: 'Açık',     color: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300',   dot: 'bg-green-500' },
  İşlemde:  { label: 'İşlemde',  color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',       dot: 'bg-blue-500' },
  Kapalı:   { label: 'Kapalı',   color: 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400',     dot: 'bg-slate-400' },
};

function fmtDate(iso: string) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleString('tr-TR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' });
}

// ── SupportView ───────────────────────────────────────────────────────────────

const SupportView: React.FC<Props> = ({ currentUser, showToast }) => {
  const lang = useLang();
  const t = makeT(lang, DICT);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [statusFilter, setStatusFilter] = useState('all');
  const [selected, setSelected] = useState<TicketDetail | null>(null);
  const [loading, setLoading] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [replyBody, setReplyBody] = useState('');
  const [sendingReply, setSendingReply] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Create form state
  const [form, setForm] = useState({ subject: '', category: 'other', body: '' });
  const [creating, setCreating] = useState(false);

  const fetchTickets = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const params: any = {};
      if (statusFilter !== 'all') params.status = statusFilter;
      const res = await api.get('/support/tickets', { params });
      setTickets(res.data);
    } catch {
      showToast(t('Talepler yüklenemedi.'), 'error');
    } finally {
      setLoading(false);
    }
  };

  const fetchDetail = async (id: number) => {
    setDetailLoading(true);
    try {
      const res = await api.get(`/support/tickets/${id}`);
      setSelected(res.data);
    } catch {
      showToast(t('Talep detayı yüklenemedi.'), 'error');
    } finally {
      setDetailLoading(false);
    }
  };

  useEffect(() => { fetchTickets(); }, [statusFilter]);
  useRefreshOnChange(fetchTickets);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [selected?.messages]);

  const handleCreate = async () => {
    if (!form.subject.trim() || !form.body.trim()) {
      showToast(t('Konu ve mesaj zorunludur.'), 'error');
      return;
    }
    setCreating(true);
    try {
      await api.post('/support/tickets', {
        subject: form.subject.trim(),
        category: form.category,
        body: form.body.trim(),
      });
      showToast(t('Talebiniz oluşturuldu!'), 'success');
      setShowCreate(false);
      setForm({ subject: '', category: 'other', body: '' });
      await fetchTickets();
    } catch {
      showToast(t('Talep oluşturulamadı.'), 'error');
    } finally {
      setCreating(false);
    }
  };

  const handleReply = async () => {
    if (!selected || !replyBody.trim()) return;
    setSendingReply(true);
    try {
      await api.post(`/support/tickets/${selected.id}/messages`, { body: replyBody.trim() });
      setReplyBody('');
      await fetchDetail(selected.id);
      fetchTickets();
    } catch (e: any) {
      showToast(e?.response?.data?.detail || t('Mesaj gönderilemedi.'), 'error');
    } finally {
      setSendingReply(false);
    }
  };

  const sc = selected ? (STATUS_CONFIG[selected.status_label] || STATUS_CONFIG['Açık']) : null;

  return (
    <div className="flex flex-col h-full gap-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageCircle size={22} className="text-indigo-500" />
          <h1 className="text-xl font-bold text-slate-800 dark:text-white">{t('Destek & Talepler')}</h1>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium transition-colors"
        >
          <Plus size={16} /> {t('Yeni Talep')}
        </button>
      </div>

      {/* Status filter tabs */}
      <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 rounded-lg p-1 self-start">
        {STATUS_TABS.map(tab => (
          <button
            key={tab.value}
            onClick={() => { setStatusFilter(tab.value); setSelected(null); }}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
              statusFilter === tab.value
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            {t(tab.label)}
          </button>
        ))}
      </div>

      {/* Main content — ticket list + detail panel */}
      <div className="flex flex-1 gap-4 min-h-0">

        {/* Ticket list + contact card */}
        <div className={`flex flex-col min-h-0 ${selected ? 'w-1/3 min-w-[260px]' : 'w-full max-w-2xl'}`}>
          <div className="flex flex-col gap-2 overflow-y-auto flex-1 min-h-0">
            {loading ? (
              <div className="text-center py-12 text-slate-400"><RefreshCw size={24} className="animate-spin mx-auto mb-2" />{t('Yükleniyor...')}</div>
            ) : tickets.length === 0 ? (
              <div className="text-center py-16 text-slate-400">
                <Inbox size={40} className="mx-auto mb-3 opacity-40" />
                <p className="font-medium">{t('Henüz talep yok')}</p>
                <p className="text-sm mt-1">{t('"Yeni Talep" ile destek alın.')}</p>
              </div>
            ) : tickets.map(ticket => {
              const cfg = STATUS_CONFIG[ticket.status_label] || STATUS_CONFIG['Açık'];
              const isActive = selected?.id === ticket.id;
              return (
                <button
                  key={ticket.id}
                  onClick={() => fetchDetail(ticket.id)}
                  className={`text-left p-4 rounded-xl border transition-all ${
                    isActive
                      ? 'border-indigo-400 bg-indigo-50 dark:bg-indigo-950/30 dark:border-indigo-600'
                      : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800/60 hover:border-indigo-300 dark:hover:border-indigo-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <p className="font-semibold text-slate-800 dark:text-white text-sm leading-snug line-clamp-2">{ticket.subject}</p>
                    <span className={`flex items-center gap-1.5 shrink-0 text-xs font-medium px-2 py-0.5 rounded-full ${cfg.color}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
                      {ticket.status_label}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-400 dark:text-slate-500">
                    <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-700 rounded text-slate-500 dark:text-slate-400">{ticket.category_label}</span>
                    <span className="flex items-center gap-1">
                      <MessageCircle size={11} />
                      {ticket.message_count}
                      <span className="ml-1">{fmtDate(ticket.updated_at)}</span>
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Contact card */}
          <div className="shrink-0 mt-3 bg-white dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 p-4">
            <div className="flex items-center gap-2 mb-2">
              <HeadphonesIcon size={16} className="text-indigo-500" />
              <h3 className="font-semibold text-slate-700 dark:text-slate-200 text-sm">{t('İletişim')}</h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3 leading-relaxed">
              {t('Sorularınız için bizi arayabilir, WhatsApp\'tan yazabilir veya Instagram\'dan ulaşabilirsiniz.')}
            </p>
            <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">Berat Bayramkıvrak</p>
            <div className="flex flex-col gap-2">
              <a
                href="tel:+905372385409"
                className="flex items-center gap-2 px-3 py-2 bg-slate-50 dark:bg-slate-700 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors"
              >
                <Phone size={13} className="text-indigo-500 shrink-0" />
                +90 537 238 54 09
              </a>
              <a
                href="https://wa.me/905372385409"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-3 py-2 bg-green-50 dark:bg-green-950/20 hover:bg-green-100 dark:hover:bg-green-950/40 rounded-lg text-xs font-medium text-green-700 dark:text-green-400 transition-colors"
              >
                <MessageCircle size={13} className="text-green-500 shrink-0" />
                {t('WhatsApp ile Yaz')}
              </a>
              <a
                href="https://www.instagram.com/stokfinans"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium text-white transition-colors shrink-0"
                style={{ background: 'linear-gradient(135deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%)' }}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>
                </svg>
                {t('Instagram\'da Takip Et')}
              </a>
            </div>
          </div>
        </div>

        {/* Ticket detail */}
        {selected && (
          <div className="flex-1 flex flex-col bg-white dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 min-h-0">
            {/* Detail header */}
            <div className="flex items-start justify-between p-4 border-b border-slate-200 dark:border-slate-700 shrink-0">
              <div>
                <h2 className="font-bold text-slate-800 dark:text-white">{selected.subject}</h2>
                <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
                  <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-700 rounded text-slate-500 dark:text-slate-400">{selected.category_label}</span>
                  {sc && (
                    <span className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${sc.color}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                      {selected.status_label}
                    </span>
                  )}
                  <span>#{selected.id}</span>
                  <span>{fmtDate(selected.created_at)}</span>
                </div>
              </div>
              <button onClick={() => setSelected(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1">
                <X size={18} />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
              {detailLoading ? (
                <div className="text-center py-8 text-slate-400"><RefreshCw size={20} className="animate-spin mx-auto mb-1" /></div>
              ) : selected.messages.map(msg => (
                <div key={msg.id} className={`flex ${msg.is_from_admin ? 'justify-start' : 'justify-end'}`}>
                  <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm shadow-sm ${
                    msg.is_from_admin
                      ? 'bg-slate-100 dark:bg-slate-700 text-slate-800 dark:text-slate-100 rounded-tl-sm'
                      : 'bg-indigo-600 text-white rounded-tr-sm'
                  }`}>
                    {msg.is_from_admin && (
                      <p className="text-[10px] font-bold uppercase tracking-wide mb-1 opacity-60">
                        {msg.sender_name || t('Destek Ekibi')}
                      </p>
                    )}
                    <p className="whitespace-pre-wrap leading-relaxed break-words overflow-wrap-anywhere">{msg.body}</p>
                    <p className={`text-[10px] mt-1.5 opacity-60 text-right`}>{fmtDate(msg.created_at)}</p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Reply box */}
            {selected.status_label !== 'Kapalı' ? (
              <div className="p-3 border-t border-slate-200 dark:border-slate-700 shrink-0">
                <div className="flex gap-2 items-end">
                  <textarea
                    value={replyBody}
                    onChange={e => setReplyBody(e.target.value)}
                    placeholder={t('Mesajınızı yazın...')}
                    rows={2}
                    className="flex-1 resize-none rounded-xl border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-700 text-slate-800 dark:text-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400"
                    onKeyDown={e => { if (e.key === 'Enter' && e.ctrlKey) handleReply(); }}
                  />
                  <button
                    onClick={handleReply}
                    disabled={sendingReply || !replyBody.trim()}
                    className="p-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white rounded-xl transition-colors shrink-0"
                  >
                    <Send size={16} />
                  </button>
                </div>
                <p className="text-[10px] text-slate-400 mt-1 ml-1">{t('Ctrl+Enter ile gönder')}</p>
              </div>
            ) : (
              <div className="p-3 border-t border-slate-200 dark:border-slate-700 text-center text-sm text-slate-400 dark:text-slate-500">
                {t('Bu talep kapatılmış. Yeni sorun için yeni talep açın.')}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Create ticket modal */}
      {showCreate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-lg">
            <div className="flex items-center justify-between p-5 border-b border-slate-200 dark:border-slate-700">
              <h2 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2">
                <MessageCircle size={20} className="text-indigo-500" />
                {t('Yeni Destek Talebi')}
              </h2>
              <button onClick={() => setShowCreate(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                <X size={20} />
              </button>
            </div>
            <div className="p-5 space-y-4">
              {/* Subject */}
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{t('Konu *')}</label>
                <input
                  type="text"
                  value={form.subject}
                  onChange={e => setForm(p => ({ ...p, subject: e.target.value }))}
                  placeholder={t('Kısaca neyle ilgili yardım istiyorsunuz?')}
                  className="w-full rounded-lg border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-700 text-slate-800 dark:text-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400"
                />
              </div>

              {/* Category */}
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{t('Kategori')}</label>
                <select
                  value={form.category}
                  onChange={e => setForm(p => ({ ...p, category: e.target.value }))}
                  className="w-full rounded-lg border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-700 text-slate-800 dark:text-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400"
                >
                  {CATEGORIES.map(c => (
                    <option key={c.value} value={c.value}>{t(c.label)}</option>
                  ))}
                </select>
              </div>

              {/* Body */}
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{t('Açıklama *')}</label>
                <textarea
                  value={form.body}
                  onChange={e => setForm(p => ({ ...p, body: e.target.value }))}
                  placeholder={t('Sorununuzu veya önerinizi detaylıca açıklayın...')}
                  rows={5}
                  className="w-full resize-none rounded-lg border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-700 text-slate-800 dark:text-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400"
                />
              </div>

              <div className="flex gap-3 pt-1">
                <button
                  onClick={() => setShowCreate(false)}
                  className="flex-1 py-2.5 rounded-lg border border-slate-200 dark:border-slate-600 text-slate-600 dark:text-slate-300 text-sm font-medium hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
                >
                  {t('İptal')}
                </button>
                <button
                  onClick={handleCreate}
                  disabled={creating || !form.subject.trim() || !form.body.trim()}
                  className="flex-1 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white text-sm font-medium flex items-center justify-center gap-2 transition-colors"
                >
                  {creating ? <RefreshCw size={15} className="animate-spin" /> : <Send size={15} />}
                  {t('Gönder')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SupportView;
