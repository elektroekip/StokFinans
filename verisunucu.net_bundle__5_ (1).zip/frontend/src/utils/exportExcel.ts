import * as XLSX from 'xlsx';

/** Sütun genişliklerini içeriğe göre otomatik hesaplar */
function autoColWidths(data: Record<string, any>[], headers: string[]): { wch: number }[] {
  return headers.map((h) => {
    const maxLen = Math.max(
      h.length,
      ...data.map((row) => String(row[h] ?? '').length)
    );
    return { wch: Math.min(Math.max(maxLen + 2, 10), 60) };
  });
}

/** Tarih formatla (ISO → Türkçe) */
function fmtDate(val: string | null | undefined): string {
  if (!val) return '—';
  try {
    return new Date(val).toLocaleDateString('tr-TR', {
      day: '2-digit', month: '2-digit', year: 'numeric',
    });
  } catch { return String(val); }
}

/** Para formatla (sayı olarak tut, Excel'de number column olsun) */
function fmtNum(val: any): number | string {
  const n = parseFloat(String(val ?? ''));
  return isNaN(n) ? '—' : n;
}

interface ExportOptions {
  filename: string;
  sheetName?: string;
}

/** Ana export fonksiyonu — data: [{KolonAdı: değer}] şeklinde */
export function exportToExcel(
  data: Record<string, any>[],
  options: ExportOptions
): void {
  if (!data.length) return;

  const sheetName = (options.sheetName || 'Veri').slice(0, 31);
  const headers = Object.keys(data[0]);

  const ws = XLSX.utils.json_to_sheet(data);
  ws['!cols'] = autoColWidths(data, headers);
  // Başlık satırını dondur
  ws['!freeze'] = { xSplit: 0, ySplit: 1 };

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName);

  const date = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(wb, `${options.filename}_${date}.xlsx`);
}

// ─────────────────────────────────────────────────────────────
// Veri dönüşüm fonksiyonları — her modül için
// ─────────────────────────────────────────────────────────────

/** Stok ürünleri → Excel satırları */
export function exportStok(rows: any[], title: string, showCost: boolean): void {
  const data = rows.map((r) => {
    const base: Record<string, any> = {
      'Ürün Adı': r.title ?? '—',
      'Barkod': r.barcode || '—',
      'Kategori': r.category || '—',
      'Alt Kategori': r.subcategory || '—',
      'Ek Etiketler': Array.isArray(r.extraCategories) ? r.extraCategories.join(', ') : '—',
    };
    if (showCost) {
      base['Alış Fiyatı'] = fmtNum(r.buyPrice);
      base['Alış Para Birimi'] = r.costCurrency || r.currency || 'TRY';
    }
    base['Satış Fiyatı'] = fmtNum(r.sellPrice);
    base['Satış Para Birimi'] = r.currency || 'TRY';
    base['Stok Miktarı'] = fmtNum(r.amount);
    base['Min. Stok Uyarısı'] = fmtNum(r.min_stock_alert ?? 5);
    return base;
  });
  exportToExcel(data, { filename: `stok_${title}`, sheetName: title.slice(0, 31) });
}

/** Finans cari listesi (grouped) → Excel */
export function exportFinansCariler(rows: any[], title: string): void {
  const data = rows.map((r) => ({
    'Cari Adı': r.title ?? '—',
    'Hareket Sayısı': fmtNum(r.txnCount),
    'İlk Kayıt': r.date ? fmtDate(r.date) : '—',
    'Son İşlem': r.lastAt ? fmtDate(r.lastAt) : '—',
    'Toplam Borç': fmtNum(r.totalDebt),
    'Toplam Ödeme': fmtNum(r.totalPaid),
    'Net Bakiye': fmtNum(r.balance),
    'Para Birimi': r.currency || 'TRY',
    'Notlar': r.notes || '—',
  }));
  exportToExcel(data, { filename: `finans_${title}`, sheetName: title.slice(0, 31) });
}

/** Finans tekil işlemler (ungrouped) → Excel */
export function exportFinansIslemler(rows: any[], title: string): void {
  const data = rows.map((r) => ({
    'Müşteri': r.title ?? '—',
    'İşlem Türü': r.type ?? r.ledgerType ?? '—',
    'Tarih': r.date ? fmtDate(r.date) : '—',
    'Tutar': fmtNum(r.amount ?? r.balance),
    'Para Birimi': r.currency || 'TRY',
    'Notlar': r.notes || '—',
  }));
  exportToExcel(data, { filename: `islemler_${title}`, sheetName: title.slice(0, 31) });
}

/** Cari detay işlem geçmişi → Excel */
export function exportCariDetay(transactions: any[], cariAdi: string): void {
  const data = transactions.map((tx) => ({
    'Tarih': tx.date ?? '—',
    'Açıklama': tx.desc ?? '—',
    'Borç (₺)': fmtNum(tx.borc || 0),
    'Alacak (₺)': fmtNum(tx.alacak || 0),
    'Bakiye (₺)': fmtNum(tx.bakiye),
    'Belge': tx.image ? 'Evet' : 'Hayır',
  }));
  exportToExcel(data, { filename: `cari_${cariAdi}`, sheetName: cariAdi.slice(0, 31) });
}

/** Aktivite logu → Excel */
export function exportAktivite(logs: any[]): void {
  const data = logs.map((l) => ({
    'Tarih': l.time ?? '—',
    'Kullanıcı': l.user ?? '—',
    'İşlem': l.action ?? '—',
    'Detay': l.detail ?? '—',
    'Kategori': l.category ?? '—',
  }));
  exportToExcel(data, { filename: 'aktivite_logu', sheetName: 'Aktiviteler' });
}

/** Süper admin kullanıcı listesi → Excel */
export function exportKullanicilar(users: any[]): void {
  const data = users.map((u) => ({
    'Ad Soyad': u.full_name ?? '—',
    'E-posta': u.email ?? '—',
    'İşletme': u.company_name || '—',
    'Rol': u.role === 'bayi_sahibi' ? 'Bayi Sahibi' : u.is_super_admin ? 'Süper Yönetici' : 'Çalışan',
    'Durum': u.is_active ? 'Aktif' : 'Pasif',
    'Kalan Gün': fmtNum(u.sub_days),
    'Ürün Sayısı': fmtNum(u.product_count),
    'İşlem Sayısı': fmtNum(u.transaction_count),
    'Son Aktivite': fmtDate(u.last_activity_at),
    'Kayıt Tarihi': fmtDate(u.created_at),
  }));
  exportToExcel(data, { filename: 'kullanicilar', sheetName: 'Kullanıcılar' });
}

/** Garanti listesi → Excel */
export function exportGarantiler(items: any[]): void {
  const data = items.map((g) => ({
    'Müşteri': g.customer_name ?? '—',
    'Ürün': g.product_name ?? '—',
    'Seri No': g.serial_number || '—',
    'Garanti Başlangıç': fmtDate(g.warranty_start),
    'Garanti Bitiş': fmtDate(g.warranty_end),
    'Durum': g.status ?? '—',
    'Notlar': g.notes || '—',
    'Kayıt Tarihi': fmtDate(g.created_at),
  }));
  exportToExcel(data, { filename: 'garantiler', sheetName: 'Garantiler' });
}

/** Abonelik listesi → Excel */
export function exportAbonelikler(items: any[]): void {
  const data = items.map((u) => ({
    'Ad Soyad': u.full_name ?? '—',
    'E-posta': u.email ?? '—',
    'İşletme': u.company_name || '—',
    'Kalan Gün': fmtNum(u.sub_days),
    'Bitiş Tarihi': fmtDate(u.sub_expires_at),
    'Durum': u.is_active ? 'Aktif' : 'Pasif',
    'Kayıt Tarihi': fmtDate(u.created_at),
  }));
  exportToExcel(data, { filename: 'abonelikler', sheetName: 'Abonelikler' });
}

/** Ödeme/PayTR listesi → Excel */
export function exportOdemeler(items: any[]): void {
  const data = items.map((p) => ({
    'Kullanıcı': p.user_email ?? p.email ?? '—',
    'Ad Soyad': p.user_full_name ?? p.full_name ?? '—',
    'Paket': p.package_name ?? p.plan_name ?? '—',
    'Tutar': fmtNum(p.amount ?? p.price),
    'Para Birimi': p.currency || 'TRY',
    'Durum': p.status ?? '—',
    'Tarih': fmtDate(p.created_at ?? p.paid_at),
    'İşlem No': p.merchant_oid ?? p.transaction_id ?? '—',
  }));
  exportToExcel(data, { filename: 'odemeler', sheetName: 'Ödemeler' });
}

/** Araç listesi → Excel */
export function exportAraclar(items: any[]): void {
  const data = items.map((v) => ({
    'Plaka': v.plate ?? '—',
    'Marka/Model': `${v.brand ?? ''} ${v.model ?? ''}`.trim() || '—',
    'Yıl': v.year || '—',
    'Renk': v.color || '—',
    'Müşteri': v.customer_name || '—',
    'Km': fmtNum(v.mileage ?? v.km),
    'Notlar': v.notes || '—',
    'Kayıt Tarihi': fmtDate(v.created_at),
  }));
  exportToExcel(data, { filename: 'araclar', sheetName: 'Araçlar' });
}

/** Dashboard stok uyarıları → Excel */
export function exportStokUyarilari(items: any[]): void {
  const data = items.map((s) => ({
    'Ürün Adı': s.title ?? s.name ?? '—',
    'Kategori': s.category || '—',
    'Mevcut Stok': fmtNum(s.amount ?? s.stock),
    'Min. Stok': fmtNum(s.min_stock_alert ?? s.min_stock ?? 5),
    'Durum': (s.amount ?? s.stock) === 0 ? 'Tükendi' : 'Kritik',
  }));
  exportToExcel(data, { filename: 'stok_uyarilari', sheetName: 'Stok Uyarıları' });
}
