# 📚 StokFinans Geliştirme Dökümentasyonu

Bu belge, **StokFinans** projesinin her aşamasında yapılan işlemleri, teknik kararları ve uygulanan çözümleri detaylı olarak kaydeder.

**Proje Başlangıç Tarihi:** 28 Nisan 2026  
**Versiyon:** 1.0.0  
**Durum:** Geliştirme Aşamasında 🚀

---

## 📋 İçindekiler
1. [SEVIYE 1: Temel Kamp](#seviye-1-temel-kamp)
2. [SEVIYE 2: Zemin Kat](#seviye-2-zemin-kat)
3. [SEVIYE 3: Güvenlik Duvarı](#seviye-3-güvenlik-duvarı)
4. [Teknik Kararlar](#teknik-kararlar)
5. [Kurulum Rehberi](#kurulum-rehberi)

---

## SEVIYE 1: Temel Kamp
### Hazırlık ve Altyapı Kurulumu (0% - 10%)

#### ✅ 1.1 Git Repository Kurulumu
**Neler Yapıldı:**
- `git init` komutuyla yerel Git deposu oluşturuldu
- Kullanıcı bilgileri ayarlandı:
  - **Ad:** Berat Bayramkivrak
  - **Email:** beratbayramkivrak@gmail.com

**Kullanılan Komutlar:**
```bash
git init
git config user.name "Berat Bayramkivrak"
git config user.email "beratbayramkivrak@gmail.com"
```

**Açıklama:**
Git, projenin tüm değişikliklerini izleyeceğimiz versiyon kontrol sistemidir. Böylece kim ne zaman ne değiştirdi bunu görebilir, gerekirse geri dönebiliriz.

---

#### ✅ 1.2 Klasör Mimarisi Oluşturması
**Neler Yapıldı:**
```
stokfinans.com/
├── frontend/              # React uygulaması
├── backend/               # Python FastAPI uygulaması
├── docs/                  # Teknik dokümantasyon
├── .gitignore            # Git'in izlemeyeceği dosyalar
└── DEVELOPMENT.md        # Bu dosya
```

**Oluşturulan Komut:**
```bash
mkdir -p frontend backend docs
```

**Açıklama:**
Bu yapı sayesinde Frontend ve Backend tamamen ayrı olacak. Frontend, React ile kullanıcı arayüzünü, Backend ise veri işleme ve API sunucusunu yönetecek.

---

#### ✅ 1.3 .gitignore Dosyası Oluşturması
**Neler Yapıldı:**
Aşağıdaki dizin ve dosyaları Git'in takip etmekten hariç tuttu:

**Python İçin:**
- `venv/` - Python sanal ortamı
- `__pycache__/` - Python derlenmiş dosyaları
- `*.pyc`, `*.pyo` - Derlenmiş Python dosyaları
- `.env` - Gizli yapılandırma dosyaları (şifreler, API anahtarları vb.)

**Node.js İçin:**
- `node_modules/` - npm paketleri
- `package-lock.json` - Paket kilidi dosyası

**Üretim Dosyaları:**
- `build/`, `dist/` - Frontend derlenmiş dosyaları
- `uploads/` - Kullanıcı tarafından yüklenen dosyalar

**Veritabanı:**
- `*.db`, `*.sqlite`, `*.sqlite3` - Veritabanı dosyaları

**IDE ve OS:**
- `.vscode/`, `.idea/` - Editor ayarları
- `.DS_Store`, `Thumbs.db` - İşletim sistemi dosyaları

**Açıklama:**
`.gitignore` dosyası, projeyi GitHub'a yüklerken gizli bilgilerin veya test dosyalarının sızmasını önler. Örneğin, veritabanı şifresi hiçbir zaman GitHub'a yüklenmemelidir.

---

## SEVIYE 2: Zemin Kat
### Veritabanı Tasarımı ve ORM (10% - 30%)

#### ✅ 2.1 Python Sanal Ortam Kurulması
**Neler Yapıldı:**
```bash
python -m venv venv
```
- Python 3.x için izole bir ortam oluşturuldu
- Tüm kütüphaneler bu ortamda kurulacak (sistem Python'unu kirletmez)

**Açıklama:**
Sanal ortam (virtual environment), her projenin kendi paketlerini (kütüphaneleri) tutmasını sağlar. Proje A'da Django 3.0, Proje B'de 4.0 olabilir. Çakışma olmaz.

---

#### ✅ 2.2 Backend Klasör Yapısı Oluşturması
**Neler Yapıldı:**
```
backend/
├── venv/                      # Sanal ortam
├── app/
│   ├── __init__.py
│   ├── core/
│   │   ├── __init__.py
│   │   └── database.py        # Veritabanı bağlantısı
│   ├── models/
│   │   ├── __init__.py
│   │   ├── user.py            # User modeli
│   │   ├── product.py         # Product modeli
│   │   ├── transaction.py     # Transaction modeli
│   │   └── log.py             # ActivityLog modeli
│   ├── schemas/               # Pydantic validation models
│   ├── api/                   # API endpoints
│   ├── services/              # Business logic
│   └── utils/                 # Yardımcı fonksiyonlar
├── logs/                      # Uygulama logları
├── uploads/                   # Yüklenen dosyalar
├── requirements.txt           # Python bağımlılıkları
└── .env.example              # Çevre değişkenleri şablonu
```

**Açıklama:**
- `models/`: Veritabanı tablolarının Python kodu
- `schemas/`: API giriş/çıkış verisi validasyonu
- `api/`: Endpoints (GET /api/users vs)
- `services/`: İş mantığı (login doğrulama, stok hesaplama vs)
- `utils/`: Email gönderme, JWT token, vb.

---

#### ✅ 2.3 Requirements.txt Oluşturması
**Neler Yapıldı:**
Tüm Python kütüphaneleri listelenip, açıklamalarla eklendi:

**Ana Kütüphaneler:**
| Kütüphane | Versiyon | Amacı |
|-----------|----------|-------|
| fastapi | 0.104.1 | Web API framework |
| uvicorn | 0.24.0 | ASGI sunucusu |
| sqlalchemy | 2.0.23 | Database ORM |
| passlib | 1.7.4 | Şifre hashing |
| python-jose | 3.3.0 | JWT token işlemleri |
| python-dotenv | 1.0.0 | .env dosyası yükleme |

**Açıklama:**
`pip install -r requirements.txt` komutuyla hepsi tek seferde kurulacak.

---

#### ✅ 2.4 .env.example Oluşturması
**Neler Yapıldı:**
Çevre değişkenlerinin şablonu oluşturuldu:
```env
DATABASE_URL=sqlite:///./stokfinans.db
SECRET_KEY=your-secret-key-here
CORS_ORIGINS=http://localhost:5173
```

**Açıklama:**
- `.env.example` = GitHub'a gitmek OK (şablondur)
- `.env` = Gerçek dosya, `.gitignore`'da olması gerekir
- Üretimde her bir değişken değiştirilir

---

#### ✅ 2.5 SQLAlchemy Veri Modelleri Yazılması

**2.5.1 User Modeli (app/models/user.py)**
```python
class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True)
    password_hash = Column(String(255))
    full_name = Column(String(255))
    company_name = Column(String(255))  # Bayı için
    role = Column(String(50))  # bayi_sahibi, calisan
    ref_code = Column(String(50), unique=True)  # Referral kodu
    sub_days = Column(Integer, default=14)  # Abonelik günleri
    ip_address = Column(String(50))  # IP Koruma için
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now())
```

**Açıklama:**
- `primary_key=True`: Benzersiz ID (1, 2, 3...)
- `unique=True`: Aynı değer iki kere olamaz (email, ref_code)
- `index=True`: Sorgulamayı hızlandırır (email'e göre arama)
- `nullable=False`: Zorunlu alan
- `default=14`: Varsayılan değer 14 gün

---

**2.5.2 Product Modeli (app/models/product.py)**
```python
class Product(Base):
    __tablename__ = "products"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))  # Kimin ürünü
    category = Column(String(100))  # CAM, KAPUT, vb.
    name = Column(String(500))  # Ürün adı
    barcode = Column(String(100), unique=True)  # EAN kodu
    buy_price = Column(Float)  # Alış fiyatı
    sell_price = Column(Float)  # Satış fiyatı
    stock_amount = Column(Integer, default=0)  # Stok
    min_stock_alert = Column(Integer, default=5)  # Uyarı seviyesi
```

**Açıklama:**
- `ForeignKey("users.id")`: Bu ürün hangi bayıya ait
- Barcode otomatik oluşturulmaz, müşteri girer veya okuyucu ile tarar
- `profit_margin` property: Kar marjını hesaplar (otomatik)
- `is_critical` property: Stok kritik mi diye kontrol eder

---

**2.5.3 Transaction Modeli (app/models/transaction.py)**
```python
class Transaction(Base):
    __tablename__ = "transactions"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    customer_name = Column(String(255))
    customer_phone = Column(String(20))
    customer_vkn = Column(String(20))  # Vergi kimlik numarası
    transaction_type = Column(String(20))  # debt, payment, expense
    amount = Column(Float)  # Para tutarı
    description = Column(String(500))  # Ne için
    image_url = Column(String(1000))  # Fatura görseli
    balance = Column(Float)  # Kümülatif bakiye
```

**Açıklama:**
- `transaction_type`: debt (borç), payment (tahsilat), expense (gider)
- Müşteri 5000₺ borç verirse → debt kaydı
- Müşteri 2000₺ öderse → payment kaydı
- Bakiye = Toplam borç - Toplam tahsilat

---

**2.5.4 ActivityLog Modeli (app/models/log.py)**
```python
class ActivityLog(Base):
    __tablename__ = "activity_logs"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    user_name = Column(String(255))
    action_type = Column(String(100))  # product_add, stock_update
    entity_type = Column(String(100))  # product, transaction
    entity_id = Column(Integer)  # Hangi ürüne, işleme yapıldı
    description = Column(String(500))
    status = Column(String(20), default="success")  # success, error
    created_at = Column(DateTime, server_default=func.now())
```

**Açıklama:**
- Her ürün eklemesi, silmesi, düzenlemesi burada kaydedilir
- "Ahmet 10'dan 5'e stoğu değiştirdi" gibi
- İşletme geçmişini görmek için sorgulanır
- Güvenlik: Kimin ne yaptığını bilmek

---

#### ✅ 2.6 Veritabanı Bağlantısı (app/core/database.py)
**Neler Yapıldı:**
SQLAlchemy engine ve session factory oluşturuldu

```python
# SQLite (Geliştirme)
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./stokfinans.db")

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},  # SQLite için gerekli
    poolclass=StaticPool,  # Bağlantı havuzu
)

SessionLocal = sessionmaker(bind=engine)

def get_db():
    """FastAPI dependency - her endpoint'e otomatik session sağla"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```

**Açıklama:**
- `engine`: Veritabanına bağlantı kurar
- `SessionLocal`: Veritabanı işlemleri için session yaratır
- `get_db()`: FastAPI ile birlikte kullanılır (Depends)

---

**Tamamlanan SEVIYE 2 İletişim Özeti:**
✅ Python ortamı kuruldu
✅ 4 ana model yazıldı (User, Product, Transaction, ActivityLog)
✅ Veritabanı bağlantı sistemi hazırlandı
✅ Tüm açıklamalar Türkçe ve detaylı

**Sonraki Adım:** SEVIYE 3 - JWT ve Referral Sistemi

---

## SEVIYE 3: Güvenlik Duvarı
### Kimlik Doğrulama ve Referans Sistemi (30% - 50%)

#### ✅ 3.1 Bcrypt Password Hashing Sistemi
**Neler Yapıldı:**
`app/utils/security.py` dosyasında password hashing fonksiyonları yazıldı

```python
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password: str) -> str:
    """Şifreyi Bcrypt ile hashle"""
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Girilen şifreyi hash ile karşılaştır"""
    return pwd_context.verify(plain_password, hashed_password)
```

**Açıklama:**
- **Bcrypt neden?** Intentionally yavaş (brute-force attack'e karşı)
- **Salt**: Otomatik ve random (rainbow table attack'e karşı)
- **Cost Factor**: 12 (default) - Her iterasyon 2^12 işlem
- **Güvenlik**: Industry standard, OWASP tavsiyesi

---

#### ✅ 3.2 JWT Token Generation & Validation
**Neler Yapıldı:**
JWT token oluşturma ve doğrulama sistemi kuruldu

```python
# Token oluştur
def create_access_token(data: dict) -> str:
    """30 dakikalık short-lived token"""
    payload = data.copy()
    payload["exp"] = datetime.utcnow() + timedelta(minutes=30)
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

# Token doğrula
def verify_token(token: str) -> Optional[dict]:
    """Token'ı decode et ve imzayı kontrol et"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return payload
    except JWTError:
        return None
```

**Teknik Detaylar:**
- **Algoritma**: HS256 (HMAC SHA-256)
- **Access Token**: 30 dakika (kısa ömürlü, güvenli)
- **Refresh Token**: 7 gün (uzun ömürlü, token yenileme için)
- **Payload**: `{"sub": email, "user_id": id, "exp": timestamp}`

**Token Akışı:**
1. User login → verify_password
2. create_access_token + create_refresh_token
3. Frontend'e token'ları gönder
4. Frontend her istekle Authorization header'da gönder
5. Backend verify_token ile doğrula
6. Token geçerli → İşlem yap, geçersiz → 401 Unauthorized

---

#### ✅ 3.3 Referral Kodu Oluşturma & Doğrulama
**Neler Yapıldı:**

```python
def generate_referral_code(user_id: int) -> str:
    """BAYI + 5 rasgele rakam = BAYI12345"""
    random_num = random.randint(10000, 99999)
    return f"BAYI{random_num}"

def validate_referral_code(ref_code: str, db: Session) -> Optional[User]:
    """Referral code'u doğrula ve sahibini bul"""
    user = db.query(User).filter(
        User.ref_code == ref_code.upper()
    ).first()
    return user
```

**Referral Sistemi Akışı:**
1. Bayı kayıt olurken otomatik ref_code oluşturulur
2. Diğer bayılar bu kodu girip kayıt olabilir
3. Referral bonusu:
   - Yeni bayı: 14 gün → 24 gün (+10 bonus)
   - Referrer (davet eden): +10 gün
4. Anti-fraud: Aynı IP'den kendi kendine referral olamaz

---

#### ✅ 3.4 IP-Based Fraud Detection
**Neler Yapıldı:**

```python
def get_client_ip(request: Request) -> str:
    """İstemcinin IP adresini al (proxy arkasında da çalışır)"""
    forwarded_for = request.headers.get("X-Forwarded-For")
    if forwarded_for:
        return forwarded_for.split(",")[0].strip()
    return request.client.host

def check_duplicate_registration(
    email: str,
    ip_address: str,
    db: Session
) -> tuple[bool, Optional[str]]:
    """Aynı email ve IP'den çoklu kayıt engelle"""
    # 1. Email zaten var mı?
    if db.query(User).filter(User.email == email).first():
        return True, "Email zaten kayıtlı"
    
    # 2. Aynı IP'den 30 gün içinde 5+ kayıt var mı?
    recent = db.query(User).filter(
        User.ip_address == ip_address,
        User.created_at > datetime.utcnow() - timedelta(days=30)
    ).count()
    
    if recent >= 5:
        return True, "Bu IP'den çok sayıda kayıt yapılmış"
    
    return False, None
```

**Anti-Fraud Kuralları:**
- ❌ Aynı email ile 2 kez kayıt → Red
- ❌ Aynı IP'den 30 gün içinde 5+ kayıt → Red
- ❌ Kendi kendine referral (self-reference) → Red
- ✅ Farklı email, farklı IP → OK
- ✅ Referral code + bonus → OK

---

#### ✅ 3.5 Authentication Endpoints (app/api/auth.py)
**Neler Yapıldı:**
5 ana authentication endpoint'i yazıldı

**1. POST /api/v1/auth/register (Kayıt)**
```json
{
  "email": "ahmet@stokfinans.com",
  "password": "sifre123",
  "full_name": "Ahmet Yılmaz",
  "company_name": "Etiket Oto",
  "role": "bayi_sahibi",
  "ref_code": "BAYI12345"  // Opsiyonel
}
```

İşlem:
1. Email ve IP kontrolü → Duplicate check
2. Referral code doğrulama (varsa)
3. Şifre hashle (Bcrypt)
4. User oluştur
5. Token'ları oluştur (access + refresh)
6. Otomatik login

**2. POST /api/v1/auth/login (Giriş)**
```json
{
  "email": "ahmet@stokfinans.com",
  "password": "sifre123"
}
```

İşlem:
1. Kullanıcıyı bul
2. Şifreyi doğrula (verify_password)
3. Hesap aktif mi kontrol
4. Abonelik süresi geçmiş mi kontrol
5. Token'ları oluştur
6. Token + kullanıcı bilgileri döndür

**3. POST /api/v1/auth/refresh (Token Yenileme)**
```json
{
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

İşlem:
1. Refresh token'ı doğrula
2. Kullanıcıyı bul
3. Yeni access token oluştur
4. Eski token ile yeni token arasında seamless transition

**4. POST /api/v1/auth/logout (Çıkış)**
- Stateless JWT olduğu için backend'de işlem yok
- Frontend token'ı localStorage'dan siler
- Log kaydı yapılabilir (opsiyonel)

**5. GET /api/v1/auth/profile (Profil)**
- Authorization header ile doğrulama gerekli
- get_current_user dependency'si kullanuyor
- Mevcut kullanıcı bilgilerini döndürüyor

---

#### ✅ 3.6 Authentication Utilities (app/utils/auth.py)
**Neler Yapıldı:**

```python
async def get_current_user(request: Request, db: Session) -> User:
    """Endpoint'lerde kullanılacak dependency"""
    # Authorization header'dan token al
    # Token'ı doğrula
    # Kullanıcıyı veritabanından bul
    # Hesap aktif mi kontrol
    # Kullanıcı nesnesini döndür

async def get_current_admin(current_user: User) -> User:
    """Sadece Bayı Sahibi rolü için"""
    # Rol kontrolü: bayi_sahibi mı?
    # Evet → OK, Hayır → 403 Forbidden

def check_email_exists(email: str, db: Session) -> bool:
    """Email zaten kayıtlı mı?"""
    
def validate_referral_code(ref_code: str, db: Session) -> Optional[User]:
    """Referral code'u doğrula ve sahibini bul"""

def check_subscription_valid(user: User) -> bool:
    """Abonelik aktif mi? (sub_days > 0)"""
```

**Kullanım Örneği:**
```python
@app.get("/api/v1/dashboard/stats")
def get_dashboard(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # current_user otomatik doğrulanır
    # Token geçersizse 401 error
    return {"user": current_user.full_name}

@app.delete("/api/v1/employees/{id}")
def delete_employee(
    id: int,
    current_admin: User = Depends(get_current_admin),
    db: Session = Depends(get_db)
):
    # Sadece admin erişebilir
    # Çalışan hesabı 403 error
```

---

#### ✅ 3.7 Pydantic Schemas Güncellendi
**Neler Yapıldı:**
Login cevabına expires_in eklendi ve yeni schemas oluşturuldu

```python
class LoginResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: UserResponse
    expires_in: int  # Saniye cinsinden (1800 = 30 min)

class RegisterResponse(BaseModel):
    message: str
    user: UserResponse
    access_token: str
    refresh_token: str

class TokenRefreshResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
```

---

**Tamamlanan SEVIYE 3 İletişim Özeti:**
✅ Bcrypt password hashing
✅ JWT token generation & validation
✅ Access token (30 min) + Refresh token (7 gün)
✅ Referral sistemi (kod oluşturma + doğrulama)
✅ IP-based fraud detection (5+ kayıt in 30 days)
✅ 5 auth endpoint'i (register, login, refresh, logout, profile)
✅ Role-based access control (get_current_admin)
✅ Dependency injection (get_current_user)
✅ Tüm açıklamalar detaylı ve Türkçe

**Oluşturulan Dosyalar:**
- app/utils/security.py (210 satır)
- app/utils/auth.py (220 satır)
- app/api/auth.py (350 satır)
- Updated: app/schemas/user.py, main.py

**Sonraki Adım:** SEVIYE 4 - Product, Transaction, Finance endpoint'leri

---

## Teknik Kararlar

### 1. Python Framework Seçimi: FastAPI
**Neden FastAPI?**
- ⚡ **Hız:** Uvicorn ile async desteği, çok hızlı yanıt
- 📖 **Otomatik Dokümantasyon:** Swagger UI ile API dokümantasyonu otomatik
- 🔒 **Type Hints:** Python 3.6+ ile türlendirme desteği
- 🎯 **Kolay Öğrenme:** Flask benzeri basit API yazımı
- 🔄 **CORS Desteği:** Frontend entegrasyonu kolay

**Alternatifler Neden Seçilmedi:**
- Django: Çok ağır, bu proje için overkill
- Flask: Çok basit, büyük ölçekte zorluk
- Go: Ekip Python bilirse tercih edilir

### 2. Veritabanı Seçimi: PostgreSQL (Prod) + SQLite (Dev)
**Neden Hybrid Yaklaşım?**
- **Geliştirme:** SQLite - Kurulum gerektirmiyor, dosya tabanlı
- **Üretim:** PostgreSQL - Çok kullanıcılı, güvenli, ölçeklenebilir

### 3. Frontend: React (Mevcut) + Vite
**Neden React?**
- Mevcut UI zaten React ile yazılı
- Kolay state yönetimi (Context API)
- Büyük komunite ve kütüphane desteği

---

## Kurulum Rehberi

### Backend Kurulumu (Python)
```bash
# 1. Sanal ortam oluştur
python -m venv venv

# 2. Sanal ortamı aktif et (Windows)
venv\Scripts\activate

# 3. Gerekli paketleri kur
pip install fastapi uvicorn sqlalchemy pydantic python-dotenv

# 4. requirements.txt oluştur
pip freeze > requirements.txt
```

### Frontend Kurulumu (Node.js)
```bash
# 1. Node modules kur
npm install

# 2. Geliştirme sunucusunu başlat
npm run dev

# 3. Tarayıcıda aç
# http://localhost:5173
```

---

## Yapılmış İşler Kontrol Listesi

### SEVIYE 1: Temel Kamp (100% Tamamlandı ✅)
- [x] Git repository oluşturuldu
- [x] Klasör mimarisi kuruldu
- [x] .gitignore dosyası oluşturuldu
- [ ] Backend environment kurulumu (SONRAKI ADIM)
- [ ] Frontend build setup (SONRAKI ADIM)

### SEVIYE 2: Zemin Kat (0% - Bekleniyor)
- [ ] SQLite geliştirme DB kurulumu
- [ ] SQLAlchemy modelleri yazılması
- [ ] Alembic migrations kurulması

### SEVIYE 3: Güvenlik Duvarı (0% - Bekleniyor)
- [ ] Bcrypt password hashing
- [ ] JWT token generation
- [ ] IP-based referral protection

---

## Son Güncellemeler

**28 Nisan 2026, 17:45 - SEVIYE 2 TAMAMLANDI ✅**
- ✅ Python sanal ortamı (venv) oluşturuldu
- ✅ Backend klasör yapısı kuruldu
- ✅ requirements.txt ile tüm bağımlılıklar tanımlandı
- ✅ 4 SQLAlchemy modeli yazıldı:
  - User (Kullanıcı)
  - Product (Ürün)
  - Transaction (İşlem/Cari)
  - ActivityLog (Faaliyet Günlüğü)
- ✅ Veritabanı bağlantı sistemi (database.py) oluşturuldu
- ✅ Pydantic validation schemas yazıldı
- ✅ FastAPI ana uygulaması (main.py) oluşturuldu
- ✅ Kapsamlı README.md hazırlandı
- ✅ DEVELOPMENT.md detaylı güncellendi

---

## 📊 Proje İlerleme Durumu

```
SEVIYE 1: Temel Kamp          ████████████████ 100% ✅
SEVIYE 2: Zemin Kat           ████████████████ 100% ✅
SEVIYE 3: Güvenlik Duvarı     ░░░░░░░░░░░░░░░░   0% 📋
SEVIYE 4: Motor Odası         ░░░░░░░░░░░░░░░░   0% 📋
SEVIYE 5: Gelişmiş Özellikler ░░░░░░░░░░░░░░░░   0% 📋
SEVIYE 6: Köprü Kurma         ░░░░░░░░░░░░░░░░   0% 📋
SEVIYE 7: Zirve & Deployment  ░░░░░░░░░░░░░░░░   0% 📋

TOPLAM İLERLEME: 28% (2 seviye tamamlandı)
```

---

## 📁 Mevcut Proje Yapısı

```
stokfinans.com/
├── .git/                          # Git history
├── .gitignore                     # Git'in izlemeyeceği dosyalar
├── DEVELOPMENT.md                 # Bu dokümantasyon
├── README.md                      # (Yapılacak)
│
├── frontend/                      # React uygulaması (boş)
│
├── backend/                       # Python FastAPI uygulaması
│   ├── venv/                      # Python sanal ortamı
│   │   └── (Python paketleri)
│   │
│   ├── app/                       # Ana uygulama paketi
│   │   ├── __init__.py
│   │   │
│   │   ├── core/
│   │   │   ├── __init__.py
│   │   │   └── database.py        # SQLAlchemy engine & session
│   │   │
│   │   ├── models/                # Veritabanı modelleri (ORM)
│   │   │   ├── __init__.py
│   │   │   ├── user.py            # User tablosu
│   │   │   ├── product.py         # Product tablosu
│   │   │   ├── transaction.py     # Transaction tablosu
│   │   │   └── log.py             # ActivityLog tablosu
│   │   │
│   │   ├── schemas/               # Pydantic validation
│   │   │   ├── __init__.py
│   │   │   └── user.py            # User request/response
│   │   │
│   │   ├── api/                   # API endpoints (yapılacak)
│   │   │   └── __init__.py
│   │   │
│   │   ├── services/              # Business logic (yapılacak)
│   │   │   └── __init__.py
│   │   │
│   │   └── utils/                 # Yardımcı fonksiyonlar (yapılacak)
│   │       └── __init__.py
│   │
│   ├── logs/                      # Uygulama logları
│   ├── uploads/                   # Yüklenen dosyalar
│   │
│   ├── main.py                    # FastAPI uygulaması
│   ├── requirements.txt           # Python bağımlılıkları
│   ├── .env.example              # Çevre değişkenleri şablonu
│   └── README.md                  # Backend dokümantasyonu
│
├── docs/                          # Teknik dokümantasyon
│
└── Site.md                        # Eski React kodu (referans)
```

---

**Sonraki Hedef:** SEVIYE 3 - JWT Authentication ve Referral Sistemi kurulması

---

## 🎯 Sonraki Aşamada Yapılacaklar (SEVIYE 3)

1. **JWT Token Sistemi**
   - Login endpointi yazma
   - Token generation ve validation
   - Token refresh mekanizması

2. **Referral Sistemi**
   - IP-based fraud detection
   - Referral code generation
   - Sub_days otomatik ekleme

3. **Password Hashing**
   - Bcrypt integration
   - Hash verification

4. **Database Migration**
   - Alembic setup
   - Initial migration

---

## SEVIYE 4: Motor Odası
### Ürün, Finansman ve Dashboard Endpoint'leri (42.8% - 60%)

#### ✅ 4.1 Product Endpoints (CRUD + Search/Filter)
**Neler Yapıldı:**

1. **Schemas (product.py)** - 270 satır
   - `ProductCreateRequest`: Ürün oluşturma isteği (name, category, barcode, price, cost, quantity, min_stock_alert)
   - `ProductUpdateRequest`: Kısmi güncellemeler (tüm alanlar opsiyonel)
   - `ProductResponse`: Tekil ürün cevabı (id, name, profit_margin, is_critical_stock, created_at, updated_at)
   - `ProductListResponse`: Pagination desteği (items, total, page, page_size, total_pages)
   - `ProductStockResponse`: Stok durumu (id, quantity, min_stock_alert, shortage, reorder_quantity)
   - `CriticalStockListResponse`: Kritik stok listesi (items, total, severity)

2. **API Endpoints (app/api/products.py)** - 580 satır

   **POST /api/v1/products** (201 Created)
   - Yeni ürün oluştur
   - Barcode çakışması kontrolü
   - Kar marjı otomatik hesapla: `((price - cost) / cost) * 100`
   - ActivityLog'a kaydı kaydet
   - Veritabanına kaydet ve response döndür

   **GET /api/v1/products** (200 OK)
   - Ürünleri listele (pagination)
   - Arama: `name` veya `barcode` alanında
   - Filtreleme: `category`, `low_stock_only` (boolean)
   - Sıralama: `name`, `price`, `quantity`, `created_at`
   - Pagination: `page`, `page_size` (1-100)
   - Örnek: `/products?search=kilidi&category=aksesuar&low_stock_only=true&page=1&page_size=20`

   **GET /api/v1/products/{product_id}** (200 OK)
   - Tek ürünün detaylı bilgisi
   - Kar marjı ve kritik stok durumu hesapla

   **PUT /api/v1/products/{product_id}** (200 OK)
   - Ürün güncelle (kısmi güncellemeler)
   - Barcode değişirse yeni barcode benzersizliğini kontrol et
   - updated_at zaman damgasını güncelle
   - ActivityLog'a güncelleme kaydı kaydet

   **DELETE /api/v1/products/{product_id}** (200 OK)
   - Ürünü tamamen sil
   - ActivityLog'a silme işlemi kaydet
   - Silme onayı döndür

   **GET /api/v1/products/stock/critical** (200 OK)
   - Kritik stok (quantity <= min_stock_alert) ürünleri listele
   - Severity hesapla: shortage_percentage'e göre ("low", "medium", "critical")
   - Önerilen sipariş miktarı: shortage * 2
   - Kritik ürün varsa priority="high", medium varsa "medium", aksi halde "low"

**Yardımcı Fonksiyonlar:**
- `calculate_profit_margin(price, cost)`: Kar marjı hesapla
- `is_critical_stock(quantity, min_stock_alert)`: Kritik stok kontrolü
- `log_activity(db, user_id, action, entity_type, entity_id, details)`: ActivityLog kaydet

**Teknoloji Detayları:**
- SQLAlchemy `filter()`, `ilike()` (case-insensitive search), `order_by()`, `offset()`, `limit()` kullanıldı
- Pagination: `total_pages = math.ceil(total / page_size)`, `skip = (page - 1) * page_size`
- Response modellerinde `from_attributes=True` (SQLAlchemy modelden doğrudan dönüştürme)
- Authorization: `Depends(get_current_user)` ile korunan endpoint'ler

**Status Kodları:**
- 201 Created: Başarılı ürün oluşturma
- 200 OK: Başarılı GET, PUT, DELETE
- 400 Bad Request: Barcode çakışması, geçersiz veri
- 404 Not Found: Ürün bulunamadı
- 401 Unauthorized: Token geçersiz veya eksik

---

#### ✅ 4.2 Finance/Transaction Endpoints
**Neler Yapıldı:**

1. **Schemas (transaction.py)** - 250 satır
   - `TransactionCreateRequest`: İşlem oluştur (transaction_type, customer_name, amount, products, notes)
   - `TransactionUpdateRequest`: İşlem güncelle (customer_name, amount, notes)
   - `TransactionResponse`: İşlem detayları (id, type, customer, amount, created_at, notes)
   - `BalanceResponse`: Müşteri bakiyesi (total_debt, total_paid, balance, last_transaction)
   - `FinancialSummaryResponse`: Genel finansman özeti (total_sales, total_debt, total_paid, net_balance)

2. **API Endpoints (app/api/finance.py)** - 620 satır

   **POST /api/v1/finance/transactions** (201 Created)
   - Yeni işlem oluştur (satış/borç/ödeme)
   - İşlem türleri: "satış"/"sale", "borç"/"debt", "ödeme"/"payment"
   - Satış işleminde ürün stok kontrol ve otomatik azaltma
   - Yetersiz stok varsa 400 hatası
   - ActivityLog'a işlem kaydı kaydet

   **GET /api/v1/finance/transactions** (200 OK)
   - İşlemleri listele (pagination)
   - Filtreleme: `transaction_type`, `customer_name` (arama), `days` (son kaç gün, default: 30)
   - Sıralama: En yeni işlemler önce (created_at DESC)
   - Pagination: page, page_size
   - Response'da toplam tutarı döndür (total_amount)
   - Örnek: `/finance/transactions?days=7&transaction_type=satış&customer_name=Mehmet`

   **GET /api/v1/finance/transactions/{transaction_id}** (200 OK)
   - Tek işlemin detaylı bilgisi

   **PUT /api/v1/finance/transactions/{transaction_id}** (200 OK)
   - İşlem güncelle (customer_name, amount, notes)
   - transaction_type değiştirilemez
   - ActivityLog'a güncelleme kaydı kaydet

   **DELETE /api/v1/finance/transactions/{transaction_id}** (200 OK)
   - İşlem kaydını sil
   - ActivityLog'a silme işlemi kaydet

   **GET /api/v1/finance/balance/{customer_name}** (200 OK)
   - Müşteri bazında bakiye hesapla
   - Formüla: `balance = total_debt - total_paid` (pozitif=borçlu, negatif=alacaklı)
   - Son işlem tarihini göster
   - İşlem sayısını sayıştır

   **GET /api/v1/finance/summary** (200 OK)
   - Genel finansman özeti
   - Süzme: `days` parametresi (opsiyonel)
   - Metrikleri hesapla:
     * total_sales: satış işlemlerinin toplamı
     * total_debt: borç işlemlerinin toplamı
     * total_paid: ödeme işlemlerinin toplamı
     * net_balance: satış - borç + ödeme
     * unique_customers: farklı müşteri sayısı

**Yardımcı Fonksiyonlar:**
- `calculate_customer_balance(db, customer_name)`: Müşteri bakiyesi hesapla
- `log_activity()`: ActivityLog kaydet

**Teknoloji Detayları:**
- SQLAlchemy `filter()`, `or_()`, `and_()`, `distinct()`, `sum()`, `count()` kullanıldı
- Tarih filtreleme: `datetime.now() - timedelta(days=days)`
- Response'da `total_amount` (sayfadaki işlemlerin toplamı) eklendi
- Stok yönetimi: satış işleminde `product.quantity -= quantity` otomatik azaltma

**Status Kodları:**
- 201 Created: İşlem oluşturma
- 200 OK: Başarılı işlemler
- 400 Bad Request: Geçersiz işlem türü, yetersiz stok, ürün bulunamadı
- 404 Not Found: İşlem bulunamadı
- 401 Unauthorized: Token geçersiz

---

#### ✅ 4.3 Dashboard & Statistics Endpoints
**Neler Yapıldı:**

1. **Schemas (dashboard.py)** - 280 satır
   - `StatsItem`: İstatistik öğesi (label, value, percentage_change, trend)
   - `DashboardStatsResponse`: Ana istatistikler (total_products, critical_stock_count, total_customers, total_sales, total_revenue, outstanding_debt)
   - `CriticalStockAlertsResponse`: Kritik stok uyarıları (total_alerts, critical, medium, low, priority)
   - `PerformanceResponse`: Performans metrikleri (daily_avg_sales, inventory_turnover, profit_margin_avg)
   - `ChartDataResponse`: Grafik verisi zaman serisi (chart_type, period, data)

2. **API Endpoints (app/api/dashboard.py)** - 640 satır

   **GET /api/v1/dashboard/stats** (200 OK)
   - Ana istatistikler (KPI'lar)
   - Dönem: `days` parametresi (default: 30)
   - Metrikleri döndür:
     * total_products: toplam ürün sayısı
     * total_categories: kategori çeşitliliği
     * critical_stock_count: kritik stok ürün sayısı
     * total_customers: farklı müşteri sayısı
     * total_sales: satış tutarı
     * total_revenue: tahmini gelir (satış x ort.kar marjı)
     * outstanding_debt: ödenmemiş müşteri borçları
   - Trend hesapla: mevcut dönem vs önceki dönem karşılaştırması
     * percentage_change: yüzde değişim
     * trend: "up" (>5%), "down" (<-5%), "flat"

   **GET /api/v1/dashboard/critical-stock** (200 OK)
   - Kritik stok uyarıları detaylı
   - Her ürün için:
     * shortage: eksiklik miktarı (min_alert - quantity)
     * severity: "critical" (>60%), "medium" (30-60%), "low" (<30%)
     * reorder_quantity: önerilen sipariş (shortage * 2)
   - Genel priority: "high" (critical var), "medium" (medium var), "low"
   - total_shortage_value: eksik stok tutarı (shortage * price)

   **GET /api/v1/dashboard/performance** (200 OK)
   - Performans metrikleri
   - Dönem: `days` (default: 30)
   - Hesaplanan metrikler:
     * daily_average_sales: günlük ort. satış
     * weekly_average_sales: haftalık ort. satış
     * best_selling_product: en çok satılan ürün
     * inventory_turnover: stok döngüsü (satış / ort.stok)
     * profit_margin_average: ort. kar marjı

   **GET /api/v1/dashboard/chart-data** (200 OK)
   - Zaman serisi grafik verisi
   - Chart türleri: "sales" (satış tutarı), "revenue" (tahmini gelir), "transactions" (işlem sayısı)
   - Dönem: `days` (1-365)
   - Her gün için:
     * date: YYYY-MM-DD format
     * sales: günlük satış tutarı
     * transactions: işlem sayısı
     * customers: müşteri sayısı
   - Sıfır satışlı günler de dahil (grafik boşluk olmasın diye)

   **GET /api/v1/dashboard** (200 OK)
   - Dashboard tam özeti (tüm veriler bir çağrıda)
   - İçerir:
     * stats: ana istatistikler
     * critical_alerts: kritik stok uyarıları
     * performance: performans metrikleri
     * generated_at: oluşturulma tarihi

**Yardımcı Fonksiyonlar:**
- `get_product_stats(db, days)`: Ürün istatistikleri
- `get_sales_metrics(db, days)`: Satış metrikleri
- `calculate_trend(current, previous)`: Trend hesapla (yüzde değişim + direction)

**Teknoloji Detayları:**
- SQLAlchemy `func.sum()`, `func.count()`, `func.avg()`, `distinct()`, `count()` kullanıldı
- Tarih aralığı işlemleri: `datetime.now() - timedelta(days=)`
- Trend hesapları: önceki dönem (days*2) ile mevcut dönem (days) karşılaştırması
- Severity hesabı: shortage_percentage = (shortage / min_alert) * 100
- Inventory Turnover: total_sales / avg_stock (basitleştirilmiş hesap)
- Sıfır satışlı günler: for loop ile tüm günlerin verisini oluştur (boşluk olmasın diye)

**Response Format:**
- Tüm metrikleri 2 ondalık basamağa yuvarla (round())
- Tarihler ISO 8601 format (YYYY-MM-DDThh:mm:ss)
- Period string'i: f"last_{days}_days" veya "all_time"

**Status Kodları:**
- 200 OK: Başarılı dashboard çağrısı
- 401 Unauthorized: Token geçersiz

---

#### ✅ 4.4 Main Router Integration
**Neler Yapıldı:**

main.py dosyasında yeni router'lar entegre edildi:

```python
from app.api.auth import router as auth_router
from app.api.products import router as products_router
from app.api.finance import router as finance_router
from app.api.dashboard import router as dashboard_router

app.include_router(auth_router, prefix="/api/v1", tags=["Authentication"])
app.include_router(products_router, prefix="/api/v1", tags=["Products"])
app.include_router(finance_router, prefix="/api/v1", tags=["Finance"])
app.include_router(dashboard_router, prefix="/api/v1", tags=["Dashboard"])
```

**Sonuç:**
- FastAPI otomatik olarak tüm endpoint'leri Swagger UI'da gösterir
- `/api/docs` adresinde etkileşimli dokümantasyon mevcut
- Her endpoint'in detaylı açıklaması ve örnek request/response'u var

---

## 📚 Kaynaklar ve Dosyalar

| Dosya | Amaç | Durum |
|-------|------|-------|
| DEVELOPMENT.md | Ana dokümantasyon | ✅ Aktif |
| backend/README.md | Backend rehberi | ✅ Oluşturuldu |
| backend/main.py | FastAPI app | ✅ Güncellendi |
| backend/requirements.txt | Bağımlılıklar | ✅ Oluşturuldu |
| backend/app/models/*.py | Veritabanı modelleri | ✅ Tamamlandı |
| backend/app/schemas/user.py | User validation | ✅ Tamamlandı |
| backend/app/schemas/product.py | Product validation | ✅ Tamamlandı |
| backend/app/schemas/transaction.py | Transaction validation | ✅ Tamamlandı |
| backend/app/schemas/dashboard.py | Dashboard validation | ✅ Tamamlandı |
| backend/app/api/auth.py | Auth endpoint'leri | ✅ Tamamlandı |
| backend/app/api/products.py | Product endpoint'leri | ✅ Tamamlandı |
| backend/app/api/finance.py | Finance endpoint'leri | ✅ Tamamlandı |
| backend/app/api/dashboard.py | Dashboard endpoint'leri | ✅ Tamamlandı |
| backend/app/utils/security.py | Password & Token | ✅ Tamamlandı |
| backend/app/utils/auth.py | Auth utilities | ✅ Tamamlandı |
| backend/test_api.py | Manuel test suite | ✅ Oluşturuldu |

---

## SEVIYE 5: Gelişmiş Özellikler
### File Upload, PDF Raporlar ve Backend Optimizasyonları (60% - 75%)

#### ✅ 5.1 File Upload Endpoints (Ürün & İşlem Dosyaları)

**Neler Yapıldı:**

1. **Schemas (file.py)** - 120 satır
   - `FileUploadResponse`: Dosya yükleme cevabı
   - `ProductImageResponse`: Ürün fotoğrafı bilgisi
   - `TransactionAttachmentResponse`: İşlem belgesi bilgisi
   - `FileDeleteResponse`: Dosya silme cevabı

2. **API Endpoints (app/api/files.py)** - 480 satır

   **POST /api/v1/files/product/{product_id}/image** (201 Created)
   - Ürüne ait fotoğraf yükle
   - Format kontrolü: JPEG, PNG, WebP
   - Maksimum boyut: 10MB
   - Benzersiz dosya adı: `product_{id}_{uuid}.jpg`
   - Ürün modeline image_url kaydı

   **POST /api/v1/files/transaction/{transaction_id}/attachment** (201 Created)
   - İşleme ait belge yükle (fiş, fatura, kontrat)
   - Format kontrolü: PDF, JPEG, PNG
   - attachment_type parametresi: "receipt", "invoice", "contract"
   - İşlem modeline attachment_url kaydı

   **GET /api/v1/files/{filename}** (200 OK)
   - Dosya indir
   - Path Traversal saldırısı engellemesi (.. kontrolü)
   - FileResponse ile binary download

   **DELETE /api/v1/files/{filename}** (200 OK)
   - Dosya sil
   - İlgili ürün/işlem modelinden URL'i temizle
   - Disk'ten dosya sil

**Teknoloji Detayları:**
- UUID ile benzersiz dosya adı: `uuid.uuid4()[:8]`
- Path Traversal koruması: `if ".." in filename or filename.startswith("/")`
- Dosya boyutu kontrolü: `len(content) > MAX_FILE_SIZE`
- MIME type doğrulama: `file.content_type not in allowed_formats`
- Directory oluşturma: `Path("backend/uploads").mkdir(parents=True, exist_ok=True)`

---

#### ✅ 5.2 PDF Report Endpoints (Raporlar)

**Neler Yapıldı:**

1. **API Endpoints (app/api/reports.py)** - 540 satır

   **GET /api/v1/reports/daily** (200 OK)
   - Günlük satış raporu oluştur
   - Query param: `report_date` (YYYY-MM-DD, default: bugün)
   - Hesaplanan metrikler:
     * total_sales: Günlük toplam satış
     * total_debt: Müşteri borçları
     * total_paid: Alınan ödemeler
     * transaction_count: İşlem sayısı
     * unique_customers: Müşteri sayısı
   - Tarih aralığı: 00:00:00 → 23:59:59

   **GET /api/v1/reports/monthly** (200 OK)
   - Aylık finansman raporu oluştur
   - Query params: `year` (2000-2100), `month` (1-12)
   - Hesaplanacak metrikleri hesapla + daily_average
   - Aylık tarih aralığını otomatik belirle

   **GET /api/v1/reports/custom** (200 OK)
   - Özel tarih aralığı raporu oluştur
   - Query params: `start_date`, `end_date` (YYYY-MM-DD)
   - Validasyonlar:
     * start_date <= end_date
     * Maksimum aralık: 365 gün
   - Günlük ortalama satış: total_sales / days

**Teknoloji Detayları:**
- Tarih doğrulama: `datetime.strptime(date_str, "%Y-%m-%d")`
- Tarih aralığı: `datetime.combine(date, datetime.min.time())`
- Aylık son gün hesap: `datetime(year+1, 1, 1) - timedelta(seconds=1)`
- PDF simulasyon: Basit text-to-PDF (production'da reportlab, weasyprint)
- Dosya kaydet: `REPORTS_DIR / filename`, `open(file_path, "wb")`

---

#### ✅ 5.3 Güvenlik Özellikleri

| Özellik | Durum | Açıklama |
|---------|-------|----------|
| **Path Traversal** | ✅ | ".." ve "/" başında dosya adı engelle |
| **File Type Validation** | ✅ | MIME type doğrulama (JPEG/PNG/PDF) |
| **File Size Limit** | ✅ | 10MB maksimum dosya boyutu |
| **Filename Uniqueness** | ✅ | UUID ile benzersiz ad oluştur |
| **Authorization** | ✅ | Tüm endpoint'ler Depends(get_current_user) |
| **Soft Delete** | ✅ | Dosya silerken model alanları temizle |
| **Date Validation** | ✅ | YYYY-MM-DD formatı ve aralık kontrolü |

---

#### ✅ 5.4 Yeni Endpoint'ler

**File Management (4 endpoint):**
- POST /api/v1/files/product/{product_id}/image
- POST /api/v1/files/transaction/{transaction_id}/attachment
- GET /api/v1/files/{filename}
- DELETE /api/v1/files/{filename}

**Reports (3 endpoint):**
- GET /api/v1/reports/daily
- GET /api/v1/reports/monthly
- GET /api/v1/reports/custom

**Toplam Endpoint: 23 → 30 (+7 yeni endpoint)**

---

## 📚 Güncel Dosya Yapısı

```
backend/
├── app/
│   ├── api/
│   │   ├── auth.py           ✅ 350 satır
│   │   ├── products.py       ✅ 580 satır
│   │   ├── finance.py        ✅ 620 satır
│   │   ├── dashboard.py      ✅ 640 satır
│   │   ├── files.py          ✅ 480 satır (YENİ SEVIYE 5)
│   │   └── reports.py        ✅ 540 satır (YENİ SEVIYE 5)
│   │
│   ├── schemas/
│   │   ├── user.py           ✅ 200 satır
│   │   ├── product.py        ✅ 270 satır
│   │   ├── transaction.py    ✅ 250 satır
│   │   ├── dashboard.py      ✅ 280 satır
│   │   └── file.py           ✅ 120 satır (YENİ SEVIYE 5)
│   │
│   └── models/               ✅ 402 satır
│
├── uploads/                  [Yüklenen dosyalar]
├── reports/                  [Oluşturulan raporlar]
└── main.py                   ✅ Güncellendi (6 router dahil)
```

---

---

## SEVIYE 6: Köprü Kurma
### Frontend-Backend Entegrasyonu (75% - 85%)

**Tamamlandı!** 1200+ satır React + TypeScript kodu

✅ React 18 + Vite 5 + TypeScript  
✅ Axios HTTP client (600+ satır)  
✅ Context API authentication  
✅ Protected routes  
✅ Login ve Dashboard pages  
✅ Tailwind CSS responsive design  
✅ 30 API endpoint entegrasyonu  

---

## SEVIYE 7: Zirve & Deployment
### Production Hazırlığı ve Container Orchestration (85% - 100%)

**Tarih:** 28 Nisan 2026  
**Zaman:** 2 saat  

### ✅ 7.1 Backend Dockerfile
**Neler Yapıldı:**

Çok aşamalı (multi-stage) Docker build sistemi:

```dockerfile
# Stage 1: Base Image (python:3.13-slim)
- Sistem paketleri: gcc, postgresql-client
- PYTHONUNBUFFERED=1 (container logları hemen yazılsın)
- PYTHONDONTWRITEBYTECODE=1 (cache dosyaları oluşturulmasın)

# Stage 2: Dependencies
- requirements.txt kopyalanır
- pip install --no-cache-dir -r requirements.txt

# Stage 3: Development (--reload ile hot reload)
- Tüm kaynak kod kopyalanır
- uvicorn main:app --host 0.0.0.0 --port 8000 --reload
- Geliştirme sırasında kodda yapılan değişiklikler anında uygulanır

# Stage 4: Production (4 workers)
- Non-root user oluşturulur (appuser:1000) - güvenlik
- Tüm /app dizini appuser'a ait kılınır
- uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
- HEALTHCHECK: curl http://localhost:8000/health her 30 saniyede
```

**Teknik Detaylar:**

- **Multi-stage build** → Final image sadece dependencies + code içerir
- **Non-root user** → Konteyner bir saldırıya uğrarsa damage sınırlı olur
- **Health checks** → Docker Compose, container sağlığını kontrol edebilir
- **Workers** → Uvicorn 4 process ile paralel request işleme

**Dosya:** `backend/Dockerfile` (85 satır)

---

### ✅ 7.2 Frontend Dockerfile
**Neler Yapıldı:**

Çok aşamalı build (Node builder → Nginx runner):

```dockerfile
# Stage 1: Build (Node 20 Alpine)
- npm ci (clean install - production dependencies)
- npm run build → dist/ klasörü oluşturulur (100 KB gzipped)

# Stage 2: Production (Nginx Alpine)
- nginx:alpine image çok hafif (15 MB)
- Nginx konfigürasyonu: /etc/nginx/conf.d/default.conf
- Built dist/ dizini: /usr/share/nginx/html
- Expose: 80 (HTTP) ve 443 (HTTPS ready)
- HEALTHCHECK: wget --spider http://localhost:80/

# Stage 3: Development (Optional)
- Node 20 alpine
- npm install (all dependencies with devDependencies)
- npm run dev → Vite dev server port 5173'te çalışır
- --host 0.0.0.0 → Docker'ın dışından erişilebilir
```

**Build Optimizasyonları:**

- **Alpine images** → `node:20-alpine` (75 MB), `nginx:alpine` (15 MB)
- **Multi-stage** → Final image sadece runtime artifacts içerir
- **npm ci** → Package-lock.json'dan reproducible install
- **Gzip compression** → dist/ dosyaları 91 KB → 100 KB gzipped

**Dosya:** `frontend/Dockerfile` (81 satır)

---

### ✅ 7.3 Frontend Nginx Yapılandırması
**Neler Yapıldı:**

Production-grade Nginx konfigürasyonu:

```nginx
# Upstream: Backend API yönlendirilmesi
upstream backend {
    server backend:8000;  # Docker network DNS
}

# Client Configuration
client_max_body_size 10M;  # Maksimum upload: 10 MB

# Gzip Compression
gzip on;
gzip_types text/plain text/css application/json application/javascript;
gzip_min_length 1000;  # 1 KB altındaki dosyalar sıkıştırılmaz
gzip_vary on;  # Content-Encoding header ekle

# Static Assets Caching (hash-busted filenames)
location ~* ^/assets/ {
    expires 1y;                          # Tarayıcıda 1 yıl cache
    add_header Cache-Control "public, immutable";  # Değişmeyecek dosyalar
}

# Favicon, Manifest Caching
location ~* \.(ico|png|json)$ {
    expires 7d;
    add_header Cache-Control "public";
}

# API Proxy (production de de /api/ yardımıyla frontend'ten backend'e ulaşılır)
location /api/ {
    proxy_pass http://backend;
    proxy_http_version 1.1;

    # Headers: Original request bilgilerini backend'e gönder
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;

    # WebSocket support
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";

    # Timeouts
    proxy_connect_timeout 60s;
    proxy_send_timeout 60s;
    proxy_read_timeout 60s;

    # Buffering
    proxy_buffering on;
    proxy_buffer_size 4k;
    proxy_buffers 8 4k;
}

# SPA Fallback (React Router için)
location / {
    try_files $uri $uri/ /index.html;
    add_header Cache-Control "no-cache, no-store, must-revalidate";
}

# Security Headers
add_header X-Frame-Options "SAMEORIGIN" always;           # Clickjacking önleme
add_header X-Content-Type-Options "nosniff" always;       # MIME sniffing önleme
add_header X-XSS-Protection "1; mode=block" always;       # XSS filtresi
add_header Referrer-Policy "strict-origin-when-cross-origin" always;

# Error Pages
error_page 404 /index.html;      # 404 → index.html (SPA routing)
error_page 500 502 503 504 /index.html;  # Server errors → index.html

# SSL Section (Production'da yapılandırılır)
# server {
#     listen 443 ssl http2;
#     ssl_certificate /etc/letsencrypt/live/stokfinans.com/fullchain.pem;
#     ssl_certificate_key /etc/letsencrypt/live/stokfinans.com/privkey.pem;
# }
```

**Teknik Açıklamalar:**

- **Upstream** → Load balancing (çoklu backend instance'ları için ölçeklenir)
- **try_files** → React Router SPA routing (tüm routes index.html'den sunulur)
- **Proxy headers** → Backend gerçek client IP'sini ve protocol'ünü bilir (logging, rate limiting için önemli)
- **Cache Control** → Hash-busted CSS/JS dosyaları 1 yıl cache, index.html hiçbir zaman cache'lenmez
- **Security headers** → OWASP güvenlik pratikleri

**Dosya:** `frontend/nginx.conf` (150 satır)

---

### ✅ 7.4 Docker Compose - Production
**Neler Yapıldı:**

Tam yığın orchestration (backend + frontend + database):

```yaml
version: '3.8'

services:
  backend:
    build:
      context: ./backend
      target: production        # 4 workers, non-root user
    ports:
      - "8000:8000"
    environment:
      DATABASE_URL: postgresql://user:pass@db:5432/db
      JWT_SECRET_KEY: (guarded)
      ALLOWED_ORIGINS: http://localhost:3000,...
    volumes:
      - ./backend:/app          # Kod mount edilmez (immutable)
      - backend_logs:/var/log/stokfinans
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 5s
    depends_on:
      db:
        condition: service_healthy
    networks:
      - stokfinans_network
    restart: unless-stopped

  frontend:
    build:
      context: ./frontend
      target: production        # Nginx static serving
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./frontend/nginx.conf:/etc/nginx/conf.d/default.conf:ro  # Read-only
      - frontend_logs:/var/log/nginx
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost:80/"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 5s
    depends_on:
      backend:
        condition: service_healthy
    networks:
      - stokfinans_network
    restart: unless-stopped

  db:
    image: postgres:16-alpine
    ports:
      - "5432:5432"
    environment:
      POSTGRES_USER: stokfinans_user
      POSTGRES_PASSWORD: stokfinans_secure_password
      POSTGRES_DB: stokfinans_db
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U stokfinans_user -d stokfinans_db"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - stokfinans_network
    restart: unless-stopped

networks:
  stokfinans_network:
    driver: bridge
    ipam:
      config:
        - subnet: 172.28.0.0/16

volumes:
  postgres_data:      # Host: /var/lib/docker/volumes/postgres_data/_data
  backend_logs:       # Uvicorn log dosyaları
  frontend_logs:      # Nginx access/error logs
```

**Network & Health Checks:**

- **Docker bridge network** → Container'lar kendi aralarında DNS adıyla iletişim kurar
  * `backend:8000` (frontend'den backend'e erişim)
  * `db:5432` (backend'den database'e erişim)

- **Service dependencies** → `depends_on: service_name: condition: service_healthy`
  * Frontend, backend hazır olana kadar başlamaz
  * Backend, database hazır olana kadar başlamaz

- **Health checks** → Docker her service'i kontrol eder
  * Backend: curl /health endpoint'i
  * Frontend: wget /index.html
  * Database: pg_isready komutu

**Dosya:** `docker-compose.yml` (180 satır)

---

### ✅ 7.5 Docker Compose - Development
**Neler Yapıldı:**

Sıcak yükleme (hot reload) için ayrı compose dosyası:

```yaml
backend:
  build:
    target: development         # --reload flag aktif
  volumes:
    - ./backend:/app            # Kod mount edilir (hot reload)

frontend:
  build:
    target: development         # npm run dev
  ports:
    - "5173:5173"              # Vite dev server portu
  volumes:
    - ./frontend:/app           # Kod mount edilir (hot reload)
    - /app/node_modules         # node_modules'ı overwrite etme
```

**Development Workflow:**

```bash
# Başla
docker-compose -f docker-compose.dev.yml up -d

# Develop
# - backend dosyalarında değişiklik → otomatik reload
# - frontend dosyalarında değişiklik → tarayıcıda otomatik güncelle

# Logs
docker-compose -f docker-compose.dev.yml logs -f backend
docker-compose -f docker-compose.dev.yml logs -f frontend

# Stop
docker-compose -f docker-compose.dev.yml down
```

**Dosya:** `docker-compose.dev.yml` (120 satır)

---

### ✅ 7.6 GitHub Actions CI/CD Pipeline
**Neler Yapıldı:**

Otomatik testing, building ve deployment:

**5 Jobs:**

1. **backend-test** (Python + PostgreSQL test DB)
   - pytest --cov (code coverage)
   - pip install requirements.txt
   - Codecov'a upload

2. **frontend-test** (Node.js)
   - npm run lint (ESLint)
   - npx tsc --noEmit (TypeScript check)
   - npm run build (production build)
   - Build artifacts upload

3. **build-and-push** (Docker registry'ye push)
   - Docker buildx setup
   - Backend image push: ghcr.io/user/stokfinans/backend:sha
   - Frontend image push: ghcr.io/user/stokfinans/frontend:sha
   - Layer caching enabled

4. **security-scan**
   - Python: safety dependency check
   - Node: npm audit
   - Trivy image scanning

5. **deploy-production** (Main branch sadece)
   - SSH'ye VPS'ye bağlan
   - git pull origin main
   - docker-compose down (eski konteynerler durdur)
   - docker-compose up -d (yeni konteynerler başlat)
   - Database migrations (alembic upgrade head)

**Trigger Events:**
- Push to main → production deploy
- Push to develop → test & build (deploy yok)
- Pull requests → test sadece

**Dosya:** `.github/workflows/ci-cd.yml` (380 satır)

---

### ✅ 7.7 Environment Configuration Files
**Neler Yapıldı:**

`.env.example` ve `.env.production` dosyaları:

**Anahtar Değişkenler:**

```bash
# Database (Docker'da container networking)
DATABASE_URL=postgresql://user:pass@db:5432/stokfinans_db

# JWT (üretim'de secure random key)
JWT_SECRET_KEY=<openssl rand -base64 32>

# CORS (production domain'ler)
ALLOWED_ORIGINS=https://stokfinans.com,https://app.stokfinans.com

# Frontend API URL (production VPS'de)
VITE_API_URL=https://api.stokfinans.com/api/v1

# Logging
LOG_LEVEL=INFO (production), DEBUG (development)

# SSL/TLS (Let's Encrypt)
SSL_CERT_PATH=/etc/letsencrypt/live/stokfinans.com/fullchain.pem
SSL_KEY_PATH=/etc/letsencrypt/live/stokfinans.com/privkey.pem
```

**Dosyalar:**
- `.env.example` (template)
- `.env.production` (production secrets - git'e eklenmez)

---

### ✅ 7.8 Deployment Guide
**Neler Yapıldı:**

Kapsamlı deployment dokümantasyonu:

**Bölümler:**

1. **Gereksinimler** (Docker 24.0+, Ubuntu 22.04 LTS)
2. **Yerel Geliştirme** (docker-compose.dev.yml)
3. **Docker Kurulumu** (Dockerfile özellikleri)
4. **VPS Kurulumu** (Ubuntu setup, SSL, systemd)
5. **GitHub Actions Setup** (secrets configuration)
6. **Monitoring & Logging** (docker logs, Sentry, PM2)
7. **Sorun Giderme** (common errors ve çözümleri)
8. **Production Checklist** (deployment hazırlaması)

**Dosya:** `DEPLOYMENT_GUIDE.md` (550 satır, Türkçe/İngilizce)

---

### 📊 SEVIYE 7 Özet

**Tamamlanan İşler:**

| Görev | Dosya | Satır | Durum |
|-------|-------|-------|-------|
| Backend Dockerfile | `backend/Dockerfile` | 85 | ✅ |
| Frontend Dockerfile | `frontend/Dockerfile` | 81 | ✅ |
| Nginx Configuration | `frontend/nginx.conf` | 150 | ✅ |
| Docker Compose (Prod) | `docker-compose.yml` | 180 | ✅ |
| Docker Compose (Dev) | `docker-compose.dev.yml` | 120 | ✅ |
| GitHub Actions CI/CD | `.github/workflows/ci-cd.yml` | 380 | ✅ |
| Environment Templates | `.env.example`, `.env.production` | 180 | ✅ |
| Deployment Guide | `DEPLOYMENT_GUIDE.md` | 550 | ✅ |

**Toplam: 1726 satır deployment ve configuration kodu**

---

### 🎯 Production Checklist

✅ Containerization (Docker + Compose)  
✅ Reverse proxy & static serving (Nginx)  
✅ Multi-stage builds (minimal images)  
✅ Health checks (automatic recovery)  
✅ Security (non-root user, headers)  
✅ CI/CD pipeline (GitHub Actions)  
✅ Database persistence (PostgreSQL volumes)  
✅ Logging aggregation (container logs)  
✅ Environment management (.env files)  
✅ SSL/TLS ready (Let's Encrypt)  
✅ Monitoring ready (Sentry integration)  
✅ Deployment documentation  

---

## 🎯 Sonraki Aşamada Yapılacaklar

**SEVIYE 6: Köprü Kurma** - Frontend-Backend Entegrasyonu (TAMAMLANDI)

✅ React 18 + Vite 5 + TypeScript  
✅ 1200+ satır React kodu  
✅ 30 API endpoint entegrasyonu  

**SEVIYE 7: Zirve & Deployment** - TAMAMLANDI

✅ Docker setup (3 services + multi-stage builds)  
✅ Nginx reverse proxy (gzip, caching, security)  
✅ docker-compose (production + development)  
✅ GitHub Actions CI/CD  
✅ Deployment guide ve configuration  

**SONRAKI: Production Deployment**

- [ ] VPS'ye dağıt (DigitalOcean, Linode, AWS)
- [ ] Domain DNS yapılandır
- [ ] SSL sertifika (Let's Encrypt)
- [ ] Database backups
- [ ] Monitoring (Sentry, DataDog)
- [ ] Load testing

