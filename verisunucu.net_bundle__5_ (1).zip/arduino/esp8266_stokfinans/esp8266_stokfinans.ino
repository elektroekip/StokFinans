/*
 * ╔══════════════════════════════════════════════════════════════╗
 * ║          StokFinans ESP8266 Cihaz Yazılımı                   ║
 * ║          Versiyon: 1.0.0                                      ║
 * ╠══════════════════════════════════════════════════════════════╣
 * ║ Gerekli Kütüphaneler (Arduino Library Manager):              ║
 * ║   • WiFiManager by tzapu          (v2.0.17+)                ║
 * ║   • ArduinoJson by Benoit Blanchon (v6.x)                   ║
 * ║   • ESP8266HTTPClient              (Core'da dahili)          ║
 * ║   • ESP8266httpUpdate              (Core'da dahili)          ║
 * ╠══════════════════════════════════════════════════════════════╣
 * ║ Board Ayarı:                                                  ║
 * ║   "LOLIN(WEMOS) D1 R2 & mini" veya "Generic ESP8266 Module" ║
 * ║   Flash: 4MB (FS:2MB OTA:~1019KB)                            ║
 * ╠══════════════════════════════════════════════════════════════╣
 * ║ Fonksiyonlar (void'ler):                                     ║
 * ║   setupSerial()       → Seri port başlat                     ║
 * ║   setupEEPROM()       → EEPROM başlat, kimlik bilgilerini yükle ║
 * ║   setupWifi()         → WiFiManager ile WiFi bağlantısı kur  ║
 * ║   setupDevice()       → Cihaz ID oluştur, sunucuya kayıt ol  ║
 * ║   checkWifiStatus()   → WiFi kopma/yeniden bağlanma kontrolü ║
 * ║   handleHeartbeat()   → 30s'de bir sunucuya ping             ║
 * ║   handleOTA()         → OTA güncelleme uygula                ║
 * ║   queryProduct()      → Barkodla ürün sorgula                ║
 * ║   fetchCriticalStock()→ Kritik stok listesini güncelle       ║
 * ║   fetchSummary()      → Ürün/satış/müşteri özeti             ║
 * ║   fetchSubscription() → Abonelik ve kullanım limitleri       ║
 * ║   fetchStaffWarranty()→ Personel ve garanti istatistikleri   ║
 * ║   userCode()          → KULLANICININ KENDİ KODU BURAYA       ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <ESP8266httpUpdate.h>
#include <WiFiClientSecureBearSSL.h>
#include <WiFiManager.h>
#include <ArduinoJson.h>
#include <EEPROM.h>

// ════════════════════════════════════════════════════════════════
// YAPILANDIRMA — değiştirmeniz gereken tek bölüm
// ════════════════════════════════════════════════════════════════

#define SERVER_URL   "https://stokfinans.com"  // Sunucu adresi (sondaki / olmadan)
#define DEVICE_TYPE  "ESP8266"                 // Cihaz türü — değiştirmeyin

// ─────────────────────────────────────────────────────────
// DONANIM VARYANTI — derlemeden önce değiştirin:
//   "standart"  Ekstra donanım yok (varsayılan)
//   "ekran"     OLED / LCD ekran bağlı
//   "barkod"    Barkod / QR okuyucu bağlı
//   "ozel"      Özel yapılandırma
// Bu define ile derlenen cihaz yalnızca aynı varyant için
// yayınlanan firmware güncellemelerini alır.
// ─────────────────────────────────────────────────────────
#ifndef DEVICE_VARIANT
  #define DEVICE_VARIANT "standart"
#endif

#define FIRMWARE_VER "1.0.0"                   // Bu firmware'in versiyonu

#define HEARTBEAT_MS        30000   // Heartbeat aralığı (30 saniye)
#define SUMMARY_MS         120000   // Özet veri güncelleme aralığı (2 dakika)
#define SUBSCRIPTION_MS    300000   // Abonelik veri güncelleme aralığı (5 dakika)
#define STAFF_WARRANTY_MS  300000   // Personel/garanti güncelleme aralığı (5 dakika)

#define AP_NAME "StokFinans-Setup"   // WiFiManager AP adı (ilk kurulumda bu ağa bağlanın)
#define AP_PASS "stokfinans123"      // WiFiManager AP şifresi (en az 8 karakter)

// ════════════════════════════════════════════════════════════════
// EEPROM DÜZENI
//   Offset 0   : magic byte (0xAB = kayıtlı veri var)
//   Offset 1   : device_id uzunluğu (1 byte)
//   Offset 2   : device_id içeriği (64 byte)
//   Offset 66  : api_key uzunluğu (1 byte)
//   Offset 67  : api_key içeriği (65 byte)
// ════════════════════════════════════════════════════════════════

#define EEPROM_SIZE       200    // Toplam ayrılan EEPROM alanı (byte)
#define EEPROM_MAGIC      0xAB   // Geçerli veri olduğunu işaret eden sihirli byte
#define EEPROM_OFF_MAGIC  0      // Magic byte'ın adresi
#define EEPROM_OFF_IDLEN  1      // device_id uzunluğunun adresi
#define EEPROM_OFF_ID     2      // device_id içeriğinin başlangıç adresi
#define EEPROM_OFF_KEYLEN 66     // api_key uzunluğunun adresi
#define EEPROM_OFF_KEY    67     // api_key içeriğinin başlangıç adresi

// ════════════════════════════════════════════════════════════════
// CİHAZ KİMLİK DEĞİŞKENLERİ
// ════════════════════════════════════════════════════════════════

String g_deviceId      = "";               // Cihazın kalıcı benzersiz kimliği (MAC tabanlı, ör: DEV-AABBCCDDEEFF)
String g_apiKey        = "";               // Sunucudan alınan API anahtarı — tüm isteklerde Header'a eklenir
String g_macAddress    = "";               // Cihazın MAC adresi (ör: AA:BB:CC:DD:EE:FF)
const char* g_deviceVariant = DEVICE_VARIANT; // Donanım varyantı — derleme zamanında belirlenir (DEVICE_VARIANT define)
bool   g_paired        = false;            // true → cihaz bir bayi hesabına bağlı; false → eşleşme bekleniyor

// ════════════════════════════════════════════════════════════════
// AĞ / SİSTEM DEĞİŞKENLERİ
// ════════════════════════════════════════════════════════════════

int    g_wifiRssi      = 0;      // WiFi sinyal gücü (dBm) — örn: -60 iyi, -90 zayıf
String g_wifiSsid      = "";     // Bağlı olduğu WiFi ağının adı (SSID)
String g_ipAddress     = "";     // Cihazın yerel ağdaki IP adresi (ör: 192.168.1.105)
int    g_freeHeap      = 0;      // Kullanılabilir RAM miktarı (byte) — 20000 altı kritik
long   g_uptimeSec     = 0;      // Cihazın açık kaldığı süre (saniye)
bool   g_wifiWasDown   = false;  // WiFi az önce kopmuş muydu? (yeniden bağlanma tespiti için)

// ════════════════════════════════════════════════════════════════
// OTA GÜNCELLEMESİ DEĞİŞKENLERİ
// ════════════════════════════════════════════════════════════════

bool   g_otaAvailable  = false;  // true → sunucu yeni bir firmware göndermiş, güncelleme bekliyor
String g_otaVersion    = "";     // Bekleyen OTA güncellemenin versiyon numarası (ör: "1.2.0")
String g_otaUrl        = "";     // OTA firmware dosyasının indirme URL yolu

// ════════════════════════════════════════════════════════════════
// SON BARKOD SORGUSU — g_product_* değişkenleri
//   queryProduct("1234567890128") çağrıldıktan sonra bu değişkenler güncellenir.
//   Örnek kullanım:
//     queryProduct("8690804120012");
//     Serial.println(g_productName + " — " + g_productPrice + " TRY");
//     if (g_productIsCritical) { /* stok uyarısı ver */ }
// ════════════════════════════════════════════════════════════════

bool   g_productFound       = false;  // true → ürün bulundu, false → barkod kayıtlı değil
String g_productName        = "";     // Ürün adı (ör: "Coca Cola 330ml")
String g_productBarcode     = "";     // Sorgulanan barkod numarası
float  g_productPrice       = 0.0f;  // Ürün satış fiyatı (TRY veya seçili para birimi)
float  g_productCost        = 0.0f;  // Ürün maliyet fiyatı (alış fiyatı)
String g_productCurrency    = "TRY"; // Para birimi (TRY / USD / EUR)
int    g_productStock       = 0;     // Mevcut stok adedi
int    g_productMinStock    = 5;     // Minimum stok uyarı seviyesi (bu değere eşit veya altı → kritik)
bool   g_productIsCritical  = false; // true → stok kritik seviyede veya tükenmiş
String g_productCategory    = "";    // Ürün ana kategorisi (ör: "İçecek")
String g_productSubcategory = "";    // Ürün alt kategorisi (ör: "Gazlı İçecek")

// ════════════════════════════════════════════════════════════════
// KRİTİK STOK LİSTESİ — g_criticalStock[] dizisi
//   fetchCriticalStock() çağrıldıktan sonra bu dizi güncellenir.
//   Örnek kullanım:
//     fetchCriticalStock();
//     for (int i = 0; i < g_criticalCount; i++) {
//       Serial.println(g_criticalStock[i].name + ": " + g_criticalStock[i].quantity + " adet");
//     }
// ════════════════════════════════════════════════════════════════

#define MAX_CRITICAL 20   // Dizide tutulacak maksimum kritik stok kaydı sayısı

struct CriticalStockItem {
  String name;        // Ürün adı
  String barcode;     // Barkod
  int    quantity;    // Mevcut stok adedi
  float  price;       // Satış fiyatı
  int    minStock;    // Minimum stok uyarı seviyesi
  String currency;    // Para birimi
};

CriticalStockItem g_criticalStock[MAX_CRITICAL];  // Kritik stok ürünleri dizisi
int g_criticalCount = 0;                          // Dizideki kritik ürün sayısı

// ════════════════════════════════════════════════════════════════
// ÖZET VERİLERİ — g_sum_* değişkenleri
//   fetchSummary() çağrıldıktan sonra güncellenir.
//   Her 2 dakikada bir otomatik güncellenir.
// ════════════════════════════════════════════════════════════════

int    g_sumTotalProducts      = 0;      // Kayıtlı toplam ürün çeşidi sayısı
int    g_sumTotalStockQty      = 0;      // Tüm ürünlerin toplam stok adedi
float  g_sumTotalStockValue    = 0.0f;   // Tüm ürünlerin toplam stok değeri (TRY)
int    g_sumCriticalStockCount = 0;      // Kritik stok seviyesindeki ürün sayısı
int    g_sumOutOfStockCount    = 0;      // Stoku tamamen tükenmiş ürün sayısı
int    g_sumTodaySalesCount    = 0;      // Bugün yapılan satış işlemi sayısı
float  g_sumTodaySalesAmount   = 0.0f;   // Bugünkü toplam satış tutarı (TRY)
int    g_sumTodayCustomerCount = 0;      // Bugün işlem yapılan benzersiz müşteri sayısı
int    g_sumTotalTxnCount      = 0;      // Tüm zamanlar toplam işlem sayısı
float  g_sumTotalRevenue       = 0.0f;   // Tüm zamanlar toplam gelir (TRY)

// ════════════════════════════════════════════════════════════════
// ABONELİK VERİLERİ — g_sub_* değişkenleri
//   fetchSubscription() çağrıldıktan sonra güncellenir.
//   Her 5 dakikada bir otomatik güncellenir.
// ════════════════════════════════════════════════════════════════

String g_subPackageName           = "";   // Aktif abonelik paketinin adı (ör: "Pro")
String g_subPackageSlug           = "";   // Paket kısa kodu (ör: "pro", "starter")
String g_subExpiresAt             = "";   // Abonelik bitiş tarihi (YYYY-MM-DD formatında)
int    g_subDaysLeft              = 0;    // Aboneliğin biteceğine kaç gün kaldı
bool   g_subIsActive              = false; // true → abonelik aktif; false → süresi dolmuş
int    g_subMaxProducts           = 0;    // Bu pakette kayıt edilebilecek maksimum ürün sayısı
int    g_subMaxTransactions       = 0;    // Bu pakette yapılabilecek maksimum işlem sayısı
int    g_subUsedProducts          = 0;    // Şu an kayıtlı ürün sayısı (kullanılan)
int    g_subUsedTransactions      = 0;    // Şu an kayıtlı işlem sayısı (kullanılan)
int    g_subRemainingProducts     = 0;    // Daha kaç ürün daha eklenebilir
int    g_subRemainingTransactions = 0;    // Daha kaç işlem daha eklenebilir

// ════════════════════════════════════════════════════════════════
// PERSONEL VERİLERİ — g_staff_* değişkenleri
//   fetchStaffWarranty() çağrıldıktan sonra güncellenir.
// ════════════════════════════════════════════════════════════════

int g_staffConnectedUsers = 0;   // Patrona bağlı toplam hesap sayısı (patron + tüm personel)
int g_staffTotal          = 0;   // Toplam personel sayısı (patron hariç)
int g_staffActive         = 0;   // Aktif (hesabı açık) personel sayısı

// ════════════════════════════════════════════════════════════════
// GARANTİ VERİLERİ — g_warranty_* değişkenleri
//   fetchStaffWarranty() çağrıldıktan sonra güncellenir.
// ════════════════════════════════════════════════════════════════

int g_warrantyTotal          = 0;  // Toplam garanti kaydı sayısı
int g_warrantyActive         = 0;  // Süresi devam eden aktif garanti sayısı
int g_warrantyExpired        = 0;  // Süresi dolmuş garanti sayısı
int g_warrantyExpiringToday  = 0;  // Bugün sona erecek garanti sayısı
int g_warrantyExpiringWeek   = 0;  // 7 gün içinde sona erecek garanti sayısı
int g_warrantyTodayAdded     = 0;  // Bugün eklenen yeni garanti kaydı sayısı

// ════════════════════════════════════════════════════════════════
// ZAMANLAYICILAR — döngü içi aralık takibi
// ════════════════════════════════════════════════════════════════

unsigned long g_lastHeartbeat      = 0;  // Son heartbeat zamanı (millis)
unsigned long g_lastSummary        = 0;  // Son özet veri çekme zamanı
unsigned long g_lastSubscription   = 0;  // Son abonelik veri çekme zamanı
unsigned long g_lastStaffWarranty  = 0;  // Son personel/garanti veri çekme zamanı

// ════════════════════════════════════════════════════════════════
// HTTP İSTEMCİSİ
// ════════════════════════════════════════════════════════════════

BearSSL::WiFiClientSecure g_wifiClient;  // HTTPS bağlantıları için güvenli istemci

// ════════════════════════════════════════════════════════════════
// EEPROM YARDIMCI FONKSİYONLARI — dahili, doğrudan çağırmayın
// ════════════════════════════════════════════════════════════════

void _eepromWriteStr(int offset, const String& s, int maxLen) {
  int len = min((int)s.length(), maxLen - 1);
  EEPROM.write(offset, (uint8_t)len);                          // Önce uzunluğu yaz
  for (int i = 0; i < len; i++) EEPROM.write(offset + 1 + i, s[i]);  // Sonra karakterleri
  EEPROM.commit();
}

String _eepromReadStr(int offset, int maxLen) {
  int len = EEPROM.read(offset);                               // Uzunluğu oku
  if (len <= 0 || len >= maxLen) return "";                    // Geçersiz uzunluk
  String s = "";
  for (int i = 0; i < len; i++) s += (char)EEPROM.read(offset + 1 + i);
  return s;
}

void _saveCredentials() {
  EEPROM.write(EEPROM_OFF_MAGIC, EEPROM_MAGIC);                // Geçerli veri işareti
  _eepromWriteStr(EEPROM_OFF_IDLEN, g_deviceId, 64);           // device_id kaydet
  _eepromWriteStr(EEPROM_OFF_KEYLEN, g_apiKey, 65);            // api_key kaydet
  EEPROM.commit();
  Serial.println("[EEPROM] Kimlik bilgileri kaydedildi");
}

bool _loadCredentials() {
  if (EEPROM.read(EEPROM_OFF_MAGIC) != EEPROM_MAGIC) return false;  // Veri yok
  g_deviceId = _eepromReadStr(EEPROM_OFF_IDLEN, 64);
  g_apiKey   = _eepromReadStr(EEPROM_OFF_KEYLEN, 65);
  return g_deviceId.length() > 0 && g_apiKey.length() > 0;
}

// ════════════════════════════════════════════════════════════════
// HTTP YARDIMCI FONKSİYONLARI — dahili, doğrudan çağırmayın
// ════════════════════════════════════════════════════════════════

bool _httpPost(const String& path, const String& body, JsonDocument& out) {
  g_wifiClient.setInsecure();                                  // Geliştirme modu: sertifika doğrulama kapalı
  HTTPClient http;
  http.begin(g_wifiClient, String(SERVER_URL) + path);
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(body);
  if (code <= 0) { http.end(); return false; }
  DeserializationError err = deserializeJson(out, http.getString());
  http.end();
  return (code >= 200 && code < 300) && !err;
}

bool _httpGet(const String& path, JsonDocument& out) {
  g_wifiClient.setInsecure();
  HTTPClient http;
  http.begin(g_wifiClient, String(SERVER_URL) + path);
  http.addHeader("X-Api-Key", g_apiKey);                       // API anahtarı zorunlu
  int code = http.GET();
  if (code <= 0) { http.end(); return false; }
  DeserializationError err = deserializeJson(out, http.getString());
  http.end();
  return (code >= 200 && code < 300) && !err;
}

// ════════════════════════════════════════════════════════════════
// 1. SERİ PORT BAŞLATMA
// ════════════════════════════════════════════════════════════════

void setupSerial() {
  Serial.begin(115200);                                        // Seri iletişim hızı (baud rate)
  delay(500);                                                  // Seri portun stabilize olması için bekle
  Serial.println();
  Serial.println("╔══════════════════════════════════════╗");
  Serial.println("║  StokFinans ESP8266 v" FIRMWARE_VER "           ║");
  Serial.println("╚══════════════════════════════════════╝");
}

// ════════════════════════════════════════════════════════════════
// 2. EEPROM BAŞLATMA VE KİMLİK BİLGİLERİ YÜKLEME
// ════════════════════════════════════════════════════════════════

bool setupEEPROM() {
  EEPROM.begin(EEPROM_SIZE);                                   // EEPROM alanını rezerve et
  bool hasData = _loadCredentials();                           // Önceden kaydedilmiş kimlik bilgilerini yükle
  if (hasData) {
    Serial.println("[EEPROM] Kayıtlı kimlik bilgileri yüklendi");
    Serial.println("[EEPROM] Device ID: " + g_deviceId);
  } else {
    Serial.println("[EEPROM] Kayıtlı veri yok, sunucuya kayıt gerekiyor");
  }
  return hasData;
}

// ════════════════════════════════════════════════════════════════
// 3. CİHAZ ID OLUŞTURMA (dahili)
// ════════════════════════════════════════════════════════════════

void _generateDeviceId() {
  uint8_t mac[6];
  WiFi.macAddress(mac);                                        // MAC adresini oku
  g_macAddress = WiFi.macAddress();                            // String formatında sakla
  char buf[24];
  snprintf(buf, sizeof(buf), "DEV-%02X%02X%02X%02X%02X%02X",
           mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);   // DEV-AABBCCDDEEFF formatı
  g_deviceId = String(buf);
  Serial.println("[ID] Cihaz ID: " + g_deviceId);
  Serial.println("[ID] MAC: " + g_macAddress);
}

// ════════════════════════════════════════════════════════════════
// 4. WiFi BAĞLANTISI (WiFiManager ile)
//    İlk açılışta veya kayıtlı ağa bağlanamazsa:
//    "StokFinans-Setup" adlı AP açılır.
//    Telefonunuzdan bu ağa bağlanıp 192.168.4.1'e gidin.
// ════════════════════════════════════════════════════════════════

void setupWifi() {
  WiFi.mode(WIFI_STA);                                         // Station modu (istemci olarak çalış)
  _generateDeviceId();                                         // MAC hazır olduğunda ID üret

  WiFiManager wm;
  wm.setConfigPortalTimeout(180);                              // 3 dakika içinde bağlantı olmazsa devam et
  wm.setConnectTimeout(20);                                    // Ağa bağlanma zaman aşımı (saniye)
  wm.setDebugOutput(false);                                    // WiFiManager debug mesajlarını kapat

  Serial.println("[WiFi] Bağlantı kuruluyor...");
  Serial.println("[WiFi] Bağlanamazsa '" AP_NAME "' ağına bağlanın");

  if (!wm.autoConnect(AP_NAME, AP_PASS)) {
    Serial.println("[WiFi] HATA: Bağlantı kurulamadı. Yeniden başlatılıyor...");
    delay(3000);
    ESP.restart();                                             // 3 saniye sonra cihazı yeniden başlat
  }

  Serial.println("[WiFi] Bağlandı!");
  Serial.println("[WiFi] SSID: " + WiFi.SSID());
  Serial.println("[WiFi] IP: " + WiFi.localIP().toString());
  Serial.println("[WiFi] RSSI: " + String(WiFi.RSSI()) + " dBm");
}

// ════════════════════════════════════════════════════════════════
// 5. SUNUCUYA KAYIT — ilk açılışta api_key alınır
// ════════════════════════════════════════════════════════════════

bool _registerDevice() {
  Serial.println("[REG] Sunucuya kayıt olunuyor...");
  String body = "{\"device_id\":\"" + g_deviceId + "\","
                "\"device_type\":\"" DEVICE_TYPE "\","
                "\"variant\":\"" DEVICE_VARIANT "\","
                "\"firmware_version\":\"" FIRMWARE_VER "\","
                "\"mac_address\":\"" + g_macAddress + "\"}";

  DynamicJsonDocument doc(256);
  if (!_httpPost("/api/v1/devices/register", body, doc)) {
    Serial.println("[REG] HATA: Sunucu yanıt vermedi");
    return false;
  }

  g_apiKey = doc["api_key"].as<String>();
  if (g_apiKey.length() == 0) {
    Serial.println("[REG] HATA: API anahtarı alınamadı");
    return false;
  }

  _saveCredentials();                                          // EEPROM'a kaydet
  Serial.println("[REG] Kayıt başarılı!");
  Serial.println("[REG] API Key: " + g_apiKey.substring(0, 8) + "...");
  return true;
}

void setupDevice(bool hasStoredCredentials) {
  if (!hasStoredCredentials) {
    // Kayıtlı kimlik yoksa sunucuya kayıt ol
    if (!_registerDevice()) {
      Serial.println("[REG] İlk deneme başarısız, 10 saniye sonra tekrar denenecek...");
      delay(10000);
      if (!_registerDevice()) {
        Serial.println("[REG] KRİTİK: Kayıt başarısız! Manuel müdahale gerekebilir.");
      }
    }
  }
  // İlk heartbeat: sunucuya varlık bildir ve bekleyen OTA güncellemeyi kontrol et
  handleHeartbeat();
}

// ════════════════════════════════════════════════════════════════
// 6. HEARTBEAT — her 30 saniyede bir sunucuya ping
//    Heartbeat yanıtında OTA bilgisi de gelir.
//    Bu fonksiyon hem handleHeartbeat() hem setup() tarafından çağrılır.
// ════════════════════════════════════════════════════════════════

void sendHeartbeat() {
  // Anlık sistem verilerini güncelle
  g_wifiRssi  = WiFi.RSSI();                                   // Sinyal gücü (dBm)
  g_wifiSsid  = WiFi.SSID();                                   // Bağlı ağ adı
  g_ipAddress = WiFi.localIP().toString();                     // Yerel IP adresi
  g_freeHeap  = ESP.getFreeHeap();                             // Boş RAM (byte)
  g_uptimeSec = millis() / 1000;                               // Çalışma süresi (saniye)

  // Sunucuya gönderilecek JSON paketi
  String body = "{";
  body += "\"firmware_version\":\"" FIRMWARE_VER "\",";
  body += "\"variant\":\"" DEVICE_VARIANT "\",";
  body += "\"ip_address\":\"" + g_ipAddress + "\",";
  body += "\"wifi_ssid\":\"" + g_wifiSsid + "\",";
  body += "\"wifi_rssi\":" + String(g_wifiRssi) + ",";
  body += "\"free_heap\":" + String(g_freeHeap) + ",";
  body += "\"uptime_seconds\":" + String(g_uptimeSec);
  body += "}";

  g_wifiClient.setInsecure();
  HTTPClient http;
  http.begin(g_wifiClient, String(SERVER_URL) + "/api/v1/devices/heartbeat");
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Api-Key", g_apiKey);
  int code = http.POST(body);

  if (code == 200) {
    DynamicJsonDocument doc(256);
    deserializeJson(doc, http.getString());
    g_otaAvailable = doc["ota_available"] | false;             // Bekleyen OTA var mı?
    g_otaVersion   = doc["ota_version"].as<String>();          // OTA versiyon numarası
    g_otaUrl       = doc["ota_url"].as<String>();              // OTA indirme URL'i
    g_paired       = true;                                     // Bayi ile eşleşmiş
    Serial.printf("[HB] OK | Sinyal:%d dBm | RAM:%d byte | OTA:%s\n",
                  g_wifiRssi, g_freeHeap, g_otaAvailable ? g_otaVersion.c_str() : "yok");
  } else if (code == 403) {
    g_paired = false;                                          // Henüz eşleşme yapılmamış
    Serial.println("[HB] Bayi eşleşmesi bekleniyor...");
    Serial.println("[HB] Bayi panelinden Cihazlar → Cihaz Ekle → " + g_deviceId);
  } else {
    Serial.printf("[HB] Hata kodu: %d\n", code);
  }
  http.end();
}

void handleHeartbeat() {
  // Sadece HEARTBEAT_MS süresi dolmuşsa gönder (döngü içinden çağrılır)
  if (millis() - g_lastHeartbeat < HEARTBEAT_MS && g_lastHeartbeat != 0) return;
  sendHeartbeat();
  g_lastHeartbeat = millis();

  // Heartbeat sonrası OTA güncelleme geldi mi kontrol et
  if (g_otaAvailable) {
    Serial.println("[HB] OTA güncelleme hazır → " + g_otaVersion);
    delay(500);
    handleOTA();
  }
}

// ════════════════════════════════════════════════════════════════
// 7. OTA GÜNCELLEMESİ
//    handleHeartbeat() veya checkWifiStatus() tarafından tetiklenir.
//    Başarılı olursa cihaz otomatik yeniden başlar.
// ════════════════════════════════════════════════════════════════

void handleOTA() {
  if (!g_otaAvailable || g_otaUrl.length() == 0) return;
  Serial.println("[OTA] Güncelleme başlıyor: " + g_otaVersion);
  Serial.println("[OTA] URL: " + String(SERVER_URL) + g_otaUrl);

  g_wifiClient.setInsecure();
  // ESPhttpUpdate sunucudan firmware dosyasını indirip Flash'a yazar, sonra yeniden başlatır
  t_httpUpdate_return ret = ESPhttpUpdate.update(g_wifiClient, String(SERVER_URL) + g_otaUrl);

  switch (ret) {
    case HTTP_UPDATE_FAILED:
      Serial.println("[OTA] HATA: " + ESPhttpUpdate.getLastErrorString());
      g_otaAvailable = false;                                  // Başarısız → bayrağı sıfırla
      break;
    case HTTP_UPDATE_NO_UPDATES:
      Serial.println("[OTA] Güncelleme dosyası bulunamadı");
      g_otaAvailable = false;
      break;
    case HTTP_UPDATE_OK:
      Serial.println("[OTA] Başarılı! Cihaz yeniden başlatılıyor...");
      // Bu satıra normalde ulaşılmaz — cihaz zaten yeniden başlar
      break;
  }
}

// ════════════════════════════════════════════════════════════════
// 8. WiFi DURUM KONTROLÜ — her loop() iterasyonunda çağrılır
//    Kopma tespiti ve yeniden bağlandıktan sonra anlık güncelleme yapar.
// ════════════════════════════════════════════════════════════════

bool checkWifiStatus() {
  if (WiFi.status() != WL_CONNECTED) {
    if (!g_wifiWasDown) {
      g_wifiWasDown = true;                                    // İlk kopuşta bayrağı set et
      Serial.println("[WiFi] Bağlantı kesildi! Yeniden bağlanılıyor...");
    }
    WiFi.reconnect();                                          // Yeniden bağlanmayı dene
    delay(5000);                                               // 5 saniye bekle
    return false;                                              // Bağlantı yok → loop devam etmesin
  }

  if (g_wifiWasDown) {
    // WiFi az önce yeniden bağlandı → heartbeat + OTA kontrolü yap
    g_wifiWasDown = false;
    Serial.println("[WiFi] Bağlantı yeniden kuruldu!");
    sendHeartbeat();
    g_lastHeartbeat = millis();
    if (g_otaAvailable) {
      Serial.println("[WiFi] Yeniden bağlantı sonrası OTA uygulanıyor...");
      delay(500);
      handleOTA();
    }
  }

  return true;                                                 // WiFi bağlı → devam edebilirsin
}

// ════════════════════════════════════════════════════════════════
// 9. BARKODLA ÜRÜN SORGULA
//    Sunucudan ürün bilgilerini çeker ve g_product_* değişkenlerini günceller.
//
//    Kullanım:
//      if (queryProduct("8690804120012")) {
//        Serial.println("Ürün: " + g_productName);
//        Serial.println("Fiyat: " + String(g_productPrice) + " " + g_productCurrency);
//        Serial.println("Stok: " + String(g_productStock) + " adet");
//        if (g_productIsCritical) Serial.println("⚠ KRİTİK STOK!");
//      }
// ════════════════════════════════════════════════════════════════

bool queryProduct(const String& barcode) {
  if (!g_paired) {
    Serial.println("[ÜRÜN] Eşleşme yapılmamış, sorgu yapılamıyor");
    return false;
  }

  DynamicJsonDocument doc(512);
  bool ok = _httpGet("/api/v1/devices/data/product/" + barcode, doc);

  if (!ok) {
    g_productFound = false;
    Serial.println("[ÜRÜN] '" + barcode + "' barkodlu ürün bulunamadı");
    return false;
  }

  // Tüm ürün alanlarını ayrı değişkenlere aktar
  g_productFound       = true;
  g_productName        = doc["name"].as<String>();              // Ürün adı
  g_productBarcode     = doc["barcode"].as<String>();           // Barkod numarası
  g_productPrice       = doc["price"] | 0.0f;                  // Satış fiyatı
  g_productCost        = doc["cost"] | 0.0f;                   // Maliyet fiyatı
  g_productCurrency    = doc["currency"] | "TRY";              // Para birimi
  g_productStock       = doc["quantity"] | 0;                  // Stok adedi
  g_productMinStock    = doc["min_stock_alert"] | 5;           // Minimum stok uyarı seviyesi
  g_productIsCritical  = doc["is_critical"] | false;           // Kritik stok mu?
  g_productCategory    = doc["category"].as<String>();          // Ana kategori
  g_productSubcategory = doc["subcategory"].as<String>();       // Alt kategori

  Serial.printf("[ÜRÜN] %s | %.2f %s | Stok: %d%s\n",
    g_productName.c_str(), g_productPrice, g_productCurrency.c_str(),
    g_productStock, g_productIsCritical ? " [KRİTİK]" : "");
  return true;
}

// ════════════════════════════════════════════════════════════════
// 10. KRİTİK STOK LİSTESİNİ GÜNCELLE
//     g_criticalStock[] dizisini ve g_criticalCount değerini günceller.
//
//     Kullanım:
//       fetchCriticalStock();
//       Serial.println("Kritik ürün sayısı: " + String(g_criticalCount));
//       for (int i = 0; i < g_criticalCount; i++) {
//         Serial.println(g_criticalStock[i].name + ": " + g_criticalStock[i].quantity + " adet");
//       }
// ════════════════════════════════════════════════════════════════

bool fetchCriticalStock() {
  if (!g_paired) return false;

  DynamicJsonDocument doc(2048);
  if (!_httpGet("/api/v1/devices/data/critical-stock", doc)) {
    Serial.println("[STOK] Kritik stok listesi alınamadı");
    return false;
  }

  g_criticalCount = 0;                                         // Diziyi sıfırla
  JsonArray arr   = doc["items"].as<JsonArray>();

  for (JsonObject item : arr) {
    if (g_criticalCount >= MAX_CRITICAL) break;                // Dizi sınırı aşılmasın
    g_criticalStock[g_criticalCount].name     = item["name"].as<String>();
    g_criticalStock[g_criticalCount].barcode  = item["barcode"].as<String>();
    g_criticalStock[g_criticalCount].quantity = item["quantity"] | 0;
    g_criticalStock[g_criticalCount].price    = item["price"] | 0.0f;
    g_criticalStock[g_criticalCount].minStock = item["min_stock_alert"] | 5;
    g_criticalStock[g_criticalCount].currency = item["currency"] | "TRY";
    g_criticalCount++;
  }

  Serial.printf("[STOK] Kritik ürün sayısı: %d\n", g_criticalCount);
  return true;
}

// ════════════════════════════════════════════════════════════════
// 11. GENEL ÖZET VERİLERİ — g_sum_* değişkenlerini günceller
//     Ürün sayıları, stok değeri, bugünkü satışlar ve müşteri bilgileri.
//     Her 2 dakikada bir otomatik güncellenir (SUMMARY_MS).
//
//     Manuel kullanım:
//       fetchSummary();
//       Serial.println("Toplam ürün: " + String(g_sumTotalProducts));
//       Serial.println("Bugün satış: " + String(g_sumTodaySalesCount) + " işlem");
//       Serial.println("Bugün ciro: " + String(g_sumTodaySalesAmount) + " TRY");
// ════════════════════════════════════════════════════════════════

bool fetchSummary() {
  if (!g_paired) return false;

  DynamicJsonDocument doc(512);
  if (!_httpGet("/api/v1/devices/data/summary", doc)) {
    Serial.println("[ÖZET] Özet veriler alınamadı");
    return false;
  }

  // Ürün istatistikleri
  g_sumTotalProducts      = doc["total_products"] | 0;        // Toplam ürün çeşidi
  g_sumTotalStockQty      = doc["total_stock_qty"] | 0;       // Toplam stok adedi
  g_sumTotalStockValue    = doc["total_stock_value"] | 0.0f;  // Toplam stok değeri (TRY)
  g_sumCriticalStockCount = doc["critical_stock_count"] | 0;  // Kritik stok sayısı
  g_sumOutOfStockCount    = doc["out_of_stock_count"] | 0;    // Tükenmiş ürün sayısı

  // Bugünkü işlemler
  g_sumTodaySalesCount    = doc["today_sales_count"] | 0;     // Bugün satış sayısı
  g_sumTodaySalesAmount   = doc["today_sales_amount"] | 0.0f; // Bugün satış tutarı (TRY)
  g_sumTodayCustomerCount = doc["today_customer_count"] | 0;  // Bugün müşteri sayısı

  // Genel istatistikler
  g_sumTotalTxnCount      = doc["total_transaction_count"] | 0;  // Toplam işlem
  g_sumTotalRevenue       = doc["total_revenue"] | 0.0f;         // Toplam gelir (TRY)

  Serial.printf("[ÖZET] Ürün:%d | Kritik:%d | Bugün:%d satış %.2fTRY\n",
    g_sumTotalProducts, g_sumCriticalStockCount,
    g_sumTodaySalesCount, g_sumTodaySalesAmount);
  return true;
}

// ════════════════════════════════════════════════════════════════
// 12. ABONELİK BİLGİLERİ — g_sub_* değişkenlerini günceller
//     Paket adı, bitiş tarihi, kalan gün ve kullanım limitleri.
//     Her 5 dakikada bir otomatik güncellenir (SUBSCRIPTION_MS).
//
//     Manuel kullanım:
//       fetchSubscription();
//       Serial.println("Paket: " + g_subPackageName);
//       Serial.println("Kalan gün: " + String(g_subDaysLeft));
//       Serial.println("Ürün limiti: " + String(g_subUsedProducts) + "/" + String(g_subMaxProducts));
// ════════════════════════════════════════════════════════════════

bool fetchSubscription() {
  if (!g_paired) return false;

  DynamicJsonDocument doc(512);
  if (!_httpGet("/api/v1/devices/data/subscription", doc)) {
    Serial.println("[ABONELİK] Abonelik bilgileri alınamadı");
    return false;
  }

  // Paket bilgileri
  g_subPackageName = doc["package_name"].as<String>();          // Aktif paket adı
  g_subPackageSlug = doc["package_slug"].as<String>();          // Paket kısa kodu

  // Abonelik süresi
  g_subExpiresAt   = doc["expires_at"].as<String>();            // Bitiş tarihi (YYYY-MM-DD)
  g_subDaysLeft    = doc["days_left"] | 0;                      // Kalan gün sayısı
  g_subIsActive    = doc["is_active"] | false;                  // Abonelik aktif mi?

  // Limitler
  g_subMaxProducts           = doc["max_products"] | 0;         // Maksimum ürün hakkı
  g_subMaxTransactions       = doc["max_transactions"] | 0;     // Maksimum işlem hakkı

  // Kullanım
  g_subUsedProducts          = doc["used_products"] | 0;        // Kullanılan ürün sayısı
  g_subUsedTransactions      = doc["used_transactions"] | 0;    // Kullanılan işlem sayısı
  g_subRemainingProducts     = doc["remaining_products"] | 0;   // Kalan ürün hakkı
  g_subRemainingTransactions = doc["remaining_transactions"] | 0; // Kalan işlem hakkı

  Serial.printf("[ABONELİK] %s | %d gün kaldı | Ürün:%d/%d | İşlem:%d/%d\n",
    g_subPackageName.c_str(), g_subDaysLeft,
    g_subUsedProducts, g_subMaxProducts,
    g_subUsedTransactions, g_subMaxTransactions);
  return true;
}

// ════════════════════════════════════════════════════════════════
// 13. PERSONEL VE GARANTİ BİLGİLERİ
//     g_staff_* ve g_warranty_* değişkenlerini günceller.
//     Her 5 dakikada bir otomatik güncellenir (STAFF_WARRANTY_MS).
//
//     Manuel kullanım:
//       fetchStaffWarranty();
//       Serial.println("Personel: " + String(g_staffActive) + " aktif");
//       Serial.println("Garanti bugün bitiyor: " + String(g_warrantyExpiringToday));
// ════════════════════════════════════════════════════════════════

bool fetchStaffWarranty() {
  if (!g_paired) return false;

  DynamicJsonDocument doc(512);
  if (!_httpGet("/api/v1/devices/data/staff", doc)) {
    Serial.println("[PERSONEL] Personel/garanti bilgileri alınamadı");
    return false;
  }

  // Personel bilgileri
  g_staffConnectedUsers = doc["connected_user_count"] | 0;     // Toplam hesap sayısı (patron + personel)
  g_staffTotal          = doc["staff_total"] | 0;              // Toplam personel sayısı
  g_staffActive         = doc["staff_active"] | 0;             // Aktif personel sayısı

  // Garanti istatistikleri
  g_warrantyTotal          = doc["warranty_total"] | 0;        // Toplam garanti kaydı
  g_warrantyActive         = doc["warranty_active"] | 0;       // Aktif garantiler
  g_warrantyExpired        = doc["warranty_expired"] | 0;      // Süresi dolmuş
  g_warrantyExpiringToday  = doc["warranty_expiring_today"] | 0; // Bugün bitiyor
  g_warrantyExpiringWeek   = doc["warranty_expiring_week"] | 0;  // 7 günde bitiyor
  g_warrantyTodayAdded     = doc["warranty_today_added"] | 0;    // Bugün eklenen

  Serial.printf("[PERSONEL] Bağlı:%d | Aktif personel:%d\n",
    g_staffConnectedUsers, g_staffActive);
  Serial.printf("[GARANTİ] Toplam:%d | Aktif:%d | Bugün bitiyor:%d | Bugün eklendi:%d\n",
    g_warrantyTotal, g_warrantyActive, g_warrantyExpiringToday, g_warrantyTodayAdded);
  return true;
}

// ════════════════════════════════════════════════════════════════
// 14. PERİYODİK VERİ GÜNCELLEMELERİ — loop() içinden çağrılır
// ════════════════════════════════════════════════════════════════

void handlePeriodicUpdates() {
  if (!g_paired) return;                                       // Eşleşme yoksa atla

  // Özet verileri (her 2 dakikada bir)
  if (millis() - g_lastSummary >= SUMMARY_MS) {
    fetchSummary();
    g_lastSummary = millis();
  }

  // Abonelik bilgileri (her 5 dakikada bir)
  if (millis() - g_lastSubscription >= SUBSCRIPTION_MS) {
    fetchSubscription();
    g_lastSubscription = millis();
  }

  // Personel ve garanti (her 5 dakikada bir)
  if (millis() - g_lastStaffWarranty >= STAFF_WARRANTY_MS) {
    fetchStaffWarranty();
    g_lastStaffWarranty = millis();
  }
}

// ════════════════════════════════════════════════════════════════
// 15. KULLANICI KODU — KENDİ KODUNUZU BURAYA YAZIN
//
//     Bu fonksiyon her loop() döngüsünde çağrılır.
//     Tüm g_* değişkenlerine erişebilirsiniz.
//
//     ÖRNEK: Serial'dan barkod okuyup ekrana yazdır
//       if (Serial.available()) {
//         String barkod = Serial.readStringUntil('\n');
//         barkod.trim();
//         if (queryProduct(barkod)) {
//           Serial.println("=== ÜRÜN BULUNDU ===");
//           Serial.println("Ad    : " + g_productName);
//           Serial.println("Fiyat : " + String(g_productPrice) + " " + g_productCurrency);
//           Serial.println("Stok  : " + String(g_productStock) + " adet");
//           Serial.println("Durum : " + String(g_productIsCritical ? "KRİTİK" : "Normal"));
//         }
//       }
//
//     ÖRNEK: Bugünkü satış miktarını seri porta yaz
//       Serial.println("Bugün satış: " + String(g_sumTodaySalesAmount) + " TRY");
//
//     ÖRNEK: Abonelik dolmak üzereyse uyar
//       if (g_subDaysLeft <= 3 && g_subDaysLeft > 0) {
//         Serial.println("UYARI: Abonelik " + String(g_subDaysLeft) + " günde bitiyor!");
//       }
//
//     ÖRNEK: Bugün garanti bitecek müşteri varsa LED yak
//       if (g_warrantyExpiringToday > 0) {
//         digitalWrite(LED_BUILTIN, LOW); // ESP8266'da LOW = açık
//       }
// ════════════════════════════════════════════════════════════════

void userCode() {
  // BURAYA KENDİ KODUNUZU YAZIN

}

// ════════════════════════════════════════════════════════════════
// SETUP — tek seferlik başlangıç
// ════════════════════════════════════════════════════════════════

void setup() {
  setupSerial();                         // 1. Seri port başlat
  bool hasCredentials = setupEEPROM();   // 2. EEPROM başlat, kimlik bilgilerini yükle
  setupWifi();                           // 3. WiFi'ye bağlan (ilk kurulumda AP açar)
  setupDevice(hasCredentials);           // 4. Sunucuya kayıt ol ve ilk heartbeat gönder

  // Boot sonrası veri çekimi (eşleşme varsa)
  if (g_paired) {
    Serial.println("[BOOT] İlk veriler çekiliyor...");
    fetchSummary();        g_lastSummary = millis();
    fetchSubscription();   g_lastSubscription = millis();
    fetchStaffWarranty();  g_lastStaffWarranty = millis();
  }

  Serial.println("[HAZIR] Cihaz çalışmaya başladı | ID: " + g_deviceId);
  if (!g_paired) {
    Serial.println("[HAZIR] Bayi panelinden ID ile eşleştirin:");
    Serial.println("[HAZIR] Cihazlar → Cihaz Ekle → " + g_deviceId);
  }
}

// ════════════════════════════════════════════════════════════════
// LOOP — ana döngü (sade ve temiz)
// ════════════════════════════════════════════════════════════════

void loop() {
  if (!checkWifiStatus()) return;   // WiFi kontrolü — bağlantı yoksa dur

  handleHeartbeat();                // Heartbeat + OTA kontrolü (30 saniyede bir)
  handlePeriodicUpdates();          // Özet/abonelik/personel verilerini güncelle

  userCode();                       // KULLANICI KODU BURAYA

  delay(10);                        // CPU'yu bir nefes aldır
}
