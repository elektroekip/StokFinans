# 🎯 StokFinans - Stok ve Finansman Yönetim Sistemi

**Version:** 1.0.0  
**Status:** Production Ready ✅  
**Last Updated:** 28 Nisan 2026  

---

## 📋 Proje Özeti

**StokFinans**, küçük ve orta ölçekli işletmeler için **stok yönetimi** ve **finansman takibi** yapan tam yönetik web uygulamasıdır.

### Ana Özellikler

✅ **Ürün Yönetimi** - Stok, kategori, fiyatlandırma  
✅ **Finansman Takibi** - Satış, borç, ödeme işlemleri  
✅ **Dashboard & Raporlar** - KPI metrikleri, analitik  
✅ **Kullanıcı Yönetimi** - JWT authentication, rol yönetimi  
✅ **Dosya Yökleme** - Ürün resimleri, işlem ekleri  
✅ **Responsive UI** - Mobile-first Tailwind CSS  
✅ **Production Ready** - Docker, CI/CD, monitoring  

---

## 🚀 Hızlı Başlangıç

### Development (Docker ile)

```bash
git clone https://github.com/yourusername/stokfinans.git
cd stokfinans

docker-compose -f docker-compose.dev.yml up -d

# Frontend: http://localhost:5173
# Backend: http://localhost:8000
```

### Production

```bash
docker-compose up -d

# VPS üzerinde çalıştırmak için DEPLOYMENT_GUIDE.md'yi gör
```

---

## 📁 Proje Yapısı

```
stokfinans.com/
├── frontend/          # React 18 + Vite + TypeScript
│   ├── src/
│   ├── Dockerfile
│   └── nginx.conf
├── backend/           # FastAPI + SQLAlchemy + PostgreSQL
│   ├── app/
│   └── Dockerfile
├── docker-compose.yml
└── .github/workflows/ # GitHub Actions CI/CD
```

---

## 🔑 Özellikler

### Backend API (30 Endpoint)
- **Authentication:** Register, Login, JWT tokens
- **Products:** CRUD, search, filtering, stock management
- **Finance:** Sales, debts, payments, customer balance
- **Dashboard:** KPI metrics, critical stock alerts
- **Files:** Product images, transaction attachments
- **Reports:** Daily, monthly, custom date range

### Frontend UI
- **React 18** with Hooks and Context API
- **TypeScript** for type safety
- **Tailwind CSS** for responsive design
- **Axios** with JWT token refresh
- **Protected Routes** for authentication
- **Dashboard** with stats, alerts, charts

### Security
- JWT authentication (HS256)
- Password hashing (Bcrypt)
- CORS configuration
- Security headers (X-Frame-Options, etc.)
- File upload validation
- Non-root Docker user

### DevOps
- Docker & Docker Compose
- Nginx reverse proxy
- GitHub Actions CI/CD
- Health checks
- Volume persistence
- SSL/TLS ready (Let's Encrypt)

---

## 📚 Dokümantasyon

- **DEVELOPMENT.md** - Tüm 7 seviyenin detaylı açıklaması (1269 satır)
- **DEPLOYMENT_GUIDE.md** - VPS kurulumu ve deployment (550 satır)
- **LEVEL_*_SUMMARY.md** - Her seviyenin özeti

---

## 🐳 Docker Komutları

```bash
# Development
docker-compose -f docker-compose.dev.yml up -d
docker-compose -f docker-compose.dev.yml logs -f

# Production
docker-compose up -d
docker-compose ps
docker-compose down

# Clean
docker-compose down -v
```

---

## 📊 İstatistikler

- **7 Seviye** geliştirme
- **7000+** satır kod
- **30** API endpoint
- **1200+** satır frontend
- **1726+** satır deployment
- **550+** satır deployment guide

---

## ✅ Production Checklist

- [x] Backend API
- [x] Frontend UI
- [x] Database (PostgreSQL)
- [x] Docker containers
- [x] CI/CD pipeline
- [x] Security headers
- [x] SSL/TLS ready
- [x] Deployment guide

---

## 🚀 Production Deployment

See **DEPLOYMENT_GUIDE.md** for:
1. VPS setup (Ubuntu 22.04)
2. Docker installation
3. SSL certificates (Let's Encrypt)
4. GitHub Actions secrets
5. Monitoring setup

---

## 📄 Lisans

MIT License - Berat Bayramkivrak

---

## 🎉 Özet

**StokFinans 1.0.0 - Production Ready!**

7 seviye, 20+ saat geliştirme, 7000+ satır kod.

İşletmeniz için tam yönetik stok ve finansman çözümü. 🚀

