# ============================================================
# API Test Dosyası - Endpoints'i Hızlıca Test Et
# ============================================================
# Çalıştırma: python test_api.py
# Veya: python -m pytest test_api.py
#
# Sunucunun çalışıyor olması gerekir:
# uvicorn main:app --reload
# ============================================================

import requests
import json
from typing import Dict, Any

# ============================================================
# AYARLAR
# ============================================================

BASE_URL = "http://localhost:8000"
API_URL = f"{BASE_URL}/api/v1"

# Test verisi
TEST_BAYI = {
    "email": "test_bayi@stokfinans.com",
    "password": "test_sifre_123",
    "full_name": "Test Bayı",
    "company_name": "Test Oto Aksesuar",
    "role": "bayi_sahibi",
    "ref_code": None
}

TEST_CALISAN = {
    "email": "test_calisan@stokfinans.com",
    "password": "test_sifre_456",
    "full_name": "Test Çalışan",
    "company_name": None,
    "role": "calisan",
    "ref_code": None
}

# ============================================================
# YARDIMCI FONKSIYONLAR
# ============================================================

def print_header(text: str):
    """Başlık yazdır"""
    print(f"\n{'='*60}")
    print(f"  {text}")
    print(f"{'='*60}\n")

def print_response(response: requests.Response):
    """Response'u güzel yazdır"""
    print(f"Status Code: {response.status_code}")
    try:
        data = response.json()
        print(f"Response:\n{json.dumps(data, indent=2, ensure_ascii=False)}")
    except:
        print(f"Response: {response.text}")
    print()

def print_test_result(test_name: str, success: bool, message: str = ""):
    """Test sonucunu yazdır"""
    status = "✅ PASS" if success else "❌ FAIL"
    print(f"{status} - {test_name}")
    if message:
        print(f"  → {message}")

# ============================================================
# TEST FONKSIYONLARI
# ============================================================

def test_health_check():
    """API sağlık kontrolü"""
    print_header("1. Health Check")
    response = requests.get(f"{BASE_URL}/health")
    print_response(response)
    success = response.status_code == 200
    print_test_result("Health Check", success)
    return success

def test_root():
    """API ana sayfa"""
    print_header("2. Root Endpoint")
    response = requests.get(f"{BASE_URL}/")
    print_response(response)
    success = response.status_code == 200 and "StokFinans" in response.text
    print_test_result("Root Endpoint", success)
    return success

def test_register_bayi():
    """Bayı kayıt"""
    print_header("3. Bayı Kayıt")
    response = requests.post(
        f"{API_URL}/auth/register",
        json=TEST_BAYI
    )
    print_response(response)
    success = response.status_code == 201
    if success:
        data = response.json()
        TEST_BAYI["access_token"] = data.get("access_token")
        TEST_BAYI["refresh_token"] = data.get("refresh_token")
        TEST_BAYI["ref_code"] = data.get("user", {}).get("ref_code")
        print(f"Referral Code: {TEST_BAYI['ref_code']}")
    print_test_result("Bayı Kayıt", success)
    return success

def test_register_calisan():
    """Çalışan kayıt"""
    print_header("4. Çalışan Kayıt")
    response = requests.post(
        f"{API_URL}/auth/register",
        json=TEST_CALISAN
    )
    print_response(response)
    success = response.status_code == 201
    if success:
        data = response.json()
        TEST_CALISAN["access_token"] = data.get("access_token")
        TEST_CALISAN["refresh_token"] = data.get("refresh_token")
    print_test_result("Çalışan Kayıt", success)
    return success

def test_login():
    """Giriş yapma"""
    print_header("5. Login")
    response = requests.post(
        f"{API_URL}/auth/login",
        json={
            "email": TEST_BAYI["email"],
            "password": TEST_BAYI["password"]
        }
    )
    print_response(response)
    success = response.status_code == 200
    if success:
        data = response.json()
        TEST_BAYI["access_token"] = data.get("access_token")
    print_test_result("Login", success)
    return success

def test_get_profile():
    """Profil bilgilerini getir (protected endpoint)"""
    print_header("6. Get Profile (Protected)")
    headers = {
        "Authorization": f"Bearer {TEST_BAYI['access_token']}"
    }
    response = requests.get(
        f"{API_URL}/auth/profile",
        headers=headers
    )
    print_response(response)
    success = response.status_code == 200
    print_test_result("Get Profile", success)
    return success

def test_profile_without_token():
    """Token olmadan profil erişimi (401 beklenen)"""
    print_header("7. Profile Without Token (Expected 401)")
    response = requests.get(f"{API_URL}/auth/profile")
    print_response(response)
    success = response.status_code == 401
    print_test_result("Profile Without Token (Should be 401)", success)
    return success

def test_refresh_token():
    """Token yenileme"""
    print_header("8. Refresh Token")
    response = requests.post(
        f"{API_URL}/auth/refresh",
        json={"refresh_token": TEST_BAYI["refresh_token"]}
    )
    print_response(response)
    success = response.status_code == 200
    print_test_result("Refresh Token", success)
    return success

def test_duplicate_email():
    """Aynı email ile kayıt (400 beklenen)"""
    print_header("9. Duplicate Email (Expected 400)")
    response = requests.post(
        f"{API_URL}/auth/register",
        json=TEST_BAYI  # Aynı email
    )
    print_response(response)
    success = response.status_code == 400
    print_test_result("Duplicate Email (Should be 400)", success)
    return success

# ============================================================
# MAIN TEST SUITE
# ============================================================

def run_all_tests():
    """Tüm testleri çalıştır"""
    print("\n")
    print("╔" + "="*58 + "╗")
    print("║" + " "*10 + "🧪 STOKFINANS API TEST SUITE" + " "*19 + "║")
    print("╚" + "="*58 + "╝")

    results = {
        "Health Check": test_health_check(),
        "Root Endpoint": test_root(),
        "Bayı Register": test_register_bayi(),
        "Çalışan Register": test_register_calisan(),
        "Login": test_login(),
        "Get Profile": test_get_profile(),
        "Profile Without Token": test_profile_without_token(),
        "Refresh Token": test_refresh_token(),
        "Duplicate Email": test_duplicate_email(),
    }

    # Özet
    print_header("📊 TEST ÖZETI")
    passed = sum(1 for v in results.values() if v)
    total = len(results)

    for test_name, success in results.items():
        status = "✅" if success else "❌"
        print(f"{status} {test_name}")

    print(f"\n{'='*60}")
    print(f"TOPLAM: {passed}/{total} test başarılı ({int(passed/total*100)}%)")
    print(f"{'='*60}\n")

    if passed == total:
        print("🎉 TÜM TESTLER BAŞARILI! API hazır!")
    else:
        print(f"⚠️  {total - passed} test başarısız oldu.")

# ============================================================
# ÇALIŞTIRMA
# ============================================================

if __name__ == "__main__":
    try:
        run_all_tests()
    except requests.exceptions.ConnectionError:
        print("❌ Hata: API sunucusu yanıt vermiyor.")
        print("Lütfen sunucuyu başlatın:")
        print("  uvicorn main:app --reload")
    except Exception as e:
        print(f"❌ Hata: {e}")
