from sqlalchemy.orm import Session
from app.core.database import SessionLocal, engine
from app.models.user import User
from app.utils.security import hash_password

def seed_users():
    db = SessionLocal()
    suspicious_hash = "$2b$12$k8SHDZIDKVa9m8GUhH0ghetLjL4e79E.rEriSW4afYvcQVtSkJ3na"
    default_pwd = "password123"
    
    try:
        # 1. Update all users with suspicious hash
        users_to_fix = db.query(User).filter(User.password_hash == suspicious_hash).all()
        for u in users_to_fix:
            u.password_hash = hash_password(default_pwd)
            print(f"Fixed hash for user: {u.email} (New password: {default_pwd})")

        # 2. Create or Update Admin
        admin = db.query(User).filter(User.email == "admin@stokfinans.com").first()
        if admin:
            admin.password_hash = hash_password("admin123456")
            print(f"Updated admin password hash")
        else:
            admin = User(
                email="admin@stokfinans.com",
                password_hash=hash_password("admin123456"),
                full_name="System Admin",
                company_name="StokFinans HQ",
                role="bayi_sahibi",
                sub_days=365,
                is_active=True
            )
            db.add(admin)
            print(f"Created admin user")

        # 3. Create or Update Demo
        demo = db.query(User).filter(User.email == "demo@stokfinans.com").first()
        if demo:
            demo.password_hash = hash_password("demo123456")
            print(f"Updated demo password hash")
        else:
            demo = User(
                email="demo@stokfinans.com",
                password_hash=hash_password("demo123456"),
                full_name="Demo User",
                company_name="Demo Company",
                role="bayi_sahibi",
                sub_days=14,
                is_active=True
            )
            db.add(demo)
            print(f"Created demo user")

        db.commit()
        print("Seeding successful!")
    except Exception as e:
        print(f"Seeding failed: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    seed_users()
