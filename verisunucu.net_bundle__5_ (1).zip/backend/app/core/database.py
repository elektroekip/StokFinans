# ============================================================
# Database Configuration - Veritabanı Ayarları ve Bağlantı
# ============================================================
# Bu dosya, veritabanına bağlanmak ve session yönetmek için
# gerekli tüm fonksiyonları içerir.
# ============================================================

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.pool import StaticPool
import os
from typing import Generator

# ============================================================
# Ortak Declarative Base - Tüm Modeller Bunu Kullanır
# ============================================================
Base = declarative_base()

# Çevre değişkeninden DATABASE_URL'i oku
# Eğer tanımlı değilse, SQLite kullan (geliştirme)
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "sqlite:///./stokfinans.db"
)


def _mask_db_url(url: str) -> str:
    """Veritabanı URL'sindeki kullanıcı adı ve şifreyi log için maskele."""
    try:
        from urllib.parse import urlparse, urlunparse
        parsed = urlparse(url)
        if parsed.password or parsed.username:
            netloc = parsed.hostname or ""
            if parsed.port:
                netloc = f"{netloc}:{parsed.port}"
            if parsed.username:
                netloc = f"***:***@{netloc}"
            return urlunparse(parsed._replace(netloc=netloc))
        return url
    except Exception:
        return "<masked>"


print(f"[DATABASE] URL: {_mask_db_url(DATABASE_URL)}")

# ============================================================
# Engine Konfigürasyonu
# ============================================================
# SQLite ve PostgreSQL'e bağlı olarak farklı ayarlar

if DATABASE_URL.startswith("sqlite"):
    # SQLite için: check_same_thread=False ve StaticPool kullan
    # (Geliştirme ortamında thread problemini çöz)
    engine = create_engine(
        DATABASE_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    print("[OK] SQLite Engine created (Development Mode)")
else:
    # PostgreSQL veya diğer veritabanları için
    engine = create_engine(
        DATABASE_URL,
        pool_pre_ping=True,  # Bağlantı kontrolü
        pool_recycle=3600,  # Saatlik bağlantı yenileme
        echo=False,  # SQL sorgularını konsola yazdırma
    )
    print("[OK] PostgreSQL Engine created (Production Mode)")

# ============================================================
# Session Factory
# ============================================================
# Veritabanı işlemleri için session nesneleri oluşturur
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)

# ============================================================
# Database Dependency
# ============================================================
# FastAPI'de kullanılacak dependency function
# Her API çağrısı için otomatik session sağlar

def get_db() -> Generator[Session, None, None]:
    """
    Veritabanı session bağımlılığı (Dependency)

    FastAPI endpoint'lerinde şu şekilde kullanılır:
    @app.get("/users")
    def get_users(db: Session = Depends(get_db)):
        users = db.query(User).all()
        return users

    Yields:
        Session: Veritabanı session nesnesi
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ============================================================
# Tabloları Oluştur
# ============================================================
# Uygulama başlatılırken, tüm modellere göre tablolar oluşturulur

def init_db():
    """
    Tüm tabloları veritabanında oluştur

    Kullanım:
    from app.core.database import init_db
    init_db()
    """
    # Modelleri import et (metadata'ya register etmek için)
    import app.models.user      # noqa
    import app.models.product   # noqa
    import app.models.transaction  # noqa
    import app.models.log       # noqa
    import app.models.file_location  # noqa — disk yönetimi tablosu

    Base.metadata.create_all(bind=engine)
    print("[OK] Tüm tablolar oluşturuldu!")

# ============================================================
# Test Bağlantısı
# ============================================================

def test_connection():
    """Veritabanı bağlantısını test et"""
    try:
        db = SessionLocal()
        db.execute(text("SELECT 1"))
        db.close()
        print("[OK] Veritabanı bağlantısı başarılı!")
        return True
    except Exception as e:
        print(f"[ERROR] Veritabanı bağlantı hatası: {e}")
        return False

# ============================================================
# NOTLAR
# ============================================================
# 1. SQLite: Geliştirme için yeterli, prod'da risk
# 2. PostgreSQL: Üretim için önerilir (çok user, güvenli)
# 3. Pool: Çok sayıda bağlantı yönetimini otomatikleştirir
# 4. get_db(): FastAPI Depends() mekanizması ile otomatik
# ============================================================
