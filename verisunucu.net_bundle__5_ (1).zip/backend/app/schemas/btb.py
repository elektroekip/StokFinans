from __future__ import annotations
from datetime import date, datetime
from typing import List, Optional
from pydantic import BaseModel, Field


# ── Customer ──────────────────────────────────────────────────

class BtbCustomerCreate(BaseModel):
    company_name: str = Field(..., min_length=1, max_length=255)
    contact_person: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    vkn: Optional[str] = None
    tax_office: Optional[str] = None
    address: Optional[str] = None
    notes: Optional[str] = None
    category: str = "B"           # A / B / C
    discount_rate: float = 0      # Müşteri iskonto %
    credit_limit: float = 0
    payment_term_days: int = 30
    is_active: bool = True


class BtbCustomerUpdate(BaseModel):
    company_name: Optional[str] = Field(None, min_length=1, max_length=255)
    contact_person: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    vkn: Optional[str] = None
    tax_office: Optional[str] = None
    address: Optional[str] = None
    notes: Optional[str] = None
    category: Optional[str] = None
    discount_rate: Optional[float] = None
    credit_limit: Optional[float] = None
    payment_term_days: Optional[int] = None
    is_active: Optional[bool] = None


class BtbCustomerOut(BaseModel):
    id: int
    company_name: str
    contact_person: Optional[str]
    phone: Optional[str]
    email: Optional[str]
    vkn: Optional[str]
    tax_office: Optional[str] = None
    address: Optional[str]
    notes: Optional[str]
    category: str = "B"
    discount_rate: float = 0
    credit_limit: float
    payment_term_days: int
    is_active: bool
    created_at: Optional[datetime]
    updated_at: Optional[datetime]
    # Computed in API
    order_count: int = 0
    total_debt: float = 0.0
    paid_amount: float = 0.0      # toplam tahsilat
    overdue_count: int = 0        # vadesi geçmiş sipariş sayısı

    class Config:
        from_attributes = True


# ── Order Item ────────────────────────────────────────────────

class BtbOrderItemCreate(BaseModel):
    product_id: Optional[int] = None
    product_name: str = Field(..., min_length=1, max_length=255)
    unit_price: float = Field(..., ge=0)
    currency: str = "TRY"
    quantity: int = Field(..., ge=1)
    discount_rate: float = Field(0, ge=0, le=100)  # Kalem iskonto %
    kdv_rate: float = Field(0, ge=0, le=100)


class BtbOrderItemOut(BaseModel):
    id: int
    product_id: Optional[int]
    product_name: str
    unit_price: float
    currency: str
    quantity: int
    discount_rate: float = 0
    kdv_rate: float
    line_total: float = 0

    class Config:
        from_attributes = True


# ── Order ─────────────────────────────────────────────────────

class BtbOrderCreate(BaseModel):
    customer_id: int
    notes: Optional[str] = None
    due_date: Optional[date] = None
    shipping_address: Optional[str] = None
    shipping_carrier: Optional[str] = None
    tracking_number: Optional[str] = None
    currency: str = "TRY"
    discount_rate: float = Field(0, ge=0, le=100)  # Sipariş bazlı ek iskonto %
    items: List[BtbOrderItemCreate] = Field(..., min_length=1)


class BtbOrderUpdate(BaseModel):
    customer_id: Optional[int] = None
    notes: Optional[str] = None
    due_date: Optional[date] = None
    shipping_address: Optional[str] = None
    shipping_carrier: Optional[str] = None
    tracking_number: Optional[str] = None
    currency: Optional[str] = None
    discount_rate: Optional[float] = None
    items: Optional[List[BtbOrderItemCreate]] = None


class BtbOrderOut(BaseModel):
    id: int
    customer_id: int
    customer_name: str = ""
    order_number: str
    status: str
    notes: Optional[str]
    due_date: Optional[date]
    shipping_address: Optional[str] = None
    shipping_carrier: Optional[str] = None
    tracking_number: Optional[str] = None
    subtotal: float = 0
    kdv_amount: float = 0
    discount_rate: float = 0
    discount_amount: float = 0
    total_amount: float
    currency: str
    transaction_id: Optional[int]
    is_paid: bool = False
    paid_at: Optional[datetime] = None
    paid_total: float = 0       # Toplam ödenen tutar (btb_payments toplamı)
    remaining: float = 0        # Kalan borç
    created_at: Optional[datetime]
    updated_at: Optional[datetime]
    items: List[BtbOrderItemOut] = []
    payments: List["BtbPaymentOut"] = []

    class Config:
        from_attributes = True


# ── Payments ──────────────────────────────────────────────────

class BtbPaymentCreate(BaseModel):
    amount: float = Field(..., gt=0)
    payment_method: str = "cash"  # cash | bank | check | card | other
    notes: Optional[str] = None
    paid_at: Optional[datetime] = None


class BtbPaymentOut(BaseModel):
    id: int
    order_id: int
    amount: float
    payment_method: str
    notes: Optional[str]
    paid_at: Optional[datetime]
    created_at: Optional[datetime]

    class Config:
        from_attributes = True


BtbOrderOut.model_rebuild()


# ── Stats ─────────────────────────────────────────────────────

class BtbStatsOut(BaseModel):
    active_orders: int
    total_receivable: float
    customer_count: int
    delivered_this_month: int
    overdue_count: int = 0
    total_collected_this_month: float = 0


# ── Price List ────────────────────────────────────────────────

class BtbPriceListCreate(BaseModel):
    category: str = "ALL"           # A | B | C | ALL
    product_id: Optional[int] = None
    product_name: str = Field(..., min_length=1, max_length=255)
    custom_price: Optional[float] = Field(None, ge=0)
    discount_override: Optional[float] = Field(None, ge=0, le=100)
    is_active: bool = True


class BtbPriceListUpdate(BaseModel):
    category: Optional[str] = None
    product_id: Optional[int] = None
    product_name: Optional[str] = None
    custom_price: Optional[float] = None
    discount_override: Optional[float] = None
    is_active: Optional[bool] = None


class BtbPriceListOut(BaseModel):
    id: int
    category: str
    product_id: Optional[int]
    product_name: str
    custom_price: Optional[float]
    discount_override: Optional[float]
    is_active: bool
    created_at: Optional[datetime]
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True


class CreditCheckOut(BaseModel):
    customer_id: int
    company_name: str
    credit_limit: float
    current_debt: float
    available_credit: float
    order_amount: float
    would_exceed: bool
    remaining_after: float
