"""Pydantic şemaları — Kategori (Web Görünüm) endpoint'leri için."""

from datetime import datetime
from typing import Literal, Optional, List

from pydantic import BaseModel, Field, field_validator


CategoryKind = Literal["stok", "finans"]
ViewMode = Literal["list", "grid", "masonry", "carousel", "category"]


def _slugify_key(value: str) -> str:
    """Türkçe karakterleri korur ama URL-safe slug üretir."""
    import re
    s = (value or "").strip().lower()
    tr_map = str.maketrans("çğıöşüÇĞİÖŞÜ", "cgiosucgiosu")
    s = s.translate(tr_map)
    s = re.sub(r"[^a-z0-9]+", "_", s).strip("_")
    return s[:80] or "kategori"


class CategoryBase(BaseModel):
    kind: CategoryKind
    name: str = Field(..., min_length=1, max_length=200)
    icon: str = Field("Package", max_length=80)
    color_class: str = Field("text-indigo-600 dark:text-indigo-400", max_length=120)
    bg_class: str = Field("bg-indigo-100 dark:bg-indigo-900/30", max_length=120)
    display_order: int = Field(100, ge=0, le=10_000)
    is_visible: bool = True
    transaction_type: Optional[str] = Field(None, max_length=50)
    customer_label: Optional[str] = Field(None, max_length=120)
    amount_label: Optional[str] = Field(None, max_length=120)
    amount_tone: Optional[str] = Field(None, max_length=40)
    allow_edit_type: bool = False
    view_mode: ViewMode = "list"


class CategoryCreate(CategoryBase):
    key: Optional[str] = Field(None, max_length=80, description="Boş bırakılırsa addan üretilir")

    @field_validator("key")
    @classmethod
    def _validate_key(cls, v):
        if v is None:
            return v
        return _slugify_key(v)


class CategoryUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    icon: Optional[str] = Field(None, max_length=80)
    color_class: Optional[str] = Field(None, max_length=120)
    bg_class: Optional[str] = Field(None, max_length=120)
    display_order: Optional[int] = Field(None, ge=0, le=10_000)
    is_visible: Optional[bool] = None
    transaction_type: Optional[str] = Field(None, max_length=50)
    customer_label: Optional[str] = Field(None, max_length=120)
    amount_label: Optional[str] = Field(None, max_length=120)
    amount_tone: Optional[str] = Field(None, max_length=40)
    allow_edit_type: Optional[bool] = None
    view_mode: Optional[ViewMode] = None
    # Adın değişmesi key'i değiştirmez (aksi halde mevcut ürünlerin kategori adlarıyla bağı bozulur).


class CategoryOut(CategoryBase):
    id: int
    key: str
    is_default: bool
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class CategoryListResponse(BaseModel):
    items: List[CategoryOut]
    total: int
