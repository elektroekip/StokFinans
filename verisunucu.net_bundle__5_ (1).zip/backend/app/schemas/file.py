# ============================================================
# File Upload Schemas - Dosya Yükleme API Validation
# ============================================================
# Ürün fotoğrafı, işlem belgesi ve raporlar
#
# Seviye: SEVIYE 5 - Gelişmiş Özellikler
# Tarih: 28 Nisan 2026
# ============================================================

from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

# ============================================================
# RESPONSE MODELLERI
# ============================================================

class FileUploadResponse(BaseModel):
    """
    Dosya yükleme cevabı
    """
    message: str = "Dosya başarıyla yüklendi"
    file_id: str  # UUID veya ID
    filename: str
    original_filename: str
    file_size: int  # Byte cinsinden
    mime_type: str
    file_url: str  # Erişim URL'i
    uploaded_at: datetime

    class Config:
        json_schema_extra = {
            "example": {
                "message": "Dosya başarıyla yüklendi",
                "file_id": "550e8400-e29b-41d4-a716-446655440000",
                "filename": "product_1_550e8400.jpg",
                "original_filename": "foto.jpg",
                "file_size": 524288,
                "mime_type": "image/jpeg",
                "file_url": "/api/v1/files/product_1_550e8400.jpg",
                "uploaded_at": "2026-04-28T16:00:00"
            }
        }


class ProductImageResponse(BaseModel):
    """
    Ürün fotoğrafı bilgisi
    """
    product_id: int
    product_name: str
    image_url: str
    image_size: int
    mime_type: str
    uploaded_at: datetime

    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "product_id": 1,
                "product_name": "Oto Kapısı Kilidi",
                "image_url": "/api/v1/files/product_1_550e8400.jpg",
                "image_size": 524288,
                "mime_type": "image/jpeg",
                "uploaded_at": "2026-04-28T16:00:00"
            }
        }


class TransactionAttachmentResponse(BaseModel):
    """
    İşlem belgesi bilgisi
    """
    transaction_id: int
    attachment_url: str
    attachment_type: str  # "receipt", "invoice", "contract"
    file_size: int
    mime_type: str
    uploaded_at: datetime

    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "transaction_id": 5,
                "attachment_url": "/api/v1/files/transaction_5_abc123.pdf",
                "attachment_type": "receipt",
                "file_size": 102400,
                "mime_type": "application/pdf",
                "uploaded_at": "2026-04-28T16:00:00"
            }
        }


class FileDeleteResponse(BaseModel):
    """
    Dosya silme cevabı
    """
    message: str = "Dosya başarıyla silindi"
    file_id: str
    filename: str

    class Config:
        json_schema_extra = {
            "example": {
                "message": "Dosya başarıyla silindi",
                "file_id": "550e8400-e29b-41d4-a716-446655440000",
                "filename": "product_1_550e8400.jpg"
            }
        }


class ReportResponse(BaseModel):
    """
    Rapor oluşturma cevabı
    """
    message: str = "Rapor başarıyla oluşturuldu"
    report_type: str  # "daily", "monthly", "custom"
    report_url: str
    report_size: int
    generated_at: datetime
    period_start: datetime
    period_end: datetime

    class Config:
        json_schema_extra = {
            "example": {
                "message": "Rapor başarıyla oluşturuldu",
                "report_type": "daily",
                "report_url": "/api/v1/reports/daily_2026_04_28.pdf",
                "report_size": 512000,
                "generated_at": "2026-04-28T16:00:00",
                "period_start": "2026-04-28T00:00:00",
                "period_end": "2026-04-28T23:59:59"
            }
        }


class BackupResponse(BaseModel):
    """
    Veritabanı yedekleme cevabı
    """
    message: str = "Yedek başarıyla oluşturuldu"
    backup_id: str
    backup_size: int
    backup_url: str
    created_at: datetime
    expires_at: datetime  # Yedek silinmeden önce kaç gün

    class Config:
        json_schema_extra = {
            "example": {
                "message": "Yedek başarıyla oluşturuldu",
                "backup_id": "backup_20260428_160000",
                "backup_size": 5242880,
                "backup_url": "/api/v1/backups/backup_20260428_160000.sql",
                "created_at": "2026-04-28T16:00:00",
                "expires_at": "2026-05-28T16:00:00"
            }
        }
