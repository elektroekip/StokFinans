# ============================================================
# User Schemas - Kullanıcı API Giriş/Çıkış Modeleri
# ============================================================
# Bu dosya, User ile ilgili API istekleri ve cevaplarının
# yapısını Pydantic ile tanımlar. Otomatik validasyon sağlar.
# ============================================================

from pydantic import BaseModel, EmailStr, Field, field_validator
from datetime import datetime
from typing import Optional, List

# ============================================================
# REQUEST SCHEMAS (API'ye gelen veriler)
# ============================================================

class UserRegisterRequest(BaseModel):
    """
    Kullanıcı Kayıt İsteği

    Örnek JSON:
    {
        "email": "ahmet@stokfinans.com",
        "password": "sifre123",
        "full_name": "Ahmet Yılmaz",
        "company_name": "Etiket Oto Aksesuar",
        "role": "bayi_sahibi",
        "ref_code": "BAYI2026"
    }
    """
    email: EmailStr = Field(..., description="E-posta adresi")
    password: str = Field(..., min_length=8, description="En az 8 karakter")
    full_name: str = Field(..., min_length=2, max_length=150, description="Ad Soyad")
    company_name: Optional[str] = Field(None, max_length=200, description="İşletme adı (bayı için)")
    role: str = Field(default="calisan", description="bayi_sahibi veya calisan")
    ref_code: Optional[str] = Field(None, max_length=20, description="Referans kodu (opsiyonel)")

    @field_validator("role")
    @classmethod
    def role_must_be_valid(cls, v: str) -> str:
        allowed = {"bayi_sahibi", "calisan"}
        if v not in allowed:
            raise ValueError(f"Geçersiz rol. İzin verilenler: {', '.join(sorted(allowed))}")
        return v


class UserLoginRequest(BaseModel):
    """
    Kullanıcı Giriş İsteği

    Örnek JSON:
    {
        "email": "ahmet@stokfinans.com",
        "password": "sifre123"
    }
    """
    email: EmailStr = Field(..., description="E-posta adresi")
    password: str = Field(..., description="Şifre")


class UserUpdateRequest(BaseModel):
    """
    Kullanıcı Güncelleme İsteği

    Örnek JSON:
    {
        "full_name": "Ahmet Yılmaz Jr.",
        "company_name": "Etiket Oto Aksesuar 2.0"
    }
    """
    full_name: Optional[str] = Field(None, min_length=2)
    company_name: Optional[str] = Field(None)
    company_address: Optional[str] = Field(None, max_length=500, description="İşyeri adresi")
    company_phone: Optional[str] = Field(None, max_length=50, description="İşyeri telefon numarası")


class EmailChangeRequest(BaseModel):
    """
    E-posta Değiştirme İsteği

    Örnek JSON:
    {
        "new_email": "yeni@ornek.com",
        "password": "mevcutSifre"
    }
    """
    new_email: EmailStr = Field(..., description="Yeni e-posta adresi")
    password: str = Field(..., description="Mevcut şifre (onay için)")


class UnverifiedEmailUpdateRequest(BaseModel):
    """
    Doğrulanmamış hesabın e-posta adresini düzeltme isteği.

    Kullanıcı kayıt sırasında e-postasını yanlış yazmışsa,
    doğrulama bekleme ekranından bu uç ile düzeltebilir.

    Örnek JSON:
    {
        "current_email": "yanlis@ornek.com",
        "password": "mevcutSifre",
        "new_email": "dogru@ornek.com"
    }
    """
    current_email: EmailStr = Field(..., description="Mevcut (doğrulanmamış) e-posta adresi")
    password: str = Field(..., description="Hesap şifresi (onay için)")
    new_email: EmailStr = Field(..., description="Düzeltilmiş yeni e-posta adresi")


# ============================================================
# RESPONSE SCHEMAS (API'den dönen veriler)
# ============================================================

class UserResponse(BaseModel):
    """
    Kullanıcı Cevap Modeli (Gizli bilgisiz)

    Örnek JSON (Çıkış):
    {
        "id": 1,
        "email": "ahmet@stokfinans.com",
        "full_name": "Ahmet Yılmaz",
        "role": "bayi_sahibi",
        "ref_code": "BAYI2026",
        "sub_days": 24,
        "is_active": true,
        "created_at": "2026-04-28T17:15:00"
    }
    """
    id: int = Field(..., description="Kullanıcı ID")
    email: str = Field(..., description="E-posta adresi")
    full_name: str = Field(..., description="Tam ad")
    company_name: Optional[str] = Field(None, description="İşletme adı")
    company_address: Optional[str] = Field(None, description="İşyeri adresi")
    company_phone: Optional[str] = Field(None, description="İşyeri telefon numarası")
    role: str = Field(..., description="Kullanıcı rolü")
    ref_code: Optional[str] = Field(None, description="Referans kodu")
    sub_days: int = Field(..., description="Kalan abonelik günü")
    is_active: bool = Field(..., description="Hesap aktif mi?")
    is_super_admin: bool = Field(default=False, description="Platform süper yöneticisi mi?")
    is_email_verified: bool = Field(default=True, description="E-posta doğrulandı mı?")
    pending_email: Optional[str] = Field(None, description="Onay bekleyen yeni e-posta adresi")
    pending_email_expires_at: Optional[datetime] = Field(
        None,
        description="Bekleyen e-posta doğrulama bağlantısının sona erme zamanı (ISO 8601, UTC)",
    )
    parent_user_id: Optional[int] = Field(None, description="Çalışansa: bağlı patron user_id")
    permissions: Optional[List[str]] = Field(None, description="Çalışan sayfa izinleri")
    created_at: datetime = Field(..., description="Oluşturulma tarihi")

    class Config:
        from_attributes = True  # SQLAlchemy modeli → Pydantic dönüştürme


class LoginResponse(BaseModel):
    """
    Giriş Cevabı (Token ile)

    Örnek JSON (Çıkış):
    {
        "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        "token_type": "bearer",
        "user": {...},
        "expires_in": 1800
    }
    """
    access_token: str = Field(..., description="JWT Access Token")
    refresh_token: str = Field(..., description="JWT Refresh Token")
    token_type: str = Field(default="bearer", description="Token türü")
    user: Optional[UserResponse] = Field(None, description="Kullanıcı bilgileri")
    expires_in: int = Field(..., description="Access token süresi (saniye)")
    email_verification_required: bool = Field(default=False, description="E-posta doğrulama gerekiyor mu?")
    email: Optional[str] = Field(None, description="Doğrulama gerektiğinde kullanıcı e-postası")


class RegisterResponse(BaseModel):
    """
    Kayıt Cevabı

    Örnek JSON (Çıkış):
    {
        "message": "Hesabınız başarılı şekilde oluşturuldu",
        "user": {...},
        "access_token": "...",
        "refresh_token": "...",
        "email_verification_required": false
    }
    """
    message: str = Field(..., description="Başarı mesajı")
    user: UserResponse = Field(..., description="Oluşturulan kullanıcı")
    access_token: str = Field(..., description="Otomatik giriş token'ı")
    refresh_token: str = Field(..., description="Refresh token")
    email_verification_required: bool = Field(default=False, description="E-posta doğrulama gerekiyor mu?")


class TokenRefreshRequest(BaseModel):
    """
    Token Yenileme İsteği

    Örnek JSON:
    {
        "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
    }
    """
    refresh_token: str = Field(..., description="Refresh token")


class TokenRefreshResponse(BaseModel):
    """
    Token Yenileme Cevabı — Rotation: her refresh yeni bir refresh_token döner.
    Frontend eski refresh_token'ı atmalı ve dönen refresh_token'ı saklamalıdır.

    Örnek JSON (Çıkış):
    {
        "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        "token_type": "bearer",
        "expires_in": 1800
    }
    """
    access_token: str = Field(..., description="Yeni JWT Access Token")
    refresh_token: str = Field(..., description="Döndürülmüş (rotated) yeni Refresh Token")
    token_type: str = Field(default="bearer", description="Token türü")
    expires_in: int = Field(..., description="Access token süresi (saniye)")


class UserStatsResponse(BaseModel):
    """
    Kullanıcı İstatistikleri (Dashboard için)

    Örnek JSON (Çıkış):
    {
        "total_products": 45,
        "out_of_stock": 5,
        "critical_stock": 12,
        "total_revenue": 50000.00,
        "pending_collection": 15000.00,
        "total_debt": 25000.00
    }
    """
    total_products: int = Field(..., description="Toplam ürün sayısı")
    out_of_stock: int = Field(..., description="Tükenmiş ürün")
    critical_stock: int = Field(..., description="Kritik stok ürün")
    total_revenue: float = Field(..., description="Toplam ciro (TRY)")
    pending_collection: float = Field(..., description="Bekleyen tahsilat (TRY)")
    total_debt: float = Field(..., description="Toplam borç (TRY)")


# ============================================================
# AÇIKLAMALAR
# ============================================================
# 1. EmailStr: Otomatik email validasyonu
#    ❌ "invalid" → Hata
#    ✅ "user@example.com" → OK
#
# 2. Field(...): Zorunlu alan
#    Field(..., description="...") → API docs'ta gösterilir
#
# 3. Optional[str]: Opsiyonel (None olabilir)
#    Field(None) ile varsayılan None
#
# 4. class Config: Pydantic ayarları
#    from_attributes=True: SQLAlchemy → Pydantic otomatik dönüşüm
# ============================================================
