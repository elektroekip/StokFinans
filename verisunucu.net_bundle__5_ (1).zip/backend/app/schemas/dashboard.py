# ============================================================
# Dashboard Schemas - Dashboard API Validation Modelleri
# ============================================================
# İstatistikler, Özet Raporlar ve Uyarılar
#
# Seviye: SEVIYE 4 - Motor Odası
# Tarih: 28 Nisan 2026
# ============================================================

from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

# ============================================================
# RESPONSE MODELLERI
# ============================================================

class StatsItem(BaseModel):
    """
    İstatistik öğesi (toplam, artış vb)
    """
    label: str
    value: float
    percentage_change: Optional[float] = None  # Önceki döneme göre değişim
    trend: Optional[str] = None  # "up", "down", "flat"

    class Config:
        json_schema_extra = {
            "example": {
                "label": "Toplam Satış",
                "value": 125000.00,
                "percentage_change": 15.5,
                "trend": "up"
            }
        }


class DashboardStatsResponse(BaseModel):
    """
    Ana dashboard istatistikleri

    Alanlar:
    - total_products: Toplam ürün sayısı
    - total_categories: Toplam kategori sayısı
    - critical_stock_count: Kritik stok ürün sayısı
    - total_customers: Toplam müşteri sayısı
    - total_sales: Toplam satış tutarı
    - total_revenue: Toplam gelir (satış x kar marjı)
    - outstanding_debt: Ödenmemiş borç
    - period: İstatistik dönemi (daily, weekly, monthly)
    """
    total_products: StatsItem
    total_categories: StatsItem
    critical_stock_count: StatsItem
    total_customers: StatsItem
    total_sales: StatsItem
    total_revenue: StatsItem
    outstanding_debt: StatsItem
    period: str = "last_30_days"

    class Config:
        json_schema_extra = {
            "example": {
                "total_products": {
                    "label": "Toplam Ürün",
                    "value": 450,
                    "percentage_change": 5.0,
                    "trend": "up"
                },
                "total_categories": {
                    "label": "Kategoriler",
                    "value": 12,
                    "percentage_change": 0.0,
                    "trend": "flat"
                },
                "critical_stock_count": {
                    "label": "Kritik Stok",
                    "value": 15,
                    "percentage_change": -10.0,
                    "trend": "down"
                },
                "total_customers": {
                    "label": "Müşteriler",
                    "value": 85,
                    "percentage_change": 20.0,
                    "trend": "up"
                },
                "total_sales": {
                    "label": "Satışlar",
                    "value": 250000.00,
                    "percentage_change": 12.5,
                    "trend": "up"
                },
                "total_revenue": {
                    "label": "Gelir",
                    "value": 87500.00,
                    "percentage_change": 12.5,
                    "trend": "up"
                },
                "outstanding_debt": {
                    "label": "Ödenmemiş Borç",
                    "value": 45000.00,
                    "percentage_change": 8.0,
                    "trend": "up"
                },
                "period": "last_30_days"
            }
        }


class CriticalStockWarningResponse(BaseModel):
    """
    Kritik stok uyarısı
    """
    product_id: int
    product_name: str
    category: str
    current_stock: int
    min_alert_level: int
    shortage: int
    severity: str  # "low", "medium", "critical"
    reorder_quantity: int
    last_updated: datetime

    class Config:
        json_schema_extra = {
            "example": {
                "product_id": 5,
                "product_name": "Aydınlatma Seti",
                "category": "Aydınlatma",
                "current_stock": 2,
                "min_alert_level": 15,
                "shortage": 13,
                "severity": "critical",
                "reorder_quantity": 26,
                "last_updated": "2026-04-28T15:30:00"
            }
        }


class CriticalStockAlertsResponse(BaseModel):
    """
    Kritik stok uyarıları listesi
    """
    total_alerts: int
    critical: int
    medium: int
    low: int
    alerts: List[CriticalStockWarningResponse]
    total_shortage_value: float  # Eksik stok x fiyat
    priority: str  # "high", "medium", "low"

    class Config:
        json_schema_extra = {
            "example": {
                "total_alerts": 5,
                "critical": 2,
                "medium": 2,
                "low": 1,
                "alerts": [],
                "total_shortage_value": 15000.00,
                "priority": "high"
            }
        }


class TopProductResponse(BaseModel):
    """
    En çok satılan ürün
    """
    product_id: int
    product_name: str
    category: str
    total_sold: int  # Satılan toplam miktar
    total_revenue: float
    profit_margin: float

    class Config:
        json_schema_extra = {
            "example": {
                "product_id": 1,
                "product_name": "Oto Kapısı Kilidi",
                "category": "Kilidi",
                "total_sold": 150,
                "total_revenue": 52500.00,
                "profit_margin": 75.0
            }
        }


class PerformanceResponse(BaseModel):
    """
    İşletme performansı
    """
    period: str
    daily_average_sales: float
    weekly_average_sales: float
    best_selling_product: Optional[TopProductResponse] = None
    top_customers: Optional[List[dict]] = None  # {customer_name, total_spent}
    inventory_turnover: float  # Stok döngüsü (satış / ort.stok)
    profit_margin_average: float

    class Config:
        json_schema_extra = {
            "example": {
                "period": "last_30_days",
                "daily_average_sales": 8333.33,
                "weekly_average_sales": 58333.33,
                "best_selling_product": {
                    "product_id": 1,
                    "product_name": "Oto Kapısı Kilidi"
                },
                "inventory_turnover": 2.5,
                "profit_margin_average": 65.0
            }
        }


class SalesChartData(BaseModel):
    """
    Satış grafiği verisi (zaman serisi)
    """
    date: str  # YYYY-MM-DD format
    sales: float
    revenue: float = 0.0
    transactions: int
    customers: int

    class Config:
        json_schema_extra = {
            "example": {
                "date": "2026-04-28",
                "sales": 15000.00,
                "revenue": 9750.00,
                "transactions": 12,
                "customers": 8
            }
        }


class ChartDataResponse(BaseModel):
    """
    Grafik verileri (zaman serisi)
    """
    chart_type: str  # "sales", "revenue", "transactions"
    period: str
    data: List[SalesChartData]
    total: float

    class Config:
        json_schema_extra = {
            "example": {
                "chart_type": "sales",
                "period": "last_7_days",
                "data": [],
                "total": 105000.00
            }
        }


class DashboardOverviewResponse(BaseModel):
    """
    Dashboard ana özeti (tüm bilgiler)
    """
    stats: DashboardStatsResponse
    critical_alerts: CriticalStockAlertsResponse
    performance: PerformanceResponse
    generated_at: datetime

    class Config:
        json_schema_extra = {
            "example": {
                "stats": {},
                "critical_alerts": {},
                "performance": {},
                "generated_at": "2026-04-28T16:00:00"
            }
        }
