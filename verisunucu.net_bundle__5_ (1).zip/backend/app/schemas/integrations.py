from __future__ import annotations

from datetime import date, datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict


class ErpWebhookCreate(BaseModel):
    name: str
    event_types: List[str] = []
    url: str
    secret_key: Optional[str] = None
    headers_json: Optional[Dict[str, str]] = None
    is_active: bool = True


class ErpWebhookUpdate(BaseModel):
    name: Optional[str] = None
    event_types: Optional[List[str]] = None
    url: Optional[str] = None
    secret_key: Optional[str] = None
    headers_json: Optional[Dict[str, str]] = None
    is_active: Optional[bool] = None


class ErpWebhookOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    name: str
    event_types: List[str]
    url: str
    is_active: bool
    last_triggered_at: Optional[datetime]
    last_http_status: Optional[int]
    created_at: Optional[datetime]
    updated_at: Optional[datetime]


class ErpSyncLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    webhook_id: Optional[int]
    event_type: str
    payload_json: Optional[Any]
    http_status_code: Optional[int]
    response_body: Optional[str]
    duration_ms: Optional[int]
    success: bool
    created_at: Optional[datetime]


class PaymentGatewayCreate(BaseModel):
    name: str
    provider: str = "manual"
    is_active: bool = True
    test_mode: bool = True
    commission_rate: float = 0.0
    config_json: Optional[Dict[str, Any]] = None


class PaymentGatewayUpdate(BaseModel):
    name: Optional[str] = None
    provider: Optional[str] = None
    is_active: Optional[bool] = None
    test_mode: Optional[bool] = None
    commission_rate: Optional[float] = None
    config_json: Optional[Dict[str, Any]] = None


class PaymentGatewayOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    name: str
    provider: str
    is_active: bool
    test_mode: bool
    commission_rate: float
    created_at: Optional[datetime]
    updated_at: Optional[datetime]


class PosTransactionCreate(BaseModel):
    btb_order_id: Optional[int] = None
    gateway_id: Optional[int] = None
    transaction_ref: Optional[str] = None
    amount: float
    currency: str = "TRY"
    commission_rate: float = 0.0
    is_commission_reflected: bool = False
    installments: int = 1
    card_last4: Optional[str] = None
    card_bank: Optional[str] = None
    status: str = "success"
    notes: Optional[str] = None


class PosTransactionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    btb_order_id: Optional[int]
    gateway_id: Optional[int]
    transaction_ref: Optional[str]
    amount: float
    currency: str
    commission_rate: float
    commission_amount: float
    is_commission_reflected: bool
    installments: int
    card_last4: Optional[str]
    card_bank: Optional[str]
    status: str
    notes: Optional[str]
    created_at: Optional[datetime]


class DbsAgreementCreate(BaseModel):
    bank_code: str
    bank_name: str
    agreement_ref: Optional[str] = None
    credit_limit: float = 0.0
    currency: str = "TRY"
    is_active: bool = True
    notes: Optional[str] = None


class DbsAgreementUpdate(BaseModel):
    bank_code: Optional[str] = None
    bank_name: Optional[str] = None
    agreement_ref: Optional[str] = None
    credit_limit: Optional[float] = None
    currency: Optional[str] = None
    is_active: Optional[bool] = None
    notes: Optional[str] = None


class DbsAgreementOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    bank_code: str
    bank_name: str
    agreement_ref: Optional[str]
    credit_limit: float
    currency: str
    is_active: bool
    notes: Optional[str]
    created_at: Optional[datetime]
    updated_at: Optional[datetime]
    invoice_count: int = 0
    pending_amount: float = 0.0


class DbsInvoiceCreate(BaseModel):
    agreement_id: Optional[int] = None
    btb_order_id: Optional[int] = None
    btb_customer_id: Optional[int] = None
    customer_name: str
    invoice_no: str
    amount: float
    currency: str = "TRY"
    due_date: date
    notes: Optional[str] = None


class DbsInvoiceUpdate(BaseModel):
    status: Optional[str] = None
    notes: Optional[str] = None
    failure_reason: Optional[str] = None


class DbsInvoiceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    agreement_id: Optional[int]
    btb_order_id: Optional[int]
    btb_customer_id: Optional[int]
    customer_name: str
    invoice_no: str
    amount: float
    currency: str
    due_date: date
    status: str
    sent_at: Optional[datetime]
    collected_at: Optional[datetime]
    failure_reason: Optional[str]
    notes: Optional[str]
    created_at: Optional[datetime]
    updated_at: Optional[datetime]


class IntegrationStatsOut(BaseModel):
    webhook_count: int
    active_webhooks: int
    pos_gateway_count: int
    total_pos_volume: float
    dbs_agreement_count: int
    dbs_pending_amount: float
    erp_logs_today: int
