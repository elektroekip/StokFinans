from __future__ import annotations

from datetime import date, datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict


class VisitCreate(BaseModel):
    btb_customer_id: Optional[int] = None
    customer_name: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    address_label: Optional[str] = None
    notes: Optional[str] = None
    result: str = "visited"
    btb_order_id: Optional[int] = None


class CheckOutUpdate(BaseModel):
    check_out_at: Optional[datetime] = None
    duration_minutes: Optional[int] = None
    notes: Optional[str] = None
    result: str = "visited"


class VisitOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    btb_customer_id: Optional[int]
    customer_name: str
    latitude: Optional[float]
    longitude: Optional[float]
    address_label: Optional[str]
    check_in_at: Optional[datetime]
    check_out_at: Optional[datetime]
    duration_minutes: Optional[int]
    notes: Optional[str]
    result: str
    btb_order_id: Optional[int]
    created_at: Optional[datetime]


class VisitPlanCreate(BaseModel):
    btb_customer_id: Optional[int] = None
    customer_name: str
    planned_date: date
    planned_order: int = 1
    notes: Optional[str] = None


class VisitPlanUpdate(BaseModel):
    btb_customer_id: Optional[int] = None
    customer_name: Optional[str] = None
    planned_date: Optional[date] = None
    planned_order: Optional[int] = None
    notes: Optional[str] = None
    status: Optional[str] = None


class VisitPlanOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    btb_customer_id: Optional[int]
    customer_name: str
    planned_date: date
    planned_order: int
    notes: Optional[str]
    status: str
    created_at: Optional[datetime]
    updated_at: Optional[datetime]


class PlasiyerStatsOut(BaseModel):
    total_visits_today: int
    total_visits_this_month: int
    planned_today: int
    done_today: int
    orders_taken_this_month: int
