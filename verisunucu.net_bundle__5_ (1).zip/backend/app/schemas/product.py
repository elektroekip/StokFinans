# ============================================================
# Product Schemas - Ürün API Validation Modelleri
# ============================================================
# Pydantic modelleri: API istekleri ve cevaplarında veri
# doğrulama ve serileştirme (JSON <-> Python)
#
# Seviye: SEVIYE 4 - Motor Odası
# Tarih: 28 Nisan 2026
# ============================================================

from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

# ============================================================
# REQUEST MODELLERI (Frontend'den gelen veri)
# ============================================================

class ProductCreateRequest(BaseModel):
    """
    Yeni ürün oluştur isteği

    Alanlar:
    - name: Ürün adı (örn: "Oto Kapısı Kilidi")
    - category: Kategori (örn: "Kilidi", "Aydınlatma", "Aksesuar")
    - subcategory: Marka / Tür / Etiket — kullanıcı tanımlı (opsiyonel)
    - barcode: Barkod (opsiyonel, stok takibi için)
    - price: Satış fiyatı
    - cost: Maliyeti
    - currency: Para birimi (TRY/USD/EUR), varsayılan TRY
    - quantity: Mevcut stok miktarı
    - min_stock_alert: Stok uyarısı seviyesi
    """
    name: str = Field(..., min_length=1, max_length=255, description="Ürün adı")
    category: str = Field(..., min_length=1, max_length=100, description="Kategori")
    subcategory: Optional[str] = Field(None, max_length=100, description="Marka/Tür/Etiket")
    barcode: Optional[str] = Field(None, max_length=50, description="Barkod (opsiyonel)")
    price: float = Field(..., gt=0, description="Satış fiyatı")
    cost: Optional[float] = Field(None, ge=0, description="Maliyeti (opsiyonel; girilmezse 0 olarak kaydedilir)")
    cost_currency: str = Field(default="TRY", pattern="^(TRY|USD|EUR)$", description="Alış para birimi")
    currency: str = Field(default="TRY", pattern="^(TRY|USD|EUR)$", description="Satış para birimi")
    quantity: int = Field(default=0, ge=0, description="Stok miktarı")
    min_stock_alert: int = Field(default=10, ge=0, description="Kritik stok seviyesi")
    extra_categories: List[str] = Field(default_factory=list, description="Ek kategoriler (multi-tag)")

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Oto Kapısı Kilidi",
                "category": "Kilidi",
                "barcode": "123456789",
                "price": 350.00,
                "cost": 200.00,
                "quantity": 50,
                "min_stock_alert": 10
            }
        }


class ProductUpdateRequest(BaseModel):
    """
    Ürün güncelle isteği (Kısmi güncellemeler)

    Tüm alanlar opsiyonel - sadece güncellemek istediğiniz
    alanları gönderin
    """
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    category: Optional[str] = Field(None, min_length=1, max_length=100)
    subcategory: Optional[str] = Field(None, max_length=100)
    barcode: Optional[str] = Field(None, max_length=50)
    price: Optional[float] = Field(None, gt=0)
    cost: Optional[float] = Field(None, gt=0)
    cost_currency: Optional[str] = Field(None, pattern="^(TRY|USD|EUR)$")
    currency: Optional[str] = Field(None, pattern="^(TRY|USD|EUR)$")
    quantity: Optional[int] = Field(None, ge=0)
    min_stock_alert: Optional[int] = Field(None, ge=0)
    extra_categories: Optional[List[str]] = Field(None, description="Ek kategoriler (multi-tag)")

    class Config:
        json_schema_extra = {
            "example": {
                "price": 380.00,
                "quantity": 45
            }
        }


# ============================================================
# RESPONSE MODELLERI (Backend'den dönen veri)
# ============================================================

class ProductResponse(BaseModel):
    """
    Tek ürün cevabı (GET /api/v1/products/{id})

    Dönen alanlar:
    - id: Ürün ID
    - name: Ürün adı
    - category: Kategori
    - barcode: Barkod
    - price: Satış fiyatı
    - cost: Maliyeti
    - quantity: Mevcut stok
    - min_stock_alert: Kritik stok seviyesi
    - profit_margin: Kar marjı (%)
    - is_critical_stock: Stok kritik mi?
    - created_at: Oluşturulan tarih
    - updated_at: Güncellendiği tarih
    """
    id: int
    name: str
    category: str
    subcategory: Optional[str] = None
    barcode: Optional[str]
    price: float
    cost: float
    cost_currency: str = "TRY"
    currency: str = "TRY"
    quantity: int
    min_stock_alert: int
    extra_categories: List[str] = Field(default_factory=list)
    image_url: Optional[str] = None
    profit_margin: Optional[float] = None  # (price - cost) / cost * 100
    is_critical_stock: bool = False  # quantity <= min_stock_alert
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True  # SQLAlchemy model'den okuma
        json_schema_extra = {
            "example": {
                "id": 1,
                "name": "Oto Kapısı Kilidi",
                "category": "Kilidi",
                "barcode": "123456789",
                "price": 350.00,
                "cost": 200.00,
                "quantity": 50,
                "min_stock_alert": 10,
                "profit_margin": 75.0,
                "is_critical_stock": False,
                "created_at": "2026-04-28T10:00:00",
                "updated_at": "2026-04-28T10:00:00"
            }
        }


class ProductListResponse(BaseModel):
    """
    Ürün listesi cevabı (GET /api/v1/products)

    Pagination desteği:
    - items: Ürün listesi
    - total: Toplam ürün sayısı
    - page: Mevcut sayfa (1'den başlayan)
    - page_size: Sayfa başına öğe sayısı
    - total_pages: Toplam sayfa sayısı
    - search: Kullanılan arama terimi
    - category: Filtre kategorisi
    """
    items: List[ProductResponse]
    total: int
    page: int
    page_size: int
    total_pages: int
    search: Optional[str] = None
    category: Optional[str] = None

    class Config:
        json_schema_extra = {
            "example": {
                "items": [
                    {
                        "id": 1,
                        "name": "Oto Kapısı Kilidi",
                        "category": "Kilidi",
                        "price": 350.00,
                        "quantity": 50,
                        "is_critical_stock": False
                    }
                ],
                "total": 150,
                "page": 1,
                "page_size": 10,
                "total_pages": 15
            }
        }


class ProductStockResponse(BaseModel):
    """
    Stok durumu cevabı (GET /api/v1/products/stock/critical)

    Kritik stok (quantity <= min_stock_alert) listesi
    """
    id: int
    name: str
    category: str
    quantity: int
    min_stock_alert: int
    shortage: int  # min_stock_alert - quantity
    reorder_quantity: int = 0  # Önerilen sipariş miktarı

    class Config:
        from_attributes = True


class CriticalStockListResponse(BaseModel):
    """
    Kritik stok listesi cevabı
    """
    items: List[ProductStockResponse]
    total: int
    severity: str  # "low" (10-30% eksik), "medium" (30-60%), "critical" (60%+)

    class Config:
        json_schema_extra = {
            "example": {
                "items": [
                    {
                        "id": 5,
                        "name": "Aydınlatma Seti",
                        "category": "Aydınlatma",
                        "quantity": 2,
                        "min_stock_alert": 15,
                        "shortage": 13,
                        "reorder_quantity": 30
                    }
                ],
                "total": 3,
                "severity": "critical"
            }
        }


class ProductCreateResponse(BaseModel):
    """
    Ürün oluşturma cevabı (POST /api/v1/products)
    """
    message: str = "Ürün başarıyla oluşturuldu"
    product: ProductResponse

    class Config:
        json_schema_extra = {
            "example": {
                "message": "Ürün başarıyla oluşturuldu",
                "product": {
                    "id": 1,
                    "name": "Oto Kapısı Kilidi",
                    "category": "Kilidi",
                    "price": 350.00,
                    "quantity": 50
                }
            }
        }


class ProductUpdateResponse(BaseModel):
    """
    Ürün güncelleme cevabı (PUT /api/v1/products/{id})
    """
    message: str = "Ürün başarıyla güncellendi"
    product: ProductResponse

    class Config:
        json_schema_extra = {
            "example": {
                "message": "Ürün başarıyla güncellendi",
                "product": {
                    "id": 1,
                    "name": "Oto Kapısı Kilidi (Güncellenmiş)",
                    "price": 380.00
                }
            }
        }


class ProductDeleteResponse(BaseModel):
    """
    Ürün silme cevabı (DELETE /api/v1/products/{id})
    """
    message: str = "Ürün başarıyla silindi"
    product_id: int
    product_name: str

    class Config:
        json_schema_extra = {
            "example": {
                "message": "Ürün başarıyla silindi",
                "product_id": 1,
                "product_name": "Oto Kapısı Kilidi"
            }
        }
