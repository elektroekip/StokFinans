from __future__ import annotations
from datetime import date, datetime
from typing import List, Optional
from pydantic import BaseModel, Field


# ── Supplier (Tedarikçi) ──────────────────────────────────────

class SupplierCreate(BaseModel):
    company_name: str = Field(..., min_length=1, max_length=255)
    contact_person: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    vkn: Optional[str] = None
    tax_office: Optional[str] = None
    address: Optional[str] = None
    notes: Optional[str] = None
    payment_term_days: int = 30
    is_active: bool = True


class SupplierUpdate(BaseModel):
    company_name: Optional[str] = Field(None, min_length=1, max_length=255)
    contact_person: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    vkn: Optional[str] = None
    tax_office: Optional[str] = None
    address: Optional[str] = None
    notes: Optional[str] = None
    payment_term_days: Optional[int] = None
    is_active: Optional[bool] = None


class SupplierOut(BaseModel):
    id: int
    company_name: str
    contact_person: Optional[str]
    phone: Optional[str]
    email: Optional[str]
    vkn: Optional[str]
    tax_office: Optional[str]
    address: Optional[str]
    notes: Optional[str]
    payment_term_days: int
    is_active: bool
    created_at: Optional[datetime]
    updated_at: Optional[datetime]
    # Computed
    order_count: int = 0
    total_payable: float = 0.0   # ödenmemiş alım borcu

    class Config:
        from_attributes = True


# ── Purchase Order Item ───────────────────────────────────────

class PurchaseItemCreate(BaseModel):
    product_id: Optional[int] = None
    product_name: str = Field(..., min_length=1, max_length=255)
    unit_price: float = Field(..., ge=0)
    currency: str = "TRY"
    quantity: int = Field(..., ge=1)
    kdv_rate: float = Field(0, ge=0, le=100)


class PurchaseItemOut(BaseModel):
    id: int
    product_id: Optional[int]
    product_name: str
    unit_price: float
    currency: str
    quantity: int
    kdv_rate: float
    line_total: float

    class Config:
        from_attributes = True


# ── Purchase Order ────────────────────────────────────────────

class PurchaseOrderCreate(BaseModel):
    supplier_id: int
    notes: Optional[str] = None
    expected_date: Optional[date] = None
    currency: str = "TRY"
    items: List[PurchaseItemCreate] = Field(..., min_length=1)


class PurchaseOrderUpdate(BaseModel):
    supplier_id: Optional[int] = None
    notes: Optional[str] = None
    expected_date: Optional[date] = None
    currency: Optional[str] = None
    items: Optional[List[PurchaseItemCreate]] = None


class PurchaseOrderOut(BaseModel):
    id: int
    supplier_id: int
    supplier_name: str = ""
    order_number: str
    status: str
    notes: Optional[str]
    expected_date: Optional[date]
    subtotal: float = 0
    kdv_amount: float = 0
    total_amount: float
    currency: str
    transaction_id: Optional[int]
    is_paid: bool = False
    paid_at: Optional[datetime] = None
    created_at: Optional[datetime]
    updated_at: Optional[datetime]
    items: List[PurchaseItemOut] = []

    class Config:
        from_attributes = True


# ── Stats ─────────────────────────────────────────────────────

class SupplierStatsOut(BaseModel):
    active_purchases: int
    total_payable: float
    supplier_count: int
    received_this_month: int
