# ============================================================
# Transaction Schemas - İşlem API Validation Modelleri
# ============================================================
# Pydantic modelleri: Satış, Borç ve Ödemeler yönetimi
#
# Seviye: SEVIYE 4 - Motor Odası
# Tarih: 28 Nisan 2026
# ============================================================

from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

# ============================================================
# REQUEST MODELLERI
# ============================================================

class TransactionCreateRequest(BaseModel):
    """
    Yeni işlem (satış/borç/ödeme) oluştur isteği

    Alanlar:
    - transaction_type: "satış" (sale), "borç" (debt), "ödeme" (payment)
    - customer_name: Müşteri adı
    - amount: İşlem tutarı (₺)
    - products: Satılan ürünler (satış için)
    - notes: Ek açıklama
    """
    transaction_type: str = Field(..., description="satış, borç, ödeme")
    customer_name: str = Field(..., min_length=1, max_length=255)
    amount: float = Field(..., ge=0, description="İşlem tutarı KDV DAHİL (0 = sadece kişi açılışı)")
    currency: str = Field(default="TRY", pattern="^(TRY|USD|EUR)$", description="Para birimi")
    kdv_rate: float = Field(default=0, ge=0, le=100, description="KDV oranı yüzde (0-100). amount KDV dahildir.")
    products: Optional[List[dict]] = Field(None, description="Satılan ürünler listesi")
    notes: Optional[str] = Field(None, max_length=500)
    vehicle_id: Optional[int] = Field(None, description="Araç satışı — stok araç envanterinden düşer")

    class Config:
        json_schema_extra = {
            "example": {
                "transaction_type": "satış",
                "customer_name": "Mehmet Oto",
                "amount": 2500.00,
                "products": [
                    {"product_id": 1, "quantity": 5}
                ],
                "notes": "Peşin ödeme"
            }
        }


class TransactionUpdateRequest(BaseModel):
    """
    İşlem güncelle isteği (kısmi)
    """
    customer_name: Optional[str] = None
    amount: Optional[float] = Field(None, gt=0)
    currency: Optional[str] = Field(None, pattern="^(TRY|USD|EUR)$")
    kdv_rate: Optional[float] = Field(None, ge=0, le=100)
    notes: Optional[str] = None

    class Config:
        json_schema_extra = {
            "example": {
                "amount": 2600.00,
                "notes": "Güncellenmiş açıklama"
            }
        }


# ============================================================
# RESPONSE MODELLERI
# ============================================================

class ProductInTransaction(BaseModel):
    """
    İşlemdeki ürün bilgileri
    """
    product_id: int
    product_name: str
    quantity: int
    unit_price: float
    total_price: float

    class Config:
        from_attributes = True


class TransactionResponse(BaseModel):
    """
    Tek işlem cevabı

    Alanlar:
    - id: İşlem ID
    - transaction_type: İşlem türü
    - customer_name: Müşteri adı
    - amount: Toplam tutarı
    - products: Satılan ürünler listesi
    - created_at: Oluşturulan tarih
    - notes: Açıklamalar
    """
    id: int
    transaction_type: str
    customer_name: str
    amount: float
    currency: str = "TRY"
    kdv_rate: float = 0
    products: Optional[List[ProductInTransaction]] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    notes: Optional[str] = None
    image_url: Optional[str] = None

    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "id": 1,
                "transaction_type": "satış",
                "customer_name": "Mehmet Oto",
                "amount": 2500.00,
                "products": [
                    {
                        "product_id": 1,
                        "product_name": "Oto Kapısı Kilidi",
                        "quantity": 5,
                        "unit_price": 350.00,
                        "total_price": 1750.00
                    }
                ],
                "created_at": "2026-04-28T10:00:00",
                "notes": "Peşin ödeme"
            }
        }


class TransactionListResponse(BaseModel):
    """
    İşlem listesi cevabı (Pagination desteği)
    """
    items: List[TransactionResponse]
    total: int
    page: int
    page_size: int
    total_pages: int
    total_amount: float  # Listedeki toplam tutarı
    transaction_type_filter: Optional[str] = None

    class Config:
        json_schema_extra = {
            "example": {
                "items": [],
                "total": 50,
                "page": 1,
                "page_size": 10,
                "total_pages": 5,
                "total_amount": 12500.00
            }
        }


class TransactionCreateResponse(BaseModel):
    """
    İşlem oluşturma cevabı
    """
    message: str = "İşlem başarıyla oluşturuldu"
    transaction: TransactionResponse

    class Config:
        json_schema_extra = {
            "example": {
                "message": "İşlem başarıyla oluşturuldu",
                "transaction": {
                    "id": 1,
                    "transaction_type": "satış",
                    "customer_name": "Mehmet Oto",
                    "amount": 2500.00
                }
            }
        }


class BalanceResponse(BaseModel):
    """
    Cari hesap bakiyesi (Müşteri özel)
    """
    customer_name: str
    total_debt: float  # Toplam borç
    total_paid: float  # Toplam ödenen
    balance: float    # net bakiye (debt - paid)
    transaction_count: int
    last_transaction: Optional[datetime] = None

    class Config:
        json_schema_extra = {
            "example": {
                "customer_name": "Mehmet Oto",
                "total_debt": 5000.00,
                "total_paid": 3000.00,
                "balance": 2000.00,
                "transaction_count": 10,
                "last_transaction": "2026-04-28T15:30:00"
            }
        }


class FinancialSummaryResponse(BaseModel):
    """
    Genel finansman özeti
    """
    total_sales: float     # Toplam satış
    total_debt: float      # Toplam borç
    total_paid: float      # Toplam ödenen
    net_balance: float     # Net bakiye
    total_transactions: int
    unique_customers: int
    period: str = "all_time"

    class Config:
        json_schema_extra = {
            "example": {
                "total_sales": 50000.00,
                "total_debt": 15000.00,
                "total_paid": 35000.00,
                "net_balance": -20000.00,
                "total_transactions": 75,
                "unique_customers": 25,
                "period": "all_time"
            }
        }
