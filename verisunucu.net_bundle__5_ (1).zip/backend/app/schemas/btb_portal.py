from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict


# ── Auth ─────────────────────────────────────────────────────────────────────

class PortalRegisterIn(BaseModel):
    email: str
    password: str
    bayi_id: int
    full_name: Optional[str] = None


class PortalLoginIn(BaseModel):
    email: str
    password: str
    bayi_id: int


class PortalTokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    portal_account_id: int
    btb_customer_id: int
    company_name: str
    bayi_id: int
    full_name: Optional[str] = None


# ── Me ───────────────────────────────────────────────────────────────────────

class PortalMeOut(BaseModel):
    portal_account_id: int
    btb_customer_id: int
    email: str
    full_name: Optional[str] = None
    company_name: str
    bayi_id: int
    credit_limit: float
    current_debt: float
    available_credit: float
    discount_rate: float
    category: str
    payment_term_days: int


# ── Products ─────────────────────────────────────────────────────────────────

class PortalProductOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    barcode: Optional[str] = None
    price: float
    currency: str = "TRY"
    quantity: int
    unit: Optional[str] = None
    kdv_rate: float = 0
    image_url: Optional[str] = None
    category_name: Optional[str] = None
    description: Optional[str] = None


# ── Checkout ─────────────────────────────────────────────────────────────────

class PortalOrderItemIn(BaseModel):
    product_id: Optional[int] = None
    product_name: str
    unit_price: float
    quantity: int = 1
    kdv_rate: float = 0
    discount_rate: float = 0


class PortalCheckoutIn(BaseModel):
    items: List[PortalOrderItemIn]
    notes: Optional[str] = None
    due_date: Optional[str] = None       # ISO date string: "2026-06-01"
    shipping_address: Optional[str] = None


# ── Orders ───────────────────────────────────────────────────────────────────

class PortalOrderOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    order_number: str
    status: str
    total_amount: float
    currency: str
    notes: Optional[str] = None
    due_date: Optional[Any] = None
    created_at: Optional[datetime] = None
    items: List[Dict[str, Any]] = []


# ── Account ──────────────────────────────────────────────────────────────────

class PortalAccountOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    btb_customer_id: int
    email: str
    full_name: Optional[str] = None
    company_name: Optional[str] = None
    is_active: bool
    last_login: Optional[datetime] = None
    created_at: Optional[datetime] = None
