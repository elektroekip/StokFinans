from sqlalchemy import Column, String, Integer, DateTime, Text, func
from sqlalchemy.dialects.postgresql import JSONB
from app.core.database import Base


class SyncLog(Base):
    __tablename__ = "sync_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    from_node_name = Column(String(100), nullable=False)
    to_node_name = Column(String(100), nullable=False)
    event_type = Column(String(20), nullable=False)   # push | pull | heartbeat | error
    records_total = Column(Integer, nullable=True)
    duration_ms = Column(Integer, nullable=True)
    error = Column(Text, nullable=True)
    details = Column(JSONB, nullable=True)            # e.g. {"tables": {"users": 5, "products": 3}}
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
