from sqlalchemy import Column, Integer, String, Boolean, DateTime, JSON, func
from app.core.database import Base


class Package(Base):
    __tablename__ = "packages"

    id = Column(Integer, primary_key=True, index=True)
    slug = Column(String(32), unique=True, nullable=False, index=True)
    name = Column(String(100), nullable=False)
    description = Column(String(500), nullable=True)
    price_try = Column(Integer, nullable=False, default=0)
    duration_days = Column(Integer, nullable=False, default=30)
    max_products = Column(Integer, nullable=True)
    max_transactions = Column(Integer, nullable=True)
    max_support_tickets = Column(Integer, nullable=True)
    has_support = Column(Boolean, nullable=False, default=False)
    is_featured = Column(Boolean, nullable=False, default=False)
    is_active = Column(Boolean, nullable=False, default=True)
    sort_order = Column(Integer, nullable=False, default=0)
    features_json = Column(JSON, nullable=False, default=list)
    color_class = Column(String(50), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
