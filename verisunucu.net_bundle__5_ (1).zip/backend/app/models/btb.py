from sqlalchemy import Column, Integer, String, Float, Numeric, Date, Text, Boolean, ForeignKey, DateTime, func
from app.core.database import Base


class BtbCustomer(Base):
    __tablename__ = "btb_customers"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)

    company_name = Column(String(255), nullable=False, index=True)
    contact_person = Column(String(255), nullable=True)
    phone = Column(String(30), nullable=True)
    email = Column(String(255), nullable=True)
    vkn = Column(String(20), nullable=True)
    tax_office = Column(String(255), nullable=True)   # Vergi dairesi
    address = Column(Text, nullable=True)
    notes = Column(Text, nullable=True)

    category = Column(String(1), nullable=False, default="B")  # A / B / C risk sınıfı
    discount_rate = Column(Float, nullable=False, default=0)   # Müşteri bazlı iskonto %
    credit_limit = Column(Float, nullable=False, default=0)
    payment_term_days = Column(Integer, nullable=False, default=30)
    is_active = Column(Boolean, nullable=False, default=True)

    linked_user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class BtbOrder(Base):
    __tablename__ = "btb_orders"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    customer_id = Column(Integer, ForeignKey("btb_customers.id", ondelete="RESTRICT"), nullable=False, index=True)

    order_number = Column(String(30), nullable=False, index=True)
    # draft | confirmed | shipped | delivered | cancelled
    status = Column(String(20), nullable=False, default="draft", index=True)

    notes = Column(Text, nullable=True)
    due_date = Column(Date, nullable=True)
    shipping_address = Column(Text, nullable=True)
    shipping_carrier = Column(String(100), nullable=True)
    tracking_number = Column(String(100), nullable=True)

    # Finansal detaylar
    subtotal = Column(Float, nullable=False, default=0)       # KDV hariç, indirim sonrası
    kdv_amount = Column(Float, nullable=False, default=0)     # Toplam KDV tutarı
    discount_rate = Column(Float, nullable=False, default=0)  # Sipariş bazlı ek iskonto %
    discount_amount = Column(Float, nullable=False, default=0) # İndirim tutarı
    total_amount = Column(Float, nullable=False, default=0)
    currency = Column(String(3), nullable=False, default="TRY")

    # FK to transactions — set when order is confirmed
    transaction_id = Column(Integer, ForeignKey("transactions.id", ondelete="SET NULL"), nullable=True)

    is_paid = Column(Boolean, nullable=False, default=False)
    paid_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class BtbOrderItem(Base):
    __tablename__ = "btb_order_items"

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("btb_orders.id", ondelete="CASCADE"), nullable=False, index=True)

    product_id = Column(Integer, ForeignKey("products.id", ondelete="SET NULL"), nullable=True)
    product_name = Column(String(255), nullable=False)

    unit_price = Column(Float, nullable=False)
    currency = Column(String(3), nullable=False, default="TRY")
    quantity = Column(Integer, nullable=False, default=1)
    discount_rate = Column(Float, nullable=False, default=0)  # Kalem bazlı iskonto %
    kdv_rate = Column(Numeric(5, 2), nullable=False, default=0)
    line_total = Column(Float, nullable=False, default=0)     # KDV dahil satır toplamı


class BtbPayment(Base):
    """Sipariş başına kısmi/tam ödeme kayıtları."""
    __tablename__ = "btb_payments"

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("btb_orders.id", ondelete="CASCADE"), nullable=False, index=True)
    amount = Column(Float, nullable=False)
    # cash | bank | check | card | other
    payment_method = Column(String(30), nullable=False, default="cash")
    notes = Column(Text, nullable=True)
    paid_at = Column(DateTime(timezone=True), server_default=func.now())
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class BtbPriceList(Base):
    """Müşteri kategorisine (A/B/C) göre ürün bazlı özel fiyat/iskonto listesi.
    category='ALL' ise tüm kategorilere uygulanır.
    custom_price set ise birim fiyatı override eder.
    discount_override set ise müşteri bazlı iskontonu override eder.
    """
    __tablename__ = "btb_price_lists"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    category = Column(String(3), nullable=False, default="ALL", index=True)  # A | B | C | ALL
    product_id = Column(Integer, ForeignKey("products.id", ondelete="SET NULL"), nullable=True, index=True)
    product_name = Column(String(255), nullable=False)  # snapshot (ürün silinse korunur)
    custom_price = Column(Float, nullable=True)          # None = mevcut satış fiyatı korunur
    discount_override = Column(Float, nullable=True)     # None = müşteri iskontosunu kullan
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
