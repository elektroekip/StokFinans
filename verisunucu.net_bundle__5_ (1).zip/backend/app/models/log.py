# ============================================================
# ActivityLog Model - Faaliyet Günlüğü Veri Modeli
# ============================================================
# Bu dosya, ActivityLog tablosunun yapısını tanımlar.
# Sistemdeki tüm işlemleri (stok değişikliği, para işlemleri,
# silme vb.) kayıt altına almak için kullanılır.
# ============================================================

from sqlalchemy import Column, Integer, String, DateTime, func, ForeignKey, Text
from app.core.database import Base

class ActivityLog(Base):
    """
    ActivityLog (Faaliyet Günlüğü) Modeli

    Sistem içinde yapılan tüm işlemleri kaydeder. Bu sayede
    kim ne zaman ne yaptığını görebiliriz (audit trail).

    Attributes:
        id: Benzersiz log ID
        user_id: İşlemi yapan kullanıcı ID'si
        user_name: İşlemi yapan kullanıcının adı (hızlı erişim)
        action_type: İşlem türü (product_add, product_edit, transaction_add, vb.)
        entity_type: İşlemi yapılan varlık türü (product, transaction, user, vb.)
        entity_id: İşlemi yapılan varlığın ID'si
        description: İşlemin açıklaması
        details: Detaylı JSON bilgisi (opsiyonel)
        status: İşlem başarılı mı? (success, error)
        ip_address: İşlemi yapan IP adresi
        created_at: İşlem yapıldığı tarih
    """

    __tablename__ = "activity_logs"

    # Temel Alanlar
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=False)

    # Kimin Yaptığı
    user_name = Column(String(255), nullable=False)  # Hızlı sorgu için

    # Ne Yapıldı
    action_type = Column(
        String(100),
        index=True,
        nullable=False
    )  # product_add, product_edit, transaction_add, vb.
    entity_type = Column(
        String(100),
        index=True,
        nullable=False
    )  # product, transaction, user, vb.
    entity_id = Column(Integer, nullable=True)  # Hangi nesneye yapıldı

    # Açıklama
    description = Column(String(500), nullable=False)
    details = Column(Text, nullable=True)  # JSON formatında ayrıntılar

    # İşlem Sonucu
    status = Column(String(20), default="success")  # success, error

    # IP Adresi (Güvenlik için)
    ip_address = Column(String(50), nullable=True)

    # Tarih
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)

    def __repr__(self):
        return f"<ActivityLog(id={self.id}, action={self.action_type}, user={self.user_name})>"

    # ============================================================
    # VERITABANI KURALLARI
    # ============================================================
    # - user_id geçerli bir user olmalı
    # - action_type tanımlı bir işlem türü olmalı
    # - created_at sorgulanması hızlı olmalı (indexed)
    # ============================================================

    # ============================================================
    # KULLANIM ÖRNEĞİ:
    # ============================================================
    # Ürün eklendiğinde:
    # ActivityLog(
    #   user_id=1,
    #   user_name="Ahmet",
    #   action_type="product_add",
    #   entity_type="product",
    #   entity_id=123,
    #   description="Fiat Tofaş cam rüzgarlığı eklendi",
    #   status="success"
    # )
    #
    # Ürün stoku değiştirildiğinde:
    # ActivityLog(
    #   user_id=1,
    #   user_name="Ahmet",
    #   action_type="stock_update",
    #   entity_type="product",
    #   entity_id=123,
    #   description="Ürün stoku 10 → 5 olarak güncellendi",
    #   details='{"old_stock": 10, "new_stock": 5}',
    #   status="success"
    # )
    #
    # İşlem kaydı yapıldığında:
    # ActivityLog(
    #   user_id=1,
    #   user_name="Ahmet",
    #   action_type="transaction_add",
    #   entity_type="transaction",
    #   entity_id=456,
    #   description="Müşteri Eren'e 5000₺ borç kaydı yapıldı",
    #   status="success"
    # )
    # ============================================================
