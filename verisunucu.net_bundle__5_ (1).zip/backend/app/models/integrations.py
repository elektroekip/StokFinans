from sqlalchemy import Column, Integer, String, Float, Date, Text, Boolean, ForeignKey, DateTime, func
from sqlalchemy.dialects.postgresql import JSONB
from app.core.database import Base


class ErpWebhook(Base):
    __tablename__ = "erp_webhooks"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(100), nullable=False)
    event_types = Column(JSONB, nullable=False, default=list)
    url = Column(String(500), nullable=False)
    secret_key = Column(String(255), nullable=True)
    headers_json = Column(JSONB, nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)
    last_triggered_at = Column(DateTime(timezone=True), nullable=True)
    last_http_status = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class ErpSyncLog(Base):
    __tablename__ = "erp_sync_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    webhook_id = Column(Integer, ForeignKey("erp_webhooks.id", ondelete="SET NULL"), nullable=True, index=True)
    event_type = Column(String(50), nullable=False)
    payload_json = Column(JSONB, nullable=True)
    http_status_code = Column(Integer, nullable=True)
    response_body = Column(Text, nullable=True)
    duration_ms = Column(Integer, nullable=True)
    success = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class PaymentGateway(Base):
    __tablename__ = "payment_gateways"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(100), nullable=False)
    provider = Column(String(30), nullable=False, default="manual")
    is_active = Column(Boolean, nullable=False, default=True)
    test_mode = Column(Boolean, nullable=False, default=True)
    commission_rate = Column(Float, nullable=False, default=0)
    config_json = Column(JSONB, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class PosTransaction(Base):
    __tablename__ = "pos_transactions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    btb_order_id = Column(Integer, ForeignKey("btb_orders.id", ondelete="SET NULL"), nullable=True, index=True)
    gateway_id = Column(Integer, ForeignKey("payment_gateways.id", ondelete="SET NULL"), nullable=True)
    transaction_ref = Column(String(100), nullable=True)
    amount = Column(Float, nullable=False)
    currency = Column(String(3), nullable=False, default="TRY")
    commission_rate = Column(Float, nullable=False, default=0)
    commission_amount = Column(Float, nullable=False, default=0)
    is_commission_reflected = Column(Boolean, nullable=False, default=False)
    installments = Column(Integer, nullable=False, default=1)
    card_last4 = Column(String(4), nullable=True)
    card_bank = Column(String(100), nullable=True)
    status = Column(String(20), nullable=False, default="success")
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class DbsAgreement(Base):
    __tablename__ = "dbs_agreements"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    bank_code = Column(String(10), nullable=False)
    bank_name = Column(String(100), nullable=False)
    agreement_ref = Column(String(100), nullable=True)
    credit_limit = Column(Float, nullable=False, default=0)
    currency = Column(String(3), nullable=False, default="TRY")
    is_active = Column(Boolean, nullable=False, default=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class DbsInvoice(Base):
    __tablename__ = "dbs_invoices"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    agreement_id = Column(Integer, ForeignKey("dbs_agreements.id", ondelete="SET NULL"), nullable=True, index=True)
    btb_order_id = Column(Integer, ForeignKey("btb_orders.id", ondelete="SET NULL"), nullable=True)
    btb_customer_id = Column(Integer, ForeignKey("btb_customers.id", ondelete="SET NULL"), nullable=True, index=True)
    customer_name = Column(String(255), nullable=False)
    invoice_no = Column(String(50), nullable=False)
    amount = Column(Float, nullable=False)
    currency = Column(String(3), nullable=False, default="TRY")
    due_date = Column(Date, nullable=False)
    status = Column(String(20), nullable=False, default="pending")
    sent_at = Column(DateTime(timezone=True), nullable=True)
    collected_at = Column(DateTime(timezone=True), nullable=True)
    failure_reason = Column(String(500), nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
