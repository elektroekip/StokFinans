"""
EmployeeInvite Modeli — Patron tarafından çalışana çıkarılan davet kaydı.

Workflow:
1. Patron `POST /auth/employees` → bu tabloya satır eklenir (henüz User yok).
2. Çalışan `POST /auth/register` (role=calisan) → backend bu tabloda email'i arar:
   - Yoksa "Bu e-posta için herhangi bir firma sizi personel olarak eklemedi" hatası.
   - Varsa User yaratılır, parent_user_id + permissions kopyalanır,
     bu kayıt is_consumed=True olur ve consumed_user_id atanır.
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Index
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.sql import func
from app.core.database import Base


class EmployeeInvite(Base):
    __tablename__ = "employee_invites"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    full_name = Column(String(255), nullable=False)
    parent_user_id = Column(
        Integer,
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    # ["dashboard","products","finance","reports","categories"] gibi izin slug listesi
    permissions = Column(JSONB, nullable=False, server_default="[]")
    is_consumed = Column(Boolean, nullable=False, default=False, index=True)

    consumed_user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    consumed_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    __table_args__ = (
        Index("ix_employee_invites_parent_consumed", "parent_user_id", "is_consumed"),
    )

    def __repr__(self):
        return f"<EmployeeInvite id={self.id} email={self.email} parent={self.parent_user_id} consumed={self.is_consumed}>"
