import uuid
from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from app.core.database import Base


class UserSession(Base):
    __tablename__ = "user_sessions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)

    # Refresh token identity — rotated on every use
    refresh_jti = Column(String(64), unique=True, nullable=False, index=True)

    # Family groups tokens from the same login; entire family revoked on reuse
    family_id = Column(String(36), nullable=False, index=True)

    # Most-recently-issued access token from this session (revoked on logout/reuse)
    access_jti = Column(String(64), nullable=True)

    ip_address = Column(String(45), nullable=True)
    user_agent = Column(String(512), nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    last_used_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    expires_at = Column(DateTime, nullable=False)

    is_revoked = Column(Boolean, default=False, nullable=False, index=True)
    revoked_at = Column(DateTime, nullable=True)
    # 'logout' | 'reuse_detected' | 'password_change' | 'admin'
    revoked_reason = Column(String(32), nullable=True)
