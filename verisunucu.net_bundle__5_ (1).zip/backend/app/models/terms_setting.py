from sqlalchemy import Column, Integer, String, Boolean, DateTime, func, Text
from app.core.database import Base


class TermsSetting(Base):
    __tablename__ = "terms_settings"

    id = Column(Integer, primary_key=True, index=True)
    is_enabled = Column(Boolean, nullable=False, default=False)
    content = Column(Text, nullable=True, default="")
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
