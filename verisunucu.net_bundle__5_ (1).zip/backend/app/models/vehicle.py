from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text, Float
from sqlalchemy.sql import func
from app.core.database import Base


class Vehicle(Base):
    __tablename__ = "vehicles"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)

    plate = Column(String(20), nullable=False)
    nickname = Column(String(100), nullable=True)

    # Legacy columns — kept for schema compat, superseded by vehicle_assignments
    assigned_employee_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    assigned_employee_name = Column(String(255), nullable=True)

    status = Column(String(20), nullable=False, default="parked")  # parked / on_tour

    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class VehicleItem(Base):
    __tablename__ = "vehicle_items"

    id = Column(Integer, primary_key=True, index=True)
    vehicle_id = Column(Integer, ForeignKey("vehicles.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"), nullable=False, index=True)
    product_name = Column(String(255), nullable=False)
    unit_price = Column(Float, nullable=False, default=0.0)
    currency = Column(String(3), nullable=False, default="TRY")
    quantity = Column(Integer, nullable=False, default=0)
    loaded_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class VehicleAssignment(Base):
    """Araç–çalışan ataması. Bir araca birden fazla çalışan farklı rollerle atanabilir."""
    __tablename__ = "vehicle_assignments"

    id = Column(Integer, primary_key=True, index=True)
    vehicle_id = Column(Integer, ForeignKey("vehicles.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    user_name = Column(String(255), nullable=False)
    # driver / helper / warehouse
    role = Column(String(32), nullable=False, default="driver")
    assigned_at = Column(DateTime(timezone=True), server_default=func.now())
    assigned_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)


class VehicleLog(Base):
    """Araç başına tarihli aktivite logu."""
    __tablename__ = "vehicle_logs"

    id = Column(Integer, primary_key=True, index=True)
    vehicle_id = Column(Integer, ForeignKey("vehicles.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    user_name = Column(String(255), nullable=False)
    action = Column(String(64), nullable=False)
    details = Column(Text, nullable=True)
    vehicle_status = Column(String(20), nullable=True)  # status at time of action
    created_at = Column(DateTime(timezone=True), server_default=func.now())
