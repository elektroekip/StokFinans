from sqlalchemy import Column, Integer, String, Boolean, DateTime, func
from app.core.database import Base


class PaytrSetting(Base):
    __tablename__ = "paytr_settings"

    id = Column(Integer, primary_key=True, index=True)
    merchant_id = Column(String(64), nullable=True)
    merchant_key = Column(String(128), nullable=True)
    merchant_salt = Column(String(128), nullable=True)
    test_mode = Column(Boolean, nullable=False, default=True)
    callback_url = Column(String(500), nullable=True)
    success_url = Column(String(500), nullable=True)
    fail_url = Column(String(500), nullable=True)
    is_configured = Column(Boolean, nullable=False, default=False)
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    updated_by_user_id = Column(Integer, nullable=True)
