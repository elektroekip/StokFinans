from sqlalchemy import Column, String, Integer, BigInteger, ForeignKey, DateTime, func
from sqlalchemy.orm import relationship
from app.core.database import Base


class BayiBackup(Base):
    __tablename__ = "bayi_backups"

    id = Column(String(36), primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    filename = Column(String(255), nullable=False)
    password_encrypted = Column(String(500), nullable=False)
    size_bytes = Column(BigInteger, nullable=False, default=0)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    restored_at = Column(DateTime(timezone=True), nullable=True)

    user = relationship("User", foreign_keys=[user_id])
