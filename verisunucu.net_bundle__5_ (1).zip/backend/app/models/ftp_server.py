from sqlalchemy import Column, String, Integer, Boolean, DateTime, func
from app.core.database import Base


class FtpServer(Base):
    """
    Süperadminin tanımladığı uzak yedek sunucusu (FTP veya SFTP).
    Bayi yedekleri elle bu sunuculara yüklenebilir / indirilebilir.
    """
    __tablename__ = "ftp_servers"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(120), nullable=False)
    type = Column(String(8), nullable=False, default="sftp")  # 'ftp' | 'sftp'
    host = Column(String(255), nullable=False)
    port = Column(Integer, nullable=False, default=22)
    username = Column(String(255), nullable=False)
    password_encrypted = Column(String(500), nullable=False)
    base_path = Column(String(500), nullable=False, default="/")
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
