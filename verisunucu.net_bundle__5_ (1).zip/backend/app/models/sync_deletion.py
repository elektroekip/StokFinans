from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.sql import func
from app.core.database import Base


class SyncDeletion(Base):
    """
    Her hard-delete işleminde kayıt tutulur.
    Delta sync bu tabloyu okuyarak diğer node'lara silme işlemini yayar.
    """
    __tablename__ = "sync_deletions"

    id = Column(Integer, primary_key=True, index=True)
    table_name = Column(String(100), nullable=False, index=True)
    row_id = Column(Integer, nullable=False)
    deleted_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
