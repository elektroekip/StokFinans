from sqlalchemy import Column, Integer, String, DateTime, func, ForeignKey, Index
from app.core.database import Base


class SubscriptionEvent(Base):
    """
    Bir kullanıcının abonelik gün bakiyesinde oluşan her değişikliği kayıt eder.
    Olay türleri (event_type):
      - 'initial'              : kayıt sırasında verilen ilk gün (genellikle 14)
      - 'referral_bonus_received' : kullanıcı referans koduyla geldi, +10 gün aldı
      - 'referral_bonus_given'  : başka biri bu kullanıcının kodu ile geldi, +10 bonus
      - 'admin_adjust'         : süper admin +/- gün ayarladı
      - 'admin_set'            : süper admin tam değere set etti (PATCH /users/{id})
    """

    __tablename__ = "subscription_events"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    event_type = Column(String(50), nullable=False, index=True)
    days_delta = Column(Integer, nullable=False)
    days_before = Column(Integer, nullable=False, default=0)
    days_after = Column(Integer, nullable=False, default=0)
    actor_user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    related_user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    note = Column(String(500), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)

    __table_args__ = (
        Index("ix_subscription_events_user_created", "user_id", "created_at"),
    )
