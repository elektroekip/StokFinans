from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.sql import func
from app.core.database import Base


class Device(Base):
    __tablename__ = "devices"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(String(64), unique=True, nullable=False, index=True)
    device_type = Column(String(16), nullable=False, default="ESP8266")  # ESP8266 / ESP32
    variant = Column(String(32), nullable=False, default="standart")     # standart / ekran / barkod / özel
    api_key = Column(String(64), unique=True, nullable=False, index=True)

    # Pairing
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    is_paired = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)  # admin can deactivate
    paired_at = Column(DateTime(timezone=True), nullable=True)

    # Runtime info (updated by heartbeat)
    firmware_version = Column(String(32), nullable=True)
    ip_address = Column(String(64), nullable=True)
    mac_address = Column(String(64), nullable=True)
    wifi_ssid = Column(String(128), nullable=True)
    wifi_rssi = Column(Integer, nullable=True)
    free_heap = Column(Integer, nullable=True)
    uptime_seconds = Column(Integer, nullable=True)
    last_seen = Column(DateTime(timezone=True), nullable=True)

    # OTA firmware update
    pending_firmware_esp8266 = Column(String(256), nullable=True)   # filename in firmwares/
    pending_firmware_esp32 = Column(String(256), nullable=True)
    pending_firmware_version = Column(String(32), nullable=True)
    firmware_update_requested_at = Column(DateTime(timezone=True), nullable=True)
    ota_attempt_count = Column(Integer, default=0, nullable=False)   # kaç kez indirildi (2+ = sorun)
    ota_last_attempt_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    notes = Column(Text, nullable=True)
