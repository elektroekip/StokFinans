"""
Warranty Model — Bayi tarafından müşteriye verilen ürün garanti belgeleri.

Her kayıt:
  - product_image_url: ürün/garanti belgesinin görseli (uploads üzerinden public).
  - public_token: müşterinin auth olmadan erişip QR ile tarayabileceği rastgele token.
  - duration_days + start_date → end_date (uygulama hesaplar veya direkt verilir).
"""
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, func, Index
from app.core.database import Base


class Warranty(Base):
    __tablename__ = "warranties"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)

    product_name = Column(String(255), nullable=False)
    product_image_url = Column(String(1000), nullable=True)

    customer_name = Column(String(255), nullable=False, index=True)
    customer_phone = Column(String(40), nullable=True)

    duration_label = Column(String(40), nullable=False, default="1 yıl")  # "1 ay", "6 ay", "1 yıl", "Özel"
    duration_days = Column(Integer, nullable=False, default=365)

    start_date = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    end_date = Column(DateTime(timezone=True), nullable=False)

    public_token = Column(String(64), nullable=False, unique=True, index=True)
    notes = Column(String(2000), nullable=True)

    # Public link erişim istatistikleri — müşteri QR'ı/linki açtığında sayaç artar.
    # Süperadmin paneli bu kolonları kullanarak tüm bayilerin garanti görüntülenme
    # istatistiklerini gösterir.
    view_count = Column(Integer, nullable=False, server_default="0", default=0)
    last_viewed_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)


Index("ix_warranties_user_end_date", Warranty.user_id, Warranty.end_date)
