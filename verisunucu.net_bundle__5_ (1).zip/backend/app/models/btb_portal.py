from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime, func
from app.core.database import Base


class BtbPortalAccount(Base):
    __tablename__ = "btb_portal_accounts"

    id = Column(Integer, primary_key=True, index=True)
    btb_customer_id = Column(
        Integer,
        ForeignKey("btb_customers.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
    )
    bayi_user_id = Column(
        Integer,
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    email = Column(String(255), nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(255), nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)
    last_login = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
