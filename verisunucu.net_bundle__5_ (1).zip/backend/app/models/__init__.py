# ============================================================
# Models Package - Tüm Veri Modellerini Barındırır
# ============================================================
# Bu dosya, models klasöründeki tüm modelleri merkezi olarak
# dışa aktarır. Başka dosyalar bundan kolayca import edebilir.
# ============================================================

from app.models.user import User
from app.models.product import Product
from app.models.transaction import Transaction, TransactionType
from app.models.log import ActivityLog
from app.models.category import Category
from app.models.subscription_event import SubscriptionEvent
from app.models.package import Package
from app.models.payment import Payment
from app.models.paytr_setting import PaytrSetting
from app.models.employee_invite import EmployeeInvite
from app.models.smtp_setting import SmtpSetting
from app.models.register_notice import RegisterNotice
from app.models.terms_setting import TermsSetting
from app.models.bayi_backup import BayiBackup
from app.models.ftp_server import FtpServer
from app.models.sync_peer import SyncPeer
from app.models.sync_node import SyncNode
from app.models.sync_log import SyncLog
from app.models.warranty import Warranty
from app.models.debtor_link import DebtorLink
from app.models.support import SupportTicket, SupportMessage
from app.models.site_info import SiteInfo
from app.models.device import Device
from app.models.vehicle import Vehicle, VehicleItem, VehicleAssignment, VehicleLog
from app.models.security import SecurityLog, IpBan
from app.models.revoked_token import RevokedToken
from app.models.user_session import UserSession
from app.models.api_key import ApiKey
from app.models.btb import BtbCustomer, BtbOrder, BtbOrderItem, BtbPayment, BtbPriceList
from app.models.btb_activity import BtbActivityLog
from app.models.supplier import Supplier, PurchaseOrder, PurchaseOrderItem
from app.models.plasiyer import CustomerVisit, VisitPlan
from app.models.integrations import (
    ErpWebhook, ErpSyncLog, PaymentGateway, PosTransaction, DbsAgreement, DbsInvoice
)
from app.models.sync_deletion import SyncDeletion
from app.models.file_location import FileLocation
from app.models.storage import StorageNode, StorageFile, StorageFileReplica, StorageDailyBackup
from app.models.deploy_batch import DeployBatch, DeployBatchItem

__all__ = [
    "User",
    "Product",
    "Transaction",
    "TransactionType",
    "ActivityLog",
    "Category",
    "SubscriptionEvent",
    "Package",
    "Payment",
    "PaytrSetting",
    "EmployeeInvite",
    "SmtpSetting",
    "RegisterNotice",
    "TermsSetting",
    "BayiBackup",
    "FtpServer",
    "SyncPeer",
    "SyncNode",
    "SyncLog",
    "Warranty",
    "DebtorLink",
    "SupportTicket",
    "SupportMessage",
    "SiteInfo",
    "Device",
    "Vehicle",
    "VehicleItem",
    "VehicleAssignment",
    "VehicleLog",
    "SecurityLog",
    "IpBan",
    "RevokedToken",
    "UserSession",
    "ApiKey",
    "BtbCustomer",
    "BtbOrder",
    "BtbOrderItem",
    "BtbPayment",
    "BtbPriceList",
    "BtbActivityLog",
    "Supplier",
    "PurchaseOrder",
    "PurchaseOrderItem",
    "CustomerVisit",
    "VisitPlan",
    "ErpWebhook",
    "ErpSyncLog",
    "PaymentGateway",
    "PosTransaction",
    "DbsAgreement",
    "DbsInvoice",
    "SyncDeletion",
    "FileLocation",
    "StorageNode",
    "StorageFile",
    "StorageFileReplica",
    "StorageDailyBackup",
    "DeployBatch",
    "DeployBatchItem",
]
