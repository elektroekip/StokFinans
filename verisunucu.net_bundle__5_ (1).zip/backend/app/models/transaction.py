# ============================================================
# Transaction Model - İşlem/Cari Veri Modeli
# ============================================================
# Bu dosya, Transaction (Müşteri/Tedarikçi işlemleri)
# tablosunun yapısını tanımlar. Veresiye, tahsilat, borç
# kayıtlarını tutmak için kullanılır.
# ============================================================

from sqlalchemy import Column, Integer, String, Float, Numeric, DateTime, func, ForeignKey, Enum
from app.core.database import Base
import enum

class TransactionType(str, enum.Enum):
    """İşlem Türleri"""
    DEBT = "debt"  # Borç (Müşteriye satılan ama ödenmedi)
    PAYMENT = "payment"  # Tahsilat (Müşteriden para alındı)
    EXPENSE = "expense"  # Gider (Firma borcu)

class Transaction(Base):
    """
    Transaction (İşlem) Modeli

    Bu model, müşteriler ve tedarikçilerle olan finansal
    işlemleri takip eder. Veresiye, tahsilat, gider vb.

    Attributes:
        id: Benzersiz işlem ID
        user_id: İşlemi kaydeden bayının ID'si
        customer_name: Müşteri/Tedarikçi adı
        customer_phone: İletişim numarası
        customer_vkn: Vergi kimlik numarası (Tedarikçi için)
        transaction_type: İşlem türü (debt, payment, expense)
        amount: İşlem tutarı (TRY)
        description: İşlem açıklaması
        image_url: Belge/fatura görseli (opsiyonel)
        balance: İşlem sonrası bakiye
        created_at: İşlem tarihi
        updated_at: Düzenleme tarihi
    """

    __tablename__ = "transactions"

    # Temel Alanlar
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=False)

    # Cari Bilgileri
    customer_name = Column(String(255), index=True, nullable=False)
    customer_phone = Column(String(20), nullable=True)
    customer_vkn = Column(String(20), nullable=True)

    # İşlem Detayları
    transaction_type = Column(
        String(20),
        index=True,
        nullable=False,
        default="debt"
    )  # debt, payment, expense
    amount = Column(Float, nullable=False)  # Para birimi `currency` kolonunda
    currency = Column(String(3), default="TRY", nullable=False, index=True)  # TRY / USD / EUR
    kdv_rate = Column(Numeric(5, 2), nullable=False, default=0)  # KDV oranı % (0-100)
    description = Column(String(500), nullable=True)  # Kullanıcı notları (notes)

    # Belge ve Görsel
    image_url = Column(String(1000), nullable=True)  # Fatura/makbuz görseli

    # Bakiye Hesaplaması
    balance = Column(Float, default=0.0)  # O anda kümülatif bakiye

    # Araç satışı (vehicle_id set ise stok araç envanterinden düşer)
    vehicle_id = Column(Integer, ForeignKey("vehicles.id"), nullable=True)

    # Tarih Bilgileri
    transaction_date = Column(DateTime(timezone=True), server_default=func.now())
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    def __repr__(self):
        return f"<Transaction(id={self.id}, type={self.transaction_type}, amount={self.amount})>"

    # ============================================================
    # VERITABANI KURALLARI
    # ============================================================
    # - amount > 0 (negatif işlem olamaz)
    # - transaction_type enum içinde olmalı
    # - user_id geçerli bir user olmalı
    # - Aynı müşterinin birden fazla işlemi olabilir
    # ============================================================

    # ============================================================
    # KULLANIM ÖRNEĞİ:
    # ============================================================
    # Müşteri Ahmet 5000₺ borç verirse:
    # Transaction(
    #   user_id=1,
    #   customer_name="Ahmet",
    #   transaction_type="debt",
    #   amount=5000,
    #   description="Cam Rüzgarlığı satışı"
    # )
    #
    # Müşteri Ahmet 2000₺ öderse:
    # Transaction(
    #   user_id=1,
    #   customer_name="Ahmet",
    #   transaction_type="payment",
    #   amount=2000,
    #   description="Nakit ödeme"
    # )
    #
    # Sonuç: Ahmet'in bakiyesi 5000 - 2000 = 3000₺ borç
    # ============================================================
