from sqlalchemy import Column, Integer, String, Boolean, DateTime, func
from app.core.database import Base


class SmtpSetting(Base):
    __tablename__ = "smtp_settings"

    id = Column(Integer, primary_key=True, index=True)
    host = Column(String(255), nullable=True)
    port = Column(Integer, nullable=False, default=587)
    username = Column(String(255), nullable=True)
    password = Column(String(500), nullable=True)
    from_email = Column(String(255), nullable=True)
    from_name = Column(String(255), nullable=True, default="StokFinans")
    use_tls = Column(Boolean, nullable=False, default=True)
    use_ssl = Column(Boolean, nullable=False, default=False)
    is_configured = Column(Boolean, nullable=False, default=False)
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
