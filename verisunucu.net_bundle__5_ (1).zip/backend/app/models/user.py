# ============================================================
# User Model - Kullanıcı Veri Modeli
# ============================================================
# Bu dosya, User (Kullanıcı) tablosunun yapısını tanımlar.
# SQLAlchemy ORM kullanılarak veritabanındaki users tablosu
# otomatik olarak oluşturulacaktır.
# ============================================================

from sqlalchemy import Column, Integer, String, Boolean, DateTime, func
from sqlalchemy.dialects.postgresql import JSONB
from app.core.database import Base
from datetime import datetime, timezone

class User(Base):
    """
    User (Kullanıcı) Modeli

    Attributes:
        id: Benzersiz kullanıcı ID (Primary Key)
        email: E-posta adresi (benzersiz)
        password_hash: Bcrypt ile hashlenmiş şifre
        full_name: Kullanıcının tam adı
        company_name: İşletme adı (Bayı için)
        role: Kullanıcı rolü (bayi_sahibi, calisan)
        ref_code: Referans kodu (Bayılar için)
        sub_days: Kalan abonelik günleri
        ip_address: Kaydolurken kullanılan IP adresi
        is_active: Hesap aktif mi?
        created_at: Oluşturulma tarihi
        updated_at: Son güncellenme tarihi
    """

    __tablename__ = "users"

    # Temel Alanlar
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)

    # Kişisel Bilgiler
    full_name = Column(String(255), nullable=False)
    company_name = Column(String(255), nullable=True)  # Bayılar için
    company_address = Column(String(500), nullable=True)  # İşyeri adresi
    company_phone = Column(String(50), nullable=True)  # İşyeri telefon numarası

    # Rol ve Yetkilendirme
    role = Column(String(50), default="calisan", index=True)  # bayi_sahibi, calisan
    ref_code = Column(String(50), unique=True, nullable=True, index=True)  # Sadece bayılar
    referred_by_user_id = Column(Integer, nullable=True, index=True)  # Hangi kullanıcının kodu ile geldi

    # Çoklu kiracı / Personel ilişkisi
    parent_user_id = Column(Integer, nullable=True, index=True)  # Çalışansa: patron user_id
    permissions = Column(JSONB, nullable=True)  # Çalışan için sayfa izinleri ["dashboard","products",...]

    # Kullanıcı tercihleri
    dashboard_layout = Column(JSONB, nullable=True)  # Ana panel widget düzeni ve renk teması

    # Abonelik Yönetimi
    sub_days = Column(Integer, default=14)  # Geriye dönük uyumluluk; gerçek kalan gün expires_at'tan hesaplanır
    sub_expires_at = Column(DateTime(timezone=True), nullable=True)  # Aboneliğin biteceği an
    package_slug = Column(String(32), nullable=False, default="starter", index=True)  # Aktif paket
    is_active = Column(Boolean, default=True)

    # Süper Yönetici (platform sahibi) — tüm kiracıları görür/yönetir
    is_super_admin = Column(Boolean, default=False, nullable=False, index=True)

    # E-posta doğrulama
    is_email_verified = Column(Boolean, nullable=False, default=True)
    email_verification_token = Column(String(128), nullable=True, index=True)
    token_expires_at = Column(DateTime(timezone=True), nullable=True)
    pending_email = Column(String(255), nullable=True)  # Onay bekleyen yeni e-posta

    # Şifre sıfırlama
    password_reset_token = Column(String(128), nullable=True, index=True)
    password_reset_expires_at = Column(DateTime(timezone=True), nullable=True)

    # IP Adresi (Referral koruma için)
    ip_address = Column(String(50), nullable=True)

    # Tarih Bilgileri
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    def __repr__(self):
        return f"<User(id={self.id}, email={self.email}, role={self.role})>"

    # ============================================================
    # VERITABANI KURALLARI (CONSTRAINTS)
    # ============================================================
    # - Email unique olmalı (aynı email ile iki hesap olamaz)
    # - Ref_code benzersiz (her bayının kendi kodu var)
    # - Sub_days >= 0 olmalı (negatif gün olamaz)
    # ============================================================
