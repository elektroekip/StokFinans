from sqlalchemy import Column, String, Integer, Boolean, DateTime, Text, Float, func
from app.core.database import Base


class SyncNode(Base):
    __tablename__ = "sync_nodes"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, default="Sunucu")
    display_order = Column(Integer, nullable=False, default=1)
    url = Column(String(500), nullable=True)
    our_token = Column(String(128), nullable=False, default="")   # self node: all peers use this; remote nodes: field unused
    peer_token_encrypted = Column(String(500), nullable=True)     # remote nodes: token we send them (encrypted)
    is_self = Column(Boolean, nullable=False, default=False)
    is_active = Column(Boolean, nullable=False, default=True)
    last_heartbeat_at = Column(DateTime(timezone=True), nullable=True)
    last_sync_at = Column(DateTime(timezone=True), nullable=True)   # son başarılı push zamanı
    last_pull_at = Column(DateTime(timezone=True), nullable=True)   # son başarılı pull zamanı
    last_error = Column(Text, nullable=True)
    sys_cpu_count = Column(Integer, nullable=True)
    sys_ram_gb = Column(Float, nullable=True)
    sys_disk_total_gb = Column(Float, nullable=True)
    sys_disk_free_gb = Column(Float, nullable=True)
    sys_os = Column(String(200), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
