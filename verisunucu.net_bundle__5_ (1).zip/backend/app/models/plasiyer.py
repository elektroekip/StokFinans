from sqlalchemy import Column, Integer, String, Float, Date, Text, Boolean, ForeignKey, DateTime, func
from app.core.database import Base


class CustomerVisit(Base):
    __tablename__ = "customer_visits"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    btb_customer_id = Column(Integer, ForeignKey("btb_customers.id", ondelete="SET NULL"), nullable=True, index=True)
    customer_name = Column(String(255), nullable=False)
    latitude = Column(Float, nullable=True)
    longitude = Column(Float, nullable=True)
    address_label = Column(String(500), nullable=True)
    check_in_at = Column(DateTime(timezone=True), server_default=func.now())
    check_out_at = Column(DateTime(timezone=True), nullable=True)
    duration_minutes = Column(Integer, nullable=True)
    notes = Column(Text, nullable=True)
    result = Column(String(30), nullable=False, default="visited")  # visited | no_answer | postponed | order_taken
    btb_order_id = Column(Integer, ForeignKey("btb_orders.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class VisitPlan(Base):
    __tablename__ = "visit_plans"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    btb_customer_id = Column(Integer, ForeignKey("btb_customers.id", ondelete="SET NULL"), nullable=True)
    customer_name = Column(String(255), nullable=False)
    planned_date = Column(Date, nullable=False, index=True)
    planned_order = Column(Integer, nullable=False, default=1)
    notes = Column(Text, nullable=True)
    status = Column(String(20), nullable=False, default="planned")  # planned | done | skipped
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
