# ============================================================
# Category Model - Bayi'ye Özel Kategori (Web Görünüm)
# ============================================================
# Her bayi kendi stok/finans kategorilerini ekler/düzenler/siler.
# Sidebar ve ana paneldeki kısayollar buradan dinamik üretilir.
# ============================================================

from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, UniqueConstraint, func
from app.core.database import Base


class Category(Base):
    """Bayiye özel kategori (Web Görünüm) modeli."""

    __tablename__ = "categories"

    __table_args__ = (
        # Aynı bayide aynı kind içinde aynı key tekrar olmasın
        UniqueConstraint("user_id", "kind", "key", name="uq_categories_user_kind_key"),
    )

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)

    # 'stok' veya 'finans'
    kind = Column(String(20), index=True, nullable=False)

    # URL/route slug — örn: stock_cam, fin_veresiye (bayi başına benzersiz)
    key = Column(String(80), nullable=False)

    # Görünen ad — örn: "Cam Rüzgarlığı"
    name = Column(String(200), nullable=False)

    # Lucide ikon adı — örn: "Wind", "Box", "Building2"
    icon = Column(String(80), default="Package", nullable=False)

    # Tailwind renk sınıfları (frontend kullanır)
    color_class = Column(String(120), default="text-indigo-600 dark:text-indigo-400", nullable=False)
    bg_class = Column(String(120), default="bg-indigo-100 dark:bg-indigo-900/30", nullable=False)

    # Sıralama ve görünürlük
    display_order = Column(Integer, default=100, nullable=False)
    is_visible = Column(Boolean, default=True, nullable=False)

    # Görünüm modu — list / grid / masonry / carousel / category
    # Her bayi her kategori için ayrı bir görünüm tarzı seçebilir.
    view_mode = Column(String(20), default="list", nullable=False)

    # Sistem varsayılanı mı? (silinmesini engellemek için işaretleyebiliriz, ama silinebilir)
    is_default = Column(Boolean, default=False, nullable=False)

    # Finans kategorileri için ek alanlar (stok için NULL kalabilir)
    transaction_type = Column(String(50), nullable=True)   # borç/gider/senet/kredi/garanti vb.
    customer_label = Column(String(120), nullable=True)
    amount_label = Column(String(120), nullable=True)
    amount_tone = Column(String(40), nullable=True)        # red/amber/indigo/purple/slate/emerald
    allow_edit_type = Column(Boolean, default=False, nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    def __repr__(self):
        return f"<Category(id={self.id}, user={self.user_id}, kind={self.kind}, key={self.key})>"
