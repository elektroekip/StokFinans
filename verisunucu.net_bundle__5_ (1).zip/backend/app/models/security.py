from sqlalchemy import Column, Integer, String, Text, DateTime
from datetime import datetime
from app.core.database import Base


class SecurityLog(Base):
    __tablename__ = "security_logs"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    ip_address     = Column(String(45),  nullable=False, index=True)
    event_type     = Column(String(50),  nullable=False, index=True)
    # failed_login | rate_limited | banned_access | suspicious_scan | invalid_token
    email_attempted = Column(String(255), nullable=True)
    # Matched user (if the attempted email / IP maps to a known account)
    user_id        = Column(Integer,     nullable=True)
    user_email     = Column(String(255), nullable=True)
    user_name      = Column(String(255), nullable=True)
    user_role      = Column(String(50),  nullable=True)
    path           = Column(String(500), nullable=True)
    method         = Column(String(10),  nullable=True)
    user_agent     = Column(String(500), nullable=True)
    details        = Column(Text,        nullable=True)
    created_at     = Column(DateTime,    nullable=False, default=datetime.utcnow)


class IpBan(Base):
    __tablename__ = "ip_bans"

    id             = Column(Integer,     primary_key=True, autoincrement=True)
    ip_address     = Column(String(45),  nullable=False, unique=True, index=True)
    reason         = Column(String(500), nullable=True)
    banned_by      = Column(String(255), nullable=True)  # super admin email
    created_at     = Column(DateTime,    nullable=False, default=datetime.utcnow)
    expires_at     = Column(DateTime,    nullable=True)   # None = permanent
