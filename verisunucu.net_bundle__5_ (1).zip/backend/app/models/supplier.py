from sqlalchemy import Column, Integer, String, Float, Numeric, Date, Text, Boolean, ForeignKey, DateTime, func
from app.core.database import Base


class Supplier(Base):
    """Toptancı / Tedarikçi — sizin alım yaptığınız firmalar."""
    __tablename__ = "suppliers"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)

    company_name = Column(String(255), nullable=False, index=True)
    contact_person = Column(String(255), nullable=True)
    phone = Column(String(30), nullable=True)
    email = Column(String(255), nullable=True)
    vkn = Column(String(20), nullable=True)
    tax_office = Column(String(255), nullable=True)
    address = Column(Text, nullable=True)
    notes = Column(Text, nullable=True)

    payment_term_days = Column(Integer, nullable=False, default=30)
    is_active = Column(Boolean, nullable=False, default=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class PurchaseOrder(Base):
    """Satın Alma Siparişi — toptancıdan alınan sipariş."""
    __tablename__ = "purchase_orders"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    supplier_id = Column(Integer, ForeignKey("suppliers.id", ondelete="RESTRICT"), nullable=False, index=True)

    order_number = Column(String(30), nullable=False, index=True)  # SAT-2026-0001
    # draft | ordered | received | cancelled
    status = Column(String(30), nullable=False, default="draft", index=True)

    notes = Column(Text, nullable=True)
    expected_date = Column(Date, nullable=True)

    subtotal = Column(Float, nullable=False, default=0)
    kdv_amount = Column(Float, nullable=False, default=0)
    total_amount = Column(Float, nullable=False, default=0)
    currency = Column(String(3), nullable=False, default="TRY")

    # Mal kabul edildiğinde oluşan gider transaction
    transaction_id = Column(Integer, ForeignKey("transactions.id", ondelete="SET NULL"), nullable=True)

    is_paid = Column(Boolean, nullable=False, default=False)
    paid_at = Column(DateTime(timezone=True), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class PurchaseOrderItem(Base):
    """Satın alma siparişi kalemi."""
    __tablename__ = "purchase_order_items"

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("purchase_orders.id", ondelete="CASCADE"), nullable=False, index=True)

    product_id = Column(Integer, ForeignKey("products.id", ondelete="SET NULL"), nullable=True)
    product_name = Column(String(255), nullable=False)

    unit_price = Column(Float, nullable=False, default=0)
    currency = Column(String(3), nullable=False, default="TRY")
    quantity = Column(Integer, nullable=False, default=1)
    kdv_rate = Column(Numeric(5, 2), nullable=False, default=0)
    line_total = Column(Float, nullable=False, default=0)
