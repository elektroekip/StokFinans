from sqlalchemy import Column, Integer, String, Boolean, DateTime, func
from app.core.database import Base


class RegisterNotice(Base):
    __tablename__ = "register_notices"

    id = Column(Integer, primary_key=True, index=True)
    is_enabled = Column(Boolean, nullable=False, default=False)
    title = Column(String(255), nullable=True, default="Duyuru")
    message = Column(String(2000), nullable=True, default="")
    color = Column(String(32), nullable=False, default="indigo")
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
