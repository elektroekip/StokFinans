from sqlalchemy import Column, String, Integer, Boolean, DateTime, Text, func
from app.core.database import Base


class SyncPeer(Base):
    """
    İki StokFinans kurulumu (node) arasındaki ana↔ayna eşleşmesi.
    Tek satır (id=1) olarak tutulur — her node yalnızca bir peer'a eşleşebilir.

    role:
        'primary'  → bu node ana sunucu, peer ayna
        'mirror'   → bu node ayna, peer ana sunucu

    our_token   : peer bu node'a istek atarken Authorization: Bearer ile gönderir
    peer_token  : bu node peer'a istek atarken kullanır (encrypted at rest)
    """
    __tablename__ = "sync_peer"

    id = Column(Integer, primary_key=True, default=1)
    role = Column(String(16), nullable=False, default="mirror")  # 'primary' | 'mirror'
    peer_url = Column(String(500), nullable=False)               # https://other.example.com
    peer_token_encrypted = Column(String(500), nullable=False)   # Bizim peer'a göndereceğimiz token (Fernet)
    our_token = Column(String(128), nullable=False)              # Peer'in bize gönderirken kullanacağı token (plaintext lookup için)
    last_heartbeat_at = Column(DateTime(timezone=True), nullable=True)   # Son başarılı ping
    last_sync_at = Column(DateTime(timezone=True), nullable=True)        # Son başarılı snapshot pull/push
    last_error = Column(Text, nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
