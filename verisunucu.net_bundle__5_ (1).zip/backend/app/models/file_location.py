from sqlalchemy import Column, Integer, String, BigInteger, DateTime, ForeignKey, func
from app.core.database import Base


class FileLocation(Base):
    """Her yüklenen dosyanın hangi sync node'unda saklandığını tutar.
    node_id=NULL → dosya bu sunucuda yerel.
    node_id=X    → dosya X node'unda, erişim için o node'a proxy yapılmalı.
    """
    __tablename__ = "file_locations"

    id = Column(Integer, primary_key=True, autoincrement=True)
    filename = Column(String(500), nullable=False, unique=True, index=True)
    # Null = yerel sunucu; dolu = dosyanın gerçek sahibi node
    node_id = Column(Integer, ForeignKey("sync_nodes.id", ondelete="SET NULL"), nullable=True)
    file_size_bytes = Column(BigInteger, nullable=False, default=0)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
