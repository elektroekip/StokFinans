import hashlib
import secrets
from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from app.core.database import Base

API_KEY_PREFIX = "sf_"

# Scope → path prefix eşlemesi (check_scope'da kullanılır)
SCOPE_PATH_MAP = [
    # Bayi (tenant) endpoint'leri
    ("/api/v1/products",            "products"),
    ("/api/v1/finance/transactions", "transactions"),
    ("/api/v1/finance",             "finance"),
    ("/api/v1/debts",               "customers"),
    ("/api/v1/warranty",            "warranty"),
    ("/api/v1/categories",          "categories"),
    ("/api/v1/dashboard",           "reports"),
    ("/api/v1/reports",             "reports"),
    ("/api/v1/auth/profile",        "profile"),
    ("/api/v1/devices",             "devices"),
    ("/api/v1/vehicles",            "vehicles"),
    # Süper admin yönetim endpoint'leri
    ("/api/v1/ext/admin",           "admin"),
    ("/api/v1/superadmin",          "admin"),
]

ADMIN_SCOPES = [
    {"key": "admin:overview",    "group": "Yönetim", "label": "Genel Bakış",     "description": "Platform geneli istatistikler (kullanıcı sayısı, ciro, ürün sayısı)"},
    {"key": "admin:users:read",  "group": "Yönetim", "label": "Bayi Listesi",    "description": "Tüm bayi hesapları, abonelik durumu, istatistikler"},
    {"key": "admin:users:write", "group": "Yönetim", "label": "Bayi Yönetimi",   "description": "Abonelik güncelle, hesap aktif/pasif yap"},
    {"key": "admin:data:read",   "group": "Yönetim", "label": "Veri Erişimi",    "description": "Tüm bayilerin ürün, satış ve müşteri verilerini oku"},
    {"key": "admin:full",        "group": "Yönetim", "label": "Tam Yönetim",     "description": "Tüm süper admin yetkilerine API üzerinden erişim"},
]

AVAILABLE_SCOPES = [
    {"key": "products:read",      "group": "Ürünler",       "label": "Okuma",  "description": "Ürün listesi, detay, stok durumu"},
    {"key": "products:write",     "group": "Ürünler",       "label": "Yazma",  "description": "Ürün ekle, güncelle, sil"},
    {"key": "transactions:read",  "group": "Satışlar",      "label": "Okuma",  "description": "Satış ve iade geçmişi"},
    {"key": "transactions:write", "group": "Satışlar",      "label": "Yazma",  "description": "Yeni satış / iade oluştur"},
    {"key": "finance:read",       "group": "Finans",        "label": "Okuma",  "description": "Finansal özet ve raporlar"},
    {"key": "customers:read",     "group": "Müşteriler",    "label": "Okuma",  "description": "Müşteri ve borç listesi"},
    {"key": "customers:write",    "group": "Müşteriler",    "label": "Yazma",  "description": "Borç ekle, güncelle, sil"},
    {"key": "warranty:read",      "group": "Garanti",       "label": "Okuma",  "description": "Garanti kayıtları"},
    {"key": "warranty:write",     "group": "Garanti",       "label": "Yazma",  "description": "Garanti kaydı oluştur / güncelle"},
    {"key": "categories:read",    "group": "Kategoriler",   "label": "Okuma",  "description": "Kategori listesi"},
    {"key": "categories:write",   "group": "Kategoriler",   "label": "Yazma",  "description": "Kategori ekle / sil"},
    {"key": "reports:read",       "group": "Raporlar",      "label": "Okuma",  "description": "Dashboard ve analitik veriler"},
    {"key": "profile:read",       "group": "Profil",        "label": "Okuma",  "description": "Kullanıcı profil bilgileri"},
    {"key": "devices:read",       "group": "Cihazlar",      "label": "Okuma",  "description": "Bağlı cihaz listesi"},
    {"key": "devices:write",      "group": "Cihazlar",      "label": "Yazma",  "description": "Cihaz kayıt / güncelleme"},
    {"key": "vehicles:read",      "group": "Araçlar",       "label": "Okuma",  "description": "Araç ve sefer kayıtları"},
    {"key": "vehicles:write",     "group": "Araçlar",       "label": "Yazma",  "description": "Araç sefer oluştur / güncelle"},
]


def generate_api_key() -> tuple[str, str, str]:
    """(tam_anahtar, görünen_prefix, sha256_hash) döndürür."""
    raw = API_KEY_PREFIX + secrets.token_hex(24)   # sf_ + 48 hex = 51 karakter
    prefix = raw[:12]                               # "sf_" + 9 karakter
    key_hash = hashlib.sha256(raw.encode()).hexdigest()
    return raw, prefix, key_hash


def hash_api_key(key: str) -> str:
    return hashlib.sha256(key.encode()).hexdigest()


def check_scope(method: str, path: str, scopes: list) -> bool:
    """API anahtarının istek için yetki içerip içermediğini kontrol eder."""
    if "full_access" in scopes or "admin:full" in scopes:
        return True

    resource = None
    for prefix, res in SCOPE_PATH_MAP:
        if path.startswith(prefix):
            resource = res
            break

    if resource is None:
        return True  # Haritada olmayan path'ler serbest

    # Yönetim yolu → admin scope'ları
    if resource == "admin":
        if method.upper() == "GET":
            return "admin:overview" in scopes or "admin:users:read" in scopes or "admin:data:read" in scopes
        else:
            return "admin:users:write" in scopes

    read_scope  = resource + ":read"
    write_scope = resource + ":write"

    if method.upper() == "GET":
        return read_scope in scopes or write_scope in scopes
    else:
        return write_scope in scopes


class ApiKey(Base):
    __tablename__ = "api_keys"

    id           = Column(Integer, primary_key=True, index=True)
    key_hash     = Column(String(64), unique=True, nullable=False, index=True)
    key_prefix   = Column(String(16), nullable=False)   # İlk 12 karakter — gösterme amaçlı
    name         = Column(String(100), nullable=False)
    description  = Column(Text, nullable=True)

    # Bu anahtar hangi hesap adına çalışır?
    # Süper admin anahtarlarında user_id = oluşturan admin'in id'si
    user_id      = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    # Kim oluşturdu (süper admin)?
    created_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)

    # True ise kullanıcının is_super_admin = True olması beklenir;
    # tüm tenant izolasyonu bypass edilir, yönetim endpoint'leri açılır
    is_super_admin_key = Column(Boolean, default=False, nullable=False)

    scopes          = Column(JSONB, nullable=False, default=list)
    is_full_access  = Column(Boolean, default=False, nullable=False)
    is_active       = Column(Boolean, default=True,  nullable=False, index=True)

    usage_count  = Column(Integer,  default=0,    nullable=False)
    last_used_at = Column(DateTime, nullable=True)

    created_at   = Column(DateTime, default=datetime.utcnow, nullable=False)
    expires_at   = Column(DateTime, nullable=True)
