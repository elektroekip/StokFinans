from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, func
from app.core.database import Base


class Payment(Base):
    __tablename__ = "payments"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    package_slug = Column(String(32), nullable=False, index=True)
    amount_try = Column(Integer, nullable=False)
    paytr_merchant_oid = Column(String(64), unique=True, nullable=False, index=True)
    paytr_payment_token = Column(String(255), nullable=True)
    status = Column(String(20), nullable=False, default="pending", index=True)
    error_message = Column(String(500), nullable=True)
    days_added = Column(Integer, nullable=True)
    test_mode = Column(Integer, nullable=False, default=0)
    user_ip = Column(String(64), nullable=True)
    callback_received_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    completed_at = Column(DateTime(timezone=True), nullable=True)
