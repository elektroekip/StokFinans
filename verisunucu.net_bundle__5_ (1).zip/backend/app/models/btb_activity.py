from sqlalchemy import Column, Integer, String, Text, ForeignKey, DateTime, func
from app.core.database import Base


class BtbActivityLog(Base):
    __tablename__ = "btb_activity_logs"

    id = Column(Integer, primary_key=True, index=True)
    btb_customer_id = Column(Integer, ForeignKey("btb_customers.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    action = Column(String(100), nullable=False, index=True)
    # login | view_products | checkout | view_orders | view_order_detail
    details = Column(Text, nullable=True)  # JSON string
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
