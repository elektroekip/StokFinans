# ============================================================
# Product Model - Ürün Veri Modeli
# ============================================================
# Bu dosya, Product (Ürün) tablosunun yapısını tanımlar.
# Stok yönetimi sisteminin en önemli modeli.
# ============================================================

from sqlalchemy import Column, Integer, String, Float, DateTime, func, ForeignKey, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from app.core.database import Base

class Product(Base):
    """
    Product (Ürün) Modeli

    Attributes:
        id: Benzersiz ürün ID
        user_id: Ürünü ekleyen bayının ID'si (ownership)
        category: Ürün kategorisi (CAM, KAPUT, PASPAS, vb.)
        name: Ürün adı/modeli
        barcode: Ürün barkod numarası
        buy_price: Alış fiyatı (Bayi'nin ödediği)
        sell_price: Satış fiyatı (Müşteriye satılan)
        stock_amount: Mevcut stok sayısı
        min_stock_alert: Kritik stok seviyesi (uyarı için)
        description: Ürün açıklaması
        created_at: Ürün eklenme tarihi
        updated_at: Son güncellenme tarihi
    """

    __tablename__ = "products"

    # Çoklu kiracılık (multi-tenant): barkod global değil, bayi başına benzersiz olmalı
    __table_args__ = (
        UniqueConstraint("user_id", "barcode", name="uq_products_user_barcode"),
    )

    # Temel Alanlar
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=False)

    # Kategori ve Tanıtım
    category = Column(String(100), index=True, nullable=False)  # CAM, KAPUT, PASPAS, etc.
    subcategory = Column(String(100), index=True, nullable=True)  # Marka / Tür / Etiket (serbest alan)
    extra_categories = Column(JSONB, nullable=False, server_default='[]')  # Ek kategoriler (multi-tag): ['Aksesuar', 'Kampanya']
    name = Column(String(500), index=True, nullable=False)  # Ürün adı/modeli
    barcode = Column(String(100), index=True, nullable=True)  # Bayi-bazlı benzersiz (yukarıdaki UniqueConstraint)

    # Fiyatlandırma
    cost = Column(Float, default=0.0)  # Alış fiyatı
    price = Column(Float, default=0.0)  # Satış fiyatı
    cost_currency = Column(String(3), default="TRY", nullable=False, index=True)  # Alış para birimi (TRY/USD/EUR)
    currency = Column(String(3), default="TRY", nullable=False, index=True)  # Satış para birimi (TRY/USD/EUR)

    # Stok
    quantity = Column(Integer, default=0)  # Mevcut stok
    min_stock_alert = Column(Integer, default=5)  # Uyarı seviyesi

    # Açıklama
    description = Column(String(1000), nullable=True)

    # Ürün görseli (yüklenen fotoğrafın public URL'si)
    image_url = Column(String(1000), nullable=True)

    # Tarih Bilgileri
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    def __repr__(self):
        return f"<Product(id={self.id}, name={self.name}, stock={self.quantity})>"

    @property
    def profit_margin(self) -> float:
        """
        Kar marjını hesapla
        Formül: ((Satış - Alış) / Satış) * 100
        """
        if self.price == 0:
            return 0
        return ((self.price - self.cost) / self.price) * 100

    @property
    def is_critical(self) -> bool:
        """Stok kritik seviyede mi?"""
        return self.quantity <= self.min_stock_alert

    @property
    def is_out_of_stock(self) -> bool:
        """Stok tükendi mi?"""
        return self.quantity == 0

    # ============================================================
    # VERITABANI KURALLARI
    # ============================================================
    # - Barcode unique olmalı (aynı ürün iki kere girilemesin)
    # - stock_amount >= 0 (negatif stok olamaz)
    # - sell_price >= buy_price (zarar satış olmaz)
    # - user_id valid bir user olmalı (foreign key constraint)
    # ============================================================
