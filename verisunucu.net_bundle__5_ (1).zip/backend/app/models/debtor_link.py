"""
DebtorLink — Bayi'nin müşteriye gönderdiği "anlık borç slip" linki.

Müşteri bu linki tarayıcıdan açar, auth gerekmez. Sayfa o anki bakiyeyi,
tüm borç ve ödeme satırlarını gösterir; müşteri yenileyince anlık günceldir.

Süre dolduğunda link 410 (Gone) döner.
"""
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, func, Index
from app.core.database import Base


class DebtorLink(Base):
    __tablename__ = "debtor_links"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)

    customer_name = Column(String(255), nullable=False, index=True)
    public_token = Column(String(64), nullable=False, unique=True, index=True)

    expires_at = Column(DateTime(timezone=True), nullable=True)  # NULL = süresiz
    last_viewed_at = Column(DateTime(timezone=True), nullable=True)
    view_count = Column(Integer, nullable=False, default=0)

    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)


Index("ix_debtor_links_user_customer", DebtorLink.user_id, DebtorLink.customer_name)
