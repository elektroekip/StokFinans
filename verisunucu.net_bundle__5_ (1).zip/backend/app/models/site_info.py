from sqlalchemy import Column, Integer, String, Text, DateTime, func
from app.core.database import Base


class SiteInfo(Base):
    __tablename__ = "site_info"

    id = Column(Integer, primary_key=True, default=1)
    company_name = Column(String(200), nullable=True)
    contact_person = Column(String(200), nullable=True)
    address = Column(Text, nullable=True)
    phone = Column(String(50), nullable=True)
    email = Column(String(200), nullable=True)
    working_hours = Column(String(200), nullable=True)
    about_text = Column(Text, nullable=True)
    instagram_url = Column(String(300), nullable=True)
    whatsapp_number = Column(String(50), nullable=True)
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
