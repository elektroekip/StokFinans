"""
Depolama Havuzu Modelleri

storage_nodes       — MinIO, SFTP, FTP, S3, yerel disk kayıtları
storage_files       — dosya merkezi envanteri (SHA256 + boyut)
storage_file_replicas — hangi dosya hangi düğümde (primary + replica'lar)
storage_daily_backups — günlük yedek kayıtları (20 gün saklama)
"""
from __future__ import annotations

from sqlalchemy import (
    BigInteger, Boolean, Column, DateTime, ForeignKey,
    Integer, String, Text, func,
)
from app.core.database import Base


class StorageNode(Base):
    """
    Depolama havuzundaki bir düğüm.
    Tür: local | minio | sftp | ftp | s3
    """
    __tablename__ = "storage_nodes"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    name         = Column(String(120), nullable=False)
    type         = Column(String(20), nullable=False, default="minio")
    # local → yol yok; minio/s3 → endpoint_url+bucket; sftp/ftp → host+port+user+pass
    host         = Column(String(255), nullable=True)
    port         = Column(Integer, nullable=True)
    username     = Column(String(255), nullable=True)
    password_encrypted   = Column(String(500), nullable=True)
    # MinIO / S3
    access_key           = Column(String(255), nullable=True)
    secret_key_encrypted = Column(String(500), nullable=True)
    bucket               = Column(String(255), nullable=True)
    endpoint_url         = Column(String(500), nullable=True)
    base_path            = Column(String(500), nullable=False, default="/")
    # Disk istatistikleri (güncellenir)
    total_bytes  = Column(BigInteger, nullable=True)
    used_bytes   = Column(BigInteger, nullable=True)
    free_bytes   = Column(BigInteger, nullable=True)
    # Roller
    is_primary         = Column(Boolean, nullable=False, default=False)
    is_master_backup   = Column(Boolean, nullable=False, default=False)
    is_external_backup = Column(Boolean, nullable=False, default=False)  # harici S3 yedek hedefi
    is_active          = Column(Boolean, nullable=False, default=True)
    # Durum
    last_check_at = Column(DateTime(timezone=True), nullable=True)
    last_error    = Column(String(500), nullable=True)
    created_at    = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at    = Column(DateTime(timezone=True), server_default=func.now(),
                           onupdate=func.now(), nullable=False)


class StorageFile(Base):
    """
    Depolama havuzundaki her dosyanın merkezi kaydı.
    Hangi düğümlerde olduğu storage_file_replicas tablosunda tutulur.
    """
    __tablename__ = "storage_files"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    filename      = Column(String(500), nullable=False, index=True)
    storage_key   = Column(String(500), nullable=False, unique=True, index=True)
    size_bytes    = Column(BigInteger, nullable=False, default=0)
    content_type  = Column(String(255), nullable=True)
    checksum_sha256 = Column(String(64), nullable=True)
    user_id       = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    uploaded_at   = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at    = Column(DateTime(timezone=True), server_default=func.now(),
                           onupdate=func.now(), nullable=False)
    deleted_at    = Column(DateTime(timezone=True), nullable=True)  # soft delete


class StorageFileReplica(Base):
    """
    Bir dosyanın belirli bir düğümdeki kopyası.
    is_primary=True → asıl kaynak; False → replika.
    """
    __tablename__ = "storage_file_replicas"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    file_id         = Column(Integer, ForeignKey("storage_files.id", ondelete="CASCADE"),
                             nullable=False, index=True)
    node_id         = Column(Integer, ForeignKey("storage_nodes.id", ondelete="CASCADE"),
                             nullable=False, index=True)
    path_on_node    = Column(String(500), nullable=False)
    is_primary      = Column(Boolean, nullable=False, default=False)
    is_verified     = Column(Boolean, nullable=False, default=False)
    last_verified_at = Column(DateTime(timezone=True), nullable=True)
    created_at      = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)


class StorageDailyBackup(Base):
    """
    Günlük yedek kayıtları.
    expires_at = backup_date + 20 gün; geçilince otomatik silinir.
    status: pending → running → done | failed
    """
    __tablename__ = "storage_daily_backups"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    node_id       = Column(Integer, ForeignKey("storage_nodes.id", ondelete="SET NULL"),
                           nullable=True)
    backup_type   = Column(String(20), nullable=False, default="daily")
    includes_db   = Column(Boolean, nullable=False, default=True)
    includes_files = Column(Boolean, nullable=False, default=True)
    filename      = Column(String(500), nullable=True)
    size_bytes    = Column(BigInteger, nullable=True)
    status        = Column(String(20), nullable=False, default="pending")
    error         = Column(Text, nullable=True)
    backup_date   = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    expires_at    = Column(DateTime(timezone=True), nullable=True)
    completed_at  = Column(DateTime(timezone=True), nullable=True)
    created_at    = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    # Harici S3 yedek durumu
    external_backup_status = Column(String(20), nullable=True)   # pending|running|done|failed
    external_backup_at     = Column(DateTime(timezone=True), nullable=True)
    external_backup_error  = Column(Text, nullable=True)
    # Yedek kapsamı ve DR testi
    backup_scope           = Column(String(20), nullable=False, default="full")  # full|incremental
    dr_tested_at           = Column(DateTime(timezone=True), nullable=True)
    dr_test_result         = Column(String(20), nullable=True)  # ok|failed
