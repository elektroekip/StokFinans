import uuid
from datetime import datetime, timezone
from sqlalchemy import BigInteger, Column, ForeignKey, Integer, String, Text, TIMESTAMP
from sqlalchemy.orm import relationship
from app.core.database import Base


class DeployBatch(Base):
    __tablename__ = "deploy_batches"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    initiated_by = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    bundle_size_bytes = Column(BigInteger, nullable=True)
    status = Column(String(50), default="in_progress")  # in_progress|done|partial|failed
    created_at = Column(TIMESTAMP(timezone=True), default=lambda: datetime.now(timezone.utc))

    items = relationship("DeployBatchItem", back_populates="batch", cascade="all, delete-orphan")


class DeployBatchItem(Base):
    __tablename__ = "deploy_batch_items"

    id = Column(Integer, primary_key=True, autoincrement=True)
    batch_id = Column(String(36), ForeignKey("deploy_batches.id", ondelete="CASCADE"), nullable=False)
    sync_node_id = Column(Integer, ForeignKey("sync_nodes.id", ondelete="SET NULL"), nullable=True)
    node_name = Column(String(100), nullable=False)
    # mirrors DEPLOY_STEPS keys: queued|deploying|extracting|copying|rebuilding|restarting|done|error
    status = Column(String(50), default="queued")
    error_message = Column(Text, nullable=True)
    started_at = Column(TIMESTAMP(timezone=True), nullable=True)
    completed_at = Column(TIMESTAMP(timezone=True), nullable=True)

    batch = relationship("DeployBatch", back_populates="items")
