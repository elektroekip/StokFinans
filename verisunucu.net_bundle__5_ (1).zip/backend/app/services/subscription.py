"""
Abonelik servis fonksiyonları:
- Kalan gün hesaplama (sub_expires_at üzerinden)
- Süre uzatma / atama
- Paket kotası kontrolü
"""
from __future__ import annotations
from datetime import datetime, timedelta, timezone
from math import ceil
from typing import Optional

from sqlalchemy.orm import Session

from app.models import User, Package


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def compute_days_remaining(expires_at: Optional[datetime]) -> int:
    """sub_expires_at'tan tam sayı gün sayısı çıkar (yukarı yuvarlama)."""
    if not expires_at:
        return 0
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    delta = expires_at - now_utc()
    if delta.total_seconds() <= 0:
        return 0
    return max(0, ceil(delta.total_seconds() / 86400))


def is_subscription_active(user: User) -> bool:
    return compute_days_remaining(user.sub_expires_at) > 0


def extend_subscription(user: User, days: int) -> tuple[int, int]:
    """
    Kalan günü +days kadar artırır (kullanıcı erken yenilerse mevcut günler korunur).
    Negatif days verilirse expires_at'tan düşer; minimum şimdi.
    Geriye (days_before, days_after) döner.
    """
    days_before = compute_days_remaining(user.sub_expires_at)
    base = user.sub_expires_at if user.sub_expires_at and user.sub_expires_at > now_utc() else now_utc()
    new_expires = base + timedelta(days=days)
    if new_expires < now_utc():
        new_expires = now_utc()
    user.sub_expires_at = new_expires
    user.sub_days = compute_days_remaining(new_expires)
    days_after = user.sub_days
    return days_before, days_after


def set_subscription_days(user: User, days: int) -> tuple[int, int]:
    """Kalan günü tam olarak `days` yapar (yönetici full set)."""
    days_before = compute_days_remaining(user.sub_expires_at)
    user.sub_expires_at = now_utc() + timedelta(days=max(0, int(days)))
    user.sub_days = max(0, int(days))
    days_after = user.sub_days
    return days_before, days_after


def get_package(db: Session, slug: str) -> Optional[Package]:
    return db.query(Package).filter(Package.slug == slug).first()


def get_user_package(db: Session, user: User) -> Optional[Package]:
    slug = user.package_slug or "starter"
    return get_package(db, slug)


def get_quota_usage(db: Session, user: User) -> dict:
    """
    Kullanıcının ürün, işlem ve aylık destek talebi sayısını + paket limitlerini döndür.
    Çalışan ise patron'un (parent_user_id) verisi sayılır.
    """
    from app.models import Product, Transaction, SupportTicket
    from app.utils.tenant import data_owner_id

    pkg = get_user_package(db, user)
    owner_id = data_owner_id(user)
    products_count = db.query(Product).filter(Product.user_id == owner_id).count()
    tx_count = db.query(Transaction).filter(Transaction.user_id == owner_id).count()

    # Aylık destek talebi sayısı — bu ayın başından itibaren
    now = now_utc()
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    tickets_count = (
        db.query(SupportTicket)
        .filter(SupportTicket.user_id == owner_id, SupportTicket.created_at >= month_start)
        .count()
    )

    max_p = pkg.max_products if pkg else None
    max_t = pkg.max_transactions if pkg else None
    max_s = pkg.max_support_tickets if pkg else None

    return {
        "package": pkg,
        "products_used": products_count,
        "products_limit": max_p,
        "products_unlimited": max_p is None,
        "transactions_used": tx_count,
        "transactions_limit": max_t,
        "transactions_unlimited": max_t is None,
        "support_tickets_used": tickets_count,
        "support_tickets_limit": max_s,
        "support_tickets_unlimited": max_s is None,
    }


def check_quota(db: Session, user: User, kind: str) -> Optional[str]:
    """
    Kota aşımını kontrol et. Aşım varsa Türkçe hata mesajı döner; yoksa None.
    kind: 'product' veya 'transaction'
    Çalışan için patron kullanıcısı üzerinden değerlendirilir.
    """
    if user.is_super_admin:
        return None
    # Çalışan ise patron user'ı al
    eff_user = user
    pid = getattr(user, "parent_user_id", None)
    if pid:
        parent = db.query(User).filter(User.id == int(pid)).first()
        if parent:
            eff_user = parent
    if not is_subscription_active(eff_user):
        return "Aboneliğiniz sona ermiş. Lütfen abonelik sayfasından yeni bir paket alın."
    pkg = get_user_package(db, eff_user)
    if not pkg:
        return None
    usage = get_quota_usage(db, eff_user)
    if kind == "product":
        limit = usage["products_limit"]
        if limit is not None and usage["products_used"] >= limit:
            return f"Paket limitiniz doldu: {usage['products_used']} / {limit} ürün. Daha üst bir pakete geçin."
    elif kind == "transaction":
        limit = usage["transactions_limit"]
        if limit is not None and usage["transactions_used"] >= limit:
            return f"Paket limitiniz doldu: {usage['transactions_used']} / {limit} finans kaydı. Daha üst bir pakete geçin."
    elif kind == "support_ticket":
        limit = usage["support_tickets_limit"]
        if limit is not None and usage["support_tickets_used"] >= limit:
            return f"Bu ay açabileceğiniz destek talebi limitine ulaştınız: {usage['support_tickets_used']} / {limit}. Limit her ayın başında sıfırlanır."
    return None
