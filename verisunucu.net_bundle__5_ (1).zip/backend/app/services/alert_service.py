"""
Güvenlik Uyarı Servisi — Security Alert Service

Şüpheli olayları gerçek zamanlı olarak tespit edip bildirir:
  - E-posta (SMTP — mevcut ayarlardan)
  - Discord / Slack webhook (SECURITY_WEBHOOK_URL env)

Env değişkenleri:
  SECURITY_ALERT_EMAIL   → uyarı e-postalarının gideceği adres (süperadmin)
  SECURITY_WEBHOOK_URL   → Discord/Slack webhook URL'i (opsiyonel)

İstekle aynı thread'de çalışmaz (fire-and-forget daemon thread) —
gecikme / hata kullanıcıyı etkilemez.

Cooldown mekanizması aynı (event_type, ip) çiftinden 5 dakikada
bir uyarı gönderir; spam önlenir.
"""
from __future__ import annotations

import os
import threading
import urllib.request
import json
from datetime import datetime, timedelta
from typing import Optional

# ── Cooldown (aynı olay/IP için uyarı aralığı) ──────────────────────────────
_COOLDOWN_SECONDS = int(os.getenv("ALERT_COOLDOWN_SECONDS", "300"))
_cooldown_lock = threading.Lock()
_cooldowns: dict[str, datetime] = {}


def _is_on_cooldown(key: str) -> bool:
    now = datetime.utcnow()
    with _cooldown_lock:
        last = _cooldowns.get(key)
        if last and (now - last).total_seconds() < _COOLDOWN_SECONDS:
            return True
        _cooldowns[key] = now
        return False


# ── Uyarı tetikleyici (public API) ──────────────────────────────────────────

def trigger_alert(
    event_type: str,
    ip: str,
    detail: str,
    user_id: Optional[int] = None,
    email: Optional[str] = None,
) -> None:
    """
    Şüpheli olayı bildir. İstek döngüsünü bloklamaz.

    Parametreler:
        event_type  — "REVOKED_TOKEN_USED", "NEGATIVE_QTY_ATTEMPT", "BRUTE_FORCE" vb.
        ip          — saldırganın IP adresi
        detail      — olay özeti (tek satır)
        user_id     — varsa hedef/fail kullanıcı ID
        email       — varsa hedef e-posta adresi
    """
    key = f"{event_type}:{ip}"
    if _is_on_cooldown(key):
        return

    print(f"[ALERT] {event_type} | ip={ip} | {detail}")

    ctx = {
        "event_type": event_type,
        "ip": ip,
        "detail": detail,
        "user_id": user_id,
        "email": email,
        "ts": datetime.utcnow().isoformat(timespec="seconds"),
    }
    t = threading.Thread(target=_dispatch, args=(ctx,), daemon=True)
    t.start()


# ── Gönderim mantığı (arka plan thread) ─────────────────────────────────────

def _dispatch(ctx: dict) -> None:
    _send_email(ctx)
    _send_webhook(ctx)


def _send_email(ctx: dict) -> None:
    alert_email = os.getenv("SECURITY_ALERT_EMAIL", "").strip()
    if not alert_email:
        return

    try:
        from app.core.database import SessionLocal
        db = SessionLocal()
        try:
            _deliver_email(db, alert_email, ctx)
        finally:
            db.close()
    except Exception as exc:
        print(f"[ALERT][EMAIL] Hata: {exc}")


def _deliver_email(db, to_email: str, ctx: dict) -> None:
    import smtplib, ssl
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    from app.models.smtp_setting import SmtpSetting
    from app.utils.crypto import decrypt_secret

    s = db.query(SmtpSetting).filter(SmtpSetting.id == 1).first()
    if not s or not s.is_configured:
        return

    event   = ctx["event_type"]
    ip      = ctx["ip"]
    detail  = ctx["detail"]
    ts      = ctx["ts"]
    uid     = ctx.get("user_id") or "—"
    mail    = ctx.get("email") or "—"

    subject = f"🚨 StokFinans Güvenlik Uyarısı — {event}"

    body_text = (
        f"Güvenlik Uyarısı\n\n"
        f"Olay    : {event}\n"
        f"IP      : {ip}\n"
        f"Detay   : {detail}\n"
        f"Kullanıcı ID : {uid}\n"
        f"E-posta : {mail}\n"
        f"Zaman   : {ts} UTC\n\n"
        f"Lütfen Güvenlik > Loglar panelini inceleyin."
    )

    body_html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"></head>
<body style="font-family:Arial,sans-serif;background:#f8fafc;padding:32px;">
  <div style="max-width:520px;margin:0 auto;background:#fff;border-radius:12px;
              padding:28px;border:2px solid #ef4444;">
    <h2 style="color:#ef4444;margin:0 0 16px;">🚨 Güvenlik Uyarısı</h2>
    <table style="width:100%;border-collapse:collapse;font-size:14px;">
      <tr><td style="padding:6px 0;color:#64748b;width:130px;">Olay</td>
          <td style="padding:6px 0;font-weight:bold;color:#1e293b;">{event}</td></tr>
      <tr style="background:#fef2f2;"><td style="padding:6px 8px;color:#64748b;">IP Adresi</td>
          <td style="padding:6px 8px;font-family:monospace;color:#b91c1c;">{ip}</td></tr>
      <tr><td style="padding:6px 0;color:#64748b;">Detay</td>
          <td style="padding:6px 0;color:#1e293b;">{detail}</td></tr>
      <tr style="background:#fef2f2;"><td style="padding:6px 8px;color:#64748b;">Kullanıcı ID</td>
          <td style="padding:6px 8px;color:#1e293b;">{uid}</td></tr>
      <tr><td style="padding:6px 0;color:#64748b;">E-posta</td>
          <td style="padding:6px 0;color:#1e293b;">{mail}</td></tr>
      <tr style="background:#fef2f2;"><td style="padding:6px 8px;color:#64748b;">Zaman (UTC)</td>
          <td style="padding:6px 8px;font-family:monospace;color:#1e293b;">{ts}</td></tr>
    </table>
    <p style="margin-top:20px;color:#64748b;font-size:13px;">
      Güvenlik &gt; Loglar panelinden detayları inceleyebilirsiniz.
    </p>
    <hr style="border:none;border-top:1px solid #e2e8f0;margin:20px 0;">
    <p style="color:#94a3b8;font-size:11px;text-align:center;">
      StokFinans Otomatik Güvenlik Bildirimi
    </p>
  </div>
</body></html>"""

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = f"{s.from_name or 'StokFinans'} <{s.from_email}>"
    msg["To"] = to_email
    msg.attach(MIMEText(body_text, "plain", "utf-8"))
    msg.attach(MIMEText(body_html, "html", "utf-8"))

    pwd = decrypt_secret(s.password or "")
    if s.use_ssl:
        ctx_ssl = ssl.create_default_context()
        with smtplib.SMTP_SSL(s.host, s.port, context=ctx_ssl, timeout=10) as srv:
            srv.login(s.username, pwd)
            srv.sendmail(s.from_email, [to_email], msg.as_string())
    else:
        with smtplib.SMTP(s.host, s.port, timeout=10) as srv:
            if s.use_tls:
                srv.starttls(context=ssl.create_default_context())
            srv.login(s.username, pwd)
            srv.sendmail(s.from_email, [to_email], msg.as_string())

    print(f"[ALERT][EMAIL] {ctx['event_type']} uyarısı {to_email} adresine gönderildi")


def _send_webhook(ctx: dict) -> None:
    webhook_url = os.getenv("SECURITY_WEBHOOK_URL", "").strip()
    if not webhook_url:
        return

    event  = ctx["event_type"]
    ip     = ctx["ip"]
    detail = ctx["detail"]
    ts     = ctx["ts"]
    uid    = ctx.get("user_id") or "—"

    # Discord ve Slack her ikisiyle de uyumlu payload (content + embeds)
    payload = {
        "content": f"🚨 **Güvenlik Uyarısı — {event}**",
        "embeds": [{
            "color": 0xEF4444,
            "fields": [
                {"name": "Olay",      "value": f"`{event}`",  "inline": True},
                {"name": "IP",        "value": f"`{ip}`",     "inline": True},
                {"name": "Kullanıcı", "value": str(uid),      "inline": True},
                {"name": "Detay",     "value": detail,        "inline": False},
                {"name": "Zaman",     "value": f"`{ts} UTC`", "inline": False},
            ],
        }],
    }

    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            webhook_url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=5):
            pass
        print(f"[ALERT][WEBHOOK] {event} bildirimi gönderildi")
    except Exception as exc:
        print(f"[ALERT][WEBHOOK] Hata: {exc}")


# ── Brute-force dedektörü (opsiyonel yardımcı) ──────────────────────────────

def check_and_alert_brute_force(
    db,
    ip: str,
    event_type: str,
    threshold: int = 5,
    window_minutes: int = 5,
) -> bool:
    """
    Son `window_minutes` içinde aynı IP'den `threshold` kez aynı olay varsa
    uyarı tetikler ve True döner. Middleware veya endpoint'ten çağrılabilir.
    """
    try:
        from app.models.security import SecurityLog
        from sqlalchemy import func
        cutoff = datetime.utcnow() - timedelta(minutes=window_minutes)
        count = (
            db.query(func.count(SecurityLog.id))
            .filter(
                SecurityLog.ip_address == ip,
                SecurityLog.event_type == event_type,
                SecurityLog.created_at >= cutoff,
            )
            .scalar()
        ) or 0
        if count >= threshold:
            trigger_alert(
                f"BRUTE_FORCE",
                ip,
                f"{event_type} — son {window_minutes} dakikada {count} deneme",
            )
            return True
    except Exception as exc:
        print(f"[ALERT][BRUTE_FORCE_CHECK] Hata: {exc}")
    return False
