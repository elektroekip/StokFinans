"""
Süperadmin TAM SİSTEM YEDEĞİ servisi.

Farkı (sync_service'den):
  - Süper adminler **DAHİL** edilir (tüm kullanıcılar).
  - SyncPeer kaydı dahil EDİLMEZ (peer config makineye özgü, restore sonrası bağlantı bozulmasın).
  - Restore: tüm tabloları (sync_peer hariç) TRUNCATE + INSERT — id'ler korunur.
  - Restore sonrası tüm sequence'ler max(id)+1'e ayarlanır.
  - uploads/ + backups/ klasörleri restore edilir.

ZIP yapısı:
  data.json                — {version, exported_at, kind: "system", tables: {...}}
  uploads/<filename>       — Ürün/işlem görsel dosyaları
  backups/<uuid>.sfb       — Mevcut bayi yedek dosyaları (varsa)
"""

from __future__ import annotations

import io
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from sqlalchemy import text
from sqlalchemy.orm import Session

from app.services.sync_service import (
    SYNC_TABLES,
    SEQUENCE_TABLES,
    _coerce_value,
    _row_to_dict,
    UPLOADS_DIR,
    BACKUPS_DIR,
)
from app.models import User


# ============================================================
# EXPORT
# ============================================================

def export_system_snapshot(db: Session) -> bytes:
    """
    Tüm sistem verisini ZIP olarak döndürür.
    Süper adminler dahil tüm tablolar + tüm dosyalar.
    """
    data: Dict[str, List[Dict[str, Any]]] = {}
    for model, tname in SYNC_TABLES:
        rows = db.query(model).all()  # NO super admin filter — TÜM kullanıcılar
        data[tname] = [_row_to_dict(r) for r in rows]

    payload = {
        "kind": "system",
        "version": 1,
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "tables": data,
    }

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        zf.writestr("data.json", json.dumps(payload, default=str, ensure_ascii=False))
        # uploaded files
        if UPLOADS_DIR.exists():
            for fp in UPLOADS_DIR.iterdir():
                if fp.is_file():
                    zf.write(fp, arcname=f"uploads/{fp.name}")
        # bayi yedek (.sfb) dosyaları
        if BACKUPS_DIR.exists():
            for fp in BACKUPS_DIR.iterdir():
                if fp.is_file() and fp.suffix.lower() == ".sfb":
                    zf.write(fp, arcname=f"backups/{fp.name}")

    return buf.getvalue()


# ============================================================
# IMPORT
# ============================================================

# Zip bomb koruması: toplam açılan boyut + dosya sayısı üst sınırları
MAX_UNCOMPRESSED_SIZE = 5 * 1024 * 1024 * 1024  # 5 GiB
MAX_FILE_COUNT = 200_000


class SystemBackupValidationError(ValueError):
    """Restore preflight'ta yedek doğrulanamadıysa fırlatılır."""


def _validate_snapshot_payload(payload: Any) -> Dict[str, Any]:
    """
    data.json içeriğini doğrula:
      - kind 'system' olmalı
      - tables dict olmalı, tüm beklenen tablolar mevcut olmalı (boş liste OK)
      - users içinde en az bir is_super_admin=True kayıt olmalı (kilitlenme önleme)
    """
    if not isinstance(payload, dict):
        raise SystemBackupValidationError("data.json geçersiz yapıda")
    kind = payload.get("kind")
    if kind not in (None, "system"):
        raise SystemBackupValidationError(f"Bu yedek 'system' tipinde değil (kind={kind})")
    tables = payload.get("tables")
    if not isinstance(tables, dict):
        raise SystemBackupValidationError("data.json içinde 'tables' bulunamadı veya hatalı")

    expected = {tname for _, tname in SYNC_TABLES}
    missing = [t for t in expected if t not in tables]
    if missing:
        raise SystemBackupValidationError(f"Yedekte eksik tablolar var: {', '.join(missing)}")
    for tname in expected:
        if not isinstance(tables[tname], list):
            raise SystemBackupValidationError(f"Tablo '{tname}' liste değil")

    users = tables.get("users", [])
    has_super = any(isinstance(u, dict) and bool(u.get("is_super_admin")) for u in users)
    if not has_super:
        raise SystemBackupValidationError(
            "Yedekte hiç süperadmin yok — geri yükleme reddedildi (sisteme erişim kaybedilebilir)"
        )
    return tables


def _check_zip_safety(zf: zipfile.ZipFile) -> None:
    """Zip bomb / aşırı boyut koruması."""
    infos = zf.infolist()
    if len(infos) > MAX_FILE_COUNT:
        raise SystemBackupValidationError("Yedek dosyası içinde çok fazla dosya var")
    total = 0
    for info in infos:
        # Path traversal koruması
        if info.filename.startswith("/") or ".." in info.filename.split("/"):
            raise SystemBackupValidationError(f"Yedek içinde geçersiz yol: {info.filename}")
        total += info.file_size
        if total > MAX_UNCOMPRESSED_SIZE:
            raise SystemBackupValidationError("Yedek açıldığında çok büyük (zip bomb koruması)")


def _safe_replace_dir(target: Path, write_files_callback) -> None:
    """
    Hedef klasörü atomik şekilde değiştir:
      - Yeni klasöre dosyaları yaz
      - Sonra eskiyi sil + yeniyi yerine taşı
    Hata olursa eski klasöre dokunulmaz.
    """
    target.mkdir(parents=True, exist_ok=True)
    parent = target.parent
    new_dir = parent / f".{target.name}.new.{secrets_token()}"
    old_dir = parent / f".{target.name}.old.{secrets_token()}"
    new_dir.mkdir(parents=True, exist_ok=True)
    try:
        write_files_callback(new_dir)
        # Atomik swap: target → old, new → target
        if target.exists():
            target.rename(old_dir)
        new_dir.rename(target)
    except Exception:
        # Temizle ve yeniden fırlat
        try:
            import shutil
            if new_dir.exists():
                shutil.rmtree(new_dir, ignore_errors=True)
        except Exception:
            pass
        # Eskisini geri al
        if old_dir.exists() and not target.exists():
            try:
                old_dir.rename(target)
            except Exception:
                pass
        raise
    finally:
        if old_dir.exists():
            try:
                import shutil
                shutil.rmtree(old_dir, ignore_errors=True)
            except Exception:
                pass


def secrets_token() -> str:
    import secrets as _s
    return _s.token_hex(8)


def import_system_snapshot(db: Session, zip_bytes: bytes) -> Dict[str, Any]:
    """
    Sistemin tamamını verilen ZIP'ten geri yükler.
    Tek transaction'da DB restore + atomik klasör swap ile uploads/backups restore.
    Süperadmin'siz yedek reddedilir.
    """
    buf = io.BytesIO(zip_bytes)
    stats: Dict[str, Any] = {"tables": {}, "uploads": 0, "backups": 0}

    # 1) ZIP aç + güvenlik kontrolleri
    try:
        zf = zipfile.ZipFile(buf, "r")
    except zipfile.BadZipFile:
        raise SystemBackupValidationError("Dosya geçerli bir ZIP değil")

    with zf:
        _check_zip_safety(zf)

        # 2) data.json oku + doğrula (preflight)
        try:
            with zf.open("data.json") as f:
                payload = json.loads(f.read().decode("utf-8"))
        except KeyError:
            raise SystemBackupValidationError("Geçersiz yedek: data.json bulunamadı")
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise SystemBackupValidationError("data.json okunamadı (bozuk JSON)")

        tables = _validate_snapshot_payload(payload)

        # 3) Tek transaction: TRUNCATE + INSERT
        try:
            # Reverse order DELETE — sync_peer'a dokunma
            for model, tname in reversed(SYNC_TABLES):
                db.execute(text(f"DELETE FROM {tname}"))

            # Forward order INSERT (id'leri koruyarak)
            for model, tname in SYNC_TABLES:
                rows = tables.get(tname, [])
                cnt = 0
                for raw in rows:
                    kwargs = {k: _coerce_value(model, k, v) for k, v in raw.items() if hasattr(model, k)}
                    obj = model(**kwargs)
                    db.add(obj)
                    cnt += 1
                db.flush()
                stats["tables"][tname] = cnt

            # Son kontrol: en az bir super admin var mı?
            super_count = db.query(User).filter(User.is_super_admin == True).count()  # noqa: E712
            if super_count == 0:
                raise SystemBackupValidationError(
                    "Restore sonrası süperadmin kalmıyor — işlem geri alındı"
                )

            # Sequence'leri max(id)+1'e ayarla (PostgreSQL)
            for tname, pk in SEQUENCE_TABLES:
                try:
                    db.execute(text(
                        f"SELECT setval(pg_get_serial_sequence('{tname}', '{pk}'), "
                        f"COALESCE((SELECT MAX({pk}) FROM {tname}), 0) + 1, false)"
                    ))
                except Exception:
                    pass

            db.commit()
        except Exception:
            db.rollback()
            raise

        # 4) uploads/ ve backups/ klasörlerini ATOMİK swap ile değiştir
        # (yedekte olmayan eski dosyalar kalmaz)
        def write_uploads(target_dir: Path):
            count = 0
            for name in zf.namelist():
                if name.startswith("uploads/") and not name.endswith("/"):
                    fname = name[len("uploads/"):]
                    if not fname or "/" in fname or "\\" in fname or fname.startswith(".."):
                        continue
                    with zf.open(name) as src, open(target_dir / fname, "wb") as dst:
                        dst.write(src.read())
                    count += 1
            stats["uploads"] = count

        def write_backups(target_dir: Path):
            count = 0
            for name in zf.namelist():
                if name.startswith("backups/") and not name.endswith("/"):
                    fname = name[len("backups/"):]
                    if not fname or "/" in fname or "\\" in fname or fname.startswith(".."):
                        continue
                    with zf.open(name) as src, open(target_dir / fname, "wb") as dst:
                        dst.write(src.read())
                    count += 1
            stats["backups"] = count

        _safe_replace_dir(UPLOADS_DIR, write_uploads)
        _safe_replace_dir(BACKUPS_DIR, write_backups)

    return stats
