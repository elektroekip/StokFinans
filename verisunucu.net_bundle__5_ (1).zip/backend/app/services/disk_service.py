"""
Disk yönetimi servisi — diyagram algoritması:
  1. İşlem geldi (dosya yükle)
  2. Yerel disk kontrolü → Disk Boş? → bu sunucuyu kullan
  3. Disk Dolu? → peer node ara → Disk Boş? → o sunucuyu kullan
  4. Tüm diskler dolu? → en fazla boş alanı olan peer'ı kullan (en az kötü seçenek)
"""
import shutil
from typing import Optional

# Minimum boş alan eşiği (varsayılan 500 MB)
DISK_MIN_FREE_BYTES: int = 500 * 1024 * 1024  # 500 MB


def get_disk_stats() -> dict:
    """Yerel disk istatistiklerini döndür."""
    usage = shutil.disk_usage("/")
    return {
        "total_bytes": usage.total,
        "used_bytes": usage.used,
        "free_bytes": usage.free,
        "total_gb": round(usage.total / (1024 ** 3), 2),
        "free_gb": round(usage.free / (1024 ** 3), 2),
        "used_percent": round(usage.used / usage.total * 100, 1),
    }


def is_disk_low() -> bool:
    """Yerel diskin boş alanı eşiğin altındaysa True döner."""
    return shutil.disk_usage("/").free < DISK_MIN_FREE_BYTES


def find_best_peer_node(db):
    """
    En fazla boş disk alanına sahip aktif peer node'u döndürür.
    Yerel disk doluyken yeni dosyaların gönderileceği sunucuyu belirler.
    """
    from app.models.sync_node import SyncNode
    nodes = (
        db.query(SyncNode)
        .filter(
            SyncNode.is_self == False,
            SyncNode.is_active == True,
            SyncNode.url.isnot(None),
            SyncNode.peer_token_encrypted.isnot(None),
        )
        .all()
    )
    best = None
    best_free = -1
    for node in nodes:
        free_gb = node.sys_disk_free_gb or 0
        free_bytes = free_gb * (1024 ** 3)
        if free_bytes > best_free:
            best_free = free_bytes
            best = node
    return best  # None if no peers
