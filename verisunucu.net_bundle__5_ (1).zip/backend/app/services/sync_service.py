"""
Multi-Node Sync Service — çoklu StokFinans kurulumları arasında çok-yönlü replikasyon.

Tasarım:
  - Her sunucu kendi SyncNode kaydına sahip (is_self=True).
  - Uzak sunucular is_self=False kayıtlarla temsil edilir.
  - peer_token_encrypted: uzak sunucuya gönderirken kullanacağımız token (Fernet şifreli).
  - our_token: uzak sunucuların bize gelirken Authorization: Bearer ile göndermesi gereken token.
  - Snapshot = ZIP: data.json + uploads/* + backups/*
  - MERGE stratejisi: daha yeni updated_at kazanır (yeni satırlar eklenir, eski olanlar korunur).
  - sync_nodes ve sync_logs tabloları hiçbir zaman senkronize edilmez.
  - Super admin kullanıcılar hiçbir zaman üzerine yazılmaz.
"""
from __future__ import annotations

import io
import json
import os
import secrets
import shutil
import time
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import httpx
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.models.sync_node import SyncNode
from app.models.sync_log import SyncLog
from app.models import (
    User, Product, Transaction, ActivityLog, Category,
    SubscriptionEvent, Package, Payment, PaytrSetting, EmployeeInvite,
    SmtpSetting, RegisterNotice, TermsSetting, BayiBackup, FtpServer,
    Warranty, DebtorLink, SupportTicket, SupportMessage,
    BtbCustomer, BtbOrder, BtbOrderItem, BtbPayment, BtbPriceList,
    CustomerVisit, VisitPlan,
    ErpWebhook, ErpSyncLog, PaymentGateway, PosTransaction, DbsAgreement, DbsInvoice,
)
from app.models.device import Device
from app.models.api_key import ApiKey
from app.models.vehicle import Vehicle, VehicleItem, VehicleAssignment, VehicleLog
from app.models.supplier import Supplier, PurchaseOrder, PurchaseOrderItem
from app.models.sync_deletion import SyncDeletion
from app.models.file_location import FileLocation
from app.utils.crypto import encrypt_secret, decrypt_secret

UPLOADS_DIR = Path("uploads")
BACKUPS_DIR = Path("backups")

# Senkronize edilecek tablolar (import sırası FK bağımlılıklarına göre)
SYNC_TABLES: List[Tuple[Any, str]] = [
    (Package, "packages"),
    (SmtpSetting, "smtp_settings"),
    (RegisterNotice, "register_notices"),
    (TermsSetting, "terms_settings"),
    (PaytrSetting, "paytr_settings"),
    (FtpServer, "ftp_servers"),
    (User, "users"),
    (EmployeeInvite, "employee_invites"),
    (ApiKey, "api_keys"),
    (Category, "categories"),
    (Product, "products"),
    (Device, "devices"),
    (Vehicle, "vehicles"),
    (VehicleItem, "vehicle_items"),
    (VehicleAssignment, "vehicle_assignments"),
    (VehicleLog, "vehicle_logs"),
    (Transaction, "transactions"),
    (ActivityLog, "activity_logs"),
    (SubscriptionEvent, "subscription_events"),
    (Payment, "payments"),
    (BayiBackup, "bayi_backups"),
    (Warranty, "warranties"),
    (DebtorLink, "debtor_links"),
    (SupportTicket, "support_tickets"),
    (SupportMessage, "support_messages"),
    # BTB (B2B) — dependency sırasına göre
    (BtbCustomer,       "btb_customers"),
    (BtbOrder,          "btb_orders"),
    (BtbOrderItem,      "btb_order_items"),
    (BtbPayment,        "btb_payments"),
    (BtbPriceList,      "btb_price_lists"),
    # Tedarikçi
    (Supplier,          "suppliers"),
    (PurchaseOrder,     "purchase_orders"),
    (PurchaseOrderItem, "purchase_order_items"),
    # Plasiyer
    (CustomerVisit,     "customer_visits"),
    (VisitPlan,         "visit_plans"),
    # Entegrasyon
    (ErpWebhook,        "erp_webhooks"),
    (ErpSyncLog,        "erp_sync_logs"),
    (PaymentGateway,    "payment_gateways"),
    (PosTransaction,    "pos_transactions"),
    (DbsAgreement,      "dbs_agreements"),
    (DbsInvoice,        "dbs_invoices"),
    (FileLocation,      "file_locations"),
]

# Sequence güncellenecek tablolar (max(id)+1 yap)
SEQUENCE_TABLES: List[Tuple[str, str]] = [
    ("packages", "id"),
    ("smtp_settings", "id"),
    ("register_notices", "id"),
    ("terms_settings", "id"),
    ("paytr_settings", "id"),
    ("ftp_servers", "id"),
    ("users", "id"),
    ("employee_invites", "id"),
    ("api_keys", "id"),
    ("categories", "id"),
    ("products", "id"),
    ("devices", "id"),
    ("vehicles", "id"),
    ("vehicle_items", "id"),
    ("vehicle_assignments", "id"),
    ("vehicle_logs", "id"),
    ("transactions", "id"),
    ("activity_logs", "id"),
    ("subscription_events", "id"),
    ("payments", "id"),
    ("warranties", "id"),
    ("debtor_links", "id"),
    ("support_tickets", "id"),
    ("support_messages", "id"),
    ("btb_customers", "id"),
    ("btb_orders", "id"),
    ("btb_order_items", "id"),
    ("btb_payments", "id"),
    ("btb_price_lists", "id"),
    ("suppliers", "id"),
    ("purchase_orders", "id"),
    ("purchase_order_items", "id"),
    ("customer_visits", "id"),
    ("visit_plans", "id"),
    ("erp_webhooks", "id"),
    ("erp_sync_logs", "id"),
    ("payment_gateways", "id"),
    ("pos_transactions", "id"),
    ("dbs_agreements", "id"),
    ("dbs_invoices", "id"),
    ("file_locations", "id"),
]


# ============================================================
# Self Node yönetimi
# ============================================================

def get_self_node(db: Session) -> SyncNode:
    """
    Bu sunucunun SyncNode kaydını döndürür; yoksa otomatik oluşturur.
    SELF_NODE_NAME env değişkeni set edilmişse, kayıtlı adı da günceller.
    """
    import os as _os
    env_name = _os.environ.get("SELF_NODE_NAME", "").strip()

    node = db.query(SyncNode).filter(SyncNode.is_self == True).first()  # noqa: E712
    if node:
        if env_name and node.name != env_name:
            node.name = env_name
            db.commit()
        return node
    node = SyncNode(
        name=env_name or "Ana Sunucu",
        display_order=1,
        url=None,
        our_token=secrets.token_urlsafe(64),
        peer_token_encrypted=None,
        is_self=True,
        is_active=True,
    )
    db.add(node)
    db.commit()
    db.refresh(node)
    return node


# ============================================================
# Sistem bilgileri
# ============================================================

def get_local_sysinfo() -> Dict[str, Any]:
    """CPU/RAM/disk/OS bilgilerini döndürür."""
    disk = shutil.disk_usage("/")
    cpu = os.cpu_count() or 1

    # RAM: /proc/meminfo (Linux, psutil gerekmez)
    ram_gb = None
    try:
        with open("/proc/meminfo", "r") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    kb = int(line.split()[1])
                    ram_gb = round(kb / (1024 * 1024), 2)
                    break
    except Exception:
        pass

    # Fallback: psutil
    if ram_gb is None:
        try:
            import psutil
            ram_gb = round(psutil.virtual_memory().total / (1024 ** 3), 2)
        except Exception:
            pass

    return {
        "cpu_count": cpu,
        "ram_gb": ram_gb,
        "disk_total_gb": round(disk.total / (1024 ** 3), 2),
        "disk_free_gb": round(disk.free / (1024 ** 3), 2),
        "os": os.name,
    }


# ============================================================
# Snapshot export
# ============================================================

def _row_to_dict(row) -> Dict[str, Any]:
    from decimal import Decimal
    out: Dict[str, Any] = {}
    for col in row.__table__.columns:
        val = getattr(row, col.name)
        if isinstance(val, datetime):
            out[col.name] = val.isoformat()
        elif isinstance(val, Decimal):
            out[col.name] = float(val)
        else:
            out[col.name] = val
    return out


def export_full_snapshot(db: Session) -> bytes:
    """
    Tüm tabloları (super admin user'lar ve sync_* tabloları hariç) +
    uploads/ + backups/ klasörlerini bir ZIP içine paketler.
    """
    data: Dict[str, List[Dict[str, Any]]] = {}
    for model, tname in SYNC_TABLES:
        q = db.query(model)
        if model is User:
            q = q.filter(User.is_super_admin == False)  # noqa: E712
        rows = q.all()
        data[tname] = [_row_to_dict(r) for r in rows]

    payload = {
        "version": 2,
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "tables": data,
    }

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        zf.writestr("data.json", json.dumps(payload, default=str, ensure_ascii=False))

        if UPLOADS_DIR.exists():
            for fp in UPLOADS_DIR.iterdir():
                if fp.is_file():
                    zf.write(fp, arcname=f"uploads/{fp.name}")

        if BACKUPS_DIR.exists():
            for fp in BACKUPS_DIR.iterdir():
                if fp.is_file() and fp.suffix.lower() == ".sfb":
                    zf.write(fp, arcname=f"backups/{fp.name}")

    return buf.getvalue()


# ============================================================
# Snapshot import — MERGE stratejisi (daha yeni timestamp kazanır)
# ============================================================

def _coerce_value(model, col_name: str, val: Any) -> Any:
    """JSON'dan gelen string datetime'ları gerçek datetime'a çevir."""
    if val is None:
        return None
    col = getattr(model, col_name, None)
    if col is None:
        return val
    try:
        coltype = str(col.property.columns[0].type).lower()
    except Exception:
        return val
    if "timestamp" in coltype or "datetime" in coltype:
        if isinstance(val, str):
            try:
                return datetime.fromisoformat(val)
            except Exception:
                return None
    return val


def _parse_dt(val: Any) -> Optional[datetime]:
    """Herhangi bir datetime / ISO string'i timezone-aware datetime'a çevir."""
    if val is None:
        return None
    if isinstance(val, datetime):
        if val.tzinfo is None:
            return val.replace(tzinfo=timezone.utc)
        return val
    if isinstance(val, str):
        try:
            dt = datetime.fromisoformat(val)
            if dt.tzinfo is None:
                return dt.replace(tzinfo=timezone.utc)
            return dt
        except Exception:
            return None
    return None


def import_merge_snapshot(
    db: Session,
    zip_bytes: bytes,
    from_node_name: str,
    from_node_url: str,
) -> Dict[str, Any]:
    """
    MERGE stratejisi ile snapshot import:
    - Mevcut satır varsa: incoming.updated_at > local.updated_at ise UPSERT, aksi halde SKIP.
    - Yeni satırlar (local'de yok): INSERT.
    - sync_nodes ve sync_logs tabloları HİÇBİR ZAMAN senkronize edilmez.
    - Super admin kullanıcılar HİÇBİR ZAMAN üzerine yazılmaz.
    - uploads/ ve backups/ dosyaları üzerine yazılır (dosyalar için timestamp kontrolü yok).
    """
    self_node = get_self_node(db)
    self_name = self_node.name

    t_start = time.monotonic()
    buf = io.BytesIO(zip_bytes)
    stats: Dict[str, Any] = {"tables": {}, "uploads": 0, "backups": 0, "skipped": {}}

    with zipfile.ZipFile(buf, "r") as zf:
        with zf.open("data.json") as f:
            payload = json.loads(f.read().decode("utf-8"))
        tables = payload.get("tables", {})

        # Super admin ID'lerini topla — bunlara asla dokunulmaz
        super_admin_ids = {
            u.id for u in db.query(User).filter(User.is_super_admin == True).all()  # noqa: E712
        }

        try:
            for model, tname in SYNC_TABLES:
                rows = tables.get(tname, [])
                inserted = 0
                updated = 0
                skipped = 0

                for raw in rows:
                    row_id = raw.get("id")

                    # Super admin kullanıcıları koru
                    if model is User:
                        if bool(raw.get("is_super_admin")):
                            skipped += 1
                            continue
                        if row_id in super_admin_ids:
                            skipped += 1
                            continue

                    incoming_updated_at = _parse_dt(raw.get("updated_at"))
                    incoming_created_at = _parse_dt(raw.get("created_at"))

                    # Mevcut satırı bul
                    existing = None
                    if row_id is not None:
                        existing = db.get(model, row_id)

                    if existing is not None:
                        # Timestamp karşılaştırması
                        local_updated_at = _parse_dt(getattr(existing, "updated_at", None))
                        local_created_at = _parse_dt(getattr(existing, "created_at", None))

                        # Local daha yeniyse SKIP
                        local_ts = local_updated_at or local_created_at
                        incoming_ts = incoming_updated_at or incoming_created_at

                        if local_ts and incoming_ts and local_ts >= incoming_ts:
                            skipped += 1
                            continue

                        # Mevcut kaydı güncelle
                        for k, v in raw.items():
                            if hasattr(existing, k):
                                setattr(existing, k, _coerce_value(model, k, v))
                        db.add(existing)
                        updated += 1
                    else:
                        # Yeni satır — INSERT (unique ihlali olursa savepoint ile atla)
                        kwargs = {
                            k: _coerce_value(model, k, v)
                            for k, v in raw.items()
                            if hasattr(model, k)
                        }
                        obj = model(**kwargs)
                        try:
                            with db.begin_nested():
                                db.add(obj)
                                db.flush()
                            inserted += 1
                        except Exception:
                            skipped += 1

                stats["tables"][tname] = {"inserted": inserted, "updated": updated, "skipped": skipped}

            db.flush()

            # Sequence'leri güncelle
            for tname, pk in SEQUENCE_TABLES:
                try:
                    db.execute(text(
                        f"SELECT setval(pg_get_serial_sequence('{tname}', '{pk}'), "
                        f"COALESCE((SELECT MAX({pk}) FROM {tname}), 0) + 1, false)"
                    ))
                except Exception:
                    pass

            db.commit()
        except Exception:
            db.rollback()
            raise

        # Dosyaları yaz
        UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
        BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
        for name in zf.namelist():
            if name.startswith("uploads/") and not name.endswith("/"):
                with zf.open(name) as src:
                    fname = name[len("uploads/"):]
                    if not fname or "/" in fname or "\\" in fname or fname.startswith(".."):
                        continue
                    with open(UPLOADS_DIR / fname, "wb") as dst:
                        dst.write(src.read())
                    stats["uploads"] += 1
            elif name.startswith("backups/") and not name.endswith("/"):
                with zf.open(name) as src:
                    fname = name[len("backups/"):]
                    if not fname or "/" in fname or "\\" in fname or fname.startswith(".."):
                        continue
                    with open(BACKUPS_DIR / fname, "wb") as dst:
                        dst.write(src.read())
                    stats["backups"] += 1

    duration_ms = int((time.monotonic() - t_start) * 1000)
    total_records = sum(
        (v.get("inserted", 0) + v.get("updated", 0))
        for v in stats["tables"].values()
        if isinstance(v, dict)
    )

    # Log yaz
    _write_log(
        db,
        from_node_name=from_node_name,
        to_node_name=self_name,
        event_type="pull",
        records_total=total_records,
        duration_ms=duration_ms,
        error=None,
        details={"tables": {t: v for t, v in stats["tables"].items()}},
    )

    return stats


# ============================================================
# Eski import (geri uyumluluk için export edilir — backup servisinde kullanılıyor)
# ============================================================

def import_full_snapshot(db: Session, zip_bytes: bytes) -> Dict[str, Any]:
    """
    Tam overwrite import (eski API ile uyumluluk — system backup restore için).
    MERGE değil, TRUNCATE+INSERT yapar. Sync node'ları ve super admin'ler korunur.
    """
    buf = io.BytesIO(zip_bytes)
    stats: Dict[str, Any] = {"tables": {}, "uploads": 0, "backups": 0}

    with zipfile.ZipFile(buf, "r") as zf:
        with zf.open("data.json") as f:
            payload = json.loads(f.read().decode("utf-8"))
        tables = payload.get("tables", {})

        super_admins = db.query(User).filter(User.is_super_admin == True).all()  # noqa: E712
        super_admin_ids = {u.id for u in super_admins}

        imported_users = [r for r in tables.get("users", []) if not r.get("is_super_admin")]

        used_ids = set(super_admin_ids)
        for r in imported_users:
            uid = r.get("id")
            if uid is not None and uid not in super_admin_ids:
                used_ids.add(uid)
        next_id = max(used_ids, default=0) + 1
        user_remap: Dict[int, int] = {}
        for r in imported_users:
            uid = r.get("id")
            if uid in super_admin_ids:
                while next_id in used_ids:
                    next_id += 1
                user_remap[uid] = next_id
                used_ids.add(next_id)
                next_id += 1

        def remap_uid(v):
            if v is None:
                return None
            return user_remap.get(v, v)

        USER_FK_TABLES: List[Tuple[Any, List[str]]] = [
            (Product, ["user_id"]),
            (Transaction, ["user_id"]),
            (Category, ["user_id"]),
            (ActivityLog, ["user_id"]),
            (SubscriptionEvent, ["user_id", "actor_user_id", "related_user_id"]),
            (Payment, ["user_id"]),
            (BayiBackup, ["user_id"]),
            (EmployeeInvite, ["parent_user_id", "consumed_user_id"]),
            (User, ["referred_by_user_id", "parent_user_id"]),
        ]

        try:
            for model, tname in reversed(SYNC_TABLES):
                if model is User:
                    db.query(User).filter(User.is_super_admin == False).delete(synchronize_session=False)  # noqa: E712
                else:
                    db.execute(text(f"DELETE FROM {tname}"))

            for model, tname in SYNC_TABLES:
                rows = tables.get(tname, [])
                cnt = 0
                for raw in rows:
                    if model is User:
                        if bool(raw.get("is_super_admin")):
                            continue
                        old_id = raw.get("id")
                        new_id = user_remap.get(old_id, old_id)
                        kwargs = {k: _coerce_value(model, k, v) for k, v in raw.items() if hasattr(model, k)}
                        kwargs["id"] = new_id
                        if "referred_by_user_id" in kwargs:
                            kwargs["referred_by_user_id"] = remap_uid(kwargs["referred_by_user_id"])
                        if "parent_user_id" in kwargs:
                            kwargs["parent_user_id"] = remap_uid(kwargs["parent_user_id"])
                    else:
                        kwargs = {k: _coerce_value(model, k, v) for k, v in raw.items() if hasattr(model, k)}
                        for fk_model, fk_cols in USER_FK_TABLES:
                            if fk_model is model:
                                for fc in fk_cols:
                                    if fc in kwargs:
                                        kwargs[fc] = remap_uid(kwargs[fc])
                                break
                    obj = model(**kwargs)
                    db.add(obj)
                    cnt += 1
                db.flush()
                stats["tables"][tname] = cnt

            for tname, pk in SEQUENCE_TABLES:
                try:
                    db.execute(text(
                        f"SELECT setval(pg_get_serial_sequence('{tname}', '{pk}'), "
                        f"COALESCE((SELECT MAX({pk}) FROM {tname}), 0) + 1, false)"
                    ))
                except Exception:
                    pass

            db.commit()
        except Exception:
            db.rollback()
            raise

        UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
        BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
        for name in zf.namelist():
            if name.startswith("uploads/") and not name.endswith("/"):
                with zf.open(name) as src:
                    fname = name[len("uploads/"):]
                    if not fname or "/" in fname or "\\" in fname or fname.startswith(".."):
                        continue
                    with open(UPLOADS_DIR / fname, "wb") as dst:
                        dst.write(src.read())
                    stats["uploads"] += 1
            elif name.startswith("backups/") and not name.endswith("/"):
                with zf.open(name) as src:
                    fname = name[len("backups/"):]
                    if not fname or "/" in fname or "\\" in fname or fname.startswith(".."):
                        continue
                    with open(BACKUPS_DIR / fname, "wb") as dst:
                        dst.write(src.read())
                    stats["backups"] += 1

    return stats


# ============================================================
# HTTP iletişim (httpx)
# ============================================================

def _node_headers(node: SyncNode) -> Dict[str, str]:
    token = decrypt_secret(node.peer_token_encrypted or "")
    return {"Authorization": f"Bearer {token}"}


def register_self_on_peer(
    db: Session,
    peer_node: SyncNode,
    self_node: SyncNode,
    timeout: float = 15.0,
) -> Tuple[bool, str]:
    """
    Bu sunucunun bilgilerini uzak node'a gönderir — uzak node bizi sync listesine ekler.
    Yeni node eklendiğinde otomatik çağrılır (çift yönlü bağlantı).
    Uzak node, bu sunucuya bağlanmak için self_node.our_token'ı kullanacak.
    """
    if not peer_node.url:
        return False, "Uzak node URL'si tanımlı değil"
    if not self_node.our_token:
        return False, "Bu sunucunun our_token'ı henüz oluşturulmamış"

    # Bu sunucunun genel URL'si: peer'ın URL'sinden türetemeyiz, bu yüzden
    # SELF_URL env değişkenine bakıyoruz; yoksa uyarı ver.
    import os
    self_url = os.getenv("SELF_URL", "").rstrip("/")
    if not self_url:
        return False, (
            "SELF_URL ortam değişkeni tanımlı değil — "
            "karşı sunucu bu sunucuya bağlanamayacak. "
            "docker-compose.yml'e SELF_URL=https://sunucu1.example.com ekleyin."
        )

    headers = _node_headers(peer_node)
    body = {
        "name": self_node.name,
        "url": self_url,
        "our_token": self_node.our_token,
        "display_order": 1,  # Bu sunucu daima "Ana Sunucu" (1)
    }
    try:
        r = httpx.post(
            f"{peer_node.url.rstrip('/')}/api/v1/sync/register-peer",
            headers=headers,
            json=body,
            timeout=timeout,
        )
        if r.status_code == 200:
            return True, "ok"
        return False, f"HTTP {r.status_code}: {r.text[:200]}"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def heartbeat_to_node(db: Session, node: SyncNode, timeout: float = 10.0) -> Tuple[bool, str]:
    """Uzak node'a heartbeat gönder; sysinfo'yu da al ve node kaydını güncelle."""
    if not node.url:
        return False, "URL tanımlı değil"
    base_url = node.url.rstrip("/")
    headers = _node_headers(node)
    self_node = get_self_node(db)

    try:
        # Ping
        ping_headers = {**headers, "X-Node-Name": self_node.name}
        r = httpx.post(f"{base_url}/api/v1/sync/ping", headers=ping_headers, timeout=timeout)
        if r.status_code != 200:
            return False, f"HTTP {r.status_code}: {r.text[:200]}"

        # Sysinfo al
        try:
            rs = httpx.get(f"{base_url}/api/v1/sync/sysinfo", headers=headers, timeout=timeout)
            if rs.status_code == 200:
                info = rs.json()
                node.sys_cpu_count = info.get("cpu_count")
                node.sys_ram_gb = info.get("ram_gb")
                node.sys_disk_total_gb = info.get("disk_total_gb")
                node.sys_disk_free_gb = info.get("disk_free_gb")
                node.sys_os = info.get("os")
        except Exception:
            pass  # sysinfo alınamazsa devam et

        node.last_heartbeat_at = datetime.now(timezone.utc)
        node.last_error = None
        db.commit()

        _write_log(
            db,
            from_node_name=self_node.name,
            to_node_name=node.name,
            event_type="heartbeat",
            records_total=None,
            duration_ms=None,
            error=None,
            details=None,
        )

        return True, "ok"
    except Exception as e:
        err_msg = f"{type(e).__name__}: {e}"
        node.last_error = err_msg
        db.commit()
        return False, err_msg


def push_to_node(
    db: Session,
    node: SyncNode,
    from_name: str,
    timeout: float = 120.0,
) -> Dict[str, Any]:
    """Lokal snapshot'ı uzak node'a gönder."""
    t_start = time.monotonic()
    snap = export_full_snapshot(db)
    base_url = node.url.rstrip("/")
    self_node = get_self_node(db)
    headers = {
        **_node_headers(node),
        "Content-Type": "application/zip",
        "X-Node-Name": self_node.name,
        "X-Node-Url": self_node.url or "",
    }

    try:
        r = httpx.post(
            f"{base_url}/api/v1/sync/import",
            headers=headers,
            content=snap,
            timeout=timeout,
        )
        if r.status_code != 200:
            raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")

        duration_ms = int((time.monotonic() - t_start) * 1000)
        node.last_sync_at = datetime.now(timezone.utc)
        node.last_error = None
        db.commit()

        _write_log(
            db,
            from_node_name=from_name,
            to_node_name=node.name,
            event_type="push",
            records_total=None,
            duration_ms=duration_ms,
            error=None,
            details=None,
        )

        try:
            return r.json()
        except Exception:
            return {"ok": True}
    except Exception as e:
        duration_ms = int((time.monotonic() - t_start) * 1000)
        err_msg = str(e)
        node.last_error = err_msg
        db.commit()
        _write_log(
            db,
            from_node_name=from_name,
            to_node_name=node.name,
            event_type="error",
            records_total=None,
            duration_ms=duration_ms,
            error=err_msg,
            details=None,
        )
        raise


def pull_from_node(
    db: Session,
    node: SyncNode,
    self_name: str,
    timeout: float = 120.0,
) -> Dict[str, Any]:
    """Uzak node'dan snapshot indir; MERGE stratejisiyle uygula."""
    t_start = time.monotonic()
    base_url = node.url.rstrip("/")
    headers = _node_headers(node)

    try:
        r = httpx.get(f"{base_url}/api/v1/sync/snapshot", headers=headers, timeout=timeout)
        if r.status_code != 200:
            raise RuntimeError(f"Snapshot çekilemedi: HTTP {r.status_code} {r.text[:200]}")

        stats = import_merge_snapshot(db, r.content, node.name, node.url or "")

        duration_ms = int((time.monotonic() - t_start) * 1000)
        node.last_sync_at = datetime.now(timezone.utc)
        node.last_error = None
        db.commit()

        _write_log(
            db,
            from_node_name=node.name,
            to_node_name=self_name,
            event_type="pull",
            records_total=sum(
                (v.get("inserted", 0) + v.get("updated", 0))
                for v in stats["tables"].values()
                if isinstance(v, dict)
            ),
            duration_ms=duration_ms,
            error=None,
            details={"tables": stats["tables"]},
        )

        return stats
    except Exception as e:
        duration_ms = int((time.monotonic() - t_start) * 1000)
        err_msg = str(e)
        node.last_error = err_msg
        db.commit()
        _write_log(
            db,
            from_node_name=node.name,
            to_node_name=self_name,
            event_type="error",
            records_total=None,
            duration_ms=duration_ms,
            error=err_msg,
            details=None,
        )
        raise


def push_to_all(db: Session, self_name: str) -> List[Dict[str, Any]]:
    """Tüm aktif uzak node'lara push yap."""
    nodes = (
        db.query(SyncNode)
        .filter(SyncNode.is_self == False, SyncNode.is_active == True)  # noqa: E712
        .all()
    )
    results = []
    for node in nodes:
        if not node.url or not node.peer_token_encrypted:
            results.append({"node": node.name, "ok": False, "error": "URL veya token eksik"})
            continue
        try:
            result = push_to_node(db, node, self_name)
            results.append({"node": node.name, "ok": True, "result": result})
        except Exception as e:
            results.append({"node": node.name, "ok": False, "error": str(e)})
    return results


# ============================================================
# Log yardımcısı
# ============================================================

def _write_log(
    db: Session,
    from_node_name: str,
    to_node_name: str,
    event_type: str,
    records_total: Optional[int],
    duration_ms: Optional[int],
    error: Optional[str],
    details: Optional[Any],
) -> None:
    try:
        log = SyncLog(
            from_node_name=from_node_name,
            to_node_name=to_node_name,
            event_type=event_type,
            records_total=records_total,
            duration_ms=duration_ms,
            error=error,
            details=details,
        )
        db.add(log)
        db.commit()
    except Exception as e:
        # Log yazma hatası uygulamayı durdurmasın
        try:
            db.rollback()
        except Exception:
            pass
        print(f"[SYNC_LOG] Log yazılamadı: {e}")


# ============================================================
# Delta sync — çift yönlü, anlık, toleranslı
# ============================================================
# Tasarım:
#   PUSH  (S1→S2): Herhangi bir veri değişikliğinde debounce (3sn) sonra anlık delta push.
#                  S1 son başarılı push'tan (last_sync_at) bu yana değişenleri gönderir.
#   PULL  (S1←S2): S1, S2'nin /sync/delta endpoint'ini her 30 saniyede bir çeker.
#                  Son başarılı pull'dan (last_pull_at) bu yana değişenleri alır.
#   SAFETY NET   : Her 30 dakikada bir tam snapshot push — kaçan delta'ları yakalar.
#   ÇAKIŞMA ÇÖZME: "Daha yeni timestamp kazanır" + 2 saniyelik saat toleransı.
#                  Eğer local ile incoming arasındaki fark < CLOCK_SKEW_TOLERANCE_S → incoming kazanır.
# ============================================================

import threading as _threading

CLOCK_SKEW_TOLERANCE_S = 2.0          # Saat toleransı (saniye) — bu kadar farkı "eşit" say
DELTA_SAFETY_BUFFER   = timedelta(minutes=5)   # since hesaplarken güvenlik tampon
_DEBOUNCE_SEC         = 3.0            # Push debounce (saniye)

_debounce_lock  = _threading.Lock()
_debounce_timer: Optional[_threading.Timer] = None


# ── Delta dışa aktarma ──────────────────────────────────────

def export_delta(db: Session, since_dt: datetime) -> Dict[str, Any]:
    """
    since_dt'den bu yana değişen/eklenen satırları + silme kayıtlarını döndürür.
    Super admin'ler ve sync_* tabloları HİÇBİR ZAMAN dahil edilmez.
    """
    delta: Dict[str, Any] = {}
    for model, tname in SYNC_TABLES:
        try:
            if hasattr(model, "updated_at"):
                rows = db.query(model).filter(model.updated_at >= since_dt).all()
            elif hasattr(model, "created_at"):
                rows = db.query(model).filter(model.created_at >= since_dt).all()
            else:
                continue
            if model is User:
                rows = [r for r in rows if not r.is_super_admin]
            if rows:
                delta[tname] = [_row_to_dict(r) for r in rows]
        except Exception as exc:
            print(f"[SYNC][export_delta] {tname} atlandı: {exc}")
            continue

    # Silme kayıtları
    try:
        deletions = (
            db.query(SyncDeletion)
            .filter(SyncDeletion.deleted_at >= since_dt)
            .all()
        )
        if deletions:
            delta["_deletions"] = [
                {"table_name": d.table_name, "row_id": d.row_id}
                for d in deletions
            ]
    except Exception as exc:
        print(f"[SYNC][export_delta] _deletions atlandı: {exc}")

    return delta


# ── Delta uygulama (MERGE + tolerans) ───────────────────────

def apply_delta(
    db: Session,
    delta: Dict[str, Any],
    from_node_name: str,
) -> Dict[str, Any]:
    """
    Delta'yı MERGE stratejisiyle uygular.

    Çakışma kuralı:
      • incoming_ts > local_ts + CLOCK_SKEW_TOLERANCE_S  → incoming kabul
      • fark <= CLOCK_SKEW_TOLERANCE_S                   → incoming kabul (clock skew toleransı)
      • local_ts > incoming_ts + CLOCK_SKEW_TOLERANCE_S  → local korunur (skip)

    Super admin kullanıcılar HİÇBİR ZAMAN üzerine yazılmaz.
    """
    stats: Dict[str, Any] = {}
    try:
        super_admin_ids = {
            u.id
            for u in db.query(User).filter(User.is_super_admin == True).all()  # noqa: E712
        }

        for model, tname in SYNC_TABLES:
            rows = delta.get(tname, [])
            if not rows:
                continue

            inserted = updated = skipped = conflict_skipped = 0

            for raw in rows:
                # Super admin koruması
                if model is User:
                    if raw.get("is_super_admin"):
                        skipped += 1
                        continue
                    if raw.get("id") in super_admin_ids:
                        skipped += 1
                        continue

                pk = raw.get("id")

                # Gelen timestamp
                incoming_ts: Optional[datetime] = None
                ts_str = raw.get("updated_at") or raw.get("created_at")
                if ts_str:
                    try:
                        incoming_ts = datetime.fromisoformat(str(ts_str))
                        if incoming_ts.tzinfo is None:
                            incoming_ts = incoming_ts.replace(tzinfo=timezone.utc)
                    except Exception:
                        pass

                local_row = (
                    db.query(model).filter(model.id == pk).first()
                    if pk is not None else None
                )

                if local_row is not None:
                    # Çakışma çözme: local aynı veya daha yeniyse SKIP
                    local_ts: Optional[datetime] = (
                        getattr(local_row, "updated_at", None)
                        or getattr(local_row, "created_at", None)
                    )
                    if local_ts and incoming_ts:
                        if local_ts.tzinfo is None:
                            local_ts = local_ts.replace(tzinfo=timezone.utc)
                        # Local >= incoming → aynı veri ya da daha yeni → güncelleme yok
                        # (ping-pong döngüsünü engeller: S1→S2→S1 geri gelmesini önler)
                        if local_ts >= incoming_ts:
                            conflict_skipped += 1
                            continue

                    # Güncelle
                    for k, v in raw.items():
                        if hasattr(local_row, k):
                            setattr(local_row, k, _coerce_value(model, k, v))
                    updated += 1
                else:
                    # Yeni satır — INSERT
                    kwargs = {
                        k: _coerce_value(model, k, v)
                        for k, v in raw.items()
                        if hasattr(model, k)
                    }
                    try:
                        with db.begin_nested():
                            db.add(model(**kwargs))
                            db.flush()
                        inserted += 1
                    except Exception:
                        skipped += 1

            if inserted or updated or skipped or conflict_skipped:
                stats[tname] = {
                    "inserted": inserted,
                    "updated": updated,
                    "skipped": skipped,
                    "conflict_skipped": conflict_skipped,
                }

        # Silme kayıtlarını uygula
        raw_deletions = delta.get("_deletions", [])
        deletions_deleted = deletions_not_found = 0
        if raw_deletions:
            _tname_to_model = {t: m for m, t in SYNC_TABLES}
            for entry in raw_deletions:
                tname   = entry.get("table_name")
                row_id  = entry.get("row_id")
                if not tname or not row_id:
                    continue
                model = _tname_to_model.get(tname)
                if model is None:
                    continue
                try:
                    with db.begin_nested():
                        row = db.query(model).filter(model.id == row_id).first()
                        if row:
                            db.delete(row)
                            deletions_deleted += 1
                        else:
                            deletions_not_found += 1
                except Exception as exc:
                    print(f"[SYNC][apply_delta] silme hatası {tname}:{row_id}: {exc}")
        if raw_deletions:
            stats["_deletions"] = {
                "deleted": deletions_deleted,
                "not_found": deletions_not_found,
            }

        # Sequence güncelle
        for tname, pk in SEQUENCE_TABLES:
            try:
                db.execute(text(
                    f"SELECT setval(pg_get_serial_sequence('{tname}', '{pk}'), "
                    f"COALESCE((SELECT MAX({pk}) FROM {tname}), 0) + 1, false)"
                ))
            except Exception:
                pass

        db.commit()
    except Exception:
        db.rollback()
        raise
    return stats


# ── Delta push (S1→S2) ──────────────────────────────────────

def push_delta_to_node(
    db: Session,
    node: SyncNode,
    self_name: str,
    delta: Dict[str, Any],
    timeout: float = 30.0,
) -> Dict[str, Any]:
    """Delta'yı belirli uzak node'a gönder ve istatistiği döndür."""
    if not node.url or not node.peer_token_encrypted:
        raise ValueError("Node URL veya peer token eksik")

    t_start = time.monotonic()
    headers = {**_node_headers(node), "X-Node-Name": self_name}

    # Toplam satır sayısını hesapla (log için)
    total_rows = sum(
        len(v) for k, v in delta.items()
        if k != "_deletions" and isinstance(v, list)
    ) + len(delta.get("_deletions", []))

    payload = {"from_node": self_name, "tables": delta}

    try:
        r = httpx.post(
            f"{node.url.rstrip('/')}/api/v1/sync/push-delta",
            headers=headers,
            json=payload,
            timeout=timeout,
        )
        duration_ms = int((time.monotonic() - t_start) * 1000)

        if r.status_code != 200:
            raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")

        node.last_sync_at = datetime.now(timezone.utc)
        node.last_error    = None
        db.commit()

        tbl_summary = {k: len(v) for k, v in delta.items() if k != "_deletions" and isinstance(v, list)}
        if "_deletions" in delta:
            tbl_summary["_deletions"] = len(delta["_deletions"])
        _write_log(
            db, self_name, node.name, "push_delta",
            total_rows, duration_ms, None,
            {"tables": tbl_summary, "from": self_name, "to": node.name},
        )

        try:
            return r.json()
        except Exception:
            return {"ok": True}
    except Exception as e:
        duration_ms = int((time.monotonic() - t_start) * 1000)
        err_msg = str(e)
        node.last_error = err_msg[:500]
        db.commit()
        _write_log(
            db, self_name, node.name, "error",
            None, duration_ms, err_msg,
            {"operation": "push_delta", "node": node.name},
        )
        raise


def _do_delta_push_all() -> None:
    """
    Arka plan thread'inde tüm aktif node'lara delta push.
    Since: node.last_sync_at - DELTA_SAFETY_BUFFER (veya 24 saat öncesi).
    """
    from app.core.database import SessionLocal
    db = SessionLocal()
    try:
        self_node = get_self_node(db)
        nodes = db.query(SyncNode).filter(
            SyncNode.is_self == False,  # noqa: E712
            SyncNode.is_active == True,  # noqa: E712
        ).all()

        for node in nodes:
            if not node.url or not node.peer_token_encrypted:
                continue

            # Since hesabı: son başarılı push - güvenlik tampon
            last_sync = node.last_sync_at
            if last_sync is None:
                since_dt = datetime.now(timezone.utc) - timedelta(hours=24)
            else:
                if last_sync.tzinfo is None:
                    last_sync = last_sync.replace(tzinfo=timezone.utc)
                since_dt = last_sync - DELTA_SAFETY_BUFFER

            try:
                delta = export_delta(db, since_dt)
                if not delta:
                    # Değişen bir şey yok — node'un sync_at'ini güncelle
                    node.last_sync_at = datetime.now(timezone.utc)
                    db.commit()
                    continue
                push_delta_to_node(db, node, self_node.name, delta)
                print(
                    f"[SYNC][push-delta] {node.name}: "
                    f"{sum(len(v) for v in delta.values() if isinstance(v, list))} satır"
                )
            except Exception as e:
                print(f"[SYNC][push-delta] {node.name} hata: {e}")
    except Exception as e:
        print(f"[SYNC][push-delta-all] beklenmeyen hata: {e}")
        try:
            db.rollback()
        except Exception:
            pass
    finally:
        db.close()


# ── Delta pull (S1←S2) ──────────────────────────────────────

def pull_delta_from_node(
    db: Session,
    node: SyncNode,
    self_name: str,
    timeout: float = 30.0,
) -> Dict[str, Any]:
    """
    Uzak node'dan delta çek ve MERGE uygula.
    S1←S2 yönünü sağlar: S2 S1'e ulaşamadığında S1 aktif olarak çeker.

    Since hesabı: node.last_pull_at - DELTA_SAFETY_BUFFER
    (ilk kez ise 24 saat öncesi)
    """
    if not node.url or not node.peer_token_encrypted:
        return {}

    t_start = time.monotonic()

    # Since hesabı — last_pull_at ile doğru takip
    last_pull = node.last_pull_at
    if last_pull is None:
        since_dt = datetime.now(timezone.utc) - timedelta(hours=24)
    else:
        if last_pull.tzinfo is None:
            last_pull = last_pull.replace(tzinfo=timezone.utc)
        since_dt = last_pull - DELTA_SAFETY_BUFFER

    since_ts = since_dt.timestamp()
    base_url  = node.url.rstrip("/")
    headers   = _node_headers(node)

    try:
        r = httpx.get(
            f"{base_url}/api/v1/sync/delta",
            headers=headers,
            params={"since": since_ts},
            timeout=timeout,
        )
        if r.status_code != 200:
            raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")

        data  = r.json()
        delta: Dict[str, Any] = data.get("delta", {})

        # Her durumda last_pull_at güncelle (hata yoksa)
        node.last_pull_at = datetime.now(timezone.utc)
        node.last_error   = None
        db.commit()

        if not delta:
            # Değişen bir şey yok — log yazma (spam önleme)
            return {}

        stats = apply_delta(db, delta, node.name)
        duration_ms = int((time.monotonic() - t_start) * 1000)

        # İstatistik hesapla
        del_stats    = stats.get("_deletions", {})
        deleted_cnt  = del_stats.get("deleted", 0) if isinstance(del_stats, dict) else 0
        total_rows   = sum(
            (v.get("inserted", 0) + v.get("updated", 0))
            for k, v in stats.items()
            if k != "_deletions" and isinstance(v, dict)
        ) + deleted_cnt

        _write_log(
            db,
            from_node_name=node.name,
            to_node_name=self_name,
            event_type="pull_delta",
            records_total=total_rows,
            duration_ms=duration_ms,
            error=None,
            details={
                "tables": stats,
                "since": since_dt.isoformat(),
                "from": node.name,
                "to": self_name,
            },
        )
        print(
            f"[SYNC][pull-delta] {node.name}→{self_name}: "
            f"{total_rows} satır ({duration_ms}ms)"
        )
        return stats

    except Exception as e:
        duration_ms = int((time.monotonic() - t_start) * 1000)
        err_msg = str(e)
        node.last_error = err_msg[:500]
        db.commit()
        _write_log(
            db,
            from_node_name=node.name,
            to_node_name=self_name,
            event_type="error",
            records_total=None,
            duration_ms=duration_ms,
            error=err_msg,
            details={"operation": "pull_delta", "since": since_dt.isoformat()},
        )
        print(f"[SYNC][pull-delta] {node.name} hata: {err_msg}")
        raise


# ── Dosya push ──────────────────────────────────────────────

def push_file_to_nodes(file_path) -> None:
    """Yeni yüklenen dosyayı tüm aktif node'lara gönder (arka planda)."""
    _fp = Path(file_path) if not isinstance(file_path, Path) else file_path

    def _push() -> None:
        from app.core.database import SessionLocal
        db = SessionLocal()
        try:
            if not _fp.exists():
                return
            content  = _fp.read_bytes()
            filename = _fp.name
            nodes = db.query(SyncNode).filter(
                SyncNode.is_self  == False,  # noqa: E712
                SyncNode.is_active == True,  # noqa: E712
            ).all()
            for node in nodes:
                if not node.url or not node.peer_token_encrypted:
                    continue
                try:
                    r = httpx.post(
                        f"{node.url.rstrip('/')}/api/v1/sync/push-file",
                        headers=_node_headers(node),
                        files={"file": (filename, content, "application/octet-stream")},
                        timeout=30.0,
                    )
                    if r.status_code != 200:
                        print(f"[SYNC][push-file] {node.name}: HTTP {r.status_code}")
                except Exception as exc:
                    print(f"[SYNC][push-file] {node.name}: {exc}")
        except Exception as exc:
            print(f"[SYNC][push-file-all] hata: {exc}")
        finally:
            db.close()

    _threading.Thread(target=_push, daemon=True).start()


# ── Silme kaydı ─────────────────────────────────────────────

def record_deletion(db: Session, table_name: str, row_id: int) -> None:
    """
    Hard-delete öncesinde çağrılır.
    sync_deletions'a kayıt ekler; delta push/pull bunu diğer node'lara iletir.
    """
    try:
        db.add(SyncDeletion(table_name=table_name, row_id=row_id))
        db.flush()
    except Exception:
        pass  # silme kaydı başarısız olsa da asıl delete devam eder


# ── Push tetikleyici (debounce) ─────────────────────────────

def trigger_delta_push() -> None:
    """
    Herhangi bir yazma işleminden sonra çağrılır.
    Debounce: son tetiklemeden _DEBOUNCE_SEC geçmeden gelen yeni isteklerde
    timer sıfırlanır — birden fazla hızlı değişiklik tek push'a indirilir.
    Delta push, HTTP request'i bloklamaksızın ayrı thread'de çalışır.
    """
    global _debounce_timer
    with _debounce_lock:
        if _debounce_timer is not None:
            _debounce_timer.cancel()
        _debounce_timer = _threading.Timer(_DEBOUNCE_SEC, _do_delta_push_all)
        _debounce_timer.daemon = True
        _debounce_timer.start()


# ============================================================
# Eski SyncPeer uyumluluğu (sync_scheduler için)
# ============================================================

def get_or_init_peer(db: Session):
    """Geriye dönük uyumluluk — SyncPeer döndürür (varsa)."""
    from app.models.sync_peer import SyncPeer
    import secrets as _s
    p = db.query(SyncPeer).filter(SyncPeer.id == 1).first()
    if p:
        return p
    p = SyncPeer(
        id=1,
        role="mirror",
        peer_url="",
        peer_token_encrypted="",
        our_token=_s.token_urlsafe(32),
        is_active=False,
    )
    db.add(p)
    db.commit()
    db.refresh(p)
    return p


def is_paired(peer) -> bool:
    return bool(peer and peer.is_active and peer.peer_url and peer.peer_token_encrypted)


def verify_peer_token(db: Session, auth_header: Optional[str]):
    """Geriye dönük uyumluluk — eski SyncPeer token doğrulaması."""
    import hmac as _hmac
    from app.models.sync_peer import SyncPeer
    if not auth_header or not auth_header.lower().startswith("bearer "):
        raise PermissionError("Eksik veya hatalı Authorization header")
    token = auth_header.split(None, 1)[1].strip()
    peer = db.query(SyncPeer).filter(SyncPeer.id == 1).first()
    if not peer or not peer.our_token:
        raise PermissionError("Sunucuda eşleşme yapılandırılmamış")
    if not peer.is_active or not peer.peer_url or not peer.peer_token_encrypted:
        raise PermissionError("Eşleşme aktif değil")
    if not _hmac.compare_digest(token.encode("utf-8"), peer.our_token.encode("utf-8")):
        raise PermissionError("Geçersiz peer token")
    return peer


def heartbeat(peer, timeout: float = 10.0) -> Tuple[bool, str]:
    """Geriye dönük uyumluluk — eski SyncPeer heartbeat."""
    url = peer.peer_url.rstrip("/") + "/api/v1/sync/ping"
    token = decrypt_secret(peer.peer_token_encrypted)
    try:
        r = httpx.post(url, headers={"Authorization": f"Bearer {token}"}, timeout=timeout)
        if r.status_code == 200:
            return True, "ok"
        return False, f"HTTP {r.status_code}: {r.text[:200]}"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def pull_from_peer(db: Session, peer, timeout: float = 120.0) -> Dict[str, Any]:
    """Geriye dönük uyumluluk — eski SyncPeer pull."""
    token = decrypt_secret(peer.peer_token_encrypted)
    url = peer.peer_url.rstrip("/") + "/api/v1/sync/snapshot"
    r = httpx.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=timeout)
    if r.status_code != 200:
        raise RuntimeError(f"HTTP {r.status_code} {r.text[:200]}")
    stats = import_full_snapshot(db, r.content)
    peer.last_sync_at = datetime.now(timezone.utc)
    peer.last_error = None
    db.commit()
    return stats


def push_to_peer(db: Session, peer, timeout: float = 120.0) -> Dict[str, Any]:
    """Geriye dönük uyumluluk — eski SyncPeer push."""
    snap = export_full_snapshot(db)
    token = decrypt_secret(peer.peer_token_encrypted)
    url = peer.peer_url.rstrip("/") + "/api/v1/sync/import"
    r = httpx.post(
        url,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/zip"},
        content=snap,
        timeout=timeout,
    )
    if r.status_code != 200:
        raise RuntimeError(f"HTTP {r.status_code} {r.text[:200]}")
    peer.last_sync_at = datetime.now(timezone.utc)
    peer.last_error = None
    db.commit()
    try:
        return r.json()
    except Exception:
        return {"ok": True}
