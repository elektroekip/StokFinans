"""
FTP/SFTP Service
================
Süperadminin tanımladığı uzak sunuculara bayi yedek dosyalarını (.sfb)
yükle/indir/listele/sil.

İki protokol desteklenir:
  - 'ftp'  : ftplib.FTP (clear FTP, port 21)
  - 'sftp' : paramiko Transport + SFTPClient (port 22)

Tüm fonksiyonlar (server, ...) imzasını alır; server bir FtpServer ORM
satırıdır. Şifre çözme dahili olarak yapılır.
"""

from __future__ import annotations

import io
import os
import posixpath
from contextlib import contextmanager
from typing import Iterator, List, Tuple

from app.models import FtpServer
from app.utils.crypto import decrypt_secret


# ============================================================
# Bağlantı yöneticileri
# ============================================================

@contextmanager
def _ftp_connect(server: FtpServer):
    """ftplib.FTP context manager. Connect/login hatasında socket'i kapatır."""
    import ftplib
    pwd = decrypt_secret(server.password_encrypted)
    ftp = ftplib.FTP()
    try:
        ftp.connect(server.host, server.port or 21, timeout=30)
        ftp.login(server.username, pwd)
        if server.base_path and server.base_path not in ("", "/"):
            _ftp_ensure_path(ftp, server.base_path)
            ftp.cwd(server.base_path)
        yield ftp
    except Exception:
        try:
            ftp.close()
        except Exception:
            pass
        raise
    else:
        try:
            ftp.quit()
        except Exception:
            try:
                ftp.close()
            except Exception:
                pass


@contextmanager
def _sftp_connect(server: FtpServer):
    """paramiko SFTP context manager. Hatada transport'u kapatır."""
    import paramiko
    pwd = decrypt_secret(server.password_encrypted)
    transport = paramiko.Transport((server.host, server.port or 22))
    transport.banner_timeout = 30
    sftp = None
    try:
        transport.connect(username=server.username, password=pwd)
        sftp = paramiko.SFTPClient.from_transport(transport)
        if server.base_path and server.base_path not in ("", "/"):
            _sftp_ensure_path(sftp, server.base_path)
            sftp.chdir(server.base_path)
        yield sftp
    finally:
        if sftp is not None:
            try:
                sftp.close()
            except Exception:
                pass
        try:
            transport.close()
        except Exception:
            pass


def _ftp_ensure_path(ftp, path: str) -> None:
    """FTP'de derin klasörler oluştur (cwd hatasız)."""
    parts = [p for p in path.strip("/").split("/") if p]
    for p in parts:
        try:
            ftp.cwd(p)
        except Exception:
            try:
                ftp.mkd(p)
                ftp.cwd(p)
            except Exception:
                # zaten var olabilir; kullanıcı izinleri ile cwd başarısızsa root'a dön
                pass
    # cwd absolute path
    try:
        ftp.cwd("/" + path.strip("/"))
    except Exception:
        pass


def _sftp_ensure_path(sftp, path: str) -> None:
    """SFTP'de derin klasörler oluştur."""
    parts = [p for p in path.strip("/").split("/") if p]
    cur = ""
    for p in parts:
        cur = cur + "/" + p if cur or path.startswith("/") else p
        if not cur.startswith("/"):
            cur = "/" + cur
        try:
            sftp.stat(cur)
        except IOError:
            try:
                sftp.mkdir(cur)
            except IOError:
                pass


def _norm_remote(p: str) -> str:
    """Uzak yolları posix normalize et."""
    p = (p or "").strip()
    if not p:
        return ""
    return posixpath.normpath(p).replace("\\", "/")


# ============================================================
# Genel API
# ============================================================

def test_connection(server: FtpServer) -> Tuple[bool, str]:
    try:
        if (server.type or "sftp").lower() == "ftp":
            with _ftp_connect(server) as ftp:
                ftp.voidcmd("NOOP")
        else:
            with _sftp_connect(server) as sftp:
                sftp.listdir(".")
        return True, "Bağlantı başarılı"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def upload_file(server: FtpServer, local_bytes: bytes, remote_path: str) -> str:
    """
    remote_path: server.base_path'e GÖRELİ olabilir veya '/' ile başlayan absolute.
    Dönüş: yüklenen dosyanın TAM uzak yolu.
    """
    rp = _norm_remote(remote_path)
    if not rp:
        raise ValueError("Geçersiz uzak yol")
    folder = posixpath.dirname(rp)
    fname = posixpath.basename(rp)
    if not fname:
        raise ValueError("Geçersiz dosya adı")

    if (server.type or "sftp").lower() == "ftp":
        with _ftp_connect(server) as ftp:
            if folder:
                _ftp_ensure_path(ftp, folder)
            else:
                # base_path zaten cwd
                pass
            ftp.storbinary(f"STOR {fname}", io.BytesIO(local_bytes))
    else:
        with _sftp_connect(server) as sftp:
            if folder:
                _sftp_ensure_path(sftp, folder)
                target = posixpath.join(folder if folder.startswith("/") else folder, fname)
            else:
                target = fname
            with sftp.file(target, "wb") as f:
                f.write(local_bytes)
    return rp


def download_file(server: FtpServer, remote_path: str) -> bytes:
    """Uzak dosyayı indirir."""
    rp = _norm_remote(remote_path)
    if not rp:
        raise ValueError("Geçersiz uzak yol")
    if (server.type or "sftp").lower() == "ftp":
        with _ftp_connect(server) as ftp:
            buf = io.BytesIO()
            ftp.retrbinary(f"RETR {rp}", buf.write)
            return buf.getvalue()
    else:
        with _sftp_connect(server) as sftp:
            with sftp.file(rp, "rb") as f:
                return f.read()


def list_files(server: FtpServer, sub_path: str = "") -> List[dict]:
    """
    Verilen alt yolun (base_path altında) içeriğini listeler.
    Her dosya: {name, path, is_dir, size}
    """
    sub = _norm_remote(sub_path) if sub_path else ""
    out: List[dict] = []
    if (server.type or "sftp").lower() == "ftp":
        with _ftp_connect(server) as ftp:
            target_dir = sub if sub else "."
            try:
                if sub:
                    ftp.cwd(sub)
            except Exception:
                pass
            try:
                # MLSD modern; yoksa NLST'e düş
                entries = list(ftp.mlsd())
                for name, facts in entries:
                    if name in (".", ".."):
                        continue
                    is_dir = facts.get("type") == "dir"
                    size = int(facts.get("size", 0)) if not is_dir else 0
                    out.append({
                        "name": name,
                        "path": (sub + "/" + name) if sub else name,
                        "is_dir": is_dir,
                        "size": size,
                    })
            except Exception:
                names = ftp.nlst()
                for name in names:
                    if name in (".", ".."):
                        continue
                    out.append({
                        "name": name,
                        "path": (sub + "/" + name) if sub else name,
                        "is_dir": False,
                        "size": 0,
                    })
    else:
        with _sftp_connect(server) as sftp:
            target = sub if sub else "."
            for entry in sftp.listdir_attr(target):
                import stat
                is_dir = stat.S_ISDIR(entry.st_mode or 0)
                out.append({
                    "name": entry.filename,
                    "path": (sub + "/" + entry.filename) if sub else entry.filename,
                    "is_dir": is_dir,
                    "size": entry.st_size or 0,
                })
    out.sort(key=lambda x: (not x["is_dir"], x["name"].lower()))
    return out


def delete_file(server: FtpServer, remote_path: str) -> None:
    rp = _norm_remote(remote_path)
    if not rp:
        raise ValueError("Geçersiz uzak yol")
    if (server.type or "sftp").lower() == "ftp":
        with _ftp_connect(server) as ftp:
            ftp.delete(rp)
    else:
        with _sftp_connect(server) as sftp:
            sftp.remove(rp)


def safe_subdir_for_user(user) -> str:
    """
    Bayi başına alt klasör adı: önce company_name, yoksa email'in @ önü, yoksa user_<id>.
    Güvenli karakter filtresi.
    """
    raw = (getattr(user, "company_name", None) or (getattr(user, "email", "") or "").split("@")[0] or f"user_{user.id}")
    safe = "".join(c if (c.isalnum() or c in "-_") else "_" for c in raw)[:80] or f"user_{user.id}"
    return safe
