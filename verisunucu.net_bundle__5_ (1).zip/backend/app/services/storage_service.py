"""
Depolama Havuzu Servisi

MinIO üzerinden dosya yükleme, indirme, replica yönetimi ve
günlük yedek sistemi (20 gün saklama) fonksiyonları.
"""
from __future__ import annotations

import hashlib
import io
import os
import subprocess
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy.orm import Session

from app.models.storage import StorageDailyBackup, StorageFile, StorageFileReplica, StorageNode

# ── MinIO / boto3 bağlantısı ────────────────────────────────


def _get_s3_client(node: StorageNode):
    """StorageNode'dan boto3 S3 istemcisi oluştur."""
    import boto3
    from botocore.config import Config

    endpoint = node.endpoint_url or f"http://{node.host}:{node.port or 9000}"
    access_key = node.access_key or node.username or ""
    secret_key = ""
    if node.secret_key_encrypted:
        try:
            from app.utils.crypto import decrypt_secret
            secret_key = decrypt_secret(node.secret_key_encrypted)
        except Exception:
            secret_key = node.secret_key_encrypted
    elif node.password_encrypted:
        try:
            from app.utils.crypto import decrypt_secret
            secret_key = decrypt_secret(node.password_encrypted)
        except Exception:
            secret_key = node.password_encrypted

    return boto3.client(
        "s3",
        endpoint_url=endpoint,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
        config=Config(signature_version="s3v4"),
        region_name="us-east-1",
    )


def _env_minio_client():
    """Ortam değişkenlerinden varsayılan MinIO istemcisi."""
    import boto3
    from botocore.config import Config

    endpoint = os.environ.get("MINIO_ENDPOINT", "http://minio:9000")
    access_key = os.environ.get("MINIO_ACCESS_KEY", "")
    secret_key = os.environ.get("MINIO_SECRET_KEY", "")
    return boto3.client(
        "s3",
        endpoint_url=endpoint,
        aws_access_key_id=access_key,
        aws_secret_access_key=secret_key,
        config=Config(signature_version="s3v4"),
        region_name="us-east-1",
    )


def _default_bucket() -> str:
    return os.environ.get("MINIO_BUCKET", "stokfinans-uploads")


# ── Bucket bootstrap ─────────────────────────────────────────

def ensure_bucket_exists(bucket: Optional[str] = None) -> None:
    """Bucket yoksa oluştur. Uygulama başlangıcında çağrılır."""
    bucket = bucket or _default_bucket()
    try:
        client = _env_minio_client()
        try:
            client.head_bucket(Bucket=bucket)
        except Exception:
            client.create_bucket(Bucket=bucket)
            print(f"[STORAGE] Bucket oluşturuldu: {bucket}")
    except Exception as exc:
        print(f"[STORAGE] Bucket bootstrap hatası: {exc}")


# ── Dosya yükleme ─────────────────────────────────────────────

def upload_file(
    db: Session,
    file_bytes: bytes,
    filename: str,
    content_type: str = "application/octet-stream",
    user_id: Optional[int] = None,
    storage_key: Optional[str] = None,
) -> StorageFile:
    """
    Dosyayı birincil MinIO node'a yükle, ardından tüm aktif ikincil node'lara kopyala.
    storage_file_replicas tablosuna her node için kayıt ekler.
    Eğer aynı storage_key zaten varsa mevcut kaydı döndürür.
    """
    bucket = _default_bucket()
    if storage_key is None:
        storage_key = filename

    checksum = hashlib.sha256(file_bytes).hexdigest()

    # Mevcut kayıt var mı? (soft-delete gözetmeksizin)
    existing = db.query(StorageFile).filter(StorageFile.storage_key == storage_key).first()
    if existing:
        return existing

    # ── 1. Primary node'a yükle (env MinIO) ──
    primary_node = _get_or_create_env_node(db)
    primary_endpoint = os.environ.get("MINIO_ENDPOINT", "http://minio:9000")
    client = _env_minio_client()
    ensure_bucket_exists(bucket)
    client.put_object(
        Bucket=bucket,
        Key=storage_key,
        Body=io.BytesIO(file_bytes),
        ContentLength=len(file_bytes),
        ContentType=content_type,
    )

    # ── 2. DB kaydı ──
    sf = StorageFile(
        filename=filename,
        storage_key=storage_key,
        size_bytes=len(file_bytes),
        content_type=content_type,
        checksum_sha256=checksum,
        user_id=user_id,
    )
    db.add(sf)
    db.flush()

    if primary_node:
        db.add(StorageFileReplica(
            file_id=sf.id,
            node_id=primary_node.id,
            path_on_node=f"{bucket}/{storage_key}",
            is_primary=True,
            is_verified=True,
            last_verified_at=datetime.now(timezone.utc),
        ))

    # ── 3. İkincil node'lara kopyala (distributed mode gerekmez) ──
    secondary_nodes = db.query(StorageNode).filter(
        StorageNode.is_active == True,             # noqa: E712
        StorageNode.type.in_(["minio", "s3"]),
        StorageNode.endpoint_url != primary_endpoint,
    ).all()

    for node in secondary_nodes:
        try:
            sec_client = _get_s3_client(node)
            sec_bucket = node.bucket or bucket
            # Bucket yoksa oluştur
            try:
                sec_client.head_bucket(Bucket=sec_bucket)
            except Exception:
                sec_client.create_bucket(Bucket=sec_bucket)
            sec_client.put_object(
                Bucket=sec_bucket,
                Key=storage_key,
                Body=io.BytesIO(file_bytes),
                ContentLength=len(file_bytes),
                ContentType=content_type,
            )
            db.add(StorageFileReplica(
                file_id=sf.id,
                node_id=node.id,
                path_on_node=f"{sec_bucket}/{storage_key}",
                is_primary=False,
                is_verified=True,
                last_verified_at=datetime.now(timezone.utc),
            ))
            print(f"[STORAGE] Replica oluşturuldu: {storage_key} → {node.name}")
        except Exception as exc:
            # Replica hatası upload'u durdurmaz; kaydedilmemiş replica yeniden denenebilir
            print(f"[STORAGE] Replica hatası ({node.name}): {exc}")

    db.commit()
    db.refresh(sf)

    # Topoloji: upload olayı
    try:
        from app.api.topology import emit_topology_event
        size_str = f"{len(file_bytes) / 1024:.0f}KB" if len(file_bytes) < 1048576 else f"{len(file_bytes) / 1048576:.1f}MB"
        emit_topology_event("upload", "backend-s1", "minio-s1", f"{filename} yüklendi ({size_str})")
        if secondary_nodes:
            emit_topology_event("replicate", "minio-s1", "minio-s2", f"{filename} replika oluşturuldu")
    except Exception:
        pass

    return sf


def _get_or_create_env_node(db: Session) -> Optional[StorageNode]:
    """Ortam MinIO'suna karşılık gelen StorageNode'u bul veya oluştur."""
    endpoint = os.environ.get("MINIO_ENDPOINT", "http://minio:9000")
    bucket = _default_bucket()
    node = db.query(StorageNode).filter(
        StorageNode.endpoint_url == endpoint,
        StorageNode.type == "minio",
    ).first()
    if not node:
        from app.utils.crypto import encrypt_secret
        secret = os.environ.get("MINIO_SECRET_KEY", "")
        node = StorageNode(
            name="MinIO (Yerel)",
            type="minio",
            endpoint_url=endpoint,
            access_key=os.environ.get("MINIO_ACCESS_KEY", ""),
            secret_key_encrypted=encrypt_secret(secret) if secret else None,
            bucket=bucket,
            is_primary=True,
            is_active=True,
        )
        db.add(node)
        db.flush()
    return node


# ── Dosya indirme / presigned URL ────────────────────────────

def get_presigned_url(storage_key: str, expires_seconds: int = 3600) -> str:
    """MinIO presigned download URL oluştur."""
    client = _env_minio_client()
    return client.generate_presigned_url(
        "get_object",
        Params={"Bucket": _default_bucket(), "Key": storage_key},
        ExpiresIn=expires_seconds,
    )


def download_file(storage_key: str) -> bytes:
    """MinIO'dan dosyayı indir ve bytes döndür."""
    client = _env_minio_client()
    resp = client.get_object(Bucket=_default_bucket(), Key=storage_key)
    return resp["Body"].read()


# ── Düğüm istatistikleri ─────────────────────────────────────

def refresh_node_stats(db: Session, node: StorageNode) -> None:
    """Düğümün disk kullanım istatistiklerini güncelle."""
    try:
        if node.type == "minio":
            client = _get_s3_client(node)
            bucket = node.bucket or _default_bucket()
            # Bucket toplam boyutunu hesapla (paginate)
            paginator = client.get_paginator("list_objects_v2")
            total = 0
            count = 0
            for page in paginator.paginate(Bucket=bucket):
                for obj in page.get("Contents", []):
                    total += obj.get("Size", 0)
                    count += 1
            node.used_bytes = total
            node.last_check_at = datetime.now(timezone.utc)
            node.last_error = None
        elif node.type in ("sftp", "ftp"):
            node.last_check_at = datetime.now(timezone.utc)
        db.commit()
    except Exception as exc:
        node.last_error = str(exc)[:500]
        node.last_check_at = datetime.now(timezone.utc)
        db.commit()


def check_node_health(db: Session, node: StorageNode) -> Dict[str, Any]:
    """
    Düğümü ping et, yanıt süresini ölç ve durumu DB'ye yaz.
    Döndürür: {"ok": bool, "latency_ms": int, "error": str | None}
    """
    import time
    t0 = time.monotonic()
    ok = False
    error = None
    try:
        if node.type == "minio":
            client = _get_s3_client(node)
            bucket = node.bucket or _default_bucket()
            client.head_bucket(Bucket=bucket)
            ok = True
        elif node.type in ("sftp", "ftp"):
            import socket
            host = node.host or "localhost"
            port = node.port or (22 if node.type == "sftp" else 21)
            with socket.create_connection((host, port), timeout=5):
                ok = True
        elif node.type == "s3":
            client = _get_s3_client(node)
            client.head_bucket(Bucket=node.bucket or "")
            ok = True
        elif node.type == "local":
            ok = True
    except Exception as exc:
        error = str(exc)[:300]

    latency_ms = int((time.monotonic() - t0) * 1000)
    node.last_check_at = datetime.now(timezone.utc)
    node.last_error = error
    node.is_active = ok
    db.commit()
    return {"ok": ok, "latency_ms": latency_ms, "error": error}


def list_files_in_node(node: StorageNode, prefix: str = "") -> List[Dict[str, Any]]:
    """Belirtilen düğümdeki dosyaları listele."""
    if node.type == "minio":
        client = _get_s3_client(node)
        bucket = node.bucket or _default_bucket()
        paginator = client.get_paginator("list_objects_v2")
        files = []
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            for obj in page.get("Contents", []):
                files.append({
                    "key": obj["Key"],
                    "size_bytes": obj["Size"],
                    "last_modified": obj["LastModified"].isoformat(),
                })
        return files
    return []


# ── Günlük Yedek Sistemi ──────────────────────────────────────

BACKUP_RETENTION_DAYS = 20
# PostgreSQL advisory lock key — tüm sunucularda aynı sabit sayı
# Böylece saat 03:00'de hem S1 hem S2 çalışırsa sadece biri lock alır
_BACKUP_ADVISORY_LOCK_KEY = 20260518_01  # proje-özgü sabit


def _try_acquire_backup_lock(db: Session) -> bool:
    """
    PostgreSQL advisory lock dene. True → lock alındı, bu sunucu çalışacak.
    False → başka sunucu zaten çalışıyor, bu sunucu pas geçecek.
    Lock session-scoped: bağlantı kapanınca otomatik serbest kalır.
    """
    from sqlalchemy import text
    try:
        result = db.execute(
            text("SELECT pg_try_advisory_lock(:key)"),
            {"key": _BACKUP_ADVISORY_LOCK_KEY},
        ).scalar()
        return bool(result)
    except Exception as exc:
        print(f"[BACKUP] Advisory lock hatası: {exc}")
        return True  # lock alınamadıysa bile devam et (fallback)


def _release_backup_lock(db: Session) -> None:
    from sqlalchemy import text
    try:
        db.execute(
            text("SELECT pg_advisory_unlock(:key)"),
            {"key": _BACKUP_ADVISORY_LOCK_KEY},
        )
    except Exception:
        pass


def create_daily_backup(db: Session, backup_type: str = "daily") -> Optional["StorageDailyBackup"]:
    """
    Günlük yedek oluştur.

    Race condition koruması: PostgreSQL advisory lock ile sadece tek sunucu çalışır.
    S1 ve S2'nin zamanlayıcıları aynı anda tetiklense bile biri pas geçer.

    Akış:
      1. Advisory lock dene → başarısızsa None döndür (diğer sunucu çalışıyor)
      2. PostgreSQL pg_dump
      3. MinIO'ya yükle
      4. 20 günden eski yedekleri temizle
      5. Lock serbest bırak
    """
    now = datetime.now(timezone.utc)
    expires_at = now + timedelta(days=BACKUP_RETENTION_DAYS)
    filename = f"backup_{now.strftime('%Y%m%d_%H%M%S')}.dump"

    # Master backup düğümünü bul
    master_node = db.query(StorageNode).filter(
        StorageNode.is_master_backup == True,  # noqa: E712
        StorageNode.is_active == True,         # noqa: E712
    ).first()

    backup = StorageDailyBackup(
        node_id=master_node.id if master_node else None,
        backup_type=backup_type,
        includes_db=True,
        includes_files=False,
        filename=filename,
        status="running",
        backup_date=now,
        expires_at=expires_at,
    )
    db.add(backup)
    db.commit()
    db.refresh(backup)

    def _run():
        from app.core.database import SessionLocal as _SL
        _db = _SL()
        lock_acquired = False
        try:
            # ── Advisory lock: sadece bir sunucu çalışsın ──
            lock_acquired = _try_acquire_backup_lock(_db)
            if not lock_acquired:
                # Başka sunucu zaten çalışıyor — bu kaydı iptal et
                _b = _db.query(StorageDailyBackup).filter(StorageDailyBackup.id == backup.id).first()
                if _b:
                    _b.status = "skipped"
                    _b.error = "Başka sunucu bu yedeği alıyor (advisory lock)"
                    _db.commit()
                print("[BACKUP] Advisory lock alınamadı — başka sunucu çalışıyor, atlandı")
                return

            _backup = _db.query(StorageDailyBackup).filter(StorageDailyBackup.id == backup.id).first()
            if not _backup:
                return

            # ── pg_dump ──
            db_url = os.environ.get("DATABASE_URL", "")
            dump_data = _pg_dump(db_url)
            if dump_data is None:
                _backup.status = "failed"
                _backup.error = "pg_dump başarısız"
                _db.commit()
                return

            # ── MinIO'ya yükle ──
            bucket = _default_bucket()
            backup_key = f"backups/{filename}"
            try:
                client = _env_minio_client()
                client.put_object(
                    Bucket=bucket,
                    Key=backup_key,
                    Body=io.BytesIO(dump_data),
                    ContentLength=len(dump_data),
                    ContentType="application/octet-stream",
                )
                _backup.size_bytes = len(dump_data)
                _backup.status = "done"
                _backup.completed_at = datetime.now(timezone.utc)
                size_str = f"{len(dump_data) / 1048576:.1f}MB"
                print(f"[BACKUP] Tamamlandı: {filename} ({len(dump_data):,} byte)")
                # Topoloji: backup olayı
                try:
                    from app.api.topology import emit_topology_event
                    emit_topology_event("backup", "backend-s1", "minio-s1", f"DB yedek tamamlandı: {filename} ({size_str})")
                except Exception:
                    pass
            except Exception as exc:
                _backup.status = "failed"
                _backup.error = f"Yükleme hatası: {exc}"[:500]

            try:
                push_backup_to_external_s3(_db, backup.id)
            except Exception as exc2:
                print(f"[BACKUP][external] push hatası: {exc2}")

            # ── Eski yedekleri temizle ──
            _cleanup_old_backups(_db)

        except Exception as exc:
            try:
                _b2 = _db.query(StorageDailyBackup).filter(StorageDailyBackup.id == backup.id).first()
                if _b2:
                    _b2.status = "failed"
                    _b2.error = str(exc)[:500]
                    _db.commit()
            except Exception:
                pass
            print(f"[BACKUP] Beklenmeyen hata: {exc}")
        finally:
            if lock_acquired:
                _release_backup_lock(_db)
            _db.close()

    threading.Thread(target=_run, daemon=True).start()
    return backup


def _pg_dump(db_url: str) -> Optional[bytes]:
    """PostgreSQL veritabanını gzip dump olarak döndür."""
    try:
        # DATABASE_URL'den bağlantı bilgilerini ayrıştır
        from urllib.parse import urlparse
        parsed = urlparse(db_url)
        env = {
            **os.environ,
            "PGPASSWORD": parsed.password or "",
        }
        cmd = [
            "pg_dump",
            "-h", parsed.hostname or "db",
            "-p", str(parsed.port or 5432),
            "-U", parsed.username or "stokfinans_user",
            "-d", (parsed.path or "/stokfinans_db").lstrip("/"),
            "--no-password",
            "--format=custom",
        ]
        result = subprocess.run(cmd, capture_output=True, timeout=300, env=env)
        if result.returncode != 0:
            print(f"[BACKUP] pg_dump hata: {result.stderr.decode()[:500]}")
            return None
        return result.stdout
    except Exception as exc:
        print(f"[BACKUP] pg_dump exception: {exc}")
        return None


def push_backup_to_external_s3(db: Session, backup_id: int) -> Dict[str, Any]:
    """
    Tamamlanmış bir yedeği tüm is_external_backup=True olan S3 düğümlerine kopyala.
    Harici S3 düğümü yoksa hemen döner.
    """
    backup = db.query(StorageDailyBackup).filter(StorageDailyBackup.id == backup_id).first()
    if not backup:
        return {"error": "Yedek bulunamadı"}
    if backup.status != "done":
        return {"error": "Yedek henüz tamamlanmadı", "status": backup.status}

    external_nodes = db.query(StorageNode).filter(
        StorageNode.is_external_backup == True,   # noqa: E712
        StorageNode.is_active == True,             # noqa: E712
    ).all()

    if not external_nodes:
        return {"message": "Harici S3 düğümü yok — atlandı"}

    backup.external_backup_status = "running"
    db.commit()

    backup_key = f"backups/{backup.filename}"
    try:
        data = download_file(backup_key)
    except Exception as exc:
        backup.external_backup_status = "failed"
        backup.external_backup_error = f"Yerel yedek indirilemedi: {exc}"[:500]
        backup.external_backup_at = datetime.now(timezone.utc)
        db.commit()
        return {"error": str(exc)}

    results = []
    for node in external_nodes:
        try:
            client = _get_s3_client(node)
            bucket = node.bucket or "stokfinans-backups"
            # Bucket yoksa oluştur (harici S3 servisinde)
            try:
                client.head_bucket(Bucket=bucket)
            except Exception:
                client.create_bucket(Bucket=bucket)
            client.put_object(
                Bucket=bucket,
                Key=f"backups/{backup.filename}",
                Body=io.BytesIO(data),
                ContentLength=len(data),
                ContentType="application/octet-stream",
            )
            results.append({"node": node.name, "ok": True})
            print(f"[BACKUP][external] {backup.filename} → {node.name} ✓")
        except Exception as exc:
            results.append({"node": node.name, "ok": False, "error": str(exc)[:200]})
            print(f"[BACKUP][external] {backup.filename} → {node.name} ✗ {exc}")

    all_ok = all(r["ok"] for r in results)
    backup.external_backup_status = "done" if all_ok else "failed"
    backup.external_backup_at = datetime.now(timezone.utc)
    if not all_ok:
        errors = [r.get("error", "") for r in results if not r.get("ok")]
        backup.external_backup_error = "; ".join(errors)[:500]
    else:
        backup.external_backup_error = None
    db.commit()
    return {"results": results}


def _cleanup_old_backups(db: Session) -> None:
    """Süresi dolmuş yedekleri MinIO ve DB'den temizle."""
    now = datetime.now(timezone.utc)
    expired = db.query(StorageDailyBackup).filter(
        StorageDailyBackup.expires_at < now,
        StorageDailyBackup.status == "done",
    ).all()

    for b in expired:
        # MinIO'dan sil
        if b.filename:
            try:
                client = _env_minio_client()
                client.delete_object(
                    Bucket=_default_bucket(),
                    Key=f"backups/{b.filename}",
                )
            except Exception:
                pass
        db.delete(b)
    if expired:
        db.commit()
        print(f"[BACKUP] {len(expired)} eski yedek temizlendi")


# ── Soft delete ve temizlik ───────────────────────────────────

def soft_delete_file(db: Session, file_id: int) -> bool:
    """
    Dosyayı soft-delete ile işaretle. MinIO'dan hemen SİLMEZ.
    30 gün sonra `purge_deleted_files()` gerçek silmeyi yapar.
    """
    sf = db.query(StorageFile).filter(
        StorageFile.id == file_id,
        StorageFile.deleted_at == None,  # noqa: E711
    ).first()
    if not sf:
        return False
    sf.deleted_at = datetime.now(timezone.utc)
    db.commit()
    return True


class FileAlreadyPurgedError(Exception):
    """MinIO'dan silinmiş, artık restore edilemez."""


def restore_file(db: Session, file_id: int) -> bool:
    """
    Soft-delete edilmiş dosyayı geri al (deleted_at → NULL).
    MinIO'da gerçekten hâlâ varsa restore eder; yoksa FileAlreadyPurgedError fırlatır.
    """
    sf = db.query(StorageFile).filter(
        StorageFile.id == file_id,
        StorageFile.deleted_at != None,  # noqa: E711
    ).first()
    if not sf:
        return False

    # Primary replica üzerinden MinIO varlığını kontrol et
    primary_replica = db.query(StorageFileReplica).filter(
        StorageFileReplica.file_id == sf.id,
        StorageFileReplica.is_primary == True,  # noqa: E712
    ).first()

    if primary_replica:
        node = db.query(StorageNode).filter(StorageNode.id == primary_replica.node_id).first()
        if node and node.type in ("minio", "s3"):
            try:
                client = _get_s3_client(node) if node.endpoint_url else _env_minio_client()
                client.head_object(Bucket=node.bucket or _default_bucket(), Key=sf.storage_key)
            except Exception as exc:
                if _s3_not_found(exc):
                    raise FileAlreadyPurgedError(
                        f"{sf.filename} depolama sisteminden zaten silinmiş — geri yüklenemiyor"
                    )
                # S3 erişim hatası: MinIO'ya ulaşamıyoruz, restore'u bloklamayalım
                print(f"[STORAGE][restore] MinIO erişim hatası (kontrol atlandı): {exc}")

    sf.deleted_at = None
    db.commit()
    return True


_PURGE_ADVISORY_LOCK_KEY = 20260518_02  # purge için ayrı lock key

_MINIO_NOT_FOUND_CODES = frozenset(["NoSuchKey", "NotFound", "404", "NoSuchObject"])

_PURGE_BATCH_SIZE = 100


def _s3_not_found(exc: Exception) -> bool:
    msg = str(exc)
    return any(code in msg for code in _MINIO_NOT_FOUND_CODES)


def purge_deleted_files(db: Session, grace_days: int = 30) -> int:
    """
    deleted_at süresi dolmuş dosyaları MinIO'dan ve DB'den tamamen kaldır.
    Scheduler: haftada bir Pazar 04:30 UTC.

    Güvenlik katmanları:
    1. Advisory lock — aynı anda iki instance çalışmaz (S1+S2 senaryosu)
    2. Batch taze okuma — restore yarışını yakalar, N+1 yerine O(n/100) sorgu
    3. MinIO hata ayrımı — NoSuchKey (zaten yok → sil) vs. bağlantı hatası (atla)
    """
    from sqlalchemy import text

    lock_acquired = False
    try:
        result = db.execute(
            text("SELECT pg_try_advisory_lock(:key)"),
            {"key": _PURGE_ADVISORY_LOCK_KEY},
        ).scalar()
        lock_acquired = bool(result)
    except Exception as exc:
        print(f"[STORAGE][purge] Advisory lock hatası: {exc}")
        lock_acquired = True  # lock alınamadıysa devam et (fallback)

    if not lock_acquired:
        print("[STORAGE][purge] Başka sunucu zaten çalışıyor, atlandı")
        return 0

    try:
        cutoff = datetime.now(timezone.utc) - timedelta(days=grace_days)
        all_ids = [
            row[0] for row in db.query(StorageFile.id).filter(
                StorageFile.deleted_at != None,  # noqa: E711
                StorageFile.deleted_at < cutoff,
            ).all()
        ]

        purged = 0
        for batch_start in range(0, len(all_ids), _PURGE_BATCH_SIZE):
            batch_ids = all_ids[batch_start: batch_start + _PURGE_BATCH_SIZE]

            # Batch'i taze oku; deleted_at IS NOT NULL filtresi restore edilenleri eler
            fresh_files = db.query(StorageFile).filter(
                StorageFile.id.in_(batch_ids),
                StorageFile.deleted_at != None,  # noqa: E711
            ).all()

            for sf in fresh_files:
                replicas = db.query(StorageFileReplica).filter(
                    StorageFileReplica.file_id == sf.id
                ).all()

                for replica in replicas:
                    node = db.query(StorageNode).filter(StorageNode.id == replica.node_id).first()
                    if not node or node.type not in ("minio", "s3"):
                        db.delete(replica)
                        continue
                    try:
                        node_client = _get_s3_client(node) if node.endpoint_url else _env_minio_client()
                        node_client.delete_object(Bucket=node.bucket or _default_bucket(), Key=sf.storage_key)
                        db.delete(replica)
                    except Exception as exc:
                        if _s3_not_found(exc):
                            # Dosya zaten S3'te yok — DB kaydını temizle
                            db.delete(replica)
                        else:
                            # Bağlantı hatası — bu dosyayı atla, sonraki purge'de dene
                            print(f"[STORAGE][purge] S3 hatası, atlandı: {sf.storage_key} @ {node.name}: {exc}")

                db.delete(sf)
                purged += 1
                # Topoloji: silme olayı
                try:
                    from app.api.topology import emit_topology_event
                    emit_topology_event("delete", "backend-s1", "minio-s1", f"{sf.filename} kalıcı silindi (30g grace)")
                except Exception:
                    pass

            db.commit()  # Batch başına tek commit

        if purged:
            print(f"[STORAGE][purge] {purged} dosya tamamen silindi")
        return purged

    finally:
        try:
            db.execute(
                text("SELECT pg_advisory_unlock(:key)"),
                {"key": _PURGE_ADVISORY_LOCK_KEY},
            )
        except Exception:
            pass


# ── Replica checksum doğrulama (zamanlanmış) ─────────────────

def verify_all_replicas_batch(db: Session, batch_size: int = 100) -> Dict[str, Any]:
    """
    Aktif dosyaların replica'larını SHA256 ile toplu doğrula.
    Uyumsuz replica'ları is_verified=False yapar.
    Haftalık scheduler job olarak çalışır.
    """
    mismatches = []
    checked = 0

    files = (
        db.query(StorageFile)
        .filter(StorageFile.deleted_at == None)  # noqa: E711
        .order_by(StorageFile.uploaded_at.desc())
        .limit(batch_size)
        .all()
    )

    for sf in files:
        if not sf.checksum_sha256:
            continue
        replicas = db.query(StorageFileReplica).filter(StorageFileReplica.file_id == sf.id).all()
        for replica in replicas:
            node = db.query(StorageNode).filter(StorageNode.id == replica.node_id).first()
            if not node or not node.is_active:
                continue
            try:
                if node.type in ("minio", "s3"):
                    node_client = _get_s3_client(node) if node.endpoint_url != os.environ.get("MINIO_ENDPOINT") else _env_minio_client()
                    resp = node_client.get_object(Bucket=node.bucket or _default_bucket(), Key=sf.storage_key)
                    data = resp["Body"].read()
                    actual = hashlib.sha256(data).hexdigest()
                    ok = actual == sf.checksum_sha256
                    replica.is_verified = ok
                    replica.last_verified_at = datetime.now(timezone.utc)
                    checked += 1
                    if not ok:
                        mismatches.append({"file_id": sf.id, "node": node.name, "expected": sf.checksum_sha256, "actual": actual})
                        print(f"[STORAGE][verify] Checksum UYUMSUZ: {sf.storage_key} @ {node.name}")
            except Exception as exc:
                replica.is_verified = False
                replica.last_verified_at = datetime.now(timezone.utc)
                print(f"[STORAGE][verify] {sf.storage_key} @ {node.name}: {exc}")

    db.commit()
    print(f"[STORAGE][verify] {checked} replica kontrol edildi, {len(mismatches)} uyumsuzluk")
    return {"checked": checked, "mismatches": len(mismatches), "details": mismatches}


# ── Replica doğrulama ─────────────────────────────────────────

def verify_file_replicas(db: Session, file_id: int) -> Dict[str, Any]:
    """Bir dosyanın tüm replica'larını SHA256 ile doğrula."""
    sf = db.query(StorageFile).filter(StorageFile.id == file_id).first()
    if not sf:
        return {"error": "Dosya bulunamadı"}

    results = []
    replicas = db.query(StorageFileReplica).filter(StorageFileReplica.file_id == file_id).all()
    for replica in replicas:
        node = db.query(StorageNode).filter(StorageNode.id == replica.node_id).first()
        if not node:
            continue
        try:
            if node.type == "minio":
                data = download_file(sf.storage_key)
                actual = hashlib.sha256(data).hexdigest()
                ok = (sf.checksum_sha256 is None or actual == sf.checksum_sha256)
                replica.is_verified = ok
                replica.last_verified_at = datetime.now(timezone.utc)
                results.append({"node": node.name, "ok": ok, "checksum": actual})
        except Exception as exc:
            replica.is_verified = False
            replica.last_verified_at = datetime.now(timezone.utc)
            results.append({"node": node.name, "ok": False, "error": str(exc)[:200]})
    db.commit()
    return {"file_id": file_id, "filename": sf.filename, "replicas": results}
