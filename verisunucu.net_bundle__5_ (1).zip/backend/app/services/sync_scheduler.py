"""
Sync Scheduler — çift yönlü, anlık senkronizasyon için arka plan işleri.

İş listesi:
  heartbeat    : 60s  — tüm peer node'lara ping, sysinfo güncelle
  push_delta   : (debounce ile anlık) — veri değiştiğinde trigger_delta_push() çağrılır
  pull_delta   : 30s  — tüm peer node'lardan delta çek (S2→S1 yönü için kritik)
  push_all_full: 30dk — tam snapshot safety net (kaçan delta'ları yakalar)
"""
from __future__ import annotations

from typing import Optional

from apscheduler.schedulers.background import BackgroundScheduler

from app.core.database import SessionLocal
from app.models import SyncNode
from app.services import sync_service

_scheduler: Optional[BackgroundScheduler] = None


# ── İş fonksiyonları ────────────────────────────────────────

def _heartbeat_job() -> None:
    """Her 60 saniyede bir tüm peer node'lara heartbeat gönder."""
    from app.api.topology import emit_topology_event
    db = SessionLocal()
    try:
        nodes = db.query(SyncNode).filter(
            SyncNode.is_self   == False,  # noqa: E712
            SyncNode.is_active == True,   # noqa: E712
        ).all()
        for node in nodes:
            try:
                sync_service.heartbeat_to_node(db, node)
                emit_topology_event(
                    "health", "backend-s1", "backend-s2",
                    f"Heartbeat → {node.name} ✓",
                )
            except Exception as e:
                emit_topology_event(
                    "error", "backend-s1", "backend-s2",
                    f"Heartbeat başarısız → {node.name}: {e}",
                )
                print(f"[SYNC][heartbeat] {node.name} hata: {e}")
    except Exception as e:
        print(f"[SYNC][heartbeat-all] beklenmeyen hata: {e}")
        try:
            db.rollback()
        except Exception:
            pass
    finally:
        db.close()


def _pull_delta_job() -> None:
    """
    Her 30 saniyede bir tüm peer node'lardan delta çek.
    Bu job S2→S1 yönünü sağlar: S2 S1'e push edemediğinde
    S1 S2'nin /sync/delta endpoint'ini aktif olarak sorgular.
    """
    from app.api.topology import emit_topology_event
    db = SessionLocal()
    try:
        self_node = sync_service.get_self_node(db)
        nodes = db.query(SyncNode).filter(
            SyncNode.is_self   == False,  # noqa: E712
            SyncNode.is_active == True,   # noqa: E712
        ).all()
        for node in nodes:
            if not node.url or not node.peer_token_encrypted:
                continue
            try:
                sync_service.pull_delta_from_node(db, node, self_node.name)
                emit_topology_event("replicate", "backend-s2", "backend-s1", f"{node.name} → delta senkronizasyonu")
            except Exception as e:
                # Hata zaten sync_service içinde loglanır — burada sadece konsola yaz
                print(f"[SYNC][pull-delta] {node.name}: {e}")
    except Exception as e:
        print(f"[SYNC][pull-delta-all] beklenmeyen hata: {e}")
        try:
            db.rollback()
        except Exception:
            pass
    finally:
        db.close()


def _push_all_full_job() -> None:
    """
    Her 30 dakikada bir tüm aktif node'lara TAM snapshot push.
    Safety net: delta'ların kaçması durumunda tam senkronizasyonu garanti eder.
    """
    db = SessionLocal()
    try:
        self_node = sync_service.get_self_node(db)
        nodes = db.query(SyncNode).filter(
            SyncNode.is_self   == False,  # noqa: E712
            SyncNode.is_active == True,   # noqa: E712
        ).all()
        for node in nodes:
            if not node.url or not node.peer_token_encrypted:
                continue
            try:
                sync_service.push_to_node(db, node, self_node.name)
                print(f"[SYNC][push-full] {node.name} → başarılı")
            except Exception as e:
                print(f"[SYNC][push-full] {node.name} hata: {e}")
    except Exception as e:
        print(f"[SYNC][push-full-all] beklenmeyen hata: {e}")
        try:
            db.rollback()
        except Exception:
            pass
    finally:
        db.close()


def _daily_backup_job() -> None:
    """
    Her gece 03:00 UTC'de çalışır.
    PostgreSQL advisory lock sayesinde S1 ve S2 aynı anda tetiklense
    bile sadece biri gerçek yedeği alır, diğeri "skipped" olarak geçer.
    """
    db = SessionLocal()
    try:
        from app.services.storage_service import create_daily_backup
        backup = create_daily_backup(db, backup_type="daily")
        if backup:
            print(f"[BACKUP] Günlük yedek başlatıldı: id={backup.id} dosya={backup.filename}")
    except Exception as e:
        print(f"[BACKUP] Günlük yedek hatası: {e}")
        try:
            db.rollback()
        except Exception:
            pass
    finally:
        db.close()


def _storage_health_job() -> None:
    """
    Her 5 dakikada bir storage node'larını ping et, durumlarını güncelle.
    """
    from app.api.topology import emit_topology_event
    db = SessionLocal()
    try:
        from app.models.storage import StorageNode
        from app.services.storage_service import check_node_health

        # Self health heartbeat (her zaman)
        emit_topology_event("health", "backend-s1", "postgres", "DB bağlantı sağlıklı")

        minio_idx = 1
        nodes = db.query(StorageNode).filter(StorageNode.is_active.isnot(None)).order_by(StorageNode.id).all()
        for node in nodes:
            if node.type == "minio":
                node_id = f"minio-s{minio_idx}"
                minio_idx += 1
            elif node.type in ("sftp", "ftp"):
                node_id = "sftp"
            else:
                node_id = "s3-ext"
            try:
                check_node_health(db, node)
                db.refresh(node)
                status_msg = f"{node.name} sağlıklı" if node.is_active else f"{node.name} pasif"
                evt_type = "health" if node.is_active else "error"
                emit_topology_event(evt_type, "backend-s1", node_id, status_msg)
                # Yedek durumu — aktif storage düğümleri için yedek hazır sinyali
                if node.is_active:
                    emit_topology_event("backup", "backend-s1", node_id, f"{node.name} yedek hazır")
            except Exception as e:
                emit_topology_event("error", "backend-s1", node_id, f"{node.name} health check başarısız: {e}")
                print(f"[STORAGE] Health check hatası ({node.name}): {e}")
    except Exception as e:
        print(f"[STORAGE] Health check genel hata: {e}")
        try:
            db.rollback()
        except Exception:
            pass
    finally:
        db.close()


def _verify_replicas_job() -> None:
    """
    Haftada bir Pazar 04:00 UTC'de replica SHA256 doğrulama.
    Uyumsuz replica'ları is_verified=False olarak işaretler.
    """
    db = SessionLocal()
    try:
        from app.services.storage_service import verify_all_replicas_batch
        result = verify_all_replicas_batch(db, batch_size=200)
        print(f"[STORAGE][verify-job] {result['checked']} replica, {result['mismatches']} uyumsuzluk")
    except Exception as e:
        print(f"[STORAGE][verify-job] hata: {e}")
        try:
            db.rollback()
        except Exception:
            pass
    finally:
        db.close()


def _topology_cleanup_job() -> None:
    """Saatte bir 60 dakikadan eski topoloji olaylarını temizle."""
    db = SessionLocal()
    try:
        from app.api.topology import cleanup_topology_events
        cleanup_topology_events(db, max_age_minutes=60)
    except Exception as e:
        print(f"[TOPOLOGY] cleanup hatası: {e}")
    finally:
        db.close()


def _purge_deleted_files_job() -> None:
    """
    Her Pazar 04:30 UTC'de soft-delete edilen dosyaları (30 gün sonra) temizle.
    """
    db = SessionLocal()
    try:
        from app.services.storage_service import purge_deleted_files
        count = purge_deleted_files(db, grace_days=30)
        if count:
            print(f"[STORAGE][purge-job] {count} dosya tamamen silindi")
    except Exception as e:
        print(f"[STORAGE][purge-job] hata: {e}")
        try:
            db.rollback()
        except Exception:
            pass
    finally:
        db.close()


# ── Scheduler başlat / durdur ────────────────────────────────

def start_scheduler() -> None:
    global _scheduler
    if _scheduler is not None:
        return  # Zaten çalışıyor

    sch = BackgroundScheduler(timezone="UTC", daemon=True)

    # Heartbeat: 60 saniyede bir
    sch.add_job(
        _heartbeat_job, "interval", seconds=60,
        id="sync_heartbeat", max_instances=1, coalesce=True,
    )
    # Pull delta: 30 saniyede bir (S2→S1 anlık sync için)
    sch.add_job(
        _pull_delta_job, "interval", seconds=30,
        id="sync_pull_delta", max_instances=1, coalesce=True,
    )
    # Tam snapshot safety net: 30 dakikada bir
    sch.add_job(
        _push_all_full_job, "interval", minutes=30,
        id="sync_push_all_full", max_instances=1, coalesce=True,
    )
    # Günlük yedek: her gece 03:00 UTC (advisory lock → sadece 1 sunucu çalışır)
    sch.add_job(
        _daily_backup_job, "cron", hour=3, minute=0,
        id="storage_daily_backup", max_instances=1, coalesce=True,
    )
    # Storage node health check: 5 dakikada bir
    sch.add_job(
        _storage_health_job, "interval", minutes=5,
        id="storage_health_check", max_instances=1, coalesce=True,
    )
    # Topoloji olay temizliği: saatte bir
    sch.add_job(
        _topology_cleanup_job, "interval", hours=1,
        id="topology_cleanup", max_instances=1, coalesce=True,
    )
    # Replica SHA256 doğrulama: her Pazar 04:00 UTC
    sch.add_job(
        _verify_replicas_job, "cron", day_of_week="sun", hour=4, minute=0,
        id="storage_verify_replicas", max_instances=1, coalesce=True,
    )
    # Soft-delete temizliği: her Pazar 04:30 UTC
    sch.add_job(
        _purge_deleted_files_job, "cron", day_of_week="sun", hour=4, minute=30,
        id="storage_purge_deleted", max_instances=1, coalesce=True,
    )

    sch.start()
    _scheduler = sch
    print(
        "[SYNC] Scheduler başlatıldı "
        "(heartbeat:60s | pull-delta:30s | full-push:30dk | "
        "daily-backup:03:00 UTC | health-check:5dk | "
        "verify-replicas:Pazar 04:00 | purge-deleted:Pazar 04:30)"
    )


def stop_scheduler() -> None:
    global _scheduler
    if _scheduler is None:
        return
    try:
        _scheduler.shutdown(wait=False)
    except Exception:
        pass
    _scheduler = None
