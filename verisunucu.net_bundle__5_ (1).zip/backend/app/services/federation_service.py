"""
Federe okuma servisi — "tek bulut" mimarisi.

Diyagram: "okuma herzaman tüm sunuculardan olucak"
- Yerel DB'deki kayıtlar alınır
- Tüm aktif peer node'lara sorgu gönderilir (paralel)
- Sonuçlar ID'ye göre birleştirilir (yerel öncelikli)
- Döngüsel sorguları önlemek için `_federation=1` parametresi kullanılır
"""
import httpx
import threading
from typing import Any, Dict, List, Optional

_FEDERATION_TIMEOUT = 5.0  # saniye


def _node_headers(node) -> Dict[str, str]:
    """Peer token ile auth header oluştur."""
    from app.services.sync_service import decrypt_secret
    token = decrypt_secret(node.peer_token_encrypted or "")
    return {"Authorization": f"Bearer {token}"}


def federated_fetch(
    db,
    path: str,
    params: Optional[Dict[str, Any]] = None,
    id_field: str = "id",
) -> List[Dict[str, Any]]:
    """
    Tüm aktif peer node'lardan `path` endpoint'ini sorgular.
    Dönen kayıtları birleştirilmiş liste olarak döndürür.

    Döngüyü önle: isteğe `_federation=1` eklenir; bu parametre alan
    endpoint federation yapmaz.
    """
    from app.models.sync_node import SyncNode
    nodes = (
        db.query(SyncNode)
        .filter(
            SyncNode.is_self == False,
            SyncNode.is_active == True,
            SyncNode.url.isnot(None),
            SyncNode.peer_token_encrypted.isnot(None),
        )
        .all()
    )

    remote_items: List[Dict[str, Any]] = []
    query_params = {**(params or {}), "_federation": "1"}

    def _fetch_node(node):
        try:
            url = f"{node.url.rstrip('/')}/api/v1{path}"
            r = httpx.get(url, headers=_node_headers(node), params=query_params, timeout=_FEDERATION_TIMEOUT)
            if r.status_code == 200:
                data = r.json()
                items = data.get("items", data) if isinstance(data, dict) else data
                if isinstance(items, list):
                    with _lock:
                        remote_items.extend(items)
        except Exception as e:
            print(f"[FED] {node.name} ({path}): {e}")

    _lock = threading.Lock()
    threads = [threading.Thread(target=_fetch_node, args=(n,), daemon=True) for n in nodes]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=_FEDERATION_TIMEOUT + 1)

    return remote_items


def merge_with_local(
    local_items: List[Any],
    remote_items: List[Dict[str, Any]],
    id_field: str = "id",
) -> List[Any]:
    """
    Yerel kayıtları öncelikli tut; uzak kayıtlardan sadece
    yerel listede olmayan ID'leri ekle.
    """
    local_ids = set()
    for item in local_items:
        # ORM nesnesi veya dict olabilir
        if isinstance(item, dict):
            local_ids.add(item.get(id_field))
        else:
            local_ids.add(getattr(item, id_field, None))

    extras = [r for r in remote_items if r.get(id_field) not in local_ids]
    return list(local_items) + extras
