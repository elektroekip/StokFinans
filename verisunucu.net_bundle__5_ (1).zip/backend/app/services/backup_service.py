"""
Bayi Backup Service
====================
Bir bayi'nin (tenant sahibi) tüm verilerini şifreli tek dosya olarak paketler.

Dosya formatı (.sfb — StokFinans Backup):
    [HEADER JSON]\n[FERNET TOKEN]
    HEADER örnek: {"backup_id":"<uuid>","version":1,"user_id":42}
    FERNET TOKEN: tek seferlik üretilen Fernet anahtarı ile şifrelenmiş ZIP'in bytes hali.
    ZIP içerikleri:
        data.json   — tüm DB satırları
        files/...   — referans verilen yüklenmiş dosyalar (ürün/işlem görselleri)

Şifreleme anahtarı (= "şifre") her yedekte rastgele üretilir, DB'de
`bayi_backups.password_encrypted` alanında at-rest olarak Fernet ile şifreli saklanır
(uygulama ana Fernet anahtarı SMTP_SECRET_KEY veya DATABASE_URL türevli).

Bayinin kendisi şifreyi göremez. Sadece süperadmin şifreyi DB'den
çözüp dosyayı manuel inceleyebilir. Sistem geri yükleme sırasında
şifreyi backup_id ile DB'den otomatik bulur.
"""

import io
import json
import os
import shutil
import tempfile
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Tuple, Optional, List, Dict, Any

from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy.orm import Session

from app.models import (
    User, Product, Transaction, Category, ActivityLog,
    Payment, SubscriptionEvent, EmployeeInvite, BayiBackup,
    Warranty, DebtorLink,
    BtbCustomer, BtbOrder, BtbOrderItem, BtbPayment, BtbPriceList,
    CustomerVisit, VisitPlan,
    ErpWebhook, ErpSyncLog, PaymentGateway, PosTransaction, DbsAgreement, DbsInvoice,
)
from app.models.device import Device
from app.models.api_key import ApiKey
from app.models.vehicle import Vehicle, VehicleItem, VehicleAssignment, VehicleLog
from app.models.supplier import Supplier, PurchaseOrder, PurchaseOrderItem
from app.utils.crypto import encrypt_secret, decrypt_secret


BACKUPS_DIR = Path("backups")
BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
UPLOADS_DIR = Path("uploads")

CURRENT_BACKUP_VERSION = 1


def _tenant_owner_id(user: User) -> int:
    """Bayinin kendi id'sini veya çalışansa patron id'sini döner."""
    return user.parent_user_id if user.parent_user_id else user.id


def _serialize_row(obj) -> Dict[str, Any]:
    """SQLAlchemy nesnesini JSON-uyumlu dict'e çevir."""
    out = {}
    for col in obj.__table__.columns:
        val = getattr(obj, col.name)
        if isinstance(val, datetime):
            out[col.name] = val.isoformat()
        else:
            out[col.name] = val
    return out


def _collect_referenced_files(rows: List[Dict[str, Any]]) -> List[str]:
    """image_url alanlarından yerel uploads/ dosya isimlerini topla."""
    names = set()
    for r in rows:
        url = r.get("image_url")
        if url and isinstance(url, str) and "/api/v1/files/" in url:
            fname = url.rsplit("/", 1)[-1]
            if fname:
                names.add(fname)
    return list(names)


def _generate_password() -> str:
    """Fernet anahtarı üret — 32 byte URL-safe base64 (44 karakter)."""
    return Fernet.generate_key().decode()


def create_backup(db: Session, requesting_user: User) -> BayiBackup:
    """
    Bayi için yeni şifreli yedek oluşturur.
    Returns: BayiBackup DB kaydı.
    """
    owner_id = _tenant_owner_id(requesting_user)
    owner = db.query(User).filter(User.id == owner_id).first()
    if not owner:
        raise ValueError("Bayi sahibi bulunamadı")

    # 1) Tüm ilgili verileri topla
    products      = [_serialize_row(p) for p in db.query(Product).filter(Product.user_id == owner_id).all()]
    transactions  = [_serialize_row(t) for t in db.query(Transaction).filter(Transaction.user_id == owner_id).all()]
    categories    = [_serialize_row(c) for c in db.query(Category).filter(Category.user_id == owner_id).all()]
    activity_logs = [_serialize_row(l) for l in db.query(ActivityLog).filter(ActivityLog.user_id == owner_id).all()]
    payments      = [_serialize_row(p) for p in db.query(Payment).filter(Payment.user_id == owner_id).all()]
    sub_events    = [_serialize_row(e) for e in db.query(SubscriptionEvent).filter(SubscriptionEvent.user_id == owner_id).all()]
    invites       = [_serialize_row(i) for i in db.query(EmployeeInvite).filter(EmployeeInvite.parent_user_id == owner_id).all()]
    employees     = [_serialize_row(u) for u in db.query(User).filter(User.parent_user_id == owner_id).all()]
    warranties    = [_serialize_row(w) for w in db.query(Warranty).filter(Warranty.user_id == owner_id).all()]
    debtor_links  = [_serialize_row(d) for d in db.query(DebtorLink).filter(DebtorLink.user_id == owner_id).all()]
    devices       = [_serialize_row(d) for d in db.query(Device).filter(Device.user_id == owner_id).all()]
    # API anahtarları — süper admin anahtarları hariç
    api_keys      = [_serialize_row(k) for k in db.query(ApiKey).filter(
                        ApiKey.user_id == owner_id, ApiKey.is_super_admin_key == False  # noqa: E712
                    ).all()]
    # Araçlar ve alt tabloları
    owner_vehicles = db.query(Vehicle).filter(Vehicle.user_id == owner_id).all()
    vehicle_ids    = [v.id for v in owner_vehicles]
    vehicles       = [_serialize_row(v) for v in owner_vehicles]
    vehicle_items  = []
    vehicle_assignments = []
    vehicle_logs   = []
    if vehicle_ids:
        vehicle_items       = [_serialize_row(i) for i in db.query(VehicleItem).filter(VehicleItem.vehicle_id.in_(vehicle_ids)).all()]
        vehicle_assignments = [_serialize_row(a) for a in db.query(VehicleAssignment).filter(VehicleAssignment.vehicle_id.in_(vehicle_ids)).all()]
        vehicle_logs        = [_serialize_row(l) for l in db.query(VehicleLog).filter(VehicleLog.vehicle_id.in_(vehicle_ids)).all()]

    # BTB (B2B) tabloları
    btb_customer_objs  = db.query(BtbCustomer).filter(BtbCustomer.user_id == owner_id).all()
    btb_customers      = [_serialize_row(r) for r in btb_customer_objs]
    btb_order_objs     = db.query(BtbOrder).filter(BtbOrder.user_id == owner_id).all()
    btb_orders         = [_serialize_row(r) for r in btb_order_objs]
    btb_order_ids      = [o.id for o in btb_order_objs]
    btb_order_items    = []
    btb_order_payments = []
    if btb_order_ids:
        btb_order_items    = [_serialize_row(r) for r in db.query(BtbOrderItem).filter(BtbOrderItem.order_id.in_(btb_order_ids)).all()]
        btb_order_payments = [_serialize_row(r) for r in db.query(BtbPayment).filter(BtbPayment.order_id.in_(btb_order_ids)).all()]
    btb_price_lists = [_serialize_row(r) for r in db.query(BtbPriceList).filter(BtbPriceList.user_id == owner_id).all()]

    # Tedarikçi tabloları
    supplier_objs    = db.query(Supplier).filter(Supplier.user_id == owner_id).all()
    suppliers        = [_serialize_row(r) for r in supplier_objs]
    po_objs          = db.query(PurchaseOrder).filter(PurchaseOrder.user_id == owner_id).all()
    purchase_orders  = [_serialize_row(r) for r in po_objs]
    po_ids           = [o.id for o in po_objs]
    purchase_order_items = []
    if po_ids:
        purchase_order_items = [_serialize_row(r) for r in db.query(PurchaseOrderItem).filter(PurchaseOrderItem.order_id.in_(po_ids)).all()]

    # Plasiyer tabloları
    customer_visits = [_serialize_row(r) for r in db.query(CustomerVisit).filter(CustomerVisit.user_id == owner_id).all()]
    visit_plans     = [_serialize_row(r) for r in db.query(VisitPlan).filter(VisitPlan.user_id == owner_id).all()]

    # Entegrasyon tabloları
    erp_webhooks     = [_serialize_row(r) for r in db.query(ErpWebhook).filter(ErpWebhook.user_id == owner_id).all()]
    erp_sync_logs    = [_serialize_row(r) for r in db.query(ErpSyncLog).filter(ErpSyncLog.user_id == owner_id).all()]
    payment_gateways = [_serialize_row(r) for r in db.query(PaymentGateway).filter(PaymentGateway.user_id == owner_id).all()]
    pos_transactions = [_serialize_row(r) for r in db.query(PosTransaction).filter(PosTransaction.user_id == owner_id).all()]
    dbs_agreements   = [_serialize_row(r) for r in db.query(DbsAgreement).filter(DbsAgreement.user_id == owner_id).all()]
    dbs_invoices     = [_serialize_row(r) for r in db.query(DbsInvoice).filter(DbsInvoice.user_id == owner_id).all()]

    owner_dict = _serialize_row(owner)
    dashboard_layout = owner.dashboard_layout  # JSONB — None olabilir

    # 2) Referans verilen dosyaları topla
    referenced = set()
    referenced.update(_collect_referenced_files(products))
    referenced.update(_collect_referenced_files(transactions))

    # 3) JSON payload
    payload = {
        "version": CURRENT_BACKUP_VERSION,
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "owner": owner_dict,
        "dashboard_layout": dashboard_layout,
        "tables": {
            "categories":            categories,
            "employees":             employees,
            "products":              products,
            "devices":               devices,
            "api_keys":              api_keys,
            "vehicles":              vehicles,
            "vehicle_items":         vehicle_items,
            "vehicle_assignments":   vehicle_assignments,
            "vehicle_logs":          vehicle_logs,
            "transactions":          transactions,
            "warranties":            warranties,
            "debtor_links":          debtor_links,
            "activity_logs":         activity_logs,
            "payments":              payments,
            "subscription_events":   sub_events,
            "employee_invites":      invites,
            # BTB (B2B)
            "btb_customers":         btb_customers,
            "btb_orders":            btb_orders,
            "btb_order_items":       btb_order_items,
            "btb_order_payments":    btb_order_payments,
            "btb_price_lists":       btb_price_lists,
            # Tedarikçi
            "suppliers":             suppliers,
            "purchase_orders":       purchase_orders,
            "purchase_order_items":  purchase_order_items,
            # Plasiyer
            "customer_visits":       customer_visits,
            "visit_plans":           visit_plans,
            # Entegrasyon
            "erp_webhooks":          erp_webhooks,
            "erp_sync_logs":         erp_sync_logs,
            "payment_gateways":      payment_gateways,
            "pos_transactions":      pos_transactions,
            "dbs_agreements":        dbs_agreements,
            "dbs_invoices":          dbs_invoices,
        },
    }

    # 4) ZIP oluştur (in-memory)
    zip_buf = io.BytesIO()
    with zipfile.ZipFile(zip_buf, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        zf.writestr("data.json", json.dumps(payload, ensure_ascii=False, default=str))
        for fname in referenced:
            fpath = UPLOADS_DIR / fname
            if fpath.exists() and fpath.is_file():
                try:
                    zf.write(fpath, arcname=f"files/{fname}")
                except Exception:
                    pass
    zip_bytes = zip_buf.getvalue()

    # 5) Şifrele
    password = _generate_password()
    fernet = Fernet(password.encode())
    encrypted = fernet.encrypt(zip_bytes)

    # 6) Header + dosya yaz
    backup_id = str(uuid.uuid4())
    header = {
        "backup_id": backup_id,
        "version": CURRENT_BACKUP_VERSION,
        "user_id": owner_id,
    }
    header_bytes = (json.dumps(header) + "\n").encode("utf-8")
    final_bytes = header_bytes + encrypted

    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    safe_company = (owner.company_name or owner.email or f"user{owner_id}").replace("/", "_").replace(" ", "_")[:40]
    filename = f"stokfinans_yedek_{safe_company}_{ts}.sfb"

    file_path = BACKUPS_DIR / f"{backup_id}.sfb"
    with open(file_path, "wb") as f:
        f.write(final_bytes)

    # 7) DB kaydı
    record = BayiBackup(
        id=backup_id,
        user_id=owner_id,
        filename=filename,
        password_encrypted=encrypt_secret(password),
        size_bytes=len(final_bytes),
    )
    db.add(record)
    db.commit()
    db.refresh(record)

    # 8) Sunucu başına bayi yedek limiti: en fazla MAX_BACKUPS_PER_USER saklanır.
    #    Yeni yedek kaydedildikten sonra eskiden yeniye sıralı liste çekilir;
    #    limit aşılıyorsa en eski kayıtlar (ve disk dosyaları) silinir.
    _enforce_backup_limit(db, owner_id)

    return record


MAX_BACKUPS_PER_USER = 3


def _enforce_backup_limit(db: Session, owner_id: int) -> None:
    """Bayi başına MAX_BACKUPS_PER_USER yedek saklar; fazlasını (en eskiler) siler."""
    all_backups = (
        db.query(BayiBackup)
        .filter(BayiBackup.user_id == owner_id)
        .order_by(BayiBackup.created_at.asc())   # en eski başta
        .all()
    )
    excess = all_backups[: max(0, len(all_backups) - MAX_BACKUPS_PER_USER)]
    for old in excess:
        delete_backup_file(old.id)
        db.delete(old)
    if excess:
        db.commit()


def read_backup_file(backup_id: str) -> bytes:
    """Disk'ten yedek dosyasını okur (indirme için)."""
    file_path = BACKUPS_DIR / f"{backup_id}.sfb"
    if not file_path.exists():
        raise FileNotFoundError(f"Yedek dosyası bulunamadı: {backup_id}")
    with open(file_path, "rb") as f:
        return f.read()


def delete_backup_file(backup_id: str) -> None:
    """Disk'ten yedek dosyasını siler."""
    file_path = BACKUPS_DIR / f"{backup_id}.sfb"
    try:
        if file_path.exists():
            file_path.unlink()
    except Exception:
        pass


def _parse_backup_header(file_bytes: bytes) -> Tuple[Dict[str, Any], bytes]:
    """Header JSON satırını ve geri kalan ciphertext'i ayır."""
    nl = file_bytes.find(b"\n")
    if nl < 0 or nl > 4096:
        raise ValueError("Geçersiz yedek dosyası: header bulunamadı")
    try:
        header = json.loads(file_bytes[:nl].decode("utf-8"))
    except Exception as e:
        raise ValueError(f"Geçersiz yedek başlığı: {e}")
    return header, file_bytes[nl + 1:]


def restore_backup(db: Session, requesting_user: User, file_bytes: bytes) -> Dict[str, Any]:
    """
    Bir yedek dosyasından geri yükleme yapar.
    - Header'dan backup_id okunur
    - DB'den şifre bulunur (yedek bu kullanıcıya ait olmalı)
    - Decrypt → ZIP içeriğini oku → mevcut tenant verilerini sil → yeniden ekle
    - Dosyaları uploads/ dizinine yaz
    """
    owner_id = _tenant_owner_id(requesting_user)

    header, ciphertext = _parse_backup_header(file_bytes)
    backup_id = header.get("backup_id")
    if not backup_id:
        raise ValueError("Yedek dosyasında backup_id yok")

    record: Optional[BayiBackup] = db.query(BayiBackup).filter(BayiBackup.id == backup_id).first()
    if not record:
        raise ValueError("Bu yedek sistem kaydında bulunamadı. Geri yükleme yapılamaz.")

    # Sadece sahibi (veya çalışan tarafından patron için) restore edebilir
    is_super = bool(getattr(requesting_user, "is_super_admin", False))
    if not is_super and record.user_id != owner_id:
        raise PermissionError("Bu yedek sizin işletmenize ait değil")

    password = decrypt_secret(record.password_encrypted)
    if not password:
        raise ValueError("Yedek şifresi okunamadı")

    try:
        fernet = Fernet(password.encode())
        zip_bytes = fernet.decrypt(ciphertext)
    except InvalidToken:
        raise ValueError("Yedek dosyasının bütünlüğü doğrulanamadı (şifre eşleşmiyor veya dosya bozuk)")

    target_owner_id = record.user_id

    # ZIP'i oku
    payload: Dict[str, Any] = {}
    files_to_restore: List[Tuple[str, bytes]] = []
    with zipfile.ZipFile(io.BytesIO(zip_bytes), "r") as zf:
        with zf.open("data.json") as fp:
            payload = json.loads(fp.read().decode("utf-8"))
        for name in zf.namelist():
            if name.startswith("files/") and not name.endswith("/"):
                fname = name[len("files/"):]
                if fname:
                    files_to_restore.append((fname, zf.read(name)))

    tables = payload.get("tables", {})

    # === Mevcut tenant verilerini sil — FK bağımlılık sırasına göre tersden ===

    # Entegrasyon yaprak tablolar (leaf → parent)
    db.query(DbsInvoice).filter(DbsInvoice.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(PosTransaction).filter(PosTransaction.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(ErpSyncLog).filter(ErpSyncLog.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(DbsAgreement).filter(DbsAgreement.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(PaymentGateway).filter(PaymentGateway.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(ErpWebhook).filter(ErpWebhook.user_id == target_owner_id).delete(synchronize_session=False)

    # Plasiyer
    db.query(CustomerVisit).filter(CustomerVisit.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(VisitPlan).filter(VisitPlan.user_id == target_owner_id).delete(synchronize_session=False)

    # Tedarikçi
    existing_po_ids = [r.id for r in db.query(PurchaseOrder.id).filter(PurchaseOrder.user_id == target_owner_id).all()]
    if existing_po_ids:
        db.query(PurchaseOrderItem).filter(PurchaseOrderItem.order_id.in_(existing_po_ids)).delete(synchronize_session=False)
    db.query(PurchaseOrder).filter(PurchaseOrder.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(Supplier).filter(Supplier.user_id == target_owner_id).delete(synchronize_session=False)

    # BTB — önce child tablolar, sonra orders, sonra customers (RESTRICT FK)
    existing_btb_order_ids = [r.id for r in db.query(BtbOrder.id).filter(BtbOrder.user_id == target_owner_id).all()]
    if existing_btb_order_ids:
        db.query(BtbOrderItem).filter(BtbOrderItem.order_id.in_(existing_btb_order_ids)).delete(synchronize_session=False)
        db.query(BtbPayment).filter(BtbPayment.order_id.in_(existing_btb_order_ids)).delete(synchronize_session=False)
    db.query(BtbPriceList).filter(BtbPriceList.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(BtbOrder).filter(BtbOrder.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(BtbCustomer).filter(BtbCustomer.user_id == target_owner_id).delete(synchronize_session=False)

    db.query(ActivityLog).filter(ActivityLog.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(SubscriptionEvent).filter(SubscriptionEvent.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(Payment).filter(Payment.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(EmployeeInvite).filter(EmployeeInvite.parent_user_id == target_owner_id).delete(synchronize_session=False)
    db.query(DebtorLink).filter(DebtorLink.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(Warranty).filter(Warranty.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(Transaction).filter(Transaction.user_id == target_owner_id).delete(synchronize_session=False)
    # Araç alt tabloları (CASCADE olduğu hâlde explicit sil — güvenli sıra için)
    existing_vehicle_ids = [
        v.id for v in db.query(Vehicle.id).filter(Vehicle.user_id == target_owner_id).all()
    ]
    if existing_vehicle_ids:
        db.query(VehicleLog).filter(VehicleLog.vehicle_id.in_(existing_vehicle_ids)).delete(synchronize_session=False)
        db.query(VehicleAssignment).filter(VehicleAssignment.vehicle_id.in_(existing_vehicle_ids)).delete(synchronize_session=False)
        db.query(VehicleItem).filter(VehicleItem.vehicle_id.in_(existing_vehicle_ids)).delete(synchronize_session=False)
        db.query(Vehicle).filter(Vehicle.id.in_(existing_vehicle_ids)).delete(synchronize_session=False)
    db.query(Device).filter(Device.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(ApiKey).filter(ApiKey.user_id == target_owner_id, ApiKey.is_super_admin_key == False).delete(synchronize_session=False)  # noqa: E712
    db.query(Product).filter(Product.user_id == target_owner_id).delete(synchronize_session=False)
    db.query(Category).filter(Category.user_id == target_owner_id).delete(synchronize_session=False)
    # Çalışan kullanıcıları sil (yedekten geri eklenecek)
    db.query(User).filter(User.parent_user_id == target_owner_id).delete(synchronize_session=False)
    db.flush()

    # === Owner kullanıcı kaydını güncelle (id ve email değiştirilmez) ===
    owner_data = payload.get("owner") or {}
    owner_obj = db.query(User).filter(User.id == target_owner_id).first()
    if owner_obj and owner_data:
        protected = {"id", "email", "password_hash", "is_super_admin", "created_at"}
        for k, v in owner_data.items():
            if k in protected:
                continue
            if hasattr(owner_obj, k):
                try:
                    setattr(owner_obj, k, _coerce_value(owner_obj, k, v))
                except Exception:
                    pass

    # === Dashboard düzenini geri yükle ===
    if owner_obj and "dashboard_layout" in payload and payload["dashboard_layout"] is not None:
        owner_obj.dashboard_layout = payload["dashboard_layout"]

    counts = {}

    # assigned_by_user_id → restore sonrası referans edilecek kullanıcı
    # mevcut olmayabilir (örn. silinen süper admin); NULL olarak yazılır.
    NULLIFY_MISSING: Dict[str, List[str]] = {
        "vehicle_assignments": ["assigned_by_user_id"],
    }

    def _bulk_insert(model_cls, rows, force_user_id_field: Optional[str] = None):
        if not rows:
            counts[model_cls.__tablename__] = 0
            return
        cols = {c.name for c in model_cls.__table__.columns}
        null_fields = NULLIFY_MISSING.get(model_cls.__tablename__, [])
        cleaned = []
        for row in rows:
            filtered = {k: v for k, v in row.items() if k in cols}
            # tenant id alanını zorla
            if force_user_id_field and force_user_id_field in cols:
                filtered[force_user_id_field] = target_owner_id
            # Yedekte olmayan tablolara FK olan alanları NULL yap
            for field in null_fields:
                if field in filtered:
                    filtered[field] = None
            cleaned.append(filtered)
        if cleaned:
            db.bulk_insert_mappings(model_cls, cleaned)
        counts[model_cls.__tablename__] = len(cleaned)

    # FK sıralaması (bağımlılık sırasına göre):
    _bulk_insert(Category,           tables.get("categories", []),           "user_id")
    _bulk_insert(User,               tables.get("employees", []),            "parent_user_id")
    _bulk_insert(Product,            tables.get("products", []),             "user_id")
    _bulk_insert(Device,             tables.get("devices", []),              "user_id")
    _bulk_insert(ApiKey,             tables.get("api_keys", []),             "user_id")
    _bulk_insert(Vehicle,            tables.get("vehicles", []),             "user_id")
    _bulk_insert(VehicleItem,        tables.get("vehicle_items", []))
    _bulk_insert(VehicleAssignment,  tables.get("vehicle_assignments", []))
    _bulk_insert(VehicleLog,         tables.get("vehicle_logs", []))
    _bulk_insert(Transaction,        tables.get("transactions", []),         "user_id")
    _bulk_insert(Warranty,           tables.get("warranties", []),           "user_id")
    _bulk_insert(DebtorLink,         tables.get("debtor_links", []),         "user_id")
    _bulk_insert(Payment,            tables.get("payments", []),             "user_id")
    _bulk_insert(SubscriptionEvent,  tables.get("subscription_events", []), "user_id")
    _bulk_insert(ActivityLog,        tables.get("activity_logs", []),        "user_id")
    _bulk_insert(EmployeeInvite,     tables.get("employee_invites", []),     "parent_user_id")
    # BTB (FK sırasına göre: customers → orders → items/payments → price_lists)
    _bulk_insert(BtbCustomer,       tables.get("btb_customers", []),        "user_id")
    _bulk_insert(BtbOrder,          tables.get("btb_orders", []),           "user_id")
    _bulk_insert(BtbOrderItem,      tables.get("btb_order_items", []))
    _bulk_insert(BtbPayment,        tables.get("btb_order_payments", []))
    _bulk_insert(BtbPriceList,      tables.get("btb_price_lists", []),      "user_id")
    # Tedarikçi
    _bulk_insert(Supplier,          tables.get("suppliers", []),            "user_id")
    _bulk_insert(PurchaseOrder,     tables.get("purchase_orders", []),      "user_id")
    _bulk_insert(PurchaseOrderItem, tables.get("purchase_order_items", []))
    # Plasiyer
    _bulk_insert(CustomerVisit,     tables.get("customer_visits", []),      "user_id")
    _bulk_insert(VisitPlan,         tables.get("visit_plans", []),          "user_id")
    # Entegrasyon
    _bulk_insert(ErpWebhook,        tables.get("erp_webhooks", []),         "user_id")
    _bulk_insert(ErpSyncLog,        tables.get("erp_sync_logs", []),        "user_id")
    _bulk_insert(PaymentGateway,    tables.get("payment_gateways", []),     "user_id")
    _bulk_insert(PosTransaction,    tables.get("pos_transactions", []),     "user_id")
    _bulk_insert(DbsAgreement,      tables.get("dbs_agreements", []),       "user_id")
    _bulk_insert(DbsInvoice,        tables.get("dbs_invoices", []),         "user_id")

    # Dosyaları önce temp dizine yaz; DB commit BAŞARILI olursa nihai konuma taşı.
    # Bu sayede DB rollback olursa diskte yarım kalmış dosya kalmaz.
    UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
    temp_dir = Path(tempfile.mkdtemp(prefix="sfb_restore_"))
    staged: List[Tuple[Path, Path]] = []  # (temp_path, final_path)
    written_files = 0
    try:
        for fname, content in files_to_restore:
            safe = os.path.basename(fname)
            if not safe:
                continue
            tp = temp_dir / safe
            try:
                with open(tp, "wb") as fp:
                    fp.write(content)
                staged.append((tp, UPLOADS_DIR / safe))
            except Exception:
                pass

        record.restored_at = datetime.now(timezone.utc)
        db.commit()  # Önce DB commit; başarısız olursa dosyalar taşınmaz.

        for tp, final_path in staged:
            try:
                shutil.move(str(tp), str(final_path))
                written_files += 1
            except Exception:
                pass
    finally:
        try:
            shutil.rmtree(temp_dir, ignore_errors=True)
        except Exception:
            pass

    return {
        "backup_id": backup_id,
        "restored_owner_id": target_owner_id,
        "tables": counts,
        "files_restored": written_files,
    }


def _coerce_value(obj, key: str, value: Any) -> Any:
    """JSON'dan dönen değerleri SQLAlchemy column tipine uygun hale getir."""
    if value is None:
        return None
    col = obj.__table__.columns.get(key)
    if col is None:
        return value
    py_type = getattr(col.type, "python_type", None)
    try:
        if py_type is datetime and isinstance(value, str):
            try:
                return datetime.fromisoformat(value)
            except Exception:
                return value
    except NotImplementedError:
        pass
    return value
