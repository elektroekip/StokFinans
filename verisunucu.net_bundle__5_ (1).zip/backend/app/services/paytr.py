"""
PayTR iframe API entegrasyonu.
- init_payment: paytr_token üretmek için PayTR'ye POST atar
- verify_callback: IPN POST'unun hash'ini doğrular
"""
from __future__ import annotations
import base64
import hashlib
import hmac
import re
import json
import urllib.parse
import urllib.request
from typing import Optional


PAYTR_API_URL = "https://www.paytr.com/odeme/api/get-token"


def _ascii(value: str) -> str:
    """PayTR sadece basic ASCII kabul ediyor; Türkçe karakterleri normalize et."""
    if not value:
        return ""
    s = str(value)
    repl = {"ı": "i", "İ": "I", "ş": "s", "Ş": "S", "ğ": "g", "Ğ": "G",
            "ü": "u", "Ü": "U", "ö": "o", "Ö": "O", "ç": "c", "Ç": "C"}
    for k, v in repl.items():
        s = s.replace(k, v)
    s = re.sub(r"[^A-Za-z0-9 .,_\-@]", "", s)
    return s[:60]


def init_payment(
    *,
    merchant_id: str,
    merchant_key: str,
    merchant_salt: str,
    test_mode: bool,
    merchant_oid: str,
    amount_kurus: int,
    user_email: str,
    user_name: str,
    user_phone: str,
    user_address: str,
    user_ip: str,
    user_basket: list,
    success_url: str,
    fail_url: str,
    timeout_limit: int = 30,
    no_installment: int = 0,
    max_installment: int = 0,
    currency: str = "TL",
    lang: str = "tr",
) -> dict:
    """
    PayTR get-token endpoint'ine istek atar. Başarılıysa {'status':'success','token':...} döner.
    """
    if not (merchant_id and merchant_key and merchant_salt):
        return {"status": "failed", "reason": "PayTR ayarları eksik (Süper Admin > PayTR)."}

    # PayTR user_basket'i JSON list (str list) olarak ister, base64'lenmiş
    basket_b64 = base64.b64encode(json.dumps(user_basket, ensure_ascii=False).encode("utf-8")).decode("utf-8")

    hash_str = (
        f"{merchant_id}{user_ip}{merchant_oid}{user_email}{amount_kurus}"
        f"{basket_b64}{no_installment}{max_installment}{currency}{int(test_mode)}"
    )
    paytr_token = base64.b64encode(
        hmac.new(merchant_key.encode("utf-8"),
                 (hash_str + merchant_salt).encode("utf-8"),
                 hashlib.sha256).digest()
    ).decode("utf-8")

    payload = {
        "merchant_id": merchant_id,
        "user_ip": user_ip,
        "merchant_oid": merchant_oid,
        "email": user_email,
        "payment_amount": amount_kurus,
        "paytr_token": paytr_token,
        "user_basket": basket_b64,
        "debug_on": 1,
        "no_installment": no_installment,
        "max_installment": max_installment,
        "user_name": _ascii(user_name) or "Musteri",
        "user_address": _ascii(user_address) or "Turkiye",
        "user_phone": _ascii(user_phone) or "05000000000",
        "merchant_ok_url": success_url,
        "merchant_fail_url": fail_url,
        "timeout_limit": timeout_limit,
        "currency": currency,
        "test_mode": int(test_mode),
        "lang": lang,
    }

    try:
        body = urllib.parse.urlencode(payload).encode("utf-8")
        req = urllib.request.Request(
            PAYTR_API_URL, data=body,
            headers={"Content-Type": "application/x-www-form-urlencoded"}
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        return {"status": "failed", "reason": f"PayTR bağlantı hatası: {e}"}

    if data.get("status") == "success":
        return {"status": "success", "token": data["token"]}
    return {"status": "failed", "reason": data.get("reason", "PayTR token alınamadı")}


def verify_callback(
    *,
    merchant_oid: str,
    merchant_salt: str,
    merchant_key: str,
    status: str,
    total_amount: str,
    received_hash: str,
) -> bool:
    hash_str = f"{merchant_oid}{merchant_salt}{status}{total_amount}"
    expected = base64.b64encode(
        hmac.new(merchant_key.encode("utf-8"), hash_str.encode("utf-8"), hashlib.sha256).digest()
    ).decode("utf-8")
    return hmac.compare_digest(expected, received_hash or "")
