"""
In-memory frame store + QR/barcode detection.
Frames are keyed by device_id and expire after 30 s with no refresh.
"""
from __future__ import annotations

import base64
import io
import time
from dataclasses import dataclass, field
from typing import Optional

_frames: dict[str, "_Frame"] = {}


@dataclass
class _Frame:
    jpeg_b64: str
    width: int
    height: int
    codes: list[str]
    ts: float = field(default_factory=time.time)


def _zbar_scan(img_pil, seen: set, codes: list, zbar_decode) -> bool:
    """Scan one PIL image variant; return True if anything new was found."""
    found = False
    for obj in zbar_decode(img_pil):
        text = obj.data.decode("utf-8", errors="replace").strip()
        if text and text not in seen:
            seen.add(text)
            codes.append(text)
            found = True
    return found


def process_frame(device_id: str, jpeg_bytes: bytes) -> list[str]:
    """Decode QR/barcodes in the JPEG, store the frame, return found codes."""
    codes: list[str] = []
    w, h = 0, 0

    try:
        from PIL import Image, ImageEnhance, ImageFilter
        img = Image.open(io.BytesIO(jpeg_bytes))
        w, h = img.width, img.height

        try:
            from pyzbar.pyzbar import decode as zbar_decode
            seen: set[str] = set()

            # Pass 1 — grayscale (fastest, best for QR)
            gray = img.convert("L")
            if not _zbar_scan(gray, seen, codes, zbar_decode):

                # Pass 2 — 2× upscale (1D barkodlar için kritik: modül başına piksel artar)
                # 320×240 → 640×480: EAN-13 güvenle okunabilir seviyeye gelir
                big = gray.resize((w * 2, h * 2), Image.LANCZOS)
                if not _zbar_scan(big, seen, codes, zbar_decode):

                    # Pass 3 — kontrast + keskinlik artırılmış büyütülmüş görüntü
                    sharp = ImageEnhance.Contrast(big).enhance(2.0)
                    sharp = ImageEnhance.Sharpness(sharp).enhance(2.0)
                    _zbar_scan(sharp, seen, codes, zbar_decode)

        except ImportError:
            pass
    except Exception:
        pass

    _frames[device_id] = _Frame(
        jpeg_b64=base64.b64encode(jpeg_bytes).decode(),
        width=w,
        height=h,
        codes=codes,
        ts=time.time(),
    )
    return codes


def get_frame(device_id: str) -> Optional[_Frame]:
    f = _frames.get(device_id)
    if f is None:
        return None
    if time.time() - f.ts > 30:
        del _frames[device_id]
        return None
    return f
