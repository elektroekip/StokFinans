import smtplib
import ssl
import secrets
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timezone, timedelta
from sqlalchemy.orm import Session
from app.models.smtp_setting import SmtpSetting
from app.utils.crypto import decrypt_secret


def get_smtp_settings(db: Session):
    s = db.query(SmtpSetting).filter(SmtpSetting.id == 1).first()
    if not s or not s.is_configured:
        return None
    return s


def generate_verification_token() -> str:
    return secrets.token_urlsafe(32)


def get_token_expiry() -> datetime:
    return datetime.now(timezone.utc) + timedelta(hours=24)


def send_verification_email(db: Session, to_email: str, token: str, full_name: str, base_url: str) -> bool:
    s = get_smtp_settings(db)
    if not s:
        return False

    verify_url = f"{base_url}/?action=verify&token={token}"

    subject = "StokFinans - E-posta Adresinizi Doğrulayın"
    body_text = f"""Merhaba {full_name},

StokFinans'a hoş geldiniz!

E-posta adresinizi doğrulamak için aşağıdaki bağlantıya tıklayın:

{verify_url}

Bu bağlantı 24 saat geçerlidir.

Eğer bu kaydı siz yapmadıysanız, bu e-postayı görmezden gelebilirsiniz.

İyi çalışmalar,
StokFinans Ekibi
"""

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = f"{s.from_name or 'StokFinans'} <{s.from_email}>"
    msg["To"] = to_email

    body_html = f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: Arial, sans-serif; background: #f8fafc; padding: 32px;">
  <div style="max-width: 480px; margin: 0 auto; background: #fff; border-radius: 16px; padding: 32px; border: 1px solid #e2e8f0;">
    <h2 style="color: #4f46e5; margin-bottom: 8px;">E-posta Doğrulama</h2>
    <p style="color: #475569;">Merhaba <strong>{full_name}</strong>,</p>
    <p style="color: #475569;">StokFinans'a hoş geldiniz! E-posta adresinizi doğrulamak için aşağıdaki butona tıklayın.</p>
    <div style="text-align: center; margin: 32px 0;">
      <a href="{verify_url}" style="background: #4f46e5; color: #fff; padding: 14px 32px; border-radius: 10px; text-decoration: none; font-weight: bold; font-size: 15px;">E-postamı Doğrula</a>
    </div>
    <p style="color: #94a3b8; font-size: 12px;">Bu bağlantı 24 saat geçerlidir. Kaydı siz yapmadıysanız bu e-postayı görmezden gelebilirsiniz.</p>
    <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 24px 0;">
    <p style="color: #94a3b8; font-size: 11px; text-align: center;">StokFinans Stok & Finans Yönetimi</p>
  </div>
</body>
</html>"""

    msg.attach(MIMEText(body_text, "plain", "utf-8"))
    msg.attach(MIMEText(body_html, "html", "utf-8"))

    pwd = decrypt_secret(s.password or "")
    try:
        if s.use_ssl:
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(s.host, s.port, context=context, timeout=15) as server:
                server.login(s.username, pwd)
                server.sendmail(s.from_email, [to_email], msg.as_string())
        else:
            with smtplib.SMTP(s.host, s.port, timeout=15) as server:
                if s.use_tls:
                    context = ssl.create_default_context()
                    server.starttls(context=context)
                server.login(s.username, pwd)
                server.sendmail(s.from_email, [to_email], msg.as_string())
        return True
    except Exception as exc:
        print(f"[EMAIL] Gönderim hatası: {exc}")
        return False


def send_email_change_verification_email(db: Session, to_email: str, token: str, full_name: str, base_url: str) -> bool:
    s = get_smtp_settings(db)
    if not s:
        return False

    verify_url = f"{base_url}/?action=confirm-email-change&token={token}"

    subject = "StokFinans - Yeni E-posta Adresinizi Doğrulayın"
    body_text = f"""Merhaba {full_name},

Hesabınızın e-posta adresi değiştirme talebinde bulundunuz.

Yeni e-posta adresinizi ({to_email}) doğrulamak için aşağıdaki bağlantıya tıklayın:

{verify_url}

Bu bağlantı 24 saat geçerlidir.

Mevcut e-posta adresiniz, siz doğrulama yapana kadar aktif olmaya devam eder.

Eğer bu değişikliği siz yapmadıysanız, bu e-postayı görmezden gelebilirsiniz.

İyi çalışmalar,
StokFinans Ekibi
"""

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = f"{s.from_name or 'StokFinans'} <{s.from_email}>"
    msg["To"] = to_email

    body_html = f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: Arial, sans-serif; background: #f8fafc; padding: 32px;">
  <div style="max-width: 480px; margin: 0 auto; background: #fff; border-radius: 16px; padding: 32px; border: 1px solid #e2e8f0;">
    <h2 style="color: #4f46e5; margin-bottom: 8px;">E-posta Adresi Değişikliği</h2>
    <p style="color: #475569;">Merhaba <strong>{full_name}</strong>,</p>
    <p style="color: #475569;">Hesabınızdaki e-posta adresini <strong>{to_email}</strong> olarak değiştirme talebinde bulundunuz. Yeni adresinizi doğrulamak için aşağıdaki butona tıklayın.</p>
    <div style="text-align: center; margin: 32px 0;">
      <a href="{verify_url}" style="background: #4f46e5; color: #fff; padding: 14px 32px; border-radius: 10px; text-decoration: none; font-weight: bold; font-size: 15px;">Yeni E-postamı Doğrula</a>
    </div>
    <p style="color: #94a3b8; font-size: 12px;">Bu bağlantı 24 saat geçerlidir. Mevcut e-posta adresiniz doğrulama yapılana kadar aktif kalmaya devam eder. Bu değişikliği siz yapmadıysanız bu e-postayı görmezden gelebilirsiniz.</p>
    <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 24px 0;">
    <p style="color: #94a3b8; font-size: 11px; text-align: center;">StokFinans Stok & Finans Yönetimi</p>
  </div>
</body>
</html>"""

    msg.attach(MIMEText(body_text, "plain", "utf-8"))
    msg.attach(MIMEText(body_html, "html", "utf-8"))

    pwd = decrypt_secret(s.password or "")
    try:
        if s.use_ssl:
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(s.host, s.port, context=context, timeout=15) as server:
                server.login(s.username, pwd)
                server.sendmail(s.from_email, [to_email], msg.as_string())
        else:
            with smtplib.SMTP(s.host, s.port, timeout=15) as server:
                if s.use_tls:
                    context = ssl.create_default_context()
                    server.starttls(context=context)
                server.login(s.username, pwd)
                server.sendmail(s.from_email, [to_email], msg.as_string())
        return True
    except Exception as exc:
        print(f"[EMAIL] E-posta değişikliği doğrulama maili hatası: {exc}")
        return False


def send_email_change_alert_email(db: Session, to_email: str, new_email: str, full_name: str, base_url: str) -> bool:
    """Mevcut (eski) e-posta adresine, e-posta değiştirme talebi yapıldığına dair güvenlik uyarı maili gönderir."""
    s = get_smtp_settings(db)
    if not s:
        return False

    cancel_url = f"{base_url}/?action=cancel-email-change"

    subject = "StokFinans - Güvenlik Uyarısı: E-posta Değişikliği Talebi"
    body_text = f"""Merhaba {full_name},

Hesabınız için yeni bir e-posta adresi ({new_email}) belirleme talebinde bulunuldu.

Mevcut e-posta adresiniz, yeni adres doğrulanana kadar aktif olmaya devam eder.

Bu talebi SİZ yaptıysanız, herhangi bir işlem yapmanıza gerek yoktur. Yeni adresinize gönderilen doğrulama bağlantısına tıklayarak değişikliği tamamlayabilirsiniz.

Bu talebi SİZ YAPMADIYSANIZ, hesabınızın güvenliği tehlikede olabilir. Lütfen aşağıdaki bağlantıdan hesabınıza giriş yapıp talebi iptal edin ve şifrenizi değiştirin:

{cancel_url}

Sorun devam ederse veya hesabınıza erişemiyorsanız lütfen destek ekibimizle iletişime geçin.

İyi çalışmalar,
StokFinans Ekibi
"""

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = f"{s.from_name or 'StokFinans'} <{s.from_email}>"
    msg["To"] = to_email

    body_html = f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: Arial, sans-serif; background: #f8fafc; padding: 32px;">
  <div style="max-width: 480px; margin: 0 auto; background: #fff; border-radius: 16px; padding: 32px; border: 1px solid #e2e8f0;">
    <h2 style="color: #dc2626; margin-bottom: 8px;">Güvenlik Uyarısı: E-posta Değişikliği Talebi</h2>
    <p style="color: #475569;">Merhaba <strong>{full_name}</strong>,</p>
    <p style="color: #475569;">Hesabınız için yeni bir e-posta adresi (<strong>{new_email}</strong>) belirleme talebinde bulunuldu. Mevcut e-posta adresiniz, yeni adres doğrulanana kadar aktif olmaya devam eder.</p>
    <div style="background: #fef2f2; border-left: 4px solid #dc2626; padding: 12px 16px; margin: 20px 0; border-radius: 6px;">
      <p style="color: #991b1b; margin: 0; font-size: 14px;"><strong>Bu talebi siz yapmadıysanız</strong>, hesabınızın güvenliği tehlikede olabilir. Lütfen hemen hesabınıza giriş yapıp talebi iptal edin ve şifrenizi değiştirin.</p>
    </div>
    <div style="text-align: center; margin: 32px 0;">
      <a href="{cancel_url}" style="background: #dc2626; color: #fff; padding: 14px 32px; border-radius: 10px; text-decoration: none; font-weight: bold; font-size: 15px;">Talebi İptal Et</a>
    </div>
    <p style="color: #94a3b8; font-size: 12px;">Bu talebi siz yaptıysanız herhangi bir işlem yapmanıza gerek yoktur; yeni adresinize gönderilen doğrulama bağlantısına tıklayarak değişikliği tamamlayabilirsiniz. Hesabınıza erişemiyorsanız lütfen destek ekibimizle iletişime geçin.</p>
    <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 24px 0;">
    <p style="color: #94a3b8; font-size: 11px; text-align: center;">StokFinans Stok & Finans Yönetimi</p>
  </div>
</body>
</html>"""

    msg.attach(MIMEText(body_text, "plain", "utf-8"))
    msg.attach(MIMEText(body_html, "html", "utf-8"))

    pwd = decrypt_secret(s.password or "")
    try:
        if s.use_ssl:
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(s.host, s.port, context=context, timeout=15) as server:
                server.login(s.username, pwd)
                server.sendmail(s.from_email, [to_email], msg.as_string())
        else:
            with smtplib.SMTP(s.host, s.port, timeout=15) as server:
                if s.use_tls:
                    context = ssl.create_default_context()
                    server.starttls(context=context)
                server.login(s.username, pwd)
                server.sendmail(s.from_email, [to_email], msg.as_string())
        return True
    except Exception as exc:
        print(f"[EMAIL] E-posta değişikliği uyarı maili hatası: {exc}")
        return False


def send_password_reset_email(db: Session, to_email: str, token: str, full_name: str, base_url: str) -> bool:
    s = get_smtp_settings(db)
    if not s:
        return False

    reset_url = f"{base_url}/?action=reset-password&token={token}"

    subject = "StokFinans - Şifre Sıfırlama"
    body_text = f"""Merhaba {full_name},

StokFinans hesabınız için şifre sıfırlama talebinde bulundunuz.

Şifrenizi sıfırlamak için aşağıdaki bağlantıya tıklayın:

{reset_url}

Bu bağlantı 1 saat geçerlidir. Eğer bu talebi siz yapmadıysanız, bu e-postayı görmezden gelebilirsiniz.

İyi çalışmalar,
StokFinans Ekibi
"""

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = f"{s.from_name or 'StokFinans'} <{s.from_email}>"
    msg["To"] = to_email

    body_html = f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: Arial, sans-serif; background: #f8fafc; padding: 32px;">
  <div style="max-width: 480px; margin: 0 auto; background: #fff; border-radius: 16px; padding: 32px; border: 1px solid #e2e8f0;">
    <h2 style="color: #4f46e5; margin-bottom: 8px;">Şifre Sıfırlama</h2>
    <p style="color: #475569;">Merhaba <strong>{full_name}</strong>,</p>
    <p style="color: #475569;">StokFinans hesabınız için şifre sıfırlama talebinde bulundunuz. Aşağıdaki butona tıklayarak yeni şifrenizi belirleyin.</p>
    <div style="text-align: center; margin: 32px 0;">
      <a href="{reset_url}" style="background: #4f46e5; color: #fff; padding: 14px 32px; border-radius: 10px; text-decoration: none; font-weight: bold; font-size: 15px;">Şifremi Sıfırla</a>
    </div>
    <p style="color: #94a3b8; font-size: 12px;">Bu bağlantı 1 saat geçerlidir. Talebi siz yapmadıysanız bu e-postayı görmezden gelebilirsiniz.</p>
    <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 24px 0;">
    <p style="color: #94a3b8; font-size: 11px; text-align: center;">StokFinans Stok & Finans Yönetimi</p>
  </div>
</body>
</html>"""

    msg.attach(MIMEText(body_text, "plain", "utf-8"))
    msg.attach(MIMEText(body_html, "html", "utf-8"))

    pwd = decrypt_secret(s.password or "")
    try:
        if s.use_ssl:
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(s.host, s.port, context=context, timeout=15) as server:
                server.login(s.username, pwd)
                server.sendmail(s.from_email, [to_email], msg.as_string())
        else:
            with smtplib.SMTP(s.host, s.port, timeout=15) as server:
                if s.use_tls:
                    context = ssl.create_default_context()
                    server.starttls(context=context)
                server.login(s.username, pwd)
                server.sendmail(s.from_email, [to_email], msg.as_string())
        return True
    except Exception as exc:
        print(f"[EMAIL] Şifre sıfırlama maili hatası: {exc}")
        return False


def test_smtp_connection(host: str, port: int, username: str, password: str,
                         use_tls: bool, use_ssl: bool) -> tuple[bool, str]:
    try:
        if use_ssl:
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(host, port, context=context, timeout=10) as server:
                server.login(username, password)
        else:
            with smtplib.SMTP(host, port, timeout=10) as server:
                if use_tls:
                    context = ssl.create_default_context()
                    server.starttls(context=context)
                server.login(username, password)
        return True, "Bağlantı başarılı"
    except Exception as exc:
        return False, str(exc)
