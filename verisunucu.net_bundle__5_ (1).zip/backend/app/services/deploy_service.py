"""
Uzak Dağıtım Servisi — uygulama kaynak dosyalarını ZIP olarak paketler/çözer ve
Docker containerları yeniden başlatır.

Akış (alıcı sunucuda):
  1. /sync/deploy  →  ZIP kaydedilir + arka planda deploy thread başlatılır
  2. Thread: ZIP çıkarılır → dosyalar kopyalanır → docker compose build (image'lar oluşturulur)
  3. Thread: bağımsız "deployer" container başlatılır (docker run -d)
  4. Deployer: docker compose up -d --no-build (eski container'lar durdurulur, yeniler başlatılır)
  5. Yeni backend açılırken startup'ta finalize_deploy_on_startup() çağrılır → "done"

Neden ayrı deployer container?
  docker compose up eski backend container'ı durdurduğunda, bu komutu çalıştıran
  thread (eski backend içinde) de ölür → yeni container hiç başlatılamaz.
  Çözüm: önce sadece image'ları build et (çalışan container'lara dokunmadan),
  sonra yeniden başlatmayı bağımsız bir container'da yürüt.

Durum dosyası: DEPLOY_APP_ROOT/.deploy_status.json  (host dizinine yazılır)
"""
from __future__ import annotations

import io
import json
import os
import shutil
import subprocess
import threading
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

# Proje kök dizini — docker-compose.yml'de /opt/app_root olarak mount edilir
APP_ROOT = Path(os.environ.get("DEPLOY_APP_ROOT", "/opt/app_root"))
STATUS_FILE = APP_ROOT / ".deploy_status.json"
DEPLOY_TMP = APP_ROOT / ".deploy_tmp"

EXCLUDE_DIRS = {
    "node_modules", "__pycache__", ".git", ".deploy_tmp",
    "backend_logs", "frontend_logs", ".local",
}
EXCLUDE_NAMES = {
    ".deploy_status.json", "docker-build.log", "zipFile.zip",
}
# Bundle'a dahil edilir ama remote deploy sırasında karşı sunucunun dosyasının
# üzerine yazılmaz — her sunucunun kendi compose konfigürasyonu olduğu için.
DEPLOY_SKIP_NAMES = {
    "docker-compose.yml", "docker-compose.yaml",
    "docker-compose.dev.yml", "docker-compose.prod.yml",
    "docker-compose.staging.yml",
}
EXCLUDE_PREFIXES = (".",)
EXCLUDE_EXTENSIONS = {".pyc", ".pyo", ".log"}
EXCLUDE_SUBTREES = {
    "backend/backups",
    "backend/firmwares",
    "backend/tests",
    "frontend/dist",      # build artefaktı — hedef sunucu kendi build eder
    "staging",            # staging-only dosyalar production S2'ye gitmez
}


def _write_status(
    step: str,
    message: str,
    done: bool = False,
    error: Optional[str] = None,
) -> None:
    try:
        STATUS_FILE.parent.mkdir(parents=True, exist_ok=True)
        STATUS_FILE.write_text(
            json.dumps(
                {
                    "step": step,
                    "message": message,
                    "done": done,
                    "error": error,
                    "ts": datetime.now(timezone.utc).isoformat(),
                },
                ensure_ascii=False,
            )
        )
    except Exception:
        pass


def get_deploy_status() -> Dict[str, Any]:
    """Mevcut deploy durumunu döndürür."""
    if not STATUS_FILE.exists():
        return {
            "step": "idle",
            "message": "Beklemede",
            "done": False,
            "error": None,
            "ts": None,
        }
    try:
        return json.loads(STATUS_FILE.read_text())
    except Exception:
        return {
            "step": "error",
            "message": "Durum dosyası okunamadı",
            "done": False,
            "error": "parse hatası",
            "ts": None,
        }


def finalize_deploy_on_startup() -> None:
    """
    main.py startup'ında çağrılır.
    Eğer sunucu 'rebuilding'/'restarting' adımında ölmüşse (yeniden başlatma sırasında),
    yeni backend başladığında durumu 'done' olarak işaretle.
    """
    status = get_deploy_status()
    if status.get("step") in ("rebuilding", "restarting"):
        _write_status(
            "done",
            "Dağıtım tamamlandı — sunucu başarıyla yeniden başlatıldı!",
            done=True,
        )
        print("[DEPLOY] Önceki deploy tamamlandı — durum 'done' olarak güncellendi")


def _find_compose() -> list[str]:
    """Kullanılabilir docker compose komutunu bulur."""
    for cmd in [["docker", "compose"], ["docker-compose"]]:
        try:
            r = subprocess.run(
                cmd + ["version"],
                capture_output=True,
                timeout=10,
            )
            if r.returncode == 0:
                return cmd
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue
    raise RuntimeError("docker compose veya docker-compose bulunamadı")


def _get_compose_project() -> str:
    """
    Çalışan stokfinans-backend container'ından compose proje adını okur.
    Bu sayede deploy her zaman mevcut projeyle uyumlu çalışır.
    """
    try:
        r = subprocess.run(
            ["docker", "inspect", "stokfinans-backend",
             "--format", "{{index .Config.Labels \"com.docker.compose.project\"}}"],
            capture_output=True, text=True, timeout=10,
        )
        name = r.stdout.strip()
        if name:
            return name
    except Exception:
        pass
    return APP_ROOT.name  # fallback: dizin adı


def _get_app_root_host_path() -> str:
    """
    Container içinde /opt/app_root olarak erişilen dizinin HOST'taki gerçek yolunu döndürür.
    Deployer container'ı için volume mount'ta kullanılır.
    """
    try:
        r = subprocess.run(
            ["docker", "inspect", "stokfinans-backend",
             "--format",
             "{{range .Mounts}}{{if eq .Destination \"/opt/app_root\"}}{{.Source}}{{end}}{{end}}"],
            capture_output=True, text=True, timeout=10,
        )
        path = r.stdout.strip()
        if path:
            return path
    except Exception:
        pass
    return str(APP_ROOT)  # fallback (container path — aynı ortamda çalışıyorsa geçerli)


def create_bundle_zip() -> bytes:
    """
    Uygulama kaynak dosyalarını ZIP olarak paketler (veritabanı ve build artefaktları hariç).
    """
    buf = io.BytesIO()
    app_root_str = str(APP_ROOT)

    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for root, dirs, files in os.walk(APP_ROOT):
            root_path = Path(root)
            try:
                rel_root = root_path.relative_to(APP_ROOT)
            except ValueError:
                continue

            rel_str = str(rel_root)

            # Excluded subtrees
            if any(rel_str.startswith(excl) or rel_str == excl.split("/")[0] and len(excl.split("/")) == 1
                   for excl in EXCLUDE_SUBTREES):
                # More precise check
                skip = False
                for excl in EXCLUDE_SUBTREES:
                    parts = excl.split("/")
                    if rel_str == excl or rel_str.startswith(excl + "/") or rel_str.startswith(excl + os.sep):
                        skip = True
                        break
                if skip:
                    dirs.clear()
                    continue

            # Filter dirs
            dirs[:] = [
                d for d in dirs
                if d not in EXCLUDE_DIRS and not d.startswith(".")
            ]

            for fname in files:
                if fname in EXCLUDE_NAMES:
                    continue
                if any(fname.endswith(ext) for ext in EXCLUDE_EXTENSIONS):
                    continue
                if fname.startswith(".") and fname not in (".gitignore", ".env.example"):
                    continue

                file_path = root_path / fname
                arc_name = str(rel_root / fname) if str(rel_root) != "." else fname
                try:
                    zf.write(file_path, arc_name)
                except (PermissionError, OSError):
                    pass

    return buf.getvalue()


ROLLBACK_DIR = APP_ROOT / ".deploy_rollback"
_ROLLBACK_ITEMS = ["backend", "frontend"]  # rollback kapsamı


def _make_rollback_snapshot() -> bool:
    """Kritik dizinlerin anlık yedeğini alır. Başarı True döner."""
    try:
        if ROLLBACK_DIR.exists():
            shutil.rmtree(ROLLBACK_DIR)
        ROLLBACK_DIR.mkdir(parents=True)
        for name in _ROLLBACK_ITEMS:
            src = APP_ROOT / name
            if src.exists():
                shutil.copytree(str(src), str(ROLLBACK_DIR / name))
        return True
    except Exception as exc:
        print(f"[DEPLOY] Rollback snapshot alınamadı: {exc}")
        return False


def _restore_rollback() -> bool:
    """Rollback snapshot'ını geri yükler. Başarı True döner."""
    if not ROLLBACK_DIR.exists():
        return False
    try:
        for name in _ROLLBACK_ITEMS:
            src = ROLLBACK_DIR / name
            dest = APP_ROOT / name
            if src.exists():
                if dest.exists():
                    shutil.rmtree(dest)
                shutil.copytree(str(src), str(dest))
        return True
    except Exception as exc:
        print(f"[DEPLOY] Rollback geri yükleme hatası: {exc}")
        return False


def _run_deploy(zip_bytes: bytes) -> None:
    """Arka planda çalışan deploy işlemi."""
    try:
        # ── 1. Rollback snapshot al ───────────────────────────────────
        _write_status("extracting", "Yedek alınıyor (rollback için)...")
        _make_rollback_snapshot()

        # ── 2. ZIP'i çıkar ────────────────────────────────────────────
        _write_status("extracting", "ZIP dosyası çıkarılıyor...")
        if DEPLOY_TMP.exists():
            shutil.rmtree(DEPLOY_TMP)
        DEPLOY_TMP.mkdir(parents=True, exist_ok=True)

        zip_path = DEPLOY_TMP / "deploy.zip"
        zip_path.write_bytes(zip_bytes)

        extract_dir = DEPLOY_TMP / "extracted"
        extract_dir.mkdir(exist_ok=True)
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_dir)

        # Tek üst dizin varsa onu kök kabul et
        entries = list(extract_dir.iterdir())
        if len(entries) == 1 and entries[0].is_dir():
            src_dir = entries[0]
        else:
            src_dir = extract_dir

        # ── 3. Dosyaları kopyala ──────────────────────────────────────
        _write_status("copying", "Dosyalar hedef dizine kopyalanıyor...")
        for item in src_dir.iterdir():
            if item.name in EXCLUDE_DIRS or item.name in DEPLOY_SKIP_NAMES or item.name.startswith("."):
                continue
            dest = APP_ROOT / item.name
            if item.is_dir():
                if dest.exists():
                    shutil.rmtree(dest)
                shutil.copytree(str(item), str(dest))
            else:
                shutil.copy2(str(item), str(dest))

        # ── 3. Sadece IMAGE'ları derle (container'lara dokunmadan) ────
        _write_status(
            "rebuilding",
            "Docker imajları derleniyor — bu birkaç dakika sürebilir...",
        )

        compose_cmd = _find_compose()
        project_name = _get_compose_project()
        host_app_root = _get_app_root_host_path()

        build_result = subprocess.run(
            compose_cmd + ["-p", project_name, "build"],
            cwd=str(APP_ROOT),
            capture_output=True,
            text=True,
            timeout=900,  # 15 dk
        )

        if build_result.returncode != 0:
            err_tail = (build_result.stderr or build_result.stdout or "")[-1500:]
            # Build başarısız → rollback
            _write_status("error", "Docker build hatası — önceki sürüme geri dönülüyor...", error=err_tail)
            if _restore_rollback():
                _write_status(
                    "error",
                    "Docker build hatası — önceki sürüme geri dönüldü",
                    done=False,
                    error=err_tail,
                )
            else:
                _write_status(
                    "error",
                    "Docker build hatası — rollback da başarısız, manuel müdahale gerekiyor",
                    done=False,
                    error=err_tail,
                )
            return

        # ── 4. Bağımsız deployer container ile yeniden başlat ─────────
        # Neden ayrı container?
        # "docker compose up -d" eski backend'i durdurduğunda bu thread de ölür →
        # yeni container başlatılamaz. Çözüm: yeniden başlatmayı bağımsız container'da yürüt.
        _write_status(
            "restarting",
            "Containerlar yeniden başlatılıyor — yeni backend yükleniyor...",
            done=False,
        )

        # Varsa önceki deployer container'ı temizle
        subprocess.run(
            ["docker", "rm", "-f", "stokfinans-deployer"],
            capture_output=True, timeout=10,
        )

        deployer_image = f"{project_name}-backend"
        compose_bin   = " ".join(compose_cmd)
        compose_file  = f"{host_app_root}/docker-compose.yml"

        # Restart sırası:
        #  1. Eski container'ları durdur ve kaldır
        #  2. Compose up --no-build ile başlat
        #  3. Sadece hata varsa status dosyasına yaz — başarıda dokunma!
        #     Yeni backend startup'ta finalize_deploy_on_startup() → "done" yazar.
        #     Deployer'ın başarı durumunda status'u ezmesi race condition yaratır.
        restart_cmd = (
            "sleep 3 && "
            # Eski container'ları durdur ve kaldır
            "docker stop stokfinans-backend stokfinans-frontend 2>/dev/null; "
            "docker rm   stokfinans-backend stokfinans-frontend 2>/dev/null; "
            # Backend başlat, exit kodunu sakla
            f"{compose_bin} -p {project_name} -f {compose_file} up -d --no-build backend; "
            f"B_EXIT=$?; "
            # Frontend başlat (backend bağımsız)
            f"{compose_bin} -p {project_name} -f {compose_file} up -d --no-build frontend; "
            # Sadece backend başlatma başarısızsa hata yaz
            f"if [ \"$B_EXIT\" -ne 0 ]; then "
            f"  echo '{{\"step\":\"error\",\"message\":\"docker compose up backend başarısız (exit: '$B_EXIT')\","
            f"\"done\":false,\"error\":\"Compose up çıkış kodu: $B_EXIT — docker logs stokfinans-backend ile inceleyin\","
            f"\"ts\":\"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'\"}}' "
            f"  > {host_app_root}/.deploy_status.json; "
            f"fi"
            # Başarıda: status dosyasına dokunma — yeni backend finalize_deploy_on_startup() ile "done" yazar
        )

        subprocess.Popen(
            [
                "docker", "run", "--rm", "-d",
                "--entrypoint", "sh",
                "--user", "root",  # Docker socket erişimi için root gerekli
                "--name", "stokfinans-deployer",
                "-v", "/var/run/docker.sock:/var/run/docker.sock",
                "-v", "/usr/bin/docker:/usr/bin/docker:ro",
                "-v", "/usr/libexec/docker/cli-plugins:/usr/libexec/docker/cli-plugins:ro",
                "-v", f"{host_app_root}:{host_app_root}",
                "-w", host_app_root,
                deployer_image,
                "-c", restart_cmd,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        # Thread buradan döner; deployer bağımsız çalışmaya devam eder.
        # Yeni backend startup'ta finalize_deploy_on_startup() → "done" yazar.

    except Exception as exc:
        _write_status(
            "error",
            f"Beklenmeyen deploy hatası: {exc}",
            done=False,
            error=str(exc)[:1000],
        )
    finally:
        shutil.rmtree(DEPLOY_TMP, ignore_errors=True)


def start_deploy(zip_bytes: bytes) -> None:
    """Arka planda deploy thread başlatır; anlık döner."""
    t = threading.Thread(target=_run_deploy, args=(zip_bytes,), daemon=True)
    t.start()
