# ============================================================
# Security Utils - Güvenlik İşlemleri
# ============================================================
# Bu dosya, şifre hashing, JWT token generation ve validation
# gibi tüm güvenlik işlemlerini barındırır.
# ============================================================

import bcrypt
import secrets as _secrets
import uuid as _uuid
from datetime import datetime, timedelta
from typing import Optional
import os
from jose import JWTError, jwt
from dotenv import load_dotenv

load_dotenv()

# ============================================================
# JWT TOKEN AYARLARI
# ============================================================
# .env dosyasından oku, yoksa default kullan

SECRET_KEY = os.getenv("JWT_SECRET_KEY") or os.getenv("SECRET_KEY")
ALGORITHM = os.getenv("JWT_ALGORITHM") or os.getenv("ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "60"))
REFRESH_TOKEN_EXPIRE_DAYS = int(os.getenv("REFRESH_TOKEN_EXPIRE_DAYS", "90"))

if not SECRET_KEY:
    if os.getenv("ENVIRONMENT", "development").lower() == "production":
        raise RuntimeError(
            "JWT_SECRET_KEY ortam değişkeni tanımlı değil. "
            "Üretimde mutlaka güçlü bir secret ayarlayın."
        )
    SECRET_KEY = "dev-only-insecure-secret-do-not-use-in-production-32chars"
    print("[WARNING] JWT_SECRET_KEY tanımlı değil, geliştirme varsayılanı kullanılıyor.")

# ============================================================
# PASSWORD HASHING FONKSIYONLARI
# ============================================================

def hash_password(password: str) -> str:
    """
    Şifreyi Bcrypt ile hashle ve depolama için hazırla
    """
    pwd_bytes = password.encode('utf-8')
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(pwd_bytes, salt).decode('utf-8')


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Girilen şifreyi depolanan hash ile karşılaştır
    """
    try:
        plain_bytes = plain_password.encode('utf-8')
        hash_bytes = hashed_password.encode('utf-8')
        return bcrypt.checkpw(plain_bytes, hash_bytes)
    except Exception:
        return False

# ============================================================
# JWT TOKEN GENERATION
# ============================================================

def create_access_token(
    data: dict,
    expires_delta: Optional[timedelta] = None
) -> str:
    """
    Access Token (JWT) oluştur

    Kullanıcı login yaptığında, bu token oluşturulur ve
    frontend'e gönderilir. API istekleri sırasında bu token
    Authorization header'ında gönderilir.

    Args:
        data (dict): Token'a eklenecek veriler
                    Örnek: {"sub": "user@email.com", "user_id": 1}
        expires_delta (Optional[timedelta]): Özel süre (varsayılan: 30 min)

    Returns:
        str: Kodlanmış JWT token

    Örnek:
        token = create_access_token(
            data={"sub": "ahmet@stokfinans.com", "user_id": 1}
        )
        # "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWI..."
    """
    to_encode = data.copy()

    # Süre belirtilmediyse, DEFAULT sürü kullan
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)

    # jti (JWT ID): her token'a özgü, revocation için
    to_encode.update({"exp": expire, "jti": _secrets.token_hex(16)})

    # Token'ı HS256 (HMAC SHA-256) ile şifrele
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

    return encoded_jwt


def create_refresh_token(
    data: dict,
    family_id: Optional[str] = None,
    expires_delta: Optional[timedelta] = None,
) -> str:
    """
    Refresh Token (JWT) oluştur

    Access token süresi dolduğunda, bu refresh token kullanarak
    yeni bir access token alınır. Kullanıcı tekrar login yapmak
    zorunda kalmaz.

    Args:
        data (dict): Token'a eklenecek veriler
        expires_delta (Optional[timedelta]): Özel süre (varsayılan: 7 gün)

    Returns:
        str: Kodlanmış JWT token (uzun ömürlü)

    Örnek:
        refresh_token = create_refresh_token(
            data={"sub": "ahmet@stokfinans.com"}
        )
    """
    to_encode = data.copy()

    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)

    to_encode.update({
        "exp": expire,
        "jti": _secrets.token_hex(16),
        "family_id": family_id or str(_uuid.uuid4()),
        "token_type": "refresh",
    })

    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

    return encoded_jwt

# ============================================================
# JWT TOKEN VERIFICATION (DOĞRULAMA)
# ============================================================

def verify_token(token: str) -> Optional[dict]:
    """
    JWT token'ı doğrula ve payload'ını çıkar

    API endpoint'leri istekle birlikte gelen token'ı
    doğrulamak için bu fonksiyonu kullanır.

    Args:
        token (str): Bearer token (başlık: "Authorization: Bearer {token}")

    Returns:
        Optional[dict]: Token geçerli ise payload, değilse None

    Örnek:
        payload = verify_token("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...")
        if payload:
            user_id = payload.get("user_id")
            # Kullanıcı işlemleri yap
        else:
            # Token geçersiz - 401 Unauthorized
    """
    try:
        # Token'ı decode et ve signature'ı doğrula
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        # Token geçersiz, süresi dolmuş veya imzası bozuk
        return None

# ============================================================
# REFERRAL CODE GENERATION
# ============================================================

def generate_referral_code(user_id: int, company_name: str = "") -> str:
    """
    Benzersiz referral kodu oluştur

    Her bayıya verilecek özel referral kodu.
    Format: BAYI + 5 rasgele rakam = BAYI12345

    Args:
        user_id (int): Kullanıcı ID
        company_name (str): İşletme adı (opsiyonel, formatlamak için)

    Returns:
        str: Referral kodu (örn: "BAYI12345")

    Örnek:
        ref_code = generate_referral_code(user_id=1)
        # "BAYI25463"
    """
    import random
    random_num = random.randint(10000, 99999)
    return f"BAYI{random_num}"

# ============================================================
# IP ADDRESS EXTRACTION (IP ADRESI ÇIKARMA)
# ============================================================

def get_client_ip(request) -> str:
    """
    İstemcinin gerçek IP adresini döndürür.

    Öncelik: nginx tarafından set edilen X-Real-IP (kullanıcı tarafından
    manipüle edilemez). X-Forwarded-For'a güvenilmez çünkü saldırgan
    bunu spoofleyerek rate-limit ve IP ban'ı atlayabilir.
    """
    real_ip = request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip.strip()
    return request.client.host if request.client else "unknown"

# ============================================================
# AÇIKLAMALAR
# ============================================================
#
# 1. BCRYPT NEDEN?
#    - Çok yavaş intentionally (brute-force attacks'e karşı)
#    - Salt otomatik (rainbow table attacks'e karşı)
#    - Industry standard, güvenilir
#
# 2. JWT TOKEN AKIŞI:
#    1. Kullanıcı email+password → register/login
#    2. Şifre doğrula (verify_password)
#    3. Token oluştur (create_access_token)
#    4. Frontend token'ı sakla (localStorage, cookie)
#    5. Her istek'te Authorization header'da gönder
#    6. Backend token doğrula (verify_token)
#    7. Token geçerli → İşlem yap, geçersiz → 401 error
#
# 3. REFRESH TOKEN:
#    - Short-lived access token (30 min)
#    - Long-lived refresh token (7 gün)
#    - Access token süresi dolunca:
#      POST /api/v1/auth/refresh + refresh_token
#      → Yeni access_token al
#      → Tekrar login gerekmez
#
# 4. IP KORUMA:
#    - Aynı IP'den çoklu sahte kayıtlar engelle
#    - Anti-fraud mekanizması
#    - Referral code istismarı önle
#
# ============================================================
