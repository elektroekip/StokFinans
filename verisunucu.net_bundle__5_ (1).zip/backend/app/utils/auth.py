# ============================================================
# Auth Utils - Kimlik Doğrulama Yardımcı Fonksiyonları
# ============================================================
# Login, register ve permission check işlemleri için
# yardımcı fonksiyonlar içerir.
# ============================================================

from fastapi import Depends, HTTPException, status, Request
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models import User
from app.utils.security import verify_token, get_client_ip
from typing import Optional

# ============================================================
# CURRENT USER DEPENDENCY (Kimlik doğrulanmış kullanıcı al)
# ============================================================

async def get_current_user(
    request: Request,
    db: Session = Depends(get_db)
) -> User:
    """
    Authorization header'dan token al, doğrula ve
    ilgili User nesnesini döndür

    FastAPI endpoint'lerinde Depends olarak kullanılır.
    Token geçersiz veya kullanıcı bulunamazsa 401 error döner.

    Args:
        request (Request): FastAPI request nesnesi
        db (Session): Veritabanı session

    Returns:
        User: Doğrulanan kullanıcı nesnesi

    Raises:
        HTTPException: 401 (Token invalid/missing)
                      404 (User not found)

    Örnek Kullanım:
        @app.get("/api/v1/profile")
        def get_profile(current_user: User = Depends(get_current_user)):
            return {"name": current_user.full_name, "email": current_user.email}
    """
    # ── API Key auth (X-API-Key header) ─────────────────────────────────────
    api_key_raw = request.headers.get("X-API-Key", "").strip()
    if api_key_raw:
        from app.models.api_key import ApiKey as _ApiKey, hash_api_key, check_scope
        from datetime import datetime as _dt
        key_hash = hash_api_key(api_key_raw)
        ak = db.query(_ApiKey).filter(
            _ApiKey.key_hash == key_hash,
            _ApiKey.is_active == True,
        ).first()
        if not ak:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Geçersiz API anahtarı")
        if ak.expires_at and ak.expires_at < _dt.utcnow():
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="API anahtarının süresi dolmuş")
        if not ak.is_full_access:
            if not check_scope(request.method, request.url.path, list(ak.scopes or [])):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"API anahtarı bu kaynak için yetki içermiyor",
                )
        # Kullanım sayacını atomik artır
        try:
            db.query(_ApiKey).filter(_ApiKey.id == ak.id).update({
                "usage_count": _ApiKey.usage_count + 1,
                "last_used_at": _dt.utcnow(),
            })
            db.commit()
        except Exception:
            db.rollback()
        if getattr(ak, "is_super_admin_key", False):
            # Süper admin anahtarı → key sahibinin is_super_admin olduğu doğrulanır
            user = db.query(User).filter(User.id == ak.user_id, User.is_super_admin == True).first()
            if not user or not user.is_active:
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Süper admin hesabı aktif değil")
        else:
            user = db.query(User).filter(User.id == ak.user_id).first()
            if not user or not user.is_active:
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="API anahtarına bağlı hesap aktif değil")
        return user

    # ── JWT auth (Authorization: Bearer) ─────────────────────────────────────
    auth_header = request.headers.get("Authorization")

    if not auth_header:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authorization header eksik",
            headers={"WWW-Authenticate": "Bearer"}
        )

    # "Bearer " prefix'ini çıkar
    try:
        scheme, token = auth_header.split()
        if scheme.lower() != "bearer":
            raise ValueError()
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authorization header format",
            headers={"WWW-Authenticate": "Bearer"}
        )

    # Token'ı doğrula
    payload = verify_token(token)

    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Geçersiz veya süresi dolmuş token",
            headers={"WWW-Authenticate": "Bearer"}
        )

    # Revocation kontrolü: token iptal listesinde mi?
    jti = payload.get("jti")
    if jti:
        from app.models.revoked_token import RevokedToken
        if db.query(RevokedToken).filter(RevokedToken.jti == jti).first():
            try:
                from app.services.alert_service import trigger_alert
                trigger_alert(
                    "REVOKED_TOKEN_USED",
                    get_client_ip(request),
                    f"İptal edilmiş token kullanım girişimi",
                    user_id=payload.get("user_id"),
                )
            except Exception:
                pass
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token iptal edilmiş, lütfen tekrar giriş yapın",
                headers={"WWW-Authenticate": "Bearer"},
            )

    # Token'dan user_id çıkar
    user_id = payload.get("user_id")

    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token'da user_id bulunmadı"
        )

    # Veritabanından kullanıcıyı bul
    user = db.query(User).filter(User.id == user_id).first()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Kullanıcı bulunamadı"
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Kullanıcı hesabı pasif"
        )

    # Canlı topoloji aktivite kaydı (JWT akışı — yalnızca gerçek kullanıcı istekleri)
    try:
        from app.utils.activity import track_user_access
        _tenant_id = user.id if user.role == "bayi_sahibi" else (user.parent_user_id or user.id)
        track_user_access(
            user.id, user.email, user.full_name or "",
            str(request.url.path), request.method, user.role or "",
            tenant_id=_tenant_id,
        )
    except Exception:
        pass

    # E-posta doğrulanmamışsa ve SMTP aktifse korumayı zorla
    if not getattr(user, 'is_email_verified', True) and not getattr(user, 'is_super_admin', False):
        try:
            from app.services.email import get_smtp_settings as _get_smtp
            smtp = _get_smtp(db)
        except Exception as _smtp_exc:
            import logging as _log
            _log.getLogger("auth").error("[EMAIL_VERIFY_GUARD] SMTP check failed: %s", _smtp_exc)
            smtp = None
        if smtp:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "code": "email_not_verified",
                    "message": "E-posta adresiniz henüz doğrulanmamış. Lütfen e-posta kutunuzu kontrol edin.",
                    "email": user.email,
                },
                headers={"X-Email-Verification-Required": "true"},
            )

    return user


async def get_current_user_unverified(
    request: Request,
    db: Session = Depends(get_db)
) -> User:
    """
    get_current_user ile aynı ama is_email_verified kontrolünü atlar.
    Sadece resend-verification, profile ve benzeri doğrulama akışı endpoint'lerinde kullanılır.
    """
    auth_header = request.headers.get("Authorization")
    if not auth_header:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authorization header eksik",
            headers={"WWW-Authenticate": "Bearer"}
        )
    try:
        scheme, token = auth_header.split()
        if scheme.lower() != "bearer":
            raise ValueError()
    except ValueError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid authorization header format")
    from app.utils.security import verify_token as _vt
    payload = _vt(token)
    if not payload:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Geçersiz veya süresi dolmuş token")
    jti = payload.get("jti")
    if jti:
        from app.models.revoked_token import RevokedToken
        if db.query(RevokedToken).filter(RevokedToken.jti == jti).first():
            try:
                from app.services.alert_service import trigger_alert
                trigger_alert(
                    "REVOKED_TOKEN_USED",
                    get_client_ip(request),
                    "İptal edilmiş token kullanım girişimi",
                    user_id=payload.get("user_id"),
                )
            except Exception:
                pass
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token iptal edilmiş, lütfen tekrar giriş yapın")
    user_id = payload.get("user_id")
    if not user_id:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token'da user_id bulunmadı")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Kullanıcı bulunamadı")
    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Kullanıcı hesabı pasif")
    return user

# ============================================================
# SUPER ADMIN DEPENDENCY (Platform süper yöneticisi)
# ============================================================

async def get_current_super_admin(
    current_user: User = Depends(get_current_user),
) -> User:
    """
    Yalnızca platform süper yöneticileri için erişim. Aksi halde 403 döner.
    """
    if not getattr(current_user, "is_super_admin", False):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Bu sayfa yalnızca platform süper yöneticilerine açıktır",
        )
    return current_user

# ============================================================
# ROLE-BASED ACCESS CONTROL (Rol bazlı erişim)
# ============================================================

async def get_current_admin(
    current_user: User = Depends(get_current_user)
) -> User:
    """
    Sadece Bayı Sahibi (Admin) rolü olan kullanıcılara izin ver

    Kullanıcı YÖNETİMİ, SİSTEM AYARLARI gibi kritik işlemler
    için kullanılır.

    Args:
        current_user (User): Doğrulanmış kullanıcı

    Returns:
        User: Admin rolü olan kullanıcı

    Raises:
        HTTPException: 403 (Forbidden - Not admin)

    Örnek:
        @app.delete("/api/v1/employees/{id}")
        def delete_employee(
            id: int,
            current_admin: User = Depends(get_current_admin),
            db: Session = Depends(get_db)
        ):
            # Sadece admin bu endpoint'i kullanabilir
            employee = db.query(User).filter(User.id == id).first()
            db.delete(employee)
            db.commit()
    """
    if current_user.role != "bayi_sahibi":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Bu işlem için Bayı Sahibi rolü gerekli"
        )

    return current_user

# ============================================================
# EMAIL VARLIK KONTROLÜ
# ============================================================

def check_email_exists(email: str, db: Session) -> bool:
    """
    E-posta adresi zaten kullanımda mı kontrol et

    Register sırasında çift kayıt (duplicate) engelleme.

    Args:
        email (str): Kontrol edilecek e-posta
        db (Session): Veritabanı session

    Returns:
        bool: True = Email zaten var, False = Yeni email

    Örnek:
        if check_email_exists("ahmet@mail.com", db):
            raise HTTPException(detail="Email zaten kayıtlı")
    """
    user = db.query(User).filter(User.email == email).first()
    return user is not None

# ============================================================
# REFERRAL CODE VALIDASYON
# ============================================================

def validate_referral_code(ref_code: str, db: Session) -> Optional[User]:
    """
    Referral code'u doğrula ve sahibini bul

    Register sırasında girilen referral code geçerli mi
    ve kime ait olduğunu kontrol et.

    Args:
        ref_code (str): Doğrulanacak referral kodu
        db (Session): Veritabanı session

    Returns:
        Optional[User]: Referral code sahibi (varsa), None (yoksa)

    Örnek:
        referrer = validate_referral_code("BAYI12345", db)
        if referrer:
            # Referrer'a +10 gün ekle
            referrer.sub_days += 10
        else:
            raise HTTPException(detail="Geçersiz referral kodu")
    """
    user = db.query(User).filter(
        User.ref_code == ref_code.upper()
    ).first()

    return user

# ============================================================
# IP-BASED FRAUD DETECTION (Hile koruması)
# ============================================================

def check_duplicate_registration(
    email: str,
    ip_address: str,
    db: Session
) -> tuple[bool, Optional[str]]:
    """
    Aynı IP'den çoklu kayıt ve aynı email çoklu kayıt engelle

    Anti-fraud mekanizması:
    1. Aynı email ile iki kez kayıt olamazsın
    2. Aynı IP'den 30 gün içinde 5+ kayıt geçersiz

    Args:
        email (str): Kayıt etmek istenen email
        ip_address (str): Kayıt yapan kişinin IP'si
        db (Session): Veritabanı session

    Returns:
        tuple[bool, Optional[str]]: (Hile mi?, Hata mesajı)
        - (True, "Email zaten kayıtlı") → Hile tespit
        - (False, None) → Güvenli, devam et

    Örnek:
        is_fraud, error = check_duplicate_registration(
            email="ahmet@mail.com",
            ip_address="192.168.1.100",
            db=db
        )
        if is_fraud:
            raise HTTPException(detail=error)
    """
    # 1. Aynı email zaten var mı?
    existing_user = db.query(User).filter(User.email == email).first()

    if existing_user:
        return True, "Bu e-posta adresi zaten kayıtlı"

    # 2. Aynı IP'den kaç kayıt var?
    from datetime import datetime, timedelta

    thirty_days_ago = datetime.utcnow() - timedelta(days=30)

    recent_registrations = db.query(User).filter(
        User.ip_address == ip_address,
        User.created_at > thirty_days_ago
    ).count()

    if recent_registrations >= 5:
        return True, "Bu IP'den çok sayıda kayıt yapılmış. Lütfen daha sonra tekrar deneyin."

    return False, None

# ============================================================
# ABONELIK KONTROLÜ (Subscription check)
# ============================================================

def check_subscription_valid(user: User) -> bool:
    """
    Kullanıcının aboneliği aktif mi kontrol et

    sub_days > 0 ise aktif, <= 0 ise pasif (suspend).

    Args:
        user (User): Kontrol edilecek kullanıcı

    Returns:
        bool: True = Aktif abonelik, False = Pasif

    Örnek:
        if not check_subscription_valid(current_user):
            raise HTTPException(
                status_code=403,
                detail="Aboneliğinizin süresi dolmuş"
            )
    """
    return user.sub_days > 0

# ============================================================
# AÇIKLAMALAR
# ============================================================
#
# 1. GET_CURRENT_USER AKIŞI:
#    1. Request'ten Authorization header'ı al
#    2. Format'ı kontrol et: "Bearer {token}"
#    3. Token'ı doğrula (verify_token)
#    4. Token'dan user_id çıkar
#    5. Veritabanından kullanıcı bul
#    6. Hesap aktif mi kontrol et
#    7. Kullanıcı nesnesini döndür
#
# 2. ADMIN CHECK:
#    get_current_user sonucuna, rol kontrolü ekle
#    Sadece bayi_sahibi → Başarılı
#    Diğer roller → 403 Forbidden
#
# 3. REFERRAL CODE FLOW:
#    1. Kullanıcı register sırasında BAYI12345 girer
#    2. validate_referral_code() tarafından kontrol edilir
#    3. Varsa: Hem yeni kullanıcı hem referrer'a bonus
#    4. Yoksa: Hata dön
#
# 4. IP PROTECTION:
#    - Same IP: 5+ registrations in 30 days = FRAUD
#    - Kendi kendine referral yapmasını engelle
#    - Çoklu hesap açılmasını engellesin
#
# ============================================================
