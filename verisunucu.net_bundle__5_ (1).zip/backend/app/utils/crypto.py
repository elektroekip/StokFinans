import os
import base64
import hashlib
from cryptography.fernet import Fernet


def _get_fernet() -> Fernet:
    raw = os.environ.get("SMTP_SECRET_KEY", "").strip()
    if raw:
        try:
            return Fernet(raw.encode() if isinstance(raw, str) else raw)
        except Exception:
            pass
    # Deterministic key derived from DATABASE_URL — no hardcoded fallback
    db_url = os.environ.get("DATABASE_URL", "") or os.environ.get("POSTGRES_URL", "")
    if not db_url:
        raise RuntimeError(
            "SMTP_SECRET_KEY env var is not set and DATABASE_URL is unavailable. "
            "Please set SMTP_SECRET_KEY to a 32-byte URL-safe base64 Fernet key."
        )
    digest = hashlib.sha256(("stokfinans-smtp-key:" + db_url).encode()).digest()
    key = base64.urlsafe_b64encode(digest)
    print("[CRYPTO] SMTP_SECRET_KEY not set — deriving key from DATABASE_URL. "
          "Set SMTP_SECRET_KEY env var for explicit key management.")
    return Fernet(key)


def encrypt_secret(plaintext: str) -> str:
    if not plaintext:
        return ""
    return _get_fernet().encrypt(plaintext.encode()).decode()


def decrypt_secret(ciphertext: str) -> str:
    if not ciphertext:
        return ""
    try:
        return _get_fernet().decrypt(ciphertext.encode()).decode()
    except Exception:
        # Possibly plaintext stored before encryption was introduced — return as-is
        return ciphertext
