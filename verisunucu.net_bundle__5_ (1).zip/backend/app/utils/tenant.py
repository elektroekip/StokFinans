"""
Multi-tenant veri sahipliği yardımcısı.

StokFinans'ta veri (ürünler, transaction'lar, kategoriler vb.) **bayi sahibi
(bayi_sahibi)** kullanıcıya bağlıdır. Çalışanlar (calisan) kendi User satırına
sahip olsalar da, veri açısından patronlarının (parent_user_id) verilerini
görür ve düzenler. Bu fonksiyon `Product.user_id == data_owner_id(user)` gibi
filtrelemeler için kullanılır.

Kullanım:
    from app.utils.tenant import data_owner_id
    owner_id = data_owner_id(current_user)
    products = db.query(Product).filter(Product.user_id == owner_id).all()
"""

from typing import Optional


def data_owner_id(user) -> int:
    """
    Verileri sahiplenen kullanıcının id'sini döndürür.
    Çalışan ise patron, değilse kullanıcının kendi id'si.
    """
    pid = getattr(user, "parent_user_id", None)
    if pid:
        return int(pid)
    return int(user.id)


def is_employee(user) -> bool:
    """Bu kullanıcı bir başkasının çalışanı mı?"""
    return bool(getattr(user, "parent_user_id", None))


def has_permission(user, page_slug: str) -> bool:
    """
    Çalışanın belirtilen sayfa için izni var mı?
    - Patron (parent_user_id yok) her zaman izinli.
    - Süper admin her zaman izinli.
    - Çalışanda permissions listesinde varsa izinli.
    """
    if getattr(user, "is_super_admin", False):
        return True
    if not is_employee(user):
        return True
    perms = getattr(user, "permissions", None) or []
    return page_slug in perms
