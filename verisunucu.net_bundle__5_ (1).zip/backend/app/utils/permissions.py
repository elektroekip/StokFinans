"""
Çalışan yetki sistemi (permissions).

Yetki string formatı (atomik):
- "dashboard"
- "products.<action>"               action ∈ {view, add, edit, delete}
- "finance.<tip>.<action>"          tip ∈ {veresiye, firma, senet, kredi, kasa, garanti}
- "reports.view"
- "profile.view"

Patron (role='bayi_sahibi') her zaman tüm izinlere sahiptir.
Süper admin de aynı şekilde geçer.
"""

from typing import Iterable, List, Optional
from fastapi import HTTPException, status


PRODUCT_ACTIONS = ("view", "add", "edit", "delete", "view_cost")

# Finance alt tipler — backend'de transaction_type değerleri ile eşleşir.
# transaction_type değeri NULL ise "kasa" olarak yorumlanır (Kasa Defteri).
FINANCE_TYPES = ("veresiye", "firma", "senet", "kredi", "kasa", "garanti")
FINANCE_ACTIONS = ("view", "add", "edit", "delete")

# transaction_type değerinden permission alt-tip anahtarına eşleme.
# Frontend'deki MODULE_CONFIG ve buildModuleConfig ile uyumludur.
FINANCE_TYPE_TO_KEY = {
    "borç": "veresiye",
    "borc": "veresiye",
    "gider": "firma",
    "expense": "firma",
    "senet": "senet",
    "kredi": "kredi",
    "garanti": "garanti",
    None: "kasa",
    "": "kasa",
}


BTB_ACTIONS = ("view", "add", "edit", "delete")
SUPPLIER_ACTIONS = ("view", "add", "edit", "delete")
PLASIYER_ACTIONS = ("view", "manage")
INTEGRATIONS_ACTIONS = ("view", "add", "edit", "delete")


def _build_allowed():
    s = {"dashboard", "reports.view", "profile.view"}
    for a in PRODUCT_ACTIONS:
        s.add(f"products.{a}")
    for t in FINANCE_TYPES:
        for a in FINANCE_ACTIONS:
            s.add(f"finance.{t}.{a}")
    for a in BTB_ACTIONS:
        s.add(f"btb.{a}")
    for a in SUPPLIER_ACTIONS:
        s.add(f"supplier.{a}")
    for a in PLASIYER_ACTIONS:
        s.add(f"plasiyer.{a}")
    for a in INTEGRATIONS_ACTIONS:
        s.add(f"integrations.{a}")
    return s


ALLOWED_PERMISSIONS = _build_allowed()


def expand_legacy(perms: Iterable[str]) -> List[str]:
    """
    Eski koarse-grained izinleri yeni granüler izinlere genişletir.
    - "products"  → tüm products.{view,add,edit,delete}
    - "finance"   → tüm finance.<tip>.{view,add,edit,delete}
    - "reports"   → reports.view
    - "profile"   → profile.view
    - "dashboard" → dashboard
    Yeni granüler izinler aynen kalır.
    Tanınmayan izinler atılır.
    """
    out: List[str] = []
    seen = set()

    def add(p: str):
        if p in ALLOWED_PERMISSIONS and p not in seen:
            seen.add(p)
            out.append(p)

    for p in perms or []:
        if not isinstance(p, str):
            continue
        p = p.strip()
        if not p:
            continue
        if p == "products":
            for a in PRODUCT_ACTIONS:
                add(f"products.{a}")
        elif p == "finance":
            for t in FINANCE_TYPES:
                for a in FINANCE_ACTIONS:
                    add(f"finance.{t}.{a}")
        elif p == "reports":
            add("reports.view")
        elif p == "profile":
            add("profile.view")
        else:
            add(p)
    return out


def finance_type_key(transaction_type: Optional[str]) -> str:
    """transaction_type değerinden finance alt tip anahtarına çevir."""
    if transaction_type is None:
        return "kasa"
    return FINANCE_TYPE_TO_KEY.get(transaction_type, "kasa")


def is_owner(user) -> bool:
    """Patron veya süper admin ise True."""
    if user is None:
        return False
    if getattr(user, "is_super_admin", False):
        return True
    if getattr(user, "parent_user_id", None):
        return False
    return getattr(user, "role", None) == "bayi_sahibi"


def has_perm(user, perm: str) -> bool:
    """Kullanıcı bu izne sahip mi? Eski (legacy) izinler defensive olarak genişletilir."""
    if is_owner(user):
        return True
    perms = getattr(user, "permissions", None) or []
    if not isinstance(perms, list):
        return False
    if perm in perms:
        return True
    # Legacy fallback: DB'de "products"/"finance" gibi koarse-grained izin kalmışsa
    # runtime'da expand edip kontrol et
    if any(p in ("products", "finance", "reports", "profile") for p in perms if isinstance(p, str)):
        return perm in expand_legacy(perms)
    return False


def has_any(user, perms: Iterable[str]) -> bool:
    if is_owner(user):
        return True
    user_perms = set(getattr(user, "permissions", None) or [])
    return any(p in user_perms for p in perms)


def require_perm(user, perm: str):
    """Yetki yoksa 403 fırlat."""
    if has_perm(user, perm):
        return
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail=f"Bu işlem için yetkiniz yok ({perm}). Lütfen firma sahibinizle iletişime geçin.",
    )


def require_finance_action(user, transaction_type: Optional[str], action: str):
    """Belirli finans alt tipi + action için yetki kontrolü."""
    require_perm(user, f"finance.{finance_type_key(transaction_type)}.{action}")


def require_any_finance_view(user):
    """En az bir finance.<tip>.view iznine sahip olunmasını gerektirir."""
    if is_owner(user):
        return
    perms = set(getattr(user, "permissions", None) or [])
    # Defensive legacy expand
    if any(p in ("finance",) for p in perms if isinstance(p, str)):
        perms.update(expand_legacy(list(perms)))
    if any(p in perms for p in (f"finance.{t}.view" for t in FINANCE_TYPES)):
        return
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Bu sayfayı görüntülemek için finans izniniz yok.",
    )
