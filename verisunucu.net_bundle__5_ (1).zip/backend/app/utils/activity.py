"""
In-memory kullanıcı aktivite cache'i — topoloji canlı izleme için.
Hiçbir DB yazımı gerektirmez; süper admin /topology/users endpoint'i bu veriyi okur.
"""
from __future__ import annotations
import time
from typing import Any, Dict, List, Optional

# {user_id: {email, name, endpoint, method, ts, role}}
_user_activity: Dict[int, Dict[str, Any]] = {}


def track_user_access(
    user_id: int, email: str, name: str, endpoint: str, method: str,
    role: str = "", tenant_id: Optional[int] = None,
) -> None:
    now = time.time()
    _user_activity[user_id] = {
        "email": email,
        "name": name or email.split("@")[0],
        "endpoint": endpoint,
        "method": method,
        "role": role,
        "tenant_id": tenant_id,
        "ts": now,
    }
    # 5 dakikadan eski girişleri temizle
    cutoff = now - 300
    for uid in list(_user_activity):
        if _user_activity[uid]["ts"] < cutoff:
            del _user_activity[uid]


def get_active_users(max_age_seconds: int = 300) -> List[Dict[str, Any]]:
    now = time.time()
    cutoff = now - max_age_seconds
    return sorted(
        [
            {**d, "user_id": uid, "seconds_ago": int(now - d["ts"])}
            for uid, d in _user_activity.items()
            if d["ts"] > cutoff
        ],
        key=lambda x: x["ts"],
        reverse=True,
    )
