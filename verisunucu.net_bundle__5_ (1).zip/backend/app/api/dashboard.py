# ============================================================
# Dashboard Endpoints - İşletme İstatistikleri API
# ============================================================
# KPI'lar, Performans Metrikleri ve Raporlar
#
# Seviye: SEVIYE 4 - Motor Odası
# Tarih: 28 Nisan 2026
# ============================================================

from fastapi import APIRouter, Depends, Query
from app.utils.tenant import data_owner_id
from sqlalchemy.orm import Session
from sqlalchemy import and_, func, distinct
from app.core.database import get_db
from app.models import Product, Transaction, User, ActivityLog
from app.schemas.dashboard import (
    DashboardStatsResponse,
    CriticalStockAlertsResponse,
    CriticalStockWarningResponse,
    PerformanceResponse,
    ChartDataResponse,
    SalesChartData,
    DashboardOverviewResponse,
    StatsItem,
    TopProductResponse
)
from app.utils.auth import get_current_user
from datetime import datetime, timedelta, timezone
from collections import defaultdict

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])

# ============================================================
# Yardımcı Fonksiyonlar
# ============================================================

def get_product_stats(db: Session, user_id: int, days: int = 30):
    """
    Ürün istatistiklerini hesapla (yalnızca ilgili bayinin envanterinden)

    Returns:
        dict: {total_products, total_categories, critical_stock_count}
    """
    total_products = db.query(func.count(Product.id)).filter(
        Product.user_id == user_id
    ).scalar()
    total_categories = db.query(func.count(distinct(Product.category))).filter(
        Product.user_id == user_id
    ).scalar()
    critical_stock = db.query(func.count(Product.id)).filter(
        and_(
            Product.user_id == user_id,
            Product.quantity <= Product.min_stock_alert,
        )
    ).scalar()

    return {
        "total_products": total_products or 0,
        "total_categories": total_categories or 0,
        "critical_stock": critical_stock or 0
    }


def get_sales_metrics(db: Session, user_id: int, days: int = 30):
    """
    Satış metriklerini hesapla (yalnızca ilgili bayinin işlemlerinden)

    Returns:
        dict: {total_sales, total_revenue, outstanding_debt, unique_customers}
    """
    start_date = datetime.now(timezone.utc) - timedelta(days=days)

    # Satışları topla
    total_sales = db.query(func.sum(Transaction.amount)).filter(
        and_(
            Transaction.user_id == user_id,
            Transaction.transaction_type.in_(["satış", "sale"]),
            Transaction.created_at >= start_date
        )
    ).scalar() or 0.0

    # Borçları topla
    total_debt = db.query(func.sum(Transaction.amount)).filter(
        and_(
            Transaction.user_id == user_id,
            Transaction.transaction_type.in_(["borç", "debt"]),
            Transaction.created_at >= start_date
        )
    ).scalar() or 0.0

    # Ödemeleri topla
    total_paid = db.query(func.sum(Transaction.amount)).filter(
        and_(
            Transaction.user_id == user_id,
            Transaction.transaction_type.in_(["ödeme", "payment"]),
            Transaction.created_at >= start_date
        )
    ).scalar() or 0.0

    outstanding_debt = total_debt - total_paid

    # Benzersiz müşteri sayısı
    unique_customers = db.query(func.count(distinct(Transaction.customer_name))).filter(
        and_(
            Transaction.user_id == user_id,
            Transaction.created_at >= start_date,
        )
    ).scalar() or 0

    # Ortalama kar marjı (yalnızca bu bayinin ürünlerinden)
    avg_profit_margin = db.query(
        func.avg((Product.price - Product.cost) / Product.cost * 100)
    ).filter(
        and_(Product.user_id == user_id, Product.cost > 0)
    ).scalar() or 0.0

    # Tahmini gelir = satış x ort.kar marjı
    total_revenue = total_sales * (avg_profit_margin / 100) if avg_profit_margin > 0 else 0

    return {
        "total_sales": total_sales,
        "total_revenue": total_revenue,
        "outstanding_debt": outstanding_debt,
        "unique_customers": unique_customers,
        "avg_profit_margin": avg_profit_margin
    }


def calculate_trend(current: float, previous: float) -> tuple:
    """
    Trend hesapla (yüzde değişim)

    Returns:
        tuple: (percentage_change, trend_string)
    """
    if previous == 0:
        if current == 0:
            return (0.0, "flat")
        return (100.0, "up")

    percentage = ((current - previous) / previous) * 100

    if percentage > 5:
        trend = "up"
    elif percentage < -5:
        trend = "down"
    else:
        trend = "flat"

    return (round(percentage, 2), trend)


# ============================================================
# 1. GET /api/v1/dashboard/stats - Ana İstatistikler
# ============================================================

@router.get(
    "/stats",
    response_model=DashboardStatsResponse,
    status_code=200,
    summary="Ana İstatistikler",
    description="Ürün, Satış ve Finansman İstatistikleri"
)
async def get_dashboard_stats(
    days: int = Query(30, ge=1, description="Son kaç gündeki veriler"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Ana dashboard istatistiklerini getir

    ## Içerik:
    1. **Ürün İstatistikleri:**
       - total_products: Toplam ürün sayısı
       - total_categories: Kategori çeşitliliği
       - critical_stock_count: Acil sipariş gereken ürünler

    2. **Satış İstatistikleri:**
       - total_sales: Toplam satış tutarı
       - total_revenue: Kar etmiş gelir
       - total_customers: Farklı müşteri sayısı

    3. **Finansman:**
       - outstanding_debt: Ödenmeyen müşteri borçları

    ## Trend Hesaplaması:
    - Her metrik için önceki döneme göre değişim
    - Trend: up (>5% artış), down (<-5% azalış), flat

    Args:
        days: Veri toplamada kullanılacak dönem (default: 30)
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        DashboardStatsResponse: Detaylı istatistikler
    """
    # Mevcut dönemi al (yalnızca giriş yapmış bayi için)
    current_products = get_product_stats(db, data_owner_id(current_user), days)
    current_sales = get_sales_metrics(db, data_owner_id(current_user), days)

    # Önceki dönemi al (trend hesaplamak için)
    previous_products = get_product_stats(db, data_owner_id(current_user), days * 2)
    previous_sales = get_sales_metrics(db, data_owner_id(current_user), days * 2)

    # Trend hesapla
    _, trend_products = calculate_trend(
        current_products["total_products"],
        previous_products["total_products"]
    )
    _, trend_critical = calculate_trend(
        current_products["critical_stock"],
        previous_products["critical_stock"]
    )
    change_sales, trend_sales = calculate_trend(
        current_sales["total_sales"],
        previous_sales["total_sales"]
    )
    change_revenue, trend_revenue = calculate_trend(
        current_sales["total_revenue"],
        previous_sales["total_revenue"]
    )
    change_debt, trend_debt = calculate_trend(
        current_sales["outstanding_debt"],
        previous_sales["outstanding_debt"]
    )

    return DashboardStatsResponse(
        total_products=StatsItem(
            label="Toplam Ürün",
            value=current_products["total_products"],
            percentage_change=0.0,
            trend="flat"
        ),
        total_categories=StatsItem(
            label="Kategoriler",
            value=current_products["total_categories"],
            percentage_change=0.0,
            trend="flat"
        ),
        critical_stock_count=StatsItem(
            label="Kritik Stok",
            value=current_products["critical_stock"],
            percentage_change=0.0,
            trend=trend_critical
        ),
        total_customers=StatsItem(
            label="Müşteriler",
            value=current_sales["unique_customers"],
            percentage_change=0.0,
            trend="flat"
        ),
        total_sales=StatsItem(
            label="Satışlar (₺)",
            value=round(current_sales["total_sales"], 2),
            percentage_change=change_sales,
            trend=trend_sales
        ),
        total_revenue=StatsItem(
            label="Gelir (₺)",
            value=round(current_sales["total_revenue"], 2),
            percentage_change=change_revenue,
            trend=trend_revenue
        ),
        outstanding_debt=StatsItem(
            label="Ödenmemiş Borç (₺)",
            value=round(current_sales["outstanding_debt"], 2),
            percentage_change=change_debt,
            trend=trend_debt
        ),
        period=f"last_{days}_days"
    )


# ============================================================
# 2. GET /api/v1/dashboard/critical-stock - Kritik Stok Uyarıları
# ============================================================

@router.get(
    "/critical-stock",
    response_model=CriticalStockAlertsResponse,
    status_code=200,
    summary="Kritik Stok Uyarıları",
    description="Derhal sipariş edilmesi gereken ürünleri listele"
)
async def get_critical_stock_alerts(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Kritik stok durumundaki ürünleri listele

    ## Severity Seviyeleri:
    - **critical** (kırmızı): Stok %60+ yetersiz (acil siparişe konu)
    - **medium** (sarı): Stok %30-60 yetersiz (en kısa zamanda sipariş ver)
    - **low** (mavi): Stok %10-30 yetersiz (rutin sipariş)

    ## İşlem Adımları:
    1. quantity <= min_stock_alert olan ürünleri bul
    2. Her ürün için eksiklik ve önem seviyesini hesapla
    3. Öneri sipariş miktarını belirle (eksiklik x 2)
    4. Genel priority'yi belirle (en yüksek severity'ye göre)
    5. Eksiklik tutarını hesapla (shortage x price)

    ## Priority Belirleme:
    - High: critical ürün varsa
    - Medium: medium ürün varsa ama critical yoksa
    - Low: sadece low ürünler varsa

    Returns:
        CriticalStockAlertsResponse: Kritik ürünler + özet
    """
    # Kritik stok ürünlerini bul (yalnızca bu bayiye ait)
    critical_products = db.query(Product).filter(
        and_(
            Product.user_id == data_owner_id(current_user),
            Product.quantity <= Product.min_stock_alert,
        )
    ).order_by(Product.quantity).all()

    alerts = []
    critical_count = 0
    medium_count = 0
    low_count = 0
    total_shortage_value = 0.0

    for product in critical_products:
        shortage = product.min_stock_alert - product.quantity
        shortage_percentage = (shortage / product.min_stock_alert * 100) if product.min_stock_alert > 0 else 0
        reorder_qty = shortage * 2

        # Severity belirle
        if shortage_percentage >= 60:
            severity = "critical"
            critical_count += 1
        elif shortage_percentage >= 30:
            severity = "medium"
            medium_count += 1
        else:
            severity = "low"
            low_count += 1

        total_shortage_value += shortage * product.price

        alert = CriticalStockWarningResponse(
            product_id=product.id,
            product_name=product.name,
            category=product.category,
            current_stock=product.quantity,
            min_alert_level=product.min_stock_alert,
            shortage=shortage,
            severity=severity,
            reorder_quantity=reorder_qty,
            last_updated=product.updated_at
        )
        alerts.append(alert)

    # Genel priority'yi belirle
    if critical_count > 0:
        priority = "high"
    elif medium_count > 0:
        priority = "medium"
    else:
        priority = "low"

    return CriticalStockAlertsResponse(
        total_alerts=len(critical_products),
        critical=critical_count,
        medium=medium_count,
        low=low_count,
        alerts=alerts,
        total_shortage_value=round(total_shortage_value, 2),
        priority=priority
    )


# ============================================================
# 3. GET /api/v1/dashboard/performance - Performans Metrikleri
# ============================================================

@router.get(
    "/performance",
    response_model=PerformanceResponse,
    status_code=200,
    summary="Performans Metrikleri",
    description="Satış, Kar ve Stok Döngüsü Performansı"
)
async def get_performance_metrics(
    days: int = Query(30, ge=1, description="Analiz süresi (gün)"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    İşletme performansı metriklerini hesapla

    ## Metrikler:
    1. **Daily/Weekly Average Sales:**
       - Ortalama günlük satış = total_sales / days
       - Ortalama haftalık satış = daily_avg * 7

    2. **Best Selling Product:**
       - En çok satılan ürünü (miktar bazında) bul
       - Ürün bilgileri ve kar marjını göster

    3. **Inventory Turnover:**
       - Stok döngüsü = toplam satış / ortalama stok
       - Yüksek = stok hızlı tükeniyor
       - Düşük = stok yavaş hareket ediyor

    4. **Profit Margin Average:**
       - Tüm ürünlerin ortalama kar marjı
       - Formula: ((price - cost) / cost) * 100

    Args:
        days: Performans analiz süresi (default: 30)
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        PerformanceResponse: Performans metrikleri
    """
    start_date = datetime.now(timezone.utc) - timedelta(days=days)

    # 1. Satış verilerini al (bu bayinin işlemleri)
    total_sales = db.query(func.sum(Transaction.amount)).filter(
        and_(
            Transaction.user_id == data_owner_id(current_user),
            Transaction.transaction_type.in_(["satış", "sale"]),
            Transaction.created_at >= start_date
        )
    ).scalar() or 0.0

    daily_average = total_sales / days if days > 0 else 0
    weekly_average = daily_average * 7

    # 2. En çok satılan ürünü bul — işlem notu + ürün adı eşleştirmesi
    best_product = None
    uid_perf = data_owner_id(current_user)
    # Dönemde satılan işlemler
    sold_txs = db.query(Transaction).filter(
        and_(
            Transaction.user_id == uid_perf,
            Transaction.transaction_type.in_(["satış", "sale"]),
            Transaction.created_at >= start_date,
        )
    ).all()
    # Transaction notes'undan ürün adı çıkar, tutar bazlı sırala
    sales_by_product: dict = {}
    for tx in sold_txs:
        name = (tx.customer_name or tx.description or "").strip() or "Bilinmiyor"
        sales_by_product[name] = sales_by_product.get(name, {"revenue": 0.0, "count": 0})
        sales_by_product[name]["revenue"] += float(tx.amount or 0)
        sales_by_product[name]["count"] += 1
    if sales_by_product:
        top_name = max(sales_by_product, key=lambda k: sales_by_product[k]["revenue"])
        top = sales_by_product[top_name]
        # Ürün tablosundan eşleştirme dene
        matched = db.query(Product).filter(
            and_(Product.user_id == uid_perf, Product.name == top_name)
        ).first()
        cat = matched.category if matched else ""
        profit_m = ((matched.price - matched.cost) / matched.cost * 100) if matched and matched.cost and matched.cost > 0 else 0.0
        best_product = TopProductResponse(
            product_id=matched.id if matched else 0,
            product_name=top_name,
            category=cat,
            total_sold=top["count"],
            total_revenue=round(top["revenue"], 2),
            profit_margin=round(profit_m, 2),
        )
    else:
        # Satış yoksa en değerli ürünü göster
        fallback = db.query(Product).filter(Product.user_id == uid_perf).order_by(
            (Product.price * Product.quantity).desc()
        ).first()
        if fallback:
            profit_m = ((fallback.price - fallback.cost) / fallback.cost * 100) if fallback.cost and fallback.cost > 0 else 0.0
            best_product = TopProductResponse(
                product_id=fallback.id,
                product_name=fallback.name,
                category=fallback.category or "",
                total_sold=0,
                total_revenue=0.0,
                profit_margin=round(profit_m, 2),
            )

    # 3. Stok Döngüsü (Inventory Turnover) — bu bayinin envanterinden
    total_stock = db.query(func.sum(Product.quantity)).filter(
        Product.user_id == data_owner_id(current_user)
    ).scalar() or 0
    avg_stock = total_stock / 2 if total_stock > 0 else 1  # Simplified
    inventory_turnover = total_sales / avg_stock if avg_stock > 0 else 0

    # 4. Ortalama Kar Marjı (bu bayinin ürünleri)
    avg_profit_margin = db.query(
        func.avg((Product.price - Product.cost) / Product.cost * 100)
    ).filter(
        and_(Product.user_id == data_owner_id(current_user), Product.cost > 0)
    ).scalar() or 0.0

    return PerformanceResponse(
        period=f"last_{days}_days",
        daily_average_sales=round(daily_average, 2),
        weekly_average_sales=round(weekly_average, 2),
        best_selling_product=best_product,
        inventory_turnover=round(inventory_turnover, 2),
        profit_margin_average=round(avg_profit_margin, 2)
    )


# ============================================================
# 4. GET /api/v1/dashboard/chart-data - Grafik Verisi
# ============================================================

@router.get(
    "/chart-data",
    response_model=ChartDataResponse,
    status_code=200,
    summary="Satış Grafik Verisi",
    description="Zaman serisi satış verileri (günlük)"
)
async def get_chart_data(
    chart_type: str = Query("sales", description="sales, revenue, transactions"),
    days: int = Query(7, ge=1, le=365, description="Son kaç gün"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Grafik çizimi için zaman serisi verileri

    ## Chart Türleri:
    - **sales**: Günlük satış tutarı
    - **revenue**: Günlük tahmini gelir
    - **transactions**: Günlük işlem sayısı

    ## İşlem Adımları:
    1. Belirtilen gün sayısı için tarih aralığını oluştur
    2. Her gün için satış verilerini grupla
    3. İstenen chart_type'ına göre veri hesapla
    4. Sıfır satışlı günleri de dahil et (boşluk olmasın diye)

    Args:
        chart_type: Grafiğin tipi
        days: Kaç günlük veri (1-365)
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        ChartDataResponse: Zaman serisi veri
    """
    data_points = []
    total_value = 0.0

    # Kullanıcının ürünlerinden ortalama kar marjı hesapla
    uid = data_owner_id(current_user)
    avg_margin_raw = db.query(
        func.avg((Product.price - Product.cost) / Product.cost * 100)
    ).filter(
        and_(Product.user_id == uid, Product.cost > 0)
    ).scalar()
    margin_rate = (avg_margin_raw or 65.0) / 100.0

    # Her gün için veri oluştur
    for i in range(days):
        current_day = datetime.now(timezone.utc) - timedelta(days=days - i - 1)
        day_start = current_day.replace(hour=0, minute=0, second=0, microsecond=0)
        day_end = current_day.replace(hour=23, minute=59, second=59, microsecond=999999)

        # Günlük satışları topla (bu bayinin işlemleri)
        day_sales = db.query(func.sum(Transaction.amount)).filter(
            and_(
                Transaction.user_id == uid,
                Transaction.transaction_type.in_(["satış", "sale"]),
                Transaction.created_at >= day_start,
                Transaction.created_at <= day_end
            )
        ).scalar() or 0.0

        # Günlük işlem sayısı
        day_transactions = db.query(func.count(Transaction.id)).filter(
            and_(
                Transaction.user_id == uid,
                Transaction.created_at >= day_start,
                Transaction.created_at <= day_end
            )
        ).scalar() or 0

        # Müşteri sayısı
        day_customers = db.query(func.count(distinct(Transaction.customer_name))).filter(
            and_(
                Transaction.user_id == uid,
                Transaction.created_at >= day_start,
                Transaction.created_at <= day_end
            )
        ).scalar() or 0

        day_revenue = round(day_sales * margin_rate, 2)

        # Chart type'ına göre değer belirle
        if chart_type == "revenue":
            value = day_revenue
        elif chart_type == "transactions":
            value = float(day_transactions)
        else:  # sales (default)
            value = day_sales

        total_value += value

        data_point = SalesChartData(
            date=current_day.strftime("%Y-%m-%d"),
            sales=day_sales,
            revenue=day_revenue,
            transactions=day_transactions,
            customers=day_customers
        )
        data_points.append(data_point)

    return ChartDataResponse(
        chart_type=chart_type,
        period=f"last_{days}_days",
        data=data_points,
        total=round(total_value, 2)
    )


# ============================================================
# 5. GET /api/v1/dashboard - Tam Dashboard Özeti
# ============================================================

@router.get(
    "",
    response_model=DashboardOverviewResponse,
    status_code=200,
    summary="Dashboard Özeti",
    description="Tüm dashboard verilerini tek çağrıda getir"
)
async def get_dashboard_overview(
    days: int = Query(30, ge=1, description="Veri süresi"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Tüm dashboard bilgilerini bir arada döndür

    ## İçerir:
    1. Ana İstatistikler (stats endpoint'inin çıktısı)
    2. Kritik Stok Uyarıları (critical-stock endpoint'inin çıktısı)
    3. Performans Metrikleri (performance endpoint'inin çıktısı)
    4. Oluşturulma Tarihi

    ## Kullanım Senaryosu:
    - Dashboard sayfası açıldığında tek çağrı yeterli
    - Tüm gerekli bilgiler response'da var
    - Client-side filtering/sorting yapılabilir

    Args:
        days: Veri toplama süresi
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        DashboardOverviewResponse: Tam dashboard verisi
    """
    # Stats'ı al
    stats_response = await get_dashboard_stats(days, current_user, db)

    # Critical stock'u al
    alerts_response = await get_critical_stock_alerts(current_user, db)

    # Performance'ı al
    performance_response = await get_performance_metrics(days, current_user, db)

    return DashboardOverviewResponse(
        stats=stats_response,
        critical_alerts=alerts_response,
        performance=performance_response,
        generated_at=datetime.now(timezone.utc)
    )


# ============================================================
# 6. GET /api/v1/dashboard/activities - Aktivite Günlüğü
# ============================================================

@router.get(
    "/activities",
    status_code=200,
    summary="Aktivite Günlüğü",
    description="Sistemdeki tüm aktiviteleri (ekleme, silme, güncelleme) listele"
)
async def get_activities(
    limit: int = Query(50, ge=1, le=200, description="Kaç adet kayıt"),
    activity_type: str = Query(None, description="Filtre: product, transaction, vb."),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    İşlem geçmişi/aktivite logu döndür

    ## Filtreler:
    - activity_type: product, transaction, user, file (opsiyonel)
    - limit: Maksimum kayıt sayısı (1-200, default: 50)

    Returns:
        items: Aktivite kayıtları (en yeni önce)
        total: Toplam kayıt sayısı
    """
    # Yalnızca giriş yapmış bayinin aktivite kayıtları
    query = db.query(ActivityLog).filter(
        ActivityLog.user_id == data_owner_id(current_user)
    ).order_by(ActivityLog.created_at.desc())

    if activity_type:
        query = query.filter(ActivityLog.entity_type == activity_type)

    total = query.count()
    activities = query.limit(limit).all()

    # Frontend için kategori eşleştirmesi
    category_map = {
        "product": "Stok İşlemleri",
        "transaction": "Finans & Cari",
        "user": "Sistem Ayarları",
        "file": "Sistem Ayarları",
        "auth": "Sistem Ayarları",
        "report": "İşlem",
    }

    action_label_map = {
        "create": "Yeni Kayıt Oluşturuldu",
        "update": "Kayıt Güncellendi",
        "delete": "Kayıt Silindi",
        "view": "Görüntülendi",
        "login": "Giriş Yapıldı",
        "logout": "Çıkış Yapıldı",
        "register": "Yeni Hesap Oluşturuldu",
    }

    items = []
    for log in activities:
        items.append({
            "id": log.id,
            "user": log.user_name or "Sistem",
            "action": action_label_map.get(log.action_type, log.action_type),
            "detail": log.description,
            "time": log.created_at.isoformat() if log.created_at else None,
            "type": log.entity_type,
            "category": category_map.get(log.entity_type, "İşlem"),
            "status": log.status,
        })

    return {
        "items": items,
        "total": total,
        "limit": limit,
    }


# ============================================================
# 8. GET /api/v1/dashboard/finance-breakdown - Detaylı Finans Dağılımı
# ============================================================
# Gelişmiş raporlar için tıklanabilir metrik kartlarını besler.
# Her tip için tutar/sayı; period parametresi ile bugün/hafta/ay/yıl.
# ============================================================
@router.get(
    "/finance-breakdown",
    summary="Detaylı Finans Dağılımı",
    description="Her işlem tipi için tutar+adet (bugün/hafta/ay/yıl)"
)
async def get_finance_breakdown(
    period: str = Query("month", description="today | week | month | year | all"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    period_map = {
        "today": 1,
        "week": 7,
        "month": 30,
        "year": 365,
        "all": 36500,
    }
    days = period_map.get(period, 30)

    if period == "today":
        start_dt = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        start_dt = datetime.now(timezone.utc) - timedelta(days=days)

    type_groups = {
        "satış":     ["satış", "sale"],
        "borç":      ["borç", "debt"],
        "ödeme":     ["ödeme", "payment"],
        "gider":     ["gider", "expense"],
        "senet":     ["senet"],
        "kredi":     ["kredi", "loan"],
        "garanti":   ["garanti"],
    }

    breakdown = {}
    for label, types in type_groups.items():
        row = db.query(
            func.coalesce(func.sum(Transaction.amount), 0.0),
            func.count(Transaction.id),
        ).filter(
            and_(
                Transaction.user_id == data_owner_id(current_user),
                Transaction.transaction_type.in_(types),
                Transaction.created_at >= start_dt,
            )
        ).one()
        breakdown[label] = {
            "total": float(row[0] or 0.0),
            "count": int(row[1] or 0),
            "types": types,
        }

    # Tüm zamanlardaki açık müşteri borcu (dönem bağımsız)
    uid = data_owner_id(current_user)
    all_debt = db.query(func.coalesce(func.sum(Transaction.amount), 0.0)).filter(
        and_(Transaction.user_id == uid, Transaction.transaction_type.in_(["borç", "debt"]))
    ).scalar() or 0.0
    all_paid = db.query(func.coalesce(func.sum(Transaction.amount), 0.0)).filter(
        and_(Transaction.user_id == uid, Transaction.transaction_type.in_(["ödeme", "payment"]))
    ).scalar() or 0.0
    outstanding = round(float(all_debt) - float(all_paid), 2)

    return {
        "period": period,
        "start_date": start_dt.isoformat(),
        "breakdown": breakdown,
        "outstanding_debt": outstanding,
    }


# ============================================================
# 9. GET /api/v1/dashboard/top-products - En İyi Ürünler
# ============================================================

@router.get(
    "/top-products",
    status_code=200,
    summary="En İyi Ürünler",
    description="Stok değeri, kritik stok veya kar marjına göre sıralanmış ürünler"
)
async def get_top_products(
    sort_by: str = Query("stock_value", description="stock_value | low_stock | profit"),
    limit: int = Query(5, ge=1, le=10),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    uid = data_owner_id(current_user)
    products = db.query(Product).filter(Product.user_id == uid).all()

    if sort_by == "low_stock":
        candidates = [p for p in products if p.min_stock_alert > 0]
        items = sorted(candidates, key=lambda p: p.quantity / max(p.min_stock_alert, 1))[:limit]
        return [
            {
                "name": p.name,
                "category": p.category or "",
                "quantity": p.quantity,
                "min_stock": p.min_stock_alert,
                "pct": round(p.quantity / max(p.min_stock_alert, 1) * 100, 1),
                "value": round(p.price * p.quantity, 2),
            }
            for p in items
        ]
    elif sort_by == "profit":
        candidates = [p for p in products if p.cost and p.cost > 0]
        items = sorted(candidates, key=lambda p: (p.price - p.cost) / p.cost, reverse=True)[:limit]
        return [
            {
                "name": p.name,
                "category": p.category or "",
                "quantity": p.quantity,
                "price": float(p.price),
                "cost": float(p.cost),
                "margin_pct": round((p.price - p.cost) / p.cost * 100, 1),
                "value": round(p.price * p.quantity, 2),
            }
            for p in items
        ]
    else:  # stock_value (default)
        items = sorted(products, key=lambda p: float(p.price or 0) * (p.quantity or 0), reverse=True)[:limit]
        return [
            {
                "name": p.name,
                "category": p.category or "",
                "quantity": p.quantity,
                "price": float(p.price or 0),
                "value": round(float(p.price or 0) * (p.quantity or 0), 2),
            }
            for p in items
        ]
