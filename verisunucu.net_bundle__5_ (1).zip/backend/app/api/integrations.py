"""
Entegrasyon Modülü: ERP Webhook, Sanal POS, DBS
"""
from __future__ import annotations

import time
from datetime import datetime, date, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.integrations import (
    DbsAgreement, DbsInvoice, ErpSyncLog, ErpWebhook,
    PaymentGateway, PosTransaction,
)
from app.schemas.integrations import (
    DbsAgreementCreate, DbsAgreementOut, DbsAgreementUpdate,
    DbsInvoiceCreate, DbsInvoiceOut, DbsInvoiceUpdate,
    ErpSyncLogOut, ErpWebhookCreate, ErpWebhookOut, ErpWebhookUpdate,
    IntegrationStatsOut,
    PaymentGatewayCreate, PaymentGatewayOut, PaymentGatewayUpdate,
    PosTransactionCreate, PosTransactionOut,
)
from app.utils.auth import get_current_user
from app.utils.permissions import require_perm
from app.utils.tenant import data_owner_id
from app.services.sync_service import record_deletion, trigger_delta_push

router = APIRouter(prefix="/integrations", tags=["Integrations"])


def _owner_or_404(db: Session, model, record_id: int, owner_id: int):
    obj = db.query(model).filter(model.id == record_id, model.user_id == owner_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="Kayıt bulunamadı")
    return obj


# ── Stats ──────────────────────────────────────────────────────

@router.get("/stats", response_model=IntegrationStatsOut)
def get_integration_stats(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.view")
    owner = data_owner_id(current_user)
    now = datetime.now(timezone.utc)
    today = now.date()

    webhook_count = db.query(func.count(ErpWebhook.id)).filter(ErpWebhook.user_id == owner).scalar() or 0
    active_webhooks = db.query(func.count(ErpWebhook.id)).filter(ErpWebhook.user_id == owner, ErpWebhook.is_active == True).scalar() or 0
    pos_gateway_count = db.query(func.count(PaymentGateway.id)).filter(PaymentGateway.user_id == owner).scalar() or 0
    total_pos_volume = float(
        db.query(func.coalesce(func.sum(PosTransaction.amount), 0))
        .filter(PosTransaction.user_id == owner, PosTransaction.status == "success")
        .scalar() or 0
    )
    dbs_agreement_count = db.query(func.count(DbsAgreement.id)).filter(DbsAgreement.user_id == owner, DbsAgreement.is_active == True).scalar() or 0
    dbs_pending_amount = float(
        db.query(func.coalesce(func.sum(DbsInvoice.amount), 0))
        .filter(DbsInvoice.user_id == owner, DbsInvoice.status.in_(["pending", "sent"]))
        .scalar() or 0
    )
    erp_logs_today = db.query(func.count(ErpSyncLog.id)).filter(
        ErpSyncLog.user_id == owner,
        func.date(ErpSyncLog.created_at) == today,
    ).scalar() or 0

    return IntegrationStatsOut(
        webhook_count=webhook_count,
        active_webhooks=active_webhooks,
        pos_gateway_count=pos_gateway_count,
        total_pos_volume=total_pos_volume,
        dbs_agreement_count=dbs_agreement_count,
        dbs_pending_amount=dbs_pending_amount,
        erp_logs_today=erp_logs_today,
    )


# ── ERP Webhooks ───────────────────────────────────────────────

@router.get("/erp/webhooks", response_model=List[ErpWebhookOut])
def list_erp_webhooks(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.view")
    owner = data_owner_id(current_user)
    return [ErpWebhookOut.model_validate(w) for w in
            db.query(ErpWebhook).filter(ErpWebhook.user_id == owner).order_by(ErpWebhook.created_at.desc()).all()]


@router.post("/erp/webhooks", response_model=ErpWebhookOut, status_code=201)
def create_erp_webhook(
    data: ErpWebhookCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.add")
    owner = data_owner_id(current_user)
    wh = ErpWebhook(user_id=owner, **data.model_dump())
    db.add(wh)
    db.commit()
    db.refresh(wh)
    return ErpWebhookOut.model_validate(wh)


@router.put("/erp/webhooks/{webhook_id}", response_model=ErpWebhookOut)
def update_erp_webhook(
    webhook_id: int,
    data: ErpWebhookUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.edit")
    owner = data_owner_id(current_user)
    wh = _owner_or_404(db, ErpWebhook, webhook_id, owner)
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(wh, k, v)
    db.commit()
    db.refresh(wh)
    return ErpWebhookOut.model_validate(wh)


@router.delete("/erp/webhooks/{webhook_id}", status_code=204)
def delete_erp_webhook(
    webhook_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.delete")
    owner = data_owner_id(current_user)
    wh = _owner_or_404(db, ErpWebhook, webhook_id, owner)
    db.query(ErpSyncLog).filter(ErpSyncLog.webhook_id == wh.id).update(
        {"webhook_id": None}, synchronize_session=False
    )
    record_deletion(db, "erp_webhooks", wh.id)
    db.delete(wh)
    db.commit()
    trigger_delta_push()


@router.get("/erp/logs", response_model=List[ErpSyncLogOut])
def list_erp_logs(
    webhook_id: Optional[int] = Query(None),
    limit: int = Query(50, ge=1, le=500),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.view")
    owner = data_owner_id(current_user)
    q = db.query(ErpSyncLog).filter(ErpSyncLog.user_id == owner)
    if webhook_id is not None:
        q = q.filter(ErpSyncLog.webhook_id == webhook_id)
    logs = q.order_by(ErpSyncLog.created_at.desc()).limit(limit).all()
    return [ErpSyncLogOut.model_validate(l) for l in logs]


@router.post("/erp/webhooks/{webhook_id}/test")
def test_erp_webhook(
    webhook_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.edit")
    owner = data_owner_id(current_user)
    wh = _owner_or_404(db, ErpWebhook, webhook_id, owner)

    payload = {
        "event": "webhook.test",
        "source": "stokfinans",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "data": {"message": "StokFinans test webhook — bağlantı başarılı"},
    }
    headers = {"Content-Type": "application/json", "X-StokFinans-Event": "webhook.test"}
    if wh.headers_json:
        headers.update(wh.headers_json)

    http_status: Optional[int] = None
    response_body: Optional[str] = None
    success = False
    duration_ms: Optional[int] = None

    t0 = time.time()
    try:
        try:
            import httpx
            resp = httpx.post(wh.url, json=payload, headers=headers, timeout=8)
            http_status = resp.status_code
            response_body = resp.text[:500]
            success = 200 <= resp.status_code < 300
        except ImportError:
            import requests as req_lib
            resp = req_lib.post(wh.url, json=payload, headers=headers, timeout=8)
            http_status = resp.status_code
            response_body = resp.text[:500]
            success = 200 <= resp.status_code < 300
    except Exception as exc:
        response_body = str(exc)[:500]
        success = False
    finally:
        duration_ms = int((time.time() - t0) * 1000)

    log = ErpSyncLog(
        user_id=owner,
        webhook_id=wh.id,
        event_type="webhook.test",
        payload_json=payload,
        http_status_code=http_status,
        response_body=response_body,
        duration_ms=duration_ms,
        success=success,
    )
    db.add(log)
    wh.last_triggered_at = datetime.now(timezone.utc)
    wh.last_http_status = http_status
    db.commit()

    return {"success": success, "http_status": http_status, "message": response_body or "Bağlantı denendi"}


# ── Payment Gateways ───────────────────────────────────────────

@router.get("/pos/gateways", response_model=List[PaymentGatewayOut])
def list_gateways(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.view")
    owner = data_owner_id(current_user)
    return [PaymentGatewayOut.model_validate(g) for g in
            db.query(PaymentGateway).filter(PaymentGateway.user_id == owner).all()]


@router.post("/pos/gateways", response_model=PaymentGatewayOut, status_code=201)
def create_gateway(
    data: PaymentGatewayCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.add")
    owner = data_owner_id(current_user)
    gw = PaymentGateway(user_id=owner, **data.model_dump())
    db.add(gw)
    db.commit()
    db.refresh(gw)
    return PaymentGatewayOut.model_validate(gw)


@router.put("/pos/gateways/{gateway_id}", response_model=PaymentGatewayOut)
def update_gateway(
    gateway_id: int,
    data: PaymentGatewayUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.edit")
    owner = data_owner_id(current_user)
    gw = _owner_or_404(db, PaymentGateway, gateway_id, owner)
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(gw, k, v)
    db.commit()
    db.refresh(gw)
    return PaymentGatewayOut.model_validate(gw)


@router.delete("/pos/gateways/{gateway_id}", status_code=204)
def delete_gateway(
    gateway_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.delete")
    owner = data_owner_id(current_user)
    gw = _owner_or_404(db, PaymentGateway, gateway_id, owner)
    txn_count = db.query(func.count(PosTransaction.id)).filter(PosTransaction.gateway_id == gw.id).scalar() or 0
    if txn_count > 0:
        raise HTTPException(400, "Bu POS'a bağlı işlemler var — silinemez.")
    record_deletion(db, "payment_gateways", gw.id)
    db.delete(gw)
    db.commit()
    trigger_delta_push()


@router.get("/pos/transactions", response_model=List[PosTransactionOut])
def list_pos_transactions(
    btb_order_id: Optional[int] = Query(None),
    gateway_id: Optional[int] = Query(None),
    limit: int = Query(100, ge=1, le=500),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.view")
    owner = data_owner_id(current_user)
    q = db.query(PosTransaction).filter(PosTransaction.user_id == owner)
    if btb_order_id is not None:
        q = q.filter(PosTransaction.btb_order_id == btb_order_id)
    if gateway_id is not None:
        q = q.filter(PosTransaction.gateway_id == gateway_id)
    return [PosTransactionOut.model_validate(t) for t in q.order_by(PosTransaction.created_at.desc()).limit(limit).all()]


@router.post("/pos/transactions", response_model=PosTransactionOut, status_code=201)
def create_pos_transaction(
    data: PosTransactionCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.add")
    owner = data_owner_id(current_user)
    commission_amount = round(data.amount * data.commission_rate / 100, 2)
    txn = PosTransaction(
        user_id=owner,
        btb_order_id=data.btb_order_id,
        gateway_id=data.gateway_id,
        transaction_ref=data.transaction_ref,
        amount=data.amount,
        currency=data.currency,
        commission_rate=data.commission_rate,
        commission_amount=commission_amount,
        is_commission_reflected=data.is_commission_reflected,
        installments=data.installments,
        card_last4=data.card_last4,
        card_bank=data.card_bank,
        status=data.status,
        notes=data.notes,
    )
    db.add(txn)
    db.commit()
    db.refresh(txn)
    return PosTransactionOut.model_validate(txn)


# ── DBS ────────────────────────────────────────────────────────

def _agreement_out(agreement: DbsAgreement, db: Session) -> DbsAgreementOut:
    out = DbsAgreementOut.model_validate(agreement)
    out.invoice_count = db.query(func.count(DbsInvoice.id)).filter(DbsInvoice.agreement_id == agreement.id).scalar() or 0
    out.pending_amount = float(
        db.query(func.coalesce(func.sum(DbsInvoice.amount), 0))
        .filter(DbsInvoice.agreement_id == agreement.id, DbsInvoice.status.in_(["pending", "sent"]))
        .scalar() or 0
    )
    return out


@router.get("/dbs/agreements", response_model=List[DbsAgreementOut])
def list_dbs_agreements(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.view")
    owner = data_owner_id(current_user)
    agreements = db.query(DbsAgreement).filter(DbsAgreement.user_id == owner).order_by(DbsAgreement.created_at.desc()).all()
    return [_agreement_out(a, db) for a in agreements]


@router.post("/dbs/agreements", response_model=DbsAgreementOut, status_code=201)
def create_dbs_agreement(
    data: DbsAgreementCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.add")
    owner = data_owner_id(current_user)
    agreement = DbsAgreement(user_id=owner, **data.model_dump())
    db.add(agreement)
    db.commit()
    db.refresh(agreement)
    return _agreement_out(agreement, db)


@router.put("/dbs/agreements/{agreement_id}", response_model=DbsAgreementOut)
def update_dbs_agreement(
    agreement_id: int,
    data: DbsAgreementUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.edit")
    owner = data_owner_id(current_user)
    agreement = _owner_or_404(db, DbsAgreement, agreement_id, owner)
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(agreement, k, v)
    db.commit()
    db.refresh(agreement)
    return _agreement_out(agreement, db)


@router.delete("/dbs/agreements/{agreement_id}", status_code=204)
def delete_dbs_agreement(
    agreement_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.delete")
    owner = data_owner_id(current_user)
    agreement = _owner_or_404(db, DbsAgreement, agreement_id, owner)
    pending = db.query(func.count(DbsInvoice.id)).filter(
        DbsInvoice.agreement_id == agreement.id,
        DbsInvoice.status.in_(["pending", "sent"]),
    ).scalar() or 0
    if pending > 0:
        raise HTTPException(400, "Bu anlaşmaya bağlı bekleyen faturalar var — önce iptal edin.")
    db.query(DbsInvoice).filter(DbsInvoice.agreement_id == agreement.id).update(
        {"agreement_id": None}, synchronize_session=False
    )
    record_deletion(db, "dbs_agreements", agreement.id)
    db.delete(agreement)
    db.commit()
    trigger_delta_push()


@router.get("/dbs/invoices", response_model=List[DbsInvoiceOut])
def list_dbs_invoices(
    agreement_id: Optional[int] = Query(None),
    status_filter: Optional[str] = Query(None, alias="status"),
    overdue_only: bool = Query(False),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.view")
    owner = data_owner_id(current_user)
    q = db.query(DbsInvoice).filter(DbsInvoice.user_id == owner)
    if agreement_id is not None:
        q = q.filter(DbsInvoice.agreement_id == agreement_id)
    if status_filter:
        q = q.filter(DbsInvoice.status == status_filter)
    if overdue_only:
        today = datetime.now(timezone.utc).date()
        q = q.filter(DbsInvoice.status.in_(["pending", "sent"]), DbsInvoice.due_date < today)
    return [DbsInvoiceOut.model_validate(i) for i in q.order_by(DbsInvoice.due_date).all()]


@router.post("/dbs/invoices", response_model=DbsInvoiceOut, status_code=201)
def create_dbs_invoice(
    data: DbsInvoiceCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.add")
    owner = data_owner_id(current_user)
    inv = DbsInvoice(user_id=owner, **data.model_dump())
    db.add(inv)
    db.commit()
    db.refresh(inv)
    return DbsInvoiceOut.model_validate(inv)


@router.put("/dbs/invoices/{invoice_id}", response_model=DbsInvoiceOut)
def update_dbs_invoice(
    invoice_id: int,
    data: DbsInvoiceUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.edit")
    owner = data_owner_id(current_user)
    inv = _owner_or_404(db, DbsInvoice, invoice_id, owner)
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(inv, k, v)
    db.commit()
    db.refresh(inv)
    return DbsInvoiceOut.model_validate(inv)


@router.delete("/dbs/invoices/{invoice_id}", status_code=204)
def delete_dbs_invoice(
    invoice_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.delete")
    owner = data_owner_id(current_user)
    inv = _owner_or_404(db, DbsInvoice, invoice_id, owner)
    if inv.status != "pending":
        raise HTTPException(400, "Yalnızca 'pending' faturalar silinebilir.")
    record_deletion(db, "dbs_invoices", inv.id)
    db.delete(inv)
    db.commit()
    trigger_delta_push()


@router.post("/dbs/invoices/{invoice_id}/send", response_model=DbsInvoiceOut)
def send_dbs_invoice(
    invoice_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.edit")
    owner = data_owner_id(current_user)
    inv = _owner_or_404(db, DbsInvoice, invoice_id, owner)
    if inv.status != "pending":
        raise HTTPException(400, f"Fatura zaten '{inv.status}' durumunda.")
    inv.status = "sent"
    inv.sent_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(inv)
    return DbsInvoiceOut.model_validate(inv)


@router.post("/dbs/invoices/{invoice_id}/collect", response_model=DbsInvoiceOut)
def collect_dbs_invoice(
    invoice_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "integrations.edit")
    owner = data_owner_id(current_user)
    inv = _owner_or_404(db, DbsInvoice, invoice_id, owner)
    if inv.status not in ("pending", "sent"):
        raise HTTPException(400, f"Tahsilat için fatura 'pending' veya 'sent' olmalı (şu an: '{inv.status}').")
    inv.status = "collected"
    inv.collected_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(inv)
    return DbsInvoiceOut.model_validate(inv)
