"""
Toptancı / Tedarikçi Modülü
Alım siparişleri, mal kabul, stok artırımı ve toptancı borç takibi.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models import Transaction, Product
from app.models.supplier import Supplier, PurchaseOrder, PurchaseOrderItem
from app.schemas.supplier import (
    SupplierCreate, SupplierUpdate, SupplierOut,
    PurchaseOrderCreate, PurchaseOrderUpdate, PurchaseOrderOut,
    PurchaseItemOut, SupplierStatsOut,
)
from app.utils.auth import get_current_user
from app.utils.permissions import require_perm
from app.utils.tenant import data_owner_id
from app.services.sync_service import record_deletion, trigger_delta_push

router = APIRouter(prefix="/supplier", tags=["Supplier"])


# ── Helpers ───────────────────────────────────────────────────

def _get_supplier_or_404(db: Session, supplier_id: int, owner_id: int) -> Supplier:
    s = db.query(Supplier).filter(
        Supplier.id == supplier_id,
        Supplier.user_id == owner_id,
    ).first()
    if not s:
        raise HTTPException(status_code=404, detail="Tedarikçi bulunamadı")
    return s


def _get_purchase_or_404(db: Session, order_id: int, owner_id: int) -> PurchaseOrder:
    o = db.query(PurchaseOrder).filter(
        PurchaseOrder.id == order_id,
        PurchaseOrder.user_id == owner_id,
    ).first()
    if not o:
        raise HTTPException(status_code=404, detail="Satın alma siparişi bulunamadı")
    return o


def _next_purchase_number(db: Session, owner_id: int) -> str:
    year = datetime.now(timezone.utc).year
    count = db.query(func.count(PurchaseOrder.id)).filter(
        PurchaseOrder.user_id == owner_id,
        func.extract("year", PurchaseOrder.created_at) == year,
    ).scalar() or 0
    return f"SAT-{year}-{count + 1:04d}"


def _compute_purchase_totals(items_data: list):
    subtotal = 0.0
    kdv_total = 0.0
    for it in items_data:
        qty = int(it.quantity if hasattr(it, "quantity") else it.get("quantity", 1))
        price = float(it.unit_price if hasattr(it, "unit_price") else it.get("unit_price", 0))
        kdv = float(it.kdv_rate if hasattr(it, "kdv_rate") else it.get("kdv_rate", 0))
        line_base = price * qty
        line_kdv = line_base * kdv / 100
        subtotal += line_base
        kdv_total += line_kdv
    total = round(subtotal + kdv_total, 2)
    return round(subtotal, 2), round(kdv_total, 2), total


def _item_line_total(item) -> float:
    qty = int(item.quantity if hasattr(item, "quantity") else item.get("quantity", 1))
    price = float(item.unit_price if hasattr(item, "unit_price") else item.get("unit_price", 0))
    kdv = float(item.kdv_rate if hasattr(item, "kdv_rate") else item.get("kdv_rate", 0))
    base = price * qty
    return round(base * (1 + kdv / 100), 2)


def _purchase_out(order: PurchaseOrder, db: Session) -> PurchaseOrderOut:
    supplier = db.query(Supplier).filter(Supplier.id == order.supplier_id).first()
    out = PurchaseOrderOut.model_validate(order)
    out.supplier_name = supplier.company_name if supplier else ""
    items = db.query(PurchaseOrderItem).filter(PurchaseOrderItem.order_id == order.id).all()
    out.items = [PurchaseItemOut.model_validate(i) for i in items]
    return out


# ── Stats ─────────────────────────────────────────────────────

@router.get("/stats", response_model=SupplierStatsOut)
def get_supplier_stats(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "supplier.view")
    owner = data_owner_id(current_user)

    active_purchases = db.query(func.count(PurchaseOrder.id)).filter(
        PurchaseOrder.user_id == owner,
        PurchaseOrder.status.in_(["draft", "ordered"]),
    ).scalar() or 0

    total_payable = float(
        db.query(func.coalesce(func.sum(PurchaseOrder.total_amount), 0)).filter(
            PurchaseOrder.user_id == owner,
            PurchaseOrder.status == "received",
            PurchaseOrder.is_paid == False,
        ).scalar() or 0
    )

    supplier_count = db.query(func.count(Supplier.id)).filter(
        Supplier.user_id == owner,
        Supplier.is_active == True,
    ).scalar() or 0

    now = datetime.now(timezone.utc)
    received_this_month = db.query(func.count(PurchaseOrder.id)).filter(
        PurchaseOrder.user_id == owner,
        PurchaseOrder.status == "received",
        func.extract("year", PurchaseOrder.updated_at) == now.year,
        func.extract("month", PurchaseOrder.updated_at) == now.month,
    ).scalar() or 0

    return SupplierStatsOut(
        active_purchases=active_purchases,
        total_payable=total_payable,
        supplier_count=supplier_count,
        received_this_month=received_this_month,
    )


# ── Suppliers ─────────────────────────────────────────────────

@router.get("/suppliers", response_model=List[SupplierOut])
def list_suppliers(
    q: Optional[str] = Query(None),
    active_only: bool = Query(False),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "supplier.view")
    owner = data_owner_id(current_user)
    query = db.query(Supplier).filter(Supplier.user_id == owner)
    if active_only:
        query = query.filter(Supplier.is_active == True)
    if q:
        like = f"%{q}%"
        query = query.filter(
            Supplier.company_name.ilike(like) |
            Supplier.contact_person.ilike(like) |
            Supplier.phone.ilike(like)
        )
    suppliers = query.order_by(Supplier.company_name).all()

    result = []
    for s in suppliers:
        out = SupplierOut.model_validate(s)
        out.order_count = db.query(func.count(PurchaseOrder.id)).filter(
            PurchaseOrder.supplier_id == s.id,
        ).scalar() or 0
        out.total_payable = float(
            db.query(func.coalesce(func.sum(PurchaseOrder.total_amount), 0)).filter(
                PurchaseOrder.supplier_id == s.id,
                PurchaseOrder.status == "received",
                PurchaseOrder.is_paid == False,
            ).scalar() or 0
        )
        result.append(out)
    return result


@router.post("/suppliers", response_model=SupplierOut, status_code=201)
def create_supplier(
    data: SupplierCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "supplier.add")
    owner = data_owner_id(current_user)
    supplier = Supplier(user_id=owner, **data.model_dump())
    db.add(supplier)
    db.commit()
    db.refresh(supplier)
    return SupplierOut.model_validate(supplier)


@router.get("/suppliers/{supplier_id}", response_model=SupplierOut)
def get_supplier(
    supplier_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "supplier.view")
    owner = data_owner_id(current_user)
    s = _get_supplier_or_404(db, supplier_id, owner)
    out = SupplierOut.model_validate(s)
    out.order_count = db.query(func.count(PurchaseOrder.id)).filter(
        PurchaseOrder.supplier_id == s.id,
    ).scalar() or 0
    out.total_payable = float(
        db.query(func.coalesce(func.sum(PurchaseOrder.total_amount), 0)).filter(
            PurchaseOrder.supplier_id == s.id,
            PurchaseOrder.status == "received",
            PurchaseOrder.is_paid == False,
        ).scalar() or 0
    )
    return out


@router.put("/suppliers/{supplier_id}", response_model=SupplierOut)
def update_supplier(
    supplier_id: int,
    data: SupplierUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "supplier.edit")
    owner = data_owner_id(current_user)
    s = _get_supplier_or_404(db, supplier_id, owner)
    for field, val in data.model_dump(exclude_unset=True).items():
        setattr(s, field, val)
    db.commit()
    db.refresh(s)
    return SupplierOut.model_validate(s)


@router.delete("/suppliers/{supplier_id}", status_code=204)
def delete_supplier(
    supplier_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "supplier.delete")
    owner = data_owner_id(current_user)
    s = _get_supplier_or_404(db, supplier_id, owner)
    active = db.query(func.count(PurchaseOrder.id)).filter(
        PurchaseOrder.supplier_id == s.id,
        PurchaseOrder.status.in_(["ordered", "received"]),
        PurchaseOrder.is_paid == False,
    ).scalar() or 0
    if active > 0:
        raise HTTPException(400, "Bu tedarikçiye ait aktif veya ödenmemiş siparişler var.")

    order_ids = [
        row[0] for row in db.query(PurchaseOrder.id).filter(PurchaseOrder.supplier_id == s.id).all()
    ]
    if order_ids:
        for oid in order_ids:
            record_deletion(db, "purchase_orders", oid)
        db.query(PurchaseOrderItem).filter(
            PurchaseOrderItem.order_id.in_(order_ids)
        ).delete(synchronize_session=False)
        db.query(PurchaseOrder).filter(
            PurchaseOrder.id.in_(order_ids)
        ).delete(synchronize_session=False)
    record_deletion(db, "suppliers", s.id)
    db.delete(s)
    db.commit()
    trigger_delta_push()


# ── Purchase Orders ───────────────────────────────────────────

@router.get("/purchases", response_model=List[PurchaseOrderOut])
def list_purchases(
    status_filter: Optional[str] = Query(None, alias="status"),
    supplier_id: Optional[int] = Query(None),
    q: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "supplier.view")
    owner = data_owner_id(current_user)
    query = db.query(PurchaseOrder).filter(PurchaseOrder.user_id == owner)
    if status_filter:
        query = query.filter(PurchaseOrder.status == status_filter)
    if supplier_id:
        query = query.filter(PurchaseOrder.supplier_id == supplier_id)
    if q:
        query = query.filter(PurchaseOrder.order_number.ilike(f"%{q}%"))
    orders = query.order_by(PurchaseOrder.created_at.desc()).all()
    return [_purchase_out(o, db) for o in orders]


@router.post("/purchases", response_model=PurchaseOrderOut, status_code=201)
def create_purchase(
    data: PurchaseOrderCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "supplier.add")
    owner = data_owner_id(current_user)
    _get_supplier_or_404(db, data.supplier_id, owner)

    subtotal, kdv_amount, total = _compute_purchase_totals(data.items)

    order = PurchaseOrder(
        user_id=owner,
        supplier_id=data.supplier_id,
        order_number=_next_purchase_number(db, owner),
        status="draft",
        notes=data.notes,
        expected_date=data.expected_date,
        subtotal=subtotal,
        kdv_amount=kdv_amount,
        total_amount=total,
        currency=data.currency,
    )
    db.add(order)
    db.flush()

    for item in data.items:
        db.add(PurchaseOrderItem(
            order_id=order.id,
            product_id=item.product_id,
            product_name=item.product_name,
            unit_price=item.unit_price,
            currency=item.currency,
            quantity=item.quantity,
            kdv_rate=item.kdv_rate,
            line_total=_item_line_total(item),
        ))

    db.commit()
    db.refresh(order)
    return _purchase_out(order, db)


@router.get("/purchases/{order_id}", response_model=PurchaseOrderOut)
def get_purchase(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "supplier.view")
    owner = data_owner_id(current_user)
    order = _get_purchase_or_404(db, order_id, owner)
    return _purchase_out(order, db)


@router.put("/purchases/{order_id}", response_model=PurchaseOrderOut)
def update_purchase(
    order_id: int,
    data: PurchaseOrderUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "supplier.edit")
    owner = data_owner_id(current_user)
    order = _get_purchase_or_404(db, order_id, owner)
    if order.status != "draft":
        raise HTTPException(400, "Sadece taslak satın alma siparişleri düzenlenebilir.")

    updates = data.model_dump(exclude_unset=True)
    items_data = updates.pop("items", None)

    if "supplier_id" in updates:
        _get_supplier_or_404(db, updates["supplier_id"], owner)

    for field, val in updates.items():
        setattr(order, field, val)

    if items_data is not None:
        db.query(PurchaseOrderItem).filter(PurchaseOrderItem.order_id == order.id).delete()
        for item in items_data:
            db.add(PurchaseOrderItem(
                order_id=order.id,
                product_id=item.get("product_id"),
                product_name=item["product_name"],
                unit_price=item["unit_price"],
                currency=item.get("currency", "TRY"),
                quantity=item["quantity"],
                kdv_rate=item.get("kdv_rate", 0),
                line_total=_item_line_total(item),
            ))

    all_items = db.query(PurchaseOrderItem).filter(PurchaseOrderItem.order_id == order.id).all()
    subtotal, kdv_amount, total = _compute_purchase_totals(all_items)
    order.subtotal = subtotal
    order.kdv_amount = kdv_amount
    order.total_amount = total

    db.commit()
    db.refresh(order)
    return _purchase_out(order, db)


@router.delete("/purchases/{order_id}", status_code=204)
def delete_purchase(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "supplier.delete")
    owner = data_owner_id(current_user)
    order = _get_purchase_or_404(db, order_id, owner)
    if order.status != "draft":
        raise HTTPException(400, "Sadece taslak siparişler silinebilir.")
    record_deletion(db, "purchase_orders", order.id)
    db.delete(order)
    db.commit()
    trigger_delta_push()


# ── Status transitions ────────────────────────────────────────

@router.post("/purchases/{order_id}/order", response_model=PurchaseOrderOut)
def send_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Taslak siparişi toptancıya gönder (draft → ordered)."""
    require_perm(current_user, "supplier.edit")
    owner = data_owner_id(current_user)
    order = _get_purchase_or_404(db, order_id, owner)
    if order.status != "draft":
        raise HTTPException(400, f"Bu sipariş zaten '{order.status}' durumunda.")
    items = db.query(PurchaseOrderItem).filter(PurchaseOrderItem.order_id == order.id).all()
    if not items:
        raise HTTPException(400, "Sipariş kalemi boş — gönderilemez.")
    order.status = "ordered"
    order.updated_at = datetime.now()
    db.commit()
    db.refresh(order)
    return _purchase_out(order, db)


@router.post("/purchases/{order_id}/receive", response_model=PurchaseOrderOut)
def receive_goods(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Malı kabul et: stokları artır ve toptancı borç (gider) transaction'ı oluştur."""
    require_perm(current_user, "supplier.edit")
    owner = data_owner_id(current_user)
    order = _get_purchase_or_404(db, order_id, owner)
    if order.status != "ordered":
        raise HTTPException(400, f"Mal kabul için sipariş 'ordered' olmalı (şu an: '{order.status}').")

    supplier = _get_supplier_or_404(db, order.supplier_id, owner)
    items = db.query(PurchaseOrderItem).filter(PurchaseOrderItem.order_id == order.id).all()

    # Stok artır
    for item in items:
        if item.product_id is None:
            continue
        product = db.query(Product).filter(
            Product.id == item.product_id,
            Product.user_id == owner,
        ).first()
        if product:
            product.quantity += item.quantity
            product.updated_at = datetime.now()
            db.add(product)

    # Gider transaction (toptancıya borç)
    txn = Transaction(
        user_id=owner,
        transaction_type="gider",
        customer_name=supplier.company_name,
        customer_phone=supplier.phone,
        customer_vkn=supplier.vkn,
        amount=order.total_amount,
        currency=order.currency,
        kdv_rate=0,
        description=f"Toptancı Alım #{order.order_number}",
        created_at=datetime.now(),
        updated_at=datetime.now(),
    )
    db.add(txn)
    db.flush()

    order.transaction_id = txn.id
    order.status = "received"
    order.updated_at = datetime.now()
    db.commit()
    db.refresh(order)
    return _purchase_out(order, db)


@router.post("/purchases/{order_id}/cancel", response_model=PurchaseOrderOut)
def cancel_purchase(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "supplier.edit")
    owner = data_owner_id(current_user)
    order = _get_purchase_or_404(db, order_id, owner)
    if order.status in ("received", "cancelled"):
        raise HTTPException(400, f"Bu sipariş iptal edilemez (durum: '{order.status}').")

    order.status = "cancelled"
    order.updated_at = datetime.now()
    db.commit()
    db.refresh(order)
    return _purchase_out(order, db)


@router.post("/purchases/{order_id}/mark-paid", response_model=PurchaseOrderOut)
def mark_purchase_paid(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Toptancı faturasını ödendi olarak işaretle."""
    require_perm(current_user, "supplier.edit")
    owner = data_owner_id(current_user)
    order = _get_purchase_or_404(db, order_id, owner)
    if order.status != "received":
        raise HTTPException(400, "Ödeme yalnızca teslim alınan siparişler için işaretlenebilir.")
    if order.is_paid:
        raise HTTPException(400, "Bu sipariş zaten ödendi olarak işaretlenmiş.")
    order.is_paid = True
    order.paid_at = datetime.now(timezone.utc)
    order.updated_at = datetime.now()
    db.commit()
    db.refresh(order)
    return _purchase_out(order, db)
