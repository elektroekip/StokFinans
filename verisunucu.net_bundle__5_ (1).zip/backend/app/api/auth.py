# ============================================================
# Auth Endpoints - Kimlik Doğrulama API
# ============================================================
# Login, Register, Token Refresh endpointleri
# ============================================================

from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models import User
from app.models.security import SecurityLog
from app.schemas.user import (
    UserRegisterRequest,
    UserLoginRequest,
    UserResponse,
    UserUpdateRequest,
    EmailChangeRequest,
    UnverifiedEmailUpdateRequest,
    LoginResponse,
    RegisterResponse,
    TokenRefreshRequest,
    TokenRefreshResponse
)
from app.utils.security import (
    hash_password,
    verify_password,
    create_access_token,
    create_refresh_token,
    generate_referral_code,
    get_client_ip,
    verify_token,
    ACCESS_TOKEN_EXPIRE_MINUTES
)
from app.utils.auth import (
    get_current_user,
    get_current_user_unverified,
    check_email_exists,
    validate_referral_code,
    check_duplicate_registration
)
from app.services.email import (
    get_smtp_settings,
    generate_verification_token,
    get_token_expiry,
    send_verification_email,
    send_email_change_verification_email,
    send_email_change_alert_email,
    send_password_reset_email,
)
from datetime import timedelta, datetime, timezone

router = APIRouter(prefix="/auth", tags=["Authentication"])


def _user_resp(user: User, db: Session) -> "UserResponse":
    """
    UserResponse'a serialize ederken çalışan kullanıcılar için
    sub_days ve sub_expires_at alanlarını PATRON'dan hesapla.
    Böylece çalışan paneli "abonelik bitti" gibi davranmaz.
    """
    from app.utils.tenant import is_employee
    from app.services.subscription import compute_days_remaining
    resp = UserResponse.model_validate(user)
    if is_employee(user) and user.parent_user_id:
        parent = db.query(User).filter(User.id == int(user.parent_user_id)).first()
        if parent:
            resp.sub_days = compute_days_remaining(parent.sub_expires_at)
    # token_expires_at, hem pending_email değişikliği hem de mevcut adres doğrulaması
    # için kullanılıyor. Sadece bekleyen e-posta varsa cevaba ekle ki istemci
    # yanlış bağlama düşmesin.
    if getattr(user, "pending_email", None):
        resp.pending_email_expires_at = getattr(user, "token_expires_at", None)
    else:
        resp.pending_email_expires_at = None
    return resp

# ============================================================
# REGISTER ENDPOINT - KayÄ±t
# ============================================================

@router.post(
    "/register",
    response_model=RegisterResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Yeni Hesap OluÅtur",
    description="Bayı veya çalışan hesabı oluştur. Referral kodu varsa bonus gün ekle."
)
async def register(
    request: Request,
    user_data: UserRegisterRequest,
    db: Session = Depends(get_db)
):
    """
    Yeni bir kullanıcı (Bayı veya Çalışan) hesabı oluştur

    ## İşlem Adımları:
    1. E-posta ve IP'nin çoklu kayıt yapılıp yapılmadığını kontrol et
    2. Referral kodu varsa doğrula ve bonus hesapla
    3. Şifreyi Bcrypt ile hashle
    4. Yeni User nesnesini oluştur
    5. Veritabanına kaydet
    6. Access ve Refresh token'ları oluştur
    7. Kullanıcıyı otomatik giriş yap

    ## Anti-Fraud:
    - Aynı email → Red (Email zaten kayıtlı)
    - Aynı IP 30 gün içinde 5+ kayıt → Red (Şüpheli aktivite)
    - Referral code self-reference → Red (Kendi kendine referral olamaz)

    ## Referral Sistemi:
    - Yeni bayı referral kodu ile kaydolursa: +24 gün (default 14)
    - Referrer (kimim davet eden) → +10 gün bonus

    Args:
        request (Request): HTTP request (IP çıkarmak için)
        user_data (UserRegisterRequest): Kullanıcı bilgileri
        db (Session): Veritabanı bağlantısı

    Returns:
        RegisterResponse: Oluşturulan kullanıcı + token'lar

    Raises:
        HTTPException: 400 (Email duplicate, IP fraud, etc.)
                      404 (Invalid referral code)
    """
    # 1. İstemcinin IP adresini al
    client_ip = get_client_ip(request)

    # 2. Çoklu kayıt (Email duplicate veya IP fraud) kontrolü
    is_fraud, error_msg = check_duplicate_registration(
        email=user_data.email,
        ip_address=client_ip,
        db=db
    )

    if is_fraud:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=error_msg
        )

    # 3. Abonelik süresi hesapla (varsayılan: 14 gün)
    sub_days = 14
    referrer = None

    # 4. Referral kodu kontrol et (sadece bayılar için)
    if user_data.role == "bayi_sahibi" and user_data.ref_code:
        referrer = validate_referral_code(user_data.ref_code, db)

        if not referrer:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Geçersiz referral kodu"
            )

        # Self-reference check (kendi kendine referral olamaz)
        if referrer.ip_address == client_ip:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Aynı IP'den kendi kendine referral olamazsınız"
            )

        # Referral bonusu
        sub_days = 24  # +10 gün bonus
        referrer.sub_days += 10  # Referrer'a bonus
        db.add(referrer)

    # 4b. Çalışan rolünde kayıt: davet edilmiş olmak ZORUNLU
    invite = None
    parent_user_id = None
    permissions_to_copy = None
    if user_data.role == "calisan":
        from app.models.employee_invite import EmployeeInvite
        invite = (
            db.query(EmployeeInvite)
            .filter(
                EmployeeInvite.email == user_data.email,
                EmployeeInvite.is_consumed == False,  # noqa: E712
            )
            .first()
        )
        if not invite:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=(
                    "Bu e-posta için herhangi bir firma sizi personel olarak eklemedi. "
                    "Lütfen önce firma sahibinizden personel daveti oluşturmasını isteyin."
                ),
            )
        # Davet'teki ad/permissions'ı baz al
        parent_user_id = invite.parent_user_id
        permissions_to_copy = list(invite.permissions or [])
        # Çalışan ek bonus alamaz
        sub_days = 0  # çalışanın kendi süresi yok; abonelik patrondan gelir

    # 5. Şifreyi hashle
    hashed_password = hash_password(user_data.password)

    # 6. Referral kodu oluştur (sadece bayılar)
    ref_code = None
    if user_data.role == "bayi_sahibi":
        ref_code = generate_referral_code(user_id=1)  # user_id sonra atanacak

    # 7. Yeni User nesnesini oluştur (whitelist'teki e-posta otomatik süper yönetici)
    from main import is_email_super_admin
    from app.services.subscription import now_utc
    from datetime import timedelta as _td
    is_super = is_email_super_admin(user_data.email)
    # Çalışanın sub_expires_at'i NULL — guard middleware patron expires_at'ını kontrol eder
    sub_expires = None if user_data.role == "calisan" else now_utc() + _td(days=sub_days)

    # SMTP aktifse e-posta doğrulama gerekir
    smtp_cfg = get_smtp_settings(db)
    needs_verification = smtp_cfg is not None and not is_super
    verification_token = generate_verification_token() if needs_verification else None
    token_exp = get_token_expiry() if needs_verification else None

    new_user = User(
        email=user_data.email,
        password_hash=hashed_password,
        full_name=invite.full_name if invite else user_data.full_name,
        company_name=user_data.company_name,
        role=user_data.role,
        ref_code=ref_code,
        sub_days=sub_days,
        sub_expires_at=sub_expires,
        package_slug="starter",
        ip_address=client_ip,
        is_active=True,
        is_super_admin=is_super,
        referred_by_user_id=referrer.id if referrer else None,
        parent_user_id=parent_user_id,
        permissions=permissions_to_copy,
        is_email_verified=not needs_verification,
        email_verification_token=verification_token,
        token_expires_at=token_exp,
    )

    # Referrer'ın da sub_expires_at'ını güncelle (10 gün ekle, mevcut süre korunur)
    if referrer:
        from app.services.subscription import extend_subscription
        extend_subscription(referrer, 10)

    # 8. Veritabanına kaydet
    db.add(new_user)
    db.flush()  # ID atanır

    # 8a. Davet'i tüket (consumed)
    if invite:
        from app.services.subscription import now_utc as _now_utc2
        invite.is_consumed = True
        invite.consumed_user_id = new_user.id
        invite.consumed_at = _now_utc2()
        db.add(invite)

    # 8b. Abonelik olaylarını logla (subscription_events) — sadece bayılar için
    from app.models.subscription_event import SubscriptionEvent
    base_initial = 14
    if user_data.role != "calisan":
        db.add(SubscriptionEvent(
            user_id=new_user.id,
            event_type="initial",
            days_delta=base_initial,
            days_before=0,
            days_after=base_initial,
            actor_user_id=None,
            related_user_id=None,
            note="Kayıt sırasında verilen başlangıç süresi",
        ))
    if referrer:
        # Yeni kullanıcı referans bonusu aldı
        db.add(SubscriptionEvent(
            user_id=new_user.id,
            event_type="referral_bonus_received",
            days_delta=10,
            days_before=base_initial,
            days_after=sub_days,
            actor_user_id=None,
            related_user_id=referrer.id,
            note=f"{referrer.ref_code or '—'} kodu kullanıldı",
        ))
        # Referrer (kod sahibi) bonus kazandı
        db.add(SubscriptionEvent(
            user_id=referrer.id,
            event_type="referral_bonus_given",
            days_delta=10,
            days_before=int((referrer.sub_days or 0) - 10),
            days_after=int(referrer.sub_days or 0),
            actor_user_id=None,
            related_user_id=new_user.id,
            note=f"{new_user.full_name} ({new_user.email}) bu kodla kayıt oldu",
        ))

    # BTB Müşteri bağlama: kayıt e-postası btb_customers.email ile eşleşiyorsa
    # kullanıcıya btb_musteri rolü ver ve hesabı bağla
    try:
        from app.models.btb import BtbCustomer as _BtbCust
        matched_customers = (
            db.query(_BtbCust)
            .filter(
                _BtbCust.email == user_data.email,
                _BtbCust.linked_user_id == None,  # noqa: E711
            )
            .all()
        )
        for matched_customer in matched_customers:
            if new_user.role not in ("bayi_sahibi", "calisan"):
                new_user.role = "btb_musteri"
                new_user.sub_expires_at = None
                new_user.sub_days = 0
            matched_customer.linked_user_id = new_user.id
            db.add(matched_customer)
    except Exception as _btb_link_exc:
        print(f"[REGISTER] BTB link hatası (kayıt yine de başarılı): {_btb_link_exc}")

    db.commit()
    db.refresh(new_user)

    # 9. Doğrulama maili gönder (arka planda; hata olsa da kayıt başarılı sayılır)
    if needs_verification and verification_token:
        import os as _os, re as _re
        # Güvenilir kaynak: FRONTEND_BASE_URL env var → Origin header → Referer
        host_clean = (
            _os.environ.get("FRONTEND_BASE_URL", "").rstrip("/")
            or _re.sub(r"(https?://[^/]+).*", r"\1", request.headers.get("origin") or request.headers.get("referer") or str(request.base_url).replace("8000", "5000"))
        )
        try:
            send_verification_email(db, new_user.email, verification_token, new_user.full_name, host_clean)
        except Exception as _mail_exc:
            print(f"[REGISTER] Mail gönderim hatası (kayıt yine de başarılı): {_mail_exc}")

    # 10. Token'ları oluştur
    access_token = create_access_token(
        data={"sub": new_user.email, "user_id": new_user.id}
    )
    refresh_token = create_refresh_token(
        data={"sub": new_user.email, "user_id": new_user.id}
    )

    # 10b. Oturum kaydı oluştur
    _persist_session(db, new_user.id, access_token, refresh_token, request)

    # 11. Response oluştur
    return RegisterResponse(
        message="Hesabınız başarılı şekilde oluşturuldu",
        user=_user_resp(new_user, db),
        access_token=access_token,
        refresh_token=refresh_token,
        email_verification_required=needs_verification,
    )

# ============================================================
# SESSION HELPER — login/register/verify-email akışları paylaşır
# ============================================================

def _persist_session(db, user_id: int, access_token: str, refresh_token_str: str, request) -> None:
    """Refresh token'a karşılık gelen UserSession kaydını oluşturur."""
    try:
        from app.models.user_session import UserSession
        at_payload = verify_token(access_token)
        rt_payload = verify_token(refresh_token_str)
        if not at_payload or not rt_payload:
            return
        exp_ts = rt_payload.get("exp")
        if not exp_ts:
            return
        db.add(UserSession(
            user_id=user_id,
            refresh_jti=rt_payload["jti"],
            family_id=rt_payload["family_id"],
            access_jti=at_payload["jti"],
            ip_address=get_client_ip(request),
            user_agent=(request.headers.get("user-agent", "") or "")[:512],
            expires_at=datetime.utcfromtimestamp(exp_ts),
        ))
        db.commit()
    except Exception as _e:
        # Session oluşturma hatası login'i engellemez
        print(f"[SESSION] Oturum kaydı oluşturulamadı: {_e}")


# ============================================================
# LOGIN ENDPOINT - GiriÅ
# ============================================================

@router.post(
    "/login",
    response_model=LoginResponse,
    status_code=status.HTTP_200_OK,
    summary="Sisteme GiriÅ Yap",
    description="Email ve şifre ile giriş yapıp token al"
)
async def login(
    request: Request,
    user_data: UserLoginRequest,
    db: Session = Depends(get_db)
):
    """
    Kullanıcı email ve şifre ile sisteme giriş yap

    ## İşlem Adımları:
    1. Veritabanında kullanıcıyı email'e göre ara
    2. Şifreyi doğrula (Bcrypt)
    3. Hesap aktif mi kontrol et
    4. Abonelik süresi geçmiş mi kontrol et
    5. Access ve Refresh token'larını oluştur
    6. Token'ları cevap olarak döndür

    Args:
        user_data (UserLoginRequest): Email ve şifre
        db (Session): Veritabanı bağlantısı

    Returns:
        LoginResponse: Kullanıcı bilgileri + token'lar

    Raises:
        HTTPException: 401 (Geçersiz email/şifre)
                      403 (Hesap pasif veya abonelik dolmuş)
    """
    # 1. Kullanıcıyı bul
    ip = get_client_ip(request)
    user = db.query(User).filter(User.email == user_data.email).first()

    if not user:
        try:
            db.add(SecurityLog(
                ip_address=ip,
                event_type="failed_login",
                email_attempted=user_data.email,
                path="/api/v1/auth/login",
                method="POST",
                user_agent=request.headers.get("user-agent", "")[:500],
                details="Kullanıcı bulunamadı",
            ))
            db.commit()
            from app.services.alert_service import check_and_alert_brute_force
            check_and_alert_brute_force(db, ip, "failed_login", threshold=5, window_minutes=5)
        except Exception:
            pass
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Geçersiz e-posta veya şifre",
            headers={"WWW-Authenticate": "Bearer"}
        )

    # 2. Şifreyi doğrula
    is_valid = verify_password(user_data.password, user.password_hash)

    if not is_valid:
        try:
            db.add(SecurityLog(
                ip_address=ip,
                event_type="failed_login",
                email_attempted=user_data.email,
                user_id=user.id,
                user_email=user.email,
                user_name=getattr(user, "full_name", None) or getattr(user, "name", None) or "",
                user_role=user.role,
                path="/api/v1/auth/login",
                method="POST",
                user_agent=request.headers.get("user-agent", "")[:500],
                details="Yanlış şifre",
            ))
            db.commit()
            from app.services.alert_service import check_and_alert_brute_force
            check_and_alert_brute_force(db, ip, "failed_login", threshold=5, window_minutes=5)
        except Exception:
            pass
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Geçersiz e-posta veya şifre",
            headers={"WWW-Authenticate": "Bearer"}
        )

    # 3. Hesap aktif mi?
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Kullanıcı hesabı devre dışı bırakılmış"
        )

    # 3b. E-posta doğrulandı mı? (SMTP aktif ve süper admin değilse zorunlu)
    if not getattr(user, 'is_email_verified', True) and not user.is_super_admin:
        smtp_cfg = get_smtp_settings(db)
        if smtp_cfg:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "code": "email_not_verified",
                    "message": "E-posta adresiniz henüz doğrulanmamış. Lütfen e-posta kutunuzu kontrol edin.",
                    "email": user.email,
                }
            )

    # 4. Abonelik süresi geçmiş mi? (süper yöneticiler bu kontrolden muaftır)
    # Not: Süresi dolan kullanıcı login olabilir; frontend onu /subscription sayfasına yönlendirir
    # ve sadece /api/v1/subscription/* endpoint'lerini kullanabilir.
    pass

    # 5. Token'ları oluştur
    access_token = create_access_token(
        data={"sub": user.email, "user_id": user.id}
    )
    refresh_token = create_refresh_token(
        data={"sub": user.email, "user_id": user.id}
    )

    # 5b. Oturum kaydı oluştur (refresh token rotation için)
    _persist_session(db, user.id, access_token, refresh_token, request)

    # BTB müşteri için login aktivite logu
    if user.role == "btb_musteri":
        try:
            from app.models.btb import BtbCustomer as _BtbCust
            from app.models.btb_activity import BtbActivityLog as _BtbALog
            btb_cust = db.query(_BtbCust).filter(_BtbCust.linked_user_id == user.id).first()
            if btb_cust:
                db.add(_BtbALog(btb_customer_id=btb_cust.id, user_id=user.id, action="login"))
                db.commit()
        except Exception:
            pass

    # 6. Response döndür
    return LoginResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",
        user=_user_resp(user, db),
        expires_in=ACCESS_TOKEN_EXPIRE_MINUTES * 60  # Saniye cinsinden
    )

# ============================================================
# TOKEN REFRESH ENDPOINT - Token YeniÄle
# ============================================================

@router.post(
    "/refresh",
    response_model=TokenRefreshResponse,
    status_code=status.HTTP_200_OK,
    summary="Token Yenile",
    description="Refresh token kullanarak yeni access + refresh token çifti al (rotation)"
)
async def refresh_token(
    request: Request,
    token_data: TokenRefreshRequest,
    db: Session = Depends(get_db)
):
    """
    Refresh token ile token çiftini yenile (rotation + reuse detection).

    Normal akış: refresh_jti → oturum bulunur → yeni token çifti + oturum güncellenir.
    Çalıntı token: eski jti tekrar kullanılırsa aynı family_id altındaki tüm
    aktif oturumlar zincirleme iptal edilir ve güvenlik uyarısı tetiklenir.
    """
    from app.models.user_session import UserSession
    from app.models.revoked_token import RevokedToken

    # 1. JWT imzasını ve süresini doğrula
    payload = verify_token(token_data.refresh_token)
    if not payload:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Geçersiz veya süresi dolmuş refresh token")

    refresh_jti = payload.get("jti")
    family_id = payload.get("family_id")
    user_id = payload.get("user_id")

    if not refresh_jti or not family_id or not user_id:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Token yapısı geçersiz")

    # 2. Oturumu refresh_jti ile ara
    session = db.query(UserSession).filter(UserSession.refresh_jti == refresh_jti).first()

    if not session:
        # Bu JTI daha önce kullanılmış (rotated) → token tekrar kullanımı tespit edildi
        ip = get_client_ip(request)
        family_sessions = (
            db.query(UserSession)
            .filter(UserSession.family_id == family_id, UserSession.is_revoked == False)
            .all()
        )
        if family_sessions:
            now = datetime.utcnow()
            for s in family_sessions:
                s.is_revoked = True
                s.revoked_at = now
                s.revoked_reason = "reuse_detected"
                if s.access_jti:
                    if not db.query(RevokedToken).filter(RevokedToken.jti == s.access_jti).first():
                        db.add(RevokedToken(jti=s.access_jti, expires_at=s.expires_at))
            db.commit()
            try:
                from app.services.alert_service import trigger_alert
                trigger_alert(
                    "REFRESH_TOKEN_REUSE",
                    ip,
                    f"Family {family_id[:8]}… zincirleme iptal — {len(family_sessions)} oturum",
                    user_id=user_id,
                )
            except Exception:
                pass
        raise HTTPException(
            status.HTTP_401_UNAUTHORIZED,
            "Güvenlik ihlali tespit edildi: lütfen tekrar giriş yapın",
        )

    # 3. Oturum iptal edilmiş mi?
    if session.is_revoked:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Bu oturum iptal edilmiş")

    # 4. Kullanıcı ve hesap kontrolleri
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Kullanıcı bulunamadı")
    if not user.is_active:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Kullanıcı hesabı devre dışı")

    if not getattr(user, 'is_email_verified', True) and not user.is_super_admin:
        smtp_cfg = get_smtp_settings(db)
        if smtp_cfg:
            raise HTTPException(status.HTTP_403_FORBIDDEN, {
                "code": "email_not_verified",
                "message": "E-posta adresiniz henüz doğrulanmamış.",
                "email": user.email,
            })

    from app.utils.tenant import is_employee
    from app.services.subscription import compute_days_remaining
    eff_user = user
    if is_employee(user) and user.parent_user_id:
        parent = db.query(User).filter(User.id == int(user.parent_user_id)).first()
        if parent:
            eff_user = None if parent.is_super_admin else parent
    if eff_user is not None:
        days_left = (
            compute_days_remaining(eff_user.sub_expires_at)
            if eff_user.sub_expires_at
            else (eff_user.sub_days or 0)
        )
        if days_left <= 0:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Aboneliğinizin süresi dolmuş")

    # 5. Rotation: aynı family_id ile yeni token çifti üret
    new_access_token = create_access_token(data={"sub": user.email, "user_id": user.id})
    new_refresh_token = create_refresh_token(
        data={"sub": user.email, "user_id": user.id},
        family_id=family_id,  # Aynı oturum ailesi
    )

    new_at_payload = verify_token(new_access_token)
    new_rt_payload = verify_token(new_refresh_token)

    # 6. Oturum kaydını güncelle (eski JTI'lar artık geçersiz)
    now = datetime.utcnow()
    session.refresh_jti = new_rt_payload["jti"]
    session.access_jti = new_at_payload["jti"]
    session.last_used_at = now
    session.ip_address = get_client_ip(request)
    db.commit()

    return TokenRefreshResponse(
        access_token=new_access_token,
        refresh_token=new_refresh_token,
        token_type="bearer",
        expires_in=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )

# ============================================================
# LOGOUT ENDPOINT - ÇÄ±kÄ±Å (Opsiyonel)
# ============================================================

@router.post(
    "/logout",
    status_code=status.HTTP_200_OK,
    summary="Sistemden Çıkış Yap",
    description="Token sunucu tarafında iptal listesine alınır"
)
async def logout(
    request: Request,
    current_user: User = Depends(get_current_user_unverified),
    db: Session = Depends(get_db),
):
    """Access token'ı kara listeye alır, bağlı oturumu iptal eder."""
    from app.models.revoked_token import RevokedToken
    from app.models.user_session import UserSession
    from datetime import datetime as _dt

    access_jti = None
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        raw_token = auth_header[7:]
        payload = verify_token(raw_token)
        if payload:
            access_jti = payload.get("jti")
            exp_ts = payload.get("exp")
            if access_jti and exp_ts:
                if not db.query(RevokedToken).filter(RevokedToken.jti == access_jti).first():
                    db.add(RevokedToken(jti=access_jti, expires_at=_dt.utcfromtimestamp(exp_ts)))

    # Oturumu access_jti üzerinden bul ve iptal et
    if access_jti:
        session = (
            db.query(UserSession)
            .filter(UserSession.access_jti == access_jti, UserSession.is_revoked == False)
            .first()
        )
        if session:
            session.is_revoked = True
            session.revoked_at = _dt.utcnow()
            session.revoked_reason = "logout"

    db.commit()
    return {"message": "Başarı ile çıkış yaptınız"}

# ============================================================
# REGISTER NOTICE - Public (kayıt sayfası bilgilendirmesi)
# ============================================================

@router.get(
    "/register-notice",
    status_code=status.HTTP_200_OK,
    summary="Kayıt sayfası bilgilendirme kutusunu getir (public)",
)
async def get_register_notice(db: Session = Depends(get_db)):
    from app.models.register_notice import RegisterNotice
    notice = db.query(RegisterNotice).filter(RegisterNotice.id == 1).first()
    if not notice:
        return {"is_enabled": False, "title": "", "message": "", "color": "indigo"}
    return {
        "is_enabled": bool(notice.is_enabled),
        "title": notice.title or "",
        "message": notice.message or "",
        "color": notice.color or "indigo",
    }


@router.get(
    "/terms",
    status_code=status.HTTP_200_OK,
    summary="Kayıt sayfası site şartlarını getir (public)",
)
async def get_terms(db: Session = Depends(get_db)):
    from app.models.terms_setting import TermsSetting
    terms = db.query(TermsSetting).filter(TermsSetting.id == 1).first()
    if not terms:
        return {"is_enabled": False, "content": ""}
    return {
        "is_enabled": bool(terms.is_enabled),
        "content": terms.content or "",
    }


# ============================================================
# VERIFY EMAIL - E-posta doğrulama token'ı işle
# ============================================================

@router.post(
    "/verify-email",
    status_code=status.HTTP_200_OK,
    summary="E-posta doğrulama token'ını doğrula",
)
async def verify_email(token: str, request: Request, db: Session = Depends(get_db)):
    if not token:
        raise HTTPException(status_code=400, detail="Token gerekli")
    user = db.query(User).filter(User.email_verification_token == token).first()
    if not user:
        raise HTTPException(status_code=400, detail="Geçersiz veya kullanılmış doğrulama bağlantısı")
    now = datetime.now(timezone.utc)
    exp = user.token_expires_at
    if exp:
        if exp.tzinfo is None:
            from datetime import timezone as _tz
            exp = exp.replace(tzinfo=_tz.utc)
        if exp < now:
            raise HTTPException(status_code=400, detail="Doğrulama bağlantısının süresi dolmuş. Lütfen yeni bir bağlantı isteyin.")

    # E-posta değişikliği mi yoksa ilk kayıt doğrulaması mı?
    pending = getattr(user, "pending_email", None)
    if pending:
        # E-posta değişikliği: yeni adresi kontrol et ve uygula
        already = db.query(User).filter(User.email == pending, User.id != user.id).first()
        if already:
            user.pending_email = None
            user.email_verification_token = None
            user.token_expires_at = None
            db.commit()
            raise HTTPException(status_code=409, detail="Bu e-posta adresi başka bir hesap tarafından kullanılıyor.")
        user.email = pending
        user.pending_email = None
        user.is_email_verified = True
        user.email_verification_token = None
        user.token_expires_at = None
        db.commit()
        db.refresh(user)
        access_token = create_access_token(data={"sub": user.email, "user_id": user.id})
        refresh_token_val = create_refresh_token(data={"sub": user.email, "user_id": user.id})
        _persist_session(db, user.id, access_token, refresh_token_val, request)
        return {
            "message": "E-posta adresi başarıyla güncellendi",
            "already_verified": False,
            "email_changed": True,
            "access_token": access_token,
            "refresh_token": refresh_token_val,
            "user": _user_resp(user, db).model_dump(),
        }

    # Normal kayıt doğrulaması
    if user.is_email_verified:
        return {"message": "E-posta zaten doğrulanmış", "already_verified": True}
    user.is_email_verified = True
    user.email_verification_token = None
    user.token_expires_at = None
    db.commit()
    db.refresh(user)
    access_token = create_access_token(data={"sub": user.email, "user_id": user.id})
    refresh_token_val = create_refresh_token(data={"sub": user.email, "user_id": user.id})
    _persist_session(db, user.id, access_token, refresh_token_val, request)
    return {
        "message": "E-posta başarıyla doğrulandı",
        "already_verified": False,
        "email_changed": False,
        "access_token": access_token,
        "refresh_token": refresh_token_val,
        "user": _user_resp(user, db).model_dump(),
    }


# ============================================================
# RESEND VERIFICATION (PUBLIC) - Token gerektirmeden e-posta ile gönder
# ============================================================

@router.post(
    "/resend-verification-public",
    status_code=status.HTTP_200_OK,
    summary="Doğrulama e-postasını yeniden gönder (public, e-posta ile)",
)
async def resend_verification_public(
    request: Request,
    payload: dict,
    db: Session = Depends(get_db),
):
    email = (payload.get("email") or "").strip().lower()
    if not email:
        raise HTTPException(status_code=400, detail="E-posta adresi gerekli")
    user = db.query(User).filter(User.email == email).first()
    if not user or user.is_email_verified:
        return {"message": "Doğrulama e-postası gönderildi"}
    smtp_cfg = get_smtp_settings(db)
    if not smtp_cfg:
        raise HTTPException(status_code=503, detail="E-posta servisi henüz yapılandırılmamış")
    token = generate_verification_token()
    user.email_verification_token = token
    user.token_expires_at = get_token_expiry()
    db.commit()
    import os as _os3, re as _re3
    host_clean = (
        _os3.environ.get("FRONTEND_BASE_URL", "").rstrip("/")
        or _re3.sub(r"(https?://[^/]+).*", r"\1", request.headers.get("origin") or str(request.base_url).rstrip("/"))
    )
    try:
        sent = send_verification_email(db, user.email, token, user.full_name, host_clean)
    except Exception:
        sent = False
    if not sent:
        raise HTTPException(status_code=500, detail="E-posta gönderilemedi. Lütfen daha sonra tekrar deneyin.")
    return {"message": "Doğrulama e-postası gönderildi"}


# ============================================================
# UPDATE UNVERIFIED EMAIL (PUBLIC) - Doğrulama bekleyen hesabın
# e-posta adresini düzelt (kayıt sırasındaki yazım hatası için)
# ============================================================

@router.post(
    "/update-unverified-email",
    status_code=status.HTTP_200_OK,
    summary="Doğrulanmamış hesabın e-posta adresini düzelt (public)",
)
async def update_unverified_email(
    request: Request,
    payload: UnverifiedEmailUpdateRequest,
    db: Session = Depends(get_db),
):
    current_email = payload.current_email.strip().lower()
    new_email = payload.new_email.strip().lower()

    user = db.query(User).filter(User.email == current_email).first()
    # Kullanıcı yoksa veya şifre yanlışsa: hesap varlığını sızdırmamak için
    # her iki durumda da aynı genel hatayı döndür.
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Geçersiz e-posta veya şifre.",
        )

    # Hesap zaten doğrulanmışsa bu uç ile değiştirilmesine izin verme.
    if user.is_email_verified:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Bu hesap zaten doğrulanmış. Lütfen giriş yapıp profil ayarlarından değiştirin.",
        )

    # Çalışan hesapları e-posta değiştiremez (davete bağlı oldukları için).
    if getattr(user, "parent_user_id", None):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Çalışan hesapları e-posta değiştiremez. Lütfen patronunuzla iletişime geçin.",
        )

    if new_email == current_email:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Yeni e-posta mevcut adresinizle aynı.",
        )

    # Yeni adres başka bir hesapta var mı?
    existing = db.query(User).filter(User.email == new_email, User.id != user.id).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Bu e-posta adresi zaten kullanımda.",
        )

    smtp_cfg = get_smtp_settings(db)
    if not smtp_cfg:
        raise HTTPException(
            status_code=503,
            detail="E-posta servisi henüz yapılandırılmamış. Lütfen daha sonra tekrar deneyin.",
        )

    # Eski değerleri tut, gönderim başarısız olursa geri al.
    old_email = user.email
    old_token = user.email_verification_token
    old_expiry = user.token_expires_at

    token = generate_verification_token()
    user.email = new_email
    user.email_verification_token = token
    user.token_expires_at = get_token_expiry()
    db.commit()

    import os as _os_uue, re as _re_uue
    host_clean = (
        _os_uue.environ.get("FRONTEND_BASE_URL", "").rstrip("/")
        or _re_uue.sub(
            r"(https?://[^/]+).*",
            r"\1",
            request.headers.get("origin") or str(request.base_url).rstrip("/"),
        )
    )

    try:
        sent = send_verification_email(db, user.email, token, user.full_name, host_clean)
    except Exception:
        sent = False

    if not sent:
        # E-posta gönderilemediyse değişikliği geri al ki kullanıcı kilitlenmesin.
        user.email = old_email
        user.email_verification_token = old_token
        user.token_expires_at = old_expiry
        db.commit()
        raise HTTPException(
            status_code=500,
            detail="Doğrulama e-postası gönderilemedi. Lütfen daha sonra tekrar deneyin.",
        )

    return {
        "message": f"E-posta adresiniz güncellendi. Doğrulama bağlantısı {new_email} adresine gönderildi.",
        "new_email": new_email,
    }


# ============================================================
# RESEND VERIFICATION - Doğrulama mailini yeniden gönder
# ============================================================

@router.post(
    "/resend-verification",
    status_code=status.HTTP_200_OK,
    summary="Doğrulama e-postasını yeniden gönder",
)
async def resend_verification(
    request: Request,
    current_user: User = Depends(get_current_user_unverified),
    db: Session = Depends(get_db),
):
    if current_user.is_email_verified:
        raise HTTPException(status_code=400, detail="E-posta zaten doğrulanmış")
    smtp_cfg = get_smtp_settings(db)
    if not smtp_cfg:
        raise HTTPException(status_code=503, detail="E-posta servisi henüz yapılandırılmamış")
    token = generate_verification_token()
    current_user.email_verification_token = token
    current_user.token_expires_at = get_token_expiry()
    db.commit()
    import os as _os2, re as _re2
    host_clean = (
        _os2.environ.get("FRONTEND_BASE_URL", "").rstrip("/")
        or _re2.sub(r"(https?://[^/]+).*", r"\1", request.headers.get("origin") or str(request.base_url).rstrip("/"))
    )
    sent = send_verification_email(db, current_user.email, token, current_user.full_name, host_clean)
    if not sent:
        raise HTTPException(status_code=500, detail="E-posta gönderilemedi. Lütfen daha sonra tekrar deneyin.")
    return {"message": "Doğrulama e-postası gönderildi"}


# ============================================================
# PROFILE ENDPOINT - Profil Bilgileri
# ============================================================

@router.get(
    "/profile",
    response_model=UserResponse,
    status_code=status.HTTP_200_OK,
    summary="Profil Bilgilerimi Göster",
    description="Mevcut kullanıcının profil bilgilerini getir"
)
async def get_profile(
    current_user: User = Depends(get_current_user_unverified),
    db: Session = Depends(get_db),
):
    return _user_resp(current_user, db)


@router.put(
    "/profile",
    response_model=UserResponse,
    status_code=status.HTTP_200_OK,
    summary="Profil Güncelle",
    description="Kullanıcının ad ve işletme adını güncelle"
)
async def update_profile(
    data: UserUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if data.full_name is not None:
        current_user.full_name = data.full_name
    if data.company_name is not None:
        current_user.company_name = data.company_name
    if data.company_address is not None:
        # Boş string gelirse NULL kaydet
        current_user.company_address = data.company_address.strip() or None
    if data.company_phone is not None:
        current_user.company_phone = data.company_phone.strip() or None
    db.add(current_user)
    db.commit()
    db.refresh(current_user)
    return _user_resp(current_user, db)


# ============================================================
# CHANGE EMAIL - E-posta değiştirme isteği
# ============================================================

@router.post(
    "/change-email",
    status_code=status.HTTP_200_OK,
    summary="E-posta Değiştirme İsteği",
    description="Yeni e-posta adresine doğrulama e-postası gönderir; eski adres doğrulanana kadar aktif kalır",
)
async def change_email(
    request: Request,
    data: EmailChangeRequest,
    current_user: User = Depends(get_current_user_unverified),
    db: Session = Depends(get_db),
):
    import re as _re_ce, os as _os_ce

    new_email = data.new_email.strip().lower()

    # Çalışanlar e-posta değiştiremez
    if getattr(current_user, "parent_user_id", None):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Çalışan hesapları e-posta değiştiremez.",
        )

    # Mevcut şifreyi doğrula
    if not verify_password(data.password, current_user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Mevcut şifreniz yanlış.")

    # Yeni adres mevcut adresle aynı mı?
    if new_email == current_user.email.lower():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Yeni e-posta mevcut adresinizle aynı.")

    # Yeni adres başka bir hesapta var mı?
    existing = db.query(User).filter(User.email == new_email).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Bu e-posta adresi zaten kullanımda.")

    smtp_cfg = get_smtp_settings(db)
    if not smtp_cfg:
        raise HTTPException(status_code=503, detail="E-posta servisi henüz yapılandırılmamış. Yöneticinizle iletişime geçin.")

    # Doğrulama token'ı oluştur ve pending_email'i kaydet
    token = generate_verification_token()
    current_user.pending_email = new_email
    current_user.email_verification_token = token
    current_user.token_expires_at = get_token_expiry()
    db.commit()

    host_clean = (
        _os_ce.environ.get("FRONTEND_BASE_URL", "").rstrip("/")
        or _re_ce.sub(r"(https?://[^/]+).*", r"\1", request.headers.get("origin") or str(request.base_url).rstrip("/"))
    )

    sent = send_email_change_verification_email(db, new_email, token, current_user.full_name, host_clean)
    if not sent:
        # Token'ı geri al
        current_user.pending_email = None
        current_user.email_verification_token = None
        current_user.token_expires_at = None
        db.commit()
        raise HTTPException(status_code=500, detail="Doğrulama e-postası gönderilemedi. Lütfen daha sonra tekrar deneyin.")

    # Mevcut (eski) e-posta adresine güvenlik uyarı maili gönder.
    # Başarısız olursa değişiklik talebini bozmamak için sadece logla
    # (helper False döner, ayrıca beklenmedik hatalar exception olarak da gelebilir).
    try:
        alert_sent = send_email_change_alert_email(
            db, current_user.email, new_email, current_user.full_name, host_clean
        )
        if not alert_sent:
            print(
                f"[EMAIL] Eski adrese uyarı maili gönderilemedi (user_id={current_user.id}, "
                f"old_email={current_user.email})"
            )
    except Exception as exc:
        print(f"[EMAIL] Eski adrese uyarı maili gönderilemedi: {exc}")

    return {
        "message": f"Doğrulama e-postası {new_email} adresine gönderildi. Lütfen yeni adresinizi doğrulayın.",
        "pending_email": new_email,
        "pending_email_expires_at": (
            current_user.token_expires_at.isoformat()
            if current_user.token_expires_at
            else None
        ),
    }


# ============================================================
# CANCEL EMAIL CHANGE - Bekleyen e-posta değişikliğini iptal et
# ============================================================

@router.delete(
    "/change-email",
    status_code=status.HTTP_200_OK,
    summary="E-posta Değiştirme İsteğini İptal Et",
    description="Bekleyen e-posta değişikliği isteğini ve doğrulama token'ını temizler",
)
async def cancel_email_change(
    current_user: User = Depends(get_current_user_unverified),
    db: Session = Depends(get_db),
):
    # Çalışanlar e-posta değiştiremediği için iptal de edemez
    if getattr(current_user, "parent_user_id", None):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Çalışan hesapları e-posta değiştiremez.",
        )

    if not getattr(current_user, "pending_email", None):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="İptal edilecek bekleyen bir e-posta değişikliği yok.",
        )

    current_user.pending_email = None
    current_user.email_verification_token = None
    current_user.token_expires_at = None
    db.commit()

    return {"message": "E-posta değiştirme isteği iptal edildi."}


@router.post(
    "/change-password",
    status_code=status.HTTP_200_OK,
    summary="Şifre Değiştir",
)
async def change_password(
    body: dict,
    current_user: User = Depends(get_current_user_unverified),
    db: Session = Depends(get_db),
):
    current_pw = (body.get("current_password") or "").strip()
    new_pw = (body.get("new_password") or "").strip()

    if not current_pw:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Mevcut şifrenizi girin.")
    if len(new_pw) < 8:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Yeni şifre en az 8 karakter olmalı.")
    if not verify_password(current_pw, current_user.password_hash):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Mevcut şifre hatalı.")

    current_user.password_hash = hash_password(new_pw)
    db.commit()
    return {"message": "Şifreniz başarıyla güncellendi."}


# ============================================================
# EMPLOYEES (PERSONEL) MANAGEMENT - Patron tarafından
# ============================================================
# Patron (bayi_sahibi veya is_super_admin) kendi çalışanlarını
# davet eder, listeler, izinlerini düzenler veya siler.
# ============================================================

from pydantic import BaseModel as _BaseModel
from typing import List as _List, Literal as _Literal
from app.models.employee_invite import EmployeeInvite

# Geçerli sayfa izinleri — granüler izin sisteminden gelir
from app.utils.permissions import ALLOWED_PERMISSIONS, expand_legacy


def _ensure_owner(current_user: User):
    """Çalışan olmayan (yani patron) ve aktif kullanıcı olmalı."""
    if getattr(current_user, "parent_user_id", None):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Sadece firma sahibi personel yönetimi yapabilir.",
        )
    if current_user.role not in ("bayi_sahibi",) and not current_user.is_super_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Personel yönetimi için yetkiniz yok.",
        )


def _normalize_perms(perms):
    """
    Permissions girdisini normalize eder:
    - Liste değilse 400
    - Eski (legacy) koarse-grained izinleri ("products","finance",...) granüler
      izinlere genişletir (geriye uyumluluk).
    - Tanınmayan izinleri atar.
    - Tekrarları kaldırır, sırayı korur.
    """
    if perms is None:
        return []
    if not isinstance(perms, list):
        raise HTTPException(status_code=400, detail="permissions liste olmalı")
    return expand_legacy(perms)


class EmployeeInviteRequest(_BaseModel):
    email: str
    full_name: str
    permissions: _List[str] = []


class EmployeeUpdatePermsRequest(_BaseModel):
    permissions: _List[str]


class EmployeeRowResponse(_BaseModel):
    kind: _Literal["user", "invite"]
    id: int
    email: str
    full_name: str
    permissions: _List[str]
    status: _Literal["active", "pending", "inactive"]
    created_at: datetime
    is_active: bool

    class Config:
        from_attributes = True


@router.post(
    "/employees",
    status_code=status.HTTP_201_CREATED,
    summary="Yeni Personel Daveti Oluştur",
)
async def create_employee_invite(
    body: EmployeeInviteRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _ensure_owner(current_user)

    email = (body.email or "").strip().lower()
    full_name = (body.full_name or "").strip()
    if "@" not in email or len(email) < 5:
        raise HTTPException(status_code=400, detail="Geçerli bir e-posta giriniz")
    if len(full_name) < 2:
        raise HTTPException(status_code=400, detail="Personel adı en az 2 karakter olmalı")
    perms = _normalize_perms(body.permissions)

    # Aynı email ile hâlihazırda kayıtlı bir kullanıcı var mı?
    existing_user = db.query(User).filter(User.email == email).first()
    if existing_user:
        raise HTTPException(
            status_code=400,
            detail="Bu e-posta sistemde zaten kayıtlı; başka bir e-posta seçin.",
        )

    # Var olan davet?
    existing_inv = db.query(EmployeeInvite).filter(EmployeeInvite.email == email).first()
    if existing_inv and not existing_inv.is_consumed:
        # Aynı patrondan ise update; başka patrondan ise reddet
        if existing_inv.parent_user_id != current_user.id:
            raise HTTPException(
                status_code=400,
                detail="Bu e-posta için başka bir firma davet oluşturmuş.",
            )
        existing_inv.full_name = full_name
        existing_inv.permissions = perms
        db.add(existing_inv)
        db.commit()
        db.refresh(existing_inv)
        return {
            "id": existing_inv.id,
            "email": existing_inv.email,
            "full_name": existing_inv.full_name,
            "permissions": existing_inv.permissions or [],
            "updated": True,
        }
    if existing_inv and existing_inv.is_consumed:
        # Tüketilmiş davet → User var olmalı; üstte yakalanırdı
        raise HTTPException(
            status_code=400,
            detail="Bu e-posta sistemde zaten kayıtlı; başka bir e-posta seçin.",
        )

    inv = EmployeeInvite(
        email=email,
        full_name=full_name,
        parent_user_id=current_user.id,
        permissions=perms,
        is_consumed=False,
    )
    db.add(inv)
    db.commit()
    db.refresh(inv)
    return {
        "id": inv.id,
        "email": inv.email,
        "full_name": inv.full_name,
        "permissions": inv.permissions or [],
        "created": True,
    }


@router.get(
    "/employees",
    summary="Personel Listesi (Aktif + Bekleyen)",
)
async def list_employees(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _ensure_owner(current_user)

    # Aktif kayıtlı personel
    users = (
        db.query(User)
        .filter(User.parent_user_id == current_user.id)
        .order_by(User.created_at.desc())
        .all()
    )
    # Bekleyen davetler
    invites = (
        db.query(EmployeeInvite)
        .filter(
            EmployeeInvite.parent_user_id == current_user.id,
            EmployeeInvite.is_consumed == False,  # noqa: E712
        )
        .order_by(EmployeeInvite.created_at.desc())
        .all()
    )

    rows = []
    for u in users:
        rows.append({
            "kind": "user",
            "id": u.id,
            "email": u.email,
            "full_name": u.full_name,
            "permissions": u.permissions or [],
            "status": "active" if u.is_active else "inactive",
            "created_at": u.created_at.isoformat() if u.created_at else None,
            "is_active": bool(u.is_active),
        })
    for i in invites:
        rows.append({
            "kind": "invite",
            "id": i.id,
            "email": i.email,
            "full_name": i.full_name,
            "permissions": i.permissions or [],
            "status": "pending",
            "created_at": i.created_at.isoformat() if i.created_at else None,
            "is_active": True,
        })
    return {
        "items": rows,
        "allowed_permissions": sorted(ALLOWED_PERMISSIONS),
    }


@router.patch(
    "/employees/{user_id}/permissions",
    summary="Aktif Personelin Sayfa İzinlerini Güncelle",
)
async def update_employee_permissions(
    user_id: int,
    body: EmployeeUpdatePermsRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _ensure_owner(current_user)

    target = db.query(User).filter(
        User.id == user_id, User.parent_user_id == current_user.id
    ).first()
    if not target:
        raise HTTPException(status_code=404, detail="Personel bulunamadı")
    target.permissions = _normalize_perms(body.permissions)
    db.add(target)
    db.commit()
    return {"id": target.id, "permissions": target.permissions or []}


@router.patch(
    "/employees/invite/{invite_id}/permissions",
    summary="Bekleyen Davetin Sayfa İzinlerini Güncelle",
)
async def update_invite_permissions(
    invite_id: int,
    body: EmployeeUpdatePermsRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _ensure_owner(current_user)
    inv = db.query(EmployeeInvite).filter(
        EmployeeInvite.id == invite_id,
        EmployeeInvite.parent_user_id == current_user.id,
        EmployeeInvite.is_consumed == False,  # noqa: E712
    ).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Davet bulunamadı")
    inv.permissions = _normalize_perms(body.permissions)
    db.add(inv)
    db.commit()
    return {"id": inv.id, "permissions": inv.permissions or []}


@router.delete(
    "/employees/{user_id}",
    summary="Personeli Komple Kaldır",
)
async def delete_employee(
    user_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Personeli firma listesinden tamamen çıkarır:
    - Patron ile bağı kopar (parent_user_id=NULL)
    - Hesabı pasifleştirilir (giriş yapamaz)
    - Yetkileri temizlenir
    - E-posta UNIQUE çakışmasını engellemek için mask'lenir; böylece
      aynı e-posta başka bir firma tarafından personel olarak yeniden
      davet edilebilir.

    NOT: Geçmiş kayıtlar (loglar vb.) korunur — kullanıcı satırı silinmez,
    sadece görünmez ve bağlantısız hâle getirilir.
    """
    _ensure_owner(current_user)
    target = db.query(User).filter(
        User.id == user_id, User.parent_user_id == current_user.id
    ).first()
    if not target:
        raise HTTPException(status_code=404, detail="Personel bulunamadı")

    import time as _time
    original_email = target.email or f"user{target.id}"
    # E-postayı invalid bir alan adıyla mask'le → UNIQUE constraint serbest kalır.
    # Aynı kişi tekrar bu firmaya alınmak istenirse de farklı bir kayıt olarak gelir.
    target.email = f"deleted+{target.id}+{int(_time.time())}@deleted.local"
    target.is_active = False
    target.permissions = []
    target.parent_user_id = None  # patron ile bağ koptu
    # Eski davet kalıntısı (consumed=True) varsa email'i de serbest kalsın diye sil
    db.query(EmployeeInvite).filter(EmployeeInvite.email == original_email).delete(synchronize_session=False)
    db.add(target)
    db.commit()
    return {"id": target.id, "removed": True, "freed_email": original_email}


@router.delete(
    "/employees/invite/{invite_id}",
    summary="Bekleyen Daveti İptal Et",
)
async def delete_invite(
    invite_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _ensure_owner(current_user)
    inv = db.query(EmployeeInvite).filter(
        EmployeeInvite.id == invite_id,
        EmployeeInvite.parent_user_id == current_user.id,
        EmployeeInvite.is_consumed == False,  # noqa: E712
    ).first()
    if not inv:
        raise HTTPException(status_code=404, detail="Davet bulunamadı")
    db.delete(inv)
    db.commit()
    return {"id": invite_id, "deleted": True}


# ============================================================
# ŞİFRE SIFIRLAMA (E-posta ile)
# ============================================================

@router.post(
    "/forgot-password",
    status_code=status.HTTP_200_OK,
    summary="Şifre sıfırlama bağlantısı gönder",
)
async def forgot_password(
    request: Request,
    body: dict,
    db: Session = Depends(get_db),
):
    """
    E-posta adresine şifre sıfırlama bağlantısı gönderir.
    E-posta bulunsun ya da bulunmasın aynı başarı mesajını döner (enumeration koruması).
    SMTP yapılandırılmamışsa 503 döner.
    """
    import os as _os, re as _re
    email = (body.get("email") or "").strip().lower()
    if not email:
        raise HTTPException(status_code=422, detail="E-posta adresi zorunludur")

    # Hesap bazlı rate limit — IP'den bağımsız (proxy havuzu saldırılarına karşı)
    try:
        from main import _check_account_rate_limit
        if not _check_account_rate_limit(email, "/api/v1/auth/forgot-password"):
            return {"message": "Eğer bu e-posta adresine kayıtlı aktif bir hesap varsa, şifre sıfırlama bağlantısı gönderildi."}
    except ImportError:
        pass

    smtp_cfg = get_smtp_settings(db)
    if not smtp_cfg:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Şifre sıfırlama e-posta servisi henüz yapılandırılmamış. Lütfen sistem yöneticisiyle iletişime geçin.",
        )

    user = db.query(User).filter(User.email == email).first()
    if user and user.is_active:
        token = generate_verification_token()
        user.password_reset_token = token
        user.password_reset_expires_at = datetime.now(timezone.utc) + timedelta(hours=1)
        db.commit()

        host_clean = (
            _os.environ.get("FRONTEND_BASE_URL", "").rstrip("/")
            or _re.sub(r"(https?://[^/]+).*", r"\1", request.headers.get("origin") or str(request.base_url).rstrip("/"))
        )
        send_password_reset_email(db, user.email, token, user.full_name, host_clean)

    return {"message": "Eğer bu e-posta adresine kayıtlı aktif bir hesap varsa, şifre sıfırlama bağlantısı gönderildi."}


@router.post(
    "/reset-password",
    status_code=status.HTTP_200_OK,
    summary="Şifreyi sıfırla",
)
async def reset_password(
    body: dict,
    db: Session = Depends(get_db),
):
    """
    Token ile yeni şifreyi kaydeder. Token 1 saatlik geçerlilik süresi var.
    """
    from app.utils.security import hash_password as _hp
    token = (body.get("token") or "").strip()
    new_password = body.get("new_password") or ""

    if not token:
        raise HTTPException(status_code=422, detail="Token zorunludur")
    if len(new_password) < 8:
        raise HTTPException(status_code=422, detail="Şifre en az 8 karakter olmalıdır")

    user = db.query(User).filter(User.password_reset_token == token).first()
    if not user:
        raise HTTPException(status_code=400, detail="Geçersiz veya süresi dolmuş sıfırlama bağlantısı")

    if not user.password_reset_expires_at:
        raise HTTPException(status_code=400, detail="Geçersiz sıfırlama bağlantısı")

    exp = user.password_reset_expires_at
    if exp.tzinfo is None:
        exp = exp.replace(tzinfo=timezone.utc)
    if datetime.now(timezone.utc) > exp:
        user.password_reset_token = None
        user.password_reset_expires_at = None
        db.commit()
        raise HTTPException(status_code=400, detail="Sıfırlama bağlantısının süresi dolmuş. Lütfen yeniden talep edin.")

    user.password_hash = _hp(new_password)
    user.password_reset_token = None
    user.password_reset_expires_at = None
    db.commit()
    return {"message": "Şifreniz başarıyla güncellendi. Artık yeni şifrenizle giriş yapabilirsiniz."}


# ─────────────────────────────────────────────────────────────────
# HESAP YÖNETİMİ — Sıfırla / Komple Sil
# ─────────────────────────────────────────────────────────────────

def _delete_owner_data(owner_id: int, db: Session):
    """
    Verilen owner_id'ye ait TÜM içeriği siler.
    Sadece o bayinin verileri etkilenir; başka bayiler dokunulmaz.
    Devices unpair edilir (silinmez — donanım kayıt dışında kalmaz).
    """
    from app.models.product import Product
    from app.models.transaction import Transaction
    from app.models.warranty import Warranty
    from app.models.category import Category
    from app.models.debtor_link import DebtorLink
    from app.models.bayi_backup import BayiBackup
    from app.models.payment import Payment
    from app.models.device import Device

    # Ürünler
    db.query(Product).filter(Product.user_id == owner_id).delete(synchronize_session=False)
    # İşlemler (borç/alacak/satış)
    db.query(Transaction).filter(Transaction.user_id == owner_id).delete(synchronize_session=False)
    # Garantiler
    db.query(Warranty).filter(Warranty.user_id == owner_id).delete(synchronize_session=False)
    # Kategoriler
    db.query(Category).filter(Category.user_id == owner_id).delete(synchronize_session=False)
    # Borçlu bağlantıları
    db.query(DebtorLink).filter(DebtorLink.user_id == owner_id).delete(synchronize_session=False)
    # Yedekler
    db.query(BayiBackup).filter(BayiBackup.user_id == owner_id).delete(synchronize_session=False)
    # Ödemeler
    db.query(Payment).filter(Payment.user_id == owner_id).delete(synchronize_session=False)
    # Cihazlar — unpair et, silme (donanım kaydı korunur)
    for dev in db.query(Device).filter(Device.user_id == owner_id).all():
        dev.user_id = None
        dev.is_paired = False
        dev.paired_at = None
    db.flush()


@router.post(
    "/account/reset",
    summary="Hesap içeriğini sıfırla (veriler silinir, hesap kalır)",
)
async def reset_account(
    body: dict,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Hesabın TÜM içeriğini siler; kullanıcı hesabı ve personeller korunur.
    Sadece bayi sahipleri çağırabilir (calisanların verisi zaten patrona ait).
    Şifre doğrulaması zorunludur.

    Silinen veriler:
      - Ürünler, İşlemler, Garantiler, Kategoriler
      - Borçlu bağlantıları, Yedekler, Ödemeler
      - Cihazlar unpair edilir (kayıt silinmez)

    Korunan veriler:
      - Kullanıcı hesabı (giriş bilgileri, abonelik)
      - Personel hesapları
      - Diğer bayilerin tüm verileri
    """
    password = (body.get("password") or "").strip()
    if not password:
        raise HTTPException(status_code=422, detail="Şifre zorunludur.")

    if not verify_password(password, current_user.password_hash):
        raise HTTPException(status_code=403, detail="Şifre hatalı.")

    # Sadece bayi sahipleri için anlamlı — çalışanın verisi patrona ait
    if current_user.role != "bayi_sahibi":
        raise HTTPException(
            status_code=403,
            detail="İçerik sıfırlama yalnızca bayi sahipleri tarafından yapılabilir.",
        )

    _delete_owner_data(current_user.id, db)
    db.commit()
    return {"message": "Hesap içeriği başarıyla sıfırlandı. Verileriniz temizlendi."}


@router.delete(
    "/account",
    summary="Hesabı komple sil",
)
async def delete_account(
    body: dict,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Hesabı ve tüm verilerini kalıcı olarak siler. Geri alınamaz.

    Bayi sahibi için:
      - Tüm içerik silinir (ürünler, işlemler, garantiler vb.)
      - Personel hesapları da silinir (parent_user_id == bu kullanıcı)
      - Hesabın kendisi silinir

    Çalışan için:
      - Sadece kendi hesabı silinir
      - Patronun verilerine, diğer personele dokunulmaz

    Şifre doğrulaması zorunludur.
    """
    import time as _time

    password = (body.get("password") or "").strip()
    if not password:
        raise HTTPException(status_code=422, detail="Şifre zorunludur.")

    if not verify_password(password, current_user.password_hash):
        raise HTTPException(status_code=403, detail="Şifre hatalı.")

    # Süper admin kendini silemez
    if current_user.is_super_admin:
        raise HTTPException(status_code=403, detail="Süper yönetici hesabı silinemez.")

    if current_user.role == "bayi_sahibi":
        # 1. Tüm bayiye ait içeriği sil
        _delete_owner_data(current_user.id, db)

        # 2. Personel hesaplarını sil (parent_user_id == bu bayi)
        employees = db.query(User).filter(User.parent_user_id == current_user.id).all()
        for emp in employees:
            # E-postayı mask'le → UNIQUE constraint serbest kalır
            emp.email = f"deleted+{emp.id}+{int(_time.time())}@deleted.local"
            emp.is_active = False
            emp.parent_user_id = None
        db.flush()

        # 3. Bekleyen davetleri iptal et
        db.query(EmployeeInvite).filter(
            EmployeeInvite.parent_user_id == current_user.id
        ).delete(synchronize_session=False)
        db.flush()

    # Hesabı sil (hem bayi hem çalışan)
    db.delete(current_user)
    db.commit()
    return {"message": "Hesabınız kalıcı olarak silindi."}


# ============================================================
# Ana Panel Düzeni — GET/PUT /auth/dashboard-layout
# ============================================================

@router.get("/dashboard-layout", status_code=200, summary="Ana panel düzenini getir")
async def get_dashboard_layout(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Kullanıcının kaydedilmiş dashboard widget düzenini ve renk temasını döner."""
    from app.utils.tenant import data_owner_id
    owner_id = data_owner_id(current_user)
    owner = db.query(User).filter(User.id == owner_id).first()
    return {"dashboard_layout": owner.dashboard_layout if owner else None}


@router.put("/dashboard-layout", status_code=200, summary="Ana panel düzenini kaydet")
async def put_dashboard_layout(
    payload: dict,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Kullanıcının dashboard widget düzenini ve renk temasını kaydeder."""
    from app.utils.tenant import data_owner_id
    owner_id = data_owner_id(current_user)
    owner = db.query(User).filter(User.id == owner_id).first()
    if not owner:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")
    layout = payload.get("dashboard_layout")
    if layout is not None:
        owner.dashboard_layout = layout
        db.commit()
    return {"ok": True}
