"""
Warranty (Garanti Belgeleri) API.

Bayi paneli için CRUD + QR kod üretimi + WhatsApp paylaşım yardımcısı.
Müşterinin gördüğü public sayfa `app/api/public.py` içindedir.
"""
from __future__ import annotations

import io
import re
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List, Optional

import qrcode
from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File, Form, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models import User, Warranty
from app.utils.auth import get_current_user
from app.utils.tenant import data_owner_id
from app.services.sync_service import record_deletion, trigger_delta_push

router = APIRouter(prefix="/warranty", tags=["Warranty"])


UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

ALLOWED_IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
MAX_IMAGE_SIZE = 10 * 1024 * 1024  # 10 MiB

DURATION_PRESETS = {
    "1 ay": 30,
    "3 ay": 90,
    "6 ay": 180,
    "7 ay": 210,
    "1 yıl": 365,
    "2 yıl": 730,
    "3 yıl": 1095,
}


# ============================================================
# Schemas
# ============================================================

class WarrantyOut(BaseModel):
    id: int
    product_name: str
    product_image_url: Optional[str] = None
    customer_name: str
    customer_phone: Optional[str] = None
    duration_label: str
    duration_days: int
    start_date: datetime
    end_date: datetime
    public_token: str
    notes: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    is_expired: bool
    days_remaining: int

    class Config:
        from_attributes = True


def _to_out(w: Warranty) -> WarrantyOut:
    now = datetime.now(timezone.utc)
    end = w.end_date if w.end_date.tzinfo else w.end_date.replace(tzinfo=timezone.utc)
    is_expired = end < now
    days_remaining = max(0, (end - now).days)
    return WarrantyOut(
        id=w.id,
        product_name=w.product_name,
        product_image_url=w.product_image_url,
        customer_name=w.customer_name,
        customer_phone=w.customer_phone,
        duration_label=w.duration_label,
        duration_days=w.duration_days,
        start_date=w.start_date,
        end_date=w.end_date,
        public_token=w.public_token,
        notes=w.notes,
        created_at=w.created_at,
        updated_at=w.updated_at,
        is_expired=is_expired,
        days_remaining=days_remaining,
    )


# ============================================================
# Helpers
# ============================================================

_IMAGE_MAGIC: dict[bytes, str] = {
    b"\xff\xd8\xff":    ".jpg",
    b"\x89PNG\r\n":     ".png",
    b"RIFF":            ".webp",  # webp: RIFF....WEBP
    b"GIF87a":          ".gif",
    b"GIF89a":          ".gif",
}

def _check_image_magic(content: bytes, declared_suffix: str) -> None:
    """İçerik magic bytes ile beyan edilen uzantının uyumunu doğrula."""
    for magic, ext in _IMAGE_MAGIC.items():
        if content.startswith(magic):
            # WebP için ek kontrol (RIFF....WEBP)
            if magic == b"RIFF" and len(content) >= 12 and content[8:12] != b"WEBP":
                continue
            if declared_suffix in (".jpg", ".jpeg") and ext == ".jpg":
                return
            if declared_suffix == ext:
                return
    # Magic bytes bilinen formatlara uymadı veya uzantıyla çelişti
    raise HTTPException(status_code=400, detail="Dosya içeriği görüntü formatıyla uyuşmuyor.")


def _save_image(file: UploadFile) -> str:
    raw_suffix = Path(file.filename or "").suffix
    import re as _re
    suffix = _re.sub(r"[^a-zA-Z0-9.]", "", raw_suffix)[:10].lower()
    if suffix not in ALLOWED_IMAGE_EXT:
        raise HTTPException(
            status_code=400,
            detail=f"Geçersiz dosya türü. İzin verilenler: {', '.join(sorted(ALLOWED_IMAGE_EXT))}",
        )
    content = file.file.read()
    if len(content) == 0:
        raise HTTPException(status_code=400, detail="Boş dosya.")
    if len(content) > MAX_IMAGE_SIZE:
        raise HTTPException(status_code=400, detail="Resim 10 MB'dan büyük olamaz.")
    _check_image_magic(content, suffix)
    name = f"warranty_{uuid.uuid4().hex}{suffix}"
    (UPLOAD_DIR / name).write_bytes(content)
    return f"/api/v1/files/{name}"


def _normalize_phone_for_wa(phone: str) -> Optional[str]:
    """+90 ile başlayan E.164 benzeri normalize. Geçersizse None."""
    if not phone:
        return None
    digits = re.sub(r"\D", "", phone)
    if not digits:
        return None
    if digits.startswith("00"):
        digits = digits[2:]
    if digits.startswith("90"):
        return digits
    if digits.startswith("0"):
        digits = digits[1:]
    if len(digits) == 10:
        return "90" + digits
    if len(digits) >= 10:
        return digits
    return None


def _resolve_duration(label: str, custom_days: Optional[int]) -> tuple[str, int]:
    if label == "Özel":
        if custom_days is None or custom_days <= 0:
            raise HTTPException(status_code=400, detail="Özel süre için 'duration_days' (>0) zorunlu.")
        if custom_days > 36500:
            raise HTTPException(status_code=400, detail="Süre çok uzun (max 100 yıl).")
        return ("Özel", int(custom_days))
    if label not in DURATION_PRESETS:
        raise HTTPException(status_code=400, detail=f"Geçersiz süre. Seçenekler: {list(DURATION_PRESETS.keys())} veya Özel.")
    return (label, DURATION_PRESETS[label])


# ============================================================
# Endpoints
# ============================================================

@router.get("", response_model=List[WarrantyOut])
def list_warranties(
    status: str = Query("all", pattern="^(all|active|expired)$"),
    customer_name: Optional[str] = None,
    q: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Bayinin tüm garanti belgelerini listele. status=active|expired|all."""
    owner = data_owner_id(current_user)
    query = db.query(Warranty).filter(Warranty.user_id == owner)

    now = datetime.now(timezone.utc)
    if status == "active":
        query = query.filter(Warranty.end_date >= now)
    elif status == "expired":
        query = query.filter(Warranty.end_date < now)

    if customer_name:
        query = query.filter(Warranty.customer_name == customer_name)

    if q:
        like = f"%{q}%"
        query = query.filter(or_(
            Warranty.product_name.ilike(like),
            Warranty.customer_name.ilike(like),
            Warranty.customer_phone.ilike(like),
        ))

    rows = query.order_by(Warranty.end_date.desc()).limit(2000).all()
    return [_to_out(w) for w in rows]


@router.post("", response_model=WarrantyOut, status_code=201)
def create_warranty(
    product_name: str = Form(...),
    customer_name: str = Form(...),
    customer_phone: Optional[str] = Form(None),
    duration_label: str = Form("1 yıl"),
    duration_days: Optional[int] = Form(None),  # only used when label == "Özel"
    start_date: Optional[str] = Form(None),  # ISO; default = now
    notes: Optional[str] = Form(None),
    image: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    owner = data_owner_id(current_user)
    if not product_name.strip():
        raise HTTPException(status_code=400, detail="Ürün adı boş olamaz.")
    if not customer_name.strip():
        raise HTTPException(status_code=400, detail="Müşteri adı boş olamaz.")

    label, days = _resolve_duration(duration_label, duration_days)

    if start_date:
        try:
            sd = datetime.fromisoformat(start_date.replace("Z", "+00:00"))
            if sd.tzinfo is None:
                sd = sd.replace(tzinfo=timezone.utc)
        except ValueError:
            raise HTTPException(status_code=400, detail="Geçersiz başlangıç tarihi (ISO formatında olmalı).")
    else:
        sd = datetime.now(timezone.utc)

    end_date = sd + timedelta(days=days)

    image_url = _save_image(image) if image and image.filename else None

    token = secrets.token_urlsafe(24)

    w = Warranty(
        user_id=owner,
        product_name=product_name.strip()[:255],
        product_image_url=image_url,
        customer_name=customer_name.strip()[:255],
        customer_phone=(customer_phone or "").strip()[:40] or None,
        duration_label=label,
        duration_days=days,
        start_date=sd,
        end_date=end_date,
        public_token=token,
        notes=(notes or "").strip()[:2000] or None,
    )
    db.add(w)
    db.commit()
    db.refresh(w)
    return _to_out(w)


@router.get("/{wid}", response_model=WarrantyOut)
def get_warranty(
    wid: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    owner = data_owner_id(current_user)
    w = db.query(Warranty).filter(Warranty.id == wid, Warranty.user_id == owner).first()
    if not w:
        raise HTTPException(status_code=404, detail="Garanti belgesi bulunamadı.")
    return _to_out(w)


@router.put("/{wid}", response_model=WarrantyOut)
def update_warranty(
    wid: int,
    product_name: Optional[str] = Form(None),
    customer_name: Optional[str] = Form(None),
    customer_phone: Optional[str] = Form(None),
    duration_label: Optional[str] = Form(None),
    duration_days: Optional[int] = Form(None),
    start_date: Optional[str] = Form(None),
    notes: Optional[str] = Form(None),
    image: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    owner = data_owner_id(current_user)
    w = db.query(Warranty).filter(Warranty.id == wid, Warranty.user_id == owner).first()
    if not w:
        raise HTTPException(status_code=404, detail="Garanti belgesi bulunamadı.")

    if product_name is not None:
        if not product_name.strip():
            raise HTTPException(status_code=400, detail="Ürün adı boş olamaz.")
        w.product_name = product_name.strip()[:255]

    if customer_name is not None:
        if not customer_name.strip():
            raise HTTPException(status_code=400, detail="Müşteri adı boş olamaz.")
        w.customer_name = customer_name.strip()[:255]

    if customer_phone is not None:
        w.customer_phone = customer_phone.strip()[:40] or None

    if notes is not None:
        w.notes = notes.strip()[:2000] or None

    if image and image.filename:
        w.product_image_url = _save_image(image)

    # Süre veya başlangıç değişirse end_date yeniden hesapla
    days_changed = duration_label is not None or duration_days is not None
    start_changed = start_date is not None

    if days_changed:
        label = duration_label if duration_label is not None else w.duration_label
        custom = duration_days if duration_label == "Özel" or w.duration_label == "Özel" else None
        new_label, new_days = _resolve_duration(label, custom)
        w.duration_label = new_label
        w.duration_days = new_days

    if start_changed:
        try:
            sd = datetime.fromisoformat(start_date.replace("Z", "+00:00"))
            if sd.tzinfo is None:
                sd = sd.replace(tzinfo=timezone.utc)
        except ValueError:
            raise HTTPException(status_code=400, detail="Geçersiz başlangıç tarihi.")
        w.start_date = sd

    if days_changed or start_changed:
        sd = w.start_date if w.start_date.tzinfo else w.start_date.replace(tzinfo=timezone.utc)
        w.end_date = sd + timedelta(days=w.duration_days)

    db.commit()
    db.refresh(w)
    return _to_out(w)


@router.delete("/{wid}", status_code=204)
def delete_warranty(
    wid: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    owner = data_owner_id(current_user)
    w = db.query(Warranty).filter(Warranty.id == wid, Warranty.user_id == owner).first()
    if not w:
        raise HTTPException(status_code=404, detail="Garanti belgesi bulunamadı.")
    record_deletion(db, "warranties", w.id)
    db.delete(w)
    db.commit()
    trigger_delta_push()
    return None


def _safe_base_url(request: Request, client_hint: Optional[str] = None) -> str:
    """
    Public link base URL'sini GÜVENLİ ve PRODUCTION-SAFE şekilde derive et.

    Öncelik sırası:
      1) PUBLIC_BASE_URL ortam değişkeni (operatör override — production'da set edilmeli)
      2) X-Forwarded-Proto + X-Forwarded-Host (Vite proxy / reverse proxy zinciri)
      3) Client hint (browser'ın window.location.origin'i — gerçek public URL)
      4) request.base_url (son çare — dev'de hep localhost olur, production'da iç host olabilir)

    KRİTİK: Loopback adresleri (127.0.0.1, localhost, 0.0.0.0) ve internal hostname'ler
    asla public link içinde kullanılmaz; bu adresler içeren her aday ATLANIR.
    Public link kimseye direkt backend port'unu (8000) sızdırmaz.

    Asla: client'ın gönderdiği path / query / fragment kullanılmaz;
    "javascript:" gibi schemeler reddedilir.
    """
    import os
    from urllib.parse import urlparse

    INTERNAL_HOSTS = ("127.0.0.1", "localhost", "0.0.0.0", "::1")

    def _is_public_hostname(hostname: Optional[str]) -> bool:
        # urlparse.hostname IPv6 köşeli parantezleri otomatik soyar ve lowercase eder,
        # bu yüzden "[::1]:8000" -> "::1" gibi gelir. Bracket-split bug riski yok.
        if not hostname:
            return False
        h = hostname.strip().lower()
        if h in INTERNAL_HOSTS:
            return False
        # 127.0.0.0/8 tüm bloğunu da kes (örn. 127.1.2.3) — bazı dev araçları kullanır.
        if h.startswith("127."):
            return False
        return True

    def _normalize(candidate: str) -> Optional[str]:
        try:
            p = urlparse(candidate)
            if p.scheme in ("http", "https") and p.netloc and _is_public_hostname(p.hostname):
                return f"{p.scheme}://{p.netloc}"
        except Exception:
            pass
        return None

    # 1) Operator override
    env_base = os.environ.get("PUBLIC_BASE_URL", "").strip()
    if env_base:
        n = _normalize(env_base)
        if n:
            return n

    # 2) Forwarded headers (Vite proxy bunları manuel set ediyor — vite.config.ts'e bak)
    fwd_proto = request.headers.get("x-forwarded-proto", "").split(",")[0].strip().lower()
    fwd_host  = request.headers.get("x-forwarded-host", "").split(",")[0].strip()
    if fwd_proto in ("http", "https") and fwd_host:
        n = _normalize(f"{fwd_proto}://{fwd_host}")
        if n:
            return n

    # 3) Client hint — browser'ın gerçek origin'i. request.base_url'dan ÖNCE,
    # çünkü uvicorn 127.0.0.1:8000'e bind, request.base_url her zaman localhost döndürür.
    if client_hint:
        n = _normalize(client_hint)
        if n:
            return n

    # 4) request.base_url son çare. Loopback ise boş döneriz — caller hata verir,
    # böylece kullanıcıya yanlış (kullanılamaz) link asla gönderilmez.
    try:
        bu = str(request.base_url).rstrip("/")
        n = _normalize(bu)
        if n:
            return n
    except Exception:
        pass

    return ""


def _build_public_url(base: str, token: str, kind: str = "garanti") -> str:
    base = (base or "").rstrip("/")
    return f"{base}/{kind}/{token}"


@router.get("/{wid}/qr.png")
def warranty_qr(
    wid: int,
    request: Request,
    base_url: Optional[str] = Query(None, description="Opsiyonel client hint; backend kendi origin'ini tercih eder."),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    owner = data_owner_id(current_user)
    w = db.query(Warranty).filter(Warranty.id == wid, Warranty.user_id == owner).first()
    if not w:
        raise HTTPException(status_code=404, detail="Garanti belgesi bulunamadı.")
    safe_base = _safe_base_url(request, base_url)
    if not safe_base:
        raise HTTPException(status_code=500, detail="Public base URL belirlenemedi (PUBLIC_BASE_URL ayarlanmamış).")
    public_url = _build_public_url(safe_base, w.public_token, "garanti")
    img = qrcode.make(public_url)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="image/png",
        headers={
            "Content-Disposition": f'inline; filename="garanti-{wid}.png"',
            "Cache-Control": "no-store",
        },
    )


class WhatsAppLinkOut(BaseModel):
    public_url: str
    wa_url: Optional[str] = None
    text: str


@router.post("/{wid}/whatsapp-link", response_model=WhatsAppLinkOut)
def warranty_whatsapp_link(
    wid: int,
    request: Request,
    base_url: Optional[str] = Form(None, description="Opsiyonel client hint; backend kendi origin'ini tercih eder."),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    owner = data_owner_id(current_user)
    w = db.query(Warranty).filter(Warranty.id == wid, Warranty.user_id == owner).first()
    if not w:
        raise HTTPException(status_code=404, detail="Garanti belgesi bulunamadı.")

    safe_base = _safe_base_url(request, base_url)
    if not safe_base:
        raise HTTPException(status_code=500, detail="Public base URL belirlenemedi.")
    public_url = _build_public_url(safe_base, w.public_token, "garanti")
    bayi_name = current_user.company_name or current_user.full_name or "Bayi"
    text = (
        f"Merhaba {w.customer_name},\n\n"
        f"\"{w.product_name}\" ürünü için garanti belgeniz hazır.\n"
        f"Garanti süresi: {w.duration_label} (bitiş: {w.end_date.strftime('%d.%m.%Y')}).\n\n"
        f"Anlık takip ve QR doğrulama için:\n{public_url}\n\n"
        f"— {bayi_name}"
    )
    import urllib.parse as _u
    wa_phone = _normalize_phone_for_wa(w.customer_phone or "")
    wa_url = None
    if wa_phone:
        wa_url = f"https://wa.me/{wa_phone}?text={_u.quote(text)}"
    return WhatsAppLinkOut(public_url=public_url, wa_url=wa_url, text=text)
