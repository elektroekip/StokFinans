from __future__ import annotations

from datetime import date, datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models import User
from app.models.plasiyer import CustomerVisit, VisitPlan
from app.schemas.plasiyer import (
    CheckOutUpdate,
    PlasiyerStatsOut,
    VisitCreate,
    VisitOut,
    VisitPlanCreate,
    VisitPlanOut,
    VisitPlanUpdate,
)
from app.utils.auth import get_current_user
from app.utils.permissions import has_perm, is_owner, require_perm
from app.utils.tenant import data_owner_id
from app.services.sync_service import record_deletion, trigger_delta_push

router = APIRouter(prefix="/plasiyer", tags=["Plasiyer"])


# ── Helpers ───────────────────────────────────────────────────


def _tenant_user_ids(db: Session, owner_id: int) -> List[int]:
    """Return IDs of the owner and all their employees."""
    employee_ids = [
        row[0]
        for row in db.query(User.id).filter(User.parent_user_id == owner_id).all()
    ]
    return [owner_id] + employee_ids


def _can_see_all(current_user) -> bool:
    """Owner or a user with plasiyer.manage may see all tenant visits."""
    return is_owner(current_user) or has_perm(current_user, "plasiyer.manage")


def _get_visit_or_404(db: Session, visit_id: int, owner_id: int) -> CustomerVisit:
    ids = _tenant_user_ids(db, owner_id)
    visit = db.query(CustomerVisit).filter(
        CustomerVisit.id == visit_id,
        CustomerVisit.user_id.in_(ids),
    ).first()
    if not visit:
        raise HTTPException(status_code=404, detail="Ziyaret kaydı bulunamadı")
    return visit


def _get_plan_or_404(db: Session, plan_id: int, owner_id: int) -> VisitPlan:
    ids = _tenant_user_ids(db, owner_id)
    plan = db.query(VisitPlan).filter(
        VisitPlan.id == plan_id,
        VisitPlan.user_id.in_(ids),
    ).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Ziyaret planı bulunamadı")
    return plan


# ── Stats ─────────────────────────────────────────────────────


@router.get("/stats", response_model=PlasiyerStatsOut)
def get_plasiyer_stats(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "plasiyer.view")

    now = datetime.now(timezone.utc)
    today = now.date()
    uid = current_user.id

    total_visits_today = db.query(func.count(CustomerVisit.id)).filter(
        CustomerVisit.user_id == uid,
        func.date(CustomerVisit.check_in_at) == today,
    ).scalar() or 0

    total_visits_this_month = db.query(func.count(CustomerVisit.id)).filter(
        CustomerVisit.user_id == uid,
        func.extract("year", CustomerVisit.check_in_at) == now.year,
        func.extract("month", CustomerVisit.check_in_at) == now.month,
    ).scalar() or 0

    planned_today = db.query(func.count(VisitPlan.id)).filter(
        VisitPlan.user_id == uid,
        VisitPlan.planned_date == today,
        VisitPlan.status == "planned",
    ).scalar() or 0

    done_today = db.query(func.count(VisitPlan.id)).filter(
        VisitPlan.user_id == uid,
        VisitPlan.planned_date == today,
        VisitPlan.status == "done",
    ).scalar() or 0

    orders_taken_this_month = db.query(func.count(CustomerVisit.id)).filter(
        CustomerVisit.user_id == uid,
        CustomerVisit.result == "order_taken",
        func.extract("year", CustomerVisit.check_in_at) == now.year,
        func.extract("month", CustomerVisit.check_in_at) == now.month,
    ).scalar() or 0

    return PlasiyerStatsOut(
        total_visits_today=total_visits_today,
        total_visits_this_month=total_visits_this_month,
        planned_today=planned_today,
        done_today=done_today,
        orders_taken_this_month=orders_taken_this_month,
    )


# ── Visits ────────────────────────────────────────────────────


@router.get("/visits", response_model=List[VisitOut])
def list_visits(
    date_filter: Optional[date] = Query(None, alias="date"),
    plasiyer_id: Optional[int] = Query(None),
    limit: int = Query(50, ge=1, le=500),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "plasiyer.view")
    owner = data_owner_id(current_user)

    if _can_see_all(current_user):
        ids = _tenant_user_ids(db, owner)
        query = db.query(CustomerVisit).filter(CustomerVisit.user_id.in_(ids))
        if plasiyer_id is not None:
            if plasiyer_id not in ids:
                raise HTTPException(status_code=403, detail="Bu plasiyere erişim yetkiniz yok")
            query = query.filter(CustomerVisit.user_id == plasiyer_id)
    else:
        query = db.query(CustomerVisit).filter(CustomerVisit.user_id == current_user.id)

    if date_filter is not None:
        query = query.filter(func.date(CustomerVisit.check_in_at) == date_filter)

    visits = query.order_by(CustomerVisit.check_in_at.desc()).limit(limit).all()
    return [VisitOut.model_validate(v) for v in visits]


@router.post("/visits", response_model=VisitOut, status_code=201)
def create_visit(
    data: VisitCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "plasiyer.manage")

    visit = CustomerVisit(
        user_id=current_user.id,
        btb_customer_id=data.btb_customer_id,
        customer_name=data.customer_name,
        latitude=data.latitude,
        longitude=data.longitude,
        address_label=data.address_label,
        notes=data.notes,
        result=data.result,
        btb_order_id=data.btb_order_id,
    )
    db.add(visit)
    db.commit()
    db.refresh(visit)
    return VisitOut.model_validate(visit)


@router.post("/visits/{visit_id}/checkout", response_model=VisitOut)
def checkout_visit(
    visit_id: int,
    data: CheckOutUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "plasiyer.manage")
    owner = data_owner_id(current_user)
    visit = _get_visit_or_404(db, visit_id, owner)

    if visit.check_out_at is not None:
        raise HTTPException(status_code=400, detail="Bu ziyaret zaten teslim edilmiş")

    now = datetime.now(timezone.utc)
    check_out = data.check_out_at or now

    duration: Optional[int] = data.duration_minutes
    if duration is None and visit.check_in_at is not None:
        check_in = visit.check_in_at
        if check_in.tzinfo is None:
            check_in = check_in.replace(tzinfo=timezone.utc)
        delta = check_out - check_in
        duration = max(0, int(delta.total_seconds() // 60))

    visit.check_out_at = check_out
    visit.duration_minutes = duration
    if data.notes is not None:
        visit.notes = data.notes
    visit.result = data.result

    db.commit()
    db.refresh(visit)
    return VisitOut.model_validate(visit)


# ── Plans ─────────────────────────────────────────────────────


@router.get("/plans", response_model=List[VisitPlanOut])
def list_plans(
    date_filter: Optional[date] = Query(None, alias="date"),
    plasiyer_id: Optional[int] = Query(None),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "plasiyer.view")
    owner = data_owner_id(current_user)

    if _can_see_all(current_user):
        ids = _tenant_user_ids(db, owner)
        query = db.query(VisitPlan).filter(VisitPlan.user_id.in_(ids))
        if plasiyer_id is not None:
            if plasiyer_id not in ids:
                raise HTTPException(status_code=403, detail="Bu plasiyere erişim yetkiniz yok")
            query = query.filter(VisitPlan.user_id == plasiyer_id)
    else:
        query = db.query(VisitPlan).filter(VisitPlan.user_id == current_user.id)

    if date_filter is not None:
        query = query.filter(VisitPlan.planned_date == date_filter)

    plans = query.order_by(VisitPlan.planned_date, VisitPlan.planned_order).all()
    return [VisitPlanOut.model_validate(p) for p in plans]


@router.post("/plans", response_model=VisitPlanOut, status_code=201)
def create_plan(
    data: VisitPlanCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "plasiyer.manage")

    plan = VisitPlan(
        user_id=current_user.id,
        btb_customer_id=data.btb_customer_id,
        customer_name=data.customer_name,
        planned_date=data.planned_date,
        planned_order=data.planned_order,
        notes=data.notes,
    )
    db.add(plan)
    db.commit()
    db.refresh(plan)
    return VisitPlanOut.model_validate(plan)


@router.put("/plans/{plan_id}", response_model=VisitPlanOut)
def update_plan(
    plan_id: int,
    data: VisitPlanUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "plasiyer.manage")
    owner = data_owner_id(current_user)
    plan = _get_plan_or_404(db, plan_id, owner)

    for field, val in data.model_dump(exclude_unset=True).items():
        setattr(plan, field, val)

    db.commit()
    db.refresh(plan)
    return VisitPlanOut.model_validate(plan)


@router.delete("/plans/{plan_id}", status_code=204)
def delete_plan(
    plan_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "plasiyer.manage")
    owner = data_owner_id(current_user)
    plan = _get_plan_or_404(db, plan_id, owner)

    if plan.status != "planned":
        raise HTTPException(
            status_code=400,
            detail="Yalnızca 'planned' durumundaki planlar silinebilir",
        )

    record_deletion(db, "visit_plans", plan.id)
    db.delete(plan)
    db.commit()
    trigger_delta_push()
