# ============================================================
# File Upload Endpoints - Dosya Yönetimi API
# ============================================================
# Ürün fotoğrafı, işlem belgesi ve rapor yükleme
#
# Seviye: SEVIYE 5 - Gelişmiş Özellikler
# Tarih: 28 Nisan 2026
# ============================================================

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status
from app.utils.tenant import data_owner_id
from sqlalchemy.orm import Session
import os
import uuid
from datetime import datetime
from app.core.database import get_db
from app.models import Product, Transaction, User, ActivityLog
from app.models.file_location import FileLocation
from app.models.sync_node import SyncNode
from app.schemas.file import (
    FileUploadResponse,
    ProductImageResponse,
    TransactionAttachmentResponse,
    FileDeleteResponse
)
from app.utils.auth import get_current_user
from pathlib import Path
from app.services.sync_service import push_file_to_nodes, trigger_delta_push, _node_headers
from app.services.disk_service import is_disk_low, find_best_peer_node

router = APIRouter(prefix="/files", tags=["File Management"])

# ============================================================
# Ayarlar
# ============================================================

UPLOAD_DIR = Path("uploads")
ALLOWED_PRODUCT_FORMATS = {"image/jpeg", "image/png", "image/webp"}
ALLOWED_DOCUMENT_FORMATS = {"application/pdf", "image/jpeg", "image/png"}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB

# MIME → izin verilen uzantı eşleşmesi (çapraz doğrulama için)
_MIME_TO_EXT: dict[str, set[str]] = {
    "image/jpeg":       {".jpg", ".jpeg"},
    "image/png":        {".png"},
    "image/webp":       {".webp"},
    "application/pdf":  {".pdf"},
}

# Yükleme klasörünü oluştur
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# ============================================================
# Yardımcı Fonksiyonlar
# ============================================================

def validate_file(file: UploadFile, allowed_formats: set, max_size: int):
    """
    Dosya doğrulama: MIME tipi + uzantı çapraz kontrolü.
    Yalnızca MIME tipini kontrol etmek yeterli değildir; saldırgan
    Content-Type başlığını manipüle edebilir. Uzantı da doğrulanır.
    """
    mime = (file.content_type or "").lower().split(";")[0].strip()
    if mime not in allowed_formats:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Geçersiz dosya türü. İzin verilen: {', '.join(sorted(allowed_formats))}"
        )
    # Uzantı ile MIME tipinin uyumunu kontrol et
    ext = os.path.splitext(file.filename or "")[1].lower()
    allowed_exts = _MIME_TO_EXT.get(mime, set())
    if allowed_exts and ext not in allowed_exts:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Dosya uzantısı ({ext}) MIME tipiyle ({mime}) uyuşmuyor"
        )


def generate_filename(original_filename: str, entity_type: str, entity_id: int) -> str:
    """
    Benzersiz ve güvenli dosya adı oluştur.
    Uzantı yalnızca alfanümerik karakterler içerebilir; path traversal ve
    null byte saldırılarına karşı sanitize edilir.
    """
    raw_ext = os.path.splitext(original_filename or "")[1]
    # Sadece harf/rakam + nokta, max 10 karakter
    import re as _re
    ext = _re.sub(r"[^a-zA-Z0-9.]", "", raw_ext)[:10].lower()
    unique_id = str(uuid.uuid4())[:8]
    return f"{entity_type}_{entity_id}_{unique_id}{ext}"


def save_file(file: UploadFile, filename: str) -> tuple:
    """
    Dosyayı disk'e kaydet (geriye uyumluluk için - DB erişimi olmayan çağrılar için).
    Disk kontrollü kayıt için save_file_smart() kullanın.
    """
    file_path = UPLOAD_DIR / filename
    content = file.file.read()
    file_size = len(content)
    if file_size > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Dosya çok büyük. Maksimum: {MAX_FILE_SIZE / (1024*1024):.1f}MB"
        )
    with open(file_path, "wb") as buffer:
        buffer.write(content)
    return str(file_path), file_size


def save_file_smart(file: UploadFile, filename: str, db: Session) -> tuple:
    """
    Disk algoritması (diyagram):
      1. İçeriği oku, boyut kontrolü yap
      2. Yerel disk yeterli mi? → Yerel kaydet
      3. Disk dolu → En uygun peer node'a gönder, FileLocation kaydı oluştur
      4. Peer bulunamazsa → Yine de yerel kaydet (en kötü durum)

    Returns:
        (file_path_or_none, remote_node_id_or_none, file_size)
    """
    import httpx as _httpx

    content = file.file.read()
    file_size = len(content)
    if file_size > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Dosya çok büyük. Maksimum: {MAX_FILE_SIZE / (1024*1024):.1f}MB"
        )

    # Disk kontrolü
    if is_disk_low():
        peer = find_best_peer_node(db)
        if peer:
            try:
                r = _httpx.post(
                    f"{peer.url.rstrip('/')}/api/v1/sync/push-file",
                    headers=_node_headers(peer),
                    files={"file": (filename, content, "application/octet-stream")},
                    timeout=30.0,
                )
                if r.status_code == 200:
                    # FileLocation kaydı oluştur (bu sunucu dosyanın peer'da olduğunu bilsin)
                    _record_file_location(db, filename, peer.id, file_size)
                    print(f"[DISK] {filename} → {peer.name} (disk düşük, peer'a gönderildi)")
                    return None, peer.id, file_size
            except Exception as e:
                print(f"[DISK] Peer'a gönderilemedi ({peer.name}): {e}")

    # Yerel kaydet
    file_path = UPLOAD_DIR / filename
    with open(file_path, "wb") as buffer:
        buffer.write(content)
    _record_file_location(db, filename, None, file_size)
    return str(file_path), None, file_size


def _record_file_location(db: Session, filename: str, node_id, file_size: int) -> None:
    """FileLocation kaydı oluştur veya güncelle."""
    from datetime import datetime
    existing = db.query(FileLocation).filter(FileLocation.filename == filename).first()
    if existing:
        existing.node_id = node_id
        existing.file_size_bytes = file_size
    else:
        loc = FileLocation(filename=filename, node_id=node_id, file_size_bytes=file_size)
        db.add(loc)
    try:
        db.commit()
    except Exception:
        db.rollback()


def _user_owns_file(db: Session, filename: str, user_id: int) -> bool:
    """
    Çoklu kiracılık (multi-tenant) sahiplik kontrolü.

    Dosya adı şu formatta üretiliyor:
      product_{product_id}_{uuid}.ext
      transaction_{attachment_type}_{transaction_id}_{uuid}.ext

    Bu yardımcı, dosyada referans verilen ürün/işlemin gerçekten
    `user_id`'ye ait olup olmadığını kontrol eder. Format dışı dosyalar
    için güvenli tarafta kalıp False döner.
    """
    parts = filename.split("_")
    if not parts:
        return False
    entity_type = parts[0]
    try:
        if entity_type == "product" and len(parts) >= 2:
            product_id = int(parts[1])
            return db.query(Product.id).filter(
                Product.id == product_id,
                Product.user_id == user_id,
            ).first() is not None
        if entity_type == "transaction" and len(parts) >= 3:
            transaction_id = int(parts[2])
            return db.query(Transaction.id).filter(
                Transaction.id == transaction_id,
                Transaction.user_id == user_id,
            ).first() is not None
    except (ValueError, IndexError):
        return False
    return False


def log_activity(db: Session, user_id: int, action: str, details: str, user_name: str = "Bayi"):
    """Aktivite logu kaydet (ActivityLog modeli alan adlarına uygun)."""
    log = ActivityLog(
        user_id=user_id,
        user_name=user_name,
        action_type=action,
        entity_type="file",
        entity_id=None,
        description=details,
        details=details,
        status="success",
    )
    db.add(log)
    db.commit()


# ============================================================
# 1. POST /api/v1/files/product/{product_id}/image - Ürün Fotoğrafı Yükle
# ============================================================

@router.post(
    "/product/{product_id}/image",
    response_model=FileUploadResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Ürün Fotoğrafı Yükle",
    description="Ürüne ait fotoğraf ekle"
)
async def upload_product_image(
    product_id: int,
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Ürüne ait fotoğraf yükle

    ## Gereksinimleri:
    - Dosya türü: JPEG, PNG, WebP
    - Maksimum boyut: 10MB
    - Ürün mevcut olmalı

    ## İşlem Adımları:
    1. Ürünü bul, yoksa 404
    2. Dosya formatını doğrula (JPEG/PNG/WebP)
    3. Benzersiz dosya adı oluştur
    4. Dosyayı disk'e kaydet
    5. Ürün modelinde image_url güncelle
    6. ActivityLog'a kaydı kaydet
    7. File response döndür

    Args:
        product_id: Ürün ID
        file: Yüklenenecek resim dosyası
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        FileUploadResponse: Yükleme detayları

    Raises:
        HTTPException: 404 (Ürün bulunamadı)
                      400 (Geçersiz format, dosya çok büyük)
    """
    # 1. Ürünü bul - YALNIZCA giriş yapan bayinin ürünleri arasından
    product = db.query(Product).filter(
        Product.id == product_id,
        Product.user_id == data_owner_id(current_user),
    ).first()

    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Ürün bulunamadı (ID: {product_id})"
        )

    # 2. Dosya formatını doğrula
    validate_file(file, ALLOWED_PRODUCT_FORMATS, MAX_FILE_SIZE)

    # 3. Benzersiz dosya adı oluştur
    filename = generate_filename(file.filename, "product", product_id)

    # 4. Dosyayı kaydet (disk algoritması)
    file_path, remote_node_id, file_size = save_file_smart(file, filename, db)

    # 5. Ürün modelinde image_url güncelle
    file_url = f"/api/v1/files/{filename}"
    product.image_url = file_url
    db.add(product)
    db.commit()

    # Yerel kaydedildiyse diğer node'lara push et; peer'a gittiyse o zaten saklıyor
    if file_path:
        push_file_to_nodes(file_path)
    trigger_delta_push()

    # 6. ActivityLog + topology event
    log_activity(
        db=db,
        user_id=data_owner_id(current_user),
        action="upload",
        details=f"Ürün {product_id} için fotoğraf yüklendi: {filename}"
    )
    try:
        from app.api.topology import emit_topology_event
        sz = f"{file_size/1024:.0f}KB" if file_size < 1048576 else f"{file_size/1048576:.1f}MB"
        emit_topology_event("upload", "backend-s1", "minio-s1", f"{filename} ({sz}) yüklendi")
    except Exception:
        pass

    # 7. Response döndür
    return FileUploadResponse(
        file_id=str(uuid.uuid4()),
        filename=filename,
        original_filename=file.filename,
        file_size=file_size,
        mime_type=file.content_type,
        file_url=file_url,
        uploaded_at=datetime.now()
    )


# ============================================================
# 2. POST /api/v1/files/transaction/{transaction_id}/attachment - İşlem Belgesi Yükle
# ============================================================

@router.post(
    "/transaction/{transaction_id}/attachment",
    response_model=FileUploadResponse,
    status_code=status.HTTP_201_CREATED,
    summary="İşlem Belgesi Yükle",
    description="İşleme ait fatura, fiş veya kontrat ekle"
)
async def upload_transaction_attachment(
    transaction_id: int,
    attachment_type: str = "receipt",  # receipt, invoice, contract
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    İşleme ait belge yükle (fiş, fatura, kontrat)

    ## Gereksinimleri:
    - Dosya türü: PDF, JPEG, PNG
    - Maksimum boyut: 10MB
    - İşlem mevcut olmalı
    - attachment_type: "receipt", "invoice", "contract"

    ## İşlem Adımları:
    1. İşlemi bul, yoksa 404
    2. Dosya formatını doğrula
    3. Benzersiz dosya adı oluştur
    4. Dosyayı kaydet
    5. İşlem modelinde attachment_url güncelle
    6. ActivityLog'a kaydı kaydet
    7. Response döndür

    Args:
        transaction_id: İşlem ID
        attachment_type: Belge türü (receipt, invoice, contract)
        file: Yüklenenecek belge dosyası
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        FileUploadResponse: Yükleme detayları

    Raises:
        HTTPException: 404 (İşlem bulunamadı)
                      400 (Geçersiz format, dosya çok büyük)
    """
    # 1. İşlemi bul - YALNIZCA giriş yapan bayinin işlemleri arasından
    transaction = db.query(Transaction).filter(
        Transaction.id == transaction_id,
        Transaction.user_id == data_owner_id(current_user),
    ).first()

    if not transaction:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"İşlem bulunamadı (ID: {transaction_id})"
        )

    # 2. Dosya formatını doğrula
    validate_file(file, ALLOWED_DOCUMENT_FORMATS, MAX_FILE_SIZE)

    # 3. Benzersiz dosya adı oluştur
    filename = generate_filename(file.filename, f"transaction_{attachment_type}", transaction_id)

    # 4. Dosyayı kaydet (disk algoritması)
    file_path, remote_node_id, file_size = save_file_smart(file, filename, db)

    # 5. İşlem modelinde image_url güncelle
    file_url = f"/api/v1/files/{filename}"
    transaction.image_url = file_url
    db.add(transaction)
    db.commit()

    # Yerel kaydedildiyse diğer node'lara push et
    if file_path:
        push_file_to_nodes(file_path)
    trigger_delta_push()

    # 6. ActivityLog + topology event
    log_activity(
        db=db,
        user_id=data_owner_id(current_user),
        action="upload",
        details=f"İşlem {transaction_id} için {attachment_type} belgesi yüklendi: {filename}"
    )
    try:
        from app.api.topology import emit_topology_event
        sz = f"{file_size/1024:.0f}KB" if file_size < 1048576 else f"{file_size/1048576:.1f}MB"
        emit_topology_event("upload", "backend-s1", "minio-s1", f"{filename} ({sz}) yüklendi")
    except Exception:
        pass

    # 7. Response döndür
    return FileUploadResponse(
        file_id=str(uuid.uuid4()),
        filename=filename,
        original_filename=file.filename,
        file_size=file_size,
        mime_type=file.content_type,
        file_url=file_url,
        uploaded_at=datetime.now()
    )


# ============================================================
# 3. GET /api/v1/files/{filename} - Dosya İndir
# ============================================================

@router.get(
    "/{filename}",
    status_code=status.HTTP_200_OK,
    summary="Dosya İndir",
    description="Yüklenmiş dosyayı indir"
)
async def download_file(
    filename: str,
):
    """
    Yüklenmiş dosyayı indir (public — <img src> ile erişim için auth yok).

    ## Güvenlik:
    - Dosya adında ../ ve path separator karakterleri engellenir (Path Traversal)
    - Sadece uploads klasöründe dosya erişilebilir
    - Dosya adları rastgele uuid içerir; pratik olarak guess edilemez
      (örn: product_{id}_{uuid8}.ext)

    Args:
        filename: İndirilecek dosya adı

    Returns:
        FileResponse: Dosya içeriği

    Raises:
        HTTPException: 404 (Dosya bulunamadı)
                      400 (Geçersiz dosya adı)
    """
    # Path Traversal saldırısını engelle
    if ".." in filename or filename.startswith("/") or "/" in filename or "\\" in filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Geçersiz dosya adı"
        )

    file_path = UPLOAD_DIR / filename

    # Dosyanın uploads klasöründe olduğundan emin ol
    try:
        file_path.resolve().relative_to(UPLOAD_DIR.resolve())
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Geçersiz dosya yolu"
        )

    if file_path.exists():
        from fastapi.responses import FileResponse
        try:
            from app.api.topology import emit_topology_event
            emit_topology_event("download", "minio-s1", "backend-s1", f"{filename} indirildi")
        except Exception:
            pass
        return FileResponse(path=file_path)

    # Yerel değil → FileLocation'dan hangi node'da olduğunu bul ve proxy yap
    import httpx as _httpx
    from fastapi.responses import Response as _Response

    # DB bağlantısı lazım — download_file endpoint'ine eklenemiyor (public endpoint).
    # Yeni bir bağlantı aç.
    from app.core.database import SessionLocal
    _db = SessionLocal()
    try:
        loc = _db.query(FileLocation).filter(FileLocation.filename == filename).first()
        if loc and loc.node_id:
            node = _db.query(SyncNode).filter(SyncNode.id == loc.node_id).first()
            if node and node.url:
                try:
                    r = _httpx.get(
                        f"{node.url.rstrip('/')}/api/v1/files/{filename}",
                        timeout=15.0,
                        follow_redirects=True,
                    )
                    if r.status_code == 200:
                        return _Response(
                            content=r.content,
                            media_type=r.headers.get("content-type", "application/octet-stream"),
                            headers={"X-Served-From": node.name},
                        )
                except Exception as e:
                    print(f"[FILES] Proxy hatası ({node.name}): {e}")

        # Peer'lardan da dene (FileLocation kaydı yoksa)
        if not loc:
            nodes = _db.query(SyncNode).filter(
                SyncNode.is_self == False,
                SyncNode.is_active == True,
                SyncNode.url.isnot(None),
            ).all()
            for node in nodes:
                try:
                    r = _httpx.get(
                        f"{node.url.rstrip('/')}/api/v1/files/{filename}",
                        timeout=8.0,
                        follow_redirects=True,
                    )
                    if r.status_code == 200:
                        # Konumu öğrendik, bir sonraki istek için kaydedelim
                        _record_file_location(_db, filename, node.id, len(r.content))
                        return _Response(
                            content=r.content,
                            media_type=r.headers.get("content-type", "application/octet-stream"),
                            headers={"X-Served-From": node.name},
                        )
                except Exception:
                    pass
    finally:
        _db.close()

    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail=f"Dosya bulunamadı: {filename}"
    )


# ============================================================
# 4. DELETE /api/v1/files/{filename} - Dosya Sil
# ============================================================

@router.delete(
    "/{filename}",
    response_model=FileDeleteResponse,
    status_code=status.HTTP_200_OK,
    summary="Dosya Sil",
    description="Yüklenmiş dosyayı sil"
)
async def delete_file(
    filename: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Dosyayı sil ve ilgili modelleri güncelle

    ## İşlem Adımları:
    1. Dosya adını doğrula
    2. Dosya path'ini oluştur
    3. Dosyayı disk'ten sil
    4. İlgili ürün/işlem modelinden URL'i temizle
    5. ActivityLog'a kaydı kaydet
    6. Silme onayı döndür

    Args:
        filename: Silinecek dosya adı
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        FileDeleteResponse: Silme onayı

    Raises:
        HTTPException: 404 (Dosya bulunamadı)
                      400 (Geçersiz dosya adı)
    """
    # Path Traversal saldırısını engelle
    if ".." in filename or filename.startswith("/"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Geçersiz dosya adı"
        )

    file_path = UPLOAD_DIR / filename

    if not file_path.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Dosya bulunamadı: {filename}"
        )

    # Çoklu kiracılık sahiplik kontrolü
    if not _user_owns_file(db, filename, data_owner_id(current_user)):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Dosya bulunamadı: {filename}"
        )

    # Dosya adından entity türünü ve ID'yi çıkar
    # Format: product_{id}_{uuid}.ext  veya  transaction_{type}_{id}_{uuid}.ext
    parts = filename.split("_")
    entity_type = parts[0] if parts else None

    # İlgili modeli güncelle (sahiplik yukarıda doğrulandı)
    if entity_type == "product" and len(parts) >= 2:
        try:
            product_id = int(parts[1])
            product = db.query(Product).filter(
                Product.id == product_id,
                Product.user_id == data_owner_id(current_user),
            ).first()
            if product:
                product.image_url = None
                db.add(product)
                db.commit()
        except (ValueError, IndexError):
            pass

    elif entity_type == "transaction" and len(parts) >= 3:
        # Format: transaction_{attachment_type}_{id}_{uuid}.ext
        try:
            transaction_id = int(parts[2])
            transaction = db.query(Transaction).filter(
                Transaction.id == transaction_id,
                Transaction.user_id == data_owner_id(current_user),
            ).first()
            if transaction:
                transaction.image_url = None
                db.add(transaction)
                db.commit()
        except (ValueError, IndexError):
            pass

    # Dosyayı sil
    file_path.unlink()

    # ActivityLog'a kaydet
    log_activity(
        db=db,
        user_id=data_owner_id(current_user),
        action="delete",
        details=f"Dosya silindi: {filename}"
    )

    return FileDeleteResponse(
        file_id=str(uuid.uuid4()),
        filename=filename
    )
