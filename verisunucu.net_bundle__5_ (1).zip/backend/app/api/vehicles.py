from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import Optional, List
from pydantic import BaseModel
from datetime import datetime

from app.core.database import get_db
from app.models import User, Product, Transaction
from app.models.vehicle import Vehicle, VehicleItem, VehicleAssignment, VehicleLog
from app.utils.auth import get_current_user
from app.services.sync_service import record_deletion, trigger_delta_push

router = APIRouter(prefix="/vehicles", tags=["Vehicles"])

ROLES = ("driver", "helper", "warehouse")
ROLE_LABELS = {"driver": "Şoför", "helper": "Yardımcı", "warehouse": "Depo Sorumlusu"}


# ── helpers ───────────────────────────────────────────────────────────────────

def _owner_id(user: User) -> int:
    return int(user.parent_user_id) if user.parent_user_id else user.id


def _is_patron(user: User) -> bool:
    return not bool(user.parent_user_id)


def _actor_name(user: User) -> str:
    return user.full_name or user.email or f"Kullanıcı#{user.id}"


def _require_patron(user: User):
    if not _is_patron(user):
        raise HTTPException(403, "Bu işlem için patron yetkisi gereklidir.")


def _vehicle_or_404(db: Session, vehicle_id: int, owner_id: int) -> Vehicle:
    v = db.query(Vehicle).filter(Vehicle.id == vehicle_id, Vehicle.user_id == owner_id).first()
    if not v:
        raise HTTPException(404, "Araç bulunamadı.")
    return v


def _check_access(db: Session, vehicle_id: int, current_user: User) -> Vehicle:
    """Patron: tüm araçlara erişir. Çalışan: sadece atandığı araçlara."""
    owner_id = _owner_id(current_user)
    v = db.query(Vehicle).filter(Vehicle.id == vehicle_id, Vehicle.user_id == owner_id).first()
    if not v:
        raise HTTPException(404, "Araç bulunamadı.")
    if not _is_patron(current_user):
        asgn = db.query(VehicleAssignment).filter(
            VehicleAssignment.vehicle_id == vehicle_id,
            VehicleAssignment.user_id == current_user.id,
        ).first()
        if not asgn:
            raise HTTPException(403, "Bu araca erişim yetkiniz yok.")
    return v


def _log(db: Session, vehicle: Vehicle, user: User, action: str, details: str = None):
    vehicle.updated_at = datetime.now()
    entry = VehicleLog(
        vehicle_id=vehicle.id,
        user_id=user.id,
        user_name=_actor_name(user),
        action=action,
        details=details,
        vehicle_status=vehicle.status,
    )
    db.add(entry)


def _assignments_out(asgns: list) -> list:
    return [
        {
            "id": a.id,
            "user_id": a.user_id,
            "user_name": a.user_name,
            "role": a.role,
            "role_label": ROLE_LABELS.get(a.role, a.role),
            "assigned_at": a.assigned_at.isoformat() if a.assigned_at else None,
        }
        for a in asgns
    ]


def _vehicle_out(v: Vehicle, items: list, asgns: list) -> dict:
    return {
        "id": v.id,
        "plate": v.plate,
        "nickname": v.nickname,
        "status": v.status,
        "assignments": _assignments_out(asgns),
        "notes": v.notes,
        "total_quantity": sum(i.quantity for i in items),
        "distinct_products": len([i for i in items if i.quantity > 0]),
        "created_at": v.created_at.isoformat() if v.created_at else None,
        "updated_at": v.updated_at.isoformat() if v.updated_at else None,
    }


# ── schemas ───────────────────────────────────────────────────────────────────

class VehicleCreate(BaseModel):
    plate: str
    nickname: Optional[str] = None
    notes: Optional[str] = None


class VehicleUpdate(BaseModel):
    plate: Optional[str] = None
    nickname: Optional[str] = None
    status: Optional[str] = None
    notes: Optional[str] = None


class AssignmentCreate(BaseModel):
    user_id: int
    role: str = "driver"


class LoadItem(BaseModel):
    product_id: int
    quantity: int


class LoadRequest(BaseModel):
    items: List[LoadItem]


class UnloadItem(BaseModel):
    product_id: int
    quantity: int


class UnloadRequest(BaseModel):
    items: List[UnloadItem]
    destination: str = "depot"   # depot | sold
    customer_name: Optional[str] = None


# ── endpoints ─────────────────────────────────────────────────────────────────

@router.get("/employees/list")
async def list_employees(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    owner_id = _owner_id(current_user)
    employees = db.query(User).filter(User.parent_user_id == owner_id).all()
    return [
        {"id": e.id, "full_name": e.full_name or e.email, "email": e.email}
        for e in employees
    ]


@router.get("")
async def list_vehicles(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    owner_id = _owner_id(current_user)
    if _is_patron(current_user):
        vehicles = db.query(Vehicle).filter(Vehicle.user_id == owner_id).order_by(Vehicle.created_at.desc()).all()
    else:
        vehicle_ids = [
            a.vehicle_id for a in
            db.query(VehicleAssignment).filter(VehicleAssignment.user_id == current_user.id).all()
        ]
        if not vehicle_ids:
            return []
        vehicles = db.query(Vehicle).filter(
            Vehicle.id.in_(vehicle_ids),
            Vehicle.user_id == owner_id,
        ).order_by(Vehicle.created_at.desc()).all()

    result = []
    for v in vehicles:
        items = db.query(VehicleItem).filter(VehicleItem.vehicle_id == v.id, VehicleItem.quantity > 0).all()
        asgns = db.query(VehicleAssignment).filter(VehicleAssignment.vehicle_id == v.id).all()
        result.append(_vehicle_out(v, items, asgns))
    return result


@router.post("", status_code=201)
async def create_vehicle(
    body: VehicleCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_patron(current_user)
    owner_id = _owner_id(current_user)
    v = Vehicle(
        user_id=owner_id,
        plate=body.plate.upper().strip(),
        nickname=body.nickname,
        notes=body.notes,
        status="parked",
    )
    db.add(v)
    db.flush()
    _log(db, v, current_user, "created", f"Araç oluşturuldu: {v.plate}")
    db.commit()
    db.refresh(v)
    return _vehicle_out(v, [], [])


@router.put("/{vehicle_id}")
async def update_vehicle(
    vehicle_id: int,
    body: VehicleUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    v = _check_access(db, vehicle_id, current_user)
    changes = []
    status_labels = {"parked": "Parkta", "on_tour": "Turda"}

    if body.plate is not None and _is_patron(current_user):
        v.plate = body.plate.upper().strip()
        changes.append(f"Plaka → {v.plate}")
    if body.nickname is not None and _is_patron(current_user):
        v.nickname = body.nickname
        changes.append(f"Ad → {v.nickname or '—'}")
    if body.status is not None:
        if body.status not in ("parked", "on_tour"):
            raise HTTPException(400, "Geçersiz durum. Geçerli: parked, on_tour")
        old = v.status
        v.status = body.status
        changes.append(f"Durum: {status_labels.get(old, old)} → {status_labels.get(v.status, v.status)}")
    if body.notes is not None and _is_patron(current_user):
        v.notes = body.notes
        changes.append("Notlar güncellendi")

    v.updated_at = datetime.now()
    if changes:
        _log(db, v, current_user, "updated", "; ".join(changes))
    db.commit()
    db.refresh(v)
    items = db.query(VehicleItem).filter(VehicleItem.vehicle_id == v.id, VehicleItem.quantity > 0).all()
    asgns = db.query(VehicleAssignment).filter(VehicleAssignment.vehicle_id == v.id).all()
    return _vehicle_out(v, items, asgns)


@router.delete("/{vehicle_id}", status_code=204)
async def delete_vehicle(
    vehicle_id: int,
    force: bool = Query(False),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_patron(current_user)
    owner_id = _owner_id(current_user)
    v = _vehicle_or_404(db, vehicle_id, owner_id)
    if not force:
        total = db.query(VehicleItem).filter(
            VehicleItem.vehicle_id == vehicle_id, VehicleItem.quantity > 0
        ).count()
        if total > 0:
            raise HTTPException(400, "Araçta ürün var. Önce boşaltın veya force=true ile silin.")
    db.query(VehicleLog).filter(VehicleLog.vehicle_id == vehicle_id).delete()
    db.query(VehicleAssignment).filter(VehicleAssignment.vehicle_id == vehicle_id).delete()
    db.query(VehicleItem).filter(VehicleItem.vehicle_id == vehicle_id).delete()
    record_deletion(db, "vehicles", v.id)
    db.delete(v)
    db.commit()
    trigger_delta_push()


@router.get("/{vehicle_id}/items")
async def get_vehicle_items(
    vehicle_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _check_access(db, vehicle_id, current_user)
    items = db.query(VehicleItem).filter(
        VehicleItem.vehicle_id == vehicle_id,
        VehicleItem.quantity > 0,
    ).all()
    return [
        {
            "id": i.id,
            "product_id": i.product_id,
            "product_name": i.product_name,
            "unit_price": i.unit_price,
            "currency": i.currency,
            "quantity": i.quantity,
            "loaded_at": i.loaded_at.isoformat() if i.loaded_at else None,
        }
        for i in items
    ]


@router.post("/{vehicle_id}/load")
async def load_vehicle(
    vehicle_id: int,
    body: LoadRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    owner_id = _owner_id(current_user)
    v = _check_access(db, vehicle_id, current_user)
    if not body.items:
        raise HTTPException(400, "En az bir ürün belirtin.")

    log_parts = []
    for item in body.items:
        if item.quantity <= 0:
            continue
        product = db.query(Product).filter(
            Product.id == item.product_id, Product.user_id == owner_id
        ).first()
        if not product:
            raise HTTPException(400, f"Ürün bulunamadı (ID: {item.product_id})")
        upd = db.execute(
            text(
                "UPDATE products SET quantity = quantity - :qty "
                "WHERE id = :id AND user_id = :uid AND quantity >= :qty"
            ),
            {"qty": item.quantity, "id": item.product_id, "uid": owner_id},
        )
        if upd.rowcount == 0:
            raise HTTPException(
                400,
                f"Yetersiz stok: {product.name} (İstenen: {item.quantity})"
            )
        db.expire(product)
        vi = db.query(VehicleItem).filter(
            VehicleItem.vehicle_id == vehicle_id,
            VehicleItem.product_id == item.product_id,
        ).first()
        if vi:
            vi.quantity += item.quantity
            vi.unit_price = product.price
            vi.updated_at = datetime.now()
        else:
            vi = VehicleItem(
                vehicle_id=vehicle_id,
                product_id=item.product_id,
                product_name=product.name,
                unit_price=product.price,
                currency=product.currency or "TRY",
                quantity=item.quantity,
            )
            db.add(vi)
        log_parts.append(f"{item.quantity}x {product.name}")

    if log_parts:
        actor = _actor_name(current_user)
        _log(db, v, current_user, "load",
             f"{actor} yükledi: {', '.join(log_parts)}")
    db.commit()
    return {"loaded": len(log_parts)}


@router.post("/{vehicle_id}/unload")
async def unload_vehicle(
    vehicle_id: int,
    body: UnloadRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    owner_id = _owner_id(current_user)
    v = _check_access(db, vehicle_id, current_user)

    if body.destination not in ("depot", "sold"):
        raise HTTPException(400, "destination: depot veya sold olmalı.")
    if body.destination == "sold" and not (body.customer_name or "").strip():
        raise HTTPException(400, "Satış için müşteri adı gereklidir.")
    if not body.items:
        raise HTTPException(400, "En az bir ürün belirtin.")

    log_parts = []
    total_amount = 0.0
    currency_used = "TRY"

    for item in body.items:
        if item.quantity <= 0:
            continue
        vi = db.query(VehicleItem).filter(
            VehicleItem.vehicle_id == vehicle_id,
            VehicleItem.product_id == item.product_id,
        ).first()
        if not vi or vi.quantity < item.quantity:
            have = vi.quantity if vi else 0
            name = vi.product_name if vi else f"ID:{item.product_id}"
            raise HTTPException(400, f"Araçta yeterli ürün yok: {name} (Araçta: {have}, İstenen: {item.quantity})")

        db.execute(
            text(
                "UPDATE vehicle_items SET quantity = quantity - :qty "
                "WHERE vehicle_id = :vid AND product_id = :pid AND quantity >= :qty"
            ),
            {"qty": item.quantity, "vid": vehicle_id, "pid": item.product_id},
        )
        db.expire(vi)

        if body.destination == "depot":
            db.execute(
                text(
                    "UPDATE products SET quantity = quantity + :qty "
                    "WHERE id = :id AND user_id = :uid"
                ),
                {"qty": item.quantity, "id": item.product_id, "uid": owner_id},
            )

        total_amount += vi.unit_price * item.quantity
        currency_used = vi.currency or "TRY"
        log_parts.append(f"{item.quantity}x {vi.product_name}")

    if body.destination == "sold" and log_parts:
        customer = (body.customer_name or "").strip()
        actor = _actor_name(current_user)
        new_tx = Transaction(
            user_id=owner_id,
            transaction_type="satış",
            customer_name=customer,
            amount=total_amount,
            currency=currency_used,
            kdv_rate=0,
            description=f"Araç satışı [{v.plate}]: " + ", ".join(log_parts),
            vehicle_id=vehicle_id,
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )
        db.add(new_tx)
        _log(db, v, current_user, "unload_sold",
             f"{actor} sattı → Müşteri: {customer} | {', '.join(log_parts)} | Toplam: ₺{total_amount:,.2f}")
    elif log_parts:
        actor = _actor_name(current_user)
        _log(db, v, current_user, "unload_depot",
             f"{actor} iade etti: {', '.join(log_parts)}")

    db.commit()
    return {"unloaded": len(log_parts), "destination": body.destination, "total_amount": total_amount}


@router.get("/{vehicle_id}/assignments")
async def get_assignments(
    vehicle_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _check_access(db, vehicle_id, current_user)
    asgns = db.query(VehicleAssignment).filter(VehicleAssignment.vehicle_id == vehicle_id).all()
    return _assignments_out(asgns)


@router.post("/{vehicle_id}/assignments", status_code=201)
async def add_assignment(
    vehicle_id: int,
    body: AssignmentCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_patron(current_user)
    owner_id = _owner_id(current_user)
    v = _vehicle_or_404(db, vehicle_id, owner_id)

    if body.role not in ROLES:
        raise HTTPException(400, f"Geçersiz rol. Geçerli: {', '.join(ROLES)}")

    emp = db.query(User).filter(
        User.id == body.user_id, User.parent_user_id == owner_id
    ).first()
    if not emp:
        raise HTTPException(404, "Çalışan bulunamadı.")

    existing = db.query(VehicleAssignment).filter(
        VehicleAssignment.vehicle_id == vehicle_id,
        VehicleAssignment.user_id == body.user_id,
    ).first()
    if existing:
        old_role = existing.role
        existing.role = body.role
        _log(db, v, current_user, "assignment_update",
             f"{emp.full_name or emp.email}: {ROLE_LABELS.get(old_role, old_role)} → {ROLE_LABELS.get(body.role, body.role)}")
        db.commit()
        return _assignments_out([existing])[0]

    asgn = VehicleAssignment(
        vehicle_id=vehicle_id,
        user_id=body.user_id,
        user_name=emp.full_name or emp.email,
        role=body.role,
        assigned_by_user_id=current_user.id,
    )
    db.add(asgn)
    _log(db, v, current_user, "assignment_add",
         f"Çalışan atandı: {emp.full_name or emp.email} ({ROLE_LABELS.get(body.role, body.role)})")
    db.commit()
    db.refresh(asgn)
    return _assignments_out([asgn])[0]


@router.delete("/{vehicle_id}/assignments/{assignment_id}", status_code=204)
async def remove_assignment(
    vehicle_id: int,
    assignment_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_patron(current_user)
    owner_id = _owner_id(current_user)
    v = _vehicle_or_404(db, vehicle_id, owner_id)
    asgn = db.query(VehicleAssignment).filter(
        VehicleAssignment.id == assignment_id,
        VehicleAssignment.vehicle_id == vehicle_id,
    ).first()
    if not asgn:
        raise HTTPException(404, "Atama bulunamadı.")
    _log(db, v, current_user, "assignment_remove",
         f"Çalışan kaldırıldı: {asgn.user_name} ({ROLE_LABELS.get(asgn.role, asgn.role)})")
    record_deletion(db, "vehicle_assignments", asgn.id)
    db.delete(asgn)
    db.commit()
    trigger_delta_push()


@router.get("/{vehicle_id}/logs")
async def get_logs(
    vehicle_id: int,
    limit: int = Query(100, ge=1, le=500),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _check_access(db, vehicle_id, current_user)
    logs = db.query(VehicleLog).filter(
        VehicleLog.vehicle_id == vehicle_id
    ).order_by(VehicleLog.created_at.desc()).limit(limit).all()
    return [
        {
            "id": l.id,
            "user_name": l.user_name,
            "action": l.action,
            "details": l.details,
            "vehicle_status": l.vehicle_status,
            "created_at": l.created_at.isoformat() if l.created_at else None,
        }
        for l in logs
    ]
