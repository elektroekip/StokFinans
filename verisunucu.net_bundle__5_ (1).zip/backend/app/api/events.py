import threading
import time

from fastapi import APIRouter, Depends
from app.utils.auth import get_current_user

router = APIRouter(prefix="/events", tags=["Events"])

_last_ts: float = 0.0
_lock = threading.Lock()


def notify() -> None:
    global _last_ts
    with _lock:
        _last_ts = time.time()


@router.get("/latest")
async def latest_change(_=Depends(get_current_user)):
    with _lock:
        return {"ts": _last_ts}
