"""
Multi-Node Sync API — peer-auth ile çoklu sunucu senkronizasyonu + süperadmin yönetim endpoint'leri.

Public peer endpoint'leri (Authorization: Bearer <self_node.our_token>):
  - POST /sync/ping          → heartbeat, caller node kaydını güncelle
  - GET  /sync/sysinfo       → bu sunucunun CPU/RAM/disk/OS bilgileri
  - GET  /sync/snapshot      → tüm DB+dosyalar (zip)
  - POST /sync/import        → snapshot kabul et, MERGE stratejisiyle uygula

Süperadmin endpoint'leri (cookie/JWT auth):
  - GET    /superadmin/sync/self                → bu sunucunun bilgileri + our_token
  - GET    /superadmin/sync/nodes               → uzak node listesi
  - POST   /superadmin/sync/nodes               → yeni node ekle
  - PUT    /superadmin/sync/nodes/{id}          → node güncelle
  - DELETE /superadmin/sync/nodes/{id}          → node sil
  - POST   /superadmin/sync/nodes/{id}/test     → belirli node'a heartbeat
  - POST   /superadmin/sync/nodes/{id}/pull     → belirli node'dan çek
  - POST   /superadmin/sync/nodes/{id}/push     → belirli node'a gönder
  - POST   /superadmin/sync/nodes/push-all      → tüm aktif node'lara gönder
  - GET    /superadmin/sync/logs                → sync log listesi
  - POST   /superadmin/sync/regenerate-token    → our_token yenile
"""
from __future__ import annotations

import hmac
import secrets
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional

from pathlib import Path
from fastapi import APIRouter, Depends, HTTPException, Header, Query, Request, Response, UploadFile, File
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.utils.auth import get_current_super_admin
from app.models.sync_node import SyncNode
from app.models.sync_log import SyncLog
from app.services import sync_service
from app.utils.crypto import encrypt_secret


# ============================================================
# 1) Public peer-auth router
# ============================================================
peer_router = APIRouter(prefix="/sync", tags=["Sync (Peer)"])


def _get_self_node(db: Session) -> SyncNode:
    return sync_service.get_self_node(db)


def _peer_auth(authorization: Optional[str], db: Session) -> SyncNode:
    """
    Authorization: Bearer <token> header'ını doğrular.
    Token, self SyncNode'un our_token'ı ile eşleşmeli.
    Sabit zamanlı karşılaştırma (timing attack'a karşı).
    """
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Eksik veya hatalı Authorization header")
    token = authorization.split(None, 1)[1].strip()
    self_node = _get_self_node(db)
    if not self_node.our_token:
        raise HTTPException(status_code=401, detail="Sunucuda sync yapılandırılmamış")
    if not hmac.compare_digest(token.encode("utf-8"), self_node.our_token.encode("utf-8")):
        raise HTTPException(status_code=401, detail="Geçersiz peer token")
    return self_node


@peer_router.post("/ping")
async def sync_ping(
    authorization: Optional[str] = Header(default=None),
    x_node_name: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
):
    """
    Remote node'lardan heartbeat alır.
    İstek yapan node'un last_heartbeat_at alanını günceller (X-Node-Name header'ına göre).
    """
    self_node = _peer_auth(authorization, db)

    # Çağıran node'u bulmaya çalış (X-Node-Name header ile)
    caller_name = x_node_name or "bilinmiyor"
    if x_node_name:
        caller = db.query(SyncNode).filter(
            SyncNode.is_self == False,  # noqa: E712
            SyncNode.name == x_node_name,
        ).first()
        if caller:
            caller.last_heartbeat_at = datetime.now(timezone.utc)
            db.commit()

    # Gelen heartbeat'i de logla (topoloji diyagramında iki yönlü ok için)
    try:
        log = SyncLog(
            from_node_name=caller_name,
            to_node_name=self_node.name,
            event_type="HEARTBEAT",
            records_total=None,
            duration_ms=None,
            error=None,
            details=None,
        )
        db.add(log)
        db.commit()
    except Exception:
        db.rollback()

    return {
        "ok": True,
        "node_name": self_node.name,
        "ts": datetime.now(timezone.utc).isoformat(),
    }


@peer_router.get("/sysinfo")
async def sync_sysinfo(
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
):
    """Bu sunucunun sistem bilgilerini (CPU/RAM/Disk/OS) döndürür."""
    _peer_auth(authorization, db)
    return sync_service.get_local_sysinfo()


@peer_router.get("/snapshot")
async def sync_get_snapshot(
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
):
    """Tüm veritabanı + dosyaları ZIP olarak dışa aktarır."""
    _peer_auth(authorization, db)
    data = sync_service.export_full_snapshot(db)
    return Response(
        content=data,
        media_type="application/zip",
        headers={
            "Content-Length": str(len(data)),
            "Content-Disposition": 'attachment; filename="snapshot.zip"',
        },
    )


@peer_router.get("/delta")
async def sync_get_delta(
    since: Optional[float] = Query(None, description="Unix timestamp; bu tarihten bu yana değişiklikler"),
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
):
    """
    Belirli tarihten bu yana değişen satırları ve silinen kayıtları döndürür.
    Karşı node'un pull etmesi için kullanılır (S1 ← S2 yönü).
    """
    _peer_auth(authorization, db)
    if since is not None:
        since_dt = datetime.fromtimestamp(since, tz=timezone.utc)
    else:
        since_dt = datetime.now(timezone.utc) - timedelta(hours=24)
    delta = sync_service.export_delta(db, since_dt)
    return {"ok": True, "delta": delta, "since": since_dt.isoformat()}


SYNC_MAX_BODY_BYTES = 2 * 1024 * 1024 * 1024  # 2 GiB üst sınır


@peer_router.post("/import")
async def sync_post_import(
    request: Request,
    authorization: Optional[str] = Header(default=None),
    x_node_name: Optional[str] = Header(default=None),
    x_node_url: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
):
    """Remote node'dan snapshot alır; MERGE stratejisiyle (daha yeni timestamp kazanır) uygular."""
    _peer_auth(authorization, db)

    chunks: list = []
    total = 0
    async for chunk in request.stream():
        if not chunk:
            continue
        total += len(chunk)
        if total > SYNC_MAX_BODY_BYTES:
            raise HTTPException(status_code=413, detail="Snapshot boyutu çok büyük")
        chunks.append(chunk)

    body = b"".join(chunks)
    if not body or len(body) < 32:
        raise HTTPException(status_code=400, detail="Boş veya geçersiz snapshot")

    from_name = x_node_name or "bilinmiyor"
    from_url = x_node_url or ""

    try:
        stats = sync_service.import_merge_snapshot(db, body, from_name, from_url)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Import hatası: {e}")

    return {"ok": True, "stats": stats}


@peer_router.post("/push-delta")
async def sync_push_delta(
    request: Request,
    authorization: Optional[str] = Header(default=None),
    x_node_name: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
):
    """
    Uzak node'dan delta (sadece değişen satırlar) alır; MERGE stratejisiyle uygular.
    Tam snapshot yerine küçük ve hızlı — değişen satırlar anlık gönderilir.
    """
    _peer_auth(authorization, db)
    try:
        body = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Geçersiz JSON body")

    from_name = body.get("from_node") or x_node_name or "bilinmiyor"
    tables: Dict[str, Any] = body.get("tables", {})
    if not tables:
        return {"ok": True, "stats": {}, "message": "Delta boş — değişen veri yok"}

    try:
        stats = sync_service.apply_delta(db, tables, from_name)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Delta import hatası: {e}")

    return {"ok": True, "stats": stats}


@peer_router.post("/push-file")
async def sync_push_file(
    authorization: Optional[str] = Header(default=None),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """
    Uzak node'dan tek bir upload dosyası alır ve uploads/ klasörüne kaydeder.
    Dosya zaten varsa üzerine yazar (idempotent).
    """
    _peer_auth(authorization, db)

    original_name = file.filename or ""
    # Güvenlik: path traversal önlemi — sadece dosya adı, dizin bileşeni yok
    safe_name = Path(original_name).name
    if not safe_name:
        raise HTTPException(status_code=400, detail="Geçersiz dosya adı")

    uploads_dir = Path("uploads")
    uploads_dir.mkdir(exist_ok=True)
    dest = uploads_dir / safe_name

    content = await file.read()
    dest.write_bytes(content)
    return {"ok": True, "filename": safe_name, "size": len(content)}


class RegisterPeerIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    url: str = Field(..., min_length=8, max_length=500)
    our_token: str = Field(..., min_length=8, max_length=500, description="Çağıran sunucunun our_token'ı (biz bunu peer_token olarak saklarız)")
    display_order: int = Field(default=2, ge=1)


@peer_router.get("/bundle")
async def sync_get_bundle(
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
):
    """Bu sunucunun uygulama kaynak dosyalarını ZIP olarak döndürür."""
    _peer_auth(authorization, db)
    from app.services import deploy_service
    data = deploy_service.create_bundle_zip()
    self_node = sync_service.get_self_node(db)
    fname = f"{self_node.name.lower().replace(' ', '_')}_bundle.zip"
    return Response(
        content=data,
        media_type="application/zip",
        headers={
            "Content-Length": str(len(data)),
            "Content-Disposition": f'attachment; filename="{fname}"',
        },
    )


@peer_router.post("/deploy")
async def sync_post_deploy(
    request: Request,
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
):
    """ZIP bundle alır; arka planda deploy başlatır."""
    _peer_auth(authorization, db)
    chunks: list = []
    total = 0
    async for chunk in request.stream():
        if not chunk:
            continue
        total += len(chunk)
        if total > 2 * 1024 * 1024 * 1024:
            raise HTTPException(status_code=413, detail="ZIP boyutu çok büyük (max 2 GiB)")
        chunks.append(chunk)
    zip_bytes = b"".join(chunks)
    if len(zip_bytes) < 100:
        raise HTTPException(status_code=400, detail="Geçersiz veya boş ZIP")
    from app.services import deploy_service
    deploy_service.start_deploy(zip_bytes)
    return {"ok": True, "message": "Deploy başlatıldı"}


@peer_router.get("/deploy/status")
async def sync_get_deploy_status(
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
):
    """Mevcut deploy durumunu döndürür."""
    _peer_auth(authorization, db)
    from app.services import deploy_service
    return deploy_service.get_deploy_status()


@peer_router.post("/register-peer")
async def sync_register_peer(
    payload: RegisterPeerIn,
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
):
    """
    Uzak sunucu kendini bu sunucuya kaydeder.
    Çağıran sunucu, bu sunucuya bağlanmak için peer_token göndermeli (bizim our_token'ımız ile auth edilir).
    Biz de çağıranın URL + our_token'ını saklarız ki ona bağlanabilelim.
    """
    _peer_auth(authorization, db)

    url_clean = payload.url.rstrip("/")
    # Aynı URL ile kayıtlı node var mı? Güncelle.
    existing = db.query(SyncNode).filter(
        SyncNode.is_self == False,  # noqa: E712
        SyncNode.url == url_clean,
    ).first()
    if existing:
        existing.name = payload.name
        existing.peer_token_encrypted = encrypt_secret(payload.our_token)
        existing.display_order = payload.display_order
        existing.is_active = True
        db.commit()
    else:
        node = SyncNode(
            name=payload.name,
            url=url_clean,
            peer_token_encrypted=encrypt_secret(payload.our_token),
            display_order=payload.display_order,
            is_self=False,
            is_active=True,
        )
        db.add(node)
        db.commit()

    self_node = sync_service.get_self_node(db)
    return {"ok": True, "registered_as": payload.name, "my_name": self_node.name}


# ============================================================
# 2) Süperadmin yönetim router
# ============================================================
admin_router = APIRouter(
    prefix="/superadmin/sync",
    tags=["SuperAdmin (Sync)"],
    dependencies=[Depends(get_current_super_admin)],
)


# ── Pydantic şemaları ─────────────────────────────────────────

class SelfInfoOut(BaseModel):
    name: str
    our_token: str
    sys_cpu_count: Optional[int]
    sys_ram_gb: Optional[float]
    sys_disk_total_gb: Optional[float]
    sys_disk_free_gb: Optional[float]
    sys_os: Optional[str]

    class Config:
        from_attributes = True


class RemoteNodeOut(BaseModel):
    id: int
    name: str
    display_order: int
    url: Optional[str]
    is_active: bool
    last_heartbeat_at: Optional[datetime]
    last_sync_at: Optional[datetime]
    last_pull_at: Optional[datetime]
    last_error: Optional[str]
    sys_cpu_count: Optional[int]
    sys_ram_gb: Optional[float]
    sys_disk_total_gb: Optional[float]
    sys_disk_free_gb: Optional[float]
    sys_os: Optional[str]

    class Config:
        from_attributes = True


class AddNodeIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    url: str = Field(..., min_length=8, max_length=500)
    peer_token: str = Field(..., min_length=8, max_length=500, description="Bu node'un karşı tarafa gönderirken kullanacağı token")
    display_order: int = Field(default=2, ge=1)


class UpdateNodeIn(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=100)
    url: Optional[str] = Field(default=None, min_length=8, max_length=500)
    peer_token: Optional[str] = Field(default=None, min_length=8, max_length=500)
    display_order: Optional[int] = Field(default=None, ge=1)
    is_active: Optional[bool] = None


class SyncLogOut(BaseModel):
    id: int
    from_node_name: str
    to_node_name: str
    event_type: str
    records_total: Optional[int]
    duration_ms: Optional[int]
    error: Optional[str]
    details: Optional[Any]
    created_at: datetime

    class Config:
        from_attributes = True


# ── Yardımcı ─────────────────────────────────────────────────

def _node_to_self_info(node: SyncNode) -> SelfInfoOut:
    return SelfInfoOut(
        name=node.name,
        our_token=node.our_token,
        sys_cpu_count=node.sys_cpu_count,
        sys_ram_gb=node.sys_ram_gb,
        sys_disk_total_gb=node.sys_disk_total_gb,
        sys_disk_free_gb=node.sys_disk_free_gb,
        sys_os=node.sys_os,
    )


# ── Endpoint'ler ─────────────────────────────────────────────

@admin_router.get("/self", response_model=SelfInfoOut)
async def sync_self(db: Session = Depends(get_db)):
    """Bu sunucunun adı, our_token ve sistem specs'ini döndürür."""
    self_node = sync_service.get_self_node(db)
    info = sync_service.get_local_sysinfo()
    self_node.sys_cpu_count = info.get("cpu_count")
    self_node.sys_ram_gb = info.get("ram_gb")
    self_node.sys_disk_total_gb = info.get("disk_total_gb")
    self_node.sys_disk_free_gb = info.get("disk_free_gb")
    self_node.sys_os = info.get("os")
    db.commit()
    db.refresh(self_node)
    return _node_to_self_info(self_node)


class RenameSelfIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)


@admin_router.put("/self", response_model=SelfInfoOut)
async def sync_rename_self(payload: RenameSelfIn, db: Session = Depends(get_db)):
    """Bu sunucunun adını değiştirir."""
    self_node = sync_service.get_self_node(db)
    self_node.name = payload.name.strip()
    db.commit()
    db.refresh(self_node)
    return _node_to_self_info(self_node)


@admin_router.get("/nodes", response_model=List[RemoteNodeOut])
async def sync_list_nodes(db: Session = Depends(get_db)):
    """Uzak node listesini döndürür (is_self=False)."""
    nodes = (
        db.query(SyncNode)
        .filter(SyncNode.is_self == False)  # noqa: E712
        .order_by(SyncNode.display_order)
        .all()
    )
    return nodes


@admin_router.post("/nodes", response_model=RemoteNodeOut, status_code=201)
async def sync_add_node(payload: AddNodeIn, db: Session = Depends(get_db)):
    """
    Yeni uzak node ekle.
    Ekledikten sonra karşı sunucuya bu sunucunun bilgilerini otomatik gönderir
    (çift yönlü bağlantı — karşı sunucu da bizi sync_nodes listesine ekler).
    """
    if len(payload.peer_token) < 8:
        raise HTTPException(status_code=400, detail="peer_token en az 8 karakter olmalı")
    node = SyncNode(
        name=payload.name,
        url=payload.url.rstrip("/"),
        peer_token_encrypted=encrypt_secret(payload.peer_token),
        display_order=payload.display_order,
        is_self=False,
        is_active=True,
    )
    db.add(node)
    db.commit()
    db.refresh(node)

    # Karşı sunucuya bu sunucunun bilgilerini otomatik gönder (çift yönlü kayıt)
    self_node = sync_service.get_self_node(db)
    auto_register_ok, auto_register_msg = sync_service.register_self_on_peer(db, node, self_node)
    if not auto_register_ok:
        # Hata node kaydını engellemez; kullanıcı uyarılır
        node.last_error = f"[otomatik kayıt] {auto_register_msg}"
        db.commit()

    return node


@admin_router.put("/nodes/{node_id}", response_model=RemoteNodeOut)
async def sync_update_node(node_id: int, payload: UpdateNodeIn, db: Session = Depends(get_db)):
    """Uzak node'u güncelle."""
    node = db.query(SyncNode).filter(SyncNode.id == node_id, SyncNode.is_self == False).first()  # noqa: E712
    if not node:
        raise HTTPException(status_code=404, detail="Node bulunamadı")
    if payload.name is not None:
        node.name = payload.name
    if payload.url is not None:
        node.url = payload.url.rstrip("/")
    if payload.peer_token is not None:
        if len(payload.peer_token) < 8:
            raise HTTPException(status_code=400, detail="peer_token en az 8 karakter olmalı")
        node.peer_token_encrypted = encrypt_secret(payload.peer_token)
    if payload.display_order is not None:
        node.display_order = payload.display_order
    if payload.is_active is not None:
        node.is_active = payload.is_active
    db.commit()
    db.refresh(node)
    return node


@admin_router.delete("/nodes/{node_id}", status_code=204)
async def sync_delete_node(node_id: int, db: Session = Depends(get_db)):
    """Uzak node'u sil."""
    node = db.query(SyncNode).filter(SyncNode.id == node_id, SyncNode.is_self == False).first()  # noqa: E712
    if not node:
        raise HTTPException(status_code=404, detail="Node bulunamadı")
    db.delete(node)
    db.commit()
    return Response(status_code=204)


@admin_router.post("/nodes/{node_id}/test")
async def sync_test_node(node_id: int, db: Session = Depends(get_db)):
    """Belirli uzak node'a heartbeat gönder."""
    node = db.query(SyncNode).filter(SyncNode.id == node_id, SyncNode.is_self == False).first()  # noqa: E712
    if not node:
        raise HTTPException(status_code=404, detail="Node bulunamadı")
    ok, msg = sync_service.heartbeat_to_node(db, node)
    if ok:
        node.last_heartbeat_at = datetime.now(timezone.utc)
        node.last_error = None
    else:
        node.last_error = msg
    db.commit()
    return {"ok": ok, "message": msg}


@admin_router.post("/nodes/{node_id}/pull")
async def sync_pull_from_node(node_id: int, db: Session = Depends(get_db)):
    """Belirli uzak node'dan snapshot çek ve MERGE uygula."""
    node = db.query(SyncNode).filter(SyncNode.id == node_id, SyncNode.is_self == False).first()  # noqa: E712
    if not node:
        raise HTTPException(status_code=404, detail="Node bulunamadı")
    if not node.url or not node.peer_token_encrypted:
        raise HTTPException(status_code=400, detail="Node URL veya token eksik")
    self_node = sync_service.get_self_node(db)
    try:
        stats = sync_service.pull_from_node(db, node, self_node.name)
    except Exception as e:
        node.last_error = str(e)
        db.commit()
        raise HTTPException(status_code=502, detail=f"Pull başarısız: {e}")
    return {"ok": True, "stats": stats}


@admin_router.post("/nodes/{node_id}/push")
async def sync_push_to_node(node_id: int, db: Session = Depends(get_db)):
    """Lokal snapshot'ı belirli uzak node'a gönder."""
    node = db.query(SyncNode).filter(SyncNode.id == node_id, SyncNode.is_self == False).first()  # noqa: E712
    if not node:
        raise HTTPException(status_code=404, detail="Node bulunamadı")
    if not node.url or not node.peer_token_encrypted:
        raise HTTPException(status_code=400, detail="Node URL veya token eksik")
    self_node = sync_service.get_self_node(db)
    try:
        result = sync_service.push_to_node(db, node, self_node.name)
    except Exception as e:
        node.last_error = str(e)
        db.commit()
        raise HTTPException(status_code=502, detail=f"Push başarısız: {e}")
    return {"ok": True, "remote": result}


@admin_router.post("/nodes/push-all")
async def sync_push_all(db: Session = Depends(get_db)):
    """Tüm aktif uzak node'lara snapshot gönder."""
    self_node = sync_service.get_self_node(db)
    results = sync_service.push_to_all(db, self_node.name)
    return {"ok": True, "results": results}


@admin_router.get("/logs", response_model=List[SyncLogOut])
async def sync_logs(
    limit: int = 100,
    offset: int = 0,
    event_type: Optional[str] = None,
    node: Optional[str] = None,
    db: Session = Depends(get_db),
):
    """
    Sync log kayıtlarını döndürür (en yeniden eskiye).
    Filtreler: event_type (push_delta|pull_delta|heartbeat|error|push|pull),
               node (from veya to node adı içeren).
    """
    q = db.query(SyncLog)
    if event_type:
        q = q.filter(SyncLog.event_type == event_type)
    if node:
        from sqlalchemy import or_
        q = q.filter(or_(
            SyncLog.from_node_name.ilike(f"%{node}%"),
            SyncLog.to_node_name.ilike(f"%{node}%"),
        ))
    logs = (
        q.order_by(SyncLog.created_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )
    return logs


@admin_router.get("/stats")
async def sync_stats(db: Session = Depends(get_db)):
    """
    Son 24 saatin sync istatistiklerini döndürür.
    Süperadmin dashboard'unda özet görünümü için.
    """
    from sqlalchemy import func as sqlfunc
    from datetime import datetime, timezone, timedelta

    since = datetime.now(timezone.utc) - timedelta(hours=24)
    rows = (
        db.query(
            SyncLog.event_type,
            sqlfunc.count(SyncLog.id).label("count"),
            sqlfunc.sum(SyncLog.records_total).label("total_records"),
            sqlfunc.avg(SyncLog.duration_ms).label("avg_ms"),
        )
        .filter(SyncLog.created_at >= since)
        .group_by(SyncLog.event_type)
        .all()
    )
    error_count = (
        db.query(sqlfunc.count(SyncLog.id))
        .filter(SyncLog.created_at >= since, SyncLog.error.isnot(None))
        .scalar()
    )
    return {
        "since": since.isoformat(),
        "by_event": [
            {
                "event_type": r.event_type,
                "count": r.count,
                "total_records": int(r.total_records or 0),
                "avg_ms": int(r.avg_ms or 0),
            }
            for r in rows
        ],
        "error_count": error_count or 0,
    }


@admin_router.post("/regenerate-token", response_model=SelfInfoOut)
async def sync_regen_token(db: Session = Depends(get_db)):
    """our_token'ı yenile (mevcut eşleşmeler bozulur — peer'lere yeni token verilmeli)."""
    self_node = sync_service.get_self_node(db)
    self_node.our_token = secrets.token_urlsafe(64)
    db.commit()
    db.refresh(self_node)
    return _node_to_self_info(self_node)


# ── Deploy (uzak sunucu güncelleme) ──────────────────────────────────────────

@admin_router.get("/bundle")
async def sync_download_self_bundle(db: Session = Depends(get_db)):
    """Bu sunucunun kaynak dosyalarını ZIP olarak indir."""
    from app.services import deploy_service
    data = deploy_service.create_bundle_zip()
    self_node = sync_service.get_self_node(db)
    fname = f"{self_node.name.lower().replace(' ', '_')}_bundle.zip"
    return Response(
        content=data,
        media_type="application/zip",
        headers={
            "Content-Length": str(len(data)),
            "Content-Disposition": f'attachment; filename="{fname}"',
        },
    )


@admin_router.get("/bundle-all")
async def sync_download_all_bundles(db: Session = Depends(get_db)):
    """Tüm sunucuların (bu sunucu + tüm aktif uzak node'lar) bundle'larını tek ZIP içinde döndürür.
    Ulaşılamayan node'lar atlanır; sadece başarıyla alınanlar eklenir."""
    import asyncio
    import io
    import zipfile as _zipfile
    import httpx
    from app.utils.crypto import decrypt_secret

    self_node = sync_service.get_self_node(db)
    active_nodes = (
        db.query(SyncNode)
        .filter(SyncNode.is_self == False, SyncNode.is_active == True)  # noqa: E712
        .all()
    )

    # Snapshot: sıfır bekleme ile ihtiyaç duyulan değerleri al
    node_snapshots = [
        (n.id, n.name, n.url, n.peer_token_encrypted)
        for n in active_nodes
        if n.url and n.peer_token_encrypted
    ]

    async def _fetch(node_name: str, node_url: str, token_enc: str) -> tuple[str, Optional[bytes]]:
        fname = f"{node_name.lower().replace(' ', '_')}_bundle.zip"
        try:
            peer_token = decrypt_secret(token_enc)
            async with httpx.AsyncClient(timeout=120.0) as client:
                r = await client.get(
                    f"{node_url}/api/v1/sync/bundle",
                    headers={"Authorization": f"Bearer {peer_token}"},
                )
                r.raise_for_status()
                return fname, r.content
        except Exception:
            return fname, None

    from app.services import deploy_service as _ds
    self_bundle = _ds.create_bundle_zip()
    self_fname = f"{self_node.name.lower().replace(' ', '_')}_bundle.zip"

    results = await asyncio.gather(*[
        _fetch(name, url, token_enc)
        for (_, name, url, token_enc) in node_snapshots
    ])

    buf = io.BytesIO()
    with _zipfile.ZipFile(buf, "w", _zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        zf.writestr(self_fname, self_bundle)
        for fname, content in results:
            if content is not None:
                zf.writestr(fname, content)

    data = buf.getvalue()
    return Response(
        content=data,
        media_type="application/zip",
        headers={
            "Content-Length": str(len(data)),
            "Content-Disposition": 'attachment; filename="all_servers_bundle.zip"',
        },
    )


def _get_node_or_404(node_id: int, db: Session) -> SyncNode:
    node = db.query(SyncNode).filter(
        SyncNode.id == node_id,
        SyncNode.is_self == False,  # noqa: E712
    ).first()
    if not node:
        raise HTTPException(status_code=404, detail="Node bulunamadı")
    if not node.url or not node.peer_token_encrypted:
        raise HTTPException(status_code=400, detail="Node URL veya peer token eksik")
    return node


@admin_router.get("/nodes/{node_id}/bundle")
async def sync_download_node_bundle(node_id: int, db: Session = Depends(get_db)):
    """Uzak node'un kaynak dosyalarını bu sunucu üzerinden proxy ederek indir."""
    import httpx
    from app.utils.crypto import decrypt_secret
    node = _get_node_or_404(node_id, db)
    peer_token = decrypt_secret(node.peer_token_encrypted)
    try:
        async with httpx.AsyncClient(timeout=180.0) as client:
            r = await client.get(
                f"{node.url}/api/v1/sync/bundle",
                headers={"Authorization": f"Bearer {peer_token}"},
            )
            r.raise_for_status()
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Uzak sunucudan bundle alınamadı: {exc}")
    fname = f"{node.name.lower().replace(' ', '_')}_bundle.zip"
    return Response(
        content=r.content,
        media_type="application/zip",
        headers={
            "Content-Length": str(len(r.content)),
            "Content-Disposition": f'attachment; filename="{fname}"',
        },
    )


@admin_router.post("/nodes/{node_id}/push-deploy")
async def sync_push_deploy(node_id: int, db: Session = Depends(get_db)):
    """Bu sunucunun bundle'ını uzak node'a gönder ve deploy'u başlat."""
    import httpx
    from app.services import deploy_service
    from app.utils.crypto import decrypt_secret
    node = _get_node_or_404(node_id, db)
    peer_token = decrypt_secret(node.peer_token_encrypted)

    # ── Pre-deploy health check ──────────────────────────────────────
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            health = await client.get(
                f"{node.url}/health",
                headers={"Authorization": f"Bearer {peer_token}"},
            )
            if health.status_code != 200:
                raise HTTPException(
                    status_code=502,
                    detail=f"{node.name} sağlık kontrolü başarısız (HTTP {health.status_code}) — deploy iptal edildi",
                )
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"{node.name} deploy öncesi ulaşılamıyor: {exc} — deploy iptal edildi",
        )

    # ── Bundle oluştur ───────────────────────────────────────────────
    try:
        bundle = deploy_service.create_bundle_zip()
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Bundle oluşturulamadı: {exc}")

    # ── Deploy gönder ────────────────────────────────────────────────
    try:
        async with httpx.AsyncClient(timeout=300.0) as client:
            r = await client.post(
                f"{node.url}/api/v1/sync/deploy",
                content=bundle,
                headers={
                    "Authorization": f"Bearer {peer_token}",
                    "Content-Type": "application/octet-stream",
                    "X-Bundle-Size": str(len(bundle)),
                },
            )
            r.raise_for_status()
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Deploy gönderilemedi: {exc}")
    return {
        "ok": True,
        "message": f"{node.name} üzerinde deploy başlatıldı",
        "bundle_kb": len(bundle) // 1024,
    }


@admin_router.post("/nodes/{node_id}/upload-deploy")
async def sync_upload_deploy(
    node_id: int,
    request: Request,
    db: Session = Depends(get_db),
):
    """Yüklenen ZIP'i uzak node'a gönder ve deploy'u başlat."""
    import httpx
    from app.utils.crypto import decrypt_secret
    node = _get_node_or_404(node_id, db)
    chunks: list = []
    total = 0
    async for chunk in request.stream():
        if not chunk:
            continue
        total += len(chunk)
        if total > 2 * 1024 * 1024 * 1024:
            raise HTTPException(status_code=413, detail="ZIP çok büyük (max 2 GiB)")
        chunks.append(chunk)
    zip_bytes = b"".join(chunks)
    if len(zip_bytes) < 100:
        raise HTTPException(status_code=400, detail="Geçersiz ZIP")
    peer_token = decrypt_secret(node.peer_token_encrypted)
    try:
        async with httpx.AsyncClient(timeout=300.0) as client:
            r = await client.post(
                f"{node.url}/api/v1/sync/deploy",
                content=zip_bytes,
                headers={
                    "Authorization": f"Bearer {peer_token}",
                    "Content-Type": "application/octet-stream",
                },
            )
            r.raise_for_status()
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Deploy gönderilemedi: {exc}")
    return {"ok": True, "message": f"{node.name} üzerinde deploy başlatıldı"}


@admin_router.get("/nodes/{node_id}/deploy-status")
async def sync_node_deploy_status(node_id: int, db: Session = Depends(get_db)):
    """Uzak node'un deploy durumunu döndürür; sunucu kapalıysa 'restarting' döner."""
    import httpx
    from app.utils.crypto import decrypt_secret
    node = _get_node_or_404(node_id, db)
    peer_token = decrypt_secret(node.peer_token_encrypted)
    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            r = await client.get(
                f"{node.url}/api/v1/sync/deploy/status",
                headers={"Authorization": f"Bearer {peer_token}"},
            )
            r.raise_for_status()
            return r.json()
    except (httpx.ConnectError, httpx.ConnectTimeout, httpx.ReadTimeout, httpx.RemoteProtocolError):
        return {
            "step": "restarting",
            "message": "Sunucu yeniden başlatılıyor — lütfen bekleyin...",
            "done": False,
            "error": None,
            "ts": None,
            "offline": True,
        }
    except httpx.HTTPStatusError as exc:
        # 5xx (502, 503, 504, 521 Cloudflare "origin down", vb.):
        # Sunucu yeniden başlatılıyor — geçici bir durum, polling devam etmeli
        if exc.response.status_code >= 500:
            return {
                "step": "restarting",
                "message": "Sunucu yeniden başlatılıyor — lütfen bekleyin...",
                "done": False,
                "error": None,
                "ts": None,
                "offline": True,
            }
        return {
            "step": "error",
            "message": f"Durum alınamadı: HTTP {exc.response.status_code}",
            "done": False,
            "error": str(exc),
            "ts": None,
        }
    except Exception as exc:
        return {
            "step": "error",
            "message": f"Durum alınamadı: {exc}",
            "done": False,
            "error": str(exc),
            "ts": None,
        }


def _deploy_to_node_thread(
    batch_id: str,
    node_id: int,
    node_url: str,
    peer_token_enc: str,
    bundle: bytes,
) -> None:
    """
    Arka planda çalışır: tek bir node'a bundle gönderir ve deploy tamamlanana dek bekler.
    Her adımda deploy_batch_items.status güncellenir (frontend polling eder).
    """
    import time
    import httpx
    from app.core.database import SessionLocal
    from app.models.deploy_batch import DeployBatch, DeployBatchItem
    from app.utils.crypto import decrypt_secret

    def _set_item(status: str, error: Optional[str] = None, completed: bool = False) -> None:
        db2 = SessionLocal()
        try:
            item = db2.query(DeployBatchItem).filter(
                DeployBatchItem.batch_id == batch_id,
                DeployBatchItem.sync_node_id == node_id,
            ).first()
            if item:
                item.status = status
                if error:
                    item.error_message = str(error)[:1000]
                if completed:
                    item.completed_at = datetime.now(timezone.utc)
                db2.commit()
        finally:
            db2.close()

    def _finalize_batch() -> None:
        db2 = SessionLocal()
        try:
            batch = db2.query(DeployBatch).filter(DeployBatch.id == batch_id).first()
            if not batch:
                return
            statuses = [i.status for i in batch.items]
            # Only finalize once all items are terminal
            if not all(s in ("done", "error") for s in statuses):
                return
            if all(s == "done" for s in statuses):
                batch.status = "done"
            elif all(s == "error" for s in statuses):
                batch.status = "failed"
            else:
                batch.status = "partial"
            db2.commit()
        finally:
            db2.close()

    try:
        peer_token = decrypt_secret(peer_token_enc)

        # Mark as deploying + record start time
        db3 = SessionLocal()
        try:
            item = db3.query(DeployBatchItem).filter(
                DeployBatchItem.batch_id == batch_id,
                DeployBatchItem.sync_node_id == node_id,
            ).first()
            if item:
                item.status = "deploying"
                item.started_at = datetime.now(timezone.utc)
                db3.commit()
        finally:
            db3.close()

        # Pre-deploy health check
        with httpx.Client(timeout=10.0) as client:
            health = client.get(
                f"{node_url}/health",
                headers={"Authorization": f"Bearer {peer_token}"},
            )
            if health.status_code != 200:
                raise RuntimeError(f"Sağlık kontrolü başarısız (HTTP {health.status_code})")

        # Send bundle
        with httpx.Client(timeout=300.0) as client:
            r = client.post(
                f"{node_url}/api/v1/sync/deploy",
                content=bundle,
                headers={
                    "Authorization": f"Bearer {peer_token}",
                    "Content-Type": "application/octet-stream",
                    "X-Bundle-Size": str(len(bundle)),
                },
            )
            r.raise_for_status()

        # Poll deploy/status until done (max 18 min = 360 × 3s)
        MAX_POLL = 360
        for _ in range(MAX_POLL):
            time.sleep(3)
            try:
                with httpx.Client(timeout=20.0) as client:
                    sr = client.get(
                        f"{node_url}/api/v1/sync/deploy/status",
                        headers={"Authorization": f"Bearer {peer_token}"},
                    )
                    if sr.status_code == 200:
                        s = sr.json()
                        step = s.get("step", "deploying")
                        if s.get("done"):
                            _set_item("done", completed=True)
                            _finalize_batch()
                            return
                        if step == "error":
                            _set_item(
                                "error",
                                error=s.get("error") or s.get("message"),
                                completed=True,
                            )
                            _finalize_batch()
                            return
                        # Mirror current step into DB so frontend can show progress
                        _set_item(step)
            except Exception:
                pass  # Network blip during restart — keep polling

        # Timeout after 18 min
        _set_item("error", error="18 dakika içinde tamamlanmadı — zaman aşımı", completed=True)
        _finalize_batch()

    except Exception as exc:
        _set_item("error", error=str(exc), completed=True)
        _finalize_batch()


class BulkDeployIn(BaseModel):
    node_ids: List[int] = Field(..., min_length=1, max_length=20)


@admin_router.post("/nodes/bulk-deploy")
async def sync_bulk_deploy(
    payload: BulkDeployIn,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_super_admin),
):
    """Seçili aktif node'lara aynı anda bundle gönderir; her biri için arka plan thread başlatır."""
    import threading
    from app.services import deploy_service
    from app.models.deploy_batch import DeployBatch, DeployBatchItem

    nodes = (
        db.query(SyncNode)
        .filter(
            SyncNode.id.in_(payload.node_ids),
            SyncNode.is_self == False,  # noqa: E712
            SyncNode.is_active == True,  # noqa: E712
        )
        .all()
    )
    if not nodes:
        raise HTTPException(400, "Geçerli aktif uzak node bulunamadı")

    # Create bundle once (shared across all nodes)
    try:
        bundle = deploy_service.create_bundle_zip()
    except Exception as exc:
        raise HTTPException(500, f"Bundle oluşturulamadı: {exc}")

    # Persist batch record
    batch = DeployBatch(
        initiated_by=current_user.id,
        bundle_size_bytes=len(bundle),
        status="in_progress",
    )
    db.add(batch)
    db.flush()

    for node in nodes:
        item = DeployBatchItem(
            batch_id=batch.id,
            sync_node_id=node.id,
            node_name=node.name,
            status="queued",
        )
        db.add(item)
    db.commit()
    db.refresh(batch)

    batch_id = batch.id

    # Launch one thread per node (daemon — won't prevent process exit)
    from app.utils.crypto import decrypt_secret
    for node in nodes:
        t = threading.Thread(
            target=_deploy_to_node_thread,
            args=(batch_id, node.id, node.url, node.peer_token_encrypted, bundle),
            daemon=True,
        )
        t.start()

    return {
        "ok": True,
        "batch_id": batch_id,
        "node_count": len(nodes),
        "bundle_kb": len(bundle) // 1024,
    }


@admin_router.get("/deploy-batch/{batch_id}/status")
async def sync_batch_status(batch_id: str, db: Session = Depends(get_db)):
    """Toplu deploy batch'ının anlık durumunu döndürür."""
    from app.models.deploy_batch import DeployBatch
    batch = db.query(DeployBatch).filter(DeployBatch.id == batch_id).first()
    if not batch:
        raise HTTPException(404, "Batch bulunamadı")
    return {
        "id": batch.id,
        "status": batch.status,
        "bundle_size_bytes": batch.bundle_size_bytes,
        "created_at": batch.created_at.isoformat() if batch.created_at else None,
        "items": [
            {
                "id": item.id,
                "node_name": item.node_name,
                "sync_node_id": item.sync_node_id,
                "status": item.status,
                "error_message": item.error_message,
                "started_at": item.started_at.isoformat() if item.started_at else None,
                "completed_at": item.completed_at.isoformat() if item.completed_at else None,
            }
            for item in batch.items
        ],
    }


@admin_router.get("/deploy-batches")
async def sync_list_batches(db: Session = Depends(get_db)):
    """Son 20 toplu deploy geçmişini döndürür."""
    from app.models.deploy_batch import DeployBatch
    from sqlalchemy import desc as sqldesc
    batches = (
        db.query(DeployBatch)
        .order_by(sqldesc(DeployBatch.created_at))
        .limit(20)
        .all()
    )
    return [
        {
            "id": b.id,
            "status": b.status,
            "bundle_size_bytes": b.bundle_size_bytes,
            "created_at": b.created_at.isoformat() if b.created_at else None,
            "node_count": len(b.items),
            "done_count": sum(1 for i in b.items if i.status == "done"),
            "error_count": sum(1 for i in b.items if i.status == "error"),
        }
        for b in batches
    ]


@admin_router.get("/disk-status")
async def sync_disk_status(db: Session = Depends(get_db)):
    """
    Tüm sunucuların disk kullanım durumunu döndürür.
    Diyagram: sunucuların disk doluluk seviyeleri görselleştirmesi.
    """
    import shutil
    from app.models.sync_node import SyncNode
    from app.models.file_location import FileLocation
    from app.services.disk_service import DISK_MIN_FREE_BYTES

    # Bu sunucunun disk bilgisi
    local_usage = shutil.disk_usage("/")
    local_node = db.query(SyncNode).filter(SyncNode.is_self == True).first()
    local_file_count = db.query(FileLocation).filter(FileLocation.node_id == None).count()

    results = [{
        "node_id": local_node.id if local_node else 0,
        "name": local_node.name if local_node else "Bu Sunucu",
        "is_self": True,
        "is_active": True,
        "total_gb": round(local_usage.total / (1024 ** 3), 2),
        "free_gb": round(local_usage.free / (1024 ** 3), 2),
        "used_gb": round(local_usage.used / (1024 ** 3), 2),
        "used_percent": round(local_usage.used / local_usage.total * 100, 1),
        "disk_low": local_usage.free < DISK_MIN_FREE_BYTES,
        "file_count": local_file_count,
        "last_heartbeat_at": None,
    }]

    # Peer node'ların disk bilgileri (heartbeat'te gelen veriler)
    peers = db.query(SyncNode).filter(SyncNode.is_self == False, SyncNode.is_active == True).all()
    for peer in peers:
        file_count = db.query(FileLocation).filter(FileLocation.node_id == peer.id).count()
        total_gb = peer.sys_disk_total_gb or 0
        free_gb = peer.sys_disk_free_gb or 0
        used_gb = round(total_gb - free_gb, 2)
        used_pct = round(used_gb / total_gb * 100, 1) if total_gb > 0 else 0
        results.append({
            "node_id": peer.id,
            "name": peer.name,
            "is_self": False,
            "is_active": peer.is_active,
            "total_gb": total_gb,
            "free_gb": free_gb,
            "used_gb": used_gb,
            "used_percent": used_pct,
            "disk_low": free_gb < (DISK_MIN_FREE_BYTES / (1024 ** 3)),
            "file_count": file_count,
            "last_heartbeat_at": peer.last_heartbeat_at.isoformat() if peer.last_heartbeat_at else None,
        })

    return {"servers": results, "threshold_gb": round(DISK_MIN_FREE_BYTES / (1024 ** 3), 2)}
