"""
Bayi Yedekleme API
====================
Bir bayi (tenant sahibi) kendi tüm verilerini şifreli tek dosya olarak
indirir/yükler. Şifreyi sadece süperadmin görür.

Endpoints:
- POST   /api/v1/backup/create               → Yeni yedek oluştur (.sfb dosyası kaydet)
- GET    /api/v1/backup/list                 → Bayinin geçmiş yedekleri
- GET    /api/v1/backup/download/{backup_id} → Şifreli dosyayı indir
- DELETE /api/v1/backup/{backup_id}          → Sil
- POST   /api/v1/backup/restore              → Dosya yükle, geri yükle
"""

from typing import List
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models import User, BayiBackup
from app.utils.auth import get_current_user, get_current_super_admin
from app.services import backup_service


router = APIRouter(prefix="/backup", tags=["Backup"])


class BackupOut(BaseModel):
    id: str
    filename: str
    size_bytes: int
    created_at: datetime
    restored_at: datetime | None = None

    class Config:
        from_attributes = True


class CreateBackupResponse(BaseModel):
    id: str
    filename: str
    size_bytes: int
    download_url: str
    backups_used: int = 0
    backups_max: int = 3


class RestoreResponse(BaseModel):
    backup_id: str
    restored_owner_id: int
    tables: dict
    files_restored: int


def _tenant_id(user: User) -> int:
    return user.parent_user_id if user.parent_user_id else user.id


@router.post("/create", response_model=CreateBackupResponse)
def create_backup(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Yeni şifreli yedek oluşturur. Sunucuda en fazla 3 yedek tutulur; eskiler otomatik silinir."""
    try:
        record = backup_service.create_backup(db, current_user)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Yedek oluşturulamadı: {exc}")
    owner_id = _tenant_id(current_user)
    backups_used = db.query(BayiBackup).filter(BayiBackup.user_id == owner_id).count()
    return CreateBackupResponse(
        id=record.id,
        filename=record.filename,
        size_bytes=record.size_bytes,
        download_url=f"/api/v1/backup/download/{record.id}",
        backups_used=backups_used,
        backups_max=backup_service.MAX_BACKUPS_PER_USER,
    )


@router.get("/list", response_model=List[BackupOut])
def list_backups(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Bayinin yedeklerini listeler (en yeni önce). Şifreyi DÖNMEZ."""
    owner_id = _tenant_id(current_user)
    rows = (
        db.query(BayiBackup)
        .filter(BayiBackup.user_id == owner_id)
        .order_by(BayiBackup.created_at.desc())
        .all()
    )
    return rows


@router.get("/download/{backup_id}")
def download_backup(
    backup_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Yedek dosyasını ham bytes olarak döner. Sadece sahibi indirebilir."""
    owner_id = _tenant_id(current_user)
    record = db.query(BayiBackup).filter(BayiBackup.id == backup_id).first()
    if not record or record.user_id != owner_id:
        raise HTTPException(status_code=404, detail="Yedek bulunamadı")
    try:
        data = backup_service.read_backup_file(backup_id)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Yedek dosyası diskten silinmiş")
    return Response(
        content=data,
        media_type="application/octet-stream",
        headers={
            "Content-Disposition": f'attachment; filename="{record.filename}"',
            "Content-Length": str(len(data)),
        },
    )


@router.delete("/{backup_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_backup(
    backup_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    owner_id = _tenant_id(current_user)
    record = db.query(BayiBackup).filter(BayiBackup.id == backup_id).first()
    if not record or record.user_id != owner_id:
        raise HTTPException(status_code=404, detail="Yedek bulunamadı")
    backup_service.delete_backup_file(backup_id)
    db.delete(record)
    db.commit()
    return Response(status_code=204)


@router.post("/restore", response_model=RestoreResponse)
async def restore_backup(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Yedek dosyasını yükler ve geri yükler. Şifre sistemce otomatik bulunur."""
    if not file or not file.filename:
        raise HTTPException(status_code=400, detail="Dosya yüklenmedi")
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="Dosya boş")
    # .sfb formatı: JSON header satırı + şifrelenmiş içerik ('{' ile başlar)
    if not raw[:1] == b"{":
        raise HTTPException(status_code=400, detail="Geçersiz dosya: .sfb formatı bekleniyordu (StokFinans yedek dosyası)")
    if len(raw) > 500 * 1024 * 1024:  # 500MB sert sınır
        raise HTTPException(status_code=413, detail="Dosya çok büyük (max 500MB)")
    try:
        result = backup_service.restore_backup(db, current_user, raw)
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Geri yükleme başarısız: {exc}")
    return RestoreResponse(**result)


# ── Süper Admin: belirli bayi için yedek oluştur ─────────────────────────────

@router.post("/admin/create-for-user/{user_id}", response_model=CreateBackupResponse)
def admin_create_backup_for_user(
    user_id: int,
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
):
    """Süper admin: belirtilen bayi için şifreli yedek oluşturur."""
    target = db.query(User).filter(User.id == user_id, User.is_super_admin == False).first()  # noqa: E712
    if not target:
        raise HTTPException(status_code=404, detail="Bayi bulunamadı")
    try:
        record = backup_service.create_backup(db, target)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Yedek oluşturulamadı: {exc}")
    return CreateBackupResponse(
        id=record.id,
        filename=record.filename,
        size_bytes=record.size_bytes,
        download_url=f"/api/v1/backup/download/{record.id}",
    )


@router.get("/admin/list-users")
def admin_list_backup_users(
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
):
    """Süper admin: yedek alınabilecek bayilerin listesi (id, email, company_name, son yedek tarihi)."""
    users = db.query(User).filter(
        User.is_super_admin == False,  # noqa: E712
        User.parent_user_id == None,   # noqa: E711
    ).order_by(User.created_at.desc()).all()

    result = []
    for u in users:
        last_backup = (
            db.query(BayiBackup)
            .filter(BayiBackup.user_id == u.id)
            .order_by(BayiBackup.created_at.desc())
            .first()
        )
        result.append({
            "id": u.id,
            "email": u.email,
            "company_name": u.company_name or u.full_name or u.email,
            "last_backup_at": last_backup.created_at.isoformat() if last_backup else None,
            "last_backup_id": last_backup.id if last_backup else None,
        })
    return result
