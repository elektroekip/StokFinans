"""
Camera endpoints.

Device (ESP32-CAM) side — authenticated with X-Api-Key:
  POST /api/v1/camera/frame
    Body: raw JPEG bytes  (Content-Type: image/jpeg)
    Returns: { codes: [...], count: N }

Frontend (user JWT) side:
  GET /api/v1/camera/{device_id}/latest
    Returns: { jpeg_b64, width, height, codes, timestamp }
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from sqlalchemy.orm import Session

from ..core.database import get_db
from ..services.camera_service import get_frame, process_frame
from ..utils.auth import get_current_user
# data_owner_id is imported locally inside get_latest() to avoid circular imports

router = APIRouter(prefix="/camera", tags=["Camera"])


def _get_device(api_key: str, db: Session):
    from ..models.device import Device  # local import avoids circular dep
    device = (
        db.query(Device)
        .filter(Device.api_key == api_key, Device.is_active == True)
        .first()
    )
    if not device:
        raise HTTPException(status_code=401, detail="Geçersiz cihaz API anahtarı.")
    return device


# ──────────────────────────────────────────────────────────────
# POST /api/v1/camera/frame   (ESP32-CAM → server)
# ──────────────────────────────────────────────────────────────
@router.post("/frame")
async def upload_frame(
    request: Request,
    x_api_key: str = Header(..., alias="X-Api-Key"),
    db: Session = Depends(get_db),
):
    device = _get_device(x_api_key, db)

    jpeg_bytes = await request.body()
    if len(jpeg_bytes) < 100:
        raise HTTPException(status_code=400, detail="Geçersiz veya boş frame verisi.")

    codes = process_frame(device.device_id, jpeg_bytes)
    try:
        from ..api.topology import emit_topology_event
        emit_topology_event("upload", "devices", "backend-s1",
                            f"Kamera: {device.device_id[:12]} ({len(jpeg_bytes)//1024}KB{', '+str(len(codes))+' kod' if codes else ''})")
    except Exception:
        pass
    return {"codes": codes, "count": len(codes)}


# ──────────────────────────────────────────────────────────────
# GET /api/v1/camera/{device_id}/latest   (frontend → server)
# ──────────────────────────────────────────────────────────────
@router.get("/{device_id}/latest")
def get_latest(
    device_id: str,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    from ..models.device import Device
    from ..utils.tenant import data_owner_id

    device = (
        db.query(Device)
        .filter(Device.device_id == device_id, Device.is_active == True)
        .first()
    )
    if not device:
        raise HTTPException(status_code=404, detail="Cihaz bulunamadı.")

    if device.user_id != data_owner_id(current_user):
        raise HTTPException(status_code=403, detail="Bu cihaza erişim yetkiniz yok.")

    frame = get_frame(device_id)
    if frame is None:
        raise HTTPException(status_code=404, detail="Cihazdan henüz görüntü gelmedi.")

    return {
        "jpeg_b64": frame.jpeg_b64,
        "width": frame.width,
        "height": frame.height,
        "codes": frame.codes,
        "timestamp": frame.ts,
    }
