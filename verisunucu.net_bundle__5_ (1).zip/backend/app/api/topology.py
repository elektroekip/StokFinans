"""
Canlı Topoloji API — /api/v1/topology/

GET /topology/snapshot  → tüm node'ların anlık durumu + sistem metrikleri
GET /topology/events    → son olaylar (since_id ile artımlı polling)

Olaylar topology_events tablosuna yazılır; tüm uvicorn worker'ları
aynı PostgreSQL'i paylaştığından cross-worker tutarlılık sorunsuz çalışır.
"""
from __future__ import annotations

import os
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.core.database import SessionLocal, get_db
from app.models.user import User
from app.utils.auth import get_current_user

router = APIRouter(prefix="/topology", tags=["topology"])


def _require_superadmin(current_user: User = Depends(get_current_user)) -> User:
    if not current_user.is_super_admin:
        raise HTTPException(status_code=403, detail="Sadece süper admin")
    return current_user


# ── Event Emitter (servislerden çağrılır) ─────────────────────

def emit_topology_event(
    event_type: str,
    from_node: str = "backend-s1",
    to_node: Optional[str] = None,
    message: str = "",
) -> None:
    """
    Topoloji olayı kaydet. Herhangi bir sync servis fonksiyonundan güvenle çağrılabilir.
    Kendi DB session'ını açar ve kapatır — caller session'ını bozmaz.
    """
    _db = SessionLocal()
    try:
        _db.execute(
            text("""
                INSERT INTO topology_events (event_type, from_node, to_node, message)
                VALUES (:etype, :from_node, :to_node, :message)
            """),
            {"etype": event_type, "from_node": from_node, "to_node": to_node, "message": message},
        )
        _db.commit()
    except Exception as exc:
        print(f"[TOPOLOGY] emit hatası: {exc}")
        try:
            _db.rollback()
        except Exception:
            pass
    finally:
        _db.close()


# ── Sistem Metrikleri (psutil gerektirmez) ────────────────────

def _sys_metrics() -> Dict[str, Any]:
    try:
        with open("/proc/loadavg") as f:
            load = float(f.read().split()[0])
        meminfo: Dict[str, int] = {}
        with open("/proc/meminfo") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 2:
                    meminfo[parts[0].rstrip(":")] = int(parts[1])
        total = meminfo.get("MemTotal", 1)
        avail = meminfo.get("MemAvailable", total)
        return {"load": round(load, 2), "ram_pct": round((1 - avail / total) * 100)}
    except Exception:
        return {"load": 0.0, "ram_pct": 0}


# ── Snapshot Endpoint ─────────────────────────────────────────

@router.get("/snapshot")
def topology_snapshot(
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    """Tüm node'ların anlık durumu ve sistem metrikleri."""
    from app.models.sync_node import SyncNode
    from app.models.storage import StorageNode

    nodes: Dict[str, Dict[str, Any]] = {}
    sys = _sys_metrics()

    # ── Nginx (her zaman ayakta — biz API'ye ulaşabiliyorsak) ──
    nodes["nginx"] = {"status": "ok"}

    # ── Backend S1 (self) ────────────────────────────────────
    self_node = db.query(SyncNode).filter(SyncNode.is_self == True).first()  # noqa: E712
    nodes["backend-s1"] = {
        "status": "ok",
        "label": self_node.name if self_node else "S1",
        "load": sys["load"],
        "ram_pct": sys["ram_pct"],
    }

    # ── Backend S2 (peer) ────────────────────────────────────
    peer = db.query(SyncNode).filter(SyncNode.is_self == False).first()  # noqa: E712
    nodes["backend-s2"] = {
        "status": "ok" if (peer and peer.is_active) else ("error" if peer else "unknown"),
        "label": peer.name if peer else "S2",
    }

    # ── IoT Cihazlar ────────────────────────────────────────
    from app.models.device import Device as _Dev
    _ninety_ago = datetime.now(timezone.utc) - timedelta(seconds=90)
    _total_dev = db.query(_Dev).filter(_Dev.is_active == True).count()  # noqa: E712
    _online_dev = db.query(_Dev).filter(
        _Dev.is_active == True,  # noqa: E712
        _Dev.last_seen >= _ninety_ago,
    ).count()
    nodes["devices"] = {
        "status": "ok" if _online_dev > 0 else ("warn" if _total_dev > 0 else "unknown"),
        "label": f"IoT Cihazlar ({_online_dev}/{_total_dev})",
        "online": _online_dev,
        "total": _total_dev,
    }

    # ── PostgreSQL ───────────────────────────────────────────
    t0 = time.monotonic()
    try:
        db.execute(text("SELECT 1"))
        nodes["postgres"] = {"status": "ok", "latency_ms": int((time.monotonic() - t0) * 1000)}
    except Exception:
        nodes["postgres"] = {"status": "error", "latency_ms": None}

    # ── Storage Nodes (MinIO, SFTP, S3) ─────────────────────
    # Default placeholders shown as "warn/yapılandırılmamış" if no DB record exists.
    nodes["minio-s1"] = {"status": "warn", "label": "MinIO S1", "disk_pct": None}
    nodes["minio-s2"] = {"status": "warn", "label": "MinIO S2 — Yapılandırılmamış", "disk_pct": None}
    nodes["sftp"]    = {"status": "warn", "label": "SFTP — Yapılandırılmamış"}
    nodes["s3-ext"]  = {"status": "warn", "label": "Harici S3 — Yapılandırılmamış"}

    storage_nodes = db.query(StorageNode).order_by(StorageNode.id).all()
    minio_idx = 1
    for sn in storage_nodes:
        disk_pct: Optional[int] = None
        if sn.total_bytes and sn.used_bytes:
            disk_pct = round(sn.used_bytes / sn.total_bytes * 100)

        st = "ok" if sn.is_active else "error"
        if sn.is_active and sn.last_error:
            st = "warn"

        if sn.type == "minio":
            node_id = f"minio-s{minio_idx}"
            minio_idx += 1
        elif sn.type in ("sftp", "ftp"):
            node_id = "sftp"
        elif sn.type == "s3" and sn.is_external_backup:
            node_id = "s3-ext"
        else:
            node_id = f"storage-{sn.id}"

        nodes[node_id] = {
            "status": st,
            "label": sn.name,
            "disk_pct": disk_pct,
            "latency_ms": None,
        }

    # MinIO S2: if only one minio configured, live-check via env for replica endpoint
    if minio_idx == 2:  # only one MinIO was in DB
        replica_ep = os.environ.get("MINIO_REPLICA_ENDPOINT", "")
        if replica_ep:
            try:
                import urllib.request as _ur
                _req = _ur.Request(f"{replica_ep.rstrip('/')}/minio/health/live",
                                   headers={"User-Agent": "topology-check"})
                with _ur.urlopen(_req, timeout=2):
                    nodes["minio-s2"] = {"status": "ok", "label": "MinIO S2", "disk_pct": None}
            except Exception:
                nodes["minio-s2"] = {"status": "error", "label": "MinIO S2 — Erişilemiyor", "disk_pct": None}

    # Backend S2 MinIO: try to get status from peer sync node
    if peer and peer.is_active and nodes.get("minio-s2", {}).get("status") == "warn":
        try:
            import urllib.request as _ur
            import json as _json
            peer_url = peer.url.rstrip("/")
            _req = _ur.Request(f"{peer_url}/api/v1/topology/snapshot",
                               headers={"Authorization": f"Bearer {peer.api_key or ''}"})
            with _ur.urlopen(_req, timeout=3) as _r:
                peer_snap = _json.loads(_r.read())
                peer_minio = peer_snap.get("nodes", {}).get("minio-s1", {})
                if peer_minio:
                    nodes["minio-s2"] = {
                        "status": peer_minio.get("status", "unknown"),
                        "label": f"MinIO S2 ({peer.name})",
                        "disk_pct": peer_minio.get("disk_pct"),
                    }
        except Exception:
            pass

    return {"nodes": nodes, "system": sys}


# ── Events Endpoint ───────────────────────────────────────────

@router.get("/events")
def topology_events(
    since_id: int = Query(0, description="Bu ID'den büyük olayları döndür (artımlı polling)"),
    limit: int = Query(20, le=100),
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> List[Dict[str, Any]]:
    """Son N topoloji olayı. since_id ile delta polling yapılır."""
    rows = db.execute(
        text("""
            SELECT id, event_type, from_node, to_node, message, created_at
            FROM topology_events
            WHERE id > :since_id
            ORDER BY id ASC
            LIMIT :limit
        """),
        {"since_id": since_id, "limit": limit},
    ).fetchall()
    return [
        {
            "id": r[0],
            "event_type": r[1],
            "from_node": r[2],
            "to_node": r[3],
            "message": r[4],
            "created_at": r[5].isoformat() if r[5] else None,
        }
        for r in rows
    ]


# ── Stats Endpoint ───────────────────────────────────────────

@router.get("/stats")
def topology_stats(
    hours: int = Query(24, le=168),
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    """Son N saatin olay sayıları türe göre + node uyarı sayısı."""
    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    rows = db.execute(
        text("""
            SELECT event_type, COUNT(*) as cnt
            FROM topology_events
            WHERE created_at > :cutoff
            GROUP BY event_type
        """),
        {"cutoff": cutoff},
    ).fetchall()
    event_counts = {r[0]: int(r[1]) for r in rows}

    # Recent events for alert list (last 20)
    recent = db.execute(
        text("""
            SELECT id, event_type, from_node, to_node, message, created_at
            FROM topology_events
            ORDER BY id DESC LIMIT 20
        """),
    ).fetchall()
    recent_events = [
        {
            "id": r[0], "event_type": r[1], "from_node": r[2],
            "to_node": r[3], "message": r[4],
            "created_at": r[5].isoformat() if r[5] else None,
        }
        for r in recent
    ]

    return {
        "event_counts": event_counts,
        "total_events": sum(event_counts.values()),
        "recent_events": recent_events,
        "hours": hours,
    }


# ── Alert Count (sidebar badge için hafif endpoint) ───────────

@router.get("/alert-count")
def topology_alert_count(
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, int]:
    """Hızlı uyarı sayısı — sidebar badge için 30s polling."""
    from app.models.storage import StorageNode
    from app.models.sync_node import SyncNode
    alerts = 0
    # Pasif storage node'lar
    alerts += db.query(StorageNode).filter(StorageNode.is_active == False).count()  # noqa: E712
    # Peer sync node offline
    peer = db.query(SyncNode).filter(SyncNode.is_self == False).first()  # noqa: E712
    if peer and not peer.is_active:
        alerts += 1
    # Son 1 saat içinde hata olayları
    cutoff = datetime.now(timezone.utc) - timedelta(hours=1)
    err_count = db.execute(
        text("SELECT COUNT(*) FROM topology_events WHERE event_type='error' AND created_at > :c"),
        {"c": cutoff},
    ).scalar()
    alerts += int(err_count or 0)
    return {"alerts": alerts}


# ── Cluster Endpoint ─────────────────────────────────────────

@router.get("/cluster")
def topology_cluster(
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    """
    Tüm bayi_sahibi kullanıcıları (dükkanlar) ve bağlı cihazları/personeli döndürür.
    S1 ve S2 aynı tenant veri tabanını paylaşır (replica), bu yüzden tek liste yeterli.
    """
    from app.models.device import Device

    ninety_ago = datetime.now(timezone.utc) - timedelta(seconds=90)

    tenants_raw = (
        db.query(User)
        .filter(User.role == "bayi_sahibi", User.is_active == True)  # noqa: E712
        .order_by(User.id)
        .all()
    )

    result = []
    for t in tenants_raw:
        devices = (
            db.query(Device)
            .filter(Device.user_id == t.id, Device.is_active == True)  # noqa: E712
            .order_by(Device.id)
            .all()
        )
        online_devs = [d for d in devices if d.last_seen and d.last_seen >= ninety_ago]
        worker_count = (
            db.query(User)
            .filter(User.parent_user_id == t.id, User.is_active == True)  # noqa: E712
            .count()
        )
        result.append({
            "id": t.id,
            "name": t.full_name or t.email.split("@")[0],
            "company": t.company_name or "",
            "email": t.email,
            "package": t.package_slug or "starter",
            "sub_days": int(t.sub_days or 0),
            "device_total": len(devices),
            "device_online": len(online_devs),
            "worker_count": worker_count,
            "devices": [
                {
                    "device_id": d.device_id,
                    "type": d.device_type or "ESP32",
                    "variant": d.variant or "standart",
                    "online": bool(d.last_seen and d.last_seen >= ninety_ago),
                    "last_seen": d.last_seen.isoformat() if d.last_seen else None,
                    "firmware": d.firmware_version or "",
                    "ip": d.ip_address or "",
                }
                for d in devices[:8]
            ],
        })

    return {"tenants": result, "total": len(result)}


# ── Active Users Endpoint ─────────────────────────────────────

@router.get("/users")
def topology_users(
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    """Son 5 dakikada API'ye erişen kullanıcıları döndürür (in-memory cache)."""
    from app.utils.activity import get_active_users
    return {"users": get_active_users(max_age_seconds=300)}


# ── Cleanup (scheduler'dan çağrılır) ─────────────────────────

def cleanup_topology_events(db: Session, max_age_minutes: int = 60) -> None:
    """60 dakikadan eski olayları temizle (scheduler: saatte bir)."""
    cutoff = datetime.now(timezone.utc) - timedelta(minutes=max_age_minutes)
    try:
        db.execute(text("DELETE FROM topology_events WHERE created_at < :cutoff"), {"cutoff": cutoff})
        db.commit()
    except Exception as exc:
        print(f"[TOPOLOGY] cleanup hatası: {exc}")
        try:
            db.rollback()
        except Exception:
            pass
