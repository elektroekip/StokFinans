# ============================================================
# Report Endpoints - PDF Rapor Oluşturma API
# ============================================================
# Günlük satış, aylık finansman ve özel raporlar
#
# Seviye: SEVIYE 5 - Gelişmiş Özellikler
# Tarih: 28 Nisan 2026
# ============================================================

from fastapi import APIRouter, Depends, HTTPException, Query, status
from app.utils.tenant import data_owner_id
from sqlalchemy.orm import Session
from sqlalchemy import and_, func
from app.core.database import get_db
from app.models import Transaction, Product, User, ActivityLog
from app.schemas.file import ReportResponse
from app.utils.auth import get_current_user
from datetime import datetime, timedelta, date, timezone
from pathlib import Path
import io

router = APIRouter(prefix="/reports", tags=["Reports"])

# ============================================================
# Ayarlar
# ============================================================

REPORTS_DIR = Path("backend/reports")
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

# ============================================================
# Yardımcı Fonksiyonlar
# ============================================================

def generate_report_filename(report_type: str, date_str: str = None) -> str:
    """
    Rapor dosya adı oluştur

    Format: {report_type}_{date}.pdf
    Örnek: daily_2026_04_28.pdf

    Args:
        report_type: Rapor türü (daily, monthly, custom)
        date_str: Tarih string'i (opsiyonel)

    Returns:
        str: Dosya adı
    """
    if not date_str:
        date_str = datetime.now().strftime("%Y_%m_%d")
    return f"{report_type}_{date_str}.pdf"


def create_pdf_content(report_data: dict) -> bytes:
    """
    PDF rapor içeriği oluştur (Basit text-to-PDF)

    Real uygulamada reportlab veya similar kullanılır

    Args:
        report_data: Rapor verileri (başlık, tablolar, vb)

    Returns:
        bytes: PDF dosya içeriği
    """
    # Basit metin şeklinde PDF simulasyon
    # Real uygulamada reportlab, weasyprint, etc. kullanılır
    content = "PDF Report Placeholder\n"
    content += f"Generated: {datetime.now().isoformat()}\n"
    content += f"Type: {report_data.get('type', 'Unknown')}\n"
    content += "\nReport Data:\n"

    for key, value in report_data.items():
        if key != 'type':
            content += f"{key}: {value}\n"

    return content.encode('utf-8')


def log_activity(db: Session, user_id: int, action: str, details: str):
    """Aktivite logu kaydet"""
    log = ActivityLog(
        user_id=user_id,
        user_name="Sistem User",
        action_type=action,
        entity_type="report",
        entity_id=0,
        description=details or f"{action} report generated",
        details=details,
        status="success",
        created_at=datetime.now()
    )
    db.add(log)
    db.commit()


# ============================================================
# 1. GET /api/v1/reports/daily - Günlük Rapor
# ============================================================

@router.get(
    "/daily",
    response_model=ReportResponse,
    status_code=status.HTTP_200_OK,
    summary="Günlük Satış Raporu",
    description="Belirli bir günün satış, işlem ve müşteri bilgileri"
)
async def generate_daily_report(
    report_date: str = Query(None, description="Rapor tarihi (YYYY-MM-DD, default: bugün)"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Günlük satış raporu oluştur

    ## İçerik:
    1. Günlük satış özeti
       - Toplam satış tutarı
       - Satış sayısı
       - Ortalama işlem

    2. İşlem detayları
       - Her işlemin detayları (müşteri, tutarı, saat)
       - İşlem türüne göre kategorize

    3. Müşteri bilgileri
       - O gün işlem yapan müşteriler
       - Müşteri başına satış tutarı

    4. Ürün bilgileri
       - En çok satılan ürünler
       - Stok değişimleri

    ## İşlem Adımları:
    1. Tarih doğrula (YYYY-MM-DD formatı)
    2. O güne ait işlemleri sorgula
    3. Metrikleri hesapla
    4. PDF rapor oluştur
    5. Dosyayı kaydet
    6. ActivityLog'a kaydı kaydet
    7. Rapor bilgilerini döndür

    Args:
        report_date: Rapor tarihi (YYYY-MM-DD)
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        ReportResponse: Rapor bilgileri ve download URL'i

    Raises:
        HTTPException: 400 (Geçersiz tarih formatı)
    """
    # 1. Tarih doğrula
    if not report_date:
        report_date = datetime.now().strftime("%Y-%m-%d")

    try:
        target_date = datetime.strptime(report_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Geçersiz tarih formatı. Formatı: YYYY-MM-DD"
        )

    # 2. O güne ait işlemleri sorgula
    day_start = datetime.combine(target_date, datetime.min.time())
    day_end = datetime.combine(target_date, datetime.max.time())

    transactions = db.query(Transaction).filter(
        and_(
            Transaction.user_id == data_owner_id(current_user),
            Transaction.created_at >= day_start,
            Transaction.created_at <= day_end
        )
    ).all()

    # 3. Metrikleri hesapla
    total_sales = sum(t.amount for t in transactions if t.transaction_type in ["satış", "sale"])
    total_debt = sum(t.amount for t in transactions if t.transaction_type in ["borç", "debt"])
    total_paid = sum(t.amount for t in transactions if t.transaction_type in ["ödeme", "payment"])
    transaction_count = len(transactions)
    unique_customers = len(set(t.customer_name for t in transactions))

    # 4. PDF rapor içeriği oluştur
    report_data = {
        "type": "daily",
        "date": report_date,
        "total_sales": f"₺{total_sales:.2f}",
        "total_debt": f"₺{total_debt:.2f}",
        "total_paid": f"₺{total_paid:.2f}",
        "net_balance": f"₺{total_sales - total_debt + total_paid:.2f}",
        "transaction_count": transaction_count,
        "unique_customers": unique_customers,
        "period": f"{report_date}"
    }

    pdf_content = create_pdf_content(report_data)

    # 5. Dosyayı kaydet
    filename = generate_report_filename("daily", report_date.replace("-", "_"))
    file_path = REPORTS_DIR / filename

    with open(file_path, "wb") as f:
        f.write(pdf_content)

    file_size = len(pdf_content)

    # 6. ActivityLog'a kaydet
    log_activity(
        db=db,
        user_id=data_owner_id(current_user),
        action="generate",
        details=f"Günlük rapor oluşturuldu: {report_date}"
    )

    # 7. Rapor bilgilerini döndür
    report_url = f"/api/v1/reports/{filename}"
    period_start = day_start
    period_end = day_end

    return ReportResponse(
        report_type="daily",
        report_url=report_url,
        report_size=file_size,
        generated_at=datetime.now(),
        period_start=period_start,
        period_end=period_end
    )


# ============================================================
# 2. GET /api/v1/reports/monthly - Aylık Rapor
# ============================================================

@router.get(
    "/monthly",
    response_model=ReportResponse,
    status_code=status.HTTP_200_OK,
    summary="Aylık Finansman Raporu",
    description="Belirli bir ayın finansal durum raporu"
)
async def generate_monthly_report(
    year: int = Query(None, ge=2000, le=2100, description="Yıl (YYYY)"),
    month: int = Query(None, ge=1, le=12, description="Ay (1-12)"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Aylık finansman raporu oluştur

    ## İçerik:
    1. Aylık finansman özeti
       - Toplam satış
       - Toplam borç ve ödeme
       - Net bakiye

    2. Müşteri analizi
       - En çok satış yapılan müşteriler
       - Ödenmemiş borç listesi

    3. Ürün analizi
       - En çok satılan ürünler
       - Stok durumu

    4. Karşılaştırmalar
       - Önceki aya göre değişim
       - Trend analizi

    ## İşlem Adımları:
    1. Yıl ve ayı doğrula
    2. O aya ait işlemleri sorgula
    3. Metrikleri hesapla
    4. PDF rapor oluştur
    5. Dosyayı kaydet
    6. ActivityLog'a kaydı kaydet
    7. Rapor bilgilerini döndür

    Args:
        year: Yıl (YYYY)
        month: Ay (1-12)
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        ReportResponse: Rapor bilgileri ve download URL'i

    Raises:
        HTTPException: 400 (Geçersiz yıl/ay)
    """
    # 1. Yıl ve ayı doğrula
    now = datetime.now(timezone.utc)
    if year is None:
        year = now.year
    if month is None:
        month = now.month

    if not (2000 <= year <= 2100 and 1 <= month <= 12):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Geçersiz yıl veya ay"
        )

    # 2. O aya ait işlemleri sorgula
    month_start = datetime(year, month, 1, tzinfo=timezone.utc)
    if month == 12:
        month_end = datetime(year + 1, 1, 1, tzinfo=timezone.utc) - timedelta(seconds=1)
    else:
        month_end = datetime(year, month + 1, 1, tzinfo=timezone.utc) - timedelta(seconds=1)

    transactions = db.query(Transaction).filter(
        and_(
            Transaction.user_id == data_owner_id(current_user),
            Transaction.created_at >= month_start,
            Transaction.created_at <= month_end
        )
    ).all()

    # 3. Metrikleri hesapla
    total_sales = sum(t.amount for t in transactions if t.transaction_type in ["satış", "sale"])
    total_debt = sum(t.amount for t in transactions if t.transaction_type in ["borç", "debt"])
    total_paid = sum(t.amount for t in transactions if t.transaction_type in ["ödeme", "payment"])
    transaction_count = len(transactions)
    unique_customers = len(set(t.customer_name for t in transactions))

    # Ortalama satış per gün
    days_in_month = (month_end - month_start).days + 1
    daily_average = total_sales / days_in_month if days_in_month > 0 else 0

    # 4. PDF rapor içeriği oluştur
    report_data = {
        "type": "monthly",
        "year_month": f"{year}-{month:02d}",
        "total_sales": f"₺{total_sales:.2f}",
        "total_debt": f"₺{total_debt:.2f}",
        "total_paid": f"₺{total_paid:.2f}",
        "net_balance": f"₺{total_sales - total_debt + total_paid:.2f}",
        "daily_average": f"₺{daily_average:.2f}",
        "transaction_count": transaction_count,
        "unique_customers": unique_customers,
        "days": days_in_month
    }

    pdf_content = create_pdf_content(report_data)

    # 5. Dosyayı kaydet
    date_str = f"{year}_{month:02d}"
    filename = generate_report_filename("monthly", date_str)
    file_path = REPORTS_DIR / filename

    with open(file_path, "wb") as f:
        f.write(pdf_content)

    file_size = len(pdf_content)

    # 6. ActivityLog'a kaydet
    log_activity(
        db=db,
        user_id=data_owner_id(current_user),
        action="generate",
        details=f"Aylık rapor oluşturuldu: {year}-{month:02d}"
    )

    # 7. Rapor bilgilerini döndür
    report_url = f"/api/v1/reports/{filename}"

    return ReportResponse(
        report_type="monthly",
        report_url=report_url,
        report_size=file_size,
        generated_at=datetime.now(),
        period_start=month_start,
        period_end=month_end
    )


# ============================================================
# 3. GET /api/v1/reports/custom - Özel Rapor (Date Range)
# ============================================================

@router.get(
    "/custom",
    response_model=ReportResponse,
    status_code=status.HTTP_200_OK,
    summary="Özel Tarih Aralığı Raporu",
    description="Belirlenen tarih aralığı için rapor oluştur"
)
async def generate_custom_report(
    start_date: str = Query(..., description="Başlangıç tarihi (YYYY-MM-DD)"),
    end_date: str = Query(..., description="Bitiş tarihi (YYYY-MM-DD)"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Özel tarih aralığı için rapor oluştur

    ## Parametre Kuralları:
    - start_date <= end_date olmalı
    - Tarih formatı: YYYY-MM-DD
    - Maksimum aralık: 1 yıl

    ## İşlem Adımları:
    1. Tarihleri doğrula
    2. Tarih aralığına ait işlemleri sorgula
    3. Metrikleri hesapla
    4. PDF rapor oluştur
    5. Dosyayı kaydet
    6. ActivityLog'a kaydı kaydet
    7. Rapor bilgilerini döndür

    Args:
        start_date: Başlangıç tarihi (YYYY-MM-DD)
        end_date: Bitiş tarihi (YYYY-MM-DD)
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        ReportResponse: Rapor bilgileri

    Raises:
        HTTPException: 400 (Geçersiz tarih formatı, start > end, aralık > 1 yıl)
    """
    # 1. Tarihleri doğrula
    try:
        start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        end_dt = datetime.strptime(end_date, "%Y-%m-%d")
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Geçersiz tarih formatı. Formatı: YYYY-MM-DD"
        )

    if start_dt > end_dt:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Başlangıç tarihi bitiş tarihinden sonra olamaz"
        )

    # Maksimum aralık kontrolü (1 yıl)
    if (end_dt - start_dt).days > 365:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Maksimum aralık 1 yıldır"
        )

    # 2. Tarih aralığına ait işlemleri sorgula
    transactions = db.query(Transaction).filter(
        and_(
            Transaction.user_id == data_owner_id(current_user),
            Transaction.created_at >= start_dt,
            Transaction.created_at <= end_dt
        )
    ).all()

    # 3. Metrikleri hesapla
    total_sales = sum(t.amount for t in transactions if t.transaction_type in ["satış", "sale"])
    total_debt = sum(t.amount for t in transactions if t.transaction_type in ["borç", "debt"])
    total_paid = sum(t.amount for t in transactions if t.transaction_type in ["ödeme", "payment"])
    transaction_count = len(transactions)
    unique_customers = len(set(t.customer_name for t in transactions))

    days = (end_dt - start_dt).days + 1
    daily_average = total_sales / days if days > 0 else 0

    # 4. PDF rapor içeriği oluştur
    report_data = {
        "type": "custom",
        "period": f"{start_date} to {end_date}",
        "total_sales": f"₺{total_sales:.2f}",
        "total_debt": f"₺{total_debt:.2f}",
        "total_paid": f"₺{total_paid:.2f}",
        "net_balance": f"₺{total_sales - total_debt + total_paid:.2f}",
        "daily_average": f"₺{daily_average:.2f}",
        "transaction_count": transaction_count,
        "unique_customers": unique_customers,
        "days": days
    }

    pdf_content = create_pdf_content(report_data)

    # 5. Dosyayı kaydet
    filename = f"custom_{start_date}_{end_date}.pdf"
    file_path = REPORTS_DIR / filename

    with open(file_path, "wb") as f:
        f.write(pdf_content)

    file_size = len(pdf_content)

    # 6. ActivityLog'a kaydet
    log_activity(
        db=db,
        user_id=data_owner_id(current_user),
        action="generate",
        details=f"Özel rapor oluşturuldu: {start_date} - {end_date}"
    )

    # 7. Rapor bilgilerini döndür
    report_url = f"/api/v1/reports/{filename}"

    return ReportResponse(
        report_type="custom",
        report_url=report_url,
        report_size=file_size,
        generated_at=datetime.now(),
        period_start=start_dt,
        period_end=end_dt
    )
