# ============================================================
# Finance Endpoints - Finansman Yönetimi API
# ============================================================
# Satış, Borç, Ödeme ve Bakiye İşlemleri
#
# Seviye: SEVIYE 4 - Motor Odası
# Tarih: 28 Nisan 2026
# ============================================================

from fastapi import APIRouter, Depends, HTTPException, status, Query, Request
from app.utils.tenant import data_owner_id
from sqlalchemy.orm import Session
from sqlalchemy import and_, func, text
from pydantic import BaseModel, Field
from typing import Optional
from app.core.database import get_db
from app.models import Transaction, Product, User, ActivityLog
from app.models.vehicle import Vehicle, VehicleItem
from app.schemas.transaction import (
    TransactionCreateRequest,
    TransactionUpdateRequest,
    TransactionResponse,
    TransactionListResponse,
    TransactionCreateResponse,
    BalanceResponse,
    FinancialSummaryResponse,
    ProductInTransaction
)
from app.utils.auth import get_current_user
from app.utils.permissions import (
    require_perm, require_finance_action, require_any_finance_view,
    finance_type_key,
)
from datetime import datetime, timedelta, timezone
import math
from app.services.sync_service import record_deletion, trigger_delta_push

router = APIRouter(prefix="/finance", tags=["Finance"])

# ============================================================
# Yardımcı Fonksiyonlar
# ============================================================

def log_activity(
    db: Session,
    user_id: int,
    action: str,
    entity_type: str,
    entity_id: int,
    details: str = None
):
    """Aktivite logu kaydet"""
    log = ActivityLog(
        user_id=user_id,
        user_name="Sistem User",
        action_type=action,
        entity_type=entity_type,
        entity_id=entity_id,
        description=details or f"{action} on {entity_type}",
        details=details,
        status="success",
        created_at=datetime.now()
    )
    db.add(log)
    db.commit()


def calculate_customer_balance(db: Session, customer_name: str, user_id: int) -> dict:
    """
    Müşteri bazında bakiye hesapla (yalnızca ilgili bayinin işlemlerinden)

    Formula:
    - Total Debt: transaction_type="borç" olan tüm işlemlerin toplamı
    - Total Paid: transaction_type="ödeme" olan tüm işlemlerin toplamı
    - Balance: total_debt - total_paid (pozitif=borçlu, negatif=alacak)

    Returns:
        dict: {total_debt, total_paid, balance}
    """
    # Borçları topla
    total_debt = db.query(
        func.sum(Transaction.amount)
    ).filter(
        and_(
            Transaction.user_id == user_id,
            Transaction.customer_name == customer_name,
            Transaction.transaction_type.in_(["borç", "debt"])
        )
    ).scalar() or 0.0

    # Ödemeleri topla
    total_paid = db.query(
        func.sum(Transaction.amount)
    ).filter(
        and_(
            Transaction.user_id == user_id,
            Transaction.customer_name == customer_name,
            Transaction.transaction_type.in_(["ödeme", "payment"])
        )
    ).scalar() or 0.0

    balance = total_debt - total_paid

    return {
        "total_debt": total_debt,
        "total_paid": total_paid,
        "balance": balance
    }


# ============================================================
# 1. POST /api/v1/finance/transactions - Yeni İşlem Oluştur
# ============================================================

@router.post(
    "/transactions",
    response_model=TransactionCreateResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Yeni İşlem Oluştur",
    description="Satış, borç veya ödeme işlemi oluştur"
)
async def create_transaction(
    request: Request,
    transaction_data: TransactionCreateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    # Yetki: tipinin ekleme (add) izni olmalı
    require_finance_action(current_user, transaction_data.transaction_type, "add")
    # Paket kotası kontrolü (süper admin muaf)
    from app.services.subscription import check_quota
    quota_err = check_quota(db, current_user, "transaction")
    if quota_err:
        raise HTTPException(status_code=402, detail=quota_err)

    """
    Yeni bir finansal işlem oluştur

    ## İşlem Türleri:
    - satış (sale): Ürün satışı
    - borç (debt): Müşteri borcu
    - ödeme (payment): Borç ödemesi

    ## İşlem Adımları:
    1. İşlem türünü doğrula
    2. Eğer satış ise, ürünleri kontrol et ve stoğu azalt
    3. İşlem kaydını oluştur
    4. ActivityLog'a kaydet
    5. Oluşturulan işlemi döndür

    ## Satış Davranışı:
    - products listesi gönderilirse, ürünler otomatik olarak stoğundan düşülür
    - Ürün yeterli stok yoksa 400 hatası
    - Amount alanı otomatik olarak ürün toplam fiyatından hesaplanır

    Args:
        transaction_data: İşlem bilgileri
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        TransactionCreateResponse: Oluşturulan işlem

    Raises:
        HTTPException: 400 (Geçersiz işlem türü, yetersiz stok)
    """
    # 1. İşlem türünü doğrula
    valid_types = [
        "satış", "sale",
        "borç", "debt",
        "ödeme", "payment",
        "gider", "expense",      # Firma borçları
        "senet",                  # Senetler
        "kredi", "loan",          # Krediler
        "garanti",                # Garanti belgeleri
    ]
    if transaction_data.transaction_type not in valid_types:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Geçersiz işlem türü. Geçerli türler: {', '.join(valid_types)}"
        )

    # 2. Satış ise ürünleri işle
    products_for_response = []
    vehicle_id = getattr(transaction_data, "vehicle_id", None)

    if transaction_data.transaction_type in ["satış", "sale"] and transaction_data.products:
        # Araç satışı ise aracın bu kullanıcıya ait olduğunu doğrula
        if vehicle_id:
            vehicle = db.query(Vehicle).filter(
                Vehicle.id == vehicle_id,
                Vehicle.user_id == data_owner_id(current_user)
            ).first()
            if not vehicle:
                raise HTTPException(400, "Araç bulunamadı.")

        for product_item in transaction_data.products:
            product_id = product_item.get("product_id")
            quantity = product_item.get("quantity", 1)
            # Negatif/sıfır quantity: stok manipülasyonu engeli
            if not isinstance(quantity, int) or quantity < 1:
                try:
                    from app.services.alert_service import trigger_alert
                    from app.utils.security import get_client_ip as _gcip
                    trigger_alert(
                        "NEGATIVE_QTY_ATTEMPT",
                        _gcip(request),
                        f"Geçersiz miktar={quantity}, ürün_id={product_id}, kullanıcı={current_user.id}",
                        user_id=current_user.id,
                    )
                except Exception:
                    pass
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Geçersiz miktar: {quantity}. Miktar en az 1 olmalı.",
                )

            product = db.query(Product).filter(
                and_(Product.id == product_id, Product.user_id == data_owner_id(current_user))
            ).first()

            if not product:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Ürün bulunamadı (ID: {product_id})"
                )

            if vehicle_id:
                # Araç satışı: araç envanterinden atomik düş
                vi_upd = db.execute(
                    text(
                        "UPDATE vehicle_items SET quantity = quantity - :qty "
                        "WHERE vehicle_id = :vid AND product_id = :pid AND quantity >= :qty"
                    ),
                    {"qty": quantity, "vid": vehicle_id, "pid": product_id},
                )
                if vi_upd.rowcount == 0:
                    vi = db.query(VehicleItem).filter(
                        VehicleItem.vehicle_id == vehicle_id,
                        VehicleItem.product_id == product_id,
                    ).first()
                    have = vi.quantity if vi else 0
                    raise HTTPException(
                        400,
                        f"Araçta yeterli ürün yok: {product.name} (Araçta: {have}, İstenen: {quantity})"
                    )
            else:
                # Depo satışı: atomik stok düş — pgLogical-proof
                upd = db.execute(
                    text(
                        "UPDATE products SET quantity = quantity - :qty, updated_at = NOW() "
                        "WHERE id = :id AND user_id = :uid AND quantity >= :qty"
                    ),
                    {"qty": quantity, "id": product_id, "uid": data_owner_id(current_user)},
                )
                if upd.rowcount == 0:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"Yetersiz stok: {product.name} (İstenen: {quantity})",
                    )
                db.expire(product)

            # Response için ürün bilgisi
            products_for_response.append(ProductInTransaction(
                product_id=product_id,
                product_name=product.name,
                quantity=quantity,
                unit_price=product.price,
                total_price=product.price * quantity
            ))

    # 3. İşlem kaydını oluştur (notes alanı veritabanında description sütununda saklanır)
    new_transaction = Transaction(vehicle_id=vehicle_id,
        transaction_type=transaction_data.transaction_type,
        customer_name=transaction_data.customer_name,
        amount=transaction_data.amount,
        currency=transaction_data.currency or "TRY",
        kdv_rate=getattr(transaction_data, "kdv_rate", 0) or 0,
        description=transaction_data.notes or f"{transaction_data.transaction_type}: {transaction_data.customer_name}",
        user_id=data_owner_id(current_user),
        created_at=datetime.now(),
        updated_at=datetime.now()
    )

    db.add(new_transaction)
    db.flush()
    db.commit()
    db.refresh(new_transaction)

    # 4. ActivityLog'a kaydet
    log_activity(
        db=db,
        user_id=data_owner_id(current_user),
        action="create",
        entity_type="transaction",
        entity_id=new_transaction.id,
        details=f"{new_transaction.transaction_type}: {new_transaction.customer_name} - ₺{new_transaction.amount}"
    )

    # 5. Response oluştur
    response = TransactionResponse(
        id=new_transaction.id,
        transaction_type=new_transaction.transaction_type,
        customer_name=new_transaction.customer_name,
        amount=new_transaction.amount,
        currency=new_transaction.currency or "TRY",
        kdv_rate=float(new_transaction.kdv_rate or 0),
        image_url=new_transaction.image_url,
        products=products_for_response if products_for_response else None,
        created_at=new_transaction.created_at,
        updated_at=new_transaction.updated_at,
        notes=new_transaction.description
    )

    return TransactionCreateResponse(transaction=response)


# ============================================================
# 2. GET /api/v1/finance/transactions - İşlem Listele
# ============================================================

@router.get(
    "/transactions",
    response_model=TransactionListResponse,
    status_code=status.HTTP_200_OK,
    summary="İşlem Listele",
    description="Tüm işlemleri listele, filtrele ve sayfalara böl"
)
async def list_transactions(
    transaction_type: str = Query(None, description="satış, borç, ödeme"),
    ledger_type: str = Query(None, description="Cari defter grubu (borç/gider/senet/kredi); ödeme dahil"),
    customer_name: str = Query(None, description="Müşteri adı ara (tam eşleşme istemiyorsa exact=false)"),
    exact_customer: bool = Query(False, description="True ise customer_name tam eşleşme"),
    days: int = Query(30, ge=1, description="Son kaç gündeki işlemler"),
    start_date: str = Query(None, description="ISO datetime; verilirse days yerine bu kullanılır"),
    page: int = Query(1, ge=1, description="Sayfa numarası"),
    page_size: int = Query(20, ge=1, le=100, description="Sayfa başına işlem sayısı"),
    _federation: str = Query(None, description="İç: federe istek bayrağı — döngüyü önler"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Yetki: spesifik tip filtresi varsa o tipin görüntüleme izni;
    # yoksa en az bir finans tipi izni
    if transaction_type:
        require_finance_action(current_user, transaction_type, "view")
    elif ledger_type:
        require_finance_action(current_user, ledger_type, "view")
    else:
        require_any_finance_view(current_user)
    """
    İşlemleri listele - Filter ve Pagination

    ## Filtreleme Seçenekleri:
    - transaction_type: satış, borç, ödeme (opsiyonel)
    - customer_name: Müşteri adı arama (opsiyonel)
    - days: Son kaç gündeki işlemler (default: 30)

    ## Pagination:
    - page: Sayfa numarası (1'den başlayan)
    - page_size: Her sayfada kaç işlem (1-100, default: 20)

    ## Örnek İstekler:
    - GET /finance/transactions?days=7 → Son 7 gün
    - GET /finance/transactions?transaction_type=satış → Sadece satışlar
    - GET /finance/transactions?customer_name=Mehmet → Mehmet ile işlemler
    """
    # 1. Base query (yalnızca bu bayinin işlemleri)
    query = db.query(Transaction).filter(Transaction.user_id == data_owner_id(current_user))

    # 2. Tarih filtresi (start_date öncelikli; aksi halde days)
    cutoff = None
    if start_date:
        try:
            cutoff = datetime.fromisoformat(start_date.replace("Z", "+00:00"))
            if cutoff.tzinfo is None:
                cutoff = cutoff.replace(tzinfo=timezone.utc)
        except ValueError:
            cutoff = None
    if cutoff is None and days:
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    if cutoff is not None:
        query = query.filter(Transaction.created_at >= cutoff)

    # 3. İşlem türü filtresi
    if transaction_type:
        query = query.filter(Transaction.transaction_type == transaction_type)
    elif ledger_type:
        debt_types = _resolve_type_group(ledger_type)
        allowed = list(debt_types) + PAYMENT_TYPES
        query = query.filter(Transaction.transaction_type.in_(allowed))

    # 4. Müşteri adı filtresi
    if customer_name:
        if exact_customer:
            query = query.filter(Transaction.customer_name == customer_name)
        else:
            query = query.filter(Transaction.customer_name.ilike(f"%{customer_name}%"))

    # 5. Toplam işlem sayısı
    total = query.count()
    total_pages = math.ceil(total / page_size)

    # 6. Sıralama (en yeni önce)
    query = query.order_by(Transaction.created_at.desc())

    # 7. Pagination
    skip = (page - 1) * page_size
    transactions = query.offset(skip).limit(page_size).all()

    # 8. Response nesneleri oluştur
    items = []
    total_amount = 0

    for transaction in transactions:
        total_amount += transaction.amount

        response_item = TransactionResponse(
            id=transaction.id,
            transaction_type=transaction.transaction_type,
            customer_name=transaction.customer_name,
            amount=transaction.amount,
            currency=transaction.currency or "TRY",
            kdv_rate=float(transaction.kdv_rate or 0),
            image_url=transaction.image_url,
            created_at=transaction.created_at,
            updated_at=transaction.updated_at,
            notes=transaction.description
        )
        items.append(response_item)

    # 9. Federe okuma — diğer sunuculardaki benzersiz işlemleri ekle
    if not _federation:
        try:
            from app.services.federation_service import federated_fetch
            params = {"page_size": page_size, "days": days}
            if transaction_type:
                params["transaction_type"] = transaction_type
            remote = federated_fetch(db, "/finance/transactions", params)
            if remote:
                local_ids = {item.id for item in items}
                for r in remote:
                    if r.get("id") not in local_ids:
                        items.append(r)
                        total += 1
        except Exception as e:
            print(f"[FED/transactions] {e}")

    return TransactionListResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
        total_amount=total_amount,
        transaction_type_filter=transaction_type
    )


# ============================================================
# 3. GET /api/v1/finance/transactions/{transaction_id} - İşlem Detayı
# ============================================================

@router.get(
    "/transactions/{transaction_id}",
    response_model=TransactionResponse,
    status_code=status.HTTP_200_OK,
    summary="İşlem Detayını Getir",
    description="Belirli bir işlemin tüm bilgilerini göster"
)
async def get_transaction(
    transaction_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Lookup öncesi en az bir finans view izni gerekli; tipi bulduktan sonra spesifik kontrol yapılır
    require_any_finance_view(current_user)
    """
    Tek bir işlemin detaylı bilgilerini getir

    Args:
        transaction_id: İşlem ID
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        TransactionResponse: İşlem detayları

    Raises:
        HTTPException: 404 (İşlem bulunamadı)
    """
    transaction = db.query(Transaction).filter(
        and_(Transaction.id == transaction_id, Transaction.user_id == data_owner_id(current_user))
    ).first()

    if not transaction:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"İşlem bulunamadı (ID: {transaction_id})"
        )

    # Spesifik tip kontrolü: çalışan sadece izinli olduğu finans alt tipini görebilir
    require_finance_action(current_user, transaction.transaction_type, "view")

    return TransactionResponse(
        id=transaction.id,
        transaction_type=transaction.transaction_type,
        customer_name=transaction.customer_name,
        amount=transaction.amount,
        currency=transaction.currency or "TRY",
        kdv_rate=float(transaction.kdv_rate or 0),
        image_url=transaction.image_url,
        created_at=transaction.created_at,
        updated_at=transaction.updated_at,
        notes=transaction.description
    )


# ============================================================
# 4. PUT /api/v1/finance/transactions/{transaction_id} - İşlem Güncelle
# ============================================================

@router.put(
    "/transactions/{transaction_id}",
    response_model=TransactionResponse,
    status_code=status.HTTP_200_OK,
    summary="İşlem Güncelle",
    description="İşlem bilgilerini güncelle"
)
async def update_transaction(
    transaction_id: int,
    transaction_data: TransactionUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    require_any_finance_view(current_user)
    """
    İşlem bilgilerini güncelle

    ## Güncellenebilir Alanlar:
    - customer_name: Müşteri adı
    - amount: İşlem tutarı
    - notes: Açıklamalar

    ## Uyarı:
    - transaction_type değiştirilemez (İşlem türü sabitlenir)
    - Satış işlemleri için stok değişiklikleri otomatik yönetilir

    Args:
        transaction_id: Güncellenecek işlem ID
        transaction_data: Güncellenecek alanlar
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        TransactionResponse: Güncellenmiş işlem

    Raises:
        HTTPException: 404 (İşlem bulunamadı)
    """
    transaction = db.query(Transaction).filter(
        and_(Transaction.id == transaction_id, Transaction.user_id == data_owner_id(current_user))
    ).first()

    if not transaction:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"İşlem bulunamadı (ID: {transaction_id})"
        )

    # Spesifik tip kontrolü: çalışan ancak izinli olduğu finans alt tipini güncelleyebilir
    require_finance_action(current_user, transaction.transaction_type, "edit")

    # Sadece belirtilen alanları güncelle (notes → description map'lenir)
    update_data = transaction_data.dict(exclude_unset=True)

    for field, value in update_data.items():
        if value is None:
            continue
        if field == "notes":
            transaction.description = value
        else:
            setattr(transaction, field, value)

    transaction.updated_at = datetime.now()
    db.add(transaction)
    db.commit()
    db.refresh(transaction)

    # ActivityLog'a kaydet
    log_activity(
        db=db,
        user_id=data_owner_id(current_user),
        action="update",
        entity_type="transaction",
        entity_id=transaction.id,
        details=f"İşlem güncellendi: {list(update_data.keys())}"
    )

    return TransactionResponse(
        id=transaction.id,
        transaction_type=transaction.transaction_type,
        customer_name=transaction.customer_name,
        amount=transaction.amount,
        currency=transaction.currency or "TRY",
        kdv_rate=float(transaction.kdv_rate or 0),
        image_url=transaction.image_url,
        created_at=transaction.created_at,
        updated_at=transaction.updated_at,
        notes=transaction.description
    )


# ============================================================
# 5. DELETE /api/v1/finance/transactions/{transaction_id} - İşlem Sil
# ============================================================

@router.delete(
    "/transactions/{transaction_id}",
    status_code=status.HTTP_200_OK,
    summary="İşlem Sil",
    description="İşlem kaydını sil"
)
async def delete_transaction(
    transaction_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    require_any_finance_view(current_user)
    """
    İşlem kaydını sil

    ## Uyarı:
    - Satış işlemi silinirse, stok otomatik olarak geri eklenmez
    - Silme işlemi ActivityLog'a kaydedilir
    - Bu işlem geri alınamaz

    Args:
        transaction_id: Silinecek işlem ID
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        dict: Silme onayı

    Raises:
        HTTPException: 404 (İşlem bulunamadı)
    """
    transaction = db.query(Transaction).filter(
        and_(Transaction.id == transaction_id, Transaction.user_id == data_owner_id(current_user))
    ).first()

    if not transaction:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"İşlem bulunamadı (ID: {transaction_id})"
        )

    # Spesifik tip kontrolü: çalışan ancak izinli olduğu finans alt tipinden silebilir
    require_finance_action(current_user, transaction.transaction_type, "delete")

    transaction_type = transaction.transaction_type
    customer_name = transaction.customer_name

    record_deletion(db, "transactions", transaction.id)
    db.delete(transaction)
    db.commit()
    trigger_delta_push()

    log_activity(
        db=db,
        user_id=data_owner_id(current_user),
        action="delete",
        entity_type="transaction",
        entity_id=transaction_id,
        details=f"İşlem silindi: {transaction_type} - {customer_name}"
    )

    return {
        "message": "İşlem başarıyla silindi",
        "transaction_id": transaction_id
    }


# ============================================================
# 6. GET /api/v1/finance/balance/{customer_name} - Müşteri Bakiyesi
# ============================================================

@router.get(
    "/balance/{customer_name}",
    response_model=BalanceResponse,
    status_code=status.HTTP_200_OK,
    summary="Müşteri Bakiyesi",
    description="Belirli bir müşterinin borç/ödeme bakiyesini getir"
)
async def get_customer_balance(
    customer_name: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    require_any_finance_view(current_user)
    """
    Müşteri bazında bakiye bilgisi

    ## Bakiye Hesabı:
    - Total Debt: Müşteri borçlarının toplamı
    - Total Paid: Müşteri ödemelerinin toplamı
    - Balance: net bakiye (borç - ödeme)
      * Pozitif = Müşteri borçlu
      * Negatif = Müşteriye borçlu (ön ödeme vb)

    Args:
        customer_name: Müşteri adı
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        BalanceResponse: Müşteri bakiyesi bilgileri
    """
    # 1. Bakiye hesapla (yalnızca bu bayinin işlemlerinden)
    balance_info = calculate_customer_balance(db, customer_name, data_owner_id(current_user))

    # 2. İşlem sayısı ve son işlem tarihini al
    transactions = db.query(Transaction).filter(
        and_(
            Transaction.user_id == data_owner_id(current_user),
            Transaction.customer_name == customer_name,
        )
    ).order_by(Transaction.created_at.desc()).all()

    last_transaction = transactions[0].created_at if transactions else None
    transaction_count = len(transactions)

    return BalanceResponse(
        customer_name=customer_name,
        total_debt=balance_info["total_debt"],
        total_paid=balance_info["total_paid"],
        balance=balance_info["balance"],
        transaction_count=transaction_count,
        last_transaction=last_transaction
    )


# ============================================================
# 7. GET /api/v1/finance/summary - Finansman Özeti
# ============================================================

@router.get(
    "/summary",
    response_model=FinancialSummaryResponse,
    status_code=status.HTTP_200_OK,
    summary="Finansman Özeti",
    description="Genel finansman durumu özeti"
)
async def get_financial_summary(
    days: int = Query(None, ge=1, description="Son kaç gündeki veriler"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    require_any_finance_view(current_user)
    """
    Genel finansman özeti

    ## Başlıklar:
    - Total Sales: Toplam satış tutarı
    - Total Debt: Müşteri borçlarının toplamı
    - Total Paid: Yapılan ödemelerin toplamı
    - Net Balance: net finansman durumu
    - Transaction Count: Toplam işlem sayısı
    - Unique Customers: Kaç müşteri ile işlem yapıldı

    ## Period Filtresi (opsiyonel):
    - Belirtilmediyse: Tüm zamanı (all_time)
    - days=7: Son 7 gün
    - days=30: Son 30 gün

    Args:
        days: Filtreleme süresi (opsiyonel)
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        FinancialSummaryResponse: Finansman özeti
    """
    # 1. Base query (yalnızca bu bayinin işlemleri)
    query = db.query(Transaction).filter(Transaction.user_id == data_owner_id(current_user))

    # 2. Tarih filtresi
    period = "all_time"
    start_date = None
    if days:
        start_date = datetime.now(timezone.utc) - timedelta(days=days)
        query = query.filter(Transaction.created_at >= start_date)
        period = f"last_{days}_days"

    # Tüm aggregate sorgularda kullanılacak ortak filtreler (bayi + opsiyonel tarih)
    base_filters = [Transaction.user_id == data_owner_id(current_user)]
    if start_date is not None:
        base_filters.append(Transaction.created_at >= start_date)

    # 3. Satışları topla
    total_sales = db.query(func.sum(Transaction.amount)).filter(
        and_(
            Transaction.transaction_type.in_(["satış", "sale"]),
            *base_filters,
        )
    ).scalar() or 0.0

    # 4. Borçları topla
    total_debt = db.query(func.sum(Transaction.amount)).filter(
        and_(
            Transaction.transaction_type.in_(["borç", "debt"]),
            *base_filters,
        )
    ).scalar() or 0.0

    # 5. Ödemeleri topla
    total_paid = db.query(func.sum(Transaction.amount)).filter(
        and_(
            Transaction.transaction_type.in_(["ödeme", "payment"]),
            *base_filters,
        )
    ).scalar() or 0.0

    # 6. Net bakiye
    net_balance = total_sales - total_debt + total_paid

    # 7. İstatistikler
    all_transactions = query.all()
    total_transactions = len(all_transactions)

    unique_customers = db.query(
        func.count(func.distinct(Transaction.customer_name))
    ).filter(and_(*base_filters)).scalar() or 0

    return FinancialSummaryResponse(
        total_sales=total_sales,
        total_debt=total_debt,
        total_paid=total_paid,
        net_balance=net_balance,
        total_transactions=total_transactions,
        unique_customers=unique_customers,
        period=period
    )


# ============================================================
# 8-11. Cari (müşteri/kişi) bazlı yönetim endpoint'leri
# ============================================================

CARI_TYPE_GROUPS = {
    "borç":   ["borç", "debt"],
    "gider":  ["gider", "expense"],
    "senet":  ["senet"],
    "kredi":  ["kredi", "loan"],
    "garanti": ["garanti"],
}
PAYMENT_TYPES = ["ödeme", "payment"]


def _resolve_type_group(transaction_type: str) -> list[str]:
    """Verilen ana tipi (ve kısa kodları) eş anlamlılarıyla genişletir.

    Bilinmeyen tipte boş liste döner; çağıran endpoint 400 atmalıdır.
    """
    if not transaction_type:
        return []
    base = CARI_TYPE_GROUPS.get(transaction_type)
    if base:
        return base
    for group in CARI_TYPE_GROUPS.values():
        if transaction_type in group:
            return group
    return []


@router.get(
    "/customers/summary",
    status_code=status.HTTP_200_OK,
    summary="Cari (müşteri) özet listesi",
    description="Belirtilen işlem tipinde her müşteri için tek satır özet döner.",
)
async def list_customer_summaries(
    transaction_type: str = Query(..., description="borç, gider, senet, kredi, garanti"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_finance_action(current_user, transaction_type, "view")
    """
    Her müşteri için: ad, para birimi, ilk/son işlem tarihi, işlem sayısı,
    toplam borç, toplam ödeme, net bakiye.

    Borç tipleri (`borç`, `gider`, `senet`, `kredi`, `garanti`) ile birlikte
    `ödeme/payment` kayıtları da hesaba katılır; böylece "toplam borç" =
    borç toplamı − ödeme toplamı (net kalan) olur.
    """
    debt_types = _resolve_type_group(transaction_type)
    if not debt_types:
        raise HTTPException(status_code=400, detail="Geçersiz işlem türü")

    relevant_types = list(set(debt_types + PAYMENT_TYPES))

    rows = db.query(Transaction).filter(
        and_(
            Transaction.user_id == data_owner_id(current_user),
            Transaction.transaction_type.in_(relevant_types),
        )
    ).order_by(Transaction.created_at.asc()).all()

    bucket: dict[str, dict] = {}
    for tx in rows:
        name = (tx.customer_name or "").strip()
        if not name:
            continue
        b = bucket.setdefault(name, {
            "name": name,
            "currency": (tx.currency or "TRY").upper(),
            "first_at": tx.created_at,
            "last_at": tx.created_at,
            "txn_count": 0,
            "total_debt": 0.0,
            "total_paid": 0.0,
        })
        if float(tx.amount or 0) > 0:
            b["txn_count"] += 1
        if tx.created_at and (b["first_at"] is None or tx.created_at < b["first_at"]):
            b["first_at"] = tx.created_at
        if tx.created_at and (b["last_at"] is None or tx.created_at > b["last_at"]):
            b["last_at"] = tx.created_at
        if tx.transaction_type in PAYMENT_TYPES:
            b["total_paid"] += float(tx.amount or 0)
        else:
            b["total_debt"] += float(tx.amount or 0)

    items = []
    for b in bucket.values():
        b["balance"] = round(b["total_debt"] - b["total_paid"], 2)
        b["total_debt"] = round(b["total_debt"], 2)
        b["total_paid"] = round(b["total_paid"], 2)
        items.append(b)

    items.sort(key=lambda x: x["name"].lower())
    return {"items": items, "total": len(items), "transaction_type": transaction_type}


class _CariCreateBody(BaseModel):
    customer_name: str = Field(..., min_length=1, max_length=255)
    transaction_type: str = Field(..., description="borç, gider, senet, kredi, garanti")
    currency: str = Field(default="TRY", pattern="^(TRY|USD|EUR)$")
    notes: Optional[str] = Field(None, max_length=500)


@router.post(
    "/customers",
    status_code=status.HTTP_201_CREATED,
    summary="Cari (müşteri) oluştur",
    description="Tutarsız bir 'açılış' kaydı (amount=0) atarak yeni müşteri açar.",
)
async def create_customer(
    body: _CariCreateBody,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_finance_action(current_user, body.transaction_type, "add")
    """
    Yeni bir müşteri açılışı: ileride borç/tahsilat işlemleri eklenecek
    boş bir kart oluşturur. Aynı isimde kayıt zaten varsa hata döner.
    """
    name = body.customer_name.strip()
    if not name:
        raise HTTPException(status_code=400, detail="Müşteri adı boş olamaz")

    debt_types = _resolve_type_group(body.transaction_type)
    if not debt_types:
        raise HTTPException(status_code=400, detail="Geçersiz işlem türü")

    existing = db.query(Transaction).filter(
        and_(
            Transaction.user_id == data_owner_id(current_user),
            Transaction.customer_name == name,
            Transaction.transaction_type.in_(debt_types),
        )
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail=f"'{name}' zaten kayıtlı")

    other_debt_groups = [
        t for grp in CARI_TYPE_GROUPS.values() for t in grp if t not in debt_types
    ]
    cross = db.query(Transaction).filter(
        and_(
            Transaction.user_id == data_owner_id(current_user),
            Transaction.customer_name == name,
            Transaction.transaction_type.in_(other_debt_groups),
        )
    ).first()
    if cross:
        raise HTTPException(
            status_code=409,
            detail=(
                f"'{name}' adıyla başka bir defterde ({cross.transaction_type}) "
                "kayıt mevcut. Modüller arası karışmayı önlemek için farklı bir ad seçin."
            ),
        )

    new_tx = Transaction(
        user_id=data_owner_id(current_user),
        customer_name=name,
        transaction_type=body.transaction_type,
        amount=0.0,
        currency=(body.currency or "TRY").upper(),
        description=(body.notes or "Cari açılışı"),
        created_at=datetime.now(),
        updated_at=datetime.now(),
    )
    db.add(new_tx)
    db.commit()
    db.refresh(new_tx)

    log_activity(
        db=db, user_id=data_owner_id(current_user), action="create",
        entity_type="customer", entity_id=new_tx.id,
        details=f"Cari açıldı: {name} ({body.transaction_type})",
    )

    return {"customer_name": name, "id": new_tx.id, "currency": new_tx.currency}


class _CariRenameBody(BaseModel):
    old_name: str = Field(..., min_length=1, max_length=255)
    new_name: str = Field(..., min_length=1, max_length=255)
    transaction_type: str = Field(..., description="borç, gider, senet, kredi, garanti")
    currency: Optional[str] = Field(None, pattern="^(TRY|USD|EUR)$")
    notes: Optional[str] = Field(None, max_length=500)


@router.put(
    "/customers/rename",
    status_code=status.HTTP_200_OK,
    summary="Cari adını değiştir",
    description="Müşterinin tüm ilgili işlemlerinin customer_name'ini günceller.",
)
async def rename_customer(
    body: _CariRenameBody,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_finance_action(current_user, body.transaction_type, "edit")
    old = body.old_name.strip()
    new = body.new_name.strip()
    if not old or not new:
        raise HTTPException(status_code=400, detail="İsim boş olamaz")

    debt_types = _resolve_type_group(body.transaction_type)
    relevant = list(set(debt_types + PAYMENT_TYPES))

    rows = db.query(Transaction).filter(
        and_(
            Transaction.user_id == data_owner_id(current_user),
            Transaction.customer_name == old,
            Transaction.transaction_type.in_(relevant),
        )
    ).all()
    if not rows:
        raise HTTPException(status_code=404, detail=f"'{old}' kaydı bulunamadı")

    if new != old:
        clash = db.query(Transaction).filter(
            and_(
                Transaction.user_id == data_owner_id(current_user),
                Transaction.customer_name == new,
                Transaction.transaction_type.in_(debt_types),
            )
        ).first()
        if clash:
            raise HTTPException(status_code=400, detail=f"'{new}' adlı cari zaten var")

    cur_upper = (body.currency or "").upper() if body.currency else None
    has_opening = False
    for tx in rows:
        tx.customer_name = new
        if cur_upper:
            tx.currency = cur_upper
        if tx.amount == 0:
            has_opening = True
            if body.notes is not None:
                tx.description = body.notes.strip() or "Cari açılışı"
        tx.updated_at = datetime.now()
        db.add(tx)

    # Açılış kaydı yoksa ve notes/currency güncellenmek istendiyse yeni bir
    # açılış kaydı yaratmıyoruz (mevcut işlemler bunu zaten taşır).
    db.commit()

    log_activity(
        db=db, user_id=data_owner_id(current_user), action="update",
        entity_type="customer", entity_id=0,
        details=f"Cari yeniden adlandırıldı: {old} → {new} ({len(rows)} kayıt)",
    )

    return {
        "old_name": old, "new_name": new,
        "updated_count": len(rows), "had_opening": has_opening,
    }


@router.delete(
    "/customers/{customer_name}",
    status_code=status.HTTP_200_OK,
    summary="Cari sil",
    description="Müşterinin verilen tipteki tüm işlemlerini (ve bu kart altındaki ödemeleri) siler.",
)
async def delete_customer(
    customer_name: str,
    transaction_type: str = Query(..., description="borç, gider, senet, kredi, garanti"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_finance_action(current_user, transaction_type, "delete")
    name = customer_name.strip()
    debt_types = _resolve_type_group(transaction_type)
    relevant = list(set(debt_types + PAYMENT_TYPES))

    rows = db.query(Transaction).filter(
        and_(
            Transaction.user_id == data_owner_id(current_user),
            Transaction.customer_name == name,
            Transaction.transaction_type.in_(relevant),
        )
    ).all()
    if not rows:
        raise HTTPException(status_code=404, detail=f"'{name}' kaydı bulunamadı")

    deleted = len(rows)
    for tx in rows:
        record_deletion(db, "transactions", tx.id)
        db.delete(tx)
    db.commit()
    trigger_delta_push()

    log_activity(
        db=db, user_id=data_owner_id(current_user), action="delete",
        entity_type="customer", entity_id=0,
        details=f"Cari silindi: {name} ({deleted} işlem)",
    )

    return {"customer_name": name, "deleted_count": deleted}


# ============================================================
# DEBTOR LINK (Borçlu Slip Linki) ENDPOINTS
# ============================================================
# Bayi, müşteriye anlık bakiye gösteren süreli/süresiz public link
# oluşturur. Müşteri linki açtığında auth gerekmeden o anki borç,
# ödeme ve net bakiyeyi görür (public.py içinde).
# ============================================================

import secrets as _secrets
import urllib.parse as _urlparse
from app.models import DebtorLink


class DebtorLinkCreateRequest(BaseModel):
    customer_name: str = Field(..., min_length=1, max_length=255)
    expires_in_days: Optional[int] = Field(None, ge=0, le=3650, description="0/None = süresiz")
    base_url: Optional[str] = Field(None, description="Opsiyonel client hint; backend kendi origin'ini tercih eder.")


class DebtorLinkOut(BaseModel):
    id: int
    customer_name: str
    public_token: str
    public_url: str
    wa_url: Optional[str] = None
    expires_at: Optional[datetime] = None
    last_viewed_at: Optional[datetime] = None
    view_count: int
    created_at: datetime

    class Config:
        from_attributes = True


def _build_debtor_links_response(
    rows, base_url: Optional[str], current_user: User, db: Session
) -> list[DebtorLinkOut]:
    base = (base_url or "").rstrip("/")
    out: list[DebtorLinkOut] = []
    bayi_name = current_user.company_name or current_user.full_name or "Bayi"
    for r in rows:
        public_url = f"{base}/borc/{r.public_token}" if base else f"/borc/{r.public_token}"
        # WhatsApp link — müşterinin telefonunu transactions'tan çek
        phone = (
            db.query(Transaction.customer_phone)
            .filter(
                Transaction.user_id == r.user_id,
                Transaction.customer_name == r.customer_name,
                Transaction.customer_phone.isnot(None),
            )
            .order_by(Transaction.created_at.desc())
            .first()
        )
        wa_url: Optional[str] = None
        phone_str = phone[0] if phone else None
        if phone_str:
            from app.api.warranty import _normalize_phone_for_wa
            wa_phone = _normalize_phone_for_wa(phone_str)
            if wa_phone:
                text = (
                    f"Merhaba {r.customer_name},\n"
                    f"Bizdeki cari hesabınızı anlık olarak şu linkten görüntüleyebilirsiniz:\n"
                    f"{public_url}\n\n"
                    f"— {bayi_name}"
                )
                wa_url = f"https://wa.me/{wa_phone}?text={_urlparse.quote(text)}"
        out.append(DebtorLinkOut(
            id=r.id,
            customer_name=r.customer_name,
            public_token=r.public_token,
            public_url=public_url,
            wa_url=wa_url,
            expires_at=r.expires_at,
            last_viewed_at=r.last_viewed_at,
            view_count=r.view_count,
            created_at=r.created_at,
        ))
    return out


@router.post("/debtor-links", response_model=DebtorLinkOut, status_code=201)
async def create_debtor_link(
    payload: DebtorLinkCreateRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_any_finance_view(current_user)
    owner = data_owner_id(current_user)

    # Müşteri var mı? (en az bir transaction'ı olmalı)
    exists = db.query(Transaction.id).filter(
        Transaction.user_id == owner,
        Transaction.customer_name == payload.customer_name,
    ).first()
    if not exists:
        raise HTTPException(status_code=404, detail=f"'{payload.customer_name}' isimli müşteri bulunamadı.")

    expires_at = None
    if payload.expires_in_days and payload.expires_in_days > 0:
        expires_at = datetime.now() + timedelta(days=payload.expires_in_days)

    token = _secrets.token_urlsafe(24)

    link = DebtorLink(
        user_id=owner,
        customer_name=payload.customer_name,
        public_token=token,
        expires_at=expires_at,
    )
    db.add(link)
    db.commit()
    db.refresh(link)

    log_activity(
        db=db, user_id=owner, action="create",
        entity_type="debtor_link", entity_id=link.id,
        details=f"Borç linki: {payload.customer_name} ({payload.expires_in_days or 'süresiz'} gün)",
    )

    from app.api.warranty import _safe_base_url
    safe_base = _safe_base_url(request, payload.base_url)
    return _build_debtor_links_response([link], safe_base, current_user, db)[0]


@router.get("/debtor-links", response_model=list[DebtorLinkOut])
async def list_debtor_links(
    request: Request,
    customer_name: Optional[str] = None,
    base_url: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_any_finance_view(current_user)
    owner = data_owner_id(current_user)
    q = db.query(DebtorLink).filter(DebtorLink.user_id == owner)
    if customer_name:
        q = q.filter(DebtorLink.customer_name == customer_name)
    rows = q.order_by(DebtorLink.created_at.desc()).limit(500).all()
    from app.api.warranty import _safe_base_url
    safe_base = _safe_base_url(request, base_url)
    return _build_debtor_links_response(rows, safe_base, current_user, db)


@router.delete("/debtor-links/{link_id}", status_code=204)
async def delete_debtor_link(
    link_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_any_finance_view(current_user)
    owner = data_owner_id(current_user)
    link = db.query(DebtorLink).filter(
        DebtorLink.id == link_id, DebtorLink.user_id == owner
    ).first()
    if not link:
        raise HTTPException(status_code=404, detail="Link bulunamadı.")
    record_deletion(db, "debtor_links", link.id)
    db.delete(link)
    db.commit()
    return None
