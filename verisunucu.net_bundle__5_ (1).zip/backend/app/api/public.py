"""
Public Router — auth gerekmeyen müşteri sayfaları.

  - GET /public/warranty/{token} → garanti belgesi detayı (müşteri görür)
  - GET /public/debtor/{token}   → cari hesap özeti + işlem listesi

Süresi geçmiş debtor linki 410 (Gone) döner.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models import User, Warranty, DebtorLink, Transaction
from app.models.site_info import SiteInfo

router = APIRouter(prefix="/public", tags=["Public"])


# ============================================================
# WARRANTY
# ============================================================

class PublicWarrantyOut(BaseModel):
    product_name: str
    product_image_url: Optional[str] = None
    customer_name: str
    duration_label: str
    duration_days: int
    start_date: datetime
    end_date: datetime
    is_expired: bool
    days_remaining: int
    notes: Optional[str] = None
    bayi_name: str
    bayi_phone: Optional[str] = None


@router.get("/warranty/{token}", response_model=PublicWarrantyOut)
def public_warranty(token: str, db: Session = Depends(get_db)):
    w = db.query(Warranty).filter(Warranty.public_token == token).first()
    if not w:
        raise HTTPException(status_code=404, detail="Garanti belgesi bulunamadı veya kaldırıldı.")

    now = datetime.now(timezone.utc)
    end = w.end_date if w.end_date.tzinfo else w.end_date.replace(tzinfo=timezone.utc)
    is_expired = end < now
    days_remaining = max(0, (end - now).days)

    # Görüntülenme istatistiği — debtor_links ile aynı pattern.
    # Atomik UPDATE: concurrent okumalar arasında increment'lerin kaybolmaması için
    # `view_count = view_count + 1` SQL ifadesi kullanılır (read-modify-write yerine).
    # Hata olursa müşteri sayfayı yine de görür; istatistik kritik değildir.
    try:
        from sqlalchemy import update as _upd
        db.execute(
            _upd(Warranty)
            .where(Warranty.id == w.id)
            .values(view_count=(Warranty.view_count + 1), last_viewed_at=now)
        )
        db.commit()
    except Exception:
        db.rollback()

    bayi = db.query(User).filter(User.id == w.user_id).first()
    bayi_name = (bayi.company_name if bayi else None) or (bayi.full_name if bayi else None) or "Bayi"
    bayi_phone = bayi.company_phone if bayi else None

    return PublicWarrantyOut(
        product_name=w.product_name,
        product_image_url=w.product_image_url,
        customer_name=w.customer_name,
        duration_label=w.duration_label,
        duration_days=w.duration_days,
        start_date=w.start_date,
        end_date=w.end_date,
        is_expired=is_expired,
        days_remaining=days_remaining,
        notes=w.notes,
        bayi_name=bayi_name,
        bayi_phone=bayi_phone,
    )


# ============================================================
# DEBTOR (Borçlu cari)
# ============================================================

DEBT_TYPES = {"borç", "borc", "debt", "veresiye", "satış", "sale", "senet", "kredi"}
PAYMENT_TYPES = {"ödeme", "odeme", "payment", "tahsilat"}


class PublicTransactionItem(BaseModel):
    id: int
    transaction_type: str
    amount: float
    currency: str
    description: Optional[str] = None
    created_at: datetime


class PublicDebtorOut(BaseModel):
    customer_name: str
    bayi_name: str
    bayi_phone: Optional[str] = None
    total_debt: float
    total_paid: float
    balance: float
    transaction_count: int
    transactions: List[PublicTransactionItem]
    expires_at: Optional[datetime] = None
    server_time: datetime


@router.get("/debtor/{token}", response_model=PublicDebtorOut)
def public_debtor(token: str, db: Session = Depends(get_db)):
    link = db.query(DebtorLink).filter(DebtorLink.public_token == token).first()
    if not link:
        raise HTTPException(status_code=404, detail="Bu link bulunamadı veya silinmiş.")

    now = datetime.now(timezone.utc)
    if link.expires_at:
        exp = link.expires_at if link.expires_at.tzinfo else link.expires_at.replace(tzinfo=timezone.utc)
        if exp < now:
            raise HTTPException(status_code=410, detail="Bu linkin süresi dolmuş. Yeni bir link talep ediniz.")

    rows = (
        db.query(Transaction)
        .filter(
            Transaction.user_id == link.user_id,
            Transaction.customer_name == link.customer_name,
        )
        .order_by(Transaction.created_at.desc())
        .limit(500)
        .all()
    )

    total_debt = 0.0
    total_paid = 0.0
    items: List[PublicTransactionItem] = []
    for r in rows:
        t = (r.transaction_type or "").lower()
        amt = float(r.amount or 0)
        if t in DEBT_TYPES:
            total_debt += amt
        elif t in PAYMENT_TYPES:
            total_paid += amt
        items.append(PublicTransactionItem(
            id=r.id,
            transaction_type=r.transaction_type,
            amount=amt,
            currency=r.currency or "TRY",
            description=r.description,
            created_at=r.created_at,
        ))

    bayi = db.query(User).filter(User.id == link.user_id).first()
    bayi_name = (bayi.company_name if bayi else None) or (bayi.full_name if bayi else None) or "Bayi"
    bayi_phone = bayi.company_phone if bayi else None

    # Son görüntüleme zamanını atomik UPDATE ile güncelle (race-safe)
    from sqlalchemy import update as _upd
    db.execute(
        _upd(DebtorLink)
        .where(DebtorLink.id == link.id)
        .values(last_viewed_at=datetime.now(), view_count=DebtorLink.view_count + 1)
    )
    db.commit()

    return PublicDebtorOut(
        customer_name=link.customer_name,
        bayi_name=bayi_name,
        bayi_phone=bayi_phone,
        total_debt=total_debt,
        total_paid=total_paid,
        balance=total_debt - total_paid,
        transaction_count=len(rows),
        transactions=items,
        expires_at=link.expires_at,
        server_time=datetime.now(timezone.utc),
    )


# ============================================================
# SITE INFO (Hakkımızda)
# ============================================================

class PublicSiteInfoOut(BaseModel):
    company_name: Optional[str] = None
    contact_person: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    working_hours: Optional[str] = None
    about_text: Optional[str] = None
    instagram_url: Optional[str] = None
    whatsapp_number: Optional[str] = None


@router.get("/site-info", response_model=PublicSiteInfoOut)
def public_site_info(db: Session = Depends(get_db)):
    row = db.query(SiteInfo).filter(SiteInfo.id == 1).first()
    if not row:
        return PublicSiteInfoOut()
    return PublicSiteInfoOut(
        company_name=row.company_name,
        contact_person=row.contact_person,
        address=row.address,
        phone=row.phone,
        email=row.email,
        working_hours=row.working_hours,
        about_text=row.about_text,
        instagram_url=row.instagram_url,
        whatsapp_number=row.whatsapp_number,
    )
