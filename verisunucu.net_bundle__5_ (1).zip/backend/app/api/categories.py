"""
Kategori (Web Görünüm) Yönetim API'si
======================================
Her bayi (multi-tenant) kendi sidebar/dashboard kategorilerini ekler,
düzenler, siler. Kategoriler hem kısayol grid'inde hem de yan menüde
dinamik olarak listelenir.

Endpoints:
- GET    /api/v1/categories?kind=stok|finans       → Listele
- POST   /api/v1/categories                         → Yeni
- PUT    /api/v1/categories/{id}                    → Güncelle
- DELETE /api/v1/categories/{id}                    → Sil
- POST   /api/v1/categories/seed-defaults           → Varsayılanları yeniden ekle (idempotent)
"""

from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from app.utils.tenant import data_owner_id
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models import Category, Product, User
from app.schemas.category import (
    CategoryCreate,
    CategoryListResponse,
    CategoryOut,
    CategoryUpdate,
    _slugify_key,
)
from app.utils.auth import get_current_user
from app.services.sync_service import record_deletion, trigger_delta_push

router = APIRouter(prefix="/categories", tags=["Categories"])


# ============================================================
# Varsayılan kategoriler (yeni bayilere otomatik atanır)
# ============================================================

DEFAULT_STOCK = [
    {"key": "stock_general",  "name": "Genel Ürünler",     "icon": "Box",        "color_class": "text-blue-600 dark:text-blue-400",   "bg_class": "bg-blue-100 dark:bg-blue-900/30"},
    {"key": "stock_cam",      "name": "Cam Rüzgarlığı",    "icon": "Wind",       "color_class": "text-sky-600 dark:text-sky-400",     "bg_class": "bg-sky-100 dark:bg-sky-900/30"},
    {"key": "stock_kaput",    "name": "Kaput Rüzgarlığı",  "icon": "Shield",     "color_class": "text-slate-600 dark:text-slate-400", "bg_class": "bg-slate-100 dark:bg-slate-800"},
    {"key": "stock_jant",     "name": "Jant Kapağı",       "icon": "Disc",       "color_class": "text-slate-800 dark:text-slate-300", "bg_class": "bg-slate-200 dark:bg-slate-700"},
    {"key": "stock_pandizot", "name": "Pandizot",          "icon": "Layers",     "color_class": "text-purple-600 dark:text-purple-400", "bg_class": "bg-purple-100 dark:bg-purple-900/30"},
    {"key": "stock_paspas",   "name": "Paspas",            "icon": "Footprints", "color_class": "text-amber-600 dark:text-amber-400", "bg_class": "bg-amber-100 dark:bg-amber-900/30"},
    {"key": "stock_spoiler",  "name": "Spoiler",           "icon": "Car",        "color_class": "text-red-600 dark:text-red-400",     "bg_class": "bg-red-100 dark:bg-red-900/30"},
]

DEFAULT_FINANCE = [
    {"key": "fin_veresiye", "name": "Veresiye (Müşteri)", "icon": "BookOpen",   "color_class": "text-indigo-600 dark:text-indigo-400", "bg_class": "bg-indigo-100 dark:bg-indigo-900/30",
     "transaction_type": "borç",   "customer_label": "Müşteri Adı",       "amount_label": "Borç Tutarı (₺)",   "amount_tone": "red",     "allow_edit_type": False},
    {"key": "fin_firma",    "name": "Firma Borçları",     "icon": "Building2",  "color_class": "text-orange-600 dark:text-orange-400", "bg_class": "bg-orange-100 dark:bg-orange-900/30",
     "transaction_type": "gider",  "customer_label": "Firma Unvanı",      "amount_label": "Borç Tutarı (₺)",   "amount_tone": "amber",   "allow_edit_type": False},
    {"key": "fin_senet",    "name": "Senetler",           "icon": "FileText",   "color_class": "text-emerald-600 dark:text-emerald-400","bg_class": "bg-emerald-100 dark:bg-emerald-900/30",
     "transaction_type": "senet",  "customer_label": "Borçlu / Alacaklı", "amount_label": "Senet Tutarı (₺)",  "amount_tone": "indigo",  "allow_edit_type": False},
    {"key": "fin_kredi",    "name": "Krediler",           "icon": "Landmark",   "color_class": "text-amber-600 dark:text-amber-400",   "bg_class": "bg-amber-100 dark:bg-amber-900/30",
     "transaction_type": "kredi",  "customer_label": "Banka / Kurum",     "amount_label": "Kredi Tutarı (₺)",  "amount_tone": "purple",  "allow_edit_type": False},
    {"key": "fin_kasa",     "name": "Kasa Defteri",       "icon": "Calculator", "color_class": "text-slate-700 dark:text-slate-300",   "bg_class": "bg-slate-200 dark:bg-slate-700",
     "transaction_type": None,     "customer_label": "Cari",              "amount_label": "Tutar (₺)",         "amount_tone": "slate",   "allow_edit_type": True},
    # NOT: "fin_garanti" finans kategorisi (transaction_type='garanti') KALDIRILDI.
    # Garantide tutar kavramı yoktur. Garanti belgeleri için ayrı bir modül var:
    # /api/v1/warranty (modeller: app/models/warranty.py, UI: WarrantyManagementView).
    # O modül müşteri adı, telefon, süre, belge görseli, public izleme linki,
    # QR ve WhatsApp paylaşımını destekler.
]


def ensure_default_categories(db: Session, user_id: int) -> int:
    """
    Bayide hiç kategori yoksa varsayılanları oluştur. Mevcut anahtarlar atlanır
    (idempotent). Eklenen kayıt sayısını döner.
    """
    existing_keys = {
        (k, kind) for (k, kind) in db.query(Category.key, Category.kind)
        .filter(Category.user_id == user_id).all()
    }

    added = 0
    order = 10
    for spec in DEFAULT_STOCK:
        if (spec["key"], "stok") in existing_keys:
            continue
        db.add(Category(
            user_id=user_id, kind="stok", is_default=True,
            display_order=order, **spec,
        ))
        order += 10
        added += 1

    order = 10
    for spec in DEFAULT_FINANCE:
        if (spec["key"], "finans") in existing_keys:
            continue
        db.add(Category(
            user_id=user_id, kind="finans", is_default=True,
            display_order=order, **spec,
        ))
        order += 10
        added += 1

    if added:
        db.commit()
    return added


# ============================================================
# 1. LIST
# ============================================================

@router.get("", response_model=CategoryListResponse, summary="Kategorileri listele")
async def list_categories(
    kind: Optional[str] = Query(None, description="stok veya finans (boş = tümü)"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    # İlk istekte varsayılanları yükle (yalnızca gerçekten boşsa)
    has_any = db.query(Category.id).filter(Category.user_id == data_owner_id(current_user)).first()
    if not has_any:
        ensure_default_categories(db, data_owner_id(current_user))

    q = db.query(Category).filter(Category.user_id == data_owner_id(current_user))
    if kind in ("stok", "finans"):
        q = q.filter(Category.kind == kind)
    items = q.order_by(Category.kind.asc(), Category.display_order.asc(), Category.name.asc()).all()
    return CategoryListResponse(items=items, total=len(items))


# ============================================================
# 2. CREATE
# ============================================================

@router.post("", response_model=CategoryOut, status_code=status.HTTP_201_CREATED, summary="Yeni kategori")
async def create_category(
    payload: CategoryCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    key = payload.key or _slugify_key(payload.name)
    # Aynı bayide aynı kind altında aynı key yasak
    if db.query(Category.id).filter(
        Category.user_id == data_owner_id(current_user),
        Category.kind == payload.kind,
        Category.key == key,
    ).first():
        raise HTTPException(status_code=400, detail=f"Bu kategori zaten mevcut: {key}")

    cat = Category(
        user_id=data_owner_id(current_user),
        kind=payload.kind,
        key=key,
        name=payload.name.strip(),
        icon=payload.icon,
        color_class=payload.color_class,
        bg_class=payload.bg_class,
        display_order=payload.display_order,
        is_visible=payload.is_visible,
        is_default=False,
        transaction_type=payload.transaction_type,
        customer_label=payload.customer_label,
        amount_label=payload.amount_label,
        amount_tone=payload.amount_tone,
        allow_edit_type=payload.allow_edit_type,
        view_mode=payload.view_mode,
    )
    db.add(cat)
    db.commit()
    db.refresh(cat)
    return cat


# ============================================================
# 3. UPDATE
# ============================================================

@router.put("/{category_id}", response_model=CategoryOut, summary="Kategori güncelle")
async def update_category(
    category_id: int,
    payload: CategoryUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    cat = db.query(Category).filter(
        Category.id == category_id,
        Category.user_id == data_owner_id(current_user),
    ).first()
    if not cat:
        raise HTTPException(status_code=404, detail="Kategori bulunamadı")

    old_name = cat.name
    data = payload.model_dump(exclude_unset=True)
    for k, v in data.items():
        setattr(cat, k, v)

    db.commit()
    db.refresh(cat)

    # Ad değiştiyse, bu kategoriye ait ürünlerin name etiketini güncelle
    # (ürün tablosunda category alanı serbest metin olduğu için bayinin
    # önceki ad ile kayıtlı ürünleri görünmez kalmasın)
    if "name" in data and old_name and old_name != cat.name:
        db.query(Product).filter(
            Product.user_id == data_owner_id(current_user),
            Product.category == old_name,
        ).update({Product.category: cat.name}, synchronize_session=False)
        db.commit()

    return cat


# ============================================================
# 4. DELETE
# ============================================================

@router.delete("/{category_id}", summary="Kategori sil")
async def delete_category(
    category_id: int,
    move_products_to: Optional[int] = Query(None, description="Ürünleri taşıyacağımız hedef kategori ID"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    cat = db.query(Category).filter(
        Category.id == category_id,
        Category.user_id == data_owner_id(current_user),
    ).first()
    if not cat:
        raise HTTPException(status_code=404, detail="Kategori bulunamadı")

    # Bu kategoriye ait ürün varsa, taşıma hedefi belirtilmediyse uyar
    if cat.kind == "stok":
        product_count = db.query(Product.id).filter(
            Product.user_id == data_owner_id(current_user),
            Product.category == cat.name,
        ).count()

        if product_count > 0:
            if move_products_to:
                target = db.query(Category).filter(
                    Category.id == move_products_to,
                    Category.user_id == data_owner_id(current_user),
                    Category.kind == "stok",
                ).first()
                if not target:
                    raise HTTPException(status_code=400, detail="Hedef kategori bulunamadı")
                db.query(Product).filter(
                    Product.user_id == data_owner_id(current_user),
                    Product.category == cat.name,
                ).update({Product.category: target.name}, synchronize_session=False)
            else:
                raise HTTPException(
                    status_code=409,
                    detail=f"Bu kategoride {product_count} ürün var. Önce ürünleri başka kategoriye taşıyın veya silme isteğine `move_products_to` parametresi ekleyin.",
                )

    record_deletion(db, "categories", cat.id)
    db.delete(cat)
    db.commit()
    trigger_delta_push()
    return {"ok": True, "deleted_id": category_id}


# ============================================================
# 5. REORDER (atomik sıralama güncellemesi)
# ============================================================

@router.post("/reorder", summary="Kategorileri toplu yeniden sırala (atomik)")
async def reorder_categories(
    payload: dict,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    payload: {"items": [{"id": 1, "display_order": 100}, {"id": 2, "display_order": 200}]}
    Tek transaction'da çalışır; yarı-uygulanma riski yoktur.
    """
    items = payload.get("items") or []
    if not isinstance(items, list) or not items:
        raise HTTPException(status_code=400, detail="items listesi gerekli")

    ids = [int(it["id"]) for it in items if "id" in it]
    cats = db.query(Category).filter(
        Category.id.in_(ids),
        Category.user_id == data_owner_id(current_user),
    ).all()
    by_id = {c.id: c for c in cats}
    if len(by_id) != len(ids):
        raise HTTPException(status_code=404, detail="Bazı kategoriler bulunamadı veya size ait değil")

    for it in items:
        cat = by_id.get(int(it["id"]))
        if cat and "display_order" in it:
            cat.display_order = int(it["display_order"])

    db.commit()
    return {"ok": True, "updated": len(items)}


# ============================================================
# 6. SEED DEFAULTS (yeniden eklemek için)
# ============================================================

@router.post("/seed-defaults", summary="Varsayılanları (eksikse) yeniden ekle")
async def seed_defaults(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    added = ensure_default_categories(db, data_owner_id(current_user))
    return {"ok": True, "added": added}
