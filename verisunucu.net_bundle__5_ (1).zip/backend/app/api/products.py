# ============================================================
# Product Endpoints - Ürün Yönetimi API
# ============================================================
# CRUD operasyonları: Create, Read, Update, Delete
# Search, Filter ve Pagination desteği
#
# Seviye: SEVIYE 4 - Motor Odası
# Tarih: 28 Nisan 2026
# ============================================================

from fastapi import APIRouter, Depends, HTTPException, status, Query
from app.utils.tenant import data_owner_id
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, text, func
from app.core.database import get_db
from app.models import Product, User, ActivityLog, Category
from app.models.transaction import Transaction
from app.schemas.product import (
    ProductCreateRequest,
    ProductUpdateRequest,
    ProductResponse,
    ProductListResponse,
    ProductCreateResponse,
    ProductUpdateResponse,
    ProductDeleteResponse,
    CriticalStockListResponse,
    ProductStockResponse
)
from app.utils.auth import get_current_user
from app.utils.permissions import require_perm
from app.services.sync_service import record_deletion, trigger_delta_push
from datetime import datetime
from pydantic import BaseModel, Field
from typing import Optional
import math

router = APIRouter(prefix="/products", tags=["Products"])

# ============================================================
# Yardımcı Fonksiyonlar
# ============================================================

def calculate_profit_margin(price: float, cost: float) -> float:
    """
    Kar marjı hesapla
    Formula: ((price - cost) / cost) * 100

    Example:
    - price=350, cost=200
    - margin = ((350-200)/200)*100 = 75%
    """
    if cost == 0:
        return 0
    return ((price - cost) / cost) * 100


def is_critical_stock(quantity: int, min_stock_alert: int) -> bool:
    """Stok kritik seviyede mi kontrol et"""
    return quantity <= min_stock_alert


def log_activity(
    db: Session,
    user_id: int,
    action: str,
    entity_type: str,
    entity_id: int,
    details: str = None,
    status: str = "success"
):
    """
    Aktivite logu kaydet (ActivityLog modeline)

    Args:
        db: Veritabanı bağlantısı
        user_id: Kullanıcı ID
        action: Yapılan işlem (create, update, delete, view)
        entity_type: İşlem yapılan tür (product, transaction, vb)
        entity_id: İşlem yapılan öğe ID
        details: Ek detaylar (isteğe bağlı)
        status: İşlem durumu (success, failed)
    """
    log = ActivityLog(
        user_id=user_id,
        user_name="Sistem User", # We don't have current_user name here, so placeholder
        action_type=action,
        entity_type=entity_type,
        entity_id=entity_id,
        description=details or f"{action} on {entity_type}",
        details=details,
        status=status,
        created_at=datetime.now()
    )
    db.add(log)
    db.commit()


# ============================================================
# 1. POST /api/v1/products - Yeni Ürün Oluştur
# ============================================================

@router.post(
    "",
    response_model=ProductCreateResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Yeni Ürün Oluştur",
    description="Envantere yeni ürün ekle"
)
async def create_product(
    product_data: ProductCreateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    require_perm(current_user, "products.add")
    # Paket kotası kontrolü (süper admin muaf)
    from app.services.subscription import check_quota
    quota_err = check_quota(db, current_user, "product")
    if quota_err:
        raise HTTPException(status_code=402, detail=quota_err)

    """
    Yeni bir ürün oluştur ve envantere ekle

    ## İşlem Adımları:
    1. Barcode çakışması kontrol et (varsa hata dön)
    2. Yeni Product nesnesi oluştur
    3. Veritabanına kaydet
    4. ActivityLog'a oluşturma işlemi kaydet
    5. Oluşturulan ürünü döndür

    ## Doğrulama:
    - price > 0 (fiyat pozitif)
    - cost > 0 (maliyet pozitif)
    - quantity >= 0 (stok negatif olamaz)
    - Barcode benzersiz olmalı (çakışma varsa 400 dön)

    Args:
        product_data: Ürün bilgileri
        current_user: Giriş yapmış kullanıcı (auth zorunlu)
        db: Veritabanı bağlantısı

    Returns:
        ProductCreateResponse: Oluşturulan ürün

    Raises:
        HTTPException: 400 (Barcode zaten var)
                      401 (Token geçersiz)
    """
    # 1. Barcode çakışması kontrol et (sadece bu bayinin envanterinde)
    if product_data.barcode:
        existing = db.query(Product).filter(
            and_(
                Product.barcode == product_data.barcode,
                Product.user_id == data_owner_id(current_user),
            )
        ).first()

        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Bu barcode zaten kullanılıyor (Ürün: {existing.name})"
            )

    # 2. Yeni Product nesnesi oluştur
    extras = []
    if product_data.extra_categories:
        seen_lower = set()
        main_lower = (product_data.category or "").strip().lower()
        for c in product_data.extra_categories:
            if not isinstance(c, str):
                continue
            v = c.strip()
            vl = v.lower()
            if not v or vl == main_lower or vl in seen_lower:
                continue
            seen_lower.add(vl)
            extras.append(v)

    new_product = Product(
        name=product_data.name,
        category=product_data.category,
        subcategory=product_data.subcategory,
        extra_categories=extras,
        barcode=product_data.barcode,
        price=product_data.price,
        cost=product_data.cost if product_data.cost is not None else 0.0,
        cost_currency=product_data.cost_currency or "TRY",
        currency=product_data.currency or "TRY",
        quantity=product_data.quantity,
        min_stock_alert=product_data.min_stock_alert,
        user_id=data_owner_id(current_user),
        created_at=datetime.now(),
        updated_at=datetime.now()
    )

    # 3. Veritabanına kaydet
    db.add(new_product)
    db.flush()
    db.commit()
    db.refresh(new_product)

    # 4. ActivityLog'a kaydet
    log_activity(
        db=db,
        user_id=data_owner_id(current_user),
        action="create",
        entity_type="product",
        entity_id=new_product.id,
        details=f"Ürün '{new_product.name}' oluşturuldu"
    )

    # 5. Response oluştur (profit_margin ve is_critical_stock hesapla)
    response_product = ProductResponse.model_validate(new_product)
    response_product.profit_margin = calculate_profit_margin(
        new_product.price,
        new_product.cost
    )
    response_product.is_critical_stock = is_critical_stock(
        new_product.quantity,
        new_product.min_stock_alert
    )

    return ProductCreateResponse(product=response_product)


# ============================================================
# 1.5 GET /api/v1/products/distinct-categories - Tüm benzersiz kategoriler
# ============================================================

@router.get(
    "/distinct-categories",
    status_code=status.HTTP_200_OK,
    summary="Benzersiz Ana Kategoriler",
    description="Kullanıcının ürünlerindeki yalnızca ANA kategorilerin (sekme isimlerinin) benzersiz listesi. extra_categories (alt etiketler) buraya dahil edilmez."
)
async def list_distinct_categories(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    require_perm(current_user, "products.view")
    rows = db.query(Product.category).filter(
        Product.user_id == data_owner_id(current_user)
    ).all()
    seen_lower = set()
    out = []
    for (cat,) in rows:
        if not isinstance(cat, str):
            continue
        s = cat.strip()
        if not s:
            continue
        sl = s.lower()
        if sl in seen_lower:
            continue
        seen_lower.add(sl)
        out.append(s)
    out.sort(key=lambda x: x.lower())
    return {"items": out}


# ============================================================
# 2. GET /api/v1/products - Ürün Listele
# ============================================================

@router.get(
    "",
    response_model=ProductListResponse,
    status_code=status.HTTP_200_OK,
    summary="Ürün Listele",
    description="Tüm ürünleri listele, ara, filtrele ve sayfalara böl"
)
async def list_products(
    search: str = Query(None, min_length=1, description="Ürün adı veya barcode ara"),
    category: str = Query(None, description="Kategori filtresi"),
    low_stock_only: bool = Query(False, description="Sadece kritik stok ürünleri"),
    page: int = Query(1, ge=1, description="Sayfa numarası (1'den başlayan)"),
    page_size: int = Query(10, ge=1, le=10000, description="Sayfa başına ürün sayısı"),
    sort_by: str = Query("name", description="Sıralama: name, price, quantity, created_at"),
    _federation: str = Query(None, description="İç: federe istek bayrağı — döngüyü önler"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    require_perm(current_user, "products.view")
    """
    Ürünleri listele - Search, Filter ve Pagination

    ## Filtreleme Seçenekleri:
    - search: Adı veya barcode'da ara
    - category: Belirli bir kategoriye filtrele
    - low_stock_only: Sadece kritik stok ürünleri göster
    - sort_by: name (A-Z), price (artan), quantity (artan), created_at (yeni)

    ## Pagination:
    - page: Kaçıncı sayfayı göster (default: 1)
    - page_size: Her sayfada kaç ürün (1-100, default: 10)

    ## Örnek İstekler:
    - GET /products?search=kilidi → "kilidi" içeren ürünler
    - GET /products?category=aksesuar&low_stock_only=true → Aksesuar kategorisinde kritik stok
    - GET /products?page=2&page_size=20 → 2. sayfada 20'şer ürün

    Args:
        search: Arama metni
        category: Kategori filtresi
        low_stock_only: Kritik stok filtresi
        page: Sayfa numarası
        page_size: Sayfa başına ürün sayısı
        sort_by: Sıralama alanı
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        ProductListResponse: Ürün listesi + pagination bilgileri
    """
    # 1. Base query oluştur (yalnızca bu bayinin ürünleri)
    query = db.query(Product).filter(Product.user_id == data_owner_id(current_user))

    # 2. Arama filtresi (name veya barcode)
    if search:
        search_term = f"%{search.lower()}%"
        query = query.filter(
            or_(
                Product.name.ilike(search_term),
                Product.barcode.ilike(search_term)
            )
        )

    # 3. Kategori filtresi — yalnızca ANA kategori (case-insensitive).
    # Sekmeler ana kategoridir; bir ürün yalnızca tek bir ana kategoriye aittir.
    # extra_categories artık ana kategori filtresine girmez (alt-etiket olarak kullanılır).
    if category:
        cat_lower = category.lower()
        query = query.filter(func.lower(Product.category) == cat_lower)

    # 4. Kritik stok filtresi
    if low_stock_only:
        query = query.filter(Product.quantity <= Product.min_stock_alert)

    # 5. Toplam ürün sayısını al (pagination için)
    total = query.count()
    total_pages = math.ceil(total / page_size)

    # 6. Sıralama
    if sort_by == "price":
        query = query.order_by(Product.price)
    elif sort_by == "quantity":
        query = query.order_by(Product.quantity)
    elif sort_by == "created_at":
        query = query.order_by(Product.created_at.desc())
    else:  # default: name
        query = query.order_by(Product.name)

    # 7. Pagination uygula
    skip = (page - 1) * page_size
    products = query.offset(skip).limit(page_size).all()

    # 8. Response nesneleri oluştur
    items = []
    for product in products:
        response_item = ProductResponse.model_validate(product)
        response_item.profit_margin = calculate_profit_margin(
            product.price,
            product.cost
        )
        response_item.is_critical_stock = is_critical_stock(
            product.quantity,
            product.min_stock_alert
        )
        items.append(response_item)

    # 9. Federe okuma — diğer sunucuların sahip olduğu benzersiz ürünleri ekle
    # Döngüyü önle: bu istek zaten bir federe istek ise atla
    if not _federation:
        try:
            from app.services.federation_service import federated_fetch, merge_with_local
            params = {"page_size": page_size}
            if search:
                params["search"] = search
            if category:
                params["category"] = category
            remote = federated_fetch(db, "/products", params)
            if remote:
                local_ids = {item.id for item in items}
                for r in remote:
                    if r.get("id") not in local_ids:
                        items.append(r)
                        total += 1
        except Exception as e:
            print(f"[FED/products] {e}")

    return ProductListResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
        search=search,
        category=category
    )


# ============================================================
# 3b. GET /api/v1/products/barcode/{barcode} - Barkod ile Ürün Bul
# ============================================================

@router.get(
    "/barcode/{barcode}",
    response_model=ProductResponse,
    status_code=status.HTTP_200_OK,
    summary="Barkod ile Ürün Bul",
)
async def get_product_by_barcode(
    barcode: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    require_perm(current_user, "products.view")
    product = db.query(Product).filter(
        and_(
            Product.user_id == data_owner_id(current_user),
            Product.barcode == barcode
        )
    ).first()
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f'"{barcode}" barkodlu ürün bulunamadı.'
        )
    response = ProductResponse.model_validate(product)
    response.profit_margin = calculate_profit_margin(product.price, product.cost)
    response.is_critical_stock = is_critical_stock(product.quantity, product.min_stock_alert)
    return response


# ============================================================
# 3. GET /api/v1/products/{product_id} - Ürün Detaylarını Getir
# ============================================================

@router.get(
    "/{product_id}",
    response_model=ProductResponse,
    status_code=status.HTTP_200_OK,
    summary="Ürün Detaylarını Getir",
    description="Belirli bir ürünün tüm bilgilerini göster"
)
async def get_product(
    product_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    require_perm(current_user, "products.view")
    """
    Tek bir ürünün detaylı bilgilerini getir

    Args:
        product_id: Ürün ID
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        ProductResponse: Ürün detayları (kar marjı dahil)

    Raises:
        HTTPException: 404 (Ürün bulunamadı)
    """
    product = db.query(Product).filter(
        and_(Product.id == product_id, Product.user_id == data_owner_id(current_user))
    ).first()

    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Ürün bulunamadı (ID: {product_id})"
        )

    response = ProductResponse.model_validate(product)
    response.profit_margin = calculate_profit_margin(product.price, product.cost)
    response.is_critical_stock = is_critical_stock(
        product.quantity,
        product.min_stock_alert
    )

    return response


# ============================================================
# 4. PUT /api/v1/products/{product_id} - Ürün Güncelle
# ============================================================

@router.put(
    "/{product_id}",
    response_model=ProductUpdateResponse,
    status_code=status.HTTP_200_OK,
    summary="Ürün Güncelle",
    description="Ürün bilgilerini kısmi veya tam olarak güncelle"
)
async def update_product(
    product_id: int,
    product_data: ProductUpdateRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    require_perm(current_user, "products.edit")
    """
    Ürün bilgilerini güncelle (kısmi güncellemeler desteklenir)

    ## Güncelleme Kuralları:
    - Sadece gönderiğiniz alanları günceller
    - Barcode değiştirilecekse benzersizlik kontrol et
    - Price ve cost değiştirilirse kar marjı otomatik güncellenir

    ## İşlem Adımları:
    1. Ürünü bul, yoksa 404 dön
    2. Barcode çakışması kontrol et (değiştirilecekse)
    3. Gelen alanları update et
    4. updated_at zaman damgasını güncelle
    5. Veritabanına kaydet
    6. ActivityLog'a işlemi kaydet
    7. Güncellenmiş ürünü döndür

    Args:
        product_id: Güncellenecek ürün ID
        product_data: Güncellenecek alanlar
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        ProductUpdateResponse: Güncellenmiş ürün

    Raises:
        HTTPException: 404 (Ürün bulunamadı)
                      400 (Barcode çakışması)
    """
    # 1. Ürünü bul (bayiye ait olmalı)
    product = db.query(Product).filter(
        and_(Product.id == product_id, Product.user_id == data_owner_id(current_user))
    ).first()

    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Ürün bulunamadı (ID: {product_id})"
        )

    # 2. Barcode çakışması kontrol et (yalnızca bu bayinin envanterinde)
    if product_data.barcode and product_data.barcode != product.barcode:
        existing = db.query(Product).filter(
            and_(
                Product.barcode == product_data.barcode,
                Product.id != product_id,
                Product.user_id == data_owner_id(current_user),
            )
        ).first()

        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Bu barcode zaten kullanılıyor (Ürün: {existing.name})"
            )

    # 3. Gelen alanları güncelle (sadece None olmayan alanlar)
    update_data = product_data.dict(exclude_unset=True)

    new_main_cat = update_data.get("category", product.category)

    if "extra_categories" in update_data:
        raw = update_data.get("extra_categories") or []
        seen_lower = set()
        cleaned = []
        main_lower = (new_main_cat or "").strip().lower()
        for c in raw:
            if not isinstance(c, str):
                continue
            v = c.strip()
            vl = v.lower()
            if not v or vl == main_lower or vl in seen_lower:
                continue
            seen_lower.add(vl)
            cleaned.append(v)
        update_data["extra_categories"] = cleaned
    elif "category" in update_data and update_data["category"] != product.category:
        existing_extras = list(product.extra_categories or [])
        main_lower = (new_main_cat or "").strip().lower()
        seen_lower = set()
        cleaned = []
        for c in existing_extras:
            if not isinstance(c, str):
                continue
            v = c.strip()
            vl = v.lower()
            if not v or vl == main_lower or vl in seen_lower:
                continue
            seen_lower.add(vl)
            cleaned.append(v)
        if cleaned != existing_extras:
            update_data["extra_categories"] = cleaned

    for field, value in update_data.items():
        if value is not None or field == "extra_categories":
            setattr(product, field, value)

    # 4. updated_at zaman damgasını güncelle
    product.updated_at = datetime.now()

    # 5. Veritabanına kaydet
    db.add(product)
    db.commit()
    db.refresh(product)

    # 6. ActivityLog'a kaydet
    log_activity(
        db=db,
        user_id=data_owner_id(current_user),
        action="update",
        entity_type="product",
        entity_id=product.id,
        details=f"Ürün '{product.name}' güncellendi: {list(update_data.keys())}"
    )

    # 7. Response oluştur
    response = ProductResponse.model_validate(product)
    response.profit_margin = calculate_profit_margin(product.price, product.cost)
    response.is_critical_stock = is_critical_stock(
        product.quantity,
        product.min_stock_alert
    )

    return ProductUpdateResponse(product=response)


# ============================================================
# 5. DELETE /api/v1/products/{product_id} - Ürün Sil
# ============================================================

@router.delete(
    "/{product_id}",
    response_model=ProductDeleteResponse,
    status_code=status.HTTP_200_OK,
    summary="Ürün Sil",
    description="Envanterzden ürünü tamamen sil"
)
async def delete_product(
    product_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    require_perm(current_user, "products.delete")
    """
    Ürünü veritabanından tamamen sil

    ## Uyarı:
    - Bu işlem geri alınamaz
    - Ürüne ait transaction'lar etkilenmez (veri bütünlüğü)
    - Silme işlemi ActivityLog'a kaydedilir

    ## İşlem Adımları:
    1. Ürünü bul, yoksa 404 dön
    2. Ürün adını kaydet (cevap için)
    3. Veritabanından sil
    4. ActivityLog'a silme işlemi kaydet
    5. Silme onayı döndür

    Args:
        product_id: Silinecek ürün ID
        current_user: Giriş yapmış kullanıcı
        db: Veritabanı bağlantısı

    Returns:
        ProductDeleteResponse: Silme onayı

    Raises:
        HTTPException: 404 (Ürün bulunamadı)
    """
    # 1. Ürünü bul (bayiye ait olmalı)
    product = db.query(Product).filter(
        and_(Product.id == product_id, Product.user_id == data_owner_id(current_user))
    ).first()

    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Ürün bulunamadı (ID: {product_id})"
        )

    # 2. Ürün adını kaydet
    product_name = product.name
    old_main_cat = (product.category or "").strip()
    old_extras = [
        (c or "").strip() for c in (product.extra_categories or [])
        if isinstance(c, str) and (c or "").strip()
    ]

    # 3. Sil
    record_deletion(db, "products", product.id)
    db.delete(product)
    db.commit()
    trigger_delta_push()

    # 3.5 Boş kalan KULLANICI-OLUŞTURMUŞ kategorileri otomatik temizle
    # (varsayılan/built-in kategoriler korunur — onlar modül navigasyonu için)
    candidates = []
    if old_main_cat:
        candidates.append(old_main_cat)
    for ec in old_extras:
        if ec.lower() != old_main_cat.lower() and ec not in candidates:
            candidates.append(ec)

    for cat_name in candidates:
        # Bu isimle başka üründe ana kategori olarak hâlâ var mı?
        still_main = db.query(Product.id).filter(
            Product.user_id == data_owner_id(current_user),
            func.lower(Product.category) == cat_name.lower(),
        ).first()
        if still_main:
            continue
        # Ek kategori olarak (case-insensitive JSONB array eleman taraması) hâlâ var mı?
        still_extra = db.query(Product.id).filter(
            Product.user_id == data_owner_id(current_user),
            text(
                "EXISTS (SELECT 1 FROM jsonb_array_elements_text(products.extra_categories) "
                "AS elem WHERE lower(elem) = lower(:cn))"
            ).bindparams(cn=cat_name),
        ).first()
        if still_extra:
            continue
        # Boş kaldı → categories tablosundan sadece kullanıcı oluşturmuş
        # (is_default == False) olanı temizle
        cat_row = db.query(Category).filter(
            Category.user_id == data_owner_id(current_user),
            Category.kind == "stok",
            func.lower(Category.name) == cat_name.lower(),
            Category.is_default == False,  # noqa: E712
        ).first()
        if cat_row:
            db.delete(cat_row)
    db.commit()

    # 4. ActivityLog'a kaydet
    log_activity(
        db=db,
        user_id=data_owner_id(current_user),
        action="delete",
        entity_type="product",
        entity_id=product_id,
        details=f"Ürün '{product_name}' silindi"
    )

    return ProductDeleteResponse(
        product_id=product_id,
        product_name=product_name
    )


# ============================================================
# Hızlı Eylem Modelleri (Quick Actions)
# ============================================================

class QuickSellRequest(BaseModel):
    quantity: int = Field(default=1, gt=0, description="Satılacak adet")
    customer_name: Optional[str] = Field(default=None, max_length=255, description="Müşteri adı (boşsa 'Hızlı Satış')")
    notes: Optional[str] = Field(default=None, max_length=500)


class QuickStockAdjustRequest(BaseModel):
    delta: int = Field(..., description="Stok değişimi (pozitif: artır, negatif: azalt)")
    notes: Optional[str] = Field(default=None, max_length=500)


# ============================================================
# POST /api/v1/products/{id}/quick-sell — Hızlı Sat
# ============================================================
@router.post(
    "/{product_id}/quick-sell",
    summary="Hızlı Satış",
    description="Ürünü stoktan düş ve kasa defterine tahsilat olarak işle"
)
async def quick_sell_product(
    product_id: int,
    payload: QuickSellRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    require_perm(current_user, "products.edit")
    qty = payload.quantity
    if qty <= 0:
        raise HTTPException(status_code=400, detail="Satış miktarı 0'dan büyük olmalı")

    # Atomik UPDATE: stok yarış koşulunu önler (concurrent satışlar overselling yapamaz).
    update_result = db.execute(
        text(
            "UPDATE products SET quantity = quantity - :qty, updated_at = NOW() "
            "WHERE id = :pid AND user_id = :uid AND quantity >= :qty "
            "RETURNING quantity, price, currency, name"
        ),
        {"qty": qty, "pid": product_id, "uid": data_owner_id(current_user)},
    )
    row = update_result.first()
    if not row:
        # Ya ürün yok/yetkin yok ya da stok yetersiz — ayırt et
        product_check = db.query(Product).filter(
            and_(Product.id == product_id, Product.user_id == data_owner_id(current_user))
        ).first()
        if not product_check:
            raise HTTPException(status_code=404, detail=f"Ürün bulunamadı (ID: {product_id})")
        raise HTTPException(
            status_code=400,
            detail=f"Yetersiz stok (mevcut: {product_check.quantity}, istenen: {qty})",
        )

    new_quantity, unit_price, sell_currency, product_name = row.quantity, row.price, row.currency or "TRY", row.name
    total = float(unit_price or 0) * qty
    customer = (payload.customer_name or "Hızlı Satış").strip() or "Hızlı Satış"

    note_parts = [f"Satış: {product_name} x{qty}"]
    if payload.notes:
        note_parts.append(payload.notes.strip())
    transaction = Transaction(
        user_id=data_owner_id(current_user),
        customer_name=customer,
        transaction_type="satış",
        amount=total,
        currency=sell_currency,
        description=" — ".join(note_parts),
        balance=0.0,
        transaction_date=datetime.now(),
    )
    db.add(transaction)
    db.flush()

    log_activity(
        db=db,
        user_id=data_owner_id(current_user),
        action="quick_sell",
        entity_type="product",
        entity_id=product_id,
        details=f"Hızlı satış: {product_name} x{qty} = {total} {sell_currency}"
    )
    db.commit()
    db.refresh(transaction)

    return {
        "message": "Hızlı satış kaydedildi",
        "product": {
            "id": product_id,
            "name": product_name,
            "quantity": new_quantity,
            "currency": sell_currency,
        },
        "transaction": {
            "id": transaction.id,
            "amount": transaction.amount,
            "currency": transaction.currency,
            "customer_name": transaction.customer_name,
        },
        "sold_quantity": qty,
        "total": total,
    }


# ============================================================
# POST /api/v1/products/{id}/adjust-stock — Hızlı Stok Artır/Azalt
# ============================================================
@router.post(
    "/{product_id}/adjust-stock",
    summary="Hızlı Stok Düzenle",
    description="Ürün stokunu artır (+) veya azalt (-)"
)
async def adjust_product_stock(
    product_id: int,
    payload: QuickStockAdjustRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    require_perm(current_user, "products.edit")
    delta = payload.delta
    if delta == 0:
        raise HTTPException(status_code=400, detail="Stok değişimi 0 olamaz")

    # Atomik UPDATE: artırırken (delta>0) her zaman güvenli; azaltırken yeni değer >= 0 koşulu garanti.
    update_result = db.execute(
        text(
            "UPDATE products SET quantity = quantity + :delta, updated_at = NOW() "
            "WHERE id = :pid AND user_id = :uid AND (quantity + :delta) >= 0 "
            "RETURNING quantity, name"
        ),
        {"delta": delta, "pid": product_id, "uid": data_owner_id(current_user)},
    )
    row = update_result.first()
    if not row:
        product_check = db.query(Product).filter(
            and_(Product.id == product_id, Product.user_id == data_owner_id(current_user))
        ).first()
        if not product_check:
            raise HTTPException(status_code=404, detail=f"Ürün bulunamadı (ID: {product_id})")
        raise HTTPException(
            status_code=400,
            detail=f"Stok negatif olamaz (mevcut: {product_check.quantity}, değişim: {delta})",
        )

    new_qty, product_name = row.quantity, row.name

    log_activity(
        db=db,
        user_id=data_owner_id(current_user),
        action="adjust_stock",
        entity_type="product",
        entity_id=product_id,
        details=f"Stok düzenleme: {product_name} {'+' if delta > 0 else ''}{delta} → {new_qty}"
    )
    db.commit()

    return {
        "message": f"Stok güncellendi ({'+' if delta > 0 else ''}{delta})",
        "product": {
            "id": product_id,
            "name": product_name,
            "quantity": new_qty,
        },
    }


# ============================================================
# 6. GET /api/v1/products/stock/critical - Kritik Stok Listesi
# ============================================================

@router.get(
    "/stock/critical",
    response_model=CriticalStockListResponse,
    status_code=status.HTTP_200_OK,
    summary="Kritik Stok Ürünleri",
    description="Stok seviyesi min_stock_alert'in altında olan ürünleri listele"
)
async def get_critical_stock(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    require_perm(current_user, "products.view")
    """
    Kritik stok durumundaki ürünleri getir

    Kritik Stok Tanımı: quantity <= min_stock_alert

    ## Severity Seviyeleri:
    - low: Eksiklik %10-30 arası (shortage/min_stock_alert)
    - medium: Eksiklik %30-60 arası
    - critical: Eksiklik %60+ (acil siparişe konu)

    ## İşlem Adımları:
    1. quantity <= min_stock_alert olan ürünleri bul
    2. Her ürün için eksiklik hesapla
    3. Önerilen sipariş miktarını belirle (shortage * 2)
    4. Severity hesapla
    5. Kritik ürünleri döndür

    Returns:
        CriticalStockListResponse: Kritik stok listesi + severity

    Example Response:
    {
        "items": [
            {
                "id": 5,
                "name": "Aydınlatma Seti",
                "quantity": 2,
                "min_stock_alert": 15,
                "shortage": 13,
                "reorder_quantity": 26,
                "severity": "critical"
            }
        ],
        "total": 3,
        "severity": "critical"
    }
    """
    # 1. Kritik stok ürünlerini bul (yalnızca bu bayiye ait)
    critical_products = db.query(Product).filter(
        and_(
            Product.user_id == data_owner_id(current_user),
            Product.quantity <= Product.min_stock_alert,
        )
    ).order_by(Product.quantity).all()

    # 2. Response nesneleri oluştur
    items = []
    total_shortage = 0

    for product in critical_products:
        shortage = product.min_stock_alert - product.quantity
        reorder_qty = shortage * 2  # Önerilen sipariş: eksikliğin 2 katı

        total_shortage += shortage

        item = ProductStockResponse(
            id=product.id,
            name=product.name,
            category=product.category,
            quantity=product.quantity,
            min_stock_alert=product.min_stock_alert,
            shortage=shortage,
            reorder_quantity=reorder_qty
        )
        items.append(item)

    # 3. Severity hesapla (ortalama eksiklik yüzdesi)
    if critical_products:
        total_min_alert = sum(p.min_stock_alert for p in critical_products)
        shortage_percentage = (total_shortage / total_min_alert) * 100 if total_min_alert > 0 else 0

        if shortage_percentage >= 60:
            severity = "critical"
        elif shortage_percentage >= 30:
            severity = "medium"
        else:
            severity = "low"
    else:
        severity = "none"

    return CriticalStockListResponse(
        items=items,
        total=len(critical_products),
        severity=severity
    )
