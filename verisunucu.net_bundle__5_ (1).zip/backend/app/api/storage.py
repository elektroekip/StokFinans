"""
Depolama Havuzu API — /api/v1/storage/

Düğüm yönetimi, dosya envanteri, replica durumu, günlük yedekler.
Sadece super admin erişebilir.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.storage import StorageDailyBackup, StorageFile, StorageFileReplica, StorageNode
from app.utils.auth import get_current_user
from app.models.user import User

router = APIRouter(prefix="/storage", tags=["storage"])


def _require_superadmin(current_user: User = Depends(get_current_user)) -> User:
    if not current_user.is_super_admin:
        raise HTTPException(status_code=403, detail="Sadece süper admin erişebilir")
    return current_user


# ── Pydantic Şemaları ────────────────────────────────────────

class StorageNodeCreate(BaseModel):
    name: str
    type: str = "minio"
    host: Optional[str] = None
    port: Optional[int] = None
    username: Optional[str] = None
    password: Optional[str] = None        # düz metin → servis şifreler
    access_key: Optional[str] = None
    secret_key: Optional[str] = None      # düz metin → servis şifreler
    bucket: Optional[str] = None
    endpoint_url: Optional[str] = None
    base_path: str = "/"
    is_primary: bool = False
    is_master_backup: bool = False
    is_external_backup: bool = False


class StorageNodeUpdate(BaseModel):
    name: Optional[str] = None
    is_primary: Optional[bool] = None
    is_master_backup: Optional[bool] = None
    is_external_backup: Optional[bool] = None
    is_active: Optional[bool] = None
    total_bytes: Optional[int] = None


# ── Yardımcılar ──────────────────────────────────────────────

def _node_to_dict(node: StorageNode) -> Dict[str, Any]:
    return {
        "id": node.id,
        "name": node.name,
        "type": node.type,
        "host": node.host,
        "port": node.port,
        "endpoint_url": node.endpoint_url,
        "bucket": node.bucket,
        "base_path": node.base_path,
        "total_bytes": node.total_bytes,
        "used_bytes": node.used_bytes,
        "free_bytes": node.free_bytes,
        "is_primary": node.is_primary,
        "is_master_backup": node.is_master_backup,
        "is_external_backup": node.is_external_backup,
        "is_active": node.is_active,
        "last_check_at": node.last_check_at.isoformat() if node.last_check_at else None,
        "last_error": node.last_error,
        "created_at": node.created_at.isoformat() if node.created_at else None,
    }


def _file_to_dict(sf: StorageFile, replicas: List[StorageFileReplica]) -> Dict[str, Any]:
    return {
        "id": sf.id,
        "filename": sf.filename,
        "storage_key": sf.storage_key,
        "size_bytes": sf.size_bytes,
        "content_type": sf.content_type,
        "checksum_sha256": sf.checksum_sha256,
        "user_id": sf.user_id,
        "uploaded_at": sf.uploaded_at.isoformat() if sf.uploaded_at else None,
        "replicas": [
            {
                "id": r.id,
                "node_id": r.node_id,
                "path_on_node": r.path_on_node,
                "is_primary": r.is_primary,
                "is_verified": r.is_verified,
                "last_verified_at": r.last_verified_at.isoformat() if r.last_verified_at else None,
            }
            for r in replicas
        ],
    }


# ── Düğüm (Node) Endpoint'leri ───────────────────────────────

@router.get("/nodes")
def list_nodes(
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> List[Dict[str, Any]]:
    nodes = db.query(StorageNode).order_by(StorageNode.id).all()
    return [_node_to_dict(n) for n in nodes]


@router.post("/nodes")
def create_node(
    body: StorageNodeCreate,
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    from app.utils.crypto import encrypt_secret

    node = StorageNode(
        name=body.name,
        type=body.type,
        host=body.host,
        port=body.port,
        username=body.username,
        password_encrypted=encrypt_secret(body.password) if body.password else None,
        access_key=body.access_key,
        secret_key_encrypted=encrypt_secret(body.secret_key) if body.secret_key else None,
        bucket=body.bucket,
        endpoint_url=body.endpoint_url,
        base_path=body.base_path,
        is_primary=body.is_primary,
        is_master_backup=body.is_master_backup,
        is_external_backup=body.is_external_backup,
    )
    db.add(node)
    db.commit()
    db.refresh(node)
    return _node_to_dict(node)


@router.put("/nodes/{node_id}")
def update_node(
    node_id: int,
    body: StorageNodeUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    node = db.query(StorageNode).filter(StorageNode.id == node_id).first()
    if not node:
        raise HTTPException(status_code=404, detail="Düğüm bulunamadı")
    for field, val in body.model_dump(exclude_none=True).items():
        setattr(node, field, val)
    db.commit()
    db.refresh(node)
    return _node_to_dict(node)


@router.delete("/nodes/{node_id}")
def delete_node(
    node_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    node = db.query(StorageNode).filter(StorageNode.id == node_id).first()
    if not node:
        raise HTTPException(status_code=404, detail="Düğüm bulunamadı")
    replica_count = db.query(StorageFileReplica).filter(StorageFileReplica.node_id == node_id).count()
    if replica_count > 0:
        raise HTTPException(
            status_code=400,
            detail=f"Bu düğümde {replica_count} dosya var. Önce dosyaları taşıyın."
        )
    db.delete(node)
    db.commit()
    return {"ok": True}


@router.post("/nodes/{node_id}/refresh-stats")
def refresh_node_stats(
    node_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    from app.services.storage_service import refresh_node_stats as _refresh
    node = db.query(StorageNode).filter(StorageNode.id == node_id).first()
    if not node:
        raise HTTPException(status_code=404, detail="Düğüm bulunamadı")
    _refresh(db, node)
    return _node_to_dict(node)


@router.post("/nodes/{node_id}/health-check")
def health_check_node(
    node_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    """Düğümü ping et: bağlantı, gecikme (ms), hata bilgisi döndür."""
    from app.services.storage_service import check_node_health
    node = db.query(StorageNode).filter(StorageNode.id == node_id).first()
    if not node:
        raise HTTPException(status_code=404, detail="Düğüm bulunamadı")
    result = check_node_health(db, node)
    return {**result, "node": _node_to_dict(node)}


@router.post("/nodes/health-check-all")
def health_check_all_nodes(
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> List[Dict[str, Any]]:
    """Tüm aktif düğümleri ping et."""
    from app.services.storage_service import check_node_health
    nodes = db.query(StorageNode).all()
    results = []
    for node in nodes:
        try:
            result = check_node_health(db, node)
            results.append({**result, "node_id": node.id, "node_name": node.name})
        except Exception as exc:
            results.append({"ok": False, "node_id": node.id, "node_name": node.name, "error": str(exc)[:200]})
    return results


@router.post("/nodes/import-ftp-servers")
def import_ftp_servers(
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    """
    Mevcut ftp_servers tablosundaki sunucuları storage_nodes'a aktar.
    Faz 7: FTP/SFTP → Depolama Havuzu entegrasyonu.
    Zaten içe aktarılmış olanları atlar (host+port kontrolü).
    """
    from app.models.ftp_server import FtpServer
    servers = db.query(FtpServer).filter(FtpServer.is_active == True).all()  # noqa: E712
    imported = 0
    skipped = 0
    for srv in servers:
        exists = db.query(StorageNode).filter(
            StorageNode.host == srv.host,
            StorageNode.port == srv.port,
            StorageNode.type == srv.type,
        ).first()
        if exists:
            skipped += 1
            continue
        node = StorageNode(
            name=f"{srv.name} (FTP)",
            type=srv.type,
            host=srv.host,
            port=srv.port,
            username=srv.username,
            password_encrypted=srv.password_encrypted,
            base_path=srv.base_path,
            is_primary=False,
            is_master_backup=False,
            is_active=True,
        )
        db.add(node)
        imported += 1
    db.commit()
    return {"imported": imported, "skipped": skipped, "total_ftp_servers": len(servers)}


# ── Dosya Envanter Endpoint'leri ─────────────────────────────

@router.get("/files")
def list_files(
    q: Optional[str] = None,
    node_id: Optional[int] = None,
    limit: int = 50,
    offset: int = 0,
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    query = db.query(StorageFile)
    if q:
        query = query.filter(StorageFile.filename.ilike(f"%{q}%"))
    if node_id:
        file_ids = db.query(StorageFileReplica.file_id).filter(
            StorageFileReplica.node_id == node_id
        ).subquery()
        query = query.filter(StorageFile.id.in_(file_ids))
    total = query.count()
    files = query.order_by(StorageFile.uploaded_at.desc()).offset(offset).limit(limit).all()
    result = []
    for sf in files:
        replicas = db.query(StorageFileReplica).filter(StorageFileReplica.file_id == sf.id).all()
        result.append(_file_to_dict(sf, replicas))
    return {"total": total, "items": result}


@router.get("/files/{file_id}")
def get_file(
    file_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    sf = db.query(StorageFile).filter(StorageFile.id == file_id).first()
    if not sf:
        raise HTTPException(status_code=404, detail="Dosya bulunamadı")
    replicas = db.query(StorageFileReplica).filter(StorageFileReplica.file_id == file_id).all()
    return _file_to_dict(sf, replicas)


@router.delete("/files/{file_id}")
def delete_file(
    file_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    """Dosyayı soft-delete ile işaretle. 30 gün sonra MinIO'dan silinir."""
    from app.services.storage_service import soft_delete_file
    ok = soft_delete_file(db, file_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Dosya bulunamadı veya zaten silinmiş")
    return {"ok": True, "message": "Dosya 30 gün sonra kalıcı olarak silinecek"}


@router.post("/files/{file_id}/restore")
def restore_file(
    file_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    """Soft-delete edilmiş dosyayı geri al (30 günlük grace period içinde)."""
    from app.services.storage_service import restore_file as _restore, FileAlreadyPurgedError
    try:
        ok = _restore(db, file_id)
    except FileAlreadyPurgedError as exc:
        raise HTTPException(status_code=410, detail=str(exc))
    if not ok:
        raise HTTPException(status_code=404, detail="Dosya bulunamadı veya zaten aktif")
    return {"ok": True, "message": "Dosya geri alındı"}


@router.post("/files/purge-deleted")
def purge_deleted_files_now(
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    """30 günlük grace period dolmuş soft-delete dosyaları şimdi temizle."""
    from app.services.storage_service import purge_deleted_files
    count = purge_deleted_files(db, grace_days=30)
    return {"purged": count}


@router.post("/files/{file_id}/verify")
def verify_file(
    file_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    from app.services.storage_service import verify_file_replicas
    return verify_file_replicas(db, file_id)


@router.get("/files/{file_id}/download-url")
def get_download_url(
    file_id: int,
    expires: int = 3600,
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    from app.services.storage_service import get_presigned_url
    sf = db.query(StorageFile).filter(StorageFile.id == file_id).first()
    if not sf:
        raise HTTPException(status_code=404, detail="Dosya bulunamadı")
    url = get_presigned_url(sf.storage_key, expires_seconds=expires)
    return {"url": url, "expires_in": expires, "filename": sf.filename}


# ── Genel İstatistikler ───────────────────────────────────────

@router.get("/stats")
def storage_stats(
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    nodes = db.query(StorageNode).filter(StorageNode.is_active == True).all()  # noqa: E712
    total_bytes = sum((n.total_bytes or 0) for n in nodes)
    used_bytes = sum((n.used_bytes or 0) for n in nodes)
    file_count = db.query(StorageFile).count()
    master_node = next((n for n in nodes if n.is_master_backup), None)
    last_backup = (
        db.query(StorageDailyBackup)
        .filter(StorageDailyBackup.status == "done")
        .order_by(StorageDailyBackup.backup_date.desc())
        .first()
    )
    pending_backup = (
        db.query(StorageDailyBackup)
        .filter(StorageDailyBackup.status == "running")
        .first()
    )
    return {
        "node_count": len(nodes),
        "total_bytes": total_bytes,
        "used_bytes": used_bytes,
        "free_bytes": total_bytes - used_bytes if total_bytes else None,
        "file_count": file_count,
        "master_backup_node": _node_to_dict(master_node) if master_node else None,
        "last_backup": {
            "id": last_backup.id,
            "backup_date": last_backup.backup_date.isoformat(),
            "filename": last_backup.filename,
            "size_bytes": last_backup.size_bytes,
            "expires_at": last_backup.expires_at.isoformat() if last_backup.expires_at else None,
        } if last_backup else None,
        "backup_running": pending_backup is not None,
    }


# ── Yedek Endpoint'leri ───────────────────────────────────────

@router.get("/backups")
def list_backups(
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> List[Dict[str, Any]]:
    backups = (
        db.query(StorageDailyBackup)
        .order_by(StorageDailyBackup.backup_date.desc())
        .limit(60)
        .all()
    )
    return [
        {
            "id": b.id,
            "node_id": b.node_id,
            "backup_type": b.backup_type,
            "filename": b.filename,
            "size_bytes": b.size_bytes,
            "status": b.status,
            "error": b.error,
            "backup_date": b.backup_date.isoformat() if b.backup_date else None,
            "expires_at": b.expires_at.isoformat() if b.expires_at else None,
            "completed_at": b.completed_at.isoformat() if b.completed_at else None,
            "days_remaining": (
                (b.expires_at - datetime.now(timezone.utc)).days
                if b.expires_at else None
            ),
            "external_backup_status": b.external_backup_status,
            "external_backup_at": b.external_backup_at.isoformat() if b.external_backup_at else None,
            "external_backup_error": b.external_backup_error,
            "backup_scope": b.backup_scope,
            "dr_tested_at": b.dr_tested_at.isoformat() if b.dr_tested_at else None,
            "dr_test_result": b.dr_test_result,
        }
        for b in backups
    ]


@router.post("/backups/trigger")
def trigger_backup(
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    from app.services.storage_service import create_daily_backup
    # Halihazırda çalışan var mı?
    running = db.query(StorageDailyBackup).filter(StorageDailyBackup.status == "running").first()
    if running:
        raise HTTPException(status_code=409, detail="Zaten çalışan bir yedek var")
    backup = create_daily_backup(db)
    return {
        "id": backup.id,
        "filename": backup.filename,
        "status": backup.status,
        "backup_date": backup.backup_date.isoformat(),
        "expires_at": backup.expires_at.isoformat() if backup.expires_at else None,
    }


@router.post("/backups/{backup_id}/push-external")
def push_backup_external(
    backup_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    """Tamamlanmış yedeği is_external_backup=True tüm S3 düğümlerine manuel gönder."""
    from app.services.storage_service import push_backup_to_external_s3
    b = db.query(StorageDailyBackup).filter(StorageDailyBackup.id == backup_id).first()
    if not b:
        raise HTTPException(status_code=404, detail="Yedek bulunamadı")
    if b.status != "done":
        raise HTTPException(status_code=400, detail=f"Yedek henüz tamamlanmadı (durum: {b.status})")
    return push_backup_to_external_s3(db, backup_id)


@router.post("/backups/{backup_id}/mark-dr-tested")
def mark_dr_tested(
    backup_id: int,
    result: str = "ok",
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    """DR testi sonucunu kaydet (ok|failed)."""
    b = db.query(StorageDailyBackup).filter(StorageDailyBackup.id == backup_id).first()
    if not b:
        raise HTTPException(status_code=404, detail="Yedek bulunamadı")
    b.dr_tested_at = datetime.now(timezone.utc)
    b.dr_test_result = result if result in ("ok", "failed") else "ok"
    db.commit()
    return {"id": b.id, "dr_tested_at": b.dr_tested_at.isoformat(), "dr_test_result": b.dr_test_result}


@router.get("/backups/{backup_id}/download-url")
def backup_download_url(
    backup_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(_require_superadmin),
) -> Dict[str, Any]:
    from app.services.storage_service import get_presigned_url
    b = db.query(StorageDailyBackup).filter(StorageDailyBackup.id == backup_id).first()
    if not b:
        raise HTTPException(status_code=404, detail="Yedek bulunamadı")
    if b.status != "done":
        raise HTTPException(status_code=400, detail=f"Yedek hazır değil (durum: {b.status})")
    url = get_presigned_url(f"backups/{b.filename}", expires_seconds=3600)
    return {"url": url, "filename": b.filename}
