"""
Yönetim API — Harici süper admin entegrasyonu
/api/v1/ext/admin/*

Tüm endpoint'ler get_current_super_admin bağımlılığını kullanır:
  • JWT süper admin token'ı
  • is_super_admin_key=True olan API anahtarı

Bu endpoint'ler tenant izolasyonu uygulamaz;
tüm bayilerin verilerine çapraz erişim sağlar.
"""
from fastapi import APIRouter, Depends, Query, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func, desc, and_
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timedelta

from app.core.database import get_db
from app.models import User, Product, Transaction
from app.utils.auth import get_current_super_admin

router = APIRouter(prefix="/ext/admin", tags=["Management API"])


# ── Yardımcı ─────────────────────────────────────────────────────────────────

def _days_left(user: User) -> int:
    from app.services.subscription import compute_days_remaining
    if user.sub_expires_at:
        return max(0, compute_days_remaining(user.sub_expires_at))
    return max(0, user.sub_days or 0)


def _user_summary(u: User, db: Session) -> dict:
    product_count = db.query(func.count(Product.id)).filter(Product.user_id == u.id).scalar() or 0
    tx_30d = (
        db.query(func.count(Transaction.id))
        .filter(Transaction.user_id == u.id, Transaction.created_at >= datetime.utcnow() - timedelta(days=30))
        .scalar() or 0
    )
    revenue_30d = (
        db.query(func.coalesce(func.sum(Transaction.total_amount), 0))
        .filter(
            Transaction.user_id == u.id,
            Transaction.transaction_type.in_(["sale", "satis", "gelir"]),
            Transaction.created_at >= datetime.utcnow() - timedelta(days=30),
        )
        .scalar() or 0
    )
    return {
        "id": u.id,
        "email": u.email,
        "full_name": getattr(u, "full_name", "") or "",
        "company_name": getattr(u, "company_name", "") or "",
        "role": u.role,
        "is_active": u.is_active,
        "is_email_verified": getattr(u, "is_email_verified", True),
        "sub_days_left": _days_left(u),
        "sub_expires_at": u.sub_expires_at.isoformat() if u.sub_expires_at else None,
        "product_count": product_count,
        "transactions_30d": tx_30d,
        "revenue_30d": float(revenue_30d),
        "created_at": u.created_at.isoformat() if u.created_at else None,
    }


# ── 1. Platform genel istatistikleri ─────────────────────────────────────────

@router.get("/overview")
async def management_overview(
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
):
    """Platform genelinde özet istatistikler."""
    now = datetime.utcnow()
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

    total_users    = db.query(func.count(User.id)).filter(User.is_super_admin == False).scalar() or 0
    active_users   = db.query(func.count(User.id)).filter(User.is_super_admin == False, User.is_active == True).scalar() or 0
    total_products = db.query(func.count(Product.id)).scalar() or 0
    low_stock      = db.query(func.count(Product.id)).filter(Product.quantity <= Product.min_stock_alert).scalar() or 0

    tx_today = db.query(func.count(Transaction.id)).filter(Transaction.created_at >= today_start).scalar() or 0
    tx_month = db.query(func.count(Transaction.id)).filter(Transaction.created_at >= month_start).scalar() or 0

    rev_today = (
        db.query(func.coalesce(func.sum(Transaction.total_amount), 0))
        .filter(Transaction.transaction_type.in_(["sale","satis","gelir"]), Transaction.created_at >= today_start)
        .scalar() or 0
    )
    rev_month = (
        db.query(func.coalesce(func.sum(Transaction.total_amount), 0))
        .filter(Transaction.transaction_type.in_(["sale","satis","gelir"]), Transaction.created_at >= month_start)
        .scalar() or 0
    )

    expiring_7d = (
        db.query(func.count(User.id))
        .filter(
            User.is_super_admin == False,
            User.sub_expires_at != None,
            User.sub_expires_at <= now + timedelta(days=7),
            User.sub_expires_at >= now,
        )
        .scalar() or 0
    )
    new_users_month = (
        db.query(func.count(User.id))
        .filter(User.is_super_admin == False, User.created_at >= month_start)
        .scalar() or 0
    )

    return {
        "users": {
            "total": total_users,
            "active": active_users,
            "new_this_month": new_users_month,
            "expiring_7d": expiring_7d,
        },
        "products": {
            "total": total_products,
            "low_stock": low_stock,
        },
        "transactions": {
            "today": tx_today,
            "this_month": tx_month,
        },
        "revenue": {
            "today": float(rev_today),
            "this_month": float(rev_month),
        },
        "generated_at": now.isoformat(),
    }


# ── 2. Bayi listesi ───────────────────────────────────────────────────────────

@router.get("/users")
async def list_users(
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
    search: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(None),
    expiring_days: Optional[int] = Query(None, description="Aboneliği bu gün içinde dolacaklar"),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
):
    """Tüm bayi hesapları — ürün sayısı ve 30 günlük satış istatistikleriyle."""
    q = db.query(User).filter(User.is_super_admin == False)
    if search:
        q = q.filter(
            User.email.ilike(f"%{search}%") |
            User.full_name.ilike(f"%{search}%") |
            User.company_name.ilike(f"%{search}%")
        )
    if is_active is not None:
        q = q.filter(User.is_active == is_active)
    if expiring_days is not None:
        cutoff = datetime.utcnow() + timedelta(days=expiring_days)
        q = q.filter(User.sub_expires_at != None, User.sub_expires_at <= cutoff, User.sub_expires_at >= datetime.utcnow())

    total = q.count()
    users = q.order_by(desc(User.created_at)).offset((page - 1) * page_size).limit(page_size).all()

    return {
        "total": total,
        "page": page,
        "page_size": page_size,
        "items": [_user_summary(u, db) for u in users],
    }


# ── 3. Tek bayi detay ─────────────────────────────────────────────────────────

@router.get("/users/{user_id}")
async def get_user_detail(
    user_id: int,
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
):
    """Belirtilen bayi için detay bilgi ve istatistikler."""
    user = db.query(User).filter(User.id == user_id, User.is_super_admin == False).first()
    if not user:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")

    now = datetime.utcnow()
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

    total_products   = db.query(func.count(Product.id)).filter(Product.user_id == user_id).scalar() or 0
    low_stock        = db.query(func.count(Product.id)).filter(Product.user_id == user_id, Product.quantity <= Product.min_stock_alert).scalar() or 0
    out_of_stock     = db.query(func.count(Product.id)).filter(Product.user_id == user_id, Product.quantity == 0).scalar() or 0
    total_tx         = db.query(func.count(Transaction.id)).filter(Transaction.user_id == user_id).scalar() or 0
    tx_month         = db.query(func.count(Transaction.id)).filter(Transaction.user_id == user_id, Transaction.created_at >= month_start).scalar() or 0
    rev_total        = db.query(func.coalesce(func.sum(Transaction.total_amount), 0)).filter(Transaction.user_id == user_id, Transaction.transaction_type.in_(["sale","satis","gelir"])).scalar() or 0
    rev_month        = db.query(func.coalesce(func.sum(Transaction.total_amount), 0)).filter(Transaction.user_id == user_id, Transaction.transaction_type.in_(["sale","satis","gelir"]), Transaction.created_at >= month_start).scalar() or 0

    return {
        "user": _user_summary(user, db),
        "stats": {
            "products": {"total": total_products, "low_stock": low_stock, "out_of_stock": out_of_stock},
            "transactions": {"total": total_tx, "this_month": tx_month},
            "revenue": {"total": float(rev_total), "this_month": float(rev_month)},
        },
    }


# ── 4. Bayinin ürünleri ───────────────────────────────────────────────────────

@router.get("/users/{user_id}/products")
async def get_user_products(
    user_id: int,
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
    search: Optional[str] = Query(None),
    low_stock_only: bool = Query(False),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
):
    """Belirtilen bayiye ait ürün listesi."""
    if not db.query(User).filter(User.id == user_id).first():
        raise HTTPException(404, "Kullanıcı bulunamadı")

    q = db.query(Product).filter(Product.user_id == user_id)
    if search:
        q = q.filter(Product.name.ilike(f"%{search}%") | Product.barcode.ilike(f"%{search}%"))
    if low_stock_only:
        q = q.filter(Product.quantity <= Product.min_stock_alert)

    total = q.count()
    items = q.order_by(desc(Product.updated_at)).offset((page - 1) * page_size).limit(page_size).all()

    return {
        "total": total,
        "items": [
            {
                "id": p.id, "name": p.name, "barcode": p.barcode,
                "price": float(p.price or 0), "cost": float(p.cost or 0),
                "quantity": p.quantity, "min_stock_alert": p.min_stock_alert,
                "category": getattr(p, "category", None),
                "is_low_stock": p.quantity <= p.min_stock_alert,
                "updated_at": p.updated_at.isoformat() if p.updated_at else None,
            }
            for p in items
        ],
    }


# ── 5. Bayinin satışları ──────────────────────────────────────────────────────

@router.get("/users/{user_id}/transactions")
async def get_user_transactions(
    user_id: int,
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
    date_from: Optional[str] = Query(None, description="YYYY-MM-DD"),
    date_to:   Optional[str] = Query(None, description="YYYY-MM-DD"),
    tx_type:   Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
):
    """Belirtilen bayiye ait işlem geçmişi."""
    if not db.query(User).filter(User.id == user_id).first():
        raise HTTPException(404, "Kullanıcı bulunamadı")

    q = db.query(Transaction).filter(Transaction.user_id == user_id)
    if date_from:
        q = q.filter(Transaction.created_at >= datetime.fromisoformat(date_from))
    if date_to:
        q = q.filter(Transaction.created_at <= datetime.fromisoformat(date_to) + timedelta(days=1))
    if tx_type:
        q = q.filter(Transaction.transaction_type == tx_type)

    total = q.count()
    items = q.order_by(desc(Transaction.created_at)).offset((page - 1) * page_size).limit(page_size).all()

    return {
        "total": total,
        "items": [
            {
                "id": t.id,
                "type": t.transaction_type,
                "total_amount": float(t.total_amount or 0),
                "note": getattr(t, "note", None) or getattr(t, "description", None),
                "created_at": t.created_at.isoformat() if t.created_at else None,
            }
            for t in items
        ],
    }


# ── 6. Abonelik yönetimi ──────────────────────────────────────────────────────

class _SubUpdate(BaseModel):
    sub_days: Optional[int] = None
    sub_expires_at: Optional[datetime] = None
    is_active: Optional[bool] = None
    note: Optional[str] = None


@router.patch("/users/{user_id}/subscription")
async def update_user_subscription(
    user_id: int,
    payload: _SubUpdate,
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
):
    """Bayi aboneliğini veya hesap durumunu güncelle."""
    user = db.query(User).filter(User.id == user_id, User.is_super_admin == False).first()
    if not user:
        raise HTTPException(404, "Kullanıcı bulunamadı")

    if payload.sub_days is not None:
        user.sub_days = payload.sub_days
        # sub_expires_at'ı da güncelle
        if payload.sub_days > 0:
            user.sub_expires_at = datetime.utcnow() + timedelta(days=payload.sub_days)
        else:
            user.sub_expires_at = datetime.utcnow()
    if payload.sub_expires_at is not None:
        user.sub_expires_at = payload.sub_expires_at
    if payload.is_active is not None:
        user.is_active = payload.is_active

    db.commit()
    db.refresh(user)
    return {"user": _user_summary(user, db), "updated": True}


# ── 7. Sistem geneli ürün listesi ─────────────────────────────────────────────

@router.get("/products")
async def all_products(
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
    user_id: Optional[int] = Query(None, description="Belirli bir bayinin ürünleri"),
    search: Optional[str] = Query(None),
    low_stock_only: bool = Query(False),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
):
    """Tüm bayilerin ürünleri (sahip bayi bilgisiyle)."""
    q = db.query(Product, User).join(User, Product.user_id == User.id)
    if user_id:
        q = q.filter(Product.user_id == user_id)
    if search:
        q = q.filter(Product.name.ilike(f"%{search}%") | Product.barcode.ilike(f"%{search}%"))
    if low_stock_only:
        q = q.filter(Product.quantity <= Product.min_stock_alert)

    total = q.count()
    rows = q.order_by(desc(Product.updated_at)).offset((page - 1) * page_size).limit(page_size).all()

    return {
        "total": total,
        "items": [
            {
                "id": p.id, "name": p.name, "barcode": p.barcode,
                "price": float(p.price or 0), "quantity": p.quantity,
                "min_stock_alert": p.min_stock_alert,
                "is_low_stock": p.quantity <= p.min_stock_alert,
                "owner": {"id": u.id, "email": u.email, "company_name": getattr(u, "company_name", "") or ""},
                "updated_at": p.updated_at.isoformat() if p.updated_at else None,
            }
            for p, u in rows
        ],
    }


# ── 8. Sistem geneli işlem listesi ───────────────────────────────────────────

@router.get("/transactions")
async def all_transactions(
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
    user_id: Optional[int] = Query(None),
    date_from: Optional[str] = Query(None, description="YYYY-MM-DD"),
    date_to:   Optional[str] = Query(None, description="YYYY-MM-DD"),
    tx_type:   Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
):
    """Tüm bayilerin işlem geçmişi (sahip bayi bilgisiyle)."""
    q = db.query(Transaction, User).join(User, Transaction.user_id == User.id)
    if user_id:
        q = q.filter(Transaction.user_id == user_id)
    if date_from:
        q = q.filter(Transaction.created_at >= datetime.fromisoformat(date_from))
    if date_to:
        q = q.filter(Transaction.created_at <= datetime.fromisoformat(date_to) + timedelta(days=1))
    if tx_type:
        q = q.filter(Transaction.transaction_type == tx_type)

    total = q.count()
    rows = q.order_by(desc(Transaction.created_at)).offset((page - 1) * page_size).limit(page_size).all()

    return {
        "total": total,
        "items": [
            {
                "id": t.id,
                "type": t.transaction_type,
                "total_amount": float(t.total_amount or 0),
                "created_at": t.created_at.isoformat() if t.created_at else None,
                "owner": {"id": u.id, "email": u.email, "company_name": getattr(u, "company_name", "") or ""},
            }
            for t, u in rows
        ],
    }
