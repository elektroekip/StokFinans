from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session, joinedload

from app.core.database import get_db
from app.utils.auth import get_current_user
from app.models import User
from app.models.support import SupportTicket, SupportMessage, TicketCategory, TicketStatus
from app.utils.tenant import data_owner_id

router = APIRouter(prefix="/support", tags=["Support"])


# ── Schemas ──────────────────────────────────────────────────────────────────

CATEGORY_LABELS = {
    TicketCategory.bug: "Hata Bildirimi",
    TicketCategory.request: "Talep",
    TicketCategory.suggestion: "Öneri",
    TicketCategory.other: "Diğer",
}

STATUS_LABELS = {
    TicketStatus.open: "Açık",
    TicketStatus.in_progress: "İşlemde",
    TicketStatus.closed: "Kapalı",
}


class MessageOut(BaseModel):
    id: int
    is_from_admin: bool
    body: str
    created_at: datetime
    sender_name: Optional[str] = None

    class Config:
        from_attributes = True


class TicketOut(BaseModel):
    id: int
    subject: str
    category: str
    category_label: str
    status: str
    status_label: str
    created_at: datetime
    updated_at: datetime
    message_count: int = 0
    last_message_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class TicketDetailOut(TicketOut):
    messages: List[MessageOut] = []


class CreateTicketRequest(BaseModel):
    subject: str = Field(..., min_length=3, max_length=255)
    category: TicketCategory = TicketCategory.other
    body: str = Field(..., min_length=5)


class AddMessageRequest(BaseModel):
    body: str = Field(..., min_length=1)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _ticket_to_out(ticket: SupportTicket) -> TicketOut:
    msgs = ticket.messages or []
    return TicketOut(
        id=ticket.id,
        subject=ticket.subject,
        category=ticket.category.value,
        category_label=CATEGORY_LABELS.get(ticket.category, ticket.category.value),
        status=ticket.status.value,
        status_label=STATUS_LABELS.get(ticket.status, ticket.status.value),
        created_at=ticket.created_at,
        updated_at=ticket.updated_at,
        message_count=len(msgs),
        last_message_at=msgs[-1].created_at if msgs else None,
    )


def _msg_to_out(msg: SupportMessage) -> MessageOut:
    sender_name = None
    if msg.sender:
        sender_name = msg.sender.company_name or msg.sender.full_name or msg.sender.email
    return MessageOut(
        id=msg.id,
        is_from_admin=msg.is_from_admin,
        body=msg.body,
        created_at=msg.created_at,
        sender_name=sender_name,
    )


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.post("/tickets", status_code=201)
def create_ticket(
    payload: CreateTicketRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    from app.services.subscription import check_quota
    quota_err = check_quota(db, current_user, "support_ticket")
    if quota_err:
        raise HTTPException(status_code=429, detail=quota_err)

    owner = data_owner_id(current_user)
    ticket = SupportTicket(
        user_id=owner,
        subject=payload.subject.strip(),
        category=payload.category,
        status=TicketStatus.open,
    )
    db.add(ticket)
    db.flush()
    msg = SupportMessage(
        ticket_id=ticket.id,
        sender_user_id=current_user.id,
        is_from_admin=False,
        body=payload.body.strip(),
    )
    db.add(msg)
    db.commit()
    db.refresh(ticket)
    db.refresh(ticket)
    return {"id": ticket.id, "message": "Talep oluşturuldu."}


@router.get("/tickets", response_model=List[TicketOut])
def list_tickets(
    status: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    owner = data_owner_id(current_user)
    q = (
        db.query(SupportTicket)
        .options(joinedload(SupportTicket.messages))
        .filter(SupportTicket.user_id == owner)
    )
    if status and status != "all":
        try:
            q = q.filter(SupportTicket.status == TicketStatus(status))
        except ValueError:
            pass
    tickets = q.order_by(SupportTicket.updated_at.desc()).limit(200).all()
    return [_ticket_to_out(t) for t in tickets]


@router.get("/tickets/{ticket_id}", response_model=TicketDetailOut)
def get_ticket(
    ticket_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    owner = data_owner_id(current_user)
    ticket = (
        db.query(SupportTicket)
        .options(
            joinedload(SupportTicket.messages).joinedload(SupportMessage.sender)
        )
        .filter(SupportTicket.id == ticket_id, SupportTicket.user_id == owner)
        .first()
    )
    if not ticket:
        raise HTTPException(status_code=404, detail="Talep bulunamadı.")
    out = _ticket_to_out(ticket)
    return TicketDetailOut(
        **out.model_dump(),
        messages=[_msg_to_out(m) for m in ticket.messages],
    )


@router.post("/tickets/{ticket_id}/messages", status_code=201)
def add_message(
    ticket_id: int,
    payload: AddMessageRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    owner = data_owner_id(current_user)
    ticket = db.query(SupportTicket).filter(
        SupportTicket.id == ticket_id, SupportTicket.user_id == owner
    ).first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Talep bulunamadı.")
    if ticket.status == TicketStatus.closed:
        raise HTTPException(status_code=400, detail="Kapalı talebe mesaj eklenemez.")
    msg = SupportMessage(
        ticket_id=ticket.id,
        sender_user_id=current_user.id,
        is_from_admin=False,
        body=payload.body.strip(),
    )
    db.add(msg)
    ticket.updated_at = datetime.now()
    if ticket.status == TicketStatus.in_progress:
        ticket.status = TicketStatus.open
    db.commit()
    return {"message": "Mesaj gönderildi."}
