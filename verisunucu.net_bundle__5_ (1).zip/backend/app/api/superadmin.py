from fastapi import APIRouter, Depends, HTTPException, status, Query, Request
from sqlalchemy.orm import Session
from sqlalchemy import func, or_, desc, text
from pydantic import BaseModel, Field, EmailStr
from typing import Optional, List, Any
from datetime import datetime
import secrets
import string

from app.core.database import get_db
from app.models import User, Product, Transaction, ActivityLog, Category, SubscriptionEvent, Package, Payment, PaytrSetting, Warranty
from app.models.security import SecurityLog, IpBan
from app.models.smtp_setting import SmtpSetting
from app.models.register_notice import RegisterNotice
from app.utils.auth import get_current_super_admin
from app.utils.security import hash_password
from app.utils.crypto import encrypt_secret, decrypt_secret
from app.services.subscription import (
    compute_days_remaining, extend_subscription, set_subscription_days,
    get_package as svc_get_package,
)


router = APIRouter(
    prefix="/superadmin",
    tags=["SuperAdmin"],
    dependencies=[Depends(get_current_super_admin)],
)


class SuperUserSummary(BaseModel):
    id: int
    email: str
    full_name: str
    company_name: Optional[str] = None
    role: str
    ref_code: Optional[str] = None
    sub_days: int
    is_active: bool
    is_super_admin: bool
    created_at: datetime
    product_count: int = 0
    transaction_count: int = 0
    last_activity_at: Optional[datetime] = None
    referred_by_user_id: Optional[int] = None
    referred_by_email: Optional[str] = None
    referred_by_name: Optional[str] = None
    invited_count: int = 0
    package_slug: Optional[str] = None
    package_name: Optional[str] = None
    sub_expires_at: Optional[datetime] = None
    days_remaining: int = 0

    class Config:
        from_attributes = True


class SuperUserListResponse(BaseModel):
    items: List[SuperUserSummary]
    total: int
    page: int
    page_size: int


class SuperUserUpdateRequest(BaseModel):
    full_name: Optional[str] = Field(None, min_length=2)
    company_name: Optional[str] = None
    role: Optional[str] = Field(None, pattern="^(bayi_sahibi|calisan)$")
    is_active: Optional[bool] = None
    sub_days: Optional[int] = Field(None, ge=0, le=10000)
    is_super_admin: Optional[bool] = None


class SubscriptionAdjustRequest(BaseModel):
    delta_days: int = Field(..., description="Eklenecek (+) veya çıkarılacak (-) gün sayısı")
    reason: Optional[str] = None


class ResetPasswordResponse(BaseModel):
    message: str
    new_password: str


class StatsResponse(BaseModel):
    total_users: int
    total_owners: int
    total_employees: int
    active_users: int
    inactive_users: int
    expiring_soon: int  # 7 gün içinde bitiyor
    expired: int  # sub_days <= 0
    total_products: int
    total_transactions: int
    total_categories: int
    new_users_30d: int


def _gen_password(n: int = 12) -> str:
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(n))


def _serialize_user(u: User, product_count: int = 0, transaction_count: int = 0,
                    last_activity_at: Optional[datetime] = None,
                    referred_by_email: Optional[str] = None,
                    referred_by_name: Optional[str] = None,
                    invited_count: int = 0,
                    package_name: Optional[str] = None) -> SuperUserSummary:
    days_left = compute_days_remaining(u.sub_expires_at)
    return SuperUserSummary(
        id=u.id,
        email=u.email,
        full_name=u.full_name,
        company_name=u.company_name,
        role=u.role,
        ref_code=u.ref_code,
        sub_days=days_left,
        is_active=u.is_active,
        is_super_admin=bool(getattr(u, "is_super_admin", False)),
        created_at=u.created_at,
        product_count=product_count,
        transaction_count=transaction_count,
        last_activity_at=last_activity_at,
        referred_by_user_id=getattr(u, "referred_by_user_id", None),
        referred_by_email=referred_by_email,
        referred_by_name=referred_by_name,
        invited_count=invited_count,
        package_slug=getattr(u, "package_slug", None),
        package_name=package_name,
        sub_expires_at=getattr(u, "sub_expires_at", None),
        days_remaining=days_left,
    )


# ============================================================
# STATS — Genel platform istatistikleri
# ============================================================

@router.get("/stats", response_model=StatsResponse)
async def get_stats(db: Session = Depends(get_db)):
    total_users = db.query(func.count(User.id)).scalar() or 0
    total_owners = db.query(func.count(User.id)).filter(User.role == "bayi_sahibi").scalar() or 0
    total_employees = db.query(func.count(User.id)).filter(User.role == "calisan").scalar() or 0
    active_users = db.query(func.count(User.id)).filter(User.is_active == True).scalar() or 0
    inactive_users = db.query(func.count(User.id)).filter(User.is_active == False).scalar() or 0
    expiring_soon = db.query(func.count(User.id)).filter(
        User.sub_days > 0, User.sub_days <= 7
    ).scalar() or 0
    expired = db.query(func.count(User.id)).filter(User.sub_days <= 0).scalar() or 0
    total_products = db.query(func.count(Product.id)).scalar() or 0
    total_transactions = db.query(func.count(Transaction.id)).scalar() or 0
    total_categories = db.query(func.count(Category.id)).scalar() or 0

    from datetime import timedelta
    cutoff = datetime.utcnow() - timedelta(days=30)
    new_users_30d = db.query(func.count(User.id)).filter(User.created_at >= cutoff).scalar() or 0

    return StatsResponse(
        total_users=total_users,
        total_owners=total_owners,
        total_employees=total_employees,
        active_users=active_users,
        inactive_users=inactive_users,
        expiring_soon=expiring_soon,
        expired=expired,
        total_products=total_products,
        total_transactions=total_transactions,
        total_categories=total_categories,
        new_users_30d=new_users_30d,
    )


# ============================================================
# USERS LIST — Tüm kullanıcılar (sayfalı, aranabilir)
# ============================================================

@router.get("/users", response_model=SuperUserListResponse)
async def list_users(
    search: Optional[str] = Query(None, description="Email/ad/firma içinde ara"),
    role: Optional[str] = Query(None, description="bayi_sahibi | calisan"),
    status_filter: Optional[str] = Query(None, alias="status",
                                          description="active|inactive|expired|expiring"),
    sort_by: str = Query("created_at_desc",
                         description="created_at_desc|created_at_asc|sub_days_asc|sub_days_desc|email_asc"),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
    db: Session = Depends(get_db),
):
    q = db.query(User)
    if search:
        s = f"%{search.lower()}%"
        q = q.filter(or_(
            func.lower(User.email).like(s),
            func.lower(User.full_name).like(s),
            func.lower(func.coalesce(User.company_name, '')).like(s),
        ))
    if role in ("bayi_sahibi", "calisan"):
        q = q.filter(User.role == role)
    if status_filter == "active":
        q = q.filter(User.is_active == True, User.sub_days > 0)
    elif status_filter == "inactive":
        q = q.filter(User.is_active == False)
    elif status_filter == "expired":
        q = q.filter(User.sub_days <= 0)
    elif status_filter == "expiring":
        q = q.filter(User.sub_days > 0, User.sub_days <= 7)

    if sort_by == "created_at_asc":
        q = q.order_by(User.created_at.asc())
    elif sort_by == "sub_days_asc":
        q = q.order_by(User.sub_days.asc())
    elif sort_by == "sub_days_desc":
        q = q.order_by(User.sub_days.desc())
    elif sort_by == "email_asc":
        q = q.order_by(func.lower(User.email).asc())
    else:
        q = q.order_by(User.created_at.desc())

    total = q.count()
    users = q.offset((page - 1) * page_size).limit(page_size).all()

    user_ids = [u.id for u in users]
    prod_counts = dict(
        db.query(Product.user_id, func.count(Product.id))
        .filter(Product.user_id.in_(user_ids))
        .group_by(Product.user_id).all()
    ) if user_ids else {}
    txn_counts = dict(
        db.query(Transaction.user_id, func.count(Transaction.id))
        .filter(Transaction.user_id.in_(user_ids))
        .group_by(Transaction.user_id).all()
    ) if user_ids else {}
    last_acts = dict(
        db.query(ActivityLog.user_id, func.max(ActivityLog.created_at))
        .filter(ActivityLog.user_id.in_(user_ids))
        .group_by(ActivityLog.user_id).all()
    ) if user_ids else {}
    inv_counts = dict(
        db.query(User.referred_by_user_id, func.count(User.id))
        .filter(User.referred_by_user_id.in_(user_ids))
        .group_by(User.referred_by_user_id).all()
    ) if user_ids else {}
    referrer_ids = [u.referred_by_user_id for u in users if u.referred_by_user_id]
    referrers_map: dict[int, User] = {}
    if referrer_ids:
        for r in db.query(User).filter(User.id.in_(referrer_ids)).all():
            referrers_map[r.id] = r

    # Paket adları
    pkg_map = {p.slug: p.name for p in db.query(Package).all()}

    items = []
    for u in users:
        ref = referrers_map.get(u.referred_by_user_id) if u.referred_by_user_id else None
        items.append(_serialize_user(
            u,
            product_count=int(prod_counts.get(u.id, 0)),
            transaction_count=int(txn_counts.get(u.id, 0)),
            last_activity_at=last_acts.get(u.id),
            referred_by_email=ref.email if ref else None,
            referred_by_name=ref.full_name if ref else None,
            invited_count=int(inv_counts.get(u.id, 0)),
            package_name=pkg_map.get(u.package_slug or "starter"),
        ))
    return SuperUserListResponse(items=items, total=total, page=page, page_size=page_size)


# ============================================================
# USER DETAIL
# ============================================================

@router.get("/users/{user_id}", response_model=SuperUserSummary)
async def get_user(user_id: int, db: Session = Depends(get_db)):
    u = db.query(User).filter(User.id == user_id).first()
    if not u:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")
    pc = db.query(func.count(Product.id)).filter(Product.user_id == user_id).scalar() or 0
    tc = db.query(func.count(Transaction.id)).filter(Transaction.user_id == user_id).scalar() or 0
    la = db.query(func.max(ActivityLog.created_at)).filter(ActivityLog.user_id == user_id).scalar()
    ic = db.query(func.count(User.id)).filter(User.referred_by_user_id == user_id).scalar() or 0
    ref = None
    if u.referred_by_user_id:
        ref = db.query(User).filter(User.id == u.referred_by_user_id).first()
    return _serialize_user(
        u,
        product_count=int(pc),
        transaction_count=int(tc),
        last_activity_at=la,
        invited_count=int(ic),
        referred_by_email=ref.email if ref else None,
        referred_by_name=ref.full_name if ref else None,
    )


# ============================================================
# UPDATE USER (full_name, role, is_active, sub_days, is_super_admin)
# ============================================================

@router.patch("/users/{user_id}", response_model=SuperUserSummary)
async def update_user(
    user_id: int,
    payload: SuperUserUpdateRequest,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    u = db.query(User).filter(User.id == user_id).first()
    if not u:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")

    # Güvenlik: bir süper yönetici kendi süper admin yetkisini kaldıramaz/pasifleştiremez
    if u.id == current_admin.id:
        if payload.is_super_admin is False:
            raise HTTPException(status_code=400,
                                detail="Kendi süper yönetici yetkinizi kaldıramazsınız")
        if payload.is_active is False:
            raise HTTPException(status_code=400,
                                detail="Kendi hesabınızı pasifleştiremezsiniz")

    if payload.full_name is not None:
        u.full_name = payload.full_name.strip()
    if payload.company_name is not None:
        u.company_name = payload.company_name.strip() or None
    if payload.role is not None:
        u.role = payload.role
    if payload.is_active is not None:
        u.is_active = payload.is_active

    sub_days_event = None
    if payload.sub_days is not None:
        new_val = max(0, int(payload.sub_days))
        old_val = compute_days_remaining(u.sub_expires_at)
        if new_val != old_val:
            set_subscription_days(u, new_val)
            sub_days_event = SubscriptionEvent(
                user_id=u.id,
                event_type="admin_set",
                days_delta=new_val - old_val,
                days_before=old_val,
                days_after=new_val,
                actor_user_id=current_admin.id,
                related_user_id=None,
                note=f"Süper yönetici tam değere set etti: {old_val} → {new_val}",
            )

    if payload.is_super_admin is not None:
        u.is_super_admin = bool(payload.is_super_admin)

    if sub_days_event is not None:
        db.add(sub_days_event)
    db.commit()
    db.refresh(u)
    return _serialize_user(u)


# ============================================================
# SUBSCRIPTION ADJUST (gün ekle/çıkar)
# ============================================================

@router.post("/users/{user_id}/subscription/adjust", response_model=SuperUserSummary)
async def adjust_subscription(
    user_id: int,
    payload: SubscriptionAdjustRequest,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    # Atomik: ROW LOCK + extend_subscription (sub_expires_at ile senkron)
    u = db.query(User).filter(User.id == user_id).with_for_update().first()
    if not u:
        db.rollback()
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")

    days_before, days_after = extend_subscription(u, int(payload.delta_days))
    actual_delta = days_after - days_before
    db.add(SubscriptionEvent(
        user_id=user_id,
        event_type="admin_adjust",
        days_delta=actual_delta,
        days_before=days_before,
        days_after=days_after,
        actor_user_id=current_admin.id,
        related_user_id=None,
        note=(payload.reason or f"Süper yönetici talebi: {payload.delta_days:+d} gün ({days_before} → {days_after})"),
    ))
    db.commit()
    db.refresh(u)
    return _serialize_user(u)


# ============================================================
# RESET PASSWORD (rastgele üret, döndür)
# ============================================================

@router.post("/users/{user_id}/reset-password", response_model=ResetPasswordResponse)
async def reset_password(user_id: int, db: Session = Depends(get_db)):
    u = db.query(User).filter(User.id == user_id).first()
    if not u:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")
    new_pwd = _gen_password(12)
    u.password_hash = hash_password(new_pwd)
    db.commit()
    return ResetPasswordResponse(
        message="Şifre sıfırlandı. Yeni şifreyi kullanıcıya iletin (bir daha gösterilmeyecek).",
        new_password=new_pwd,
    )


# ============================================================
# DELETE USER (kullanıcı + tüm verileri)
# ============================================================

def _purge_user_data(db: Session, uid: int) -> None:
    """
    Bir kullanıcıya ait tüm FK bağımlı satırları doğru sırayla siler.
    Sahiplik olmayan FK'lar (actor, assigned_by vb.) NULL'a çekilir.
    Her satır try/except içindedir — henüz var olmayan tablolar sessizce geçilir.
    """
    p = {"uid": uid}

    def run(sql: str) -> None:
        db.execute(text(sql), p)

    # ── 1. Sahiplik OLMAYAN referansları NULL yap ──────────────────────────
    run("UPDATE subscription_events SET actor_user_id   = NULL WHERE actor_user_id   = :uid")
    run("UPDATE subscription_events SET related_user_id = NULL WHERE related_user_id = :uid")
    run("UPDATE vehicle_assignments  SET assigned_by_user_id = NULL WHERE assigned_by_user_id = :uid")
    run("UPDATE vehicles             SET assigned_employee_id = NULL WHERE assigned_employee_id = :uid")
    run("UPDATE btb_customers        SET linked_user_id = NULL WHERE linked_user_id = :uid")
    run("UPDATE employee_invites     SET consumed_user_id = NULL WHERE consumed_user_id = :uid")
    run("UPDATE deploy_batches       SET initiated_by = NULL WHERE initiated_by = :uid")
    run("UPDATE api_keys             SET created_by_id = NULL WHERE created_by_id = :uid")
    db.flush()

    # ── 2. Kademeli silme (alt FK önce) ────────────────────────────────────
    # BtB: bağımlı tablolar önce
    run("DELETE FROM btb_activity_logs WHERE user_id = :uid")
    run("DELETE FROM btb_orders        WHERE user_id = :uid")
    run("DELETE FROM btb_portal_accounts WHERE bayi_user_id = :uid")
    run("DELETE FROM visit_plans       WHERE user_id = :uid")
    run("DELETE FROM btb_customers     WHERE user_id = :uid")
    run("DELETE FROM btb_price_lists   WHERE user_id = :uid")

    # Destek: mesajlar bilet'e FK, önce mesajlar
    run("DELETE FROM support_messages WHERE ticket_id IN (SELECT id FROM support_tickets WHERE user_id = :uid)")
    run("DELETE FROM support_messages WHERE sender_user_id = :uid")
    run("DELETE FROM support_tickets  WHERE user_id = :uid")

    # Araçlar: atamalar ve loglar araç'a FK, önce onlar
    run("DELETE FROM vehicle_assignments WHERE user_id = :uid")
    run("DELETE FROM vehicle_logs        WHERE user_id = :uid")
    run("DELETE FROM vehicles            WHERE user_id = :uid")

    # Diğer sahiplik tabloları
    run("DELETE FROM devices           WHERE user_id = :uid")
    run("DELETE FROM storage_files     WHERE user_id = :uid")
    run("DELETE FROM erp_sync_logs     WHERE user_id = :uid")
    run("DELETE FROM erp_webhooks      WHERE user_id = :uid")
    run("DELETE FROM payment_gateways  WHERE user_id = :uid")
    run("DELETE FROM payments          WHERE user_id = :uid")
    run("DELETE FROM warranties        WHERE user_id = :uid")
    run("DELETE FROM dbs_agreements    WHERE user_id = :uid")
    run("DELETE FROM dbs_invoices      WHERE user_id = :uid")
    run("DELETE FROM debtor_links      WHERE user_id = :uid")
    run("DELETE FROM employee_invites  WHERE parent_user_id = :uid")
    run("DELETE FROM customer_visits   WHERE user_id = :uid")
    run("DELETE FROM bayi_backups      WHERE user_id = :uid")
    run("DELETE FROM pos_transactions  WHERE user_id = :uid")
    run("DELETE FROM purchase_orders   WHERE user_id = :uid")
    run("DELETE FROM api_keys          WHERE user_id = :uid")
    run("DELETE FROM user_sessions     WHERE user_id = :uid")
    run("DELETE FROM subscription_events WHERE user_id = :uid")
    run("DELETE FROM activity_logs     WHERE user_id = :uid")
    # btb_orders references transactions — orders already deleted above
    run("DELETE FROM transactions      WHERE user_id = :uid")
    run("DELETE FROM products          WHERE user_id = :uid")
    run("DELETE FROM categories        WHERE user_id = :uid")
    db.flush()


@router.delete("/users/{user_id}", status_code=200)
async def delete_user(
    user_id: int,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    u = db.query(User).filter(User.id == user_id).first()
    if not u:
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")
    if u.id == current_admin.id:
        raise HTTPException(status_code=400, detail="Kendi hesabınızı silemezsiniz")

    try:
        # Alt kullanıcılar (çalışanlar) — önce onların verisini temizle
        child_ids = [
            row[0] for row in db.execute(
                text("SELECT id FROM users WHERE parent_user_id = :uid"), {"uid": user_id}
            ).fetchall()
        ]
        for cid in child_ids:
            _purge_user_data(db, cid)

        # Ana kullanıcı verisini temizle
        _purge_user_data(db, user_id)

        # Önce çocukları, sonra ana kullanıcıyı sil
        if child_ids:
            db.execute(
                text("DELETE FROM users WHERE parent_user_id = :uid"), {"uid": user_id}
            )
        db.execute(text("DELETE FROM users WHERE id = :uid"), {"uid": user_id})
        db.commit()

        return {
            "message": "Kullanıcı ve tüm verileri silindi",
            "user_id": user_id,
            "deleted_workers": len(child_ids),
        }
    except Exception as exc:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Silme hatası: {exc}")


# ============================================================
# USER PRODUCTS / TRANSACTIONS / LOGS (cross-tenant inceleme)
# ============================================================

@router.get("/users/{user_id}/products")
async def user_products(
    user_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(100, ge=1, le=500),
    db: Session = Depends(get_db),
):
    if not db.query(User.id).filter(User.id == user_id).first():
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")
    q = db.query(Product).filter(Product.user_id == user_id).order_by(Product.id.desc())
    total = q.count()
    rows = q.offset((page - 1) * page_size).limit(page_size).all()
    items = [{
        "id": p.id,
        "name": p.name,
        "category": p.category,
        "subcategory": p.subcategory,
        "barcode": p.barcode,
        "quantity": p.quantity,
        "min_stock_alert": p.min_stock_alert,
        "buy_price": float(p.buy_price or 0),
        "sell_price": float(p.sell_price or 0),
        "currency": p.currency,
        "image_url": getattr(p, "image_url", None),
        "extra_categories": list(p.extra_categories or []),
        "created_at": p.created_at,
    } for p in rows]
    return {"items": items, "total": total, "page": page, "page_size": page_size}


@router.get("/users/{user_id}/transactions")
async def user_transactions(
    user_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(100, ge=1, le=500),
    db: Session = Depends(get_db),
):
    if not db.query(User.id).filter(User.id == user_id).first():
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")
    q = db.query(Transaction).filter(Transaction.user_id == user_id).order_by(Transaction.id.desc())
    total = q.count()
    rows = q.offset((page - 1) * page_size).limit(page_size).all()
    items = [{
        "id": t.id,
        "type": str(t.transaction_type.value if hasattr(t.transaction_type, 'value') else t.transaction_type),
        "customer_name": t.customer_name,
        "amount": float(t.amount or 0),
        "currency": t.currency,
        "created_at": t.created_at,
    } for t in rows]
    return {"items": items, "total": total, "page": page, "page_size": page_size}


@router.get("/users/{user_id}/logs")
async def user_logs(
    user_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(100, ge=1, le=500),
    db: Session = Depends(get_db),
):
    if not db.query(User.id).filter(User.id == user_id).first():
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")
    q = (db.query(ActivityLog)
         .filter(ActivityLog.user_id == user_id)
         .order_by(ActivityLog.created_at.desc()))
    total = q.count()
    rows = q.offset((page - 1) * page_size).limit(page_size).all()
    items = [{
        "id": l.id,
        "user_name": l.user_name,
        "action_type": l.action_type,
        "entity_type": l.entity_type,
        "entity_id": l.entity_id,
        "description": l.description,
        "status": l.status,
        "ip_address": l.ip_address,
        "created_at": l.created_at,
    } for l in rows]
    return {"items": items, "total": total, "page": page, "page_size": page_size}


# ============================================================
# SUBSCRIPTION EVENTS — Aboneliği yenilenen / artırılan bayiler
# ============================================================

EVENT_LABELS = {
    "initial":                  "İlk Kayıt",
    "referral_bonus_received":  "Referans Bonusu Alındı",
    "referral_bonus_given":     "Referans Bonusu Verildi",
    "admin_adjust":             "Yönetici Ekledi/Düştü",
    "admin_set":                "Yönetici Tam Değere Set Etti",
}


def _serialize_event(ev: SubscriptionEvent, user_map: dict, actor_map: dict, related_map: dict) -> dict:
    u = user_map.get(ev.user_id)
    actor = actor_map.get(ev.actor_user_id) if ev.actor_user_id else None
    related = related_map.get(ev.related_user_id) if ev.related_user_id else None
    return {
        "id": ev.id,
        "user_id": ev.user_id,
        "user_email": u.email if u else None,
        "user_full_name": u.full_name if u else None,
        "user_company": (u.company_name if u else None),
        "event_type": ev.event_type,
        "event_label": EVENT_LABELS.get(ev.event_type, ev.event_type),
        "days_delta": ev.days_delta,
        "days_before": ev.days_before,
        "days_after": ev.days_after,
        "actor_user_id": ev.actor_user_id,
        "actor_full_name": actor.full_name if actor else None,
        "actor_email": actor.email if actor else None,
        "related_user_id": ev.related_user_id,
        "related_full_name": related.full_name if related else None,
        "related_email": related.email if related else None,
        "note": ev.note,
        "created_at": ev.created_at,
    }


def _hydrate_users(db: Session, ids: set) -> dict:
    ids = {i for i in ids if i}
    if not ids:
        return {}
    rows = db.query(User).filter(User.id.in_(ids)).all()
    return {u.id: u for u in rows}


@router.get("/subscription/stats")
async def subscription_stats(
    days: int = Query(30, ge=1, le=365, description="Son kaç gün"),
    db: Session = Depends(get_db),
):
    """
    Son N gün için abonelik aktivitesi özeti.
    """
    from datetime import timedelta
    cutoff = datetime.utcnow() - timedelta(days=days)
    base = db.query(SubscriptionEvent).filter(SubscriptionEvent.created_at >= cutoff)

    total_events = base.count()
    total_added = db.query(func.coalesce(func.sum(SubscriptionEvent.days_delta), 0)) \
        .filter(SubscriptionEvent.created_at >= cutoff,
                SubscriptionEvent.days_delta > 0).scalar() or 0
    total_removed = db.query(func.coalesce(func.sum(SubscriptionEvent.days_delta), 0)) \
        .filter(SubscriptionEvent.created_at >= cutoff,
                SubscriptionEvent.days_delta < 0).scalar() or 0
    distinct_users = db.query(func.count(func.distinct(SubscriptionEvent.user_id))) \
        .filter(SubscriptionEvent.created_at >= cutoff).scalar() or 0

    by_type_rows = (db.query(SubscriptionEvent.event_type,
                             func.count(SubscriptionEvent.id),
                             func.coalesce(func.sum(SubscriptionEvent.days_delta), 0))
                    .filter(SubscriptionEvent.created_at >= cutoff)
                    .group_by(SubscriptionEvent.event_type)
                    .all())
    by_type = [{
        "event_type": r[0],
        "event_label": EVENT_LABELS.get(r[0], r[0]),
        "count": int(r[1] or 0),
        "days_total": int(r[2] or 0),
    } for r in by_type_rows]

    # En çok süre kazanan kullanıcı (pozitif toplam)
    top_row = (db.query(SubscriptionEvent.user_id,
                        func.coalesce(func.sum(SubscriptionEvent.days_delta), 0).label("total"),
                        func.count(SubscriptionEvent.id).label("cnt"))
               .filter(SubscriptionEvent.created_at >= cutoff,
                       SubscriptionEvent.days_delta > 0)
               .group_by(SubscriptionEvent.user_id)
               .order_by(func.sum(SubscriptionEvent.days_delta).desc())
               .first())
    top_user = None
    if top_row:
        u = db.query(User).filter(User.id == top_row[0]).first()
        if u:
            top_user = {
                "id": u.id, "full_name": u.full_name, "email": u.email,
                "ref_code": u.ref_code,
                "days_added_in_period": int(top_row[1] or 0),
                "events_in_period": int(top_row[2] or 0),
                "current_sub_days": int(u.sub_days or 0),
            }

    return {
        "period_days": days,
        "total_events": int(total_events),
        "total_days_added": int(total_added),
        "total_days_removed": int(total_removed),
        "net_days_change": int(int(total_added) + int(total_removed)),
        "distinct_users": int(distinct_users),
        "by_type": by_type,
        "top_user": top_user,
    }


@router.get("/subscription/events")
async def subscription_events_list(
    search: Optional[str] = Query(None, description="Kullanıcı / yönetici / not içinde ara"),
    event_type: Optional[str] = Query(None, description="Tek tip filtresi"),
    days: Optional[int] = Query(None, ge=1, le=365, description="Son kaç gün (boş = tümü)"),
    only_positive: bool = Query(False, description="Sadece artış olayları"),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
):
    """
    Abonelik gün bakiyesinde gerçekleşen tüm hareketler.
    """
    q = db.query(SubscriptionEvent)
    if event_type:
        q = q.filter(SubscriptionEvent.event_type == event_type)
    if only_positive:
        q = q.filter(SubscriptionEvent.days_delta > 0)
    if days:
        from datetime import timedelta
        cutoff = datetime.utcnow() - timedelta(days=days)
        q = q.filter(SubscriptionEvent.created_at >= cutoff)

    if search:
        s = f"%{search.lower()}%"
        # JOIN target user, actor için filtre
        Target = User
        q = (q.outerjoin(Target, Target.id == SubscriptionEvent.user_id)
              .filter(or_(
                  func.lower(Target.email).like(s),
                  func.lower(Target.full_name).like(s),
                  func.lower(func.coalesce(Target.company_name, '')).like(s),
                  func.lower(func.coalesce(SubscriptionEvent.note, '')).like(s),
              )))

    total = q.with_entities(func.count(SubscriptionEvent.id)).scalar() or 0
    rows = (q.order_by(SubscriptionEvent.created_at.desc())
              .offset((page - 1) * page_size).limit(page_size).all())

    user_ids = set()
    actor_ids = set()
    related_ids = set()
    for ev in rows:
        user_ids.add(ev.user_id)
        if ev.actor_user_id: actor_ids.add(ev.actor_user_id)
        if ev.related_user_id: related_ids.add(ev.related_user_id)
    all_ids = user_ids | actor_ids | related_ids
    user_map = _hydrate_users(db, all_ids)

    items = [_serialize_event(ev, user_map, user_map, user_map) for ev in rows]
    return {"items": items, "total": int(total), "page": page, "page_size": page_size}


@router.get("/users/{user_id}/subscription/events")
async def user_subscription_events(
    user_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
):
    """Bir kullanıcının abonelik geçmişi."""
    if not db.query(User.id).filter(User.id == user_id).first():
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")
    base = (db.query(SubscriptionEvent)
              .filter(SubscriptionEvent.user_id == user_id)
              .order_by(SubscriptionEvent.created_at.desc()))
    total = base.count()
    rows = base.offset((page - 1) * page_size).limit(page_size).all()

    actor_ids = {ev.actor_user_id for ev in rows if ev.actor_user_id}
    related_ids = {ev.related_user_id for ev in rows if ev.related_user_id}
    user_map = _hydrate_users(db, actor_ids | related_ids | {user_id})

    items = [_serialize_event(ev, user_map, user_map, user_map) for ev in rows]
    return {"items": items, "total": total, "page": page, "page_size": page_size}


# ============================================================
# REFERRALS — Kim kimi davet etti / kim kimin koduyla geldi
# ============================================================

@router.get("/referrals/stats")
async def referrals_stats(db: Session = Depends(get_db)):
    """
    Tüm referans hareketleri için global istatistikler (sayfalamadan bağımsız).
    """
    total_invited = db.query(func.count(User.id)).filter(User.referred_by_user_id.isnot(None)).scalar() or 0
    active_referrers = (db.query(func.count(func.distinct(User.referred_by_user_id)))
                          .filter(User.referred_by_user_id.isnot(None))
                          .scalar() or 0)
    top_row = (db.query(
                    User.referred_by_user_id.label("rid"),
                    func.count(User.id).label("cnt"),
                )
                .filter(User.referred_by_user_id.isnot(None))
                .group_by(User.referred_by_user_id)
                .order_by(func.count(User.id).desc())
                .first())
    top_referrer = None
    if top_row and top_row.rid:
        u = db.query(User).filter(User.id == top_row.rid).first()
        if u:
            top_referrer = {
                "id": u.id,
                "full_name": u.full_name,
                "email": u.email,
                "ref_code": u.ref_code,
                "invited_count": int(top_row.cnt or 0),
            }
    return {
        "total_invited": int(total_invited),
        "active_referrers": int(active_referrers),
        "top_referrer": top_referrer,
    }


@router.get("/referrals/summary")
async def referrals_summary(
    search: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
    db: Session = Depends(get_db),
):
    """
    Her bir referrer (kod sahibi) için özet:
    {referrer_id, email, full_name, ref_code, invited_count, last_invited_at}
    invited_count = bu kullanıcının kodu ile kayıt olan toplam bayı sayısı.
    """
    sub = (db.query(
        User.referred_by_user_id.label("rid"),
        func.count(User.id).label("cnt"),
        func.max(User.created_at).label("last_at"),
    )
    .filter(User.referred_by_user_id.isnot(None))
    .group_by(User.referred_by_user_id)
    .subquery())

    q = (db.query(User, sub.c.cnt, sub.c.last_at)
         .join(sub, User.id == sub.c.rid))
    if search:
        s = f"%{search.lower()}%"
        q = q.filter(or_(
            func.lower(User.email).like(s),
            func.lower(User.full_name).like(s),
            func.lower(func.coalesce(User.ref_code, '')).like(s),
        ))
    q = q.order_by(sub.c.cnt.desc(), sub.c.last_at.desc())
    total = q.count()
    rows = q.offset((page - 1) * page_size).limit(page_size).all()
    items = [{
        "referrer_id": u.id,
        "email": u.email,
        "full_name": u.full_name,
        "company_name": u.company_name,
        "ref_code": u.ref_code,
        "is_active": u.is_active,
        "invited_count": int(cnt or 0),
        "last_invited_at": last_at,
    } for (u, cnt, last_at) in rows]
    return {"items": items, "total": total, "page": page, "page_size": page_size}


@router.get("/referrals/pairs")
async def referrals_pairs(
    search: Optional[str] = Query(None, description="Davet eden veya davet edilen tarafta ara"),
    page: int = Query(1, ge=1),
    page_size: int = Query(100, ge=1, le=500),
    db: Session = Depends(get_db),
):
    """
    Tüm 'kim → kimi davet etti' çiftlerini döndürür.
    """
    Inviter = User.__table__.alias("inviter")
    Invited = User
    q = (db.query(
            Invited.id.label("invited_id"),
            Invited.email.label("invited_email"),
            Invited.full_name.label("invited_name"),
            Invited.company_name.label("invited_company"),
            Invited.is_active.label("invited_active"),
            Invited.created_at.label("invited_at"),
            Inviter.c.id.label("inviter_id"),
            Inviter.c.email.label("inviter_email"),
            Inviter.c.full_name.label("inviter_name"),
            Inviter.c.ref_code.label("inviter_code"),
         )
         .outerjoin(Inviter, Invited.referred_by_user_id == Inviter.c.id)
         .filter(Invited.referred_by_user_id.isnot(None))
         .order_by(Invited.created_at.desc()))
    if search:
        s = f"%{search.lower()}%"
        q = q.filter(or_(
            func.lower(Invited.email).like(s),
            func.lower(Invited.full_name).like(s),
            func.lower(func.coalesce(Inviter.c.email, '')).like(s),
            func.lower(func.coalesce(Inviter.c.full_name, '')).like(s),
            func.lower(func.coalesce(Inviter.c.ref_code, '')).like(s),
        ))
    total = q.count()
    rows = q.offset((page - 1) * page_size).limit(page_size).all()
    items = [{
        "invited_id": r.invited_id,
        "invited_email": r.invited_email,
        "invited_name": r.invited_name,
        "invited_company": r.invited_company,
        "invited_active": r.invited_active,
        "invited_at": r.invited_at,
        "inviter_id": r.inviter_id,
        "inviter_email": r.inviter_email,
        "inviter_name": r.inviter_name,
        "inviter_code": r.inviter_code,
    } for r in rows]
    return {"items": items, "total": total, "page": page, "page_size": page_size}


@router.get("/users/{user_id}/invited")
async def user_invited(
    user_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
):
    """Verilen kullanıcının kodunu kullanarak kayıt olan tüm kullanıcılar (sayfalı)."""
    if not db.query(User.id).filter(User.id == user_id).first():
        raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")
    base = (db.query(User)
              .filter(User.referred_by_user_id == user_id)
              .order_by(User.created_at.desc()))
    total = base.count()
    rows = base.offset((page - 1) * page_size).limit(page_size).all()
    items = [{
        "id": u.id,
        "email": u.email,
        "full_name": u.full_name,
        "company_name": u.company_name,
        "is_active": u.is_active,
        "sub_days": u.sub_days,
        "created_at": u.created_at,
    } for u in rows]
    return {"items": items, "total": total, "page": page, "page_size": page_size}


# ============================================================
# GLOBAL LOGS (cross-tenant)
# ============================================================

@router.get("/logs")
async def all_logs(
    search: Optional[str] = Query(None),
    action_type: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(100, ge=1, le=500),
    db: Session = Depends(get_db),
):
    q = db.query(ActivityLog)
    if action_type:
        q = q.filter(ActivityLog.action_type == action_type)
    if search:
        s = f"%{search.lower()}%"
        q = q.filter(or_(
            func.lower(ActivityLog.user_name).like(s),
            func.lower(ActivityLog.description).like(s),
            func.lower(ActivityLog.entity_type).like(s),
        ))
    q = q.order_by(ActivityLog.created_at.desc())
    total = q.count()
    rows = q.offset((page - 1) * page_size).limit(page_size).all()
    items = [{
        "id": l.id,
        "user_id": l.user_id,
        "user_name": l.user_name,
        "action_type": l.action_type,
        "entity_type": l.entity_type,
        "entity_id": l.entity_id,
        "description": l.description,
        "status": l.status,
        "ip_address": l.ip_address,
        "created_at": l.created_at,
    } for l in rows]
    return {"items": items, "total": total, "page": page, "page_size": page_size}


# ============================================================
# PAKETLER (CRUD - sadece okuma + güncelleme; silme yok)
# ============================================================

class PackageOutAdmin(BaseModel):
    id: int
    slug: str
    name: str
    description: Optional[str] = None
    price_try: int
    duration_days: int
    max_products: Optional[int] = None
    max_transactions: Optional[int] = None
    max_support_tickets: Optional[int] = None
    has_support: bool
    is_featured: bool
    is_active: bool
    sort_order: int
    features: List[str] = []
    color_class: Optional[str] = None
    user_count: int = 0


class PackageUpdateRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    price_try: Optional[int] = Field(None, ge=0)
    duration_days: Optional[int] = Field(None, ge=1, le=3650)
    max_products: Optional[int] = Field(None, ge=0)
    max_transactions: Optional[int] = Field(None, ge=0)
    max_support_tickets: Optional[int] = Field(None, ge=0)
    max_products_unlimited: Optional[bool] = None
    max_transactions_unlimited: Optional[bool] = None
    max_support_tickets_unlimited: Optional[bool] = None
    has_support: Optional[bool] = None
    is_featured: Optional[bool] = None
    is_active: Optional[bool] = None
    sort_order: Optional[int] = None
    features: Optional[List[str]] = None
    color_class: Optional[str] = None


def _serialize_pkg(p: Package, user_count: int = 0) -> PackageOutAdmin:
    return PackageOutAdmin(
        id=p.id, slug=p.slug, name=p.name, description=p.description,
        price_try=p.price_try, duration_days=p.duration_days,
        max_products=p.max_products, max_transactions=p.max_transactions,
        max_support_tickets=p.max_support_tickets,
        has_support=p.has_support, is_featured=p.is_featured,
        is_active=p.is_active, sort_order=p.sort_order,
        features=list(p.features_json or []), color_class=p.color_class,
        user_count=user_count,
    )


@router.get("/packages", response_model=List[PackageOutAdmin])
async def admin_list_packages(db: Session = Depends(get_db)):
    pkgs = db.query(Package).order_by(Package.sort_order).all()
    counts = dict(
        db.query(User.package_slug, func.count(User.id))
          .group_by(User.package_slug).all()
    )
    return [_serialize_pkg(p, int(counts.get(p.slug, 0))) for p in pkgs]


@router.patch("/packages/{slug}", response_model=PackageOutAdmin)
async def admin_update_package(slug: str, payload: PackageUpdateRequest, db: Session = Depends(get_db)):
    p = db.query(Package).filter(Package.slug == slug).first()
    if not p:
        raise HTTPException(status_code=404, detail="Paket bulunamadı")
    if payload.name is not None: p.name = payload.name.strip()
    if payload.description is not None: p.description = payload.description
    if payload.price_try is not None: p.price_try = int(payload.price_try)
    if payload.duration_days is not None: p.duration_days = int(payload.duration_days)
    if payload.max_products_unlimited is True:
        p.max_products = None
    elif payload.max_products is not None:
        p.max_products = int(payload.max_products)
    if payload.max_transactions_unlimited is True:
        p.max_transactions = None
    elif payload.max_transactions is not None:
        p.max_transactions = int(payload.max_transactions)
    if payload.max_support_tickets_unlimited is True:
        p.max_support_tickets = None
    elif payload.max_support_tickets is not None:
        p.max_support_tickets = int(payload.max_support_tickets)
    if payload.has_support is not None: p.has_support = bool(payload.has_support)
    if payload.is_featured is not None: p.is_featured = bool(payload.is_featured)
    if payload.is_active is not None: p.is_active = bool(payload.is_active)
    if payload.sort_order is not None: p.sort_order = int(payload.sort_order)
    if payload.features is not None: p.features_json = list(payload.features)
    if payload.color_class is not None: p.color_class = payload.color_class
    db.commit()
    db.refresh(p)
    cnt = db.query(func.count(User.id)).filter(User.package_slug == p.slug).scalar() or 0
    return _serialize_pkg(p, int(cnt))


# ============================================================
# ÖDEMELER
# ============================================================

@router.get("/payments")
async def admin_list_payments(
    db: Session = Depends(get_db),
    status_filter: Optional[str] = Query(None, alias="status"),
    search: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
):
    q = db.query(Payment, User).join(User, User.id == Payment.user_id)
    if status_filter:
        q = q.filter(Payment.status == status_filter)
    if search:
        s = f"%{search.lower()}%"
        q = q.filter(or_(
            func.lower(User.email).like(s),
            func.lower(Payment.paytr_merchant_oid).like(s),
        ))
    q = q.order_by(Payment.created_at.desc())
    total = q.count()
    rows = q.offset((page - 1) * page_size).limit(page_size).all()
    items = []
    for p, u in rows:
        items.append({
            "id": p.id,
            "user_id": u.id,
            "user_email": u.email,
            "user_name": u.full_name,
            "package_slug": p.package_slug,
            "amount_try": p.amount_try,
            "merchant_oid": p.paytr_merchant_oid,
            "status": p.status,
            "days_added": p.days_added,
            "test_mode": bool(p.test_mode),
            "error_message": p.error_message,
            "created_at": p.created_at,
            "completed_at": p.completed_at,
        })
    # Özet
    sum_success = db.query(func.coalesce(func.sum(Payment.amount_try), 0))\
                    .filter(Payment.status == "success").scalar() or 0
    cnt_success = db.query(func.count(Payment.id)).filter(Payment.status == "success").scalar() or 0
    cnt_pending = db.query(func.count(Payment.id)).filter(Payment.status == "pending").scalar() or 0
    cnt_failed = db.query(func.count(Payment.id)).filter(Payment.status == "failed").scalar() or 0
    return {
        "items": items, "total": total, "page": page, "page_size": page_size,
        "summary": {
            "total_revenue_try": int(sum_success),
            "success_count": int(cnt_success),
            "pending_count": int(cnt_pending),
            "failed_count": int(cnt_failed),
        }
    }


# ============================================================
# PAYTR AYARLARI
# ============================================================

class PaytrSettingOut(BaseModel):
    merchant_id: Optional[str] = None
    merchant_key_masked: Optional[str] = None
    merchant_salt_masked: Optional[str] = None
    test_mode: bool = True
    callback_url: Optional[str] = None
    success_url: Optional[str] = None
    fail_url: Optional[str] = None
    is_configured: bool = False
    updated_at: Optional[datetime] = None


class PaytrSettingUpdate(BaseModel):
    merchant_id: Optional[str] = None
    merchant_key: Optional[str] = None
    merchant_salt: Optional[str] = None
    test_mode: Optional[bool] = None
    callback_url: Optional[str] = None
    success_url: Optional[str] = None
    fail_url: Optional[str] = None


def _mask(s: Optional[str]) -> Optional[str]:
    if not s:
        return None
    if len(s) <= 6:
        return "*" * len(s)
    return s[:3] + "*" * (len(s) - 6) + s[-3:]


@router.get("/paytr", response_model=PaytrSettingOut)
async def admin_get_paytr(db: Session = Depends(get_db)):
    s = db.query(PaytrSetting).filter(PaytrSetting.id == 1).first()
    if not s:
        s = PaytrSetting(id=1, test_mode=True, is_configured=False)
        db.add(s); db.commit(); db.refresh(s)
    return PaytrSettingOut(
        merchant_id=s.merchant_id,
        merchant_key_masked=_mask(s.merchant_key),
        merchant_salt_masked=_mask(s.merchant_salt),
        test_mode=bool(s.test_mode),
        callback_url=s.callback_url,
        success_url=s.success_url,
        fail_url=s.fail_url,
        is_configured=bool(s.is_configured),
        updated_at=s.updated_at,
    )


@router.put("/paytr", response_model=PaytrSettingOut)
async def admin_update_paytr(
    payload: PaytrSettingUpdate,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    s = db.query(PaytrSetting).filter(PaytrSetting.id == 1).first()
    if not s:
        s = PaytrSetting(id=1, test_mode=True, is_configured=False)
        db.add(s); db.flush()
    if payload.merchant_id is not None: s.merchant_id = payload.merchant_id.strip() or None
    if payload.merchant_key is not None and payload.merchant_key.strip(): s.merchant_key = payload.merchant_key.strip()
    if payload.merchant_salt is not None and payload.merchant_salt.strip(): s.merchant_salt = payload.merchant_salt.strip()
    if payload.test_mode is not None: s.test_mode = bool(payload.test_mode)
    if payload.callback_url is not None: s.callback_url = payload.callback_url.strip() or None
    if payload.success_url is not None: s.success_url = payload.success_url.strip() or None
    if payload.fail_url is not None: s.fail_url = payload.fail_url.strip() or None
    s.is_configured = bool(s.merchant_id and s.merchant_key and s.merchant_salt)
    s.updated_by_user_id = current_admin.id
    db.commit(); db.refresh(s)
    return PaytrSettingOut(
        merchant_id=s.merchant_id,
        merchant_key_masked=_mask(s.merchant_key),
        merchant_salt_masked=_mask(s.merchant_salt),
        test_mode=bool(s.test_mode),
        callback_url=s.callback_url,
        success_url=s.success_url,
        fail_url=s.fail_url,
        is_configured=bool(s.is_configured),
        updated_at=s.updated_at,
    )


# ============================================================
# SMTP AYARLARI
# ============================================================

class SmtpSettingOut(BaseModel):
    host: Optional[str] = None
    port: int = 587
    username: Optional[str] = None
    password_masked: Optional[str] = None
    from_email: Optional[str] = None
    from_name: Optional[str] = None
    use_tls: bool = True
    use_ssl: bool = False
    is_configured: bool = False
    updated_at: Optional[datetime] = None


class SmtpSettingUpdate(BaseModel):
    host: Optional[str] = None
    port: Optional[int] = None
    username: Optional[str] = None
    password: Optional[str] = None
    from_email: Optional[str] = None
    from_name: Optional[str] = None
    use_tls: Optional[bool] = None
    use_ssl: Optional[bool] = None


class SmtpTestRequest(BaseModel):
    host: str
    port: int = 587
    username: str
    password: str
    use_tls: bool = True
    use_ssl: bool = False


def _get_or_create_smtp(db: Session) -> SmtpSetting:
    s = db.query(SmtpSetting).filter(SmtpSetting.id == 1).first()
    if not s:
        s = SmtpSetting(id=1, port=587, use_tls=True, use_ssl=False, is_configured=False)
        db.add(s); db.commit(); db.refresh(s)
    return s


@router.get("/smtp", response_model=SmtpSettingOut)
async def admin_get_smtp(db: Session = Depends(get_db)):
    s = _get_or_create_smtp(db)
    return SmtpSettingOut(
        host=s.host,
        port=s.port or 587,
        username=s.username,
        password_masked=_mask(s.password),
        from_email=s.from_email,
        from_name=s.from_name,
        use_tls=bool(s.use_tls),
        use_ssl=bool(s.use_ssl),
        is_configured=bool(s.is_configured),
        updated_at=s.updated_at,
    )


@router.put("/smtp", response_model=SmtpSettingOut)
async def admin_update_smtp(
    payload: SmtpSettingUpdate,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    s = _get_or_create_smtp(db)
    if payload.host is not None: s.host = payload.host.strip() or None
    if payload.port is not None: s.port = payload.port
    if payload.username is not None: s.username = payload.username.strip() or None
    if payload.password is not None and payload.password.strip():
        s.password = encrypt_secret(payload.password.strip())
    if payload.from_email is not None: s.from_email = payload.from_email.strip() or None
    if payload.from_name is not None: s.from_name = payload.from_name.strip() or None
    if payload.use_tls is not None: s.use_tls = bool(payload.use_tls)
    if payload.use_ssl is not None: s.use_ssl = bool(payload.use_ssl)
    s.is_configured = bool(s.host and s.username and s.password and s.from_email)
    db.commit(); db.refresh(s)
    return SmtpSettingOut(
        host=s.host, port=s.port or 587, username=s.username,
        password_masked=_mask(s.password), from_email=s.from_email,
        from_name=s.from_name, use_tls=bool(s.use_tls), use_ssl=bool(s.use_ssl),
        is_configured=bool(s.is_configured), updated_at=s.updated_at,
    )


@router.post("/smtp/test")
async def admin_test_smtp(
    payload: SmtpTestRequest,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    from app.services.email import test_smtp_connection
    pwd = payload.password
    if pwd == "__use_saved__":
        s = db.query(SmtpSetting).filter(SmtpSetting.id == 1).first()
        pwd = decrypt_secret(s.password or "") if s else ""
    ok, msg = test_smtp_connection(
        payload.host, payload.port, payload.username, pwd,
        payload.use_tls, payload.use_ssl
    )
    return {"success": ok, "message": msg}


# ============================================================
# KAYIT BİLDİRİMİ (RegisterNotice)
# ============================================================

class RegisterNoticeOut(BaseModel):
    is_enabled: bool = False
    title: Optional[str] = None
    message: Optional[str] = None
    color: str = "indigo"
    updated_at: Optional[datetime] = None


class RegisterNoticeUpdate(BaseModel):
    is_enabled: Optional[bool] = None
    title: Optional[str] = None
    message: Optional[str] = None
    color: Optional[str] = None


def _get_or_create_notice(db: Session) -> RegisterNotice:
    n = db.query(RegisterNotice).filter(RegisterNotice.id == 1).first()
    if not n:
        n = RegisterNotice(id=1, is_enabled=False, title="Duyuru", message="", color="indigo")
        db.add(n); db.commit(); db.refresh(n)
    return n


@router.get("/register-notice", response_model=RegisterNoticeOut)
async def admin_get_register_notice(db: Session = Depends(get_db)):
    n = _get_or_create_notice(db)
    return RegisterNoticeOut(
        is_enabled=bool(n.is_enabled), title=n.title,
        message=n.message, color=n.color or "indigo", updated_at=n.updated_at,
    )


@router.put("/register-notice", response_model=RegisterNoticeOut)
async def admin_update_register_notice(
    payload: RegisterNoticeUpdate,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    n = _get_or_create_notice(db)
    if payload.is_enabled is not None: n.is_enabled = bool(payload.is_enabled)
    if payload.title is not None: n.title = payload.title.strip()
    if payload.message is not None: n.message = payload.message
    if payload.color is not None: n.color = payload.color
    db.commit(); db.refresh(n)
    return RegisterNoticeOut(
        is_enabled=bool(n.is_enabled), title=n.title,
        message=n.message, color=n.color or "indigo", updated_at=n.updated_at,
    )


# ============================================================
# SİTE ŞARTLARI YÖNETİMİ
# ============================================================

from app.models.terms_setting import TermsSetting


class TermsSettingOut(BaseModel):
    is_enabled: bool = False
    content: Optional[str] = None
    updated_at: Optional[datetime] = None


class TermsSettingUpdate(BaseModel):
    is_enabled: Optional[bool] = None
    content: Optional[str] = None


def _get_or_create_terms(db: Session) -> TermsSetting:
    t = db.query(TermsSetting).filter(TermsSetting.id == 1).first()
    if not t:
        t = TermsSetting(id=1, is_enabled=False, content="")
        db.add(t); db.commit(); db.refresh(t)
    return t


@router.get("/terms", response_model=TermsSettingOut)
async def admin_get_terms(
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    t = _get_or_create_terms(db)
    return TermsSettingOut(is_enabled=bool(t.is_enabled), content=t.content, updated_at=t.updated_at)


@router.put("/terms", response_model=TermsSettingOut)
async def admin_update_terms(
    payload: TermsSettingUpdate,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    t = _get_or_create_terms(db)
    if payload.is_enabled is not None: t.is_enabled = bool(payload.is_enabled)
    if payload.content is not None: t.content = payload.content
    db.commit(); db.refresh(t)
    return TermsSettingOut(is_enabled=bool(t.is_enabled), content=t.content, updated_at=t.updated_at)


# ============================================================
# BAYİ YEDEKLER YÖNETİMİ (Süperadmin)
# ============================================================

from app.models import BayiBackup
from app.services import backup_service
from app.utils.crypto import decrypt_secret
from fastapi.responses import Response


class SuperAdminBackupOut(BaseModel):
    id: str
    user_id: int
    user_email: Optional[str] = None
    company_name: Optional[str] = None
    filename: str
    size_bytes: int
    password: str  # plaintext (sadece süperadmin görür)
    created_at: datetime
    restored_at: Optional[datetime] = None


@router.get("/backups", response_model=List[SuperAdminBackupOut])
async def admin_list_backups(
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    """Tüm bayilerin yedeklerini şifreleriyle birlikte listeler."""
    rows = db.query(BayiBackup).order_by(BayiBackup.created_at.desc()).all()
    out = []
    for r in rows:
        u = db.query(User).filter(User.id == r.user_id).first()
        out.append(SuperAdminBackupOut(
            id=r.id,
            user_id=r.user_id,
            user_email=u.email if u else None,
            company_name=(u.company_name if u else None),
            filename=r.filename,
            size_bytes=r.size_bytes,
            password=decrypt_secret(r.password_encrypted),
            created_at=r.created_at,
            restored_at=r.restored_at,
        ))
    return out


@router.get("/backups/{backup_id}/download")
async def admin_download_backup(
    backup_id: str,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    record = db.query(BayiBackup).filter(BayiBackup.id == backup_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Yedek bulunamadı")
    try:
        data = backup_service.read_backup_file(backup_id)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Yedek dosyası diskten silinmiş")
    return Response(
        content=data,
        media_type="application/octet-stream",
        headers={
            "Content-Disposition": f'attachment; filename="{record.filename}"',
            "Content-Length": str(len(data)),
        },
    )


@router.delete("/backups/{backup_id}", status_code=204)
async def admin_delete_backup(
    backup_id: str,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    record = db.query(BayiBackup).filter(BayiBackup.id == backup_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Yedek bulunamadı")
    backup_service.delete_backup_file(backup_id)
    db.delete(record)
    db.commit()
    return Response(status_code=204)


# ============================================================
# FAZ 2: FTP/SFTP YEDEK SUNUCULARI YÖNETİMİ
# ============================================================

from app.models import FtpServer
from app.services import ftp_service
from app.utils.crypto import encrypt_secret
import uuid as _uuid
import os as _os


class FtpServerIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=120)
    type: str = Field("sftp")  # 'ftp' | 'sftp'
    host: str = Field(..., min_length=1, max_length=255)
    port: int = Field(22, ge=1, le=65535)
    username: str = Field(..., min_length=1, max_length=255)
    password: Optional[str] = None  # Yeni kayıtta zorunlu, güncellemede boş bırakılırsa korunur
    base_path: str = Field("/", max_length=500)
    is_active: bool = True


class FtpServerOut(BaseModel):
    id: int
    name: str
    type: str
    host: str
    port: int
    username: str
    base_path: str
    is_active: bool
    has_password: bool
    created_at: datetime
    updated_at: datetime


def _ftp_to_out(s: FtpServer) -> FtpServerOut:
    return FtpServerOut(
        id=s.id, name=s.name, type=s.type, host=s.host, port=s.port,
        username=s.username, base_path=s.base_path or "/",
        is_active=bool(s.is_active), has_password=bool(s.password_encrypted),
        created_at=s.created_at, updated_at=s.updated_at,
    )


@router.get("/ftp-servers", response_model=List[FtpServerOut])
async def admin_list_ftp_servers(
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    rows = db.query(FtpServer).order_by(FtpServer.created_at.desc()).all()
    return [_ftp_to_out(s) for s in rows]


@router.post("/ftp-servers", response_model=FtpServerOut)
async def admin_create_ftp_server(
    payload: FtpServerIn,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    if (payload.type or "").lower() not in ("ftp", "sftp"):
        raise HTTPException(status_code=400, detail="Tür 'ftp' veya 'sftp' olmalı")
    if not payload.password:
        raise HTTPException(status_code=400, detail="Yeni sunucu için şifre zorunlu")
    s = FtpServer(
        name=payload.name.strip(),
        type=payload.type.lower(),
        host=payload.host.strip(),
        port=int(payload.port),
        username=payload.username.strip(),
        password_encrypted=encrypt_secret(payload.password),
        base_path=(payload.base_path or "/").strip() or "/",
        is_active=bool(payload.is_active),
    )
    db.add(s); db.commit(); db.refresh(s)
    return _ftp_to_out(s)


@router.put("/ftp-servers/{server_id}", response_model=FtpServerOut)
async def admin_update_ftp_server(
    server_id: int,
    payload: FtpServerIn,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    s = db.query(FtpServer).filter(FtpServer.id == server_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Sunucu bulunamadı")
    if (payload.type or "").lower() not in ("ftp", "sftp"):
        raise HTTPException(status_code=400, detail="Tür 'ftp' veya 'sftp' olmalı")
    s.name = payload.name.strip()
    s.type = payload.type.lower()
    s.host = payload.host.strip()
    s.port = int(payload.port)
    s.username = payload.username.strip()
    if payload.password:  # boş bırakıldıysa korunur
        s.password_encrypted = encrypt_secret(payload.password)
    s.base_path = (payload.base_path or "/").strip() or "/"
    s.is_active = bool(payload.is_active)
    db.commit(); db.refresh(s)
    return _ftp_to_out(s)


@router.delete("/ftp-servers/{server_id}", status_code=204)
async def admin_delete_ftp_server(
    server_id: int,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    s = db.query(FtpServer).filter(FtpServer.id == server_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Sunucu bulunamadı")
    db.delete(s); db.commit()
    return Response(status_code=204)


@router.post("/ftp-servers/{server_id}/test")
async def admin_test_ftp_server(
    server_id: int,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    s = db.query(FtpServer).filter(FtpServer.id == server_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Sunucu bulunamadı")
    ok, msg = ftp_service.test_connection(s)
    return {"ok": ok, "message": msg}


@router.get("/ftp-servers/{server_id}/files")
async def admin_list_ftp_files(
    server_id: int,
    sub_path: str = "",
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    s = db.query(FtpServer).filter(FtpServer.id == server_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Sunucu bulunamadı")
    try:
        return {"sub_path": sub_path, "items": ftp_service.list_files(s, sub_path)}
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Listeleme başarısız: {e}")


@router.delete("/ftp-servers/{server_id}/files")
async def admin_delete_ftp_file(
    server_id: int,
    path: str,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    s = db.query(FtpServer).filter(FtpServer.id == server_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Sunucu bulunamadı")
    try:
        ftp_service.delete_file(s, path)
        return {"ok": True}
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Silme başarısız: {e}")


@router.post("/backups/{backup_id}/upload-ftp/{server_id}")
async def admin_upload_backup_to_ftp(
    backup_id: str,
    server_id: int,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    """Yerel bayi yedeğini seçilen FTP/SFTP sunucusuna yükler.
    Hedef yol: <base_path>/<bayi_klasor>/<filename>
    """
    record = db.query(BayiBackup).filter(BayiBackup.id == backup_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Yedek bulunamadı")
    server = db.query(FtpServer).filter(FtpServer.id == server_id).first()
    if not server:
        raise HTTPException(status_code=404, detail="Sunucu bulunamadı")
    try:
        data = backup_service.read_backup_file(backup_id)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Yedek dosyası diskten silinmiş")

    user = db.query(User).filter(User.id == record.user_id).first()
    sub = ftp_service.safe_subdir_for_user(user) if user else f"user_{record.user_id}"
    remote_path = f"{sub}/{record.filename}"
    try:
        final = ftp_service.upload_file(server, data, remote_path)
        return {"ok": True, "remote_path": final, "size_bytes": len(data)}
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"FTP yükleme başarısız: {e}")


@router.post("/ftp-servers/{server_id}/import")
async def admin_import_from_ftp(
    server_id: int,
    path: str,
    current_admin: User = Depends(get_current_super_admin),
    db: Session = Depends(get_db),
):
    """Uzakta var olan bir .sfb dosyasını yerele indir + BayiBackup kaydı oluştur.
    Bayi sahibi: dosya adındaki backup_id header'ından çözülür → mevcut user_id korunur.
    Sahip user yoksa hata döner.
    """
    server = db.query(FtpServer).filter(FtpServer.id == server_id).first()
    if not server:
        raise HTTPException(status_code=404, detail="Sunucu bulunamadı")
    try:
        data = ftp_service.download_file(server, path)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"FTP indirme başarısız: {e}")

    # .sfb header parse → backup_id, oradan password (varsa mevcut)
    try:
        nl = data.index(b"\n")
        import json as _json
        header = _json.loads(data[:nl].decode("utf-8"))
        backup_id = header["backup_id"]
    except Exception:
        raise HTTPException(status_code=400, detail="Dosya geçerli bir .sfb yedeği değil")

    existing = db.query(BayiBackup).filter(BayiBackup.id == backup_id).first()
    if existing:
        # zaten kayıtlı → sadece dosyayı yerele yaz (varsa üstüne yaz)
        from app.services.backup_service import BACKUPS_DIR as _BD
        _BD.mkdir(parents=True, exist_ok=True)
        with open(_BD / f"{backup_id}.sfb", "wb") as fp:
            fp.write(data)
        return {"ok": True, "backup_id": backup_id, "status": "already_existed_overwritten"}

    # Yeni kayıt için: user_id'yi belirleyemeyiz (header'da yok). path'in üst klasör adı bayi
    # subdir'i ile eşleşiyorsa user'a map etmeyi deneyelim.
    parts = (path or "").strip("/").split("/")
    user_match = None
    if len(parts) >= 2:
        sub = parts[-2]
        for u in db.query(User).filter(User.is_super_admin == False).all():
            if ftp_service.safe_subdir_for_user(u) == sub:
                user_match = u
                break
    if not user_match:
        raise HTTPException(
            status_code=400,
            detail="Bu yedeğin sahibi olan bayi bulunamadı (klasör adı eşleşmedi). Önce bayi hesabı mevcut olmalı.",
        )

    # Şifreyi bilmiyoruz (asıl bayide kayıtlıydı). En iyi ihtimal: dosyayı diske kaydet
    # ama BayiBackup.password_encrypted alanı zorunlu — bu yüzden burada hata dönelim
    # (kullanıcıyı uyaralım: aynı sistemden yedek alındıysa zaten DB kaydı vardır).
    raise HTTPException(
        status_code=409,
        detail=(
            "Bu yedek bu sistemde kayıtlı değil; şifresi bilinmediği için içe aktarılamaz. "
            "Bu dosya başka bir StokFinans kurulumundan oluşturulmuş olabilir. "
            "Çözüm: 'Sunucu Eşleşmesi' ile bütün veritabanını senkronize edin."
        ),
    )


# ============================================================
# TAM SİSTEM YEDEĞİ (super admin'ler dahil her şey)
# ============================================================

from fastapi import UploadFile, File
from fastapi.responses import Response as _Response
from app.services import system_backup_service


@router.post("/system-backup/create")
def superadmin_system_backup_create(
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
):
    """
    Tüm sistemin yedeğini ZIP olarak döndürür.
    İçerir: tüm tablolar (SÜPER ADMİN'LER DAHİL) + uploads/ + backups/.
    Hariç: sync_peer (peer config makineye özgü).
    """
    try:
        zip_bytes = system_backup_service.export_system_snapshot(db)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Yedek oluşturulamadı: {e}")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    return _Response(
        content=zip_bytes,
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="stokfinans-system-{ts}.zip"',
            "Content-Length": str(len(zip_bytes)),
        },
    )


@router.post("/system-backup/restore")
async def superadmin_system_backup_restore(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
):
    """
    Yüklenen ZIP'i tüm sisteme uygular.
    DİKKAT: Mevcut tüm veri (sync_peer hariç) silinir ve yedekteki ile değiştirilir.
    """
    if not file.filename or not file.filename.lower().endswith(".zip"):
        raise HTTPException(status_code=400, detail="Lütfen .zip uzantılı bir sistem yedeği yükleyin")

    # 2 GiB üst sınır
    MAX = 2 * 1024 * 1024 * 1024
    data = await file.read()
    if not data or len(data) < 32:
        raise HTTPException(status_code=400, detail="Boş veya geçersiz dosya")
    # ZIP magic bytes kontrolü (PK\x03\x04)
    if not data[:4].startswith(b"PK\x03\x04"):
        raise HTTPException(status_code=400, detail="Geçersiz dosya: ZIP formatı bekleniyordu")
    if len(data) > MAX:
        raise HTTPException(status_code=413, detail="Yedek dosyası çok büyük (üst sınır 2 GiB)")

    try:
        stats = system_backup_service.import_system_snapshot(db, data)
    except system_backup_service.SystemBackupValidationError as e:
        # Doğrulama (kullanıcı) hatası
        raise HTTPException(status_code=400, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Geri yükleme hatası: {e}")

    return {"ok": True, "stats": stats}


# ============================================================
# Destek & Talep Sistemi — Süper Admin Endpoints
# ============================================================
from sqlalchemy.orm import joinedload as _jl
from app.models.support import SupportTicket as _ST, SupportMessage as _SM, TicketStatus as _TSt


class _AdminMsgOut(BaseModel):
    id: int
    is_from_admin: bool
    body: str
    created_at: datetime
    sender_name: Optional[str] = None


class _AdminTicketOut(BaseModel):
    id: int
    subject: str
    category: str
    status: str        # raw: open | in_progress | closed
    status_label: str  # görüntüleme: Açık | İşlemde | Kapalı
    created_at: datetime
    updated_at: datetime
    message_count: int = 0
    last_message_at: Optional[datetime] = None
    bayi_name: Optional[str] = None
    bayi_email: Optional[str] = None
    bayi_id: Optional[int] = None


class _AdminTicketDetailOut(_AdminTicketOut):
    messages: List[_AdminMsgOut] = []


class _AdminReplyRequest(BaseModel):
    body: str = Field(..., min_length=1)


class _StatusChangeRequest(BaseModel):
    status: str = Field(..., pattern="^(open|in_progress|closed)$")


_CAT_LABELS = {"bug": "Hata", "request": "Talep", "suggestion": "Öneri", "other": "Diğer"}
_ST_LABELS = {"open": "Açık", "in_progress": "İşlemde", "closed": "Kapalı"}


def _admin_ticket_out(ticket: _ST) -> _AdminTicketOut:
    msgs = ticket.messages or []
    u = ticket.user
    bayi_name = None
    if u:
        bayi_name = u.company_name or u.full_name or u.email
    return _AdminTicketOut(
        id=ticket.id,
        subject=ticket.subject,
        category=_CAT_LABELS.get(ticket.category.value, ticket.category.value),
        status=ticket.status.value,
        status_label=_ST_LABELS.get(ticket.status.value, ticket.status.value),
        created_at=ticket.created_at,
        updated_at=ticket.updated_at,
        message_count=len(msgs),
        last_message_at=msgs[-1].created_at if msgs else None,
        bayi_name=bayi_name,
        bayi_email=u.email if u else None,
        bayi_id=u.id if u else None,
    )


def _admin_msg_out(msg: _SM) -> _AdminMsgOut:
    sender_name = None
    if msg.sender:
        sender_name = msg.sender.company_name or msg.sender.full_name or msg.sender.email
    return _AdminMsgOut(
        id=msg.id,
        is_from_admin=msg.is_from_admin,
        body=msg.body,
        created_at=msg.created_at,
        sender_name=sender_name,
    )


@router.get("/tickets", tags=["SuperAdmin-Support"])
def admin_list_tickets(
    status: Optional[str] = None,
    category: Optional[str] = None,
    search: Optional[str] = None,
    page: int = 1,
    page_size: int = 50,
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
):
    q = (
        db.query(_ST)
        .options(_jl(_ST.messages), _jl(_ST.user))
    )
    if status and status != "all":
        try:
            q = q.filter(_ST.status == _TSt(status))
        except ValueError:
            pass
    if category and category != "all":
        q = q.filter(_ST.category == category)
    if search:
        from sqlalchemy import or_ as _or
        q = q.join(_ST.user).filter(
            _or(
                _ST.subject.ilike(f"%{search}%"),
                User.company_name.ilike(f"%{search}%"),
                User.full_name.ilike(f"%{search}%"),
                User.email.ilike(f"%{search}%"),
            )
        )
    total = q.count()
    tickets = q.order_by(_ST.updated_at.desc()).offset((page - 1) * page_size).limit(page_size).all()
    return {
        "total": total,
        "page": page,
        "page_size": page_size,
        "items": [_admin_ticket_out(t).model_dump() for t in tickets],
    }


@router.get("/tickets/open-count", tags=["SuperAdmin-Support"])
def admin_open_ticket_count(
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
):
    count = db.query(_ST).filter(_ST.status.in_([_TSt.open, _TSt.in_progress])).count()
    return {"count": count}


@router.get("/tickets/{ticket_id}", tags=["SuperAdmin-Support"])
def admin_get_ticket(
    ticket_id: int,
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
):
    ticket = (
        db.query(_ST)
        .options(
            _jl(_ST.messages).joinedload(_SM.sender),
            _jl(_ST.user),
        )
        .filter(_ST.id == ticket_id)
        .first()
    )
    if not ticket:
        raise HTTPException(status_code=404, detail="Talep bulunamadı.")
    out = _admin_ticket_out(ticket)
    return _AdminTicketDetailOut(
        **out.model_dump(),
        messages=[_admin_msg_out(m) for m in ticket.messages],
    )


@router.post("/tickets/{ticket_id}/messages", status_code=201, tags=["SuperAdmin-Support"])
def admin_reply_ticket(
    ticket_id: int,
    payload: _AdminReplyRequest,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_super_admin),
):
    ticket = db.query(_ST).filter(_ST.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Talep bulunamadı.")
    msg = _SM(
        ticket_id=ticket.id,
        sender_user_id=admin.id,
        is_from_admin=True,
        body=payload.body.strip(),
    )
    db.add(msg)
    ticket.updated_at = datetime.now()
    if ticket.status == _TSt.open:
        ticket.status = _TSt.in_progress
    db.commit()
    return {"message": "Cevap gönderildi."}


@router.patch("/tickets/{ticket_id}/status", tags=["SuperAdmin-Support"])
def admin_change_ticket_status(
    ticket_id: int,
    payload: _StatusChangeRequest,
    db: Session = Depends(get_db),
    _admin: User = Depends(get_current_super_admin),
):
    ticket = db.query(_ST).filter(_ST.id == ticket_id).first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Talep bulunamadı.")
    try:
        ticket.status = _TSt(payload.status)
    except ValueError:
        raise HTTPException(status_code=400, detail="Geçersiz durum.")
    ticket.updated_at = datetime.now()
    db.commit()
    return {"status": ticket.status.value}


# ============================================================================
# WARRANTIES — Tüm bayilerin garanti belgeleri + görüntülenme istatistikleri
# Süperadmin kim kaç garanti üretmiş, bunlar kaç kere/ne zaman açılmış görür.
# ============================================================================

class _AdminWarrantyOut(BaseModel):
    id: int
    user_id: int
    bayi_email: str
    bayi_name: str
    bayi_company: Optional[str] = None
    product_name: str
    product_image_url: Optional[str] = None
    customer_name: str
    customer_phone: Optional[str] = None
    duration_label: str
    duration_days: int
    start_date: datetime
    end_date: datetime
    is_expired: bool
    days_remaining: int
    public_token: str
    view_count: int
    last_viewed_at: Optional[datetime] = None
    created_at: datetime


class _AdminWarrantyStatsOut(BaseModel):
    total_warranties: int
    total_views: int
    expired_count: int
    active_count: int
    never_viewed_count: int
    bayi_count: int


class _AdminWarrantyListOut(BaseModel):
    items: List[_AdminWarrantyOut]
    total: int
    page: int
    per_page: int
    stats: _AdminWarrantyStatsOut


@router.get("/warranties", response_model=_AdminWarrantyListOut, tags=["SuperAdmin-Warranties"])
def admin_list_warranties(
    db: Session = Depends(get_db),
    q: Optional[str] = Query(None, description="Müşteri adı / ürün adı / bayi email araması"),
    user_id: Optional[int] = Query(None, description="Belirli bayinin garantilerini filtrele"),
    status_filter: Optional[str] = Query(
        None, description="'active' = süresi dolmamış, 'expired' = dolmuş, 'unviewed' = hiç açılmamış"
    ),
    sort: str = Query("created_desc", description="created_desc | views_desc | last_viewed_desc | end_date_asc"),
    page: int = Query(1, ge=1),
    per_page: int = Query(50, ge=1, le=200),
):
    """
    Tüm bayilerin (tenant'ların) garanti belgelerini listele + her birinin
    public link görüntülenme istatistiğini göster.

    Süperadmin erişimi (router-level dependency) zaten zorunlu.
    """
    # Warranty.end_date timezone-aware (TIMESTAMPTZ). Karşılaştırma için aware now.
    from datetime import timezone as _tz
    now_aware = datetime.now(_tz.utc)

    base_q = db.query(Warranty, User).join(User, Warranty.user_id == User.id)

    if user_id is not None:
        base_q = base_q.filter(Warranty.user_id == user_id)

    if q:
        like = f"%{q.strip()}%"
        base_q = base_q.filter(or_(
            Warranty.product_name.ilike(like),
            Warranty.customer_name.ilike(like),
            User.email.ilike(like),
            User.full_name.ilike(like),
            User.company_name.ilike(like),
        ))

    if status_filter == "active":
        base_q = base_q.filter(Warranty.end_date >= now_aware)
    elif status_filter == "expired":
        base_q = base_q.filter(Warranty.end_date < now_aware)
    elif status_filter == "unviewed":
        base_q = base_q.filter((Warranty.view_count == 0) | (Warranty.view_count.is_(None)))

    # Toplam sayı (paging öncesi)
    total = base_q.count()

    # Sıralama
    if sort == "views_desc":
        base_q = base_q.order_by(Warranty.view_count.desc().nullslast(), Warranty.created_at.desc())
    elif sort == "last_viewed_desc":
        base_q = base_q.order_by(Warranty.last_viewed_at.desc().nullslast(), Warranty.created_at.desc())
    elif sort == "end_date_asc":
        base_q = base_q.order_by(Warranty.end_date.asc())
    else:  # created_desc (default)
        base_q = base_q.order_by(Warranty.created_at.desc())

    rows = base_q.offset((page - 1) * per_page).limit(per_page).all()

    items: List[_AdminWarrantyOut] = []
    for w, u in rows:
        end = w.end_date if w.end_date.tzinfo else w.end_date.replace(tzinfo=_tz.utc)
        is_expired = end < now_aware
        days_remaining = max(0, (end - now_aware).days)
        items.append(_AdminWarrantyOut(
            id=w.id,
            user_id=w.user_id,
            bayi_email=u.email,
            bayi_name=u.full_name or u.email,
            bayi_company=u.company_name,
            product_name=w.product_name,
            product_image_url=w.product_image_url,
            customer_name=w.customer_name,
            customer_phone=w.customer_phone,
            duration_label=w.duration_label,
            duration_days=w.duration_days,
            start_date=w.start_date,
            end_date=w.end_date,
            is_expired=is_expired,
            days_remaining=days_remaining,
            public_token=w.public_token,
            view_count=int(w.view_count or 0),
            last_viewed_at=w.last_viewed_at,
            created_at=w.created_at,
        ))

    # Genel istatistikler — global agregasyon (filtreden bağımsız, panel başlığı için)
    total_warranties = db.query(func.count(Warranty.id)).scalar() or 0
    total_views = db.query(func.coalesce(func.sum(Warranty.view_count), 0)).scalar() or 0
    expired_count = db.query(func.count(Warranty.id)).filter(Warranty.end_date < now_aware).scalar() or 0
    active_count = db.query(func.count(Warranty.id)).filter(Warranty.end_date >= now_aware).scalar() or 0
    never_viewed_count = db.query(func.count(Warranty.id)).filter(
        (Warranty.view_count == 0) | (Warranty.view_count.is_(None))
    ).scalar() or 0
    bayi_count = db.query(func.count(func.distinct(Warranty.user_id))).scalar() or 0

    return _AdminWarrantyListOut(
        items=items,
        total=int(total),
        page=page,
        per_page=per_page,
        stats=_AdminWarrantyStatsOut(
            total_warranties=int(total_warranties),
            total_views=int(total_views),
            expired_count=int(expired_count),
            active_count=int(active_count),
            never_viewed_count=int(never_viewed_count),
            bayi_count=int(bayi_count),
        ),
    )


# ============================================================
# SITE INFO (Hakkımızda / İletişim)
# ============================================================
from app.models.site_info import SiteInfo


class SiteInfoOut(BaseModel):
    company_name: Optional[str] = None
    contact_person: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    working_hours: Optional[str] = None
    about_text: Optional[str] = None
    instagram_url: Optional[str] = None
    whatsapp_number: Optional[str] = None


class SiteInfoUpdate(BaseModel):
    company_name: Optional[str] = None
    contact_person: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    working_hours: Optional[str] = None
    about_text: Optional[str] = None
    instagram_url: Optional[str] = None
    whatsapp_number: Optional[str] = None


def _get_or_create_site_info(db: Session) -> SiteInfo:
    row = db.query(SiteInfo).filter(SiteInfo.id == 1).first()
    if not row:
        row = SiteInfo(id=1)
        db.add(row)
        db.commit()
        db.refresh(row)
    return row


@router.get("/site-info", response_model=SiteInfoOut)
async def admin_get_site_info(db: Session = Depends(get_db)):
    row = _get_or_create_site_info(db)
    return SiteInfoOut(
        company_name=row.company_name,
        contact_person=row.contact_person,
        address=row.address,
        phone=row.phone,
        email=row.email,
        working_hours=row.working_hours,
        about_text=row.about_text,
        instagram_url=row.instagram_url,
        whatsapp_number=row.whatsapp_number,
    )


@router.patch("/site-info", response_model=SiteInfoOut)
async def admin_update_site_info(payload: SiteInfoUpdate, db: Session = Depends(get_db)):
    row = _get_or_create_site_info(db)
    for field, value in payload.model_dump(exclude_none=False).items():
        if value is not None or getattr(row, field) is not None:
            setattr(row, field, value if value != "" else None)
    db.commit()
    db.refresh(row)
    return SiteInfoOut(
        company_name=row.company_name,
        contact_person=row.contact_person,
        address=row.address,
        phone=row.phone,
        email=row.email,
        working_hours=row.working_hours,
        about_text=row.about_text,
        instagram_url=row.instagram_url,
        whatsapp_number=row.whatsapp_number,
    )


# ============================================================
# GÜVENLİK RAPORLARI
# ============================================================

class SecurityLogOut(BaseModel):
    id: int
    ip_address: str
    event_type: str
    email_attempted: Optional[str] = None
    user_id: Optional[int] = None
    user_email: Optional[str] = None
    user_name: Optional[str] = None
    user_role: Optional[str] = None
    path: Optional[str] = None
    method: Optional[str] = None
    user_agent: Optional[str] = None
    details: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class IpBanOut(BaseModel):
    id: int
    ip_address: str
    reason: Optional[str] = None
    banned_by: Optional[str] = None
    created_at: datetime
    expires_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class BanIpRequest(BaseModel):
    ip_address: str
    reason: Optional[str] = None
    expires_at: Optional[datetime] = None


class SecurityStatsOut(BaseModel):
    total_failed_logins: int
    total_rate_limited: int
    total_banned_access: int
    unique_attacker_ips: int
    active_bans: int
    top_attacker_ips: List[dict]


@router.get("/security/logs", response_model=List[SecurityLogOut])
async def get_security_logs(
    event_type: Optional[str] = Query(None),
    ip: Optional[str] = Query(None),
    email: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
):
    q = db.query(SecurityLog)
    if event_type:
        q = q.filter(SecurityLog.event_type == event_type)
    if ip:
        q = q.filter(SecurityLog.ip_address.ilike(f"%{ip}%"))
    if email:
        q = q.filter(
            or_(
                SecurityLog.email_attempted.ilike(f"%{email}%"),
                SecurityLog.user_email.ilike(f"%{email}%"),
            )
        )
    q = q.order_by(desc(SecurityLog.created_at))
    logs = q.offset((page - 1) * page_size).limit(page_size).all()
    return logs


@router.get("/security/stats", response_model=SecurityStatsOut)
async def get_security_stats(db: Session = Depends(get_db)):
    total_failed = db.query(func.count(SecurityLog.id)).filter(SecurityLog.event_type == "failed_login").scalar() or 0
    total_rate = db.query(func.count(SecurityLog.id)).filter(SecurityLog.event_type == "rate_limited").scalar() or 0
    total_banned = db.query(func.count(SecurityLog.id)).filter(SecurityLog.event_type == "banned_access").scalar() or 0
    unique_ips = db.query(func.count(func.distinct(SecurityLog.ip_address))).scalar() or 0
    active_bans = db.query(func.count(IpBan.id)).filter(
        or_(IpBan.expires_at.is_(None), IpBan.expires_at > datetime.utcnow())
    ).scalar() or 0

    top_ips_rows = (
        db.query(SecurityLog.ip_address, func.count(SecurityLog.id).label("cnt"))
        .group_by(SecurityLog.ip_address)
        .order_by(desc("cnt"))
        .limit(10)
        .all()
    )
    top_ips = [{"ip": r.ip_address, "count": r.cnt} for r in top_ips_rows]

    return SecurityStatsOut(
        total_failed_logins=total_failed,
        total_rate_limited=total_rate,
        total_banned_access=total_banned,
        unique_attacker_ips=unique_ips,
        active_bans=active_bans,
        top_attacker_ips=top_ips,
    )


@router.get("/security/banned-ips", response_model=List[IpBanOut])
async def get_banned_ips(db: Session = Depends(get_db)):
    bans = db.query(IpBan).order_by(desc(IpBan.created_at)).all()
    return bans


@router.post("/security/ban-ip", response_model=IpBanOut, status_code=status.HTTP_201_CREATED)
async def ban_ip(
    payload: BanIpRequest,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_super_admin),
):
    from main import invalidate_ban_cache
    existing = db.query(IpBan).filter(IpBan.ip_address == payload.ip_address).first()
    if existing:
        existing.reason = payload.reason
        existing.expires_at = payload.expires_at
        db.commit()
        db.refresh(existing)
        invalidate_ban_cache()
        return existing

    ban = IpBan(
        ip_address=payload.ip_address,
        reason=payload.reason,
        banned_by=admin.email,
        expires_at=payload.expires_at,
    )
    db.add(ban)
    db.commit()
    db.refresh(ban)
    invalidate_ban_cache()
    return ban


@router.delete("/security/ban-ip/{ban_id}", status_code=status.HTTP_204_NO_CONTENT)
async def unban_ip(ban_id: int, db: Session = Depends(get_db)):
    from main import invalidate_ban_cache
    ban = db.query(IpBan).filter(IpBan.id == ban_id).first()
    if not ban:
        raise HTTPException(status_code=404, detail="Ban bulunamadı")
    db.delete(ban)
    db.commit()
    invalidate_ban_cache()


# ============================================================
# API KEY YÖNETİMİ — Harici entegrasyon anahtarları
# ============================================================

from app.models.api_key import (
    ApiKey as _ApiKey,
    AVAILABLE_SCOPES,
    ADMIN_SCOPES,
    generate_api_key,
)


class _ApiKeyCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    user_id: Optional[int] = None          # None → süper admin anahtarı (user_id = admin.id)
    scopes: List[str] = []
    is_full_access: bool = False
    is_super_admin_key: bool = False       # True → yönetim API anahtarı
    expires_at: Optional[datetime] = None


class _ApiKeyOut(BaseModel):
    id: int
    key_prefix: str
    name: str
    description: Optional[str]
    user_id: int
    user_email: str
    user_full_name: str
    scopes: List[str]
    is_full_access: bool
    is_super_admin_key: bool
    is_active: bool
    usage_count: int
    last_used_at: Optional[datetime]
    created_at: datetime
    expires_at: Optional[datetime]


def _ak_out(ak: _ApiKey, db: Session) -> _ApiKeyOut:
    u = db.query(User).filter(User.id == ak.user_id).first()
    return _ApiKeyOut(
        id=ak.id,
        key_prefix=ak.key_prefix,
        name=ak.name,
        description=ak.description,
        user_id=ak.user_id,
        user_email=u.email if u else "—",
        user_full_name=getattr(u, "full_name", "") or "" if u else "",
        scopes=list(ak.scopes or []),
        is_full_access=bool(ak.is_full_access),
        is_super_admin_key=bool(getattr(ak, "is_super_admin_key", False)),
        is_active=bool(ak.is_active),
        usage_count=ak.usage_count or 0,
        last_used_at=ak.last_used_at,
        created_at=ak.created_at,
        expires_at=ak.expires_at,
    )


@router.get("/api-keys/scopes", tags=["SuperAdmin-ApiKeys"])
async def list_available_scopes(
    admin: User = Depends(get_current_super_admin),
):
    """Sisteme tanımlı tüm scope listesini döndürür (bayi + admin)."""
    return {"scopes": AVAILABLE_SCOPES, "admin_scopes": ADMIN_SCOPES}


@router.get("/api-keys", tags=["SuperAdmin-ApiKeys"])
async def list_api_keys(
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_super_admin),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    search: Optional[str] = Query(None),
):
    """Tüm API anahtarlarını listeler."""
    q = db.query(_ApiKey)
    if search:
        q = q.filter(_ApiKey.name.ilike(f"%{search}%"))
    total = q.count()
    items = q.order_by(desc(_ApiKey.created_at)).offset((page - 1) * page_size).limit(page_size).all()
    return {
        "total": total,
        "items": [_ak_out(a, db) for a in items],
    }


@router.post("/api-keys", status_code=status.HTTP_201_CREATED, tags=["SuperAdmin-ApiKeys"])
async def create_api_key(
    payload: _ApiKeyCreateRequest,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_super_admin),
):
    """Yeni API anahtarı oluşturur. Ham anahtar yalnızca bu yanıtta gösterilir."""
    if payload.is_super_admin_key:
        # Süper admin anahtarı → user_id = mevcut admin
        target_user_id = admin.id
    else:
        if not payload.user_id:
            raise HTTPException(status_code=422, detail="Bayi anahtarı için user_id gerekli")
        user = db.query(User).filter(User.id == payload.user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="Kullanıcı bulunamadı")
        target_user_id = payload.user_id

    raw_key, prefix, key_hash = generate_api_key()

    scopes = payload.scopes if not payload.is_full_access else []

    ak = _ApiKey(
        key_hash=key_hash,
        key_prefix=prefix,
        name=payload.name,
        description=payload.description,
        user_id=target_user_id,
        created_by_id=admin.id,
        scopes=scopes,
        is_full_access=payload.is_full_access,
        is_super_admin_key=payload.is_super_admin_key,
        expires_at=payload.expires_at,
    )
    db.add(ak)
    db.commit()
    db.refresh(ak)

    return {
        "api_key": _ak_out(ak, db),
        "raw_key": raw_key,  # Yalnızca bir kez gösterilir — saklanmalı!
    }


@router.patch("/api-keys/{key_id}/toggle", tags=["SuperAdmin-ApiKeys"])
async def toggle_api_key(
    key_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_super_admin),
):
    """API anahtarını aktif/pasif yapar."""
    ak = db.query(_ApiKey).filter(_ApiKey.id == key_id).first()
    if not ak:
        raise HTTPException(status_code=404, detail="API anahtarı bulunamadı")
    ak.is_active = not ak.is_active
    db.commit()
    return _ak_out(ak, db)


@router.delete("/api-keys/{key_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["SuperAdmin-ApiKeys"])
async def delete_api_key(
    key_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_super_admin),
):
    """API anahtarını kalıcı olarak siler."""
    ak = db.query(_ApiKey).filter(_ApiKey.id == key_id).first()
    if not ak:
        raise HTTPException(status_code=404, detail="API anahtarı bulunamadı")
    db.delete(ak)
    db.commit()


# ─── SuperAdmin: B2B Activity ────────────────────────────────────────────────

from app.models.btb import BtbCustomer as _BtbCustomer, BtbOrder as _BtbOrder
from app.models.btb_portal import BtbPortalAccount as _BtbPortalAccount


@router.get("/btb/activity", tags=["SuperAdmin-BTB"])
async def superadmin_btb_activity(
    db: Session = Depends(get_db),
    admin: User = Depends(get_current_super_admin),
):
    """Tüm bayilerin B2B portal aktivitesini özetler."""
    # Pending approval orders
    pending_orders = (
        db.query(
            _BtbOrder.id,
            _BtbOrder.order_number,
            _BtbOrder.total_amount,
            _BtbOrder.currency,
            _BtbOrder.created_at,
            _BtbOrder.user_id,
            _BtbOrder.customer_id,
            _BtbCustomer.company_name.label("customer_name"),
            User.email.label("bayi_email"),
            User.company_name.label("bayi_company"),
        )
        .join(_BtbCustomer, _BtbOrder.customer_id == _BtbCustomer.id)
        .join(User, _BtbOrder.user_id == User.id)
        .filter(_BtbOrder.status == "pending_approval")
        .order_by(_BtbOrder.created_at.desc())
        .limit(50)
        .all()
    )

    # Recent portal registrations
    recent_registrations = (
        db.query(
            _BtbPortalAccount.id,
            _BtbPortalAccount.email,
            _BtbPortalAccount.full_name,
            _BtbPortalAccount.is_active,
            _BtbPortalAccount.last_login,
            _BtbPortalAccount.created_at,
            _BtbPortalAccount.bayi_user_id,
            _BtbCustomer.company_name.label("customer_name"),
            User.email.label("bayi_email"),
            User.company_name.label("bayi_company"),
        )
        .join(_BtbCustomer, _BtbPortalAccount.btb_customer_id == _BtbCustomer.id)
        .join(User, _BtbPortalAccount.bayi_user_id == User.id)
        .order_by(_BtbPortalAccount.created_at.desc())
        .limit(50)
        .all()
    )

    # Stats
    total_portal_accounts = db.query(func.count(_BtbPortalAccount.id)).scalar() or 0
    total_pending = db.query(func.count(_BtbOrder.id)).filter(_BtbOrder.status == "pending_approval").scalar() or 0
    total_btb_orders = db.query(func.count(_BtbOrder.id)).scalar() or 0
    total_btb_customers = db.query(func.count(_BtbCustomer.id)).scalar() or 0

    return {
        "stats": {
            "total_portal_accounts": total_portal_accounts,
            "total_pending": total_pending,
            "total_btb_orders": total_btb_orders,
            "total_btb_customers": total_btb_customers,
        },
        "pending_orders": [
            {
                "id": r.id,
                "order_number": r.order_number,
                "total_amount": r.total_amount,
                "currency": r.currency,
                "created_at": r.created_at.isoformat() if r.created_at else None,
                "customer_name": r.customer_name,
                "bayi_email": r.bayi_email,
                "bayi_company": r.bayi_company,
            }
            for r in pending_orders
        ],
        "recent_registrations": [
            {
                "id": r.id,
                "email": r.email,
                "full_name": r.full_name,
                "is_active": r.is_active,
                "last_login": r.last_login.isoformat() if r.last_login else None,
                "created_at": r.created_at.isoformat() if r.created_at else None,
                "customer_name": r.customer_name,
                "bayi_email": r.bayi_email,
                "bayi_company": r.bayi_company,
            }
            for r in recent_registrations
        ],
    }
