"""
Cihaz Yönetimi API — ESP8266 / ESP32 entegrasyon sistemi

Üç katman:
  1. Cihaz ↔ Sunucu  : api_key ile kimlik doğrulama (JWT yok)
  2. Bayi ↔ Sunucu   : JWT ile kimlik doğrulama
  3. Süper Admin     : JWT + is_super_admin kontrolü
"""
import os
import secrets
import hashlib
from datetime import datetime, timezone
from typing import Optional, List

from fastapi import APIRouter, Depends, HTTPException, Header, UploadFile, File, status
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.user import User
from app.models.product import Product
from app.models.device import Device
from app.models.transaction import Transaction
from app.models.warranty import Warranty
from app.utils.auth import get_current_user
from app.utils.tenant import data_owner_id
from app.services.sync_service import record_deletion, trigger_delta_push

router = APIRouter(prefix="/devices", tags=["Devices"])

FIRMWARE_DIR = os.path.join(os.path.dirname(__file__), "../../firmwares")
os.makedirs(FIRMWARE_DIR, exist_ok=True)

# ─────────────────────────────────────────────────────────
# Yardımcı: cihaz kimlik doğrulama
# ─────────────────────────────────────────────────────────

def _get_device_by_key(api_key: str, db: Session) -> Device:
    device = db.query(Device).filter(
        Device.api_key == api_key,
        Device.is_active == True,
    ).first()
    if not device:
        raise HTTPException(status_code=401, detail="Geçersiz veya devre dışı cihaz API anahtarı.")
    return device


def _now():
    return datetime.now(timezone.utc)


# ─────────────────────────────────────────────────────────
# Şemalar
# ─────────────────────────────────────────────────────────

class DeviceRegisterRequest(BaseModel):
    device_id: str
    device_type: str = "ESP8266"   # ESP8266 | ESP32
    variant: str = "standart"      # standart | ekran | barkod | özel
    firmware_version: Optional[str] = None
    mac_address: Optional[str] = None

class DeviceRegisterResponse(BaseModel):
    api_key: str
    message: str

class HeartbeatRequest(BaseModel):
    firmware_version: Optional[str] = None
    variant: Optional[str] = None          # cihaz varyantını güncelle (opsiyonel)
    ip_address: Optional[str] = None
    wifi_ssid: Optional[str] = None
    wifi_rssi: Optional[int] = None
    free_heap: Optional[int] = None
    uptime_seconds: Optional[int] = None

class HeartbeatResponse(BaseModel):
    ok: bool
    ota_available: bool = False
    ota_version: Optional[str] = None
    ota_url: Optional[str] = None

class DeviceInfoOut(BaseModel):
    id: int
    device_id: str
    device_type: str
    variant: str
    is_paired: bool
    is_active: bool
    firmware_version: Optional[str]
    ip_address: Optional[str]
    mac_address: Optional[str]
    wifi_ssid: Optional[str]
    wifi_rssi: Optional[int]
    free_heap: Optional[int]
    uptime_seconds: Optional[int]
    last_seen: Optional[datetime]
    paired_at: Optional[datetime]
    created_at: Optional[datetime]
    notes: Optional[str]
    is_online: bool
    pending_firmware_version: Optional[str]

class PairRequest(BaseModel):
    device_id: str

class FirmwareUploadResponse(BaseModel):
    filename: str
    device_type: str
    variant: str
    version: str
    message: str

class OtaTargetRequest(BaseModel):
    device_ids: Optional[List[str]] = None   # boşsa tüm aktif eşleşmiş cihazlar
    device_type: Optional[str] = None         # ESP8266 | ESP32 | None=hepsi
    variant: Optional[str] = None             # standart | ekran | barkod | None=hepsi
    firmware_filename: str
    firmware_version: str


# ─────────────────────────────────────────────────────────
# 1. CİHAZ ↔ SUNUCU — api_key ile kimlik doğrulama
# ─────────────────────────────────────────────────────────

@router.post("/register", response_model=DeviceRegisterResponse, summary="Cihaz ilk kayıt")
def device_register(body: DeviceRegisterRequest, db: Session = Depends(get_db)):
    """Cihaz ilk açılışta bu endpoint'e çağrı yapar ve api_key alır."""
    safe_variant = (body.variant or "standart").strip().lower() or "standart"
    device = db.query(Device).filter(Device.device_id == body.device_id).first()
    if device:
        # Zaten kayıtlı — api_key'i döndür (cihaz EEPROM'unu kaybetmiş olabilir)
        device.firmware_version = body.firmware_version
        device.mac_address = body.mac_address
        device.variant = safe_variant
        device.last_seen = _now()
        db.commit()
        return DeviceRegisterResponse(api_key=device.api_key, message="Mevcut kayıt bulundu.")

    new_key = secrets.token_hex(32)
    device = Device(
        device_id=body.device_id,
        device_type=body.device_type.upper(),
        variant=safe_variant,
        api_key=new_key,
        firmware_version=body.firmware_version,
        mac_address=body.mac_address,
        last_seen=_now(),
    )
    db.add(device)
    db.commit()
    try:
        from app.api.topology import emit_topology_event
        emit_topology_event("health", "devices", "backend-s1", f"Yeni cihaz kaydı: {body.device_id[:12]}")
    except Exception:
        pass
    return DeviceRegisterResponse(api_key=new_key, message="Cihaz kaydedildi. Bayi panelinden eşleştirin.")


@router.post("/heartbeat", response_model=HeartbeatResponse, summary="Cihaz kalp atışı (30s)")
def device_heartbeat(
    body: HeartbeatRequest,
    x_api_key: str = Header(..., alias="X-Api-Key"),
    db: Session = Depends(get_db),
):
    device = _get_device_by_key(x_api_key, db)
    device.last_seen = _now()

    # Gelen firmware versiyonunu kaydet
    reported_version = body.firmware_version or device.firmware_version or ""
    if body.firmware_version:
        device.firmware_version = body.firmware_version
    if body.variant:
        device.variant = body.variant.strip().lower() or device.variant
    if body.ip_address:       device.ip_address = body.ip_address
    if body.wifi_ssid:        device.wifi_ssid = body.wifi_ssid
    if body.wifi_rssi is not None: device.wifi_rssi = body.wifi_rssi
    if body.free_heap is not None: device.free_heap = body.free_heap
    if body.uptime_seconds is not None: device.uptime_seconds = body.uptime_seconds

    # OTA tamamlandıysa pending alanları ve sayacı temizle (cihaz yeni versiyonu bildirdi)
    if device.pending_firmware_version and reported_version == device.pending_firmware_version:
        device.pending_firmware_esp8266 = None
        device.pending_firmware_esp32 = None
        device.pending_firmware_version = None
        device.firmware_update_requested_at = None
        device.ota_attempt_count = 0
        device.ota_last_attempt_at = None

    db.commit()

    # OTA kontrolü — versiyon karşılaştırması (dosya adı değil)
    ota = False
    ota_ver = None
    ota_url = None
    fw_field = "pending_firmware_esp8266" if device.device_type == "ESP8266" else "pending_firmware_esp32"
    pending_file = getattr(device, fw_field)
    pending_version = device.pending_firmware_version
    current_version = device.firmware_version or ""

    if pending_file and pending_version and pending_version != current_version:
        ota = True
        ota_ver = pending_version
        ota_url = f"/api/v1/devices/ota/download?api_key={x_api_key}"

    try:
        from app.api.topology import emit_topology_event
        emit_topology_event("health", "devices", "backend-s1",
                            f"Heartbeat: {device.device_id[:12]} (v{device.firmware_version or '?'})")
    except Exception:
        pass
    return HeartbeatResponse(ok=True, ota_available=ota, ota_version=ota_ver, ota_url=ota_url)


@router.get("/data/product/{barcode}", summary="Barkodla ürün sorgula")
def device_query_product(
    barcode: str,
    x_api_key: str = Header(..., alias="X-Api-Key"),
    db: Session = Depends(get_db),
):
    device = _get_device_by_key(x_api_key, db)
    if not device.is_paired or not device.user_id:
        raise HTTPException(status_code=403, detail="Cihaz bir bayi ile eşleştirilmemiş.")
    product = db.query(Product).filter(
        Product.user_id == device.user_id,
        Product.barcode == barcode,
    ).first()
    if not product:
        raise HTTPException(status_code=404, detail=f'"{barcode}" barkodlu ürün bulunamadı.')
    try:
        from app.api.topology import emit_topology_event
        emit_topology_event("download", "backend-s1", "devices", f"Barkod: {barcode} → {product.name[:20]}")
    except Exception:
        pass
    return {
        "id": product.id,
        "name": product.name,
        "barcode": product.barcode,
        "price": float(product.price or 0),
        "cost": float(product.cost or 0),
        "currency": product.currency or "TRY",
        "quantity": product.quantity or 0,
        "min_stock_alert": product.min_stock_alert or 5,
        "is_critical": (product.quantity or 0) <= (product.min_stock_alert or 5),
        "category": product.category or "",
        "subcategory": product.subcategory or "",
    }


@router.get("/data/critical-stock", summary="Kritik stok listesi")
def device_critical_stock(
    x_api_key: str = Header(..., alias="X-Api-Key"),
    db: Session = Depends(get_db),
):
    device = _get_device_by_key(x_api_key, db)
    if not device.is_paired or not device.user_id:
        raise HTTPException(status_code=403, detail="Cihaz bir bayi ile eşleştirilmemiş.")
    products = db.query(Product).filter(Product.user_id == device.user_id).all()
    critical = [
        {
            "id": p.id,
            "name": p.name,
            "barcode": p.barcode or "",
            "quantity": p.quantity or 0,
            "min_stock_alert": p.min_stock_alert or 5,
            "price": float(p.price or 0),
            "currency": p.currency or "TRY",
        }
        for p in products
        if (p.quantity or 0) <= (p.min_stock_alert or 5)
    ]
    return {"count": len(critical), "items": critical}


@router.get("/data/summary", summary="Genel özet: ürün, satış, müşteri istatistikleri")
def device_summary(
    x_api_key: str = Header(..., alias="X-Api-Key"),
    db: Session = Depends(get_db),
):
    """
    Tek çağrıyla tüm özet verileri döndürür:
      - Ürün sayıları (toplam, aktif, kritik stok)
      - Toplam stok değeri
      - Bugünkü satışlar (adet + tutar)
      - Bugünkü benzersiz müşteri sayısı
      - Toplam işlem sayısı
      - Tüm zamanlar toplam gelir
    """
    from sqlalchemy import func as sqlfunc
    device = _get_device_by_key(x_api_key, db)
    if not device.is_paired or not device.user_id:
        raise HTTPException(status_code=403, detail="Cihaz bir bayi ile eşleştirilmemiş.")
    uid = device.user_id

    # Ürün istatistikleri
    products = db.query(Product).filter(Product.user_id == uid).all()
    total_products      = len(products)
    total_stock_qty     = sum(p.quantity or 0 for p in products)
    total_stock_value   = sum((p.quantity or 0) * float(p.price or 0) for p in products)
    critical_count      = sum(1 for p in products if (p.quantity or 0) <= (p.min_stock_alert or 5))
    out_of_stock_count  = sum(1 for p in products if (p.quantity or 0) == 0)

    # Bugünkü işlemler
    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    all_txns    = db.query(Transaction).filter(Transaction.user_id == uid).all()
    today_txns  = [t for t in all_txns if t.transaction_date and t.transaction_date >= today_start]

    today_sales  = [t for t in today_txns if t.transaction_type in ("satis", "sale", "gelir", "income")]
    today_sales_count  = len(today_sales)
    today_sales_amount = sum(t.amount or 0 for t in today_sales)
    today_customer_set = set(t.customer_name for t in today_txns if t.customer_name)
    today_customer_count = len(today_customer_set)

    total_transaction_count = len(all_txns)
    total_revenue = sum(
        t.amount or 0 for t in all_txns
        if t.transaction_type in ("satis", "sale", "gelir", "income")
    )

    return {
        # Ürünler
        "total_products":       total_products,       # Toplam ürün çeşidi sayısı
        "total_stock_qty":      total_stock_qty,       # Toplam stok adedi (tüm ürünler)
        "total_stock_value":    round(total_stock_value, 2),  # Toplam stok değeri (TRY)
        "critical_stock_count": critical_count,        # Kritik stok seviyesindeki ürün sayısı
        "out_of_stock_count":   out_of_stock_count,    # Stoku tükenmiş ürün sayısı
        # Bugün
        "today_sales_count":    today_sales_count,     # Bugün yapılan satış işlemi sayısı
        "today_sales_amount":   round(today_sales_amount, 2),  # Bugünkü toplam satış tutarı (TRY)
        "today_customer_count": today_customer_count,  # Bugün işlem yapılan benzersiz müşteri sayısı
        # Genel
        "total_transaction_count": total_transaction_count,  # Tüm zamanlar toplam işlem sayısı
        "total_revenue":        round(total_revenue, 2),      # Tüm zamanlar toplam gelir (TRY)
    }


@router.get("/data/subscription", summary="Abonelik ve kullanım limitleri")
def device_subscription(
    x_api_key: str = Header(..., alias="X-Api-Key"),
    db: Session = Depends(get_db),
):
    """
    Abonelik durumu ve kullanım limitleri:
      - Paket adı, bitiş tarihi, kalan gün
      - Max ürün / işlem limiti (paketten)
      - Şu an kullanılan ürün / işlem sayısı
      - Kalan kullanım hakları
    """
    device = _get_device_by_key(x_api_key, db)
    if not device.is_paired or not device.user_id:
        raise HTTPException(status_code=403, detail="Cihaz bir bayi ile eşleştirilmemiş.")
    uid = device.user_id

    owner = db.query(User).filter(User.id == uid).first()
    if not owner:
        raise HTTPException(status_code=404, detail="Bayi bulunamadı.")

    # Kalan abonelik günü
    now = datetime.now(timezone.utc)
    if owner.sub_expires_at:
        exp = owner.sub_expires_at
        if exp.tzinfo is None:
            from datetime import timezone as tz
            exp = exp.replace(tzinfo=tz.utc)
        days_left = max(0, (exp - now).days)
        expires_str = exp.strftime("%Y-%m-%d")
    else:
        days_left   = owner.sub_days or 0
        expires_str = ""

    # Paket limitlerini çek
    from app.models.package import Package
    pkg = db.query(Package).filter(Package.slug == (owner.package_slug or "starter")).first()
    max_products     = pkg.max_products     if pkg else 100
    max_transactions = pkg.max_transactions if pkg else 500
    pkg_name         = pkg.name             if pkg else owner.package_slug or "Starter"

    # Kullanım
    used_products     = db.query(Product).filter(Product.user_id == uid).count()
    used_transactions = db.query(Transaction).filter(Transaction.user_id == uid).count()
    remaining_products     = max(0, (max_products     or 0) - used_products)
    remaining_transactions = max(0, (max_transactions or 0) - used_transactions)

    return {
        "package_name":           pkg_name,            # Aktif paket adı (ör. "Starter", "Pro")
        "package_slug":           owner.package_slug or "starter",  # Paket kısa adı
        "expires_at":             expires_str,          # Abonelik bitiş tarihi (YYYY-MM-DD)
        "days_left":              days_left,            # Kalan abonelik günü
        "is_active":              days_left > 0,        # Abonelik aktif mi?
        "max_products":           max_products or 0,    # Paketteki maksimum ürün limiti
        "max_transactions":       max_transactions or 0, # Paketteki maksimum işlem limiti
        "used_products":          used_products,        # Şu an kayıtlı ürün sayısı
        "used_transactions":      used_transactions,    # Şu an kayıtlı işlem sayısı
        "remaining_products":     remaining_products,   # Daha kaç ürün eklenebilir
        "remaining_transactions": remaining_transactions, # Daha kaç işlem eklenebilir
    }


@router.get("/data/staff", summary="Personel ve garanti istatistikleri")
def device_staff_warranty(
    x_api_key: str = Header(..., alias="X-Api-Key"),
    db: Session = Depends(get_db),
):
    """
    Personel ve garanti verileri:
      - Toplam bağlı kullanıcı sayısı (sahip + personel)
      - Aktif personel sayısı
      - Garanti istatistikleri (toplam, aktif, bugün biten, 7 günde biten, süresi dolmuş)
      - Bugün eklenen garanti kayıtları
    """
    device = _get_device_by_key(x_api_key, db)
    if not device.is_paired or not device.user_id:
        raise HTTPException(status_code=403, detail="Cihaz bir bayi ile eşleştirilmemiş.")
    uid = device.user_id

    # Personel — aynı parent_user_id'ye sahip tüm çalışanlar
    staff_all    = db.query(User).filter(User.parent_user_id == uid).all()
    staff_total  = len(staff_all)                  # Toplam personel sayısı
    staff_active = sum(1 for u in staff_all if u.is_active)  # Aktif personel sayısı
    connected_user_count = staff_total + 1         # Patron dahil toplam hesap sayısı

    # Garanti istatistikleri
    now        = datetime.now(timezone.utc)
    today_end  = now.replace(hour=23, minute=59, second=59)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    week_end   = now.replace(hour=23, minute=59, second=59)
    from datetime import timedelta
    week_end_dt = now + timedelta(days=7)

    warranties    = db.query(Warranty).filter(Warranty.user_id == uid).all()
    warranty_total   = len(warranties)
    warranty_active  = 0
    warranty_expiring_today = 0
    warranty_expiring_week  = 0
    warranty_expired = 0
    warranty_today_added = 0

    for w in warranties:
        end = w.end_date
        if end and end.tzinfo is None:
            from datetime import timezone as tz
            end = end.replace(tzinfo=tz.utc)
        start = w.start_date
        if start and start.tzinfo is None:
            from datetime import timezone as tz
            start = start.replace(tzinfo=tz.utc)

        if end:
            if end < now:
                warranty_expired += 1
            else:
                warranty_active += 1
                if today_start <= end <= today_end:
                    warranty_expiring_today += 1
                if now <= end <= week_end_dt:
                    warranty_expiring_week += 1

        if start and start >= today_start:
            warranty_today_added += 1

    return {
        # Personel
        "connected_user_count": connected_user_count,  # Patron dahil toplam bağlı hesap
        "staff_total":          staff_total,            # Toplam personel sayısı
        "staff_active":         staff_active,           # Aktif personel sayısı
        # Garanti
        "warranty_total":           warranty_total,           # Toplam garanti kaydı
        "warranty_active":          warranty_active,          # Süresi devam eden garantiler
        "warranty_expired":         warranty_expired,         # Süresi dolmuş garantiler
        "warranty_expiring_today":  warranty_expiring_today,  # Bugün sona erecek garantiler
        "warranty_expiring_week":   warranty_expiring_week,   # 7 gün içinde sona erecek garantiler
        "warranty_today_added":     warranty_today_added,     # Bugün eklenen yeni garanti kayıtları
    }


@router.get("/ota/download", summary="Firmware indir (OTA)")
def device_ota_download(
    api_key: str,
    db: Session = Depends(get_db),
):
    device = _get_device_by_key(api_key, db)
    fw_field = "pending_firmware_esp8266" if device.device_type == "ESP8266" else "pending_firmware_esp32"
    filename = getattr(device, fw_field)
    if not filename:
        raise HTTPException(status_code=404, detail="Bekleyen firmware yok.")
    path = os.path.join(FIRMWARE_DIR, filename)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Firmware dosyası bulunamadı.")
    # Her indirmede sayacı artır — 2+ deneme sorun sinyali
    device.ota_attempt_count = (device.ota_attempt_count or 0) + 1
    device.ota_last_attempt_at = _now()
    db.commit()
    try:
        from app.api.topology import emit_topology_event
        emit_topology_event("download", "backend-s1", "devices",
                            f"OTA firmware: {filename} → {device.device_id[:12]}")
    except Exception:
        pass
    return FileResponse(path, media_type="application/octet-stream", filename=filename)


# ─────────────────────────────────────────────────────────
# 2. BAYİ ↔ SUNUCU — JWT ile kimlik doğrulama
# ─────────────────────────────────────────────────────────

def _is_owner(user: User) -> bool:
    return user.role == "bayi_sahibi"


@router.get("/my", summary="Benim cihazlarım")
def list_my_devices(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    owner_id = data_owner_id(current_user)
    devices = db.query(Device).filter(
        Device.user_id == owner_id,
        Device.is_active == True,
    ).all()
    return [_device_out(d) for d in devices]


@router.post("/pair", summary="Cihaz eşleştir")
def pair_device(
    body: PairRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not _is_owner(current_user):
        raise HTTPException(status_code=403, detail="Yalnızca bayi sahibi cihaz ekleyebilir.")
    device = db.query(Device).filter(Device.device_id == body.device_id).first()
    if not device:
        raise HTTPException(
            status_code=404,
            detail="Bu ID'ye sahip cihaz bulunamadı. Cihazın açık ve internete bağlı olduğundan emin olun.",
        )
    if device.is_paired and device.user_id and device.user_id != current_user.id:
        raise HTTPException(
            status_code=409,
            detail="Bu cihaz zaten başka bir bayi hesabına tanımlı.",
        )
    device.user_id = current_user.id
    device.is_paired = True
    device.is_active = True
    device.paired_at = _now()
    db.commit()
    try:
        from app.api.topology import emit_topology_event
        emit_topology_event("health", "devices", "backend-s1",
                            f"Cihaz eşleştirildi: {device.device_id[:12]}")
    except Exception:
        pass
    return {"ok": True, "device": _device_out(device)}


@router.delete("/{device_id}", summary="Cihazı sil / çıkar")
def delete_device(
    device_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not _is_owner(current_user):
        raise HTTPException(status_code=403, detail="Yalnızca bayi sahibi cihaz silebilir.")
    device = db.query(Device).filter(
        Device.device_id == device_id,
        Device.user_id == current_user.id,
    ).first()
    if not device:
        raise HTTPException(status_code=404, detail="Cihaz bulunamadı.")
    device.user_id = None
    device.is_paired = False
    device.paired_at = None
    db.commit()
    return {"ok": True, "message": "Cihaz hesabınızdan çıkarıldı."}


# ─────────────────────────────────────────────────────────
# 3. SÜPER ADMİN
# ─────────────────────────────────────────────────────────

def _require_superadmin(user: User):
    if not user.is_super_admin:
        raise HTTPException(status_code=403, detail="Süper yönetici yetkisi gerekli.")


@router.get("/admin/all", summary="[Admin] Tüm cihazlar")
def admin_list_all_devices(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_superadmin(current_user)
    devices = db.query(Device).order_by(Device.created_at.desc()).all()
    return [_device_out(d, include_sensitive=True, db=db) for d in devices]


@router.post("/admin/firmware/upload", summary="[Admin] Firmware yükle")
async def admin_upload_firmware(
    device_type: str,                    # ESP8266 | ESP32
    version: str,
    variant: str = "standart",           # standart | ekran | barkod | özel
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_superadmin(current_user)
    device_type = device_type.upper()
    if device_type not in ("ESP8266", "ESP32"):
        raise HTTPException(status_code=400, detail="device_type ESP8266 veya ESP32 olmalı.")
    safe_variant = (variant or "standart").strip().lower().replace("/", "_").replace(" ", "_") or "standart"
    safe_version = version.replace("/", "_").replace(" ", "_")
    filename = f"{device_type}_{safe_variant}_{safe_version}.bin"
    path = os.path.join(FIRMWARE_DIR, filename)
    content = await file.read()
    with open(path, "wb") as f:
        f.write(content)
    return FirmwareUploadResponse(
        filename=filename,
        device_type=device_type,
        variant=safe_variant,
        version=version,
        message=f"{device_type} ({safe_variant}) için {version} firmware yüklendi.",
    )


@router.get("/admin/firmware/list", summary="[Admin] Firmware listesi")
def admin_list_firmware(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_superadmin(current_user)
    files = []
    for fn in sorted(os.listdir(FIRMWARE_DIR)):
        if fn.endswith(".bin"):
            path = os.path.join(FIRMWARE_DIR, fn)
            base = fn.replace(".bin", "")
            parts = base.split("_", 2)
            device_type = parts[0] if parts else "?"
            # Yeni format: ESP8266_ekran_1.2.0  (3 parça)
            # Eski format: ESP8266_1.2.0        (2 parça, ikinci parça rakamla başlar)
            if len(parts) == 3:
                variant = parts[1]
                version = parts[2]
            elif len(parts) == 2 and parts[1] and not parts[1][0].isdigit():
                variant = parts[1]
                version = "?"
            else:
                variant = "standart"
                version = parts[1] if len(parts) > 1 else base
            files.append({
                "filename": fn,
                "device_type": device_type,
                "variant": variant,
                "version": version,
                "size_kb": round(os.path.getsize(path) / 1024, 1),
            })
    return files


@router.post("/admin/ota/push", summary="[Admin] OTA güncelleme gönder")
def admin_push_ota(
    body: OtaTargetRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_superadmin(current_user)
    path = os.path.join(FIRMWARE_DIR, body.firmware_filename)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Firmware dosyası bulunamadı.")

    q = db.query(Device).filter(Device.is_paired == True, Device.is_active == True)
    if body.device_ids:
        q = q.filter(Device.device_id.in_(body.device_ids))
    if body.device_type:
        q = q.filter(Device.device_type == body.device_type.upper())
    if body.variant:
        q = q.filter(Device.variant == body.variant.lower())
    devices = q.all()

    now = _now()
    updated = 0
    for d in devices:
        fw_field = "pending_firmware_esp8266" if d.device_type == "ESP8266" else "pending_firmware_esp32"
        setattr(d, fw_field, body.firmware_filename)
        d.pending_firmware_version = body.firmware_version
        d.firmware_update_requested_at = now
        d.ota_attempt_count = 0
        d.ota_last_attempt_at = None
        updated += 1
    db.commit()
    try:
        from app.api.topology import emit_topology_event
        emit_topology_event("upload", "backend-s1", "devices",
                            f"OTA push: {body.firmware_version} → {updated} cihaz")
    except Exception:
        pass
    return {"ok": True, "updated_count": updated, "message": f"{updated} cihaza OTA güncelleme gönderildi."}


@router.delete("/admin/firmware/file/{filename}", summary="[Admin] Firmware dosyasını sil")
def admin_delete_firmware(
    filename: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_superadmin(current_user)
    if ".." in filename or "/" in filename:
        raise HTTPException(status_code=400, detail="Geçersiz dosya adı.")
    path = os.path.join(FIRMWARE_DIR, filename)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Dosya bulunamadı.")
    os.remove(path)
    return {"ok": True, "message": f"{filename} silindi."}


@router.get("/admin/ota/pending", summary="[Admin] Bekleyen OTA güncellemeleri")
def admin_pending_ota(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_superadmin(current_user)
    devices = db.query(Device).filter(Device.pending_firmware_version.isnot(None)).all()
    result = []
    for d in devices:
        fw_field = "pending_firmware_esp8266" if d.device_type == "ESP8266" else "pending_firmware_esp32"
        pending_file = getattr(d, fw_field)
        online = d.last_seen and (_now() - d.last_seen).total_seconds() < 90
        user_email = user_name = None
        if d.user_id:
            from app.models.user import User as UserModel
            u = db.query(UserModel).filter(UserModel.id == d.user_id).first()
            if u:
                user_email = u.email
                user_name = u.full_name
        attempt_count = d.ota_attempt_count or 0
        result.append({
            "device_id": d.device_id,
            "device_type": d.device_type,
            "variant": getattr(d, "variant", "standart") or "standart",
            "current_version": d.firmware_version or "?",
            "pending_version": d.pending_firmware_version,
            "pending_filename": pending_file,
            "attempt_count": attempt_count,
            "last_attempt_at": d.ota_last_attempt_at.isoformat() if d.ota_last_attempt_at else None,
            "requested_at": d.firmware_update_requested_at.isoformat() if d.firmware_update_requested_at else None,
            "last_seen": d.last_seen.isoformat() if d.last_seen else None,
            "is_online": online,
            "is_paired": d.is_paired,
            "user_email": user_email,
            "user_name": user_name,
            # 2+ indirme denemesi ama hâlâ eski versiyon → sorun sinyali
            "is_problem": attempt_count >= 2,
        })
    return result


@router.post("/admin/ota/cancel", summary="[Admin] OTA güncellemeyi iptal et")
def admin_cancel_ota(
    body: dict,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_superadmin(current_user)
    device_ids = body.get("device_ids") or []
    if not device_ids:
        raise HTTPException(status_code=400, detail="device_ids listesi boş olamaz.")
    devices = db.query(Device).filter(Device.device_id.in_(device_ids)).all()
    for d in devices:
        d.pending_firmware_esp8266 = None
        d.pending_firmware_esp32 = None
        d.pending_firmware_version = None
        d.firmware_update_requested_at = None
        d.ota_attempt_count = 0
        d.ota_last_attempt_at = None
    db.commit()
    return {"ok": True, "cancelled_count": len(devices)}


@router.delete("/admin/{device_id}", summary="[Admin] Cihazı devre dışı bırak")
def admin_deactivate_device(
    device_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_superadmin(current_user)
    device = db.query(Device).filter(Device.device_id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="Cihaz bulunamadı.")
    device.is_active = False
    device.is_paired = False
    device.user_id = None
    device.paired_at = None
    db.commit()
    try:
        from app.api.topology import emit_topology_event
        emit_topology_event("delete", "devices", "backend-s1",
                            f"Cihaz devre dışı: {device_id[:12]}")
    except Exception:
        pass
    return {"ok": True, "message": "Cihaz devre dışı bırakıldı."}


@router.delete("/admin/{device_id}/permanent", summary="[Admin] Cihazı kalıcı olarak sil")
def admin_delete_device_permanent(
    device_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_superadmin(current_user)
    device = db.query(Device).filter(Device.device_id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="Cihaz bulunamadı.")
    _did = device.device_id
    record_deletion(db, "devices", device.id)
    db.delete(device)
    db.commit()
    trigger_delta_push()
    try:
        from app.api.topology import emit_topology_event
        emit_topology_event("delete", "devices", "backend-s1",
                            f"Cihaz kalıcı silindi: {_did[:12]}")
    except Exception:
        pass
    return {"ok": True, "message": "Cihaz kalıcı olarak silindi."}


@router.post("/admin/{device_id}/activate", summary="[Admin] Cihazı tekrar aktifleştir")
def admin_activate_device(
    device_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _require_superadmin(current_user)
    device = db.query(Device).filter(Device.device_id == device_id).first()
    if not device:
        raise HTTPException(status_code=404, detail="Cihaz bulunamadı.")
    device.is_active = True
    db.commit()
    return {"ok": True, "message": "Cihaz aktifleştirildi."}


# ─────────────────────────────────────────────────────────
# Yardımcı: çıktı formatı
# ─────────────────────────────────────────────────────────

def _device_out(d: Device, include_sensitive: bool = False, db: Session = None) -> dict:
    online = False
    if d.last_seen:
        diff = (_now() - d.last_seen).total_seconds()
        online = diff < 90
    out = {
        "id": d.id,
        "device_id": d.device_id,
        "device_type": d.device_type,
        "variant": getattr(d, "variant", "standart") or "standart",
        "is_paired": d.is_paired,
        "is_active": d.is_active,
        "is_online": online,
        "user_id": d.user_id,
        "user_email": None,
        "user_name": None,
        "firmware_version": d.firmware_version,
        "ip_address": d.ip_address,
        "mac_address": d.mac_address,
        "wifi_ssid": d.wifi_ssid,
        "wifi_rssi": d.wifi_rssi,
        "free_heap": d.free_heap,
        "uptime_seconds": d.uptime_seconds,
        "last_seen": d.last_seen.isoformat() if d.last_seen else None,
        "paired_at": d.paired_at.isoformat() if d.paired_at else None,
        "created_at": d.created_at.isoformat() if d.created_at else None,
        "notes": d.notes,
        "pending_firmware_version": d.pending_firmware_version,
    }
    if include_sensitive:
        out["api_key"] = d.api_key
    if db and d.user_id:
        user = db.query(User).filter(User.id == d.user_id).first()
        if user:
            out["user_email"] = user.email
            out["user_name"] = user.full_name
    return out
