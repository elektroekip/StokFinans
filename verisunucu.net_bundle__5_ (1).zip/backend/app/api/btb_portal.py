# Bu modül artık kullanılmıyor. Yeni BTB müşteri sistemi btb.py içindedir.
from fastapi import APIRouter
router = APIRouter()
