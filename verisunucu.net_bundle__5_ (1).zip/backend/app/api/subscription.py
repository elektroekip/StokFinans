"""
Abonelik API'leri (bayiler için):
- Paketleri listele
- Aktif abonelik durumu + kota kullanımı
- PayTR ile ödeme başlat
- PayTR IPN callback
- Polling ile durum sorgu
"""
from __future__ import annotations
import time
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Request, Form
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.api.auth import get_current_user
from app.models import User, Package, Payment, PaytrSetting, SubscriptionEvent
from app.services.subscription import (
    compute_days_remaining, extend_subscription, get_quota_usage, now_utc
)
from app.services.paytr import init_payment as paytr_init, verify_callback as paytr_verify


router = APIRouter(prefix="/subscription", tags=["Subscription"])


# ============================================================
# Schemas
# ============================================================

class PackageOut(BaseModel):
    slug: str
    name: str
    description: Optional[str]
    price_try: int
    duration_days: int
    max_products: Optional[int]
    max_transactions: Optional[int]
    max_support_tickets: Optional[int]
    has_support: bool
    is_featured: bool
    is_active: bool
    sort_order: int
    features: list[str]
    color_class: Optional[str]

    @classmethod
    def from_db(cls, p: Package) -> "PackageOut":
        return cls(
            slug=p.slug, name=p.name, description=p.description,
            price_try=p.price_try, duration_days=p.duration_days,
            max_products=p.max_products, max_transactions=p.max_transactions,
            max_support_tickets=p.max_support_tickets,
            has_support=p.has_support, is_featured=p.is_featured,
            is_active=p.is_active, sort_order=p.sort_order,
            features=list(p.features_json or []), color_class=p.color_class,
        )


class MyStatusOut(BaseModel):
    package_slug: Optional[str]
    package: Optional[PackageOut]
    sub_expires_at: Optional[str]
    days_remaining: int
    is_active: bool
    products_used: int
    products_limit: Optional[int]
    products_unlimited: bool
    transactions_used: int
    transactions_limit: Optional[int]
    transactions_unlimited: bool
    support_tickets_used: int
    support_tickets_limit: Optional[int]
    support_tickets_unlimited: bool


class CheckoutRequest(BaseModel):
    package_slug: str


class CheckoutResponse(BaseModel):
    payment_token: str
    iframe_url: str
    merchant_oid: str
    test_mode: bool


# ============================================================
# Endpoints
# ============================================================

@router.get("/packages", response_model=list[PackageOut])
async def list_packages(db: Session = Depends(get_db)):
    rows = db.query(Package).filter(Package.is_active == True).order_by(Package.sort_order).all()
    return [PackageOut.from_db(r) for r in rows]


@router.get("/me", response_model=MyStatusOut)
async def my_status(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    # Çalışan kullanıcı ise abonelik durumu PATRON üzerinden hesaplanır
    from app.utils.tenant import is_employee
    eff_user = current_user
    if is_employee(current_user) and current_user.parent_user_id:
        parent = db.query(User).filter(User.id == int(current_user.parent_user_id)).first()
        if parent:
            eff_user = parent
    usage = get_quota_usage(db, eff_user)
    pkg = usage["package"]
    days = compute_days_remaining(eff_user.sub_expires_at)
    # User.sub_days alanını mecburen senkron tut (cache mantığı) — sadece kendi user için
    if eff_user is current_user and current_user.sub_days != days:
        current_user.sub_days = days
        db.commit()
    return MyStatusOut(
        package_slug=eff_user.package_slug,
        package=PackageOut.from_db(pkg) if pkg else None,
        sub_expires_at=eff_user.sub_expires_at.isoformat() if eff_user.sub_expires_at else None,
        days_remaining=days,
        is_active=days > 0,
        products_used=usage["products_used"],
        products_limit=usage["products_limit"],
        products_unlimited=usage["products_unlimited"],
        transactions_used=usage["transactions_used"],
        transactions_limit=usage["transactions_limit"],
        transactions_unlimited=usage["transactions_unlimited"],
        support_tickets_used=usage["support_tickets_used"],
        support_tickets_limit=usage["support_tickets_limit"],
        support_tickets_unlimited=usage["support_tickets_unlimited"],
    )


def _client_ip(request: Request) -> str:
    fwd = request.headers.get("x-forwarded-for")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.client.host if request.client else "0.0.0.0"


def _public_base_url(request: Request) -> str:
    """Public base URL'yi döndür. PUBLIC_BASE_URL env varı varsa onu kullan."""
    import os
    env_base = os.environ.get("PUBLIC_BASE_URL", "").strip().rstrip("/")
    if env_base:
        return env_base
    fwd_proto = request.headers.get("x-forwarded-proto") or request.url.scheme
    fwd_host = request.headers.get("x-forwarded-host") or request.headers.get("host")
    return f"{fwd_proto}://{fwd_host}"


@router.post("/checkout", response_model=CheckoutResponse)
async def checkout(
    payload: CheckoutRequest,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    settings = db.query(PaytrSetting).filter(PaytrSetting.id == 1).first()
    if not settings or not settings.is_configured or not (settings.merchant_id and settings.merchant_key and settings.merchant_salt):
        raise HTTPException(status_code=503, detail="Ödeme sistemi henüz yapılandırılmamış. Lütfen platform yöneticisi ile iletişime geçin.")

    pkg = db.query(Package).filter(Package.slug == payload.package_slug, Package.is_active == True).first()
    if not pkg:
        raise HTTPException(status_code=404, detail="Geçersiz paket")

    # Benzersiz merchant_oid: timestamp + user_id + slug + uuid suffix (çakışma riskini ortadan kaldırır)
    import uuid as _uuid
    oid = f"SF{int(time.time())}U{current_user.id}{pkg.slug.upper()[:6]}{_uuid.uuid4().hex[:8].upper()}"
    oid = "".join(c for c in oid if c.isalnum())[:64]
    amount_kurus = int(pkg.price_try) * 100
    user_ip = _client_ip(request)
    base = _public_base_url(request)

    success_url = settings.success_url or f"{base}/?subscription=success"
    fail_url = settings.fail_url or f"{base}/?subscription=fail"

    basket = [[pkg.name, str(pkg.price_try), 1]]

    # Önce ödeme kaydını pending olarak DB'ye yaz
    payment = Payment(
        user_id=current_user.id,
        package_slug=pkg.slug,
        amount_try=pkg.price_try,
        paytr_merchant_oid=oid,
        status="pending",
        test_mode=1 if settings.test_mode else 0,
        user_ip=user_ip,
    )
    db.add(payment)
    db.commit()

    # PayTR'ye token al
    res = paytr_init(
        merchant_id=settings.merchant_id,
        merchant_key=settings.merchant_key,
        merchant_salt=settings.merchant_salt,
        test_mode=settings.test_mode,
        merchant_oid=oid,
        amount_kurus=amount_kurus,
        user_email=current_user.email,
        user_name=current_user.full_name or current_user.email,
        user_phone="05000000000",
        user_address=current_user.company_name or "Turkiye",
        user_ip=user_ip,
        user_basket=basket,
        success_url=success_url,
        fail_url=fail_url,
    )

    if res.get("status") != "success":
        payment.status = "failed"
        payment.error_message = res.get("reason") or "PayTR token alınamadı"
        db.commit()
        raise HTTPException(status_code=502, detail=f"PayTR hatası: {payment.error_message}")

    payment.paytr_payment_token = res["token"]
    db.commit()

    return CheckoutResponse(
        payment_token=res["token"],
        iframe_url=f"https://www.paytr.com/odeme/guvenli/{res['token']}",
        merchant_oid=oid,
        test_mode=bool(settings.test_mode),
    )


@router.post("/paytr/callback", response_class=PlainTextResponse)
async def paytr_callback(
    request: Request,
    db: Session = Depends(get_db),
    merchant_oid: str = Form(...),
    status: str = Form(...),
    total_amount: str = Form(...),
    hash: str = Form(...),
    failed_reason_code: Optional[str] = Form(None),
    failed_reason_msg: Optional[str] = Form(None),
):
    """PayTR IPN. Hash verify → payment & user güncelle. Cevap: 'OK' (başka bir şey yazılmamalı)."""
    settings = db.query(PaytrSetting).filter(PaytrSetting.id == 1).first()
    if not settings or not (settings.merchant_key and settings.merchant_salt):
        return "OK"

    if not paytr_verify(
        merchant_oid=merchant_oid,
        merchant_salt=settings.merchant_salt,
        merchant_key=settings.merchant_key,
        status=status,
        total_amount=total_amount,
        received_hash=hash,
    ):
        return "PAYTR notification failed: bad hash"

    payment = (
        db.query(Payment)
        .filter(Payment.paytr_merchant_oid == merchant_oid)
        .with_for_update()
        .first()
    )
    if not payment:
        return "OK"

    # Tutar doğrulaması: gelen total_amount (kuruş) DB'deki amount_try * 100 olmalı.
    # PayTR farklı bir tutar bildirirse (ör. manipulasyon, yanlış paket) ödemeyi başarısız işaretle.
    try:
        received_kurus = int(str(total_amount).strip())
    except (ValueError, TypeError):
        received_kurus = -1
    expected_kurus = int(payment.amount_try) * 100
    if received_kurus != expected_kurus:
        if payment.status != "success":
            payment.status = "failed"
            payment.error_message = f"Tutar uyumsuz: bekleniyor {expected_kurus}, gelen {received_kurus}"
            db.commit()
        return "OK"

    if payment.status == "success":
        # idempotent
        return "OK"

    payment.callback_received_at = now_utc()

    if status == "success":
        # Kullanıcının paketine süre ekle
        user = db.query(User).filter(User.id == payment.user_id).with_for_update().first()
        pkg = db.query(Package).filter(Package.slug == payment.package_slug).first()
        if user and pkg:
            days_before, days_after = extend_subscription(user, pkg.duration_days)
            user.package_slug = pkg.slug
            payment.status = "success"
            payment.days_added = pkg.duration_days
            payment.completed_at = now_utc()
            db.add(SubscriptionEvent(
                user_id=user.id,
                event_type="payment_success",
                days_delta=days_after - days_before,
                days_before=days_before,
                days_after=days_after,
                actor_user_id=None,
                related_user_id=None,
                note=f"Ödeme: {pkg.name} ({pkg.price_try}₺) — OID {merchant_oid}",
            ))
        else:
            payment.status = "failed"
            payment.error_message = "Kullanıcı veya paket bulunamadı"
    else:
        payment.status = "failed"
        payment.error_message = f"{failed_reason_code or ''} {failed_reason_msg or ''}".strip() or "PayTR ödeme başarısız"

    db.commit()
    return "OK"


@router.get("/payments/me")
async def my_payments(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    limit: int = 50,
):
    rows = (db.query(Payment)
              .filter(Payment.user_id == current_user.id)
              .order_by(Payment.created_at.desc())
              .limit(limit).all())
    return {
        "items": [
            {
                "id": p.id,
                "package_slug": p.package_slug,
                "amount_try": p.amount_try,
                "merchant_oid": p.paytr_merchant_oid,
                "status": p.status,
                "days_added": p.days_added,
                "test_mode": bool(p.test_mode),
                "error_message": p.error_message,
                "created_at": p.created_at.isoformat() if p.created_at else None,
                "completed_at": p.completed_at.isoformat() if p.completed_at else None,
            } for p in rows
        ]
    }


@router.get("/payments/{merchant_oid}")
async def get_payment_status(
    merchant_oid: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    p = db.query(Payment).filter(
        Payment.paytr_merchant_oid == merchant_oid,
        Payment.user_id == current_user.id,
    ).first()
    if not p:
        raise HTTPException(status_code=404, detail="Ödeme bulunamadı")
    return {
        "merchant_oid": p.paytr_merchant_oid,
        "status": p.status,
        "package_slug": p.package_slug,
        "amount_try": p.amount_try,
        "days_added": p.days_added,
        "error_message": p.error_message,
        "completed_at": p.completed_at.isoformat() if p.completed_at else None,
    }
