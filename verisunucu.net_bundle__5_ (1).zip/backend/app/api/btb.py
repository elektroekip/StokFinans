"""
BTB (İşletmeden İşletmeye) Modülü
Kurumsal müşteri, sipariş, iskonto, kargo takip ve ödeme yönetimi.
"""
from __future__ import annotations

from datetime import datetime, date, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, text
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models import Transaction, Product, Category
from app.models.user import User
from app.models.btb import BtbCustomer, BtbOrder, BtbOrderItem, BtbPayment, BtbPriceList
from app.schemas.btb import (
    BtbCustomerCreate, BtbCustomerUpdate, BtbCustomerOut,
    BtbOrderCreate, BtbOrderUpdate, BtbOrderOut,
    BtbOrderItemOut, BtbPaymentCreate, BtbPaymentOut, BtbStatsOut,
    BtbPriceListCreate, BtbPriceListUpdate, BtbPriceListOut, CreditCheckOut,
)
from app.utils.auth import get_current_user
from app.utils.permissions import require_perm
from app.utils.tenant import data_owner_id
from app.services.sync_service import record_deletion, trigger_delta_push

router = APIRouter(prefix="/btb", tags=["BTB"])


# ── Helpers ───────────────────────────────────────────────────

def _get_customer_or_404(db: Session, customer_id: int, owner_id: int) -> BtbCustomer:
    c = db.query(BtbCustomer).filter(
        BtbCustomer.id == customer_id,
        BtbCustomer.user_id == owner_id,
    ).first()
    if not c:
        raise HTTPException(status_code=404, detail="Müşteri bulunamadı")
    return c


def _get_order_or_404(db: Session, order_id: int, owner_id: int) -> BtbOrder:
    o = db.query(BtbOrder).filter(
        BtbOrder.id == order_id,
        BtbOrder.user_id == owner_id,
    ).first()
    if not o:
        raise HTTPException(status_code=404, detail="Sipariş bulunamadı")
    return o


def _next_order_number(db: Session, owner_id: int) -> str:
    year = datetime.now(timezone.utc).year
    count = db.query(func.count(BtbOrder.id)).filter(
        BtbOrder.user_id == owner_id,
        func.extract("year", BtbOrder.created_at) == year,
    ).scalar() or 0
    return f"BTB-{year}-{count + 1:04d}"


def _compute_totals(items_data: list, order_discount_rate: float = 0):
    """
    Kalem ve sipariş indirimini dikkate alarak:
    subtotal, kdv_amount, discount_amount, total_amount döndürür.
    """
    subtotal = 0.0
    kdv_total = 0.0
    for it in items_data:
        qty = int(it.quantity if hasattr(it, "quantity") else it.get("quantity", 1))
        price = float(it.unit_price if hasattr(it, "unit_price") else it.get("unit_price", 0))
        item_disc = float(it.discount_rate if hasattr(it, "discount_rate") else it.get("discount_rate", 0))
        kdv = float(it.kdv_rate if hasattr(it, "kdv_rate") else it.get("kdv_rate", 0))

        line_base = price * qty * (1 - item_disc / 100)
        line_kdv = line_base * kdv / 100
        subtotal += line_base
        kdv_total += line_kdv

    order_disc_amount = round(subtotal * order_discount_rate / 100, 2)
    total = round(subtotal - order_disc_amount + kdv_total, 2)
    return round(subtotal, 2), round(kdv_total, 2), order_disc_amount, total


def _item_line_total(item) -> float:
    qty = int(item.quantity if hasattr(item, "quantity") else item.get("quantity", 1))
    price = float(item.unit_price if hasattr(item, "unit_price") else item.get("unit_price", 0))
    item_disc = float(item.discount_rate if hasattr(item, "discount_rate") else item.get("discount_rate", 0))
    kdv = float(item.kdv_rate if hasattr(item, "kdv_rate") else item.get("kdv_rate", 0))
    base = price * qty * (1 - item_disc / 100)
    return round(base * (1 + kdv / 100), 2)


def _items_for_order(db: Session, order_id: int) -> List[BtbOrderItemOut]:
    rows = db.query(BtbOrderItem).filter(BtbOrderItem.order_id == order_id).all()
    return [BtbOrderItemOut.model_validate(r) for r in rows]


def _payments_for_order(db: Session, order_id: int) -> List[BtbPaymentOut]:
    rows = db.query(BtbPayment).filter(BtbPayment.order_id == order_id).order_by(BtbPayment.paid_at).all()
    return [BtbPaymentOut.model_validate(r) for r in rows]


def _paid_total(db: Session, order_id: int) -> float:
    return float(
        db.query(func.coalesce(func.sum(BtbPayment.amount), 0))
        .filter(BtbPayment.order_id == order_id)
        .scalar() or 0
    )


def _order_out(order: BtbOrder, db: Session) -> BtbOrderOut:
    customer = db.query(BtbCustomer).filter(BtbCustomer.id == order.customer_id).first()
    out = BtbOrderOut.model_validate(order)
    out.customer_name = customer.company_name if customer else ""
    out.items = _items_for_order(db, order.id)
    out.payments = _payments_for_order(db, order.id)
    out.paid_total = _paid_total(db, order.id)
    out.remaining = max(0.0, round(order.total_amount - out.paid_total, 2))
    return out


_ACTIVE_STATUSES = ["confirmed", "shipped", "delivered"]


def _customer_debt(db: Session, customer_id: int) -> float:
    return float(
        db.query(func.coalesce(func.sum(BtbOrder.total_amount), 0)).filter(
            BtbOrder.customer_id == customer_id,
            BtbOrder.status.in_(_ACTIVE_STATUSES),
            BtbOrder.is_paid == False,
        ).scalar() or 0
    )


# ── Stats ─────────────────────────────────────────────────────

@router.get("/stats", response_model=BtbStatsOut)
def get_btb_stats(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.view")
    owner = data_owner_id(current_user)

    active_orders = db.query(func.count(BtbOrder.id)).filter(
        BtbOrder.user_id == owner,
        BtbOrder.status.in_(["draft", "confirmed", "shipped"]),
    ).scalar() or 0

    total_receivable = float(
        db.query(func.coalesce(func.sum(BtbOrder.total_amount), 0)).filter(
            BtbOrder.user_id == owner,
            BtbOrder.status.in_(_ACTIVE_STATUSES),
            BtbOrder.is_paid == False,
        ).scalar() or 0
    )

    customer_count = db.query(func.count(BtbCustomer.id)).filter(
        BtbCustomer.user_id == owner,
        BtbCustomer.is_active == True,
    ).scalar() or 0

    now = datetime.now(timezone.utc)
    delivered_this_month = db.query(func.count(BtbOrder.id)).filter(
        BtbOrder.user_id == owner,
        BtbOrder.status == "delivered",
        func.extract("year", BtbOrder.updated_at) == now.year,
        func.extract("month", BtbOrder.updated_at) == now.month,
    ).scalar() or 0

    today = now.date()
    overdue_count = db.query(func.count(BtbOrder.id)).filter(
        BtbOrder.user_id == owner,
        BtbOrder.status.in_(_ACTIVE_STATUSES),
        BtbOrder.is_paid == False,
        BtbOrder.due_date != None,
        BtbOrder.due_date < today,
    ).scalar() or 0

    # Bu ay tahsil edilen toplam
    paid_order_ids = [
        row[0] for row in db.query(BtbOrder.id).filter(
            BtbOrder.user_id == owner,
        ).all()
    ]
    total_collected = 0.0
    if paid_order_ids:
        total_collected = float(
            db.query(func.coalesce(func.sum(BtbPayment.amount), 0)).filter(
                BtbPayment.order_id.in_(paid_order_ids),
                func.extract("year", BtbPayment.paid_at) == now.year,
                func.extract("month", BtbPayment.paid_at) == now.month,
            ).scalar() or 0
        )

    return BtbStatsOut(
        active_orders=active_orders,
        total_receivable=total_receivable,
        customer_count=customer_count,
        delivered_this_month=delivered_this_month,
        overdue_count=overdue_count,
        total_collected_this_month=total_collected,
    )


# ── Customers ─────────────────────────────────────────────────

@router.get("/customers", response_model=List[BtbCustomerOut])
def list_customers(
    q: Optional[str] = Query(None),
    active_only: bool = Query(False),
    category: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.view")
    owner = data_owner_id(current_user)
    query = db.query(BtbCustomer).filter(BtbCustomer.user_id == owner)
    if active_only:
        query = query.filter(BtbCustomer.is_active == True)
    if category:
        query = query.filter(BtbCustomer.category == category)
    if q:
        like = f"%{q}%"
        query = query.filter(
            BtbCustomer.company_name.ilike(like) |
            BtbCustomer.contact_person.ilike(like) |
            BtbCustomer.phone.ilike(like)
        )
    customers = query.order_by(BtbCustomer.company_name).all()

    today = datetime.now(timezone.utc).date()
    result = []
    for c in customers:
        out = BtbCustomerOut.model_validate(c)
        out.order_count = db.query(func.count(BtbOrder.id)).filter(
            BtbOrder.customer_id == c.id,
        ).scalar() or 0
        out.total_debt = float(
            db.query(func.coalesce(func.sum(BtbOrder.total_amount), 0)).filter(
                BtbOrder.customer_id == c.id,
                BtbOrder.status.in_(_ACTIVE_STATUSES),
                BtbOrder.is_paid == False,
            ).scalar() or 0
        )
        out.overdue_count = db.query(func.count(BtbOrder.id)).filter(
            BtbOrder.customer_id == c.id,
            BtbOrder.status.in_(_ACTIVE_STATUSES),
            BtbOrder.is_paid == False,
            BtbOrder.due_date != None,
            BtbOrder.due_date < today,
        ).scalar() or 0
        result.append(out)
    return result


@router.post("/customers", response_model=BtbCustomerOut, status_code=201)
def create_customer(
    data: BtbCustomerCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.add")
    owner = data_owner_id(current_user)
    customer = BtbCustomer(user_id=owner, **data.model_dump())
    db.add(customer)
    # E-posta mevcut bir kullanıcıya aitse hemen bağla
    if data.email:
        from app.models import User as _User
        existing_user = db.query(_User).filter(_User.email == data.email).first()
        if existing_user:
            customer.linked_user_id = existing_user.id
            # btb_musteri olmayan mevcut kullanıcılar için role değiştirilmez
            # btb_musteri olmayan kullanıcılar Sipariş Paneli'ni kullanır
    db.commit()
    db.refresh(customer)
    out = BtbCustomerOut.model_validate(customer)
    return out


@router.get("/customers/{customer_id}", response_model=BtbCustomerOut)
def get_customer(
    customer_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.view")
    owner = data_owner_id(current_user)
    c = _get_customer_or_404(db, customer_id, owner)
    out = BtbCustomerOut.model_validate(c)
    today = datetime.now(timezone.utc).date()
    out.order_count = db.query(func.count(BtbOrder.id)).filter(BtbOrder.customer_id == c.id).scalar() or 0
    out.total_debt = float(
        db.query(func.coalesce(func.sum(BtbOrder.total_amount), 0)).filter(
            BtbOrder.customer_id == c.id,
            BtbOrder.status.in_(_ACTIVE_STATUSES),
            BtbOrder.is_paid == False,
        ).scalar() or 0
    )
    out.overdue_count = db.query(func.count(BtbOrder.id)).filter(
        BtbOrder.customer_id == c.id,
        BtbOrder.status.in_(_ACTIVE_STATUSES),
        BtbOrder.is_paid == False,
        BtbOrder.due_date != None,
        BtbOrder.due_date < today,
    ).scalar() or 0
    return out


@router.get("/customers/{customer_id}/summary")
def get_customer_summary(
    customer_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Müşteriye ait tüm sipariş/ödeme geçmişi ve finansal özet."""
    require_perm(current_user, "btb.view")
    owner = data_owner_id(current_user)
    c = _get_customer_or_404(db, customer_id, owner)

    orders = db.query(BtbOrder).filter(
        BtbOrder.customer_id == customer_id,
    ).order_by(BtbOrder.created_at.desc()).all()

    total_ordered = float(
        db.query(func.coalesce(func.sum(BtbOrder.total_amount), 0)).filter(
            BtbOrder.customer_id == customer_id,
            BtbOrder.status.in_(_ACTIVE_STATUSES),
        ).scalar() or 0
    )
    total_paid_q = float(
        db.query(func.coalesce(func.sum(BtbPayment.amount), 0)).filter(
            BtbPayment.order_id.in_([o.id for o in orders]) if orders else [],
        ).scalar() or 0
    ) if orders else 0.0
    total_remaining = float(
        db.query(func.coalesce(func.sum(BtbOrder.total_amount), 0)).filter(
            BtbOrder.customer_id == customer_id,
            BtbOrder.status.in_(_ACTIVE_STATUSES),
            BtbOrder.is_paid == False,
        ).scalar() or 0
    )

    order_list = []
    for o in orders:
        o_out = _order_out(o, db)
        order_list.append({
            "id": o.id,
            "order_number": o.order_number,
            "status": o.status,
            "total_amount": o.total_amount,
            "currency": o.currency,
            "is_paid": o.is_paid,
            "paid_total": o_out.paid_total,
            "remaining": o_out.remaining,
            "due_date": o.due_date.isoformat() if o.due_date else None,
            "created_at": o.created_at.isoformat() if o.created_at else None,
            "items": [
                {
                    "product_name": it.product_name,
                    "quantity": it.quantity,
                    "unit_price": it.unit_price,
                    "kdv_rate": it.kdv_rate,
                    "discount_rate": it.discount_rate,
                    "line_total": it.line_total,
                }
                for it in db.query(BtbOrderItem).filter(BtbOrderItem.order_id == o.id).all()
            ],
            "payments": [
                {
                    "id": p.id,
                    "amount": p.amount,
                    "payment_method": p.payment_method,
                    "notes": p.notes,
                    "paid_at": p.paid_at.isoformat() if p.paid_at else None,
                }
                for p in db.query(BtbPayment).filter(BtbPayment.order_id == o.id).all()
            ],
        })

    return {
        "customer": {
            "id": c.id,
            "company_name": c.company_name,
            "contact_person": c.contact_person,
            "phone": c.phone,
            "email": c.email,
            "vkn": c.vkn,
            "tax_office": c.tax_office,
            "address": c.address,
            "category": c.category,
            "discount_rate": c.discount_rate,
            "credit_limit": c.credit_limit,
            "payment_term_days": c.payment_term_days,
            "is_active": c.is_active,
            "notes": c.notes,
        },
        "summary": {
            "total_ordered": total_ordered,
            "total_paid": total_paid_q,
            "total_remaining": total_remaining,
            "order_count": len(orders),
        },
        "orders": order_list,
    }


@router.put("/customers/{customer_id}", response_model=BtbCustomerOut)
def update_customer(
    customer_id: int,
    data: BtbCustomerUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.edit")
    owner = data_owner_id(current_user)
    c = _get_customer_or_404(db, customer_id, owner)
    for field, val in data.model_dump(exclude_unset=True).items():
        setattr(c, field, val)
    # E-posta güncellendiyse linked_user_id'yi yeniden hesapla
    if hasattr(data, 'email') and data.email:
        from app.models import User as _User
        existing_user = db.query(_User).filter(_User.email == data.email).first()
        c.linked_user_id = existing_user.id if existing_user else c.linked_user_id
    db.commit()
    db.refresh(c)
    return BtbCustomerOut.model_validate(c)


@router.delete("/customers/{customer_id}", status_code=204)
def delete_customer(
    customer_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.delete")
    owner = data_owner_id(current_user)
    c = _get_customer_or_404(db, customer_id, owner)
    active = db.query(func.count(BtbOrder.id)).filter(
        BtbOrder.customer_id == c.id,
        BtbOrder.status.in_(["confirmed", "shipped"]),
    ).scalar() or 0
    if active > 0:
        raise HTTPException(
            status_code=400,
            detail="Bu müşterinin onaylanmış veya kargodaki siparişleri var — önce iptal edin.",
        )
    order_ids = [
        row[0] for row in db.query(BtbOrder.id).filter(BtbOrder.customer_id == c.id).all()
    ]
    if order_ids:
        for oid in order_ids:
            record_deletion(db, "btb_orders", oid)
        db.query(BtbPayment).filter(BtbPayment.order_id.in_(order_ids)).delete(synchronize_session=False)
        db.query(BtbOrderItem).filter(BtbOrderItem.order_id.in_(order_ids)).delete(synchronize_session=False)
        db.query(BtbOrder).filter(BtbOrder.id.in_(order_ids)).delete(synchronize_session=False)
    record_deletion(db, "btb_customers", c.id)
    db.delete(c)
    db.commit()
    trigger_delta_push()


# ── Orders ────────────────────────────────────────────────────

@router.get("/orders", response_model=List[BtbOrderOut])
def list_orders(
    status_filter: Optional[str] = Query(None, alias="status"),
    customer_id: Optional[int] = Query(None),
    q: Optional[str] = Query(None),
    overdue_only: bool = Query(False),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.view")
    owner = data_owner_id(current_user)
    query = db.query(BtbOrder).filter(BtbOrder.user_id == owner)
    if status_filter:
        query = query.filter(BtbOrder.status == status_filter)
    if customer_id:
        query = query.filter(BtbOrder.customer_id == customer_id)
    if q:
        query = query.filter(BtbOrder.order_number.ilike(f"%{q}%"))
    if overdue_only:
        today = datetime.now(timezone.utc).date()
        query = query.filter(
            BtbOrder.status.in_(["confirmed", "shipped"]),
            BtbOrder.is_paid == False,
            BtbOrder.due_date != None,
            BtbOrder.due_date < today,
        )
    orders = query.order_by(BtbOrder.created_at.desc()).all()
    return [_order_out(o, db) for o in orders]


@router.post("/orders", response_model=BtbOrderOut, status_code=201)
def create_order(
    data: BtbOrderCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.add")
    owner = data_owner_id(current_user)
    _get_customer_or_404(db, data.customer_id, owner)

    subtotal, kdv_amount, discount_amount, total = _compute_totals(data.items, data.discount_rate)

    order = BtbOrder(
        user_id=owner,
        customer_id=data.customer_id,
        order_number=_next_order_number(db, owner),
        status="draft",
        notes=data.notes,
        due_date=data.due_date,
        shipping_address=data.shipping_address,
        shipping_carrier=data.shipping_carrier,
        tracking_number=data.tracking_number,
        subtotal=subtotal,
        kdv_amount=kdv_amount,
        discount_rate=data.discount_rate,
        discount_amount=discount_amount,
        total_amount=total,
        currency=data.currency,
    )
    db.add(order)
    db.flush()

    for item in data.items:
        db.add(BtbOrderItem(
            order_id=order.id,
            product_id=item.product_id,
            product_name=item.product_name,
            unit_price=item.unit_price,
            currency=item.currency,
            quantity=item.quantity,
            discount_rate=item.discount_rate,
            kdv_rate=item.kdv_rate,
            line_total=_item_line_total(item),
        ))

    db.commit()
    db.refresh(order)
    return _order_out(order, db)


@router.get("/orders/{order_id}", response_model=BtbOrderOut)
def get_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.view")
    owner = data_owner_id(current_user)
    order = _get_order_or_404(db, order_id, owner)
    return _order_out(order, db)


@router.put("/orders/{order_id}", response_model=BtbOrderOut)
def update_order(
    order_id: int,
    data: BtbOrderUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.edit")
    owner = data_owner_id(current_user)
    order = _get_order_or_404(db, order_id, owner)
    if order.status != "draft":
        raise HTTPException(400, "Sadece taslak siparişler düzenlenebilir.")

    updates = data.model_dump(exclude_unset=True)
    items_data = updates.pop("items", None)

    if "customer_id" in updates:
        _get_customer_or_404(db, updates["customer_id"], owner)

    for field, val in updates.items():
        setattr(order, field, val)

    if items_data is not None:
        db.query(BtbOrderItem).filter(BtbOrderItem.order_id == order.id).delete()
        for item in items_data:
            db.add(BtbOrderItem(
                order_id=order.id,
                product_id=item.get("product_id"),
                product_name=item["product_name"],
                unit_price=item["unit_price"],
                currency=item.get("currency", "TRY"),
                quantity=item["quantity"],
                discount_rate=item.get("discount_rate", 0),
                kdv_rate=item.get("kdv_rate", 0),
                line_total=_item_line_total(item),
            ))

    # Yeniden toplam hesapla
    all_items = db.query(BtbOrderItem).filter(BtbOrderItem.order_id == order.id).all()
    disc_rate = float(order.discount_rate or 0)
    subtotal, kdv_amount, discount_amount, total = _compute_totals(all_items, disc_rate)
    order.subtotal = subtotal
    order.kdv_amount = kdv_amount
    order.discount_amount = discount_amount
    order.total_amount = total

    db.commit()
    db.refresh(order)
    return _order_out(order, db)


@router.delete("/orders/{order_id}", status_code=204)
def delete_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.delete")
    owner = data_owner_id(current_user)
    order = _get_order_or_404(db, order_id, owner)
    if order.status != "draft":
        raise HTTPException(400, "Sadece taslak siparişler silinebilir.")
    record_deletion(db, "btb_orders", order.id)
    db.delete(order)
    db.commit()
    trigger_delta_push()


# ── Order status transitions ──────────────────────────────────

@router.post("/orders/{order_id}/confirm", response_model=BtbOrderOut)
def confirm_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.edit")
    owner = data_owner_id(current_user)
    order = _get_order_or_404(db, order_id, owner)
    if order.status != "draft":
        raise HTTPException(400, f"Bu sipariş zaten '{order.status}' durumunda.")

    customer = _get_customer_or_404(db, order.customer_id, owner)
    items = db.query(BtbOrderItem).filter(BtbOrderItem.order_id == order.id).all()

    if not items:
        raise HTTPException(400, "Sipariş kalemi boş — onaylanamaz.")

    # 0. Kredi limiti kontrolü
    if customer.credit_limit > 0:
        current_debt = _customer_debt(db, customer.id)
        if current_debt + order.total_amount > customer.credit_limit:
            raise HTTPException(
                400,
                f"Kredi limiti aşıldı: {customer.company_name} limiti {customer.credit_limit:.2f} ₺, "
                f"mevcut açık bakiye {current_debt:.2f} ₺, bu sipariş {order.total_amount:.2f} ₺.",
            )

    # 1. Stok kontrolü + atomik düşme
    for item in items:
        if item.product_id is None:
            continue
        product = db.query(Product).filter(
            Product.id == item.product_id,
            Product.user_id == owner,
        ).first()
        if not product:
            raise HTTPException(400, f"Ürün bulunamadı (ID: {item.product_id})")
        upd = db.execute(
            text(
                "UPDATE products SET quantity = quantity - :qty, updated_at = NOW() "
                "WHERE id = :id AND user_id = :uid AND quantity >= :qty"
            ),
            {"qty": item.quantity, "id": item.product_id, "uid": owner},
        )
        if upd.rowcount == 0:
            raise HTTPException(
                400,
                f"Yetersiz stok: {product.name} (İstenen: {item.quantity})",
            )
        db.expire(product)

    # 2. Cari transaction oluştur
    txn = Transaction(
        user_id=owner,
        transaction_type="borç",
        customer_name=customer.company_name,
        customer_phone=customer.phone,
        customer_vkn=customer.vkn,
        amount=order.total_amount,
        currency=order.currency,
        kdv_rate=0,
        description=f"BTB Sipariş #{order.order_number}",
        created_at=datetime.now(),
        updated_at=datetime.now(),
    )
    db.add(txn)
    db.flush()

    order.transaction_id = txn.id
    order.status = "confirmed"
    order.updated_at = datetime.now()
    db.commit()
    db.refresh(order)
    return _order_out(order, db)


@router.post("/orders/{order_id}/ship", response_model=BtbOrderOut)
def ship_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.edit")
    owner = data_owner_id(current_user)
    order = _get_order_or_404(db, order_id, owner)
    if order.status != "confirmed":
        raise HTTPException(400, f"Kargoya vermek için sipariş 'confirmed' olmalı (şu an: '{order.status}').")
    order.status = "shipped"
    order.updated_at = datetime.now()
    db.commit()
    db.refresh(order)
    return _order_out(order, db)


@router.post("/orders/{order_id}/deliver", response_model=BtbOrderOut)
def deliver_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.edit")
    owner = data_owner_id(current_user)
    order = _get_order_or_404(db, order_id, owner)
    if order.status != "shipped":
        raise HTTPException(400, f"Teslim için sipariş 'shipped' olmalı (şu an: '{order.status}').")
    order.status = "delivered"
    order.updated_at = datetime.now()
    db.commit()
    db.refresh(order)
    return _order_out(order, db)


@router.post("/orders/{order_id}/cancel", response_model=BtbOrderOut)
def cancel_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.edit")
    owner = data_owner_id(current_user)
    order = _get_order_or_404(db, order_id, owner)
    if order.status in ("delivered", "cancelled"):
        raise HTTPException(400, f"Bu sipariş iptal edilemez (durum: '{order.status}').")

    if order.status in ("confirmed", "shipped"):
        items = db.query(BtbOrderItem).filter(BtbOrderItem.order_id == order.id).all()
        for item in items:
            if item.product_id is None:
                continue
            product = db.query(Product).filter(
                Product.id == item.product_id,
                Product.user_id == owner,
            ).first()
            if product:
                product.quantity += item.quantity
                product.updated_at = datetime.now()
                db.add(product)
        if order.transaction_id:
            txn = db.query(Transaction).filter(Transaction.id == order.transaction_id).first()
            if txn:
                record_deletion(db, "transactions", txn.id)
                db.delete(txn)

    order.status = "cancelled"
    order.transaction_id = None
    order.updated_at = datetime.now()
    db.commit()
    db.refresh(order)
    return _order_out(order, db)


@router.post("/orders/{order_id}/mark-paid", response_model=BtbOrderOut)
def mark_order_paid(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Tüm tutarı hızlıca ödendi işaretle."""
    require_perm(current_user, "btb.edit")
    owner = data_owner_id(current_user)
    order = _get_order_or_404(db, order_id, owner)
    if order.status not in ("confirmed", "shipped", "delivered"):
        raise HTTPException(400, f"Bu durumda ödeme işaretle yapılamaz (durum: '{order.status}').")
    if order.is_paid:
        raise HTTPException(400, "Bu sipariş zaten ödendi olarak işaretlenmiş.")

    order.is_paid = True
    order.paid_at = datetime.now(timezone.utc)
    order.updated_at = datetime.now()
    db.commit()
    db.refresh(order)
    return _order_out(order, db)


# ── Payments (kısmi ödeme) ────────────────────────────────────

@router.get("/orders/{order_id}/payments", response_model=List[BtbPaymentOut])
def list_payments(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.view")
    owner = data_owner_id(current_user)
    _get_order_or_404(db, order_id, owner)
    return _payments_for_order(db, order_id)


@router.post("/orders/{order_id}/payments", response_model=BtbPaymentOut, status_code=201)
def add_payment(
    order_id: int,
    data: BtbPaymentCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Siparişe ödeme ekle (kısmi veya tam). Toplam ödeme tutara ulaşırsa is_paid=True."""
    require_perm(current_user, "btb.edit")
    owner = data_owner_id(current_user)
    order = _get_order_or_404(db, order_id, owner)
    if order.status not in ("confirmed", "shipped", "delivered"):
        raise HTTPException(400, f"Bu sipariş için ödeme eklenemiyor (durum: '{order.status}').")

    paid_at = data.paid_at or datetime.now(timezone.utc)
    payment = BtbPayment(
        order_id=order.id,
        amount=data.amount,
        payment_method=data.payment_method,
        notes=data.notes,
        paid_at=paid_at,
    )
    db.add(payment)
    db.flush()

    # Toplam ödemeyi kontrol et
    total_paid = _paid_total(db, order.id)
    if total_paid >= order.total_amount and not order.is_paid:
        order.is_paid = True
        order.paid_at = paid_at
        order.updated_at = datetime.now()

    db.commit()
    db.refresh(payment)
    return BtbPaymentOut.model_validate(payment)


@router.delete("/orders/{order_id}/payments/{payment_id}", status_code=204)
def delete_payment(
    order_id: int,
    payment_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.edit")
    owner = data_owner_id(current_user)
    order = _get_order_or_404(db, order_id, owner)
    payment = db.query(BtbPayment).filter(
        BtbPayment.id == payment_id,
        BtbPayment.order_id == order_id,
    ).first()
    if not payment:
        raise HTTPException(404, "Ödeme kaydı bulunamadı.")
    record_deletion(db, "btb_payments", payment.id)
    db.delete(payment)
    db.flush()

    # is_paid'i yeniden hesapla
    total_paid = _paid_total(db, order.id)
    if total_paid < order.total_amount and order.is_paid:
        order.is_paid = False
        order.paid_at = None
        order.updated_at = datetime.now()

    db.commit()


# ── Credit Check ──────────────────────────────────────────────

@router.get("/customers/{customer_id}/credit-check", response_model=CreditCheckOut)
def credit_check(
    customer_id: int,
    amount: float = Query(..., gt=0, description="Yeni sipariş tutarı"),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Müşterinin mevcut borcu + sipariş tutarının kredi limitini aşıp aşmadığını kontrol et."""
    require_perm(current_user, "btb.view")
    owner = data_owner_id(current_user)
    customer = _get_customer_or_404(db, customer_id, owner)
    current_debt = _customer_debt(db, customer.id)
    available = max(0.0, customer.credit_limit - current_debt) if customer.credit_limit > 0 else float("inf")
    would_exceed = customer.credit_limit > 0 and (current_debt + amount > customer.credit_limit)
    remaining_after = max(0.0, customer.credit_limit - current_debt - amount) if customer.credit_limit > 0 else 0.0
    return CreditCheckOut(
        customer_id=customer.id,
        company_name=customer.company_name,
        credit_limit=customer.credit_limit,
        current_debt=current_debt,
        available_credit=available if customer.credit_limit > 0 else customer.credit_limit,
        order_amount=amount,
        would_exceed=would_exceed,
        remaining_after=remaining_after,
    )


# ── Price Lists ───────────────────────────────────────────────

@router.get("/price-lists", response_model=List[BtbPriceListOut])
def list_price_lists(
    category: Optional[str] = Query(None),
    product_id: Optional[int] = Query(None),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.view")
    owner = data_owner_id(current_user)
    q = db.query(BtbPriceList).filter(BtbPriceList.user_id == owner)
    if category:
        q = q.filter(BtbPriceList.category == category)
    if product_id is not None:
        q = q.filter(BtbPriceList.product_id == product_id)
    return [BtbPriceListOut.model_validate(p) for p in q.order_by(BtbPriceList.category, BtbPriceList.product_name).all()]


@router.post("/price-lists", response_model=BtbPriceListOut, status_code=201)
def create_price_list(
    data: BtbPriceListCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.add")
    owner = data_owner_id(current_user)
    pl = BtbPriceList(user_id=owner, **data.model_dump())
    db.add(pl)
    db.commit()
    db.refresh(pl)
    return BtbPriceListOut.model_validate(pl)


@router.put("/price-lists/{pl_id}", response_model=BtbPriceListOut)
def update_price_list(
    pl_id: int,
    data: BtbPriceListUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.edit")
    owner = data_owner_id(current_user)
    pl = db.query(BtbPriceList).filter(BtbPriceList.id == pl_id, BtbPriceList.user_id == owner).first()
    if not pl:
        raise HTTPException(status_code=404, detail="Fiyat listesi bulunamadı")
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(pl, k, v)
    db.commit()
    db.refresh(pl)
    return BtbPriceListOut.model_validate(pl)


@router.delete("/price-lists/{pl_id}", status_code=204)
def delete_price_list(
    pl_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.delete")
    owner = data_owner_id(current_user)
    pl = db.query(BtbPriceList).filter(BtbPriceList.id == pl_id, BtbPriceList.user_id == owner).first()
    if not pl:
        raise HTTPException(status_code=404, detail="Fiyat listesi bulunamadı")
    record_deletion(db, "btb_price_lists", pl.id)
    db.delete(pl)
    db.commit()
    trigger_delta_push()


@router.get("/price-lists/lookup", response_model=Optional[BtbPriceListOut])
def lookup_price(
    product_id: int = Query(...),
    category: str = Query(..., description="Müşteri kategorisi: A, B veya C"),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Belirli ürün + müşteri kategorisi için fiyat listesi kuralı döndür."""
    require_perm(current_user, "btb.view")
    owner = data_owner_id(current_user)
    # Önce tam eşleşme, sonra ALL
    pl = db.query(BtbPriceList).filter(
        BtbPriceList.user_id == owner,
        BtbPriceList.product_id == product_id,
        BtbPriceList.is_active == True,
        BtbPriceList.category == category,
    ).first()
    if not pl:
        pl = db.query(BtbPriceList).filter(
            BtbPriceList.user_id == owner,
            BtbPriceList.product_id == product_id,
            BtbPriceList.is_active == True,
            BtbPriceList.category == "ALL",
        ).first()
    return BtbPriceListOut.model_validate(pl) if pl else None


# ─────────────────────────────────────────────────────────────────────────────
# BTB PORTAL YÖNETİMİ — Bayi tarafı
# ─────────────────────────────────────────────────────────────────────────────

from app.models.btb_portal import BtbPortalAccount


@router.get("/portal/accounts")
def list_portal_accounts(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Bayi'nin portal müşteri hesaplarını listele."""
    require_perm(current_user, "btb.view")
    owner = data_owner_id(current_user)
    accounts = (
        db.query(BtbPortalAccount, BtbCustomer)
        .join(BtbCustomer, BtbPortalAccount.btb_customer_id == BtbCustomer.id)
        .filter(BtbPortalAccount.bayi_user_id == owner)
        .order_by(BtbPortalAccount.created_at.desc())
        .all()
    )
    result = []
    for acc, cust in accounts:
        result.append({
            "id": acc.id,
            "btb_customer_id": acc.btb_customer_id,
            "company_name": cust.company_name,
            "email": acc.email,
            "full_name": acc.full_name,
            "is_active": acc.is_active,
            "last_login": acc.last_login.isoformat() if acc.last_login else None,
            "created_at": acc.created_at.isoformat() if acc.created_at else None,
        })
    return result


@router.post("/portal/accounts/{account_id}/suspend")
def suspend_portal_account(
    account_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.edit")
    owner = data_owner_id(current_user)
    acc = db.query(BtbPortalAccount).filter(
        BtbPortalAccount.id == account_id,
        BtbPortalAccount.bayi_user_id == owner,
    ).first()
    if not acc:
        raise HTTPException(404, "Portal hesabı bulunamadı")
    acc.is_active = False
    db.commit()
    return {"message": "Portal hesabı askıya alındı"}


@router.post("/portal/accounts/{account_id}/activate")
def activate_portal_account(
    account_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    require_perm(current_user, "btb.edit")
    owner = data_owner_id(current_user)
    acc = db.query(BtbPortalAccount).filter(
        BtbPortalAccount.id == account_id,
        BtbPortalAccount.bayi_user_id == owner,
    ).first()
    if not acc:
        raise HTTPException(404, "Portal hesabı bulunamadı")
    acc.is_active = True
    db.commit()
    return {"message": "Portal hesabı aktif edildi"}


@router.get("/portal/pending-count")
def portal_pending_count(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """pending_approval bekleyen sipariş sayısını döndür (badge için)."""
    require_perm(current_user, "btb.view")
    owner = data_owner_id(current_user)
    count = db.query(BtbOrder).filter(
        BtbOrder.user_id == owner,
        BtbOrder.status == "pending_approval",
    ).count()
    return {"count": count}


@router.post("/orders/{order_id}/portal-approve", response_model=BtbOrderOut)
def portal_approve_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Portal'dan gelen pending_approval siparişini onayla → confirmed + stok düş + transaction."""
    require_perm(current_user, "btb.edit")
    owner = data_owner_id(current_user)
    order = _get_order_or_404(db, order_id, owner)
    if order.status != "pending_approval":
        raise HTTPException(400, f"Sipariş 'pending_approval' durumunda değil (şu an: '{order.status}').")

    customer = _get_customer_or_404(db, order.customer_id, owner)
    items = db.query(BtbOrderItem).filter(BtbOrderItem.order_id == order.id).all()

    if not items:
        raise HTTPException(400, "Sipariş kalemi boş — onaylanamaz.")

    # Kredi limiti kontrolü
    if customer.credit_limit > 0:
        current_debt = _customer_debt(db, customer.id)
        if current_debt + order.total_amount > customer.credit_limit:
            raise HTTPException(
                400,
                f"Kredi limiti aşıldı: limit {customer.credit_limit:.2f} ₺, "
                f"mevcut bakiye {current_debt:.2f} ₺, sipariş {order.total_amount:.2f} ₺.",
            )

    # Stok kontrolü + atomik düşme
    for item in items:
        if item.product_id is None:
            continue
        product = db.query(Product).filter(Product.id == item.product_id, Product.user_id == owner).first()
        if not product:
            raise HTTPException(400, f"Ürün bulunamadı (ID: {item.product_id})")
        upd = db.execute(
            text(
                "UPDATE products SET quantity = quantity - :qty, updated_at = NOW() "
                "WHERE id = :id AND user_id = :uid AND quantity >= :qty"
            ),
            {"qty": item.quantity, "id": item.product_id, "uid": owner},
        )
        if upd.rowcount == 0:
            raise HTTPException(400, f"Yetersiz stok: {product.name} (İstenen: {item.quantity})")
        db.expire(product)

    # Cari transaction oluştur
    txn = Transaction(
        user_id=owner,
        transaction_type="borç",
        customer_name=customer.company_name,
        customer_phone=customer.phone,
        customer_vkn=customer.vkn,
        amount=order.total_amount,
        currency=order.currency,
        kdv_rate=0,
        description=f"BTB Portal Sipariş #{order.order_number}",
        created_at=datetime.now(),
        updated_at=datetime.now(),
    )
    db.add(txn)
    db.flush()

    order.transaction_id = txn.id
    order.status = "confirmed"
    order.updated_at = datetime.now()
    db.commit()
    db.refresh(order)
    return _order_out(order, db)


@router.post("/orders/{order_id}/portal-reject", response_model=BtbOrderOut)
def portal_reject_order(
    order_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Portal'dan gelen pending_approval siparişini reddet → cancelled."""
    require_perm(current_user, "btb.edit")
    owner = data_owner_id(current_user)
    order = _get_order_or_404(db, order_id, owner)
    if order.status != "pending_approval":
        raise HTTPException(400, f"Sipariş 'pending_approval' durumunda değil (şu an: '{order.status}').")
    order.status = "cancelled"
    order.updated_at = datetime.now()
    db.commit()
    db.refresh(order)
    return _order_out(order, db)


# ─── BTB Customer (btb_musteri) endpoints ────────────────────────────────────

from app.models.btb_activity import BtbActivityLog as _BtbActivityLog
import json as _json


def _require_btb_musteri(current_user=Depends(get_current_user), db: Session = Depends(get_db)):
    """btb_musteri rolü olan kullanıcıyı ve ilişkili BtbCustomer kaydını döner."""
    if current_user.role != "btb_musteri":
        raise HTTPException(status_code=403, detail="Bu endpoint sadece BTB müşterilerine açıktır")
    cust = db.query(BtbCustomer).filter(BtbCustomer.linked_user_id == current_user.id).first()
    if not cust:
        raise HTTPException(status_code=404, detail="BTB müşteri kaydı bulunamadı")
    return (current_user, cust)


def _log_activity(db, btb_customer_id: int, user_id: int, action: str, details: dict = None):
    try:
        db.add(_BtbActivityLog(
            btb_customer_id=btb_customer_id,
            user_id=user_id,
            action=action,
            details=_json.dumps(details, ensure_ascii=False) if details else None,
        ))
        db.commit()
    except Exception:
        pass


@router.get("/customer/me", tags=["BTB-Customer"])
def btb_customer_me(
    pair=Depends(_require_btb_musteri),
    db: Session = Depends(get_db),
):
    current_user, cust = pair
    # Açık borç hesapla
    from app.models.btb import BtbOrder as _BtbOrd
    debt = db.query(func.sum(_BtbOrd.total_amount)).filter(
        _BtbOrd.customer_id == cust.id,
        _BtbOrd.status.in_(["confirmed", "shipped"]),
        _BtbOrd.is_paid == False,
    ).scalar() or 0
    return {
        "id": cust.id,
        "company_name": cust.company_name,
        "contact_person": cust.contact_person,
        "email": cust.email,
        "discount_rate": cust.discount_rate,
        "credit_limit": cust.credit_limit,
        "payment_term_days": cust.payment_term_days,
        "open_debt": debt,
        "bayi_user_id": cust.user_id,
        "user_full_name": current_user.full_name,
    }


@router.get("/customer/products", tags=["BTB-Customer"])
def btb_customer_products(
    q: str = Query(None),
    category: str = Query(None),
    pair=Depends(_require_btb_musteri),
    db: Session = Depends(get_db),
):
    current_user, cust = pair
    query = db.query(Product).filter(
        Product.user_id == cust.user_id,
        Product.quantity > 0,
    )
    if q:
        query = query.filter(Product.name.ilike(f"%{q}%"))
    if category:
        query = query.filter(Product.category == category)
    products = query.order_by(Product.name).limit(200).all()
    _log_activity(db, cust.id, current_user.id, "view_products", {"q": q, "category": category, "count": len(products)})
    discount = cust.discount_rate or 0
    return [
        {
            "id": p.id,
            "name": p.name,
            "stock": p.quantity,
            "list_price": p.price,
            "customer_price": round(p.price * (1 - discount / 100), 2),
            "currency": getattr(p, "currency", "TRY"),
            "category": p.category if isinstance(getattr(p, "category", None), str) else None,
            "barcode": getattr(p, "barcode", None),
            "image_url": getattr(p, "image_url", None),
            "kdv_rate": 18,
        }
        for p in products
    ]


@router.get("/customer/categories", tags=["BTB-Customer"])
def btb_customer_categories(
    pair=Depends(_require_btb_musteri),
    db: Session = Depends(get_db),
):
    current_user, cust = pair
    rows = (
        db.query(Product.category)
        .filter(Product.user_id == cust.user_id, Product.category != None, Product.category != "")
        .distinct()
        .order_by(Product.category)
        .all()
    )
    return [{"id": r.category, "name": r.category} for r in rows if r.category]


@router.post("/customer/checkout", tags=["BTB-Customer"])
def btb_customer_checkout(
    payload: dict,
    pair=Depends(_require_btb_musteri),
    db: Session = Depends(get_db),
):
    current_user, cust = pair
    items = payload.get("items", [])
    if not items:
        raise HTTPException(status_code=400, detail="Sipariş kalemi boş")

    notes = payload.get("notes", "")
    due_date_str = payload.get("due_date")
    shipping_address = payload.get("shipping_address", "")
    due_date = None
    if due_date_str:
        from datetime import date as _date
        try:
            due_date = _date.fromisoformat(due_date_str)
        except Exception:
            pass

    import datetime as _dt

    discount = cust.discount_rate or 0

    # Order number
    year = _dt.datetime.now().year
    last_order = (
        db.query(BtbOrder)
        .filter(BtbOrder.user_id == cust.user_id)
        .order_by(BtbOrder.id.desc())
        .first()
    )
    seq = (last_order.id + 1) if last_order else 1
    order_number = f"BTB-{year}-{seq:04d}"

    # Validate items & calc totals
    order_items = []
    subtotal = 0
    kdv_total = 0
    for it in items:
        product_id = it.get("product_id")
        qty = int(it.get("quantity", 1))
        prod = db.query(Product).filter(Product.id == product_id, Product.user_id == cust.user_id).first()
        if not prod:
            raise HTTPException(status_code=404, detail=f"Ürün bulunamadı: {product_id}")
        if prod.quantity < qty:
            raise HTTPException(status_code=400, detail=f"Yetersiz stok: {prod.name}")
        unit_price = round(prod.price * (1 - discount / 100), 2)
        kdv = getattr(prod, "kdv_rate", 18)
        line = unit_price * qty
        line_kdv = round(line * kdv / 100, 2)
        subtotal += line
        kdv_total += line_kdv
        order_items.append(BtbOrderItem(
            product_id=prod.id,
            product_name=prod.name,
            unit_price=unit_price,
            currency="TRY",
            quantity=qty,
            discount_rate=discount,
            kdv_rate=kdv,
        ))

    total = round(subtotal + kdv_total, 2)

    new_order = BtbOrder(
        user_id=cust.user_id,
        customer_id=cust.id,
        order_number=order_number,
        status="pending_approval",
        notes=notes,
        due_date=due_date,
        shipping_address=shipping_address,
        subtotal=round(subtotal, 2),
        kdv_amount=round(kdv_total, 2),
        discount_rate=discount,
        discount_amount=0,
        total_amount=total,
        currency="TRY",
    )
    db.add(new_order)
    db.flush()

    for item in order_items:
        item.order_id = new_order.id
        db.add(item)

    db.commit()
    _log_activity(db, cust.id, current_user.id, "checkout", {
        "order_id": new_order.id,
        "order_number": order_number,
        "total": total,
        "item_count": len(order_items),
    })
    return {"id": new_order.id, "order_number": order_number, "total_amount": total, "status": "pending_approval"}


@router.get("/customer/orders", tags=["BTB-Customer"])
def btb_customer_orders(
    pair=Depends(_require_btb_musteri),
    db: Session = Depends(get_db),
):
    current_user, cust = pair
    orders = (
        db.query(BtbOrder)
        .filter(BtbOrder.customer_id == cust.id)
        .order_by(BtbOrder.created_at.desc())
        .limit(100)
        .all()
    )
    _log_activity(db, cust.id, current_user.id, "view_orders", {"count": len(orders)})
    result = []
    for o in orders:
        items = db.query(BtbOrderItem).filter(BtbOrderItem.order_id == o.id).all()
        result.append({
            "id": o.id,
            "order_number": o.order_number,
            "status": o.status,
            "total_amount": o.total_amount,
            "currency": o.currency,
            "is_paid": o.is_paid,
            "due_date": o.due_date.isoformat() if o.due_date else None,
            "created_at": o.created_at.isoformat() if o.created_at else None,
            "items": [
                {
                    "product_name": i.product_name,
                    "quantity": i.quantity,
                    "unit_price": i.unit_price,
                    "kdv_rate": i.kdv_rate,
                }
                for i in items
            ],
        })
    return result


# ─── Bayi: Müşteri aktivite logları ──────────────────────────────────────────

@router.get("/customers/{customer_id}/activity", tags=["BTB"])
def get_customer_activity(
    customer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    owner_id = data_owner_id(current_user)
    cust = db.query(BtbCustomer).filter(BtbCustomer.id == customer_id, BtbCustomer.user_id == owner_id).first()
    if not cust:
        raise HTTPException(status_code=404, detail="Müşteri bulunamadı")
    logs = (
        db.query(_BtbActivityLog)
        .filter(_BtbActivityLog.btb_customer_id == customer_id)
        .order_by(_BtbActivityLog.created_at.desc())
        .limit(100)
        .all()
    )
    return [
        {
            "id": lg.id,
            "action": lg.action,
            "details": _json.loads(lg.details) if lg.details else None,
            "created_at": lg.created_at.isoformat() if lg.created_at else None,
        }
        for lg in logs
    ]


@router.get("/portal/activity-summary", tags=["BTB"])
def btb_portal_activity_summary(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Bayi'nin tüm B2B müşterilerinin son aktivitelerini döner."""
    owner_id = data_owner_id(current_user)
    customers = db.query(BtbCustomer).filter(BtbCustomer.user_id == owner_id).all()
    cust_ids = [c.id for c in customers]
    if not cust_ids:
        return []
    cust_map = {c.id: c for c in customers}

    logs = (
        db.query(_BtbActivityLog)
        .filter(_BtbActivityLog.btb_customer_id.in_(cust_ids))
        .order_by(_BtbActivityLog.created_at.desc())
        .limit(200)
        .all()
    )

    pending_count = (
        db.query(func.count(BtbOrder.id))
        .filter(BtbOrder.user_id == owner_id, BtbOrder.status == "pending_approval")
        .scalar() or 0
    )

    return {
        "pending_count": pending_count,
        "logs": [
            {
                "id": lg.id,
                "btb_customer_id": lg.btb_customer_id,
                "company_name": cust_map[lg.btb_customer_id].company_name if lg.btb_customer_id in cust_map else "?",
                "action": lg.action,
                "details": _json.loads(lg.details) if lg.details else None,
                "created_at": lg.created_at.isoformat() if lg.created_at else None,
            }
            for lg in logs
        ],
    }


# ─── Sipariş Paneli (Supply) endpoints ───────────────────────────────────────
# Bir kullanıcı, başka bir bayi tarafından BTB müşterisi olarak eklenmişse
# bu endpoint'ler aracılığıyla o bayiden sipariş verebilir.

@router.get("/supply/sources", tags=["BTB-Supply"])
def get_supply_sources(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Beni BTB müşterisi olarak ekleyen bayileri listele."""
    # Bu kullanıcının linked_user_id'si olan tüm btb_customer kayıtlarını bul
    my_customer_records = (
        db.query(BtbCustomer)
        .filter(BtbCustomer.linked_user_id == current_user.id)
        .all()
    )
    if not my_customer_records:
        return []

    result = []
    for cust in my_customer_records:
        supplier = db.query(User).filter(User.id == cust.user_id).first()
        if not supplier:
            continue
        # Bekleyen onay sayısı
        pending = db.query(func.count(BtbOrder.id)).filter(
            BtbOrder.customer_id == cust.id,
            BtbOrder.status == "pending_approval",
        ).scalar() or 0
        total_orders = db.query(func.count(BtbOrder.id)).filter(
            BtbOrder.customer_id == cust.id,
        ).scalar() or 0
        result.append({
            "btb_customer_id": cust.id,
            "bayi_user_id": supplier.id,
            "bayi_name": supplier.company_name or supplier.full_name,
            "bayi_email": supplier.email,
            "my_company_name": cust.company_name,
            "discount_rate": cust.discount_rate,
            "credit_limit": cust.credit_limit,
            "payment_term_days": cust.payment_term_days,
            "pending_orders": pending,
            "total_orders": total_orders,
            "is_active": cust.is_active,
        })
    return result


@router.get("/supply/{btb_customer_id}/products", tags=["BTB-Supply"])
def get_supply_products(
    btb_customer_id: int,
    q: str = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Tedarikçi bayinin ürünlerini listele."""
    # Bu btb_customer kaydının gerçekten bu kullanıcıya ait olduğunu doğrula
    cust = db.query(BtbCustomer).filter(
        BtbCustomer.id == btb_customer_id,
        BtbCustomer.linked_user_id == current_user.id,
    ).first()
    if not cust:
        raise HTTPException(status_code=403, detail="Bu tedarikçiye erişiminiz yok")

    query = db.query(Product).filter(
        Product.user_id == cust.user_id,
        Product.quantity > 0,
    )
    if q:
        query = query.filter(Product.name.ilike(f"%{q}%"))
    products = query.order_by(Product.name).limit(200).all()
    discount = cust.discount_rate or 0
    return [
        {
            "id": p.id,
            "name": p.name,
            "stock": p.quantity,
            "list_price": p.price,
            "customer_price": round(p.price * (1 - discount / 100), 2),
            "currency": getattr(p, "currency", "TRY"),
            "category": p.category if isinstance(getattr(p, "category", None), str) else None,
            "barcode": getattr(p, "barcode", None),
            "image_url": getattr(p, "image_url", None),
            "kdv_rate": 18,
        }
        for p in products
    ]


@router.post("/supply/{btb_customer_id}/checkout", tags=["BTB-Supply"])
def supply_checkout(
    btb_customer_id: int,
    payload: dict,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Tedarikçi bayiye sipariş ver."""
    cust = db.query(BtbCustomer).filter(
        BtbCustomer.id == btb_customer_id,
        BtbCustomer.linked_user_id == current_user.id,
    ).first()
    if not cust:
        raise HTTPException(status_code=403, detail="Bu tedarikçiye erişiminiz yok")
    if not cust.is_active:
        raise HTTPException(status_code=400, detail="Bu müşteri hesabı aktif değil")

    items = payload.get("items", [])
    if not items:
        raise HTTPException(status_code=400, detail="Sipariş kalemi boş")

    notes = payload.get("notes", "")
    due_date_str = payload.get("due_date")
    shipping_address = payload.get("shipping_address", "")
    due_date = None
    if due_date_str:
        from datetime import date as _date
        try:
            due_date = _date.fromisoformat(due_date_str)
        except Exception:
            pass

    from app.models.btb import BtbOrderItem as _BtbOrdItem
    import datetime as _dt

    discount = cust.discount_rate or 0
    year = _dt.datetime.now().year
    last_order = db.query(BtbOrder).filter(BtbOrder.user_id == cust.user_id).order_by(BtbOrder.id.desc()).first()
    seq = (last_order.id + 1) if last_order else 1
    order_number = f"BTB-{year}-{seq:04d}"

    order_items = []
    subtotal = 0
    kdv_total = 0
    for it in items:
        product_id = it.get("product_id")
        qty = int(it.get("quantity", 1))
        prod = db.query(Product).filter(Product.id == product_id, Product.user_id == cust.user_id).first()
        if not prod:
            raise HTTPException(status_code=404, detail=f"Ürün bulunamadı: {product_id}")
        if prod.quantity < qty:
            raise HTTPException(status_code=400, detail=f"Yetersiz stok: {prod.name}")
        unit_price = round(prod.price * (1 - discount / 100), 2)
        kdv = getattr(prod, "kdv_rate", 18)
        line = unit_price * qty
        line_kdv = round(line * kdv / 100, 2)
        subtotal += line
        kdv_total += line_kdv
        order_items.append(_BtbOrdItem(
            product_id=prod.id,
            product_name=prod.name,
            unit_price=unit_price,
            currency="TRY",
            quantity=qty,
            discount_rate=discount,
            kdv_rate=kdv,
        ))

    total = round(subtotal + kdv_total, 2)
    new_order = BtbOrder(
        user_id=cust.user_id,
        customer_id=cust.id,
        order_number=order_number,
        status="pending_approval",
        notes=f"[Bayi Portal] {current_user.full_name or current_user.email}: {notes}".strip(": "),
        due_date=due_date,
        shipping_address=shipping_address,
        subtotal=round(subtotal, 2),
        kdv_amount=round(kdv_total, 2),
        discount_rate=discount,
        discount_amount=0,
        total_amount=total,
        currency="TRY",
    )
    db.add(new_order)
    db.flush()
    for item in order_items:
        item.order_id = new_order.id
        db.add(item)
    db.commit()

    # Aktivite logu (opsiyonel)
    try:
        import json as _j
        from app.models.btb_activity import BtbActivityLog as _AL
        db.add(_AL(
            btb_customer_id=cust.id,
            user_id=current_user.id,
            action="checkout",
            details=_j.dumps({"order_number": order_number, "total": total, "source": "bayi_portal"}, ensure_ascii=False),
        ))
        db.commit()
    except Exception:
        pass

    return {"id": new_order.id, "order_number": order_number, "total_amount": total, "status": "pending_approval"}


@router.get("/supply/orders", tags=["BTB-Supply"])
def get_supply_orders(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Bu kullanıcının tedarikçilere verdiği siparişleri listele."""
    my_records = db.query(BtbCustomer).filter(BtbCustomer.linked_user_id == current_user.id).all()
    if not my_records:
        return []
    cust_ids = [c.id for c in my_records]
    cust_map = {c.id: c for c in my_records}

    from app.models.btb import BtbOrderItem as _BtbOrdItem
    orders = (
        db.query(BtbOrder)
        .filter(BtbOrder.customer_id.in_(cust_ids))
        .order_by(BtbOrder.created_at.desc())
        .limit(100)
        .all()
    )
    result = []
    for o in orders:
        cust = cust_map.get(o.customer_id)
        supplier = db.query(User).filter(User.id == o.user_id).first() if cust else None
        items = db.query(_BtbOrdItem).filter(_BtbOrdItem.order_id == o.id).all()
        result.append({
            "id": o.id,
            "order_number": o.order_number,
            "status": o.status,
            "total_amount": o.total_amount,
            "currency": o.currency,
            "is_paid": o.is_paid,
            "due_date": o.due_date.isoformat() if o.due_date else None,
            "created_at": o.created_at.isoformat() if o.created_at else None,
            "supplier_name": supplier.company_name or supplier.full_name if supplier else "?",
            "items": [
                {"product_name": i.product_name, "quantity": i.quantity, "unit_price": i.unit_price}
                for i in items
            ],
        })
    return result
