# 🚀 StokFinans Backend

FastAPI ve SQLAlchemy ile yazılmış, otomotiv aksesuar stok ve finans yönetim sisteminin backend'i.

## 📋 Hızlı Başlangıç

### 1️⃣ Sanal Ortamı Aktif Et

**Windows (PowerShell):**
```powershell
venv\Scripts\Activate.ps1
```

**Windows (CMD):**
```cmd
venv\Scripts\activate
```

**macOS / Linux:**
```bash
source venv/bin/activate
```

### 2️⃣ Paketleri Kur

```bash
pip install -r requirements.txt
```

### 3️⃣ .env Dosyasını Oluştur

```bash
cp .env.example .env
```

Gerekli bilgileri `.env` dosyasına doldurun.

### 4️⃣ Sunucuyu Başlat

```bash
uvicorn main:app --reload
```

✅ **Başarı!** API'ye şu adresten erişebilirsiniz:
- **Swagger UI:** http://localhost:8000/api/docs
- **ReDoc:** http://localhost:8000/api/redoc

---

## 📁 Proje Yapısı

```
backend/
├── app/
│   ├── core/
│   │   ├── __init__.py
│   │   └── database.py           # Veritabanı konfigürasyonu
│   ├── models/
│   │   ├── __init__.py
│   │   ├── user.py               # User modeli
│   │   ├── product.py            # Product modeli
│   │   ├── transaction.py        # Transaction modeli
│   │   └── log.py                # ActivityLog modeli
│   ├── schemas/
│   │   ├── __init__.py
│   │   └── user.py               # User validation schemas
│   ├── api/
│   │   ├── __init__.py
│   │   └── (endpoint'ler yapılacak)
│   ├── services/
│   │   ├── __init__.py
│   │   └── (business logic yapılacak)
│   ├── utils/
│   │   ├── __init__.py
│   │   └── (yardımcı fonksiyonlar yapılacak)
│   └── __init__.py
├── logs/                          # Uygulama logları
├── uploads/                       # Yüklenen dosyalar
├── venv/                          # Python sanal ortamı
├── main.py                        # Ana FastAPI uygulaması
├── requirements.txt               # Python bağımlılıkları
├── .env.example                   # Çevre değişkenleri şablonu
└── README.md                      # Bu dosya
```

---

## 🏗️ Mimari

### Models (Veritabanı)
```
User (Kullanıcı)
├── id (Primary Key)
├── email (Unique)
├── password_hash
├── full_name
├── company_name
├── role (bayi_sahibi, calisan)
├── ref_code (Referral Kodu)
├── sub_days (Abonelik Günü)
└── created_at

Product (Ürün)
├── id (Primary Key)
├── user_id (Foreign Key → User)
├── category
├── name
├── barcode (Unique)
├── buy_price
├── sell_price
├── stock_amount
└── min_stock_alert

Transaction (İşlem/Cari)
├── id (Primary Key)
├── user_id (Foreign Key → User)
├── customer_name
├── transaction_type (debt, payment, expense)
├── amount
├── description
├── image_url
└── balance

ActivityLog (Faaliyet Günlüğü)
├── id (Primary Key)
├── user_id (Foreign Key → User)
├── action_type
├── entity_type
├── entity_id
└── description
```

---

## 🔐 Güvenlik

### Şifre Hashing
- **Algoritma:** Bcrypt
- **Kütüphane:** `passlib`
- Şifreler hiçbir zaman açık metin olarak saklanmaz

### JWT Token'ı
- **Algoritma:** HS256
- **Kütüphane:** `python-jose`
- **Süresi:** 30 dakika (Access Token)
- API isteklerinde `Authorization: Bearer {token}` başlığı kullanılır

### CORS
- Sadece izin verilen domainler erişebilir
- `.env` dosyasında `CORS_ORIGINS` ile ayarlanır

### IP Koruma (Referral System)
- Aynı IP'den sahte kayıt yapılmasını önler
- Kayıt sırasında IP adresi kaydedilir

---

## 🗄️ Veritabanı

### Geliştirme (SQLite)
- Kurulum gerektirmiyor
- Dosya tabanlı: `stokfinans.db`
- Test ve geliştirme için ideal

### Üretim (PostgreSQL)
- Çok kullanıcılı desteği
- Daha güvenli ve ölçeklenebilir
- URL: `postgresql://user:pass@host:5432/stokfinans`

### Migration'lar (Alembic)
Veritabanı şemasını değiştirirken:
```bash
# Yeni migration oluştur
alembic revision --autogenerate -m "Add new column"

# Migrationları uygula
alembic upgrade head

# Geri al
alembic downgrade -1
```

---

## 📊 API Endpoints (Planlanan)

### Authentication
- `POST /api/v1/auth/register` - Kayıt
- `POST /api/v1/auth/login` - Giriş
- `POST /api/v1/auth/refresh` - Token yenileme
- `POST /api/v1/auth/logout` - Çıkış

### Products
- `GET /api/v1/products` - Ürünleri listele
- `POST /api/v1/products` - Yeni ürün ekle
- `PUT /api/v1/products/{id}` - Ürünü güncelle
- `DELETE /api/v1/products/{id}` - Ürünü sil

### Finance
- `GET /api/v1/finance/balance` - Bakiye
- `POST /api/v1/finance/transaction` - İşlem ekle
- `GET /api/v1/finance/transactions` - İşlemleri listele

### Dashboard
- `GET /api/v1/dashboard/stats` - İstatistikler
- `GET /api/v1/dashboard/critical-stock` - Kritik stok

---

## 🧪 Test

```bash
# Tüm testleri çalıştır
pytest

# Spesifik test dosyasını çalıştır
pytest tests/test_auth.py

# Coverage raporu
pytest --cov=app
```

---

## 📝 Loglar

```bash
# Log dosyasını izle (Linux/macOS)
tail -f logs/app.log

# Konsola çıkt almak için main.py'de:
log_level="info"  # info, debug, warning, error
```

---

## 🚨 Hata Ayıklama

### Veritabanı Bağlantı Hatası
```
❌ Hata: Could not find driver
✅ Çözüm: PostgreSQL sürücüsü kurulmalı mı
    pip install psycopg2-binary
```

### Modül Bulunamadı
```
❌ Hata: ModuleNotFoundError: No module named 'app'
✅ Çözüm: Sanal ortam aktif değil mi?
    source venv/bin/activate
```

### Port Zaten Kullanımda
```
❌ Hata: Address already in use
✅ Çözüm: Farklı port kullan
    uvicorn main:app --port 8001
```

---

## 📚 Bağlantılar

- [FastAPI Dokümantasyonu](https://fastapi.tiangolo.com/)
- [SQLAlchemy Dokümantasyonu](https://docs.sqlalchemy.org/)
- [Pydantic Dokümantasyonu](https://docs.pydantic.dev/)
- [JWT Token'ları](https://jwt.io/)

---

## 👨‍💻 Katkıda Bulunma

1. Yeni özellik için branch oluştur: `git checkout -b feature/yeni-ozellik`
2. Değişikliklerinizi commit'leyin: `git commit -m "Açıklama"`
3. Branch'ı push'layın: `git push origin feature/yeni-ozellik`
4. Pull Request açın

---

## 📄 Lisans

Bu proje özel kullanımdır. Tüm hakları saklıdır.

---

**Son Güncelleme:** 28 Nisan 2026  
**Geliştirici:** Berat Bayramkivrak
