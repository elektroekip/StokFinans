# ============================================================
# StokFinans Backend - Ana Uygulama Dosyası
# ============================================================
# Bu dosya, FastAPI uygulamasını başlatır ve tüm
# endpoint'leri (API çağrılarını) yönetir.
#
# Çalıştırma: uvicorn main:app --reload
# API Docs: http://localhost:8000/docs
# ============================================================

import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from app.core.database import init_db, test_connection, engine
from sqlalchemy import text

# Çevre değişkenlerini .env dosyasından yükle
load_dotenv()

# ============================================================
# FastAPI Uygulaması Oluştur
# ============================================================

app = FastAPI(
    title="StokFinans API",
    description="Otomotiv aksesuar stok ve finans yönetim sistemi",
    version="1.0.0",
    docs_url="/api/docs",  # Swagger UI
    redoc_url="/api/redoc",  # ReDoc
)

# ============================================================
# CORS (Cross-Origin Resource Sharing) Ayarları
# ============================================================
# React (localhost:5173) frontend'i, backend'e (localhost:8000)
# çağrı yapabilsin diye izin veriyoruz.

CORS_ORIGINS = [
    o.strip() for o in os.getenv(
        "CORS_ORIGINS",
        "http://localhost:5000,http://localhost:5173,http://127.0.0.1:5000"
    ).split(",") if o.strip()
]

# Replit önizleme/dağıtım domainlerine regex ile izin (alt-alanlar için).
# Yalnızca tam host eşleşsin diye anchor (^ ... $) ve host etiketi karakter sınıfı kullanılır;
# aksi halde "evil.replit.dev.attacker.com" gibi alanlar geçebilir.
CORS_ORIGIN_REGEX = os.getenv(
    "CORS_ORIGIN_REGEX",
    r"^https://([a-zA-Z0-9-]+\.)+(replit\.dev|repl\.co|replit\.app)$"
)

if os.getenv("ENVIRONMENT") != "production":
    print(f"[CORS] Origins: {CORS_ORIGINS}")
    print(f"[CORS] Origin regex: {CORS_ORIGIN_REGEX}")

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_origin_regex=CORS_ORIGIN_REGEX,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================
# Abonelik Süre Kontrolü Middleware
# ============================================================
# Süresi dolmuş bayi (sub_expires_at <= now) sadece şu prefixleri kullanabilir:
#   /api/v1/auth/*          (profile/logout)
#   /api/v1/subscription/*  (paket görüntü, checkout, ödeme polling)
#   /api/v1/superadmin/*    (zaten süper admin'e özel; ayrıca bypass'ler içeride)
#   /api/v1/files/*         (public dosya download)
# Diğer her API isteği 402 Payment Required ile bloklanır.
# CORS preflight (OPTIONS) ve OpenAPI dokümantasyon path'leri her zaman geçer.

from fastapi import Request
from fastapi.responses import JSONResponse
from datetime import datetime, timezone

_SUB_GUARD_WHITELIST_PREFIXES = (
    "/api/v1/auth/",
    "/api/v1/subscription/",
    "/api/v1/superadmin/",
    "/api/v1/files/",
    "/api/v1/public/",
    "/api/v1/auth/register-notice",
    "/api/v1/auth/terms",
    "/api/v1/auth/verify-email",
    "/api/v1/devices/",  # ESP cihazlar api_key ile çalışır; bayi endpoints her zaman açık
    "/api/v1/camera/",   # Kamera: ESP32 upload (api_key) + frontend görüntü (JWT) — aboneliğe takılmamalı
)


@app.middleware("http")
async def subscription_guard_middleware(request: Request, call_next):
    path = request.url.path or ""

    # Sadece API path'lerini koru
    if not path.startswith("/api/v1/"):
        return await call_next(request)

    # CORS preflight
    if request.method == "OPTIONS":
        return await call_next(request)

    # Whitelist prefix
    if any(path.startswith(p) for p in _SUB_GUARD_WHITELIST_PREFIXES):
        return await call_next(request)

    # Authorization header oku — yoksa router auth dependency'ine bırak (401 dönecek)
    auth_header = request.headers.get("authorization", "")
    if not auth_header.lower().startswith("bearer "):
        return await call_next(request)

    token = auth_header.split(" ", 1)[1].strip()
    if not token:
        return await call_next(request)

    # Token decode
    from app.utils.security import verify_token
    payload = verify_token(token)
    if not payload:
        return await call_next(request)

    # ÖNEMLİ: token "sub" alanında email tutuluyor; gerçek user id "user_id" alanında.
    # Önce user_id'ye bak; yoksa fallback olarak sub'a (legacy tokenlar için).
    user_id_raw = payload.get("user_id") or payload.get("sub")
    try:
        user_id = int(user_id_raw)
    except (TypeError, ValueError):
        return await call_next(request)

    # DB'den minimal user kontrolü
    from app.core.database import SessionLocal
    from app.models import User
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            return await call_next(request)
        if user.is_super_admin:
            return await call_next(request)

        # BTB müşteriler abonelik kontrolünden muaf (sub_expires_at yok)
        if getattr(user, "role", None) == "btb_musteri":
            return await call_next(request)

        # Çalışan ise patron'un abonelik tarihini kontrol et
        eff_user = user
        if getattr(user, "parent_user_id", None):
            parent = db.query(User).filter(User.id == int(user.parent_user_id)).first()
            if parent:
                if parent.is_super_admin:
                    return await call_next(request)
                eff_user = parent

        now_utc = datetime.now(timezone.utc)
        expires = eff_user.sub_expires_at
        # sub_expires_at None veya geçmiş ise blok
        if expires is None or expires <= now_utc:
            return JSONResponse(
                status_code=402,
                content={
                    "detail": "Aboneliğiniz sona erdi. Devam etmek için bir paket satın alın.",
                    "code": "subscription_expired",
                },
            )
    except Exception as e:
        # Middleware hatası uygulamayı boğmasın; hatayı logla, geçişe izin ver
        print(f"[SUB_GUARD] beklenmeyen hata: {e}")
    finally:
        db.close()

    return await call_next(request)


# ============================================================
# Güvenlik Middleware — IP Ban + Rate Limiting
# ============================================================
# Bu middleware subscription_guard'dan SONRA tanımlandığı için
# Starlette'in LIFO sarma düzeninde daha ÖNCE çalışır.

import threading
from collections import defaultdict

_ip_ban_cache: set = set()
_ip_ban_cache_ts: float = 0.0
_IP_BAN_CACHE_TTL = 60.0  # saniye

_rate_buckets: dict = defaultdict(list)
_rate_lock = threading.Lock()

# Auth endpoint rate limit: dakikada max X istek/IP
_RATE_LIMIT_RULES = {
    "/api/v1/auth/login":            (10, 60),
    "/api/v1/auth/register":         (5,  60),
    "/api/v1/auth/forgot-password":  (5,  60),
    "/api/v1/auth/reset-password":   (5,  60),
}

# ── Hesap bazlı rate limit (IP'den bağımsız) ──────────────────────────────
# Key: email adresi  →  Value: istek zaman damgaları listesi
# Proxy havuzuyla IP rotation yapan saldırganları engeller.
# forgot-password: 5 dakikada 3 istek → sonraki 15 dakika kilitli
_account_buckets: dict = defaultdict(list)
_account_lock = threading.Lock()
_ACCOUNT_RATE_RULES: dict[str, tuple] = {
    "/api/v1/auth/forgot-password": (3, 300, 900),  # max_req, window_sn, lockout_sn
    "/api/v1/auth/login":           (10, 300, 300), # 10 başarısız/5dk → 5dk kilit
}


def _check_account_rate_limit(email: str, path: str) -> bool:
    """
    True = istek geçebilir.  False = hesap kilitli, isteği reddet.
    Kilit süresi (lockout_sn) boyunca email'e yeni istek atılamaz.
    """
    rule = _ACCOUNT_RATE_RULES.get(path)
    if not rule or not email:
        return True
    max_req, window, lockout = rule
    import time
    now = time.time()
    key = f"{path}:{email.lower()}"
    with _account_lock:
        bucket = _account_buckets[key]
        # Pencere+kilit süresini aş → temizle
        _account_buckets[key] = [t for t in bucket if t > now - max(window, lockout)]
        bucket = _account_buckets[key]
        if len(bucket) >= max_req:
            oldest = min(bucket)
            # En eski istek hâlâ lockout süresi içindeyse reddet
            if now - oldest < lockout:
                return False
        _account_buckets[key].append(now)
        return True


def clear_account_rate_limit(email: str, path: str):
    """Başarılı işlem sonrası hesap kilidini temizle."""
    key = f"{path}:{email.lower()}"
    with _account_lock:
        _account_buckets.pop(key, None)


def _get_client_ip(request: Request) -> str:
    """Nginx'in X-Real-IP başlığına güven; X-Forwarded-For spooflanabilir."""
    real_ip = request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip.strip()
    return (request.client.host if request.client else "unknown")


def _check_rate_limit(ip: str, path: str) -> bool:
    """True = istek geçebilir, False = limit aşıldı."""
    rule = _RATE_LIMIT_RULES.get(path)
    if not rule:
        return True
    max_req, window = rule
    import time
    now = time.time()
    cutoff = now - window
    with _rate_lock:
        bucket = _rate_buckets[f"{ip}:{path}"]
        # Eski kayıtları temizle
        _rate_buckets[f"{ip}:{path}"] = [t for t in bucket if t > cutoff]
        if len(_rate_buckets[f"{ip}:{path}"]) >= max_req:
            return False
        _rate_buckets[f"{ip}:{path}"].append(now)
        return True


def _refresh_ban_cache_if_needed(db):
    import time
    global _ip_ban_cache, _ip_ban_cache_ts
    now = time.time()
    if now - _ip_ban_cache_ts < _IP_BAN_CACHE_TTL:
        return
    try:
        from app.models.security import IpBan
        bans = db.query(IpBan).all()
        now_dt = datetime.utcnow()
        _ip_ban_cache = {
            b.ip_address for b in bans
            if b.expires_at is None or b.expires_at > now_dt
        }
        _ip_ban_cache_ts = now
    except Exception:
        pass


def invalidate_ban_cache():
    """Yeni ban eklendiğinde çağrılır."""
    global _ip_ban_cache_ts
    _ip_ban_cache_ts = 0.0


@app.middleware("http")
async def sync_delta_middleware(request: Request, call_next):
    """
    Her başarılı yazma isteğinden sonra delta push tetikler (debounce 3 sn).
    Sync endpoint'lerinin kendi istekleri, okuma istekleri ve kamera frame'leri hariç.
    """
    response = await call_next(request)
    path = request.url.path or ""
    if (
        request.method in ("POST", "PUT", "PATCH", "DELETE")
        and response.status_code < 400
        and "/sync" not in path
        and "/camera/" not in path   # Kamera frame'leri veri değiştirmez, sync tetikleme
        and path.startswith("/api/v1/")
    ):
        try:
            from app.services.sync_service import trigger_delta_push
            trigger_delta_push()
        except Exception:
            pass
        try:
            from app.api.events import notify
            notify()
        except Exception:
            pass
    return response


@app.middleware("http")
async def security_middleware(request: Request, call_next):
    path = request.url.path or ""

    # OPTIONS ve docs yollarını atla
    if request.method == "OPTIONS" or not path.startswith("/api/"):
        return await call_next(request)

    # Kamera endpoint'leri X-Api-Key ile korunur, yüksek frekanslıdır.
    # IP ban / rate limit bu yollar için uygulanmaz — DB açma yükünü atla.
    if path.startswith("/api/v1/camera/"):
        return await call_next(request)

    ip = _get_client_ip(request)

    # Ban cache süresi dolmadıysa DB bağlantısı açmadan sadece bellekten kontrol et
    import time as _time
    if _time.time() - _ip_ban_cache_ts < _IP_BAN_CACHE_TTL:
        if ip not in _ip_ban_cache and _check_rate_limit(ip, path):
            return await call_next(request)
        # Geçersiz istek — aşağıdaki DB bloğu işleyecek (ban log kaydı için açılır)

    from app.core.database import SessionLocal
    from app.models.security import SecurityLog, IpBan

    db = SessionLocal()
    try:
        _refresh_ban_cache_if_needed(db)

        # ── IP Ban kontrolü ──────────────────────────────────────
        if ip in _ip_ban_cache:
            log = SecurityLog(
                ip_address=ip,
                event_type="banned_access",
                path=path,
                method=request.method,
                user_agent=request.headers.get("user-agent", "")[:500],
                details="Yasaklı IP erişim denemesi",
            )
            db.add(log)
            db.commit()
            return JSONResponse(
                status_code=403,
                content={"detail": "Erişiminiz engellenmiştir."},
            )

        # ── Rate limit kontrolü ──────────────────────────────────
        if not _check_rate_limit(ip, path):
            log = SecurityLog(
                ip_address=ip,
                event_type="rate_limited",
                path=path,
                method=request.method,
                user_agent=request.headers.get("user-agent", "")[:500],
                details=f"Dakika limiti aşıldı: {path}",
            )
            db.add(log)
            db.commit()
            return JSONResponse(
                status_code=429,
                content={"detail": "Çok fazla istek. Lütfen bir dakika bekleyin."},
            )
    except Exception as e:
        print(f"[SECURITY_MW] hata: {e}")
    finally:
        db.close()

    return await call_next(request)


# ============================================================
# Veritabanını Başlat
# ============================================================

def _apply_runtime_migrations():
    """
    Hafif idempotent migration: SQLAlchemy create_all yalnızca eksik tablo/kolonları
    ekler, mevcut kısıtları değiştirmez. Burada bayiler arası izolasyon için
    barkod kısıtını global'den (user_id, barcode) çiftine çeviriyoruz.
    """
    statements = [
        # Eski global unique constraint/index'leri kaldır (varsa)
        "ALTER TABLE products DROP CONSTRAINT IF EXISTS products_barcode_key",
        "DROP INDEX IF EXISTS ix_products_barcode",
        # Yeni bayi-bazlı unique constraint (NULL barkodlar birden fazla olabilir,
        # PostgreSQL unique kuralında NULL'lar farklı kabul edilir)
        "ALTER TABLE products DROP CONSTRAINT IF EXISTS uq_products_user_barcode",
        "ALTER TABLE products ADD CONSTRAINT uq_products_user_barcode UNIQUE (user_id, barcode)",
        # Barkod aramaları hızlı kalsın diye non-unique index ekle
        "CREATE INDEX IF NOT EXISTS ix_products_barcode ON products (barcode)",
        # Kategoriler için view_mode kolonu (eski tablolarda eksikse ekle)
        "ALTER TABLE categories ADD COLUMN IF NOT EXISTS view_mode VARCHAR(20) NOT NULL DEFAULT 'list'",
        # API dışı yazımlara karşı veri bütünlüğü için CHECK constraint
        "ALTER TABLE categories DROP CONSTRAINT IF EXISTS ck_categories_view_mode",
        "ALTER TABLE categories ADD CONSTRAINT ck_categories_view_mode CHECK (view_mode IN ('list','grid','masonry','carousel','category'))",
        # Ürünler için alt-etiket (marka/tür) ve para birimi
        "ALTER TABLE products ADD COLUMN IF NOT EXISTS subcategory VARCHAR(100)",
        "ALTER TABLE products ADD COLUMN IF NOT EXISTS image_url VARCHAR(1000)",
        "CREATE INDEX IF NOT EXISTS ix_products_subcategory ON products (subcategory)",
        "ALTER TABLE products ADD COLUMN IF NOT EXISTS currency VARCHAR(3) NOT NULL DEFAULT 'TRY'",
        "CREATE INDEX IF NOT EXISTS ix_products_currency ON products (currency)",
        "ALTER TABLE products DROP CONSTRAINT IF EXISTS ck_products_currency",
        "ALTER TABLE products ADD CONSTRAINT ck_products_currency CHECK (currency IN ('TRY','USD','EUR'))",
        "ALTER TABLE products ADD COLUMN IF NOT EXISTS cost_currency VARCHAR(3) NOT NULL DEFAULT 'TRY'",
        "CREATE INDEX IF NOT EXISTS ix_products_cost_currency ON products (cost_currency)",
        "ALTER TABLE products DROP CONSTRAINT IF EXISTS ck_products_cost_currency",
        "ALTER TABLE products ADD CONSTRAINT ck_products_cost_currency CHECK (cost_currency IN ('TRY','USD','EUR'))",
        # Ürünler için ek kategoriler (multi-tag JSONB array)
        "ALTER TABLE products ADD COLUMN IF NOT EXISTS extra_categories JSONB NOT NULL DEFAULT '[]'::jsonb",
        "CREATE INDEX IF NOT EXISTS ix_products_extra_categories ON products USING GIN (extra_categories)",
        # İşlemler için para birimi
        "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS currency VARCHAR(3) NOT NULL DEFAULT 'TRY'",
        "CREATE INDEX IF NOT EXISTS ix_transactions_currency ON transactions (currency)",
        "ALTER TABLE transactions DROP CONSTRAINT IF EXISTS ck_transactions_currency",
        "ALTER TABLE transactions ADD CONSTRAINT ck_transactions_currency CHECK (currency IN ('TRY','USD','EUR'))",
        # Süper yönetici flag'i (platform sahibi)
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS is_super_admin BOOLEAN NOT NULL DEFAULT FALSE",
        "CREATE INDEX IF NOT EXISTS ix_users_is_super_admin ON users (is_super_admin)",
        # Referans takibi: yeni kullanıcı kimin koduyla geldi
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS referred_by_user_id INTEGER",
        "CREATE INDEX IF NOT EXISTS ix_users_referred_by_user_id ON users (referred_by_user_id)",
        # Abonelik geçmişi tablosu (yoksa oluştur)
        """CREATE TABLE IF NOT EXISTS subscription_events (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            event_type VARCHAR(50) NOT NULL,
            days_delta INTEGER NOT NULL,
            days_before INTEGER NOT NULL DEFAULT 0,
            days_after INTEGER NOT NULL DEFAULT 0,
            actor_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
            related_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
            note VARCHAR(500),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_sub_events_user_id ON subscription_events (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_sub_events_event_type ON subscription_events (event_type)",
        "CREATE INDEX IF NOT EXISTS ix_sub_events_created_at ON subscription_events (created_at)",
        "CREATE INDEX IF NOT EXISTS ix_sub_events_user_created ON subscription_events (user_id, created_at)",
        "CREATE INDEX IF NOT EXISTS ix_sub_events_actor_user_id ON subscription_events (actor_user_id)",
        # ====== ABONELİK PAKETLERİ ======
        """CREATE TABLE IF NOT EXISTS packages (
            id SERIAL PRIMARY KEY,
            slug VARCHAR(32) UNIQUE NOT NULL,
            name VARCHAR(100) NOT NULL,
            description VARCHAR(500),
            price_try INTEGER NOT NULL DEFAULT 0,
            duration_days INTEGER NOT NULL DEFAULT 30,
            max_products INTEGER,
            max_transactions INTEGER,
            has_support BOOLEAN NOT NULL DEFAULT FALSE,
            is_featured BOOLEAN NOT NULL DEFAULT FALSE,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            sort_order INTEGER NOT NULL DEFAULT 0,
            features_json JSONB NOT NULL DEFAULT '[]'::jsonb,
            color_class VARCHAR(50),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_packages_slug ON packages (slug)",
        # 3 paket seed (idempotent)
        """INSERT INTO packages (slug, name, description, price_try, duration_days, max_products, max_transactions, has_support, is_featured, is_active, sort_order, features_json, color_class)
           VALUES
             ('starter', 'Başlangıç', 'Küçük işletmeler için temel stok ve finans yönetimi', 500, 30, 500, 1000, FALSE, FALSE, TRUE, 1,
              '["500 stok yönetim ögesi","1000 finans kaydı","Temel stok takibi","Temel finans modülleri","Destek hizmeti yok"]'::jsonb, 'slate'),
             ('pro', 'Orta Paket', 'Büyüyen işletmeler için en çok tercih edilen paket', 1000, 30, 1000, NULL, FALSE, TRUE, TRUE, 2,
              '["1000 stok yönetim ögesi","Sınırsız finans kaydı","Tüm stok modülleri","Tüm finans modülleri","Standart destek"]'::jsonb, 'indigo'),
             ('premium', 'Premium Paket', 'Profesyonel işletmeler için tüm özellikler', 2000, 30, 50000, NULL, TRUE, FALSE, TRUE, 3,
              '["Sınırsız stok yönetim ögesi","Sınırsız finans kaydı","Tüm modüller","Ücretsiz öncelikli destek","Gelişmiş raporlar","Tüm ek özellikler"]'::jsonb, 'amber')
           ON CONFLICT (slug) DO NOTHING""",
        # ====== ÖDEMELER ======
        """CREATE TABLE IF NOT EXISTS payments (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            package_slug VARCHAR(32) NOT NULL,
            amount_try INTEGER NOT NULL,
            paytr_merchant_oid VARCHAR(64) UNIQUE NOT NULL,
            paytr_payment_token VARCHAR(255),
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            error_message VARCHAR(500),
            days_added INTEGER,
            test_mode INTEGER NOT NULL DEFAULT 0,
            user_ip VARCHAR(64),
            callback_received_at TIMESTAMPTZ,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            completed_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_payments_user_id ON payments (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_payments_status ON payments (status)",
        "CREATE INDEX IF NOT EXISTS ix_payments_created_at ON payments (created_at)",
        "CREATE INDEX IF NOT EXISTS ix_payments_package_slug ON payments (package_slug)",
        # ====== PAYTR AYARLARI (tek satır) ======
        """CREATE TABLE IF NOT EXISTS paytr_settings (
            id SERIAL PRIMARY KEY,
            merchant_id VARCHAR(64),
            merchant_key VARCHAR(128),
            merchant_salt VARCHAR(128),
            test_mode BOOLEAN NOT NULL DEFAULT TRUE,
            callback_url VARCHAR(500),
            success_url VARCHAR(500),
            fail_url VARCHAR(500),
            is_configured BOOLEAN NOT NULL DEFAULT FALSE,
            updated_at TIMESTAMPTZ,
            updated_by_user_id INTEGER
        )""",
        "INSERT INTO paytr_settings (id, test_mode, is_configured) VALUES (1, TRUE, FALSE) ON CONFLICT (id) DO NOTHING",
        # ====== USERS abonelik alanları ======
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS company_address VARCHAR(500)",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS company_phone VARCHAR(50)",
        # ====== ÇALIŞAN/Personel ilişkisi ======
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS parent_user_id INTEGER",
        "CREATE INDEX IF NOT EXISTS ix_users_parent_user_id ON users (parent_user_id)",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS permissions JSONB",
        # employee_invites tablosu (idempotent)
        """CREATE TABLE IF NOT EXISTS employee_invites (
            id SERIAL PRIMARY KEY,
            email VARCHAR(255) UNIQUE NOT NULL,
            full_name VARCHAR(255) NOT NULL,
            parent_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            permissions JSONB NOT NULL DEFAULT '[]'::jsonb,
            is_consumed BOOLEAN NOT NULL DEFAULT FALSE,
            consumed_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
            consumed_at TIMESTAMPTZ,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_employee_invites_email ON employee_invites (email)",
        "CREATE INDEX IF NOT EXISTS ix_employee_invites_parent_consumed ON employee_invites (parent_user_id, is_consumed)",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS package_slug VARCHAR(32) NOT NULL DEFAULT 'starter'",
        "CREATE INDEX IF NOT EXISTS ix_users_package_slug ON users (package_slug)",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS sub_expires_at TIMESTAMPTZ",
        "CREATE INDEX IF NOT EXISTS ix_users_sub_expires_at ON users (sub_expires_at)",
        # Geçmiş kullanıcılar için sub_expires_at backfill: NULL olanlara now() + sub_days gün ver
        "UPDATE users SET sub_expires_at = NOW() + (COALESCE(sub_days, 0) || ' days')::interval WHERE sub_expires_at IS NULL",
        # ====== E-POSTA DOĞRULAMA ======
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS is_email_verified BOOLEAN NOT NULL DEFAULT TRUE",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verification_token VARCHAR(128)",
        "CREATE INDEX IF NOT EXISTS ix_users_email_verification_token ON users (email_verification_token)",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS token_expires_at TIMESTAMPTZ",
        # ====== E-POSTA DEĞİŞİKLİĞİ (onay bekleyen e-posta) ======
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS pending_email VARCHAR(255)",
        # ====== ŞİFRE SIFIRLAMA ======
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS password_reset_token VARCHAR(128)",
        "CREATE INDEX IF NOT EXISTS ix_users_password_reset_token ON users (password_reset_token)",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS password_reset_expires_at TIMESTAMPTZ",
        # ====== SMTP AYARLARI (tek satır) ======
        """CREATE TABLE IF NOT EXISTS smtp_settings (
            id SERIAL PRIMARY KEY,
            host VARCHAR(255),
            port INTEGER NOT NULL DEFAULT 587,
            username VARCHAR(255),
            password VARCHAR(500),
            from_email VARCHAR(255),
            from_name VARCHAR(255) DEFAULT 'StokFinans',
            use_tls BOOLEAN NOT NULL DEFAULT TRUE,
            use_ssl BOOLEAN NOT NULL DEFAULT FALSE,
            is_configured BOOLEAN NOT NULL DEFAULT FALSE,
            updated_at TIMESTAMPTZ
        )""",
        "INSERT INTO smtp_settings (id, port, use_tls, use_ssl, is_configured) VALUES (1, 587, TRUE, FALSE, FALSE) ON CONFLICT (id) DO NOTHING",
        # ====== KAYIT BİLDİRİMİ (tek satır) ======
        """CREATE TABLE IF NOT EXISTS register_notices (
            id SERIAL PRIMARY KEY,
            is_enabled BOOLEAN NOT NULL DEFAULT FALSE,
            title VARCHAR(255) DEFAULT 'Duyuru',
            message VARCHAR(2000) DEFAULT '',
            color VARCHAR(32) DEFAULT 'indigo',
            updated_at TIMESTAMPTZ
        )""",
        "INSERT INTO register_notices (id, is_enabled, title, message, color) VALUES (1, FALSE, 'Duyuru', '', 'indigo') ON CONFLICT (id) DO NOTHING",
        # ====== SİTE ŞARTLARI (tek satır) ======
        """CREATE TABLE IF NOT EXISTS terms_settings (
            id SERIAL PRIMARY KEY,
            is_enabled BOOLEAN NOT NULL DEFAULT FALSE,
            content TEXT DEFAULT '',
            updated_at TIMESTAMPTZ
        )""",
        "INSERT INTO terms_settings (id, is_enabled, content) VALUES (1, FALSE, '') ON CONFLICT (id) DO NOTHING",
        # ====== BAYİ YEDEKLER ======
        """CREATE TABLE IF NOT EXISTS bayi_backups (
            id VARCHAR(36) PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            filename VARCHAR(255) NOT NULL,
            password_encrypted VARCHAR(500) NOT NULL,
            size_bytes BIGINT NOT NULL DEFAULT 0,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            restored_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_bayi_backups_user_id ON bayi_backups(user_id)",
        # ====== FAZ 2: FTP/SFTP SUNUCULARI ======
        """CREATE TABLE IF NOT EXISTS ftp_servers (
            id SERIAL PRIMARY KEY,
            name VARCHAR(120) NOT NULL,
            type VARCHAR(8) NOT NULL DEFAULT 'sftp',
            host VARCHAR(255) NOT NULL,
            port INTEGER NOT NULL DEFAULT 22,
            username VARCHAR(255) NOT NULL,
            password_encrypted VARCHAR(500) NOT NULL,
            base_path VARCHAR(500) NOT NULL DEFAULT '/',
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        # ====== FAZ 2: SUNUCU EŞLEŞMESİ (ANA↔AYNA) ======
        # ====== FAZ 3: KDV (İşlemlere KDV oranı) ======
        "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS kdv_rate NUMERIC(5,2) NOT NULL DEFAULT 0",
        # ====== FAZ 3: GARANTİ BELGELERİ ======
        """CREATE TABLE IF NOT EXISTS warranties (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            product_name VARCHAR(255) NOT NULL,
            product_image_url VARCHAR(1000),
            customer_name VARCHAR(255) NOT NULL,
            customer_phone VARCHAR(40),
            duration_label VARCHAR(40) NOT NULL DEFAULT '1 yıl',
            duration_days INTEGER NOT NULL DEFAULT 365,
            start_date TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            end_date TIMESTAMPTZ NOT NULL,
            public_token VARCHAR(64) NOT NULL UNIQUE,
            notes VARCHAR(2000),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_warranties_user_id ON warranties (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_warranties_customer_name ON warranties (customer_name)",
        "CREATE INDEX IF NOT EXISTS ix_warranties_public_token ON warranties (public_token)",
        "CREATE INDEX IF NOT EXISTS ix_warranties_user_end_date ON warranties (user_id, end_date)",
        # Görüntülenme istatistikleri (debtor_links pattern'i ile aynı):
        # Public link her açıldığında view_count++ ve last_viewed_at güncellenir.
        # Süperadmin paneli bu kolonları kullanır.
        "ALTER TABLE warranties ADD COLUMN IF NOT EXISTS view_count INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE warranties ADD COLUMN IF NOT EXISTS last_viewed_at TIMESTAMPTZ",
        # ====== FAZ 3: BORÇLU SLİP LİNKLERİ ======
        """CREATE TABLE IF NOT EXISTS debtor_links (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            customer_name VARCHAR(255) NOT NULL,
            public_token VARCHAR(64) NOT NULL UNIQUE,
            expires_at TIMESTAMPTZ,
            last_viewed_at TIMESTAMPTZ,
            view_count INTEGER NOT NULL DEFAULT 0,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_debtor_links_user_id ON debtor_links (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_debtor_links_customer_name ON debtor_links (customer_name)",
        "CREATE INDEX IF NOT EXISTS ix_debtor_links_public_token ON debtor_links (public_token)",
        "CREATE INDEX IF NOT EXISTS ix_debtor_links_user_customer ON debtor_links (user_id, customer_name)",
        # ====== FAZ 2: SUNUCU EŞLEŞMESİ (ANA↔AYNA) ======
        """CREATE TABLE IF NOT EXISTS sync_peer (
            id INTEGER PRIMARY KEY DEFAULT 1,
            role VARCHAR(16) NOT NULL DEFAULT 'mirror',
            peer_url VARCHAR(500) NOT NULL,
            peer_token_encrypted VARCHAR(500) NOT NULL,
            our_token VARCHAR(128) NOT NULL,
            last_heartbeat_at TIMESTAMPTZ,
            last_sync_at TIMESTAMPTZ,
            last_error TEXT,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_sync_peer_our_token ON sync_peer(our_token)",
        # Destek/Talep sistemi
        """DO $$ BEGIN
           CREATE TYPE ticket_category_enum AS ENUM ('bug', 'request', 'suggestion', 'other');
         EXCEPTION WHEN duplicate_object THEN NULL; END $$""",
        """DO $$ BEGIN
           CREATE TYPE ticket_status_enum AS ENUM ('open', 'in_progress', 'closed');
         EXCEPTION WHEN duplicate_object THEN NULL; END $$""",
        """CREATE TABLE IF NOT EXISTS support_tickets (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            subject VARCHAR(255) NOT NULL,
            category ticket_category_enum NOT NULL DEFAULT 'other',
            status ticket_status_enum NOT NULL DEFAULT 'open',
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_support_tickets_user_id ON support_tickets(user_id)",
        "CREATE INDEX IF NOT EXISTS ix_support_tickets_status ON support_tickets(status)",
        """CREATE TABLE IF NOT EXISTS support_messages (
            id SERIAL PRIMARY KEY,
            ticket_id INTEGER NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
            sender_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
            is_from_admin BOOLEAN NOT NULL DEFAULT FALSE,
            body TEXT NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_support_messages_ticket_id ON support_messages(ticket_id)",
        # ====== ESP CİHAZ YÖNETİMİ ======
        """CREATE TABLE IF NOT EXISTS devices (
            id SERIAL PRIMARY KEY,
            device_id VARCHAR(64) UNIQUE NOT NULL,
            device_type VARCHAR(16) NOT NULL DEFAULT 'ESP8266',
            api_key VARCHAR(64) UNIQUE NOT NULL,
            user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
            is_paired BOOLEAN NOT NULL DEFAULT FALSE,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            paired_at TIMESTAMPTZ,
            firmware_version VARCHAR(32),
            ip_address VARCHAR(64),
            mac_address VARCHAR(64),
            wifi_ssid VARCHAR(128),
            wifi_rssi INTEGER,
            free_heap INTEGER,
            uptime_seconds INTEGER,
            last_seen TIMESTAMPTZ,
            pending_firmware_esp8266 VARCHAR(256),
            pending_firmware_esp32 VARCHAR(256),
            pending_firmware_version VARCHAR(32),
            firmware_update_requested_at TIMESTAMPTZ,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            notes TEXT
        )""",
        "CREATE INDEX IF NOT EXISTS ix_devices_device_id ON devices (device_id)",
        "CREATE INDEX IF NOT EXISTS ix_devices_api_key ON devices (api_key)",
        "CREATE INDEX IF NOT EXISTS ix_devices_user_id ON devices (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_devices_is_paired ON devices (is_paired)",
        # Cihaz varyantı (ekran / barkod / standart vb.)
        "ALTER TABLE devices ADD COLUMN IF NOT EXISTS variant VARCHAR(32) NOT NULL DEFAULT 'standart'",
        "CREATE INDEX IF NOT EXISTS ix_devices_variant ON devices (variant)",
        # OTA indirme sayacı — 2+ deneme = sorun sinyali
        "ALTER TABLE devices ADD COLUMN IF NOT EXISTS ota_attempt_count INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE devices ADD COLUMN IF NOT EXISTS ota_last_attempt_at TIMESTAMPTZ",
        # ====== ARAÇ YÖNETİMİ ======
        """CREATE TABLE IF NOT EXISTS vehicles (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            plate VARCHAR(20) NOT NULL,
            nickname VARCHAR(100),
            assigned_employee_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
            assigned_employee_name VARCHAR(255),
            status VARCHAR(20) NOT NULL DEFAULT 'parked',
            notes TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_vehicles_user_id ON vehicles (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_vehicles_status ON vehicles (status)",
        """CREATE TABLE IF NOT EXISTS vehicle_items (
            id SERIAL PRIMARY KEY,
            vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
            product_id INTEGER NOT NULL REFERENCES products(id),
            product_name VARCHAR(255) NOT NULL,
            unit_price FLOAT NOT NULL DEFAULT 0,
            currency VARCHAR(3) NOT NULL DEFAULT 'TRY',
            quantity INTEGER NOT NULL DEFAULT 0,
            loaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_vehicle_items_vehicle_id ON vehicle_items (vehicle_id)",
        "CREATE INDEX IF NOT EXISTS ix_vehicle_items_product_id ON vehicle_items (product_id)",
        # Araç satışı FK — transactions tablosuna
        "ALTER TABLE transactions ADD COLUMN IF NOT EXISTS vehicle_id INTEGER REFERENCES vehicles(id) ON DELETE SET NULL",
        "CREATE INDEX IF NOT EXISTS ix_transactions_vehicle_id ON transactions (vehicle_id)",
        # ====== ARAÇ ATAMALARI (çok-çalışan) ======
        """CREATE TABLE IF NOT EXISTS vehicle_assignments (
            id SERIAL PRIMARY KEY,
            vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            user_name VARCHAR(255) NOT NULL,
            role VARCHAR(32) NOT NULL DEFAULT 'driver',
            assigned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            assigned_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL
        )""",
        "CREATE INDEX IF NOT EXISTS ix_vehicle_assignments_vehicle_id ON vehicle_assignments (vehicle_id)",
        "CREATE INDEX IF NOT EXISTS ix_vehicle_assignments_user_id ON vehicle_assignments (user_id)",
        # ====== ARAÇ LOGU ======
        """CREATE TABLE IF NOT EXISTS vehicle_logs (
            id SERIAL PRIMARY KEY,
            vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
            user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
            user_name VARCHAR(255) NOT NULL,
            action VARCHAR(64) NOT NULL,
            details TEXT,
            vehicle_status VARCHAR(20),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_vehicle_logs_vehicle_id ON vehicle_logs (vehicle_id)",
        "CREATE INDEX IF NOT EXISTS ix_vehicle_logs_created_at ON vehicle_logs (vehicle_id, created_at DESC)",
        # ====== GÜVENLİK LOGLARI ======
        """CREATE TABLE IF NOT EXISTS security_logs (
            id SERIAL PRIMARY KEY,
            ip_address VARCHAR(45) NOT NULL,
            event_type VARCHAR(50) NOT NULL,
            email_attempted VARCHAR(255),
            user_id INTEGER,
            user_email VARCHAR(255),
            user_name VARCHAR(255),
            user_role VARCHAR(50),
            path VARCHAR(500),
            method VARCHAR(10),
            user_agent VARCHAR(500),
            details TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_security_logs_ip ON security_logs (ip_address)",
        "CREATE INDEX IF NOT EXISTS ix_security_logs_event ON security_logs (event_type)",
        "CREATE INDEX IF NOT EXISTS ix_security_logs_created ON security_logs (created_at DESC)",
        # ====== IP BAN LİSTESİ ======
        """CREATE TABLE IF NOT EXISTS ip_bans (
            id SERIAL PRIMARY KEY,
            ip_address VARCHAR(45) NOT NULL UNIQUE,
            reason VARCHAR(500),
            banned_by VARCHAR(255),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            expires_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_ip_bans_ip ON ip_bans (ip_address)",
        # ====== ANA PANEL DÜZENİ (kullanıcı tercihleri) ======
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS dashboard_layout JSONB",
        # ====== ÇOK-SUNUCULU SYNC ALTYAPISI ======
        """CREATE TABLE IF NOT EXISTS sync_nodes (
            id SERIAL PRIMARY KEY,
            name VARCHAR(100) NOT NULL DEFAULT 'Sunucu',
            display_order INTEGER NOT NULL DEFAULT 1,
            url VARCHAR(500),
            our_token VARCHAR(128) NOT NULL DEFAULT '',
            peer_token_encrypted VARCHAR(500),
            is_self BOOLEAN NOT NULL DEFAULT FALSE,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            last_heartbeat_at TIMESTAMPTZ,
            last_sync_at TIMESTAMPTZ,
            last_error TEXT,
            sys_cpu_count INTEGER,
            sys_ram_gb FLOAT,
            sys_disk_total_gb FLOAT,
            sys_disk_free_gb FLOAT,
            sys_os VARCHAR(200),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_sync_nodes_is_self ON sync_nodes (is_self)",
        "CREATE INDEX IF NOT EXISTS ix_sync_nodes_display_order ON sync_nodes (display_order)",
        """CREATE TABLE IF NOT EXISTS sync_logs (
            id SERIAL PRIMARY KEY,
            from_node_name VARCHAR(100) NOT NULL,
            to_node_name VARCHAR(100) NOT NULL,
            event_type VARCHAR(20) NOT NULL,
            records_total INTEGER,
            duration_ms INTEGER,
            error TEXT,
            details JSONB,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_sync_logs_created_at ON sync_logs (created_at DESC)",
        """CREATE TABLE IF NOT EXISTS sync_deletions (
            id SERIAL PRIMARY KEY,
            table_name VARCHAR(100) NOT NULL,
            row_id INTEGER NOT NULL,
            deleted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_sync_deletions_table_row ON sync_deletions (table_name, row_id)",
        "CREATE INDEX IF NOT EXISTS ix_sync_deletions_deleted_at ON sync_deletions (deleted_at DESC)",
        # sync_nodes: son pull zaman takibi (bidirektif delta için)
        "ALTER TABLE sync_nodes ADD COLUMN IF NOT EXISTS last_pull_at TIMESTAMPTZ",
        # ====== BTB (İŞLETMEDEN İŞLETMEYE) MODÜLÜ ======
        """CREATE TABLE IF NOT EXISTS btb_customers (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            company_name VARCHAR(255) NOT NULL,
            contact_person VARCHAR(255),
            phone VARCHAR(30),
            email VARCHAR(255),
            vkn VARCHAR(20),
            address TEXT,
            notes TEXT,
            credit_limit FLOAT NOT NULL DEFAULT 0,
            payment_term_days INTEGER NOT NULL DEFAULT 30,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_btb_customers_user_id ON btb_customers (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_btb_customers_company_name ON btb_customers (company_name)",
        """CREATE TABLE IF NOT EXISTS btb_orders (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            customer_id INTEGER NOT NULL REFERENCES btb_customers(id) ON DELETE RESTRICT,
            order_number VARCHAR(30) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'draft',
            notes TEXT,
            due_date DATE,
            total_amount FLOAT NOT NULL DEFAULT 0,
            currency VARCHAR(3) NOT NULL DEFAULT 'TRY',
            transaction_id INTEGER REFERENCES transactions(id) ON DELETE SET NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_btb_orders_user_id ON btb_orders (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_btb_orders_customer_id ON btb_orders (customer_id)",
        "CREATE INDEX IF NOT EXISTS ix_btb_orders_status ON btb_orders (status)",
        "CREATE INDEX IF NOT EXISTS ix_btb_orders_order_number ON btb_orders (order_number)",
        """CREATE TABLE IF NOT EXISTS btb_order_items (
            id SERIAL PRIMARY KEY,
            order_id INTEGER NOT NULL REFERENCES btb_orders(id) ON DELETE CASCADE,
            product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
            product_name VARCHAR(255) NOT NULL,
            unit_price FLOAT NOT NULL,
            currency VARCHAR(3) NOT NULL DEFAULT 'TRY',
            quantity INTEGER NOT NULL DEFAULT 1,
            kdv_rate NUMERIC(5,2) NOT NULL DEFAULT 0
        )""",
        "CREATE INDEX IF NOT EXISTS ix_btb_order_items_order_id ON btb_order_items (order_id)",
        # BTB is_paid + paid_at
        "ALTER TABLE btb_orders ADD COLUMN IF NOT EXISTS is_paid BOOLEAN NOT NULL DEFAULT FALSE",
        "ALTER TABLE btb_orders ADD COLUMN IF NOT EXISTS paid_at TIMESTAMPTZ",
        "CREATE INDEX IF NOT EXISTS ix_btb_orders_is_paid ON btb_orders (is_paid)",
        # ── BTB GENİŞLETME: müşteri/sipariş/kalem yeni kolonlar ──
        "ALTER TABLE btb_customers ADD COLUMN IF NOT EXISTS category VARCHAR(1) NOT NULL DEFAULT 'B'",
        "ALTER TABLE btb_customers ADD COLUMN IF NOT EXISTS discount_rate FLOAT NOT NULL DEFAULT 0",
        "ALTER TABLE btb_customers ADD COLUMN IF NOT EXISTS tax_office VARCHAR(255)",
        "ALTER TABLE btb_orders ADD COLUMN IF NOT EXISTS subtotal FLOAT NOT NULL DEFAULT 0",
        "ALTER TABLE btb_orders ADD COLUMN IF NOT EXISTS kdv_amount FLOAT NOT NULL DEFAULT 0",
        "ALTER TABLE btb_orders ADD COLUMN IF NOT EXISTS discount_rate FLOAT NOT NULL DEFAULT 0",
        "ALTER TABLE btb_orders ADD COLUMN IF NOT EXISTS discount_amount FLOAT NOT NULL DEFAULT 0",
        "ALTER TABLE btb_orders ADD COLUMN IF NOT EXISTS shipping_address TEXT",
        "ALTER TABLE btb_orders ADD COLUMN IF NOT EXISTS shipping_carrier VARCHAR(100)",
        "ALTER TABLE btb_orders ADD COLUMN IF NOT EXISTS tracking_number VARCHAR(100)",
        "ALTER TABLE btb_order_items ADD COLUMN IF NOT EXISTS discount_rate FLOAT NOT NULL DEFAULT 0",
        "ALTER TABLE btb_order_items ADD COLUMN IF NOT EXISTS line_total FLOAT NOT NULL DEFAULT 0",
        # ── BTB ÖDEMELER (kısmi ödeme) ────────────────────────────
        """CREATE TABLE IF NOT EXISTS btb_payments (
            id SERIAL PRIMARY KEY,
            order_id INTEGER NOT NULL REFERENCES btb_orders(id) ON DELETE CASCADE,
            amount FLOAT NOT NULL,
            payment_method VARCHAR(30) NOT NULL DEFAULT 'cash',
            notes TEXT,
            paid_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_btb_payments_order_id ON btb_payments (order_id)",
        "CREATE INDEX IF NOT EXISTS ix_btb_payments_paid_at ON btb_payments (paid_at)",
        # ── TOPTANCI / TEDARİKÇİ MODÜLÜ ──────────────────────────
        """CREATE TABLE IF NOT EXISTS suppliers (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            company_name VARCHAR(255) NOT NULL,
            contact_person VARCHAR(255),
            phone VARCHAR(30),
            email VARCHAR(255),
            vkn VARCHAR(20),
            tax_office VARCHAR(255),
            address TEXT,
            notes TEXT,
            payment_term_days INTEGER NOT NULL DEFAULT 30,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_suppliers_user_id ON suppliers (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_suppliers_company_name ON suppliers (company_name)",
        """CREATE TABLE IF NOT EXISTS purchase_orders (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            supplier_id INTEGER NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
            order_number VARCHAR(30) NOT NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'draft',
            notes TEXT,
            expected_date DATE,
            subtotal FLOAT NOT NULL DEFAULT 0,
            kdv_amount FLOAT NOT NULL DEFAULT 0,
            total_amount FLOAT NOT NULL DEFAULT 0,
            currency VARCHAR(3) NOT NULL DEFAULT 'TRY',
            transaction_id INTEGER REFERENCES transactions(id) ON DELETE SET NULL,
            is_paid BOOLEAN NOT NULL DEFAULT FALSE,
            paid_at TIMESTAMPTZ,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_purchase_orders_user_id ON purchase_orders (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_purchase_orders_supplier_id ON purchase_orders (supplier_id)",
        "CREATE INDEX IF NOT EXISTS ix_purchase_orders_status ON purchase_orders (status)",
        "CREATE INDEX IF NOT EXISTS ix_purchase_orders_order_number ON purchase_orders (order_number)",
        """CREATE TABLE IF NOT EXISTS purchase_order_items (
            id SERIAL PRIMARY KEY,
            order_id INTEGER NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
            product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
            product_name VARCHAR(255) NOT NULL,
            unit_price FLOAT NOT NULL DEFAULT 0,
            currency VARCHAR(3) NOT NULL DEFAULT 'TRY',
            quantity INTEGER NOT NULL DEFAULT 1,
            kdv_rate NUMERIC(5,2) NOT NULL DEFAULT 0,
            line_total FLOAT NOT NULL DEFAULT 0
        )""",
        "CREATE INDEX IF NOT EXISTS ix_purchase_order_items_order_id ON purchase_order_items (order_id)",
        # ====== BTB FİYAT LİSTESİ ======
        """CREATE TABLE IF NOT EXISTS btb_price_lists (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            category VARCHAR(3) NOT NULL DEFAULT 'ALL',
            product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
            product_name VARCHAR(255) NOT NULL,
            custom_price FLOAT,
            discount_override FLOAT,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_btb_price_lists_user_id ON btb_price_lists (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_btb_price_lists_category ON btb_price_lists (category)",
        "CREATE INDEX IF NOT EXISTS ix_btb_price_lists_product_id ON btb_price_lists (product_id)",
        # ====== PLASİYER / SAHA SATIŞ ======
        """CREATE TABLE IF NOT EXISTS customer_visits (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            btb_customer_id INTEGER REFERENCES btb_customers(id) ON DELETE SET NULL,
            customer_name VARCHAR(255) NOT NULL,
            latitude FLOAT,
            longitude FLOAT,
            address_label VARCHAR(500),
            check_in_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            check_out_at TIMESTAMPTZ,
            duration_minutes INTEGER,
            notes TEXT,
            result VARCHAR(30) NOT NULL DEFAULT 'visited',
            btb_order_id INTEGER REFERENCES btb_orders(id) ON DELETE SET NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_customer_visits_user_id ON customer_visits (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_customer_visits_btb_customer_id ON customer_visits (btb_customer_id)",
        "CREATE INDEX IF NOT EXISTS ix_customer_visits_check_in_at ON customer_visits (check_in_at DESC)",
        """CREATE TABLE IF NOT EXISTS visit_plans (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            btb_customer_id INTEGER REFERENCES btb_customers(id) ON DELETE SET NULL,
            customer_name VARCHAR(255) NOT NULL,
            planned_date DATE NOT NULL,
            planned_order INTEGER NOT NULL DEFAULT 1,
            notes TEXT,
            status VARCHAR(20) NOT NULL DEFAULT 'planned',
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_visit_plans_user_id ON visit_plans (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_visit_plans_planned_date ON visit_plans (planned_date)",
        # ====== ERP WEBHOOK ENTEGRASYONu ======
        """CREATE TABLE IF NOT EXISTS erp_webhooks (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            name VARCHAR(100) NOT NULL,
            event_types JSONB NOT NULL DEFAULT '[]'::jsonb,
            url VARCHAR(500) NOT NULL,
            secret_key VARCHAR(255),
            headers_json JSONB,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            last_triggered_at TIMESTAMPTZ,
            last_http_status INTEGER,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_erp_webhooks_user_id ON erp_webhooks (user_id)",
        """CREATE TABLE IF NOT EXISTS erp_sync_logs (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            webhook_id INTEGER REFERENCES erp_webhooks(id) ON DELETE SET NULL,
            event_type VARCHAR(50) NOT NULL,
            payload_json JSONB,
            http_status_code INTEGER,
            response_body TEXT,
            duration_ms INTEGER,
            success BOOLEAN NOT NULL DEFAULT FALSE,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_erp_sync_logs_user_id ON erp_sync_logs (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_erp_sync_logs_webhook_id ON erp_sync_logs (webhook_id)",
        "CREATE INDEX IF NOT EXISTS ix_erp_sync_logs_created_at ON erp_sync_logs (created_at DESC)",
        # ====== SANAL POS / ÖDEME GEÇİDİ ======
        """CREATE TABLE IF NOT EXISTS payment_gateways (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            name VARCHAR(100) NOT NULL,
            provider VARCHAR(30) NOT NULL DEFAULT 'manual',
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            test_mode BOOLEAN NOT NULL DEFAULT TRUE,
            commission_rate FLOAT NOT NULL DEFAULT 0,
            config_json JSONB,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_payment_gateways_user_id ON payment_gateways (user_id)",
        """CREATE TABLE IF NOT EXISTS pos_transactions (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            btb_order_id INTEGER REFERENCES btb_orders(id) ON DELETE SET NULL,
            gateway_id INTEGER REFERENCES payment_gateways(id) ON DELETE SET NULL,
            transaction_ref VARCHAR(100),
            amount FLOAT NOT NULL,
            currency VARCHAR(3) NOT NULL DEFAULT 'TRY',
            commission_rate FLOAT NOT NULL DEFAULT 0,
            commission_amount FLOAT NOT NULL DEFAULT 0,
            is_commission_reflected BOOLEAN NOT NULL DEFAULT FALSE,
            installments INTEGER NOT NULL DEFAULT 1,
            card_last4 VARCHAR(4),
            card_bank VARCHAR(100),
            status VARCHAR(20) NOT NULL DEFAULT 'success',
            notes TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_pos_transactions_user_id ON pos_transactions (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_pos_transactions_btb_order_id ON pos_transactions (btb_order_id)",
        # ====== DBS (DOĞRUDAN BORÇLANDIRMA) ======
        """CREATE TABLE IF NOT EXISTS dbs_agreements (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            bank_code VARCHAR(10) NOT NULL,
            bank_name VARCHAR(100) NOT NULL,
            agreement_ref VARCHAR(100),
            credit_limit FLOAT NOT NULL DEFAULT 0,
            currency VARCHAR(3) NOT NULL DEFAULT 'TRY',
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            notes TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_dbs_agreements_user_id ON dbs_agreements (user_id)",
        """CREATE TABLE IF NOT EXISTS dbs_invoices (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            agreement_id INTEGER REFERENCES dbs_agreements(id) ON DELETE SET NULL,
            btb_order_id INTEGER REFERENCES btb_orders(id) ON DELETE SET NULL,
            btb_customer_id INTEGER REFERENCES btb_customers(id) ON DELETE SET NULL,
            customer_name VARCHAR(255) NOT NULL,
            invoice_no VARCHAR(50) NOT NULL,
            amount FLOAT NOT NULL,
            currency VARCHAR(3) NOT NULL DEFAULT 'TRY',
            due_date DATE NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            sent_at TIMESTAMPTZ,
            collected_at TIMESTAMPTZ,
            failure_reason VARCHAR(500),
            notes TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_dbs_invoices_user_id ON dbs_invoices (user_id)",
        "CREATE INDEX IF NOT EXISTS ix_dbs_invoices_agreement_id ON dbs_invoices (agreement_id)",
        "CREATE INDEX IF NOT EXISTS ix_dbs_invoices_due_date ON dbs_invoices (due_date)",
        "CREATE INDEX IF NOT EXISTS ix_dbs_invoices_status ON dbs_invoices (status)",
        # ====== BTB MÜŞTERİ PORTALI (eski sistem — korundu, silinmedi) ======
        """CREATE TABLE IF NOT EXISTS btb_portal_accounts (
            id SERIAL PRIMARY KEY,
            btb_customer_id INTEGER NOT NULL REFERENCES btb_customers(id) ON DELETE CASCADE,
            bayi_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            email VARCHAR(255) NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            full_name VARCHAR(255),
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            last_login TIMESTAMPTZ,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ,
            UNIQUE (btb_customer_id)
        )""",
        "CREATE INDEX IF NOT EXISTS ix_btb_portal_accounts_bayi_user_id ON btb_portal_accounts (bayi_user_id)",
        "CREATE INDEX IF NOT EXISTS ix_btb_portal_accounts_email ON btb_portal_accounts (email)",
        # ====== BTB AKTİVİTE LOGLARI (yeni müşteri sistemi) ======
        """CREATE TABLE IF NOT EXISTS btb_activity_logs (
            id SERIAL PRIMARY KEY,
            btb_customer_id INTEGER NOT NULL REFERENCES btb_customers(id) ON DELETE CASCADE,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            action VARCHAR(100) NOT NULL,
            details TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_btb_activity_logs_btb_customer_id ON btb_activity_logs(btb_customer_id)",
        "CREATE INDEX IF NOT EXISTS ix_btb_activity_logs_user_id ON btb_activity_logs(user_id)",
        "CREATE INDEX IF NOT EXISTS ix_btb_activity_logs_created_at ON btb_activity_logs(created_at)",
        # ====== BTB MÜŞTERİ linked_user_id KOLONU ======
        "ALTER TABLE btb_customers ADD COLUMN IF NOT EXISTS linked_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL",
        "DROP INDEX IF EXISTS uq_btb_customers_linked_user_id",
        "CREATE INDEX IF NOT EXISTS ix_btb_customers_linked_user_id ON btb_customers(linked_user_id) WHERE linked_user_id IS NOT NULL",
        # ====== DEPOLAMA HAVUZU (Faz 1) ======
        """CREATE TABLE IF NOT EXISTS storage_nodes (
            id SERIAL PRIMARY KEY,
            name VARCHAR(120) NOT NULL,
            type VARCHAR(20) NOT NULL DEFAULT 'minio',
            host VARCHAR(255),
            port INTEGER,
            username VARCHAR(255),
            password_encrypted VARCHAR(500),
            access_key VARCHAR(255),
            secret_key_encrypted VARCHAR(500),
            bucket VARCHAR(255),
            endpoint_url VARCHAR(500),
            base_path VARCHAR(500) NOT NULL DEFAULT '/',
            total_bytes BIGINT,
            used_bytes BIGINT,
            free_bytes BIGINT,
            is_primary BOOLEAN NOT NULL DEFAULT FALSE,
            is_master_backup BOOLEAN NOT NULL DEFAULT FALSE,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            last_check_at TIMESTAMPTZ,
            last_error VARCHAR(500),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        """CREATE TABLE IF NOT EXISTS storage_files (
            id SERIAL PRIMARY KEY,
            filename VARCHAR(500) NOT NULL,
            storage_key VARCHAR(500) NOT NULL UNIQUE,
            size_bytes BIGINT NOT NULL DEFAULT 0,
            content_type VARCHAR(255),
            checksum_sha256 VARCHAR(64),
            user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
            uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_storage_files_filename ON storage_files (filename)",
        "CREATE INDEX IF NOT EXISTS ix_storage_files_storage_key ON storage_files (storage_key)",
        "CREATE INDEX IF NOT EXISTS ix_storage_files_user_id ON storage_files (user_id)",
        """CREATE TABLE IF NOT EXISTS storage_file_replicas (
            id SERIAL PRIMARY KEY,
            file_id INTEGER NOT NULL REFERENCES storage_files(id) ON DELETE CASCADE,
            node_id INTEGER NOT NULL REFERENCES storage_nodes(id) ON DELETE CASCADE,
            path_on_node VARCHAR(500) NOT NULL,
            is_primary BOOLEAN NOT NULL DEFAULT FALSE,
            is_verified BOOLEAN NOT NULL DEFAULT FALSE,
            last_verified_at TIMESTAMPTZ,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_storage_file_replicas_file_id ON storage_file_replicas (file_id)",
        "CREATE INDEX IF NOT EXISTS ix_storage_file_replicas_node_id ON storage_file_replicas (node_id)",
        """CREATE TABLE IF NOT EXISTS storage_daily_backups (
            id SERIAL PRIMARY KEY,
            node_id INTEGER REFERENCES storage_nodes(id) ON DELETE SET NULL,
            backup_type VARCHAR(20) NOT NULL DEFAULT 'daily',
            includes_db BOOLEAN NOT NULL DEFAULT TRUE,
            includes_files BOOLEAN NOT NULL DEFAULT TRUE,
            filename VARCHAR(500),
            size_bytes BIGINT,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            error TEXT,
            backup_date TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            expires_at TIMESTAMPTZ,
            completed_at TIMESTAMPTZ,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_storage_daily_backups_status ON storage_daily_backups (status)",
        "CREATE INDEX IF NOT EXISTS ix_storage_daily_backups_backup_date ON storage_daily_backups (backup_date DESC)",
        "CREATE INDEX IF NOT EXISTS ix_storage_daily_backups_expires_at ON storage_daily_backups (expires_at)",
        # Faz 8: Harici S3 yedek alanları
        "ALTER TABLE storage_nodes ADD COLUMN IF NOT EXISTS is_external_backup BOOLEAN NOT NULL DEFAULT FALSE",
        "ALTER TABLE storage_daily_backups ADD COLUMN IF NOT EXISTS external_backup_status VARCHAR(20)",
        "ALTER TABLE storage_daily_backups ADD COLUMN IF NOT EXISTS external_backup_at TIMESTAMPTZ",
        "ALTER TABLE storage_daily_backups ADD COLUMN IF NOT EXISTS external_backup_error TEXT",
        # Canlı topoloji olay tablosu
        """CREATE TABLE IF NOT EXISTS topology_events (
            id SERIAL PRIMARY KEY,
            event_type VARCHAR(50) NOT NULL,
            from_node VARCHAR(100),
            to_node VARCHAR(100),
            message TEXT,
            created_at TIMESTAMPTZ DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_topology_events_created_at ON topology_events (created_at DESC)",
        "CREATE INDEX IF NOT EXISTS ix_topology_events_id ON topology_events (id DESC)",
        # Soft delete + incremental backup + DR test
        "ALTER TABLE storage_files ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ",
        "CREATE INDEX IF NOT EXISTS ix_storage_files_deleted_at ON storage_files (deleted_at) WHERE deleted_at IS NOT NULL",
        "ALTER TABLE storage_daily_backups ADD COLUMN IF NOT EXISTS backup_scope VARCHAR(20) NOT NULL DEFAULT 'full'",
        "ALTER TABLE storage_daily_backups ADD COLUMN IF NOT EXISTS dr_tested_at TIMESTAMPTZ",
        "ALTER TABLE storage_daily_backups ADD COLUMN IF NOT EXISTS dr_test_result VARCHAR(20)",
        # ====== TOPLU DEPLOY (Dağıtım Yönetimi) ======
        """CREATE TABLE IF NOT EXISTS deploy_batches (
            id VARCHAR(36) PRIMARY KEY,
            initiated_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
            bundle_size_bytes BIGINT,
            status VARCHAR(50) NOT NULL DEFAULT 'in_progress',
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )""",
        "CREATE INDEX IF NOT EXISTS ix_deploy_batches_created_at ON deploy_batches (created_at DESC)",
        "CREATE INDEX IF NOT EXISTS ix_deploy_batches_status ON deploy_batches (status)",
        """CREATE TABLE IF NOT EXISTS deploy_batch_items (
            id SERIAL PRIMARY KEY,
            batch_id VARCHAR(36) NOT NULL REFERENCES deploy_batches(id) ON DELETE CASCADE,
            sync_node_id INTEGER REFERENCES sync_nodes(id) ON DELETE SET NULL,
            node_name VARCHAR(100) NOT NULL,
            status VARCHAR(50) NOT NULL DEFAULT 'queued',
            error_message TEXT,
            started_at TIMESTAMPTZ,
            completed_at TIMESTAMPTZ
        )""",
        "CREATE INDEX IF NOT EXISTS ix_deploy_batch_items_batch_id ON deploy_batch_items (batch_id)",
        "CREATE INDEX IF NOT EXISTS ix_deploy_batch_items_sync_node_id ON deploy_batch_items (sync_node_id)",
    ]
    for sql in statements:
        try:
            with engine.begin() as conn:
                conn.execute(text(sql))
        except Exception as exc:
            print(f"[MIGRATION] Atlandı ({sql[:60]}...): {exc}")
    print("[MIGRATION] Çoklu kiracılık (multi-tenant) barkod kısıtları uygulandı")

    # ====== fin_garanti TEMİZLİĞİ ======
    # 'fin_garanti' finans kategorisi artık varsayılanlardan kaldırıldı (garantide
    # tutar yoktur — garanti belgeleri için ayrı `/api/v1/warranty` modülü var).
    # Mevcut kullanıcıların seed edilmiş `is_default=True` fin_garanti kategorilerini
    # SADECE bu kategoride hiç işlem (transaction_type='garanti') yoksa siliyoruz.
    # NULL-safe ve tenant-safe olması için NOT EXISTS kullanıyoruz (NOT IN değil).
    # Verisi olan kullanıcılara dokunmuyoruz; onlar UI'dan elle taşıyıp silebilir.
    try:
        with engine.begin() as conn:
            # Önce kaç adet aday var, kaç tanesi gerçekten silinecek raporla
            kept = conn.execute(text(
                """
                SELECT COUNT(*) FROM categories c
                WHERE c.kind = 'finans'
                  AND c.key = 'fin_garanti'
                  AND c.is_default = TRUE
                  AND EXISTS (
                      SELECT 1 FROM transactions t
                      WHERE t.user_id = c.user_id
                        AND t.transaction_type = 'garanti'
                  )
                """
            )).scalar() or 0

            result = conn.execute(text(
                """
                DELETE FROM categories c
                WHERE c.kind = 'finans'
                  AND c.key = 'fin_garanti'
                  AND c.is_default = TRUE
                  AND NOT EXISTS (
                      SELECT 1 FROM transactions t
                      WHERE t.user_id = c.user_id
                        AND t.transaction_type = 'garanti'
                  )
                """
            ))
            deleted = result.rowcount or 0
            if deleted or kept:
                print(f"[MIGRATION] fin_garanti temizliği — silinen: {deleted}, korunan (verisi olan): {kept}")
    except Exception as exc:
        print(f"[MIGRATION] fin_garanti temizliği atlandı: {exc}")


def _migrate_employee_permissions_to_granular():
    """
    Tek seferlik & idempotent: çalışan kullanıcılar ve davetlerin permissions
    alanlarındaki eski koarse-grained ('products', 'finance', ...) izinleri
    granüler izinlere ('products.view','finance.veresiye.add', ...) genişletir.
    Zaten granüler formatta olanlar atlanır.
    """
    from sqlalchemy.orm import Session as _Session
    from app.core.database import SessionLocal as _Session_factory
    from app.models.user import User as _User
    from app.models.employee_invite import EmployeeInvite as _Invite
    from app.utils.permissions import expand_legacy as _expand

    legacy_keys = {"products", "finance", "reports", "profile"}
    db: _Session = _Session_factory()
    changed_users = 0
    changed_invites = 0
    try:
        for u in db.query(_User).filter(_User.role == "calisan").all():
            perms = u.permissions or []
            if any(isinstance(p, str) and p in legacy_keys for p in perms):
                u.permissions = _expand(perms)
                db.add(u)
                changed_users += 1
        for inv in db.query(_Invite).all():
            perms = inv.permissions or []
            if any(isinstance(p, str) and p in legacy_keys for p in perms):
                inv.permissions = _expand(perms)
                db.add(inv)
                changed_invites += 1
        if changed_users or changed_invites:
            db.commit()
            print(f"[MIGRATION] Granüler izin geçişi: {changed_users} kullanıcı, {changed_invites} davet güncellendi")
        else:
            print("[MIGRATION] Granüler izin geçişi: güncellenecek kayıt yok")
    finally:
        db.close()


def get_super_admin_emails() -> list[str]:
    """SUPER_ADMIN_EMAILS env'inden whitelist'i (lowercase) döndürür."""
    raw = os.getenv("SUPER_ADMIN_EMAILS", "beratbayramkivrak@stokfinans.com")
    return [e.strip().lower() for e in raw.split(",") if e.strip()]


def is_email_super_admin(email: str) -> bool:
    """Verilen e-posta adresi süper yönetici whitelist'inde mi?"""
    if not email:
        return False
    return email.strip().lower() in get_super_admin_emails()


def _bootstrap_super_admins():
    """
    SUPER_ADMIN_EMAILS env'indeki e-postaları (varsa) startup'ta süper admin
    olarak işaretler. Geriye dönük senkron amacıyla tutuluyor; kayıt sırasında
    is_email_super_admin() ile anlık atama yapılır.
    """
    emails = get_super_admin_emails()
    if not emails:
        return
    try:
        with engine.begin() as conn:
            conn.execute(
                text(
                    "UPDATE users SET is_super_admin = TRUE "
                    "WHERE LOWER(email) = ANY(:emails) AND is_super_admin = FALSE"
                ),
                {"emails": emails},
            )
        print(f"[BOOTSTRAP] Süper yönetici whitelist uygulandı: {emails}")
    except Exception as exc:
        print(f"[BOOTSTRAP] Süper yönetici flag'leme hatası: {exc}")


@app.on_event("startup")
async def startup_event():
    """Uygulama başlatılırken çalışacak fonksiyon"""
    print("\n" + "="*60)
    print("[STARTUP] StokFinans Backend Başlatılıyor...")
    print("="*60)

    # Tabloları oluştur
    try:
        init_db()
        print("[OK] Veritabanı tabloları oluşturuldu")
    except Exception as e:
        print(f"[WARNING] Tablolar zaten var veya hata: {e}")

    # Şema göçleri (özellikle barkod kısıtının bayi-bazlı olması için)
    try:
        _apply_runtime_migrations()
    except Exception as e:
        print(f"[WARNING] Migration hatası: {e}")

    # Çalışan izinleri: eski (legacy) koarse-grained -> yeni granüler format
    try:
        _migrate_employee_permissions_to_granular()
    except Exception as e:
        print(f"[WARNING] Personel izin göçü hatası: {e}")

    # Süper yönetici whitelist (env: SUPER_ADMIN_EMAILS)
    try:
        _bootstrap_super_admins()
    except Exception as e:
        print(f"[WARNING] Süper yönetici bootstrap hatası: {e}")

    # Bağlantıyı test et
    if test_connection():
        print("[OK] Veritabanı bağlantısı başarılı")
    else:
        print("[ERROR] Veritabanı bağlantı hatası!")

    # Süresi dolmuş token ve oturum kayıtlarını temizle
    try:
        from app.core.database import SessionLocal as _SL
        _s = _SL()
        try:
            _s.execute(text("DELETE FROM revoked_tokens WHERE expires_at < NOW()"))
            _s.execute(text("DELETE FROM user_sessions WHERE expires_at < NOW()"))
            _s.commit()
            print("[OK] Süresi dolmuş revoked token'lar ve oturumlar temizlendi")
        finally:
            _s.close()
    except Exception as e:
        print(f"[WARNING] Token/oturum temizleme hatası: {e}")

    # Deploy finalizasyonu — yeniden başlatma sonrası durum güncelle
    try:
        from app.services.deploy_service import finalize_deploy_on_startup
        finalize_deploy_on_startup()
    except Exception as e:
        print(f"[WARNING] Deploy finalizasyon hatası: {e}")

    # MinIO bucket bootstrap
    try:
        from app.services.storage_service import ensure_bucket_exists
        ensure_bucket_exists()
        print("[OK] MinIO bucket hazır")
    except Exception as e:
        print(f"[WARNING] MinIO bucket bootstrap: {e}")

    # Sync zamanlayıcısı (peer heartbeat + mirror auto-pull)
    try:
        from app.services.sync_scheduler import start_scheduler
        start_scheduler()
    except Exception as e:
        print(f"[WARNING] Sync scheduler başlatılamadı: {e}")

    print("="*60 + "\n")

@app.on_event("shutdown")
async def shutdown_event():
    """Uygulama kapatılırken çalışacak fonksiyon"""
    try:
        from app.services.sync_scheduler import stop_scheduler
        stop_scheduler()
    except Exception:
        pass
    print("\n[SHUTDOWN] StokFinans Backend kapatılıyor...\n")

# ============================================================
# Ana Endpoint'ler
# ============================================================

@app.get("/", tags=["Root"])
async def read_root():
    """
    Ana sayfa - API canlı mı kontrol et

    **Döner:**
    - message: Hoşgeldin mesajı
    - version: API versiyonu
    - docs: Dokümantasyon bağlantıları
    """
    return {
        "message": "🎉 StokFinans API'ye Hoşgeldiniz!",
        "version": "1.0.0",
        "docs": {
            "swagger": "/api/docs",
            "redoc": "/api/redoc",
        },
        "status": "🟢 Online"
    }

@app.get("/health", tags=["Health Check"])
async def health_check():
    """
    Sağlık kontrolü - Uygulama çalışıyor mu?

    **Döner:**
    - status: healthy/unhealthy
    """
    return {"status": "healthy", "message": "API çalışıyor"}

# ============================================================
# API V1 Router'ları
# ============================================================

from app.api.auth import router as auth_router
from app.api.products import router as products_router
from app.api.finance import router as finance_router
from app.api.dashboard import router as dashboard_router
from app.api.files import router as files_router
from app.api.reports import router as reports_router
from app.api.categories import router as categories_router
from app.api.superadmin import router as superadmin_router
from app.api.subscription import router as subscription_router
from app.api.backup import router as backup_router
from app.api.sync import peer_router as sync_peer_router, admin_router as sync_admin_router
from app.api.warranty import router as warranty_router
from app.api.public import router as public_router
from app.api.support import router as support_router
from app.api.devices import router as devices_router
from app.api.vehicles import router as vehicles_router
from app.api.ext_admin import router as ext_admin_router
from app.api.btb import router as btb_router
from app.api.supplier import router as supplier_router
from app.api.plasiyer import router as plasiyer_router
from app.api.integrations import router as integrations_router
from app.api.btb_portal import router as btb_portal_router  # devre dışı; eski sistem
from app.api.events import router as events_router

app.include_router(auth_router, prefix="/api/v1", tags=["Authentication"])
app.include_router(products_router, prefix="/api/v1", tags=["Products"])
app.include_router(finance_router, prefix="/api/v1", tags=["Finance"])
app.include_router(dashboard_router, prefix="/api/v1", tags=["Dashboard"])
app.include_router(files_router, prefix="/api/v1", tags=["File Management"])
app.include_router(reports_router, prefix="/api/v1", tags=["Reports"])
app.include_router(categories_router, prefix="/api/v1", tags=["Categories"])
app.include_router(superadmin_router, prefix="/api/v1", tags=["SuperAdmin"])
app.include_router(subscription_router, prefix="/api/v1", tags=["Subscription"])
app.include_router(backup_router, prefix="/api/v1", tags=["Backup"])
app.include_router(sync_peer_router, prefix="/api/v1", tags=["Sync (Peer)"])
app.include_router(sync_admin_router, prefix="/api/v1", tags=["SuperAdmin (Sync)"])
app.include_router(warranty_router, prefix="/api/v1", tags=["Warranty"])
app.include_router(public_router, prefix="/api/v1", tags=["Public"])
app.include_router(support_router, prefix="/api/v1", tags=["Support"])
app.include_router(devices_router, prefix="/api/v1", tags=["Devices"])
app.include_router(vehicles_router, prefix="/api/v1", tags=["Vehicles"])
app.include_router(ext_admin_router, prefix="/api/v1", tags=["Management API"])
app.include_router(btb_router, prefix="/api/v1", tags=["BTB"])
app.include_router(supplier_router, prefix="/api/v1", tags=["Supplier"])
app.include_router(plasiyer_router, prefix="/api/v1", tags=["Plasiyer"])
app.include_router(integrations_router, prefix="/api/v1", tags=["Integrations"])
app.include_router(btb_portal_router, prefix="/api/v1", tags=["BTB Portal"])
app.include_router(events_router, prefix="/api/v1", tags=["Events"])
from app.api.storage import router as storage_router
app.include_router(storage_router, prefix="/api/v1", tags=["Storage"])
from app.api.topology import router as topology_router
app.include_router(topology_router, prefix="/api/v1", tags=["Topology"])
from app.api.camera import router as camera_router
app.include_router(camera_router, prefix="/api/v1", tags=["Camera"])
#
# from app.api.finance import router as finance_router
# app.include_router(finance_router, prefix="/api/v1", tags=["Finance"])
#
# from app.api.dashboard import router as dashboard_router
# app.include_router(dashboard_router, prefix="/api/v1", tags=["Dashboard"])

# ============================================================
# Hata Yönetimi (Exception Handlers)
# ============================================================

from fastapi import HTTPException
from fastapi.responses import JSONResponse

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """HTTP hataları güzelce döndür (FastAPI standardı: 'detail')"""
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail, "error": exc.detail}
    )

# ============================================================
# KULLANIM REHBERI
# ============================================================
#
# 1. Geliştirme Sunucusunu Başlat:
#    uvicorn main:app --reload
#
# 2. API Dokümantasyonuna Git:
#    http://localhost:8000/api/docs
#
# 3. Örnek İstekler:
#    GET http://localhost:8000/
#    GET http://localhost:8000/health
#
# 4. Arka planda çalışan işlemler:
#    - Veritabanı tabloları oluşturuluyor
#    - Bağlantı test ediliyor
#    - CORS ayarları uygulanıyor
#
# ============================================================

if __name__ == "__main__":
    # Not: Normalde uvicorn command line'dan çalışır
    # ama test için buradan da başlatılabilir
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
    )
